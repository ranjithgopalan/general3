# High-Level Design: Security Reviewer Plugin

**Feature:** Claude Code Plugin for Security Review (Design & Code)

**Status:** Implementing

**Document Type:** High-Level Design (HLD)

**Version:** 1.0

**Consumer:** Development teams requiring security assessment

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Component Design](#2-component-design)
3. [Plugin Structure](#3-plugin-structure)
4. [Agent Design](#4-agent-design)
5. [Commands Design](#5-commands-design)
6. [Review Types](#6-review-types)
7. [Data Flow](#7-data-flow)
8. [Integration Points](#8-integration-points)
9. [Error Handling Strategy](#9-error-handling-strategy)
10. [Testing Strategy](#10-testing-strategy)
11. [Revision History](#11-revision-history)

---

## 1. Architecture Overview

### 1.1 System Context

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        Security Reviewer Plugin                              │
│                                                                              │
│  Reviews for security issues that SAST/DAST tools miss:                     │
│  - Design Documents: Architecture, API specs, auth design                   │
│  - Source Code: Angular/AXIS, Node.js Lambda, business logic                │
│  - Infrastructure: SAM/CloudFormation, IAM, security configs                │
│                                                                              │
│  Focus Areas (Beyond Automated Tools):                                       │
│  - Business logic flaws                - Race conditions                     │
│  - Privilege escalation                - State machine bypasses              │
│  - Authorization logic                 - Cryptographic misuse                │
│                                                                              │
│  Produces:                                                                   │
│  - SECURITY-REVIEW-REPORT.md           - Remediation roadmap                │
│  - Confidence-based findings           - Pentest recommendations            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        /security-review Command                              │
│                         (Unified Entry Point)                                │
└───────────────────────────────┬─────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      security-reviewer-router                                │
│                  (Planning + Routing + Coordination)                         │
├─────────────────────────────────────────────────────────────────────────────┤
│  1. Analyze request (determine review scope)                                 │
│  2. Get target paths from user                                               │
│  3. Present review plan for approval                                         │
│  4. Delegate to specialized reviewers                                        │
│  5. Aggregate findings with confidence levels                                │
│  6. Generate SECURITY-REVIEW-REPORT.md                                       │
│  7. Include pentest recommendations                                          │
└───────────────────────────────┬─────────────────────────────────────────────┘
                                │
        ┌───────────────────────┼───────────────────────┬─────────────────────┐
        ▼                       ▼                       ▼                     ▼
┌───────────────┐      ┌───────────────┐      ┌───────────────┐      ┌───────────────┐
│ design-       │      │ code-         │      │ crypto-       │      │ infrastructure│
│ security-     │      │ security-     │      │ security-     │      │ -security-    │
│ reviewer      │      │ reviewer      │      │ reviewer      │      │ reviewer      │
│               │      │               │      │               │      │               │
│ Architecture  │      │ Business      │      │ Cryptographic │      │ IaC Security  │
│ Auth design   │      │ logic flaws   │      │ misuse        │      │ IAM policies  │
│ API specs     │      │ OWASP Top 10  │      │ Key mgmt      │      │ Network       │
└───────────────┘      └───────────────┘      └───────────────┘      └───────────────┘
        │                       │                       │                     │
        └───────────────────────┼───────────────────────┴─────────────────────┘
                                ▼
                    ┌───────────────────────┐
                    │  Security Output       │
                    │  - SECURITY-REPORT.md  │
                    │  - Findings + severity │
                    │  - Remediation roadmap │
                    │  - Pentest recommend   │
                    └───────────────────────┘
```

### 1.3 Multi-Agent Architecture

| Agent | Model | Purpose | Permission |
|-------|-------|---------|------------|
| security-reviewer-router | Sonnet | Request analysis, scope determination, routing, aggregation | plan |
| design-security-reviewer | Haiku | Security-first design review (HLD, API specs, auth design) | plan |
| code-security-reviewer | Haiku | Business logic flaws, OWASP Top 10, authorization code | plan |
| crypto-security-reviewer | Haiku | Cryptographic implementation review | plan |
| infrastructure-security-reviewer | Haiku | IaC security (SAM, IAM, network) | plan |

### 1.4 Architectural Principles

| Principle | Implementation |
|-----------|----------------|
| **Beyond SAST/DAST** | Focus on issues automated tools miss |
| **Confidence-Based** | HIGH/MEDIUM/LOW for all findings |
| **Evidence-Based** | Every finding has code location and PoC |
| **Human-In-The-Loop (HITL)** | All findings require human verification |
| **Read-Only** | Never modifies code, only reports findings |
| **Pentest Recommended** | Always recommend professional testing |

---

## 2. Component Design

### 2.0 Agent Architecture Pattern

The security-reviewer plugin follows a **three-tier agent architecture** that separates concerns and enables scalable, maintainable agent workflows:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          Agent Architecture Pattern                          │
├─────────────────────────────────────────────────────────────────────────────┤
│  TIER 1: COMMAND (Prompt Enricher)                                          │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  /security-review command (commands/security-review.md)                │ │
│  │  - Takes $ARGUMENTS from user (scope, targets, focus areas)            │ │
│  │  - Enriches with security rule references                              │ │
│  │  - Invokes security-reviewer-router via Task tool                      │ │
│  │  - NO routing logic (delegated to router)                              │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                    │                                         │
│                                    ▼                                         │
│  TIER 2: ROUTER (Context Engineering + Orchestration)                       │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  security-reviewer-router.md (agents/security-reviewer-router.md)      │ │
│  │  Context Engineering:                                                  │ │
│  │  - Identify review scope (design, code, crypto, infrastructure)        │ │
│  │  - Locate target documents and code paths                              │ │
│  │  - Read security-rules skill for vulnerability patterns                │ │
│  │  - Detect framework for specialized checks                             │ │
│  │                                                                        │ │
│  │  Orchestration:                                                        │ │
│  │  - Present review plan for user approval                               │ │
│  │  - Coordinate specialized reviewers in parallel                        │ │
│  │  - Aggregate findings from all reviewers                               │ │
│  │  - Generate unified SECURITY-REVIEW-REPORT.md                          │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                    │                                         │
│     ┌──────────────────┬───────────┼───────────┬──────────────────┐         │
│     ▼                  ▼           ▼           ▼                  ▼         │
│  TIER 3: SPECIALIZED AGENTS (Extended Thinking + TOON)                      │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐       │
│  │ design-      │ │ code-        │ │ crypto-      │ │ infrastructure│      │
│  │ security-    │ │ security-    │ │ security-    │ │ -security-   │       │
│  │ reviewer     │ │ reviewer     │ │ reviewer     │ │ reviewer     │       │
│  │              │ │              │ │              │ │              │       │
│  │ Architecture │ │ OWASP Top 10 │ │ Crypto impl  │ │ IAM, SAM,    │       │
│  │ API security │ │ Business     │ │ Key mgmt     │ │ CloudFormation│      │
│  │              │ │ logic flaws  │ │ Token sec    │ │              │       │
│  └──────────────┘ └──────────────┘ └──────────────┘ └──────────────┘       │
│                                                                              │
│  All agents use: Extended thinking + TOON format + Guardrails               │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Tier 1: Command as Prompt Enricher

The `/security-review` command acts as a **prompt enricher**, not a router:

```markdown
---
name: security-review
description: Unified command for comprehensive security review
---

## User Request
$ARGUMENTS

## Context Instructions
1. Identify review scope (design, code, crypto, infrastructure, or full)
2. Locate target documents and code paths
3. Determine focus areas (OWASP, business logic, auth, etc.)

## Skill References
- skills/security-rules/owasp-top-10.md
- skills/security-rules/business-logic-flaws.md
- skills/security-rules/crypto-patterns.md
- skills/security-rules/iac-security.md

## Invocation
Invoke the security-reviewer-router via Task tool with full context
```

#### Tier 2: Router with Context Engineering + Orchestration

The router has two distinct responsibilities expressed in TOON format:

```
ContextEngineering[Category,Skills]:
  ScopeDetection,"Parse user request | Identify design vs code vs infra | Determine coverage"
  TargetDiscovery,"Locate design documents | Find source code paths | Find IaC templates"
  RuleSelection,"Read security-rules skill | Select applicable vulnerability patterns | Prioritize checks"
  FrameworkDetection,"Identify Angular/AXIS | Identify Lambda | Identify cloud provider"

Orchestration[Category,Skills]:
  PlanPresentation,"Show review scope | List reviewers | Show target files | Request approval"
  ReviewerDelegation,"Route to design-security-reviewer | Route to code-security-reviewer | Route to crypto-security-reviewer | Route to infrastructure-security-reviewer"
  ParallelCoordination,"Run reviewers in parallel where possible | Handle dependencies"
  ReportAggregation,"Collect findings | Categorize by severity | Generate SECURITY-REVIEW-REPORT.md"
```

#### Tier 3: Specialized Agents with Extended Thinking + TOON

Each reviewer agent uses extended thinking and TOON format:

```markdown
[Extended thinking: I am a code-security-reviewer that identifies business logic flaws and
OWASP Top 10 vulnerabilities that automated SAST/DAST tools miss. When I receive a request
from router with context, I first (1) read skill security-rules for vulnerability patterns;
(2) read target source code files; (3) analyze for authorization bypasses; (4) check for
race conditions; (5) identify injection points; (6) detect cryptographic misuse;
(7) generate findings with severity, evidence, and remediation.]

## Capabilities
Capabilities[Category,Skills]:
  VulnerabilityDetection,"OWASP Top 10 | Business logic flaws | Authorization bypasses | Race conditions"
  ContextAnalysis,"Understand business context | Identify trust boundaries | Trace data flow"
  RemediationGuidance,"Provide fix recommendations | Reference security patterns | Suggest alternatives"

## Behavioral Traits
BehavioralTraits[Trait,Description]:
  NonDestructive,"Read-only analysis - never modifies code"
  EvidenceBased,"Each finding includes file, line, and code context"
  SeverityRating,"Each finding rated Critical/High/Medium/Low/Informational"

## Guardrails
INPUT_BLOCKING_CONDITIONS[Category,Triggers]:
  SCOPE_VIOLATION,"Code modification requests | Exploitation guidance requests"
  MALICIOUS_INTENT,"Requests to help bypass security | Attack development requests"
```

### 2.1 Layer 1: Request Analysis & Routing

**Component:** `security-reviewer-router`

**Responsibilities:**
- Analyze user request to determine review scope
- Get target paths for design docs and/or code
- Present review plan for user approval
- Coordinate specialized security reviewers
- Aggregate findings from all reviewers
- Generate unified SECURITY-REVIEW-REPORT.md
- Include professional penetration testing recommendations

**Scope Detection:**
```
Detection Rules:
1. IF user mentions "design", "architecture", "HLD", "API spec"
   → Include design-security-reviewer
   → Get design document paths

2. IF user mentions "code", "source", "implementation"
   → Include code-security-reviewer
   → Get source code paths

3. IF user mentions "crypto", "encryption", "JWT", "tokens"
   → Include crypto-security-reviewer

4. IF user mentions "infrastructure", "IAM", "SAM", "CloudFormation"
   → Include infrastructure-security-reviewer

5. IF user mentions "full", "complete", "comprehensive"
   → Run all reviewers
```

### 2.2 Layer 2: Specialized Security Reviewers

#### 2.2.1 Design Security Reviewer

**Purpose:** Review design documents for security-first approach

**Input:**
- Architecture documents (HLD, system design)
- API specifications
- Authentication/Authorization design
- Data flow diagrams

**Review Checklist:**
| Category | Security Check |
|----------|----------------|
| Authentication | MFA considered? Session management? Token strategy? |
| Authorization | Least privilege? Role separation? Resource ownership? |
| Data Protection | Encryption at rest/transit? Data classification? |
| API Security | Rate limiting? Input validation? Error handling? |
| Network | Defense in depth? Security boundaries? |

**Output:** Design security findings with confidence levels

#### 2.2.2 Code Security Reviewer

**Purpose:** Identify business logic flaws and OWASP Top 10 issues

**Input:**
- Angular/AXIS components
- Node.js Lambda handlers
- Services, guards, interceptors
- Business logic code

**Focus Areas:**
| Vulnerability | What to Find |
|---------------|--------------|
| Horizontal Privilege Escalation | User A accesses User B's data |
| Vertical Privilege Escalation | User becomes admin |
| Authorization Bypass | Skipping access checks |
| Race Conditions (TOCTOU) | Check-then-act vulnerabilities |
| State Machine Bypass | Skipping workflow steps |
| Business Rule Circumvention | Manipulating calculations |

**Output:** Code security findings with PoC and remediation

#### 2.2.3 Crypto Security Reviewer

**Purpose:** Review cryptographic implementations

**Input:**
- Encryption/decryption code
- Key management
- Token generation (JWT)
- Password hashing

**Review Areas:**
| Area | Issues to Find |
|------|----------------|
| Algorithm Choice | MD5/SHA1, ECB mode, weak ciphers |
| Key Management | Hardcoded keys, weak derivation |
| Random Numbers | Math.random() for security |
| Token Security | JWT algorithm confusion, weak secrets |
| Hashing | Unsalted passwords, fast hashes |

**Output:** Cryptographic findings with fix recommendations

#### 2.2.4 Infrastructure Security Reviewer

**Purpose:** Review Infrastructure as Code for security issues

**Input:**
- SAM/CloudFormation templates
- CDK constructs
- Terraform configurations
- Lambda configurations
- API Gateway settings

**Review Areas:**
| IaC Type | Security Issues |
|----------|----------------|
| IAM Policies | Overly permissive, wildcard resources |
| Lambda | Environment secrets, excessive permissions |
| API Gateway | Missing auth, CORS misconfiguration |
| Security Groups | Open ingress, missing egress rules |
| S3 Buckets | Public access, missing encryption |

**Output:** Infrastructure findings with secure configurations

---

## 3. Plugin Structure

```
security-reviewer/
├── .claude-plugin/
│   └── plugin.json                          # Plugin manifest
│
├── requirements/
│   ├── security-reviewer-brd.md             # Business requirements
│   ├── security-reviewer-hld.md             # This document
│   └── security-reviewer-lld.md             # Implementation details
│
├── agents/
│   ├── security-reviewer-router.md          # Planning router (entry point)
│   ├── design-security-reviewer.md          # Design document review
│   ├── code-security-reviewer.md            # Code vulnerability detection
│   ├── crypto-security-reviewer.md          # Cryptographic review
│   ├── infrastructure-security-reviewer.md  # IaC security review
│   └── security-reviewer.md                 # Original agent (reference)
│
├── commands/
│   ├── security-review.md                   # Unified security review
│   └── check-dependencies.md                # Dependency vulnerability check
│
├── skills/
│   └── security-checklists/
│       ├── SKILL.md                         # Entry point
│       ├── owasp-top10.md                   # OWASP checklist
│       ├── design-security.md               # Design review checklist
│       ├── crypto-patterns.md               # Crypto vulnerability patterns
│       └── aws-security.md                  # AWS security checklist
│
├── __tests__/
│   ├── security_analysis.test
│   ├── authentication_review.test
│   ├── api_security_review.test
│   └── infrastructure_security.test
│
├── acceptance-criteria.md
└── README.md
```

---

## 4. Agent Design

### 4.1 Security Reviewer Router (Planning Router)

**File:** `agents/security-reviewer-router.md`

**Frontmatter:**
```yaml
---
name: security-reviewer-router
description: Orchestrates security review workflows by determining scope, coordinating specialized reviewers, and generating comprehensive security reports. Use PROACTIVELY when users request security review, vulnerability assessment, or security audit.
model: sonnet
tools: Read, Glob, Grep, Task
permissionMode: plan
color: red
---
```

**Purpose:**
The security-reviewer-router is the intelligent orchestrator for all security review workflows. It determines review scope, coordinates specialized reviewers, aggregates findings, and generates comprehensive reports.

**Workflow:**
```
Step 1: Analyze Request → Determine scope (design, code, crypto, infra)
Step 2: Get Paths → Get target paths from user
Step 3: Present Plan → Show review strategy for confirmation
Step 4: Delegate → Invoke specialized reviewer(s)
Step 5: Aggregate → Combine findings by severity
Step 6: Report → Generate SECURITY-REVIEW-REPORT.md
Step 7: Recommend → Include professional pentest recommendation
```

**Guardrails:**

### INPUT_BLOCKING_CONDITIONS
- **SCOPE_VIOLATION**: Requests to exploit vulnerabilities | requests to test in production
- **HARMFUL_CONTENT**: Malicious payload creation | actual attack execution
- **OUT_OF_SCOPE**: Basic SAST findings | dependency CVEs only (use npm audit)

### RESPONSE_TO_BLOCKED_INPUT
- **ACTION**: Politely refuse | explain security review scope | suggest appropriate tool
- **TONE**: Security-conscious | professional
- **ALTERNATIVES**: Suggest npm audit for dependencies | SAST tools for basic patterns

### OPERATIONAL_CONSTRAINTS
- **ALWAYS**: Get target paths from user | present plan before reviewing | include confidence levels | recommend pentest
- **NEVER**: Exploit vulnerabilities | test in production | guarantee security | replace pentest
- **STOP_AND_ASK**: Scope unclear | paths not specified | large codebase warning

---

### 4.2 Design Security Reviewer

**File:** `agents/design-security-reviewer.md`

**Frontmatter:**
```yaml
---
name: design-security-reviewer
description: Reviews design documents for security-first approach including architecture, API specs, and authentication design. Identifies security gaps before code is written. Use for design document security review.
model: haiku
tools: Read, Glob, Grep
permissionMode: plan
color: blue
---
```

**Responsibilities:**
- Review architecture documents for security patterns
- Assess authentication/authorization design
- Evaluate data protection strategies
- Check API security design
- Report design-level security gaps

---

### 4.3 Code Security Reviewer

**File:** `agents/code-security-reviewer.md`

**Frontmatter:**
```yaml
---
name: code-security-reviewer
description: Identifies business logic flaws and OWASP Top 10 vulnerabilities in source code that automated SAST/DAST tools miss. Focuses on authorization bypasses, race conditions, and context-dependent vulnerabilities.
model: haiku
tools: Read, Glob, Grep
permissionMode: plan
color: orange
---
```

**Responsibilities:**
- Detect business logic vulnerabilities
- Find authorization/authentication flaws
- Identify race conditions (TOCTOU)
- Check for state machine bypasses
- Report with PoC and remediation

---

### 4.4 Crypto Security Reviewer

**File:** `agents/crypto-security-reviewer.md`

**Frontmatter:**
```yaml
---
name: crypto-security-reviewer
description: Reviews cryptographic implementations for security issues including algorithm choices, key management, random number generation, and token security. Use for cryptographic code review.
model: haiku
tools: Read, Glob, Grep
permissionMode: plan
color: purple
---
```

**Responsibilities:**
- Review encryption/decryption implementations
- Check key management practices
- Assess random number generation
- Evaluate JWT/token security
- Verify password hashing

---

### 4.5 Infrastructure Security Reviewer

**File:** `agents/infrastructure-security-reviewer.md`

**Frontmatter:**
```yaml
---
name: infrastructure-security-reviewer
description: Reviews Infrastructure as Code (SAM, CloudFormation, Terraform) for security misconfigurations including IAM policies, network security, and service configurations. Use for IaC security review.
model: haiku
tools: Read, Glob, Grep
permissionMode: plan
color: green
---
```

**Responsibilities:**
- Review IAM policies for least privilege
- Check Lambda configurations
- Assess API Gateway security
- Verify network/security groups
- Report secure configuration alternatives

---

## 5. Commands Design

### 5.1 Unified /security-review Command

**File:** `commands/security-review.md`

**Frontmatter:**
```yaml
---
argument-hint: [review scope]
description: Unified command for comprehensive security review - analyzes design documents and source code for vulnerabilities that automated tools miss
---
```

**Routing Logic:**
```markdown
## Routing Logic

Analyze the user's request and determine review scope:

### 1. Design Review → design-security-reviewer
**Triggers:** design, architecture, HLD, API spec, auth design
**Focus:** Security-first design assessment

### 2. Code Review → code-security-reviewer
**Triggers:** code, source, implementation, business logic
**Focus:** OWASP Top 10, authorization flaws, race conditions

### 3. Crypto Review → crypto-security-reviewer
**Triggers:** crypto, encryption, JWT, tokens, hashing
**Focus:** Cryptographic implementation security

### 4. Infrastructure Review → infrastructure-security-reviewer
**Triggers:** infrastructure, IAM, SAM, CloudFormation, Lambda
**Focus:** IaC security configurations

### 5. Full Review → All reviewers
**Triggers:** full, complete, comprehensive, everything
**Flow:** Design → Code → Crypto → Infrastructure
```

---

## 6. Review Types

### 6.1 Design Security Review

| Input | Output | Focus |
|-------|--------|-------|
| HLD, Architecture docs | Design findings | Security-first approach |
| API specifications | API security gaps | Auth, rate limiting |
| Auth design docs | Auth assessment | MFA, session management |

### 6.2 Code Security Review

| Input | Output | Focus |
|-------|--------|-------|
| Angular/AXIS code | Code findings | XSS, CSRF, client-side |
| Lambda handlers | API findings | Authorization, injection |
| Business logic | Logic findings | Race conditions, bypasses |

### 6.3 Crypto Security Review

| Input | Output | Focus |
|-------|--------|-------|
| Encryption code | Crypto findings | Algorithm, mode choices |
| Key management | Key findings | Storage, derivation |
| Token code | Token findings | JWT security |

### 6.4 Infrastructure Security Review

| Input | Output | Focus |
|-------|--------|-------|
| SAM templates | IAM findings | Permissions |
| CloudFormation | Network findings | Security groups |
| Lambda configs | Config findings | Env vars, VPC |

---

## 7. Data Flow

### 7.1 Single-Scope Review Flow

```
User Request: "Review my Lambda code for security issues"
     │
     ▼
┌─────────────────────────┐
│ security-reviewer-router│
│ 1. Detect scope: code   │
│ 2. Get code path        │
│ 3. Present plan         │
└───────────┬─────────────┘
            │ (after approval)
            ▼
┌─────────────────────────┐
│ code-security-reviewer  │
│ - Read source files     │
│ - Check for OWASP Top 10│
│ - Find business logic   │
│ - Identify auth flaws   │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ SECURITY-REVIEW-REPORT  │
│ - Findings by severity  │
│ - PoC for each finding  │
│ - Remediation guidance  │
│ - Pentest recommendation│
└─────────────────────────┘
```

### 7.2 Full Review Flow

```
User Request: "Comprehensive security review"
     │
     ▼
┌─────────────────────────┐
│ security-reviewer-router│
│ - Get all target paths  │
│ - Plan comprehensive    │
└───────────┬─────────────┘
            │
    ┌───────┴───────┐
    │               │
    ▼               ▼
┌─────────┐   ┌─────────┐
│ Design  │   │ Code    │
│ Review  │   │ Review  │
└────┬────┘   └────┬────┘
     │             │
    ┌┴─────────────┴┐
    │               │
    ▼               ▼
┌─────────┐   ┌─────────┐
│ Crypto  │   │ Infra   │
│ Review  │   │ Review  │
└────┬────┘   └────┬────┘
     │             │
     └──────┬──────┘
            ▼
┌─────────────────────────┐
│ Unified Security Report │
│ - All findings combined │
│ - Severity prioritized  │
│ - Remediation roadmap   │
│ - Pentest recommendation│
└─────────────────────────┘
```

---

## 8. Integration Points

### 8.1 Upstream Dependencies

| Plugin | Provides | Usage |
|--------|----------|-------|
| design-agent | API specs, TDD | Design review input |
| axis-tools | Angular components | Code review input |
| nodejs-pair-programmer | Lambda handlers | Code review input |
| tech-architect | Architecture docs | Design review input |

### 8.2 Downstream Consumers

| Plugin | Consumes | Usage |
|--------|----------|-------|
| code-validator | Security findings | Quality context |
| documents-maintainer | Security report | Documentation |
| Development teams | Remediation roadmap | Fix guidance |

### 8.3 Relationship with Code Validator

| Aspect | Security Reviewer | Code Validator |
|--------|------------------|----------------|
| **Scope** | Design + Code security | Code quality & standards |
| **Focus** | Vulnerabilities, threats | Guidelines, requirements |
| **Depth** | Deep security analysis | Broad quality checks |
| **Overlap** | Security patterns | Security as quality |

---

## 9. Error Handling Strategy

### 9.1 File Access Errors

| Error Type | Response |
|------------|----------|
| Path not found | Report error, stop review |
| Permission denied | Report specific files |
| Unsupported format | Skip with note |

### 9.2 Analysis Errors

| Error Type | Response |
|------------|----------|
| Parse error | Report file, continue |
| Obfuscated code | Note limitation, flag for manual |
| Large file | Partial analysis with warning |

### 9.3 Error Response Format

```markdown
## Review Errors

⚠️ **2 files could not be analyzed:**

1. **PARSE_ERROR:** src/legacy/old-auth.js
   - Reason: Syntax error at line 45
   - Action: Review manually

2. **ACCESS_DENIED:** config/secrets.yaml
   - Reason: Permission denied
   - Action: Check file permissions
```

---

## 10. Testing Strategy

### 10.1 Test Categories

| Category | Test Files | Coverage |
|----------|------------|----------|
| Security Analysis | security_analysis.test | OWASP, business logic |
| Auth Review | authentication_review.test | Auth/authz flaws |
| API Security | api_security_review.test | API vulnerabilities |
| Infrastructure | infrastructure_security.test | IaC security |

### 10.2 Test Scenarios

```
Test Scenarios:
1. Single-scope review (code only)
2. Multi-scope review (design + code)
3. Full comprehensive review
4. Finding detection accuracy
5. Confidence level assignment
6. Remediation quality
7. False positive rate
```

### 10.3 Quality Metrics

| Metric | Target |
|--------|--------|
| Issue detection | 60-80% for in-scope issues |
| False positive rate | <25% |
| Evidence quality | 100% (every finding has PoC) |
| Remediation coverage | 100% |
| Human review reminder | 100% |

---

## 11. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Nov 27, 2025 | AI COE Team | Initial HLD following PLUGIN_DEVELOPMENT_GUIDE.md v2.0. Multi-agent architecture with planning router pattern. Four specialized reviewers (Design, Code, Crypto, Infrastructure). Confidence-based findings (HIGH/MEDIUM/LOW). HITL mandatory. Pentest recommendations. |
| 1.2 | 2025-12-19 | AI COE Team | Version bump for plugin bundle release v1.2.0 |
| 1.3 | 2026-01-09 | AI COE Team | Version bump for release v1.3.0 |
| 1.4 | 2026-01-21 | AI COE Team | Version bump for unified release v1.4.0 |

---

**Document Owner:** AI COE Team

**Document Type:** High-Level Design (HLD)

**Status:** Draft

**Consumer:** security-reviewer plugin implementation
