# Business Requirements Document: Security Reviewer Plugin

**Feature:** Claude Code Plugin for Security Review (Design & Code)

**User Story ID:** US-SR-001

**Status:** In Development

**Document Type:** Business Requirements Document (BRD)

**Version:** 1.2

---

## Executive Summary

This document defines the business requirements for a Claude Code plugin that performs comprehensive security review of both **design documents** and **source code**. The plugin identifies security issues that automated SAST/DAST tools typically miss, focusing on business logic flaws, architectural vulnerabilities, and security-first design assessment.

### ⚠️ IMPORTANT DISCLAIMER: Generative AI Limitations & HITL Requirement

**This plugin is powered by Generative AI (Large Language Model)** and has inherent limitations:

| Limitation                  | Description                                                 | Implication                                        |
| --------------------------- | ----------------------------------------------------------- | -------------------------------------------------- |
| **Hallucination Risk**      | LLMs can generate plausible but incorrect security findings | May report false vulnerabilities or miss real ones |
| **No Exploitation Testing** | Cannot actually exploit or test vulnerabilities             | Cannot confirm exploitability                      |
| **Context Limitations**     | May miss context-dependent security issues                  | Business logic flaws require domain knowledge      |
| **Pattern-Based**           | Relies on known patterns, not novel attack vectors          | May miss zero-day or novel vulnerabilities         |
| **Not Penetration Testing** | Static analysis only, no dynamic testing                    | Cannot replace professional security assessment    |

**Human-In-The-Loop (HITL) is MANDATORY:**
- ❌ NEVER assume findings are complete or accurate without verification
- ✅ ALWAYS have qualified security professional review findings
- ✅ ALWAYS verify vulnerabilities before remediation
- ✅ ALWAYS conduct professional penetration testing for production systems

**This tool is a security review ASSISTANT, NOT a replacement for:**
- Professional security team review
- Penetration testing by certified professionals
- Security compliance audits

### Security Review Model: Design + Code Analysis

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        INPUTS FOR SECURITY REVIEW                            │
│                                                                              │
│  ┌────────────────────────────────┐  ┌────────────────────────────────┐     │
│  │        DESIGN DOCUMENTS        │  │         SOURCE CODE            │     │
│  │                                │  │                                │     │
│  │  • Architecture docs (HLD)     │  │  • Angular components          │     │
│  │  • API specifications          │  │  • Node.js Lambda handlers     │     │
│  │  • Data flow diagrams          │  │  • Authentication logic        │     │
│  │  • Authentication design       │  │  • Authorization code          │     │
│  │  • Authorization model         │  │  • Business logic              │     │
│  │  • Infrastructure design       │  │  • Infrastructure as Code      │     │
│  └────────────────────────────────┘  └────────────────────────────────┘     │
│                                                                              │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        │ Manual Security Analysis
                                        │ (Beyond SAST/DAST Capabilities)
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        SECURITY REVIEW FOCUS                                 │
│                                                                              │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐          │
│  │  Security-First  │  │  Business Logic  │  │   Architectural  │          │
│  │  Design Review   │  │      Flaws       │  │  Vulnerabilities │          │
│  └──────────────────┘  └──────────────────┘  └──────────────────┘          │
│                                                                              │
│  What SAST/DAST tools CANNOT find:                                          │
│  • Authorization logic flaws           • Race conditions                     │
│  • Privilege escalation paths          • State machine bypasses              │
│  • Business rule circumvention         • Insecure design patterns            │
│  • Context-dependent vulnerabilities   • Cryptographic misuse                │
│                                                                              │
└───────────────────────────────────────┬─────────────────────────────────────┘
                                        │
                                        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              OUTPUT                                          │
│                                                                              │
│                    SECURITY-REVIEW-REPORT.md                                 │
│                    • Design security assessment                              │
│                    • Code vulnerability findings                             │
│                    • Confidence levels (not guarantees)                      │
│                    • Remediation recommendations                             │
│                    • Professional pen test recommendations                   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Key Distinction from Other Validators

| Aspect      | Security Reviewer          | Code Validator                     |
| ----------- | -------------------------- | ---------------------------------- |
| **Scope**   | Design + Code security     | Code quality & standards           |
| **Focus**   | Vulnerabilities, threats   | Guidelines, requirements adherence |
| **OWASP**   | Security vulnerabilities   | Coding standards                   |
| **Output**  | Security findings, threats | Quality scores, compliance         |
| **Overlap** | Security patterns in code  | Security as part of quality        |

**Note:** Some overlap exists by design. Security Reviewer goes deeper on security; Code Validator covers broader quality.

---

## Multi-Agent Architecture

The Security Reviewer plugin uses a **multi-agent architecture** with 7 specialized reviewers orchestrated by a central router.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         SECURITY REVIEWER ARCHITECTURE                       │
│                                                                              │
│                    ┌──────────────────────────────┐                         │
│                    │   security-reviewer-router   │                         │
│                    │      (Master Orchestrator)   │                         │
│                    │                              │                         │
│                    │  • Scope detection           │                         │
│                    │  • Target discovery          │                         │
│                    │  • Review planning           │                         │
│                    │  • Finding aggregation       │                         │
│                    │  • Report generation         │                         │
│                    └──────────────┬───────────────┘                         │
│                                   │                                          │
│              ┌────────────────────┼────────────────────┐                    │
│              │                    │                    │                    │
│              ▼                    ▼                    ▼                    │
│  ┌───────────────────┐ ┌───────────────────┐ ┌───────────────────┐         │
│  │ code-security-    │ │ design-security-  │ │ crypto-security-  │         │
│  │ reviewer          │ │ reviewer          │ │ reviewer          │         │
│  │                   │ │                   │ │                   │         │
│  │ • OWASP Top 10    │ │ • Auth design     │ │ • Weak algorithms │         │
│  │ • Business logic  │ │ • Authz design    │ │ • Key management  │         │
│  │ • 21 analysis     │ │ • Data protection │ │ • JWT security    │         │
│  │   phases          │ │ • API security    │ │ • Password hashing│         │
│  └───────────────────┘ └───────────────────┘ └───────────────────┘         │
│              │                    │                    │                    │
│              ▼                    ▼                    ▼                    │
│  ┌───────────────────┐ ┌───────────────────┐ ┌───────────────────┐         │
│  │ infrastructure-   │ │ dependency-       │ │ data-privacy-     │         │
│  │ security-reviewer │ │ security-reviewer │ │ reviewer          │         │
│  │                   │ │                   │ │                   │         │
│  │ • IAM policies    │ │ • CVE detection   │ │ • PII/PHI         │         │
│  │ • Lambda config   │ │ • npm audit       │ │ • GDPR/CCPA       │         │
│  │ • API Gateway     │ │ • CVSS scoring    │ │ • Timing attacks  │         │
│  │ • Security groups │ │ • Remediation     │ │ • Logging hygiene │         │
│  └───────────────────┘ └───────────────────┘ └───────────────────┘         │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Specialized Agents

| Agent                                | Role                          | Key Capabilities                                                                           |
| ------------------------------------ | ----------------------------- | ------------------------------------------------------------------------------------------ |
| **security-reviewer-router**         | Master orchestrator           | Scope detection, target discovery, review planning, finding aggregation, report generation |
| **code-security-reviewer**           | Business logic & OWASP expert | 21 security analysis phases, authorization bypasses, race conditions, enterprise standards |
| **design-security-reviewer**         | Security-first architecture   | Auth/authz design validation, data protection review, API security design (60+ checks)     |
| **crypto-security-reviewer**         | Cryptographic implementation  | Weak algorithms, hardcoded secrets, JWT vulnerabilities, password hashing                  |
| **infrastructure-security-reviewer** | AWS/IaC security              | IAM policies, Lambda config, API Gateway, security groups, S3 buckets (8-step review)      |
| **dependency-security-reviewer**     | CVE detection                 | npm audit, CVSS scoring, prioritized remediation, dependency chain analysis                |
| **data-privacy-reviewer**            | PII/PHI & compliance          | Data masking, logging hygiene, timing attacks, GDPR/CCPA/PCI-DSS/HIPAA (7 phases)          |

### Security Checklists (Skills)

The plugin includes 14 security checklists in `skills/security-checklists/`:

| Checklist                    | Purpose                                       | Used By                                          |
| ---------------------------- | --------------------------------------------- | ------------------------------------------------ |
| `owasp-top10.md`             | OWASP Top 10 2021 vulnerabilities             | code-security-reviewer                           |
| `design-security.md`         | Security-first design review                  | design-security-reviewer                         |
| `crypto-patterns.md`         | Cryptographic implementation patterns         | crypto-security-reviewer                         |
| `aws-security.md`            | AWS/IaC security best practices               | infrastructure-security-reviewer                 |
| `beyond-sast-dast.md`        | Vulnerabilities SAST/DAST miss                | code-security-reviewer                           |
| `business-logic-patterns.md` | Authorization, race conditions, state machine | code-security-reviewer                           |
| `data-privacy-patterns.md`   | PII/PHI, data masking, compliance             | data-privacy-reviewer                            |
| `dependency-patterns.md`     | CVE detection, remediation priorities         | dependency-security-reviewer                     |
| `ecommerce-patterns.md`      | E-commerce security (pricing, inventory)      | code-security-reviewer                           |
| `federation-patterns.md`     | SSO/SAML/OIDC patterns                        | design-security-reviewer                         |
| `logging-standards.md`       | Logging hygiene, audit trails                 | data-privacy-reviewer, code-security-reviewer    |
| `mobile-security.md`         | Mobile app security patterns                  | code-security-reviewer                           |
| `web-services-patterns.md`   | REST/GraphQL API security                     | design-security-reviewer, code-security-reviewer |

---

## Problem Statement

**Current Challenge:**
1. Automated SAST/DAST tools miss business logic flaws and architectural vulnerabilities
2. Security is often an afterthought rather than built into design
3. Manual security reviews are expensive and time-consuming
4. Authorization logic flaws require understanding business context
5. Race conditions and state machine bypasses need manual analysis

**Business Need:** A tool to assist with security review of both design documents and code, identifying issues that automated tools miss, while clearly stating limitations and recommending professional penetration testing.

**IMPORTANT:** This is **assisted security review**, not automated security guarantee. Professional penetration testing is still recommended for production systems.

---

## Stakeholders

| Stakeholder       | Role         | Interest                                   |
| ----------------- | ------------ | ------------------------------------------ |
| **Security Team** | Primary User | Identify vulnerabilities before deployment |
| **Architects**    | Primary User | Validate security-first design             |
| **Developers**    | Consumer     | Fix identified security issues             |
| **Tech Leads**    | Consumer     | Understand security posture                |
| **Compliance**    | Consumer     | Audit trail, compliance gaps               |
| **Management**    | Consumer     | Risk assessment                            |

---

## Assumptions

1. **Assisted Review:** This tool assists human security reviewers, does not replace them
2. **Static Analysis:** Code analysis without execution
3. **Design Documents Available:** Architecture docs, specs available for review
4. **Manual Focus:** Focuses on what automated tools miss
5. **SAST/DAST Complement:** Assumes standard SAST/DAST tools are used separately
6. **Approved Libraries:** Assumes approved/scanned dependency libraries are in use
7. **Professional Testing:** Recommends penetration testing for production systems
8. **Corporate Standards Compliance:** Applications must comply with corporate security standards including:
   - Global Records and Information Management Policy
   - Cryptography and Key Management Standard
   - Logging and Monitoring Standard
   - Vulnerability Management Standard
   - Application Security and Control Standard
   - IT Security Incident Management Standard
9. **SSA Requirements:** Applications require Software Security Assessment (SSA) per GEAR risk rating
10. **ISO Standards:** Corporate functions must follow centralized ISO standards for pre-production and post-production application security monitoring

---

## Business Objectives

### Primary Objective

**Assist security teams in identifying potential security issues in design documents and source code that automated SAST/DAST tools typically miss, providing findings with confidence levels for human review and verification.**

**This tool:**
- Assists with security review (does not guarantee security)
- Identifies potential issues (requires human verification)
- Recommends professional penetration testing for production

### Success Metrics

| Metric                   | Target | Measurement                       | Notes                                      |
| ------------------------ | ------ | --------------------------------- | ------------------------------------------ |
| **Issue Detection**      | 60-80% | Known issues found                | For issues in scope (business logic, auth) |
| **False Positive Rate**  | <25%   | Issues reported incorrectly       | Conservative reporting                     |
| **Confidence Accuracy**  | >80%   | HIGH confidence issues verified   | HIGH = likely real issue                   |
| **Human Review**         | 100%   | All findings reviewed             | Non-negotiable                             |
| **Remediation Guidance** | 100%   | Findings have fix recommendations | Actionable output                          |

**Explicitly NOT guaranteed:**
- Complete vulnerability coverage - Manual review has limits
- Zero false positives - Static analysis cannot verify exploitability
- Runtime security - Cannot test actual behavior
- All vulnerability types - Focuses on business logic, auth, design

---

## Business Requirements

### BR1: Security-First Design Review

**Requirement:** Review design documents to assess if security is built-in from the start (security-first approach).

**Design Documents to Review:**

| Document                  | Security Assessment                      |
| ------------------------- | ---------------------------------------- |
| **Architecture (HLD)**    | Defense in depth, security boundaries    |
| **API Specifications**    | Authentication, authorization design     |
| **Data Flow Diagrams**    | Sensitive data handling, encryption      |
| **Infrastructure Design** | Network security, IAM policies           |
| **Authentication Design** | Auth method strength, session management |
| **Authorization Model**   | RBAC/ABAC design, privilege separation   |

**Security-First Checklist:**
```markdown
## Design Security Assessment

### Authentication Design
- [ ] Multi-factor authentication considered?
- [ ] Session management defined?
- [ ] Token expiration/refresh strategy?
- [ ] Account lockout policy?

### Authorization Design
- [ ] Principle of least privilege applied?
- [ ] Role separation defined?
- [ ] Resource ownership model clear?
- [ ] Admin privilege escalation path?

### Data Protection
- [ ] Sensitive data identified?
- [ ] Encryption at rest defined?
- [ ] Encryption in transit defined?
- [ ] Data classification scheme?

### API Security
- [ ] Rate limiting designed?
- [ ] Input validation strategy?
- [ ] Error handling (no info leak)?
- [ ] CORS policy defined?
```

**Business Value:** Identifies security gaps before code is written.

**Priority:** P0 (Critical)

---

### BR2: Business Logic Vulnerability Detection

**Requirement:** Identify business logic flaws that automated tools cannot detect using 21 comprehensive security analysis phases.

**Focus Areas:**

| Vulnerability Type                  | Description                     | SAST/DAST Detection |
| ----------------------------------- | ------------------------------- | ------------------- |
| **Horizontal Privilege Escalation** | User A accesses User B's data   | ❌ Cannot detect    |
| **Vertical Privilege Escalation**   | User becomes admin              | ❌ Cannot detect    |
| **Authorization Bypass**            | Skipping access checks          | ❌ Cannot detect    |
| **Business Rule Circumvention**     | Manipulating business logic     | ❌ Cannot detect    |
| **Race Conditions (TOCTOU)**        | Time-of-check vs time-of-use    | ❌ Cannot detect    |
| **State Machine Bypass**            | Skipping workflow steps         | ❌ Cannot detect    |
| **Price/Discount Manipulation**     | Altering financial calculations | ❌ Cannot detect    |

**21 Security Analysis Phases (code-security-reviewer):**

| Phase | Category                           | Analysis Focus                                                                |
| ----- | ---------------------------------- | ----------------------------------------------------------------------------- |
| 1     | **A01: Broken Access Control**     | Horizontal/vertical privilege escalation, IDOR, missing function-level access |
| 2     | **A02: Cryptographic Failures**    | Weak hashing (MD5/SHA1), hardcoded secrets, insecure random                   |
| 3     | **A03: Injection**                 | SQL injection, command injection, XSS, NoSQL injection                        |
| 4     | **A04: Insecure Design**           | Race conditions (TOCTOU), state machine bypass, missing rate limiting         |
| 5     | **A05: Security Misconfiguration** | Debug mode enabled, CORS wildcards, verbose error messages                    |
| 6     | **A07: Authentication Failures**   | JWT algorithm confusion, jwt.decode() misuse, insecure session handling       |
| 7     | **A08: Data Integrity Failures**   | Insecure deserialization, prototype pollution                                 |
| 8     | **A09: Logging Failures**          | Missing security logging, sensitive data in logs                              |
| 9     | **A10: SSRF**                      | URL from user input, missing URL validation                                   |
| 10    | **Enterprise Session Management**  | Session duration ≤60 min, idle timeout, remote re-authentication              |
| 11    | **Account Lockout Validation**     | Max 6 failed attempts, ≥30 min lockout duration                               |
| 12    | **Password Policy Enforcement**    | 8+ chars human, 24+ chars service accounts, password history, rotation        |
| 13    | **Debug/Test Code Detection**      | console.log statements, DEBUG=true flags, test credentials in code            |
| 14    | **Re-authentication Requirements** | Password change validation, sensitive operation verification                  |
| 15    | **Default Credentials Detection**  | Default usernames (admin, root), default passwords, test secrets              |
| 16    | **Client-Side Exposure**           | Internal URLs in client, stack traces exposed, business logic leaked          |
| 17    | **Rate Limiting**                  | Login endpoint rate limiting, data access request throttling                  |
| 18    | **Session Security**               | Session fixation, CSRF protection, session cleanup on logout                  |
| 19    | **Malicious Code Detection**       | Dangerous function usage (eval, exec), hidden endpoints, obfuscated code      |
| 20    | **Non-Production Data**            | PII in test fixtures, production data in seed files                           |
| 21    | **Enterprise Controls Summary**    | Aggregate validation of all enterprise security standards                     |

**Enterprise Security Standards Enforced:**

| Standard                     | Requirement                       | Threshold          |
| ---------------------------- | --------------------------------- | ------------------ |
| **Session Timeout**          | Maximum session duration          | ≤60 minutes        |
| **Account Lockout**          | Failed login attempts before lock | Maximum 6 attempts |
| **Lockout Duration**         | Minimum lockout period            | ≥30 minutes        |
| **Human Password**           | Minimum password length           | 8+ characters      |
| **Service Account Password** | Non-human account password        | 24+ characters     |
| **Debug Code**               | console.log, DEBUG flags          | Must be removed    |
| **Test Credentials**         | Hardcoded test accounts           | Must be removed    |

**Example Finding:**
```markdown
**FINDING-001: Horizontal Privilege Escalation**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Location:** src/handlers/user-profile.handler.ts:45-67
- **Issue:** getUserProfile() validates authentication but not authorization
- **Code:**
  ```typescript
  // Only checks if user is logged in, not if they own this profile
  const profile = await db.get(req.params.userId);
  return profile;
  ```
- **Impact:** Any authenticated user can access any user's profile
- **OWASP:** A01:2021 - Broken Access Control
- **CWE:** CWE-639 (Authorization Bypass Through User-Controlled Key)
- **Remediation:** Add ownership check: `if (req.userId !== req.params.userId) throw Forbidden`
- **Why Automated Tools Miss This:** SAST sees authentication check exists; cannot understand business requirement that users should only access own data
```

**Limitations:**
- Requires understanding business context
- Complex authorization logic may be misinterpreted
- Cannot verify exploitability without execution

**Business Value:** Catches authorization flaws before production with enterprise standards enforcement.

**Priority:** P0 (Critical)

---

### BR3: OWASP Top 10 Assessment (Manual Focus)

**Requirement:** Assess code against OWASP Top 10, focusing on issues requiring manual review.

**Manual Review Focus:**

| OWASP Category                     | Automated Tool Coverage | Manual Review Focus                             |
| ---------------------------------- | ----------------------- | ----------------------------------------------- |
| **A01: Broken Access Control**     | Basic patterns          | Authorization logic, IDOR, privilege escalation |
| **A02: Cryptographic Failures**    | Weak algorithms         | Key management, proper usage context            |
| **A03: Injection**                 | SQL/XSS patterns        | Context-specific, second-order injection        |
| **A04: Insecure Design**           | ❌ None                 | Architecture flaws, threat modeling gaps        |
| **A05: Security Misconfiguration** | Basic checks            | Context-dependent configs                       |
| **A06: Vulnerable Components**     | ❌ Separate tools       | How components are used (not just CVE)          |
| **A07: Auth Failures**             | Basic patterns          | Session logic, credential management            |
| **A08: Integrity Failures**        | Basic patterns          | Update mechanisms, CI/CD security               |
| **A09: Logging Failures**          | ❌ Limited              | What's logged, sensitive data in logs           |
| **A10: SSRF**                      | Basic patterns          | Indirect SSRF, complex scenarios                |

**Assessment Output:**
```markdown
## OWASP Top 10 Assessment

### A01: Broken Access Control
**Risk Level:** HIGH
**Confidence:** HIGH

**Findings:**
- 3 endpoints lack authorization checks (FINDING-001, 002, 003)
- Admin functions accessible via direct URL

### A04: Insecure Design
**Risk Level:** MEDIUM
**Confidence:** MEDIUM

**Findings:**
- No rate limiting on password reset
- Session tokens don't expire on password change
```

**Business Value:** Structured security assessment against industry standard.

**Priority:** P0 (Critical)

---

### BR4: Cryptographic Implementation Review

**Requirement:** Review cryptographic implementations for misuse and weaknesses per the **Cryptography and Key Management Standard**.

**Corporate Standard Requirements:**
- All applications must adhere to the Cryptography and Key Management Standard
- Cryptography and key management tools must be identified and maintained
- Cryptography and key management procedures, including escalation points, must be maintained throughout the lifecycle
- Encryption levels must be appropriate to the classification of the data aligned with the method of storage or transmission

**Data in Transit Requirements:**
| Requirement                | Standard                                                                      |
| -------------------------- | ----------------------------------------------------------------------------- |
| **External Transmissions** | Must be encrypted using TLS v1.2-1.3 and approved algorithms                  |
| **Algorithm Currency**     | Must use latest, most secure version available                                |
| **Digital Signatures**     | Required where appropriate for non-repudiation of authenticity                |
| **PCI DSS Systems**        | Must meet PCI requirements for data in transit                                |
| **Internal Network**       | Encryption recommended when technologically feasible                          |
| **Cloud Providers**        | Must allow configuration of data in transit encryption per industry standards |
| **Client Access**          | Encryption required on any client accessing company information systems       |

**Data at Rest Requirements:**
| Classification          | Encryption Requirement                                                     |
| ----------------------- | -------------------------------------------------------------------------- |
| **Highly Confidential** | Protected at rest using encryption at physical layer minimum               |
| **Confidential**        | Protected at rest using encryption at physical layer minimum               |
| **Internal**            | Protected at rest using encryption at physical layer minimum               |
| **Database Servers**    | TDE or field-level encryption if storage encryption not viable             |
| **PCI DSS Systems**     | Must meet PCI requirements for data at rest                                |
| **Non-Production**      | Data must be masked where feasible; use dummy data if masking not possible |

**Key Management Requirements:**
| Area                     | Standard                                                                    |
| ------------------------ | --------------------------------------------------------------------------- |
| **Digital Certificates** | Must be created using approved certificate authorities                      |
| **Non-Repudiation Keys** | Must not be held in key escrow; use HSM tools                               |
| **Binary Signing**       | Home-grown compiled binaries must be signed using certificates per standard |
| **Jurisdictional Keys**  | May need to be kept within specific jurisdictions where required            |

**Review Areas:**

| Area                       | Issues to Identify                                            |
| -------------------------- | ------------------------------------------------------------- |
| **Algorithm Choice**       | MD5/SHA1 for security, ECB mode, weak ciphers, TLS < 1.2      |
| **Key Management**         | Hardcoded keys, weak derivation, no rotation, improper escrow |
| **Random Numbers**         | Math.random() for security, predictable seeds                 |
| **Token Security**         | JWT algorithm confusion, weak secrets                         |
| **Hashing**                | Unsalted passwords, fast hashes for passwords                 |
| **Encryption**             | Static IVs, missing authentication (MAC), non-compliant TLS   |
| **Certificate Management** | Unapproved CAs, improper digital signatures                   |

**Example Finding:**
```markdown
**FINDING-005: Weak Password Hashing**
**Confidence:** HIGH

- **Location:** src/services/auth.service.ts:89
- **Issue:** Passwords hashed with MD5, no salt
- **Code:** `const hash = crypto.createHash('md5').update(password).digest('hex')`
- **Impact:** Passwords vulnerable to rainbow table attacks
- **Compliance:** Violates Cryptography and Key Management Standard
- **Remediation:** Use bcrypt or Argon2 with proper work factor
```

**Limitations:**
- Cannot verify key entropy without access to key generation
- Cannot assess all cryptographic contexts

**Business Value:** Prevents cryptographic implementation errors and ensures compliance with corporate standards.

**Priority:** P1 (High)

---

### BR5: Data Security and Privacy Review

**Requirement:** Identify sensitive data exposure and privacy issues per the **Global Records and Information Management Policy** and **Logging and Monitoring Standard**.

**Data Retention and Disposal Requirements:**
- System must be designed to allow data disposal on an ongoing basis in compliance with Global Records and Information Management policy
- Company records should be disposed of once their retention period has expired (unless subject to document preservation notice)
- Records with appreciable value beyond retention period may require retention schedule revision
- Disposal may be required by applicable law or regulation depending on jurisdiction
- Managers must ensure no company records are lost due to employee departure
- Employees must save company records to appropriate shared location before separation

**Logging and Monitoring Standard Requirements:**

| Log Type              | Destination         | Requirements                                                             |
| --------------------- | ------------------- | ------------------------------------------------------------------------ |
| **Security Logs**     | SIEM System         | Must be received within security information and event management system |
| **Non-Security Logs** | Centralized Logging | Must be outside SIEM system                                              |
| **All Logs**          | Protected Storage   | Must be protected against tampering and unauthorized access              |

**Log Privacy Requirements:**
- Event logs must NOT expose personal information
- Must adhere to local policy laws and regulations
- Filtering and/or data field obfuscation must be implemented at log source

**Required Logging Events:**
| Event Category         | Specific Events                                                                                   |
| ---------------------- | ------------------------------------------------------------------------------------------------- |
| **Authentication**     | Success/failed authentications, default account auth, insecure/cleartext auth, privileged auth    |
| **System**             | Startup/shutdown/restart of systems and processes                                                 |
| **Account Management** | Creation, deletion, locks, modification                                                           |
| **Access Control**     | Alteration of access rights (grant, modify, delete) including user groups                         |
| **Network**            | Initiation/acceptance of connections, session start/end, firewall/proxy traffic (allowed/blocked) |
| **Application**        | Abort/failures/abnormal ending, input validation failures, session management failures            |
| **Security**           | IDS/IPS events, VPN connections/failures, DHCP/DNS events                                         |

**Log Format Requirements:**
| Element         | Requirement                                                                   |
| --------------- | ----------------------------------------------------------------------------- |
| **Format**      | JSON or XML (developer friendly)                                              |
| **Timestamp**   | UTC or with TZD, milliseconds, ISO 8601 format (YYYY-MM-DDThh:mm:ss[.mmm]TZD) |
| **Time Sync**   | Must use centralized NTP server                                               |
| **Position**    | Timestamp at start of event                                                   |
| **Action**      | What action was taken (authorize, create, read, update, delete, accept, deny) |
| **Source**      | User name, IP address, computer name, MAC address                             |
| **Destination** | File names, databases, computer names, IP address, MAC address                |
| **Description** | Summary of what transpired                                                    |

**Review Areas (7 Security Analysis Phases - data-privacy-reviewer):**

| Phase | Area                        | Issues to Identify                                                                                                                    |
| ----- | --------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| 1     | **PII/PHI Detection**       | SSN patterns (\d{3}-\d{2}-\d{4}), credit card patterns, email/phone in logs, health data (diagnosis, prescription, patient, medical)  |
| 2     | **Data Masking Validation** | Unmasked SSN in responses, unmasked card numbers (should show only last 4), full PII in error messages                                |
| 3     | **Logging Hygiene**         | Credentials in logs (passwords, tokens, API keys), session tokens logged, PII in log messages, request body logging without filtering |
| 4     | **Timing Attacks**          | User enumeration via response timing, password comparison timing leaks, missing constant-time comparison                              |
| 5     | **Data Retention**          | No data expiration policies, soft delete with PII retained, backup retention policies                                                 |
| 6     | **Error Messages**          | Stack traces exposed, internal details in responses                                                                                   |
| 7     | **Data Classification**     | Improper handling based on classification level                                                                                       |

**Compliance Framework Mapping (Specific Article References):**

| Framework   | Requirement            | Reference     | Violation Indicator                   |
| ----------- | ---------------------- | ------------- | ------------------------------------- |
| **GDPR**    | Data Minimization      | Art. 5(1)(c)  | Collecting more PII than necessary    |
| **GDPR**    | Right to Erasure       | Art. 17       | No data deletion mechanism            |
| **GDPR**    | Security of Processing | Art. 32       | Unencrypted PII, weak access controls |
| **CCPA**    | Right to Delete        | § 1798.105    | Cannot honor deletion requests        |
| **CCPA**    | Right to Know          | § 1798.100    | Cannot identify what PII is collected |
| **CCPA**    | Opt-Out of Sale        | § 1798.120    | No opt-out mechanism for data sharing |
| **PCI-DSS** | Mask PAN Display       | Req. 3.3      | Full card number displayed            |
| **PCI-DSS** | Encrypt Stored Data    | Req. 3.4      | Unencrypted card data at rest         |
| **PCI-DSS** | Encrypt Transmission   | Req. 4.1      | Card data over non-TLS connection     |
| **HIPAA**   | Access Controls        | 164.312(a)(1) | Unauthorized PHI access possible      |
| **HIPAA**   | Audit Controls         | 164.312(b)    | No audit trail for PHI access         |
| **HIPAA**   | Integrity Controls     | 164.312(c)(1) | PHI modification without logging      |
| **SOC2**    | Security Principle     | CC6.1         | Inadequate access restrictions        |

**CWE References:**
- CWE-359: Exposure of Private Personal Information to an Unauthorized Actor
- CWE-311: Missing Encryption of Sensitive Data
- CWE-200: Exposure of Sensitive Information to an Unauthorized Actor
- CWE-532: Insertion of Sensitive Information into Log File
- CWE-208: Observable Timing Discrepancy
- CWE-613: Insufficient Session Expiration

**Example Finding:**
```markdown
**FINDING-007: Sensitive Data in Logs**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Location:** src/handlers/auth.handler.ts:34
- **Issue:** Password logged on failed login attempt
- **Code:** `logger.error(\`Login failed for ${email} with password ${password}\`)`
- **Impact:** Credentials exposed in log files
- **CWE:** CWE-532 (Insertion of Sensitive Information into Log File)
- **Compliance Violations:**
  - Logging and Monitoring Standard (log privacy requirements)
  - GDPR Art. 32 (security of processing)
  - PCI-DSS Req. 3.2 (do not store sensitive authentication data)
- **Remediation:** Never log credentials; implement data field obfuscation at log source
```

**Business Value:** Prevents data breaches and ensures compliance with GDPR, CCPA, PCI-DSS, HIPAA, and corporate data handling standards.

**Priority:** P0 (Critical)

---

### BR6: Infrastructure Security Review

**Requirement:** Review Infrastructure as Code (IaC) for security issues.

**Review Areas:**

| IaC Type               | Security Issues                            |
| ---------------------- | ------------------------------------------ |
| **SAM/CloudFormation** | Overly permissive IAM, public resources    |
| **CDK**                | Insecure defaults, missing encryption      |
| **Terraform**          | Open security groups, public S3            |
| **Lambda Config**      | Environment secrets, excessive permissions |
| **API Gateway**        | Missing auth, CORS misconfiguration        |

**Example Finding:**
```markdown
**FINDING-010: Overly Permissive IAM Policy**
**Confidence:** HIGH

- **Location:** infrastructure/sam/template.yaml:156
- **Issue:** Lambda has `s3:*` permission on all resources
- **Code:**
  ```yaml
  Policies:
    - Statement:
        - Effect: Allow
          Action: s3:*
          Resource: '*'
  ```
- **Impact:** Compromised Lambda can access/delete any S3 bucket
- **Remediation:** Apply least privilege - specific bucket, specific actions
```

**Business Value:** Prevents infrastructure-level vulnerabilities.

**Priority:** P1 (High)

---

### BR7: Confidence Level and Evidence-Based Reporting

**Requirement:** Every finding must include confidence level and comprehensive evidence package.

**Confidence Levels:**

| Level      | Meaning                               | Criteria                                                               |
| ---------- | ------------------------------------- | ---------------------------------------------------------------------- |
| **HIGH**   | Likely real vulnerability             | Clear code evidence, known vulnerability pattern, no mitigations found |
| **MEDIUM** | Probable issue, needs verification    | Pattern detected, context unclear, partial mitigations may exist       |
| **LOW**    | Possible issue, may be false positive | Unusual pattern, mitigating factors likely present                     |

**Severity Levels:**

| Level        | Meaning                     | Examples                                                |
| ------------ | --------------------------- | ------------------------------------------------------- |
| **CRITICAL** | Immediate exploitation risk | RCE, auth bypass, hardcoded secrets, unsalted passwords |
| **HIGH**     | Significant security impact | Privilege escalation, data exposure, weak crypto        |
| **MEDIUM**   | Moderate security impact    | Missing rate limiting, verbose errors                   |
| **LOW**      | Minor security concern      | Missing security headers, minor info disclosure         |

**Evidence Package Requirements (11 Points):**

Every finding MUST include the complete evidence package:

| #   | Field                        | Description                                         | Required |
| --- | ---------------------------- | --------------------------------------------------- | -------- |
| 1   | **Location**                 | `file:line_numbers` - exact location                | Yes      |
| 2   | **Code Snippet**             | Exact vulnerable code from the file                 | Yes      |
| 3   | **Severity**                 | CRITICAL / HIGH / MEDIUM / LOW                      | Yes      |
| 4   | **Confidence**               | HIGH / MEDIUM / LOW with detailed justification     | Yes      |
| 5   | **Category**                 | OWASP category (A01-A10) + CWE reference            | Yes      |
| 6   | **Context Analysis**         | Explanation of why this is a vulnerability          | Yes      |
| 7   | **Mitigations Checked**      | Checklist of potential mitigations and their status | Yes      |
| 8   | **Proof of Concept**         | Safe exploitation demonstration                     | Yes      |
| 9   | **Remediation Code**         | Secure code fix (not just description)              | Yes      |
| 10  | **Why SAST/DAST Misses**     | Explanation of detection gap                        | Yes      |
| 11  | **Human Verification Steps** | Steps to validate the finding                       | Yes      |

**Finding Format:**
```markdown
**FINDING-{ID}: {Title}**
**Severity:** CRITICAL | HIGH | MEDIUM | LOW
**Confidence:** HIGH | MEDIUM | LOW

### Location
`src/handlers/user-profile.handler.ts:45-67`

### Vulnerable Code
```typescript
// Only checks if user is logged in, not if they own this profile
const profile = await db.get(req.params.userId);
return profile;
```

### Category
- **OWASP:** A01:2021 - Broken Access Control
- **CWE:** CWE-639 (Authorization Bypass Through User-Controlled Key)

### Context Analysis
The getUserProfile() function validates authentication but not authorization.
Any authenticated user can access any other user's profile by manipulating the userId parameter.

### Mitigations Checked
- [ ] Ownership validation in handler - NOT FOUND
- [ ] Authorization middleware - NOT APPLIED to this route
- [ ] Database-level row security - NOT CONFIGURED

### Proof of Concept
```bash
# Attacker (user_id=123) accessing victim's profile (user_id=456)
curl -H "Authorization: Bearer <attacker_token>" \
     https://api.example.com/users/456/profile
# Returns victim's profile data
```

### Remediation Code
```typescript
// ADD ownership check before returning profile
const profile = await db.get(req.params.userId);
if (profile.ownerId !== req.userId) {
  throw new ForbiddenError('Access denied');
}
return profile;
```

### Why SAST/DAST Misses This
SAST sees authentication check exists but cannot understand business requirement
that users should only access their own data. DAST cannot distinguish between
legitimate and unauthorized access without business context.

### Human Verification Steps
1. Authenticate as User A
2. Attempt to access User B's profile via API
3. Verify if profile data is returned
4. Check authorization logs for denial events

### Confidence Justification
HIGH - Clear code evidence shows no ownership validation. No mitigating controls
found in middleware or database layer. Pattern matches known IDOR vulnerability.
```

**Business Value:** Prioritized, actionable findings with complete evidence for human review.

**Priority:** P0 (Critical)

---

### BR8: File Type Filtering (Security-Relevant Focus)

**Requirement:** Focus analysis on security-relevant files, exclude non-security files.

**Files to INCLUDE (Security-Relevant):**

| File Type                 | Extension                  | Security Relevance            |
| ------------------------- | -------------------------- | ----------------------------- |
| **TypeScript/JavaScript** | .ts, .js                   | Business logic, auth code     |
| **Handlers**              | .handler.ts                | API endpoints, input handling |
| **Services**              | .service.ts                | Business logic                |
| **Guards/Middleware**     | .guard.ts, .interceptor.ts | Auth/authz logic              |
| **Infrastructure**        | .yaml, .yml (SAM/CDK)      | IAM, network config           |
| **Configuration**         | .json (security configs)   | Security settings             |

**Files to EXCLUDE (Not Security-Relevant):**

| File Type         | Extension          | Reason                          |
| ----------------- | ------------------ | ------------------------------- |
| **Stylesheets**   | .css, .scss, .less | No security logic               |
| **Images**        | .png, .jpg, .svg   | No code                         |
| **Fonts**         | .woff, .ttf        | No code                         |
| **Test Files**    | .spec.ts, .test.ts | Not production code             |
| **Documentation** | .md                | No executable code              |
| **Lock Files**    | package-lock.json  | Handled by npm audit            |
| **Build Output**  | dist/, build/      | Generated files                 |
| **Node Modules**  | node_modules/      | Third-party (separate scanning) |

**Business Value:** Efficient review focused on security-relevant code.

**Priority:** P1 (High)

---

### BR9: Remediation Roadmap and Prioritization

**Requirement:** Provide prioritized remediation roadmap aligned with the **Vulnerability Management Standard**.

**Vulnerability Management Standard - Risk Priority Ratings:**

Vulnerabilities must be remediated based on the following severity rating levels:

| Risk Priority | Remediation Timeline | Criteria                           |
| ------------- | -------------------- | ---------------------------------- |
| **RP1**       | 24 hours to 7 days   | Critical, exploitable, high impact |
| **RP2**       | 14 days              | High severity                      |
| **RP3**       | 30 days              | Elevated risk                      |
| **RP4**       | 60 days              | Moderate risk                      |
| **RP5**       | 90 days              | Lower risk                         |
| **RP6**       | 180 days             | Low risk                           |
| **RP7**       | 360 days             | Minimal risk                       |

**Risk Priority Calculation Factors:**
| Factor Category           | Considerations                                                                |
| ------------------------- | ----------------------------------------------------------------------------- |
| **Vulnerability Details** | Ease of exploration, attack vector exposure, exploit availability             |
| **Asset Details**         | Network location, application hosted, weighted impact                         |
| **Threat Intelligence**   | Threat actor capabilities, observed exploitation activity, CISA-KEV inclusion |

**Prioritization Framework (Aligned with Corporate Standard):**

| Severity             | Criteria                                  | Remediation Timeline |
| -------------------- | ----------------------------------------- | -------------------- |
| **CRITICAL (RP1)**   | Exploitable, high impact, public exposure | 24 hours to 7 days   |
| **HIGH (RP2)**       | Exploitable, significant impact           | 14 days              |
| **MEDIUM (RP3-RP4)** | Potential impact, harder to exploit       | 30-60 days           |
| **LOW (RP5-RP7)**    | Minor impact, defense in depth            | 90-360 days          |

**Remediation Prioritization Order:**
Per corporate standard, prioritize based on:
1. Externally facing infrastructure and applications
2. Infrastructure with third-party access (per systems of record)
3. End user devices

**Remediation Roadmap Output:**
```markdown
## Remediation Roadmap

### Risk Priority 1 (24 hours - 7 days)
| ID          | Finding                         | Risk Priority | Asset Type      | Owner     |
| ----------- | ------------------------------- | ------------- | --------------- | --------- |
| FINDING-001 | Horizontal Privilege Escalation | RP1           | External-facing | Auth Team |
| FINDING-003 | Hardcoded API Key               | RP1           | External-facing | DevOps    |

### Risk Priority 2 (14 days)
| ID          | Finding               | Risk Priority | Asset Type | Owner     |
| ----------- | --------------------- | ------------- | ---------- | --------- |
| FINDING-005 | Weak Password Hashing | RP2           | Internal   | Auth Team |

### Risk Priority 3-4 (30-60 days)
...
```

**Business Value:** Clear action plan aligned with corporate vulnerability management timelines.

**Priority:** P1 (High)

---

### BR10: Professional Penetration Testing Recommendation

**Requirement:** Clearly recommend professional penetration testing for production systems.

**Recommendation Output:**
```markdown
## Penetration Testing Recommendation

**IMPORTANT:** This security review is **assisted analysis**, not a comprehensive security audit.

### Limitations of This Review
- Static analysis only - cannot verify runtime behavior
- Cannot test all attack vectors
- Cannot guarantee completeness
- Business logic understanding may be incomplete

### Recommended Professional Testing
For production systems, we recommend:

1. **External Penetration Test**
   - Focus: Internet-facing applications
   - Frequency: Annually or after major changes

2. **Internal Penetration Test**
   - Focus: Internal network, privilege escalation
   - Frequency: Annually

3. **Web Application Test**
   - Focus: OWASP Top 10, business logic
   - Frequency: Before major releases

### Testing Vendors
- Engage certified pentest vendors (CREST, OSCP certified)
- Request both automated and manual testing
- Include business logic testing in scope
```

**Business Value:** Sets realistic expectations, ensures proper security validation.

**Priority:** P0 (Critical)

---

### BR11: Authentication and Authorization Review

**Requirement:** Review authentication and authorization implementations per corporate security standards.

**Session Management Requirements:**
| Requirement            | Standard                                                                                                 |
| ---------------------- | -------------------------------------------------------------------------------------------------------- |
| **Session Timeout**    | Network connections must be terminated at end of session or after 60 minutes of inactivity               |
| **Account Lockout**    | Maximum 6 consecutive invalid logon attempts; auto-lock until admin release OR minimum 30 minute lockout |
| **Access Restriction** | Highly confidential and confidential data access restricted to intended requestors (human and non-human) |

**Access Control Requirements:**
- Applications must be configured to only allow specifically defined, documented, and approved access requests
- Applications must be configured to only allow specifically defined, documented, and approved functions, APIs, services, features, ports, and protocols
- Application must separate user functionality from application management capability
- Application must prevent presentation of management capability at interface for non-privileged users

**Example Finding:**
```markdown
**FINDING-011: Insufficient Session Timeout**
**Confidence:** HIGH

- **Location:** src/config/session.config.ts:15
- **Issue:** Session timeout set to 24 hours instead of 60 minutes
- **Code:** `sessionTimeout: 86400000 // 24 hours`
- **Impact:** Sessions remain active longer than corporate standard allows
- **Compliance:** Violates corporate Authentication and Authorization requirements
- **Remediation:** Set session timeout to maximum 60 minutes (3600000ms)
```

**Business Value:** Ensures authentication mechanisms meet corporate security standards.

**Priority:** P0 (Critical)

---

### BR12: Application Security Requirements Review

**Requirement:** Review applications against corporate Application Security and Control Standard requirements.

**Web Application Firewall (WAF) Requirements:**
| Application Type               | Requirement                                               |
| ------------------------------ | --------------------------------------------------------- |
| **Externally Facing Web Apps** | Must have ISO-approved WAF deployed in block mode         |
| **WAF Not Feasible**           | Must implement Runtime Application Security (RASP)        |
| **WAF Logging**                | Must include X-Forwarded-For field to show true source IP |

**Input/Output Requirements:**
- Applications must perform input validation and output encoding
- Rate limiting must be implemented per connection on login pages and data access requests (where technically feasible)
- Automated checks must prevent data processing errors
- Error messages must provide corrective action info without revealing exploitable information

**General Application Security Requirements:**
| Requirement                | Standard                                                                                   |
| -------------------------- | ------------------------------------------------------------------------------------------ |
| **Hardcoded Secrets**      | Applications must NOT contain hardcoded secrets                                            |
| **Environment Separation** | Non-production must be separated from production                                           |
| **Segregation of Duties**  | Must be enforced between prod and non-prod; mitigating controls documented if not feasible |
| **Production Data**        | Highly confidential/confidential data may NOT be used in non-prod without risk acceptance  |
| **Privileged Accounts**    | Use domain-level privileged accounts; avoid local accounts where feasible                  |
| **Default Configurations** | Vendor-supplied defaults must be removed before network installation                       |
| **Approved Hosting**       | Applications may only be deployed in approved data centers                                 |

**Code Quality Requirements:**
- Test, debug, commented-out code, and account data must be removed before production deployment
- Application controls must prevent unauthorized access, use, modification, or destruction of resources
- Developers must follow secure system development lifecycle and DevSecOps processes
- Developers must NOT intentionally write or introduce malicious code or backdoors
- DevOps applications must automate and integrate continuous testing using ISO-approved tools

**Example Finding:**
```markdown
**FINDING-012: Hardcoded Secret Detected**
**Confidence:** HIGH

- **Location:** src/config/database.config.ts:8
- **Issue:** Database password hardcoded in configuration file
- **Code:** `password: 'Prod@Secret123!'`
- **Impact:** Secret exposure in source code repository
- **Compliance:** Violates Application Security Standard (no hardcoded secrets)
- **Remediation:** Move secret to HashiCorp Vault or approved secrets manager
```

**Business Value:** Ensures applications meet corporate application security standards.

**Priority:** P0 (Critical)

---

### BR13: API Security Review

**Requirement:** Review API implementations per corporate API Security requirements.

**API Security Requirements:**
| Requirement              | Standard                                                                                    |
| ------------------------ | ------------------------------------------------------------------------------------------- |
| **API Gateway**          | Must use technology-standard approved API gateways for inbound/outbound requests            |
| **Encryption**           | Must meet encryption requirements for data in transit and at rest per Cryptography Standard |
| **Application Standard** | All APIs subject to Application Security and Control Standard                               |
| **New/External APIs**    | Considered significant change; requires SSA approval prior to production release            |

**Client-Server Technology Requirements:**
| Requirement                   | Standard                                                                |
| ----------------------------- | ----------------------------------------------------------------------- |
| **Server-Side Authorization** | Must be implemented for all client-server technologies                  |
| **Client Storage**            | Confidential or authentication data must NOT be stored/cached on client |
| **Session Clearing**          | Session information must be cleared from client upon logout             |
| **Session Invalidation**      | Sessions must be invalidated on logout                                  |

**Web Services Security Requirements:**
- Architecture must establish trust and trust boundaries between services on transaction-by-transaction basis
- Security controls must validate repudiation of transactions
- Must manage credentials, certificates, encryption keys, secure messaging, protection of resources, secure channels
- Must mitigate against denial of service

**Example Finding:**
```markdown
**FINDING-013: Missing API Gateway**
**Confidence:** HIGH

- **Location:** infrastructure/sam/template.yaml:45
- **Issue:** API endpoint exposed directly without approved API gateway
- **Impact:** Missing centralized security controls, rate limiting, and monitoring
- **Compliance:** Violates API Security requirements (approved gateway required)
- **Remediation:** Route API through approved API gateway; configure security policies
```

**Business Value:** Ensures API implementations meet corporate security standards.

**Priority:** P0 (Critical)

---

### BR14: Database Security Review

**Requirement:** Review database access and security configurations per corporate standards.

**Database Security Requirements:**
| Requirement              | Standard                                                         |
| ------------------------ | ---------------------------------------------------------------- |
| **Action Restriction**   | Restrict actions and access to only necessary tables and schemas |
| **Stored Procedures**    | Remove access to stored procedures application does not need     |
| **Direct Client Access** | Prohibit direct client access to database                        |
| **Network Security**     | Locate database server behind a firewall                         |
| **Unused Services**      | Remove or disable unused/unnecessary services and functions      |
| **Logging**              | Log authentication events and transactions                       |

**Example Finding:**
```markdown
**FINDING-014: Overly Permissive Database Access**
**Confidence:** HIGH

- **Location:** src/services/database.service.ts:23
- **Issue:** Application uses database account with full table access
- **Code:** `GRANT ALL PRIVILEGES ON *.* TO 'app_user'`
- **Impact:** Compromised application could access/modify all database tables
- **Compliance:** Violates Database Security requirements (restrict to necessary tables)
- **Remediation:** Create specific grants for only required tables and operations
```

**Business Value:** Ensures database access follows least privilege principle.

**Priority:** P1 (High)

---

### BR15: Source Code Protection Review

**Requirement:** Review source code protection and repository security per corporate standards.

**Source Code Repository Requirements:**
| Requirement               | Standard                                                        |
| ------------------------- | --------------------------------------------------------------- |
| **Repository Privacy**    | Must remain private unless documented business justification    |
| **Sensitive Information** | Must NOT store confidential or highly confidential information  |
| **Decommissioned Apps**   | Remove or archive repositories of decommissioned applications   |
| **Departed Employees**    | Delete or disable personal repositories of departed employees   |
| **Secret Scanning**       | Must be scanned per ISO requirements for secrets/sensitive data |
| **Server-Side Code**      | Must not be viewable by users of the system                     |
| **Client-Side Scripts**   | Must not contain exploitable information                        |
| **Source Code Scans**     | Must be performed on internally developed applications          |
| **Third-Party Testing**   | Source code testing must include third-party libraries          |

**Binary and Certificate Requirements:**
- All binaries from home-grown source code must be signed using approved certificates
- Digital certificates must be created using approved certificate authorities

**Example Finding:**
```markdown
**FINDING-015: Public Repository with Sensitive Code**
**Confidence:** HIGH

- **Location:** Repository settings
- **Issue:** Internal application repository set to public visibility
- **Impact:** Source code exposed publicly; potential information disclosure
- **Compliance:** Violates Source Code Protection requirements (private by default)
- **Remediation:** Set repository to private; review for sensitive information exposure
```

**Business Value:** Ensures source code is properly protected from unauthorized access.

**Priority:** P1 (High)

---

### BR16: Software Security Assessment (SSA) Compliance Review

**Requirement:** Review applications for SSA requirements and significant change criteria.

**SSA Requirements:**
| Requirement             | Standard                                                          |
| ----------------------- | ----------------------------------------------------------------- |
| **Pre-Production**      | Applications must undergo SSA prior to initial production release |
| **Significant Changes** | SSA required for release of significant changes                   |
| **SSA Process Review**  | Must be reviewed annually by ISO                                  |

**SSA Refresh Schedule (Based on GEAR Risk Rating):**
| Risk Rating  | SSA Refresh Frequency        |
| ------------ | ---------------------------- |
| **High**     | At least every 2 years       |
| **Elevated** | At least every 3 years       |
| **Moderate** | At least every 4 years       |
| **Low**      | Only upon significant change |

**Significant Change Criteria:**
Changes requiring SSA include:
- New GEAR application, technology, service, or domain
- Technology changes (e.g., SQL to Oracle, Solaris to Linux)
- Application/technology/service decommission
- High-risk application impacts (GEAR medium and above)
- Infrastructure changes (new, relocation, decommission, deviations from standards)
- Access control or authorization methodology changes
- Functionality changes not previously reviewed (e.g., version upgrade adding AI)
- Interface changes between software/systems:
  - Managed file transfers
  - API endpoint changes, schema versions, internal changes
  - Data changes, new databases, database constructs
  - Data classification changes (e.g., confidential to highly confidential)
  - New data models, data location changes
- Multi-business line/function/product impacts (2+ areas)
- Employee job performance impacts
- Regulatory/compliance/legal/audit considerations
- Data movement across borders or into cloud

**Example Finding:**
```markdown
**FINDING-016: Missing SSA for Significant Change**
**Confidence:** HIGH

- **Location:** Project documentation / Change records
- **Issue:** New API endpoints added without SSA approval
- **Impact:** Production deployment without required security assessment
- **Compliance:** Violates SSA requirements (significant change requires approval)
- **Remediation:** Complete SSA process before production deployment; document API changes
```

**Business Value:** Ensures all significant changes undergo required security assessment.

**Priority:** P0 (Critical)

---

### BR17: Mobile Application Security Review

**Requirement:** Review mobile applications per corporate mobile security standards.

**Mobile Application Security Requirements:**
| Requirement               | Standard                                                                                |
| ------------------------- | --------------------------------------------------------------------------------------- |
| **Cached Snapshots**      | Must prevent sensitive information in cached app snapshots by masking before background |
| **Transmission Security** | Must communicate using secure transmission technologies (VPN, IPsec, TLS)               |
| **Session IDs**           | Transaction apps must use strong, non-predictable session IDs; protect from exposure    |

**Example Finding:**
```markdown
**FINDING-017: Sensitive Data in App Snapshot**
**Confidence:** HIGH

- **Location:** src/screens/AccountScreen.tsx:89
- **Issue:** Account balance visible in app snapshot when backgrounded
- **Impact:** Sensitive financial data potentially exposed in device screenshots
- **Compliance:** Violates Mobile Application Security requirements
- **Remediation:** Implement snapshot masking before app enters background state
```

**Business Value:** Ensures mobile applications protect sensitive data appropriately.

**Priority:** P1 (High)

---

### BR18: E-Commerce Security Review

**Requirement:** Review e-commerce applications per corporate e-commerce security standards.

**E-Commerce Security Requirements:**
| Requirement                | Standard                                                        |
| -------------------------- | --------------------------------------------------------------- |
| **Fraud Detection**        | Native fraudulent activity detection where technically feasible |
| **Data Protection**        | Unauthorized disclosure, modification, or duplication controls  |
| **Transmission Integrity** | Incomplete transmission mitigation                              |
| **Transaction Logging**    | Logging of all transactions                                     |

**Example Finding:**
```markdown
**FINDING-018: Missing Fraud Detection**
**Confidence:** MEDIUM

- **Location:** src/services/checkout.service.ts
- **Issue:** No fraud detection implemented for payment transactions
- **Impact:** Increased risk of fraudulent transactions
- **Compliance:** Violates E-Commerce Security requirements (fraud detection required)
- **Remediation:** Implement approved fraud detection service integration
```

**Business Value:** Ensures e-commerce applications have appropriate fraud and transaction controls.

**Priority:** P1 (High)

---

### BR19: Security Monitoring Compliance Review

**Requirement:** Review security monitoring implementation per Logging and Monitoring Standard.

**Security Monitoring Types:**

**Security Monitoring Requirements:**
- Automated data analytics triggering indicators for security threats including:
  - Insider threat activity
  - API and threat actor activity
  - Indicators of compromise
  - Malware, phishing, and ransomware
  - Network perimeter monitoring
  - Data exfiltration

**Operational Monitoring Requirements:**
- Health and performance of physical/virtual devices
- Host-based monitoring (connectivity, error rates, packet loss, latency, bandwidth)
- Network-based monitoring (error rates, packet loss, latency, bandwidth)
- Application-based monitoring (errors, success rates, service failures, performance, resource usage)
- Log-based monitoring (ensure assets actively logging in correct formats)

**Compliance Monitoring Requirements:**
- Configuration management database accuracy
- Effectiveness of logging into central platform/SIEM
- Effectiveness of logging and monitoring standard
- Audit and regulatory substantiation
- Monitoring tool access limited to approved employees/external parties

**Example Finding:**
```markdown
**FINDING-019: Missing Security Event Monitoring**
**Confidence:** HIGH

- **Location:** infrastructure/monitoring/config.yaml
- **Issue:** Failed authentication events not forwarded to SIEM
- **Impact:** Security incidents may go undetected
- **Compliance:** Violates Logging and Monitoring Standard (security logs to SIEM)
- **Remediation:** Configure authentication failure events to forward to SIEM system
```

**Business Value:** Ensures security events are properly monitored for threat detection.

**Priority:** P0 (Critical)

---

### BR20: Incident Response Compliance Review

**Requirement:** Review incident response processes per IT Security Incident Management Standard.

**Incident Management Requirements:**
| Requirement             | Standard                                                                                           |
| ----------------------- | -------------------------------------------------------------------------------------------------- |
| **Logging Protocols**   | Define who can enter, reclassify, and close tickets                                                |
| **Categorization**      | Log, review, categorize; prioritize based on impact and urgency                                    |
| **Immediate Reporting** | Incidents involving confidentiality/integrity/availability compromise must be immediately reported |
| **Diagnosis**           | Link to similar active/inactive incidents or problems                                              |
| **Service Targets**     | Resolve within agreed service targets; escalate if not met                                         |
| **Documentation**       | Record all resolution steps on system of record                                                    |
| **Confirmation**        | Obtain confirmation of service restoration from impacted users                                     |

**Example Finding:**
```markdown
**FINDING-020: Missing Incident Response Integration**
**Confidence:** MEDIUM

- **Location:** Application documentation
- **Issue:** No documented incident response procedures for security events
- **Impact:** Delayed response to security incidents
- **Compliance:** Violates IT Security Incident Management Standard
- **Remediation:** Document incident response procedures; integrate with corporate incident management system
```

**Business Value:** Ensures security incidents are properly managed per corporate standards.

**Priority:** P1 (High)

---

## Scope Definition

### In Scope

**Design Review:**
1. Security-first design assessment
2. Architecture security review
3. Authentication/authorization design review
4. Data protection design review

**Code Review:**
5. Business logic vulnerability detection
6. OWASP Top 10 manual assessment
7. Cryptographic implementation review (per Cryptography and Key Management Standard)
8. Data security and privacy review (per Logging and Monitoring Standard)
9. Infrastructure security review (IaC)

**Corporate Security Standards Compliance:**
10. Authentication and Authorization requirements
11. Application Security and Control Standard
12. API Security requirements
13. Database security requirements
14. Source Code Protection requirements
15. Software Security Assessment (SSA) compliance
16. Mobile Application Security (if applicable)
17. E-Commerce Security (if applicable)
18. Security Monitoring compliance
19. Incident Response compliance
20. Vulnerability Management Standard alignment

**Reporting:**
21. Confidence-level based findings
22. Evidence-based reporting
23. Remediation roadmap (aligned with Risk Priority ratings RP1-RP7)

### Out of Scope

1. **Dependency vulnerability scanning** - Use npm audit, Snyk, etc.
2. **Basic SAST findings** - Automated tools cover these
3. **Dynamic testing (DAST)** - Requires running application
4. **Penetration testing** - Recommend professional testers
5. **Compliance certification** - Provide gaps, not certification
6. **Non-security code quality** - Code-validator's responsibility
7. **CSS, images, fonts** - Not security-relevant
8. **Test file security** - Not production code

---

## Command Structure

### Commands

| Command               | Arguments                | Description                                                            |
| --------------------- | ------------------------ | ---------------------------------------------------------------------- |
| `/review`             | `[code or design paths]` | Main orchestrator - comprehensive security review with scope detection |
| `/check-dependencies` | `[path to package.json]` | Dependency vulnerability analysis (CVEs, outdated packages)            |
| `/check-security`     | `<path to review>`       | Focused security review with auto-detection of file types              |

### Usage Examples

**Comprehensive Security Review (`/review`):**
```
User: /review
Agent: I'll perform a comprehensive security review. What should I review?
- Keywords detected: [design/code/crypto/infrastructure/comprehensive]
- Please provide target paths to review
User: ./src ./infrastructure/sam
Agent: [Discovers files, presents plan, delegates to specialized reviewers]
Agent: [Generates SECURITY-REVIEW-REPORT.md with aggregated findings]
```

**Dependency Vulnerability Analysis (`/check-dependencies`):**
```
User: /check-dependencies ./services/order-service
Agent: [Locates package.json and lock files]
Agent: [Runs npm audit --json and npm outdated --json]
Agent: [Analyzes CVEs by CVSS severity]
Agent: [Generates DEPENDENCY-SECURITY-REPORT.md with prioritized remediation]
```

**Focused Security Review (`/check-security`):**
```
User: /check-security ./src/services/auth
Agent: [Auto-detects file types: *.ts → code-security-reviewer]
Agent: [Presents detection results for confirmation]
Agent: [Executes focused review on authentication code]
Agent: [Generates SECURITY-REVIEW-REPORT.md with scope note]
```

**Auto-Detection Logic (`/check-security`):**
| File Pattern                        | Reviewer Assigned                |
| ----------------------------------- | -------------------------------- |
| `*.ts`, `*.js`                      | code-security-reviewer           |
| `*.md`, `*.pdf` (architecture)      | design-security-reviewer         |
| `*.yaml`, `*.yml` (SAM/CF)          | infrastructure-security-reviewer |
| `*.tf`, `*.tfvars`                  | infrastructure-security-reviewer |
| Files with crypto/jwt/hash          | crypto-security-reviewer         |
| Files with user/pii/ssn patterns    | data-privacy-reviewer            |
| `package.json`, `package-lock.json` | dependency-security-reviewer     |

---

## Inputs and Outputs

### Inputs

| Input Type              | Purpose                        | Required      | Auto-Detection                      |
| ----------------------- | ------------------------------ | ------------- | ----------------------------------- |
| **Design Documents**    | Security-first design review   | Optional      | `*.md`, `*.pdf` (architecture)      |
| **Source Code Path**    | Code security review           | Yes           | `*.ts`, `*.js`                      |
| **Infrastructure Code** | IaC security review            | Optional      | `*.yaml`, `*.yml`, `*.tf`           |
| **Package Manifest**    | Dependency analysis            | Optional      | `package.json`, `package-lock.json` |
| **Scope Selection**     | Design/Code/Both/Comprehensive | Auto-detected | Based on file patterns              |

### Outputs

| Output                            | Command                      | Purpose                                          |
| --------------------------------- | ---------------------------- | ------------------------------------------------ |
| **SECURITY-REVIEW-REPORT.md**     | `/review`, `/check-security` | Comprehensive findings with OWASP Top 10 summary |
| **DEPENDENCY-SECURITY-REPORT.md** | `/check-dependencies`        | CVE findings with prioritized remediation        |

**SECURITY-REVIEW-REPORT.md Contents:**

| Section                                 | Description                                |
| --------------------------------------- | ------------------------------------------ |
| **Executive Summary**                   | High-level findings for management         |
| **OWASP Top 10 Summary**                | Findings mapped to A01-A10 categories      |
| **Compliance Mapping**                  | GDPR, CCPA, PCI-DSS, HIPAA references      |
| **Detailed Findings**                   | Full 11-point evidence package per finding |
| **Risk Priority Classification**        | RP1-RP7 severity ratings                   |
| **Remediation Roadmap**                 | Prioritized fix plan with timelines        |
| **Professional Pentest Recommendation** | Scope for manual testing                   |

**DEPENDENCY-SECURITY-REPORT.md Contents:**

| Section                   | Description                                   |
| ------------------------- | --------------------------------------------- |
| **Audit Summary**         | Counts by severity (CRITICAL/HIGH/MEDIUM/LOW) |
| **Detailed CVE Findings** | CVE ID, package, versions, CVSS score         |
| **Dependency Chain**      | Direct vs transitive vulnerability path       |
| **Remediation Commands**  | `npm update`, `npm audit fix` commands        |
| **Timeline Roadmap**      | Immediate/Short-term/Medium-term/Backlog      |

---

## Success Criteria

### Acceptance Criteria

Plugin is considered successful when:

1. ✅ **Design + Code scope** - Reviews both design and code
2. ✅ **Confidence levels** - Every finding has HIGH/MEDIUM/LOW
3. ✅ **Evidence-based** - File paths, code snippets, explanations
4. ✅ **Beyond SAST/DAST** - Focuses on manual-only findings
5. ✅ **Actionable** - Remediation recommendations provided
6. ✅ **Pentest recommendation** - Clear statement about professional testing
7. ✅ **Corporate Standards** - Findings mapped to applicable corporate security standards
8. ✅ **Risk Priority** - Remediation timelines aligned with Vulnerability Management Standard (RP1-RP7)

**Explicitly NOT guaranteed:**
- ❌ All vulnerabilities found - Manual review has limits
- ❌ Zero false positives - Cannot verify exploitability
- ❌ Runtime security - Static analysis only
- ❌ Replacement for pentest - Recommends professional testing
- ❌ SSA certification - Identifies gaps for SSA process, does not replace SSA

### Definition of Done

For each security review:
- [ ] Design documents reviewed (if provided)
- [ ] Security-relevant code files analyzed
- [ ] Business logic vulnerabilities assessed
- [ ] Corporate security standards compliance checked
- [ ] Findings documented with confidence levels
- [ ] Findings mapped to applicable corporate standards
- [ ] Remediation roadmap created with Risk Priority ratings
- [ ] SSA significant change criteria evaluated
- [ ] Professional pentest recommended
- [ ] Human review requirements stated

---

## Error Handling Requirements

### File Access Errors

| Error Condition    | Expected Behavior               |
| ------------------ | ------------------------------- |
| Path not found     | Report error, stop              |
| Permission denied  | Report specific files, continue |
| Unsupported format | Skip with note                  |

### Analysis Errors

| Error Condition         | Expected Behavior                       |
| ----------------------- | --------------------------------------- |
| Parse error             | Report file, continue with others       |
| Complex obfuscated code | Note limitation, flag for manual review |

---

## Constraints

### Business Constraints

1. **Assisted review** - Does not replace human security experts
2. **Professional pentest** - Always recommend for production
3. **Confidence-based** - No absolute security claims

### Technical Constraints

1. **Static analysis** - Cannot verify runtime behavior
2. **File type filtering** - Excludes CSS, images, tests, etc.
3. **Business context** - May miss context-dependent issues
4. **No execution** - Cannot exploit or verify vulnerabilities

### Critical Constraint: Assisted Security Review

**IMPORTANT:** This is assisted security review, not automated security guarantee.

| What This Plugin IS           | What This Plugin IS NOT       |
| ----------------------------- | ----------------------------- |
| Assistant for security review | Replacement for security team |
| Identifies potential issues   | Guarantees security           |
| Provides confidence levels    | Provides certainty            |
| Recommends pentest            | Replaces penetration testing  |

---

### Critical Limitation: Unstructured Design Document Review

**IMPORTANT:** Design documents (HLD, architecture docs, API specs) are typically **unstructured PDF or Markdown** files. Extracting security requirements from prose text has inherent limitations.

**Design Document Challenge:**
```
┌─────────────────────────────┐
│   DESIGN DOCUMENTS          │
│   (Unstructured)            │
│                             │
│ • HLD.pdf (prose)           │  Security requirements
│ • Architecture.md           │  may be implicit, scattered,
│ • API-Design.pdf            │  or ambiguously stated
└─────────────────────────────┘
```

**Extraction Reliability for Design Review:**

| Document Structure                      | Security Extraction | Confidence |
| --------------------------------------- | ------------------- | ---------- |
| Explicit security sections              | ~80-90%             | HIGH       |
| Scattered security mentions             | ~60-70%             | MEDIUM     |
| Implicit security requirements          | ~40-50%             | LOW        |
| **User-provided security requirements** | ~95%+               | HIGH       |

**Recommended Approach:**
- For HIGH confidence: User tells agent specific security requirements to validate
- For document-based: Agent attempts extraction with stated confidence level
- All findings require security professional verification

---

## Risk Assessment

| Risk                                   | Probability | Impact | Mitigation                                                                          |
| -------------------------------------- | ----------- | ------ | ----------------------------------------------------------------------------------- |
| **Unstructured design doc extraction** | High        | High   | User-assisted approach for HIGH confidence; ~60-80% reliability for auto-extraction |
| **False negatives (missed issues)**    | Medium      | High   | Recommend professional pentest                                                      |
| **False positives**                    | Medium      | Medium | Confidence levels, human review                                                     |
| **Business logic misunderstanding**    | Medium      | Medium | Require human verification                                                          |
| **Overconfidence in tool**             | High        | High   | Clear limitations documentation                                                     |
| **Outdated vulnerability patterns**    | Low         | Medium | Regular pattern updates                                                             |

---

## Appendix

### Related Documents

- **HLD:** `security-reviewer-hld.md` (to be created)
- **LLD:** `security-reviewer-lld.md` (to be created)

**Agents (7 specialized reviewers):**
| Agent File                                   | Role                          |
| -------------------------------------------- | ----------------------------- |
| `agents/security-reviewer-router.md`         | Master orchestrator           |
| `agents/code-security-reviewer.md`           | Business logic & OWASP Top 10 |
| `agents/design-security-reviewer.md`         | Security-first architecture   |
| `agents/crypto-security-reviewer.md`         | Cryptographic implementation  |
| `agents/infrastructure-security-reviewer.md` | AWS/IaC security              |
| `agents/dependency-security-reviewer.md`     | CVE detection                 |
| `agents/data-privacy-reviewer.md`            | PII/PHI & compliance          |

**Commands (3 entry points):**
| Command File                     | Description                       |
| -------------------------------- | --------------------------------- |
| `commands/review.md`             | Main orchestrator command         |
| `commands/check-dependencies.md` | Dependency vulnerability analysis |
| `commands/check-security.md`     | Focused security review           |

**Skills (14 security checklists):**
- `skills/security-checklists/` - Contains owasp-top10.md, design-security.md, crypto-patterns.md, aws-security.md, beyond-sast-dast.md, business-logic-patterns.md, data-privacy-patterns.md, dependency-patterns.md, ecommerce-patterns.md, federation-patterns.md, logging-standards.md, mobile-security.md, web-services-patterns.md

**Corporate Standards:**
  - Global Records and Information Management Policy
  - Cryptography and Key Management Standard
  - Logging and Monitoring Standard
  - Vulnerability Management Standard
  - Application Security and Control Standard
  - IT Security Incident Management Standard
  - Procedures for Determining Significant Changes in IT

### Glossary

- **SAST:** Static Application Security Testing (automated code scanning)
- **DAST:** Dynamic Application Security Testing (runtime scanning)
- **OWASP:** Open Web Application Security Project
- **TOCTOU:** Time-of-Check to Time-of-Use (race condition type)
- **IDOR:** Insecure Direct Object Reference
- **Privilege Escalation:** Gaining unauthorized elevated access
- **SSA:** Software Security Assessment
- **GEAR:** Application inventory and risk rating system
- **SIEM:** Security Information and Event Management
- **WAF:** Web Application Firewall
- **RASP:** Runtime Application Security Protection
- **TDE:** Transparent Data Encryption
- **HSM:** Hardware Security Module
- **NTP:** Network Time Protocol
- **RP1-RP7:** Risk Priority ratings (1=highest, 7=lowest)
- **CISA-KEV:** CISA Known Exploited Vulnerabilities catalog
- **ISO:** Information Security Office

### File Types Reference

**Security-Relevant (INCLUDE):**
`.ts`, `.js`, `.handler.ts`, `.service.ts`, `.guard.ts`, `.interceptor.ts`, `.yaml` (IaC), `.json` (configs)

**Not Security-Relevant (EXCLUDE):**
`.css`, `.scss`, `.less`, `.png`, `.jpg`, `.svg`, `.woff`, `.ttf`, `.spec.ts`, `.test.ts`, `.md`, `package-lock.json`, `node_modules/`, `dist/`, `build/`

### Corporate Security Standards Reference

| Standard                                             | Applicable BRs         |
| ---------------------------------------------------- | ---------------------- |
| **Cryptography and Key Management Standard**         | BR4                    |
| **Logging and Monitoring Standard**                  | BR5, BR19              |
| **Vulnerability Management Standard**                | BR9                    |
| **Application Security and Control Standard**        | BR11, BR12, BR13, BR14 |
| **Source Code Protection Requirements**              | BR15                   |
| **SSA and Significant Change Procedures**            | BR16                   |
| **Mobile Application Security**                      | BR17                   |
| **E-Commerce Security**                              | BR18                   |
| **IT Security Incident Management Standard**         | BR20                   |
| **Global Records and Information Management Policy** | BR5                    |

### Revision History

| Version | Date         | Author | Changes                                                                                                                                                                                                                                       |
| ------- | ------------ | ------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1.0     | Nov 25, 2025 | AI COE | Initial BRD: Design + Code scope; Security-first design review; Business logic focus beyond SAST/DAST; Confidence levels; File type filtering; Professional pentest recommendation; Clear limitations                                         |
| 1.0.1   | Nov 25, 2025 | AI COE | Added "Generative AI Limitations & HITL Requirement" disclaimer - LLM limitations (hallucination, no exploitation testing, pattern-based); HITL is mandatory; Tool is assistant not replacement for professional security assessment          |
| 1.1     | Nov 25, 2025 | AI COE | Added "Critical Limitation: Unstructured Design Document Review" section - design documents (HLD, architecture) are unstructured; extraction reliability varies by document structure; user-assisted approach recommended for HIGH confidence |
| 1.2     | Dec 2025     | AI COE | Bump version for plugin bundle release v1.2                                                                                                                                                                                                   |
| 1.3     | 2026-01-09   | AI COE Team | Version bump for release v1.3.0                                                                                                                                                                                                               |
| 1.4     | 2026-01-21   | AI COE Team | Version bump for unified release v1.4.0                                                                                                                                                                                                       |

---

**Document Owner:** AI COE Team
**Status:** In Development
**Last Updated:** December 18, 2025
