# Low-Level Design: Security Reviewer Plugin

**Feature:** Claude Code Plugin for Security Review (Design & Code)

**Status:** Implementing

**Document Type:** Low-Level Design (LLD)

**Version:** 1.0

**Consumer:** security-reviewer plugin agents

---

## Table of Contents

1. [Vulnerability Detection Patterns](#1-vulnerability-detection-patterns)
2. [OWASP Top 10 Implementation](#2-owasp-top-10-implementation)
3. [Severity and Confidence Scoring](#3-severity-and-confidence-scoring)
4. [Finding Templates](#4-finding-templates)
5. [Agent Prompt Specifications](#5-agent-prompt-specifications)
6. [Skill File Specifications](#6-skill-file-specifications)
7. [Integration Patterns](#7-integration-patterns)
8. [Quality Assurance](#8-quality-assurance)
9. [Related Documents](#9-related-documents)
10. [Revision History](#10-revision-history)

---

## 1. Vulnerability Detection Patterns

### 1.1 Business Logic Vulnerabilities

#### Pattern BL-01: Horizontal Privilege Escalation

**Purpose:** Detect user A accessing user B's data

**Detection:**
```bash
# Find resource access without ownership check
Grep: "params.userId", "params.id", "req.body.userId"
# Near database queries without comparison to authenticated user
```

**Code Pattern (Vulnerable):**
```typescript
// VULNERABLE: Only checks authentication, not authorization
const profile = await db.get(req.params.userId);
return profile;
```

**Code Pattern (Secure):**
```typescript
// SECURE: Checks ownership
if (req.params.userId !== req.user.id) {
  throw new ForbiddenError('Access denied');
}
const profile = await db.get(req.params.userId);
```

**Confidence:** HIGH when ownership check missing

---

#### Pattern BL-02: Vertical Privilege Escalation

**Purpose:** Detect user gaining admin privileges

**Detection:**
```bash
# Find role checks from client data
Grep: "req.body.role", "req.body.isAdmin", "user.role"
# Check if role comes from user input vs server
```

**Code Pattern (Vulnerable):**
```typescript
// VULNERABLE: Role from client-provided data
if (req.body.role === 'admin') {
  performAdminAction();
}
```

**Code Pattern (Secure):**
```typescript
// SECURE: Role from verified JWT claims
if (req.user.role === 'admin' && verifyAdminToken(req.token)) {
  performAdminAction();
}
```

---

#### Pattern BL-03: Race Condition (TOCTOU)

**Purpose:** Detect time-of-check to time-of-use vulnerabilities

**Detection:**
```bash
# Find check-then-act patterns
Grep: "if.*await.*\n.*await" (check then action pattern)
# Non-atomic balance operations
```

**Code Pattern (Vulnerable):**
```typescript
// VULNERABLE: Check-then-act with race window
if (await hasCredits(userId)) {
  // Race condition window here
  await deductCredits(userId);
  await processOrder();
}
```

**Code Pattern (Secure):**
```typescript
// SECURE: Atomic transaction
await db.transaction(async (tx) => {
  const credits = await tx.getCreditsForUpdate(userId);
  if (credits < amount) throw new Error('Insufficient credits');
  await tx.deductCredits(userId, amount);
  await tx.processOrder(orderId);
});
```

---

#### Pattern BL-04: State Machine Bypass

**Purpose:** Detect workflow step skipping

**Detection:**
```bash
# Find state transitions without validation
Grep: "status = ", "state = ", "workflow"
# Check for state validation
```

**Code Pattern (Vulnerable):**
```typescript
// VULNERABLE: Direct state update without validation
await order.update({ status: 'shipped' });
```

**Code Pattern (Secure):**
```typescript
// SECURE: State machine validation
const validTransitions = {
  'pending': ['paid', 'cancelled'],
  'paid': ['processing', 'refunded'],
  'processing': ['shipped']
};
if (!validTransitions[order.status]?.includes(newStatus)) {
  throw new Error('Invalid state transition');
}
```

---

### 1.2 Authentication Vulnerabilities

#### Pattern AUTH-01: Missing Authentication

**Detection:**
```bash
# Find API endpoints without auth middleware
Grep: "app.get", "app.post", "router."
# Check for missing auth guard/middleware
```

**Indicators:**
- Route handler without auth middleware
- Lambda without authorizer
- API Gateway without authentication

---

#### Pattern AUTH-02: JWT Vulnerabilities

**Detection:**
```bash
# JWT algorithm confusion
Grep: "algorithm.*none", "verify.*algorithms", "jwt.decode"
# Weak secrets
Grep: "secret.*=.*['\"][^'\"]{1,20}['\"]"
```

**Issues to Find:**
| Issue | Pattern |
|-------|---------|
| Algorithm confusion | `algorithms: ['none']` or missing algorithm check |
| Weak secret | Short or predictable secret string |
| Missing expiration | No `exp` claim validation |
| Client-side storage | `localStorage.setItem('token'...)` |

---

### 1.3 Injection Vulnerabilities

#### Pattern INJ-01: SQL Injection (Context-Specific)

**Focus:** Second-order and context-specific injection

**Detection:**
```bash
# String concatenation in queries
Grep: "\$\{.*\}.*SELECT|INSERT|UPDATE|DELETE"
Grep: "query.*\+.*\+|concat.*query"
```

**Beyond SAST:** Focus on:
- Second-order injection (stored, then used)
- Dynamic column/table names
- JSON/Array injection in NoSQL

---

#### Pattern INJ-02: Command Injection

**Detection:**
```bash
Grep: "exec\(", "spawn\(", "execSync"
# With user input nearby
```

**Code Pattern (Vulnerable):**
```typescript
// VULNERABLE: User input in command
const result = execSync(`convert ${req.body.filename} output.pdf`);
```

---

### 1.4 Cryptographic Vulnerabilities

#### Pattern CRYPTO-01: Weak Algorithms

**Detection:**
```bash
Grep: "createHash.*md5|sha1", "aes-.*-ecb", "DES"
```

**Weak Patterns:**
| Algorithm | Issue | Secure Alternative |
|-----------|-------|-------------------|
| MD5 | Broken | SHA-256+ |
| SHA1 | Collision attacks | SHA-256+ |
| AES-ECB | Pattern leak | AES-GCM |
| DES/3DES | Weak | AES-256 |

---

#### Pattern CRYPTO-02: Insecure Random Numbers

**Detection:**
```bash
Grep: "Math.random\(\)", "Date.now\(\).*token|session|id"
```

**Code Pattern (Vulnerable):**
```typescript
// VULNERABLE: Predictable token
const token = Math.random().toString(36);
```

**Code Pattern (Secure):**
```typescript
// SECURE: Cryptographically secure
const token = crypto.randomBytes(32).toString('hex');
```

---

#### Pattern CRYPTO-03: Weak Password Hashing

**Detection:**
```bash
Grep: "createHash.*password", "md5.*password"
# Missing bcrypt, argon2, scrypt
```

**Secure Hashing:**
```typescript
// SECURE: bcrypt with proper cost factor
const hash = await bcrypt.hash(password, 12);
```

---

### 1.5 Data Security Vulnerabilities

#### Pattern DATA-01: Sensitive Data in Logs

**Detection:**
```bash
Grep: "log.*password|secret|token|key|ssn|credit"
Grep: "console.log.*req.body"
```

**Code Pattern (Vulnerable):**
```typescript
// VULNERABLE: Logging credentials
logger.info(`Login: ${email}, password: ${password}`);
```

---

#### Pattern DATA-02: Error Message Information Leak

**Detection:**
```bash
Grep: "catch.*error.*stack|message"
Grep: "return.*error|exception"
```

**Code Pattern (Vulnerable):**
```typescript
// VULNERABLE: Stack trace exposure
catch (e) {
  return { error: e.stack };
}
```

---

### 1.6 Infrastructure Vulnerabilities

#### Pattern INFRA-01: Overly Permissive IAM

**Detection:**
```bash
Grep: "Action.*:.*\*", "Resource.*:.*\*"
```

**Code Pattern (Vulnerable):**
```yaml
# VULNERABLE: Wildcard permissions
Policies:
  - Statement:
      - Effect: Allow
        Action: s3:*
        Resource: '*'
```

---

#### Pattern INFRA-02: Secrets in Environment

**Detection:**
```bash
Grep: "Environment.*Variables.*SECRET|PASSWORD|KEY"
```

**Secure Alternative:** AWS Secrets Manager or SSM Parameter Store

---

## 2. OWASP Top 10 Implementation

### 2.1 Manual Review Focus

| OWASP | Automated Coverage | Manual Focus |
|-------|-------------------|--------------|
| A01: Broken Access Control | Basic patterns | Authorization logic, IDOR, privilege escalation |
| A02: Cryptographic Failures | Weak algorithms | Key management, usage context |
| A03: Injection | SQL/XSS patterns | Context-specific, second-order |
| A04: Insecure Design | None | Architecture flaws, threat modeling |
| A05: Security Misconfiguration | Basic checks | Context-dependent configs |
| A06: Vulnerable Components | CVE scanning | How components are used |
| A07: Auth Failures | Basic patterns | Session logic, credential management |
| A08: Integrity Failures | Basic patterns | Update mechanisms, CI/CD |
| A09: Logging Failures | Limited | What's logged, sensitive data |
| A10: SSRF | Basic patterns | Indirect SSRF, complex scenarios |

### 2.2 OWASP Assessment Template

```markdown
## OWASP Top 10 Assessment

### A01: Broken Access Control
**Risk Level:** {CRITICAL | HIGH | MEDIUM | LOW | N/A}
**Confidence:** {HIGH | MEDIUM | LOW}

**Findings:**
- {finding description}

**Evidence:**
- File: {path}
- Line: {line number}
- Code: {code snippet}

**Remediation:**
- {specific fix}

---
{Repeat for each OWASP category}
```

---

## 3. Severity and Confidence Scoring

### 3.1 Severity Levels

| Severity | Criteria | Timeline |
|----------|----------|----------|
| **CRITICAL** | Exploitable, high impact, public exposure | 24-48 hours |
| **HIGH** | Exploitable, significant impact | 1 week |
| **MEDIUM** | Potential impact, harder to exploit | 1 sprint |
| **LOW** | Minor impact, defense in depth | Backlog |

### 3.2 Severity Assignment Matrix

| Exploitability | Impact: High | Impact: Medium | Impact: Low |
|----------------|--------------|----------------|-------------|
| Easy | CRITICAL | HIGH | MEDIUM |
| Moderate | HIGH | MEDIUM | LOW |
| Difficult | MEDIUM | LOW | LOW |

### 3.3 Confidence Levels

| Level | Meaning | Criteria |
|-------|---------|----------|
| **HIGH** | Likely real vulnerability | Clear code evidence, known pattern |
| **MEDIUM** | Probable issue | Pattern detected, context unclear |
| **LOW** | Possible issue | Unusual pattern, may have mitigations |

### 3.4 Confidence Factors

```markdown
HIGH Confidence:
- Explicit vulnerable pattern found
- No apparent mitigating controls
- Known exploit technique exists
- Code path clearly reachable

MEDIUM Confidence:
- Pattern suggests vulnerability
- Mitigations may exist elsewhere
- Context-dependent exploitability
- Requires specific conditions

LOW Confidence:
- Unusual but possibly secure pattern
- Defense in depth may mitigate
- Requires complex attack chain
- May be false positive
```

---

## 4. Finding Templates

### 4.1 Standard Finding Format

```markdown
**FINDING-{ID}: {Title}**
**Severity:** {CRITICAL | HIGH | MEDIUM | LOW}
**Confidence:** {HIGH | MEDIUM | LOW}

- **Category:** {OWASP Category / CWE ID}
- **Location:** {file_path}:{line_numbers}
- **Issue:** {Clear description of the vulnerability}
- **Code:**
  ```{language}
  {vulnerable code snippet}
  ```
- **Impact:** {Business/security impact}
- **Remediation:**
  ```{language}
  {secure code example}
  ```
- **Why Automated Tools Miss This:** {Explanation}
- **Human Verification Required:** Yes - {specific verification steps}
```

### 4.2 Full Finding Example

```markdown
**FINDING-001: Horizontal Privilege Escalation in User Profile**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** A01:2021 - Broken Access Control / CWE-284
- **Location:** src/handlers/user-profile.handler.ts:45-52
- **Issue:** getUserProfile() validates authentication but not authorization. Any authenticated user can access any other user's profile data.
- **Code:**
  ```typescript
  export const handler = async (event) => {
    // Only checks if user is logged in
    const userId = event.pathParameters.userId;
    const profile = await db.get(userId);
    return { statusCode: 200, body: JSON.stringify(profile) };
  };
  ```
- **Impact:**
  - Complete user data breach - any user can access any profile
  - Privacy violation - PII exposure
  - Compliance risk - GDPR, CCPA violations
- **Remediation:**
  ```typescript
  export const handler = async (event) => {
    const requestedUserId = event.pathParameters.userId;
    const authenticatedUserId = event.requestContext.authorizer.userId;

    if (requestedUserId !== authenticatedUserId) {
      return { statusCode: 403, body: JSON.stringify({ error: 'Forbidden' }) };
    }

    const profile = await db.get(requestedUserId);
    return { statusCode: 200, body: JSON.stringify(profile) };
  };
  ```
- **Why Automated Tools Miss This:** SAST tools see authentication check but cannot understand business requirement that users should only access own data.
- **Human Verification Required:** Yes - Test accessing profile with different user's ID
```

---

### 4.3 Report Template

```markdown
# Security Review Report

**Generated:** {timestamp}
**Review Type:** {Design | Code | Crypto | Infrastructure | Full}

---

## IMPORTANT DISCLAIMER

⚠️ **This report is generated by AI and requires human verification.**

| Limitation | Impact |
|------------|--------|
| Static analysis only | Cannot verify runtime behavior |
| Pattern-based | May miss novel vulnerabilities |
| Context limits | Business logic understanding limited |
| No exploitation | Cannot confirm exploitability |

**Human-In-The-Loop (HITL) is MANDATORY before remediation.**

**Professional penetration testing recommended for production systems.**

---

## Executive Summary

**Review Scope:** {paths reviewed}
**Total Findings:** {count}

| Severity | Count | Confidence |
|----------|-------|------------|
| CRITICAL | {n} | {HIGH/MEDIUM/LOW} |
| HIGH | {n} | {HIGH/MEDIUM/LOW} |
| MEDIUM | {n} | {HIGH/MEDIUM/LOW} |
| LOW | {n} | {HIGH/MEDIUM/LOW} |

---

## OWASP Top 10 Summary

| Category | Risk | Findings |
|----------|------|----------|
| A01: Broken Access Control | {level} | FINDING-001, 002 |
| A02: Cryptographic Failures | {level} | FINDING-003 |
| ... | ... | ... |

---

## Critical Findings

{Finding details for CRITICAL severity}

---

## High Findings

{Finding details for HIGH severity}

---

## Medium Findings

{Finding details}

---

## Low Findings

{Finding details}

---

## Remediation Roadmap

### Immediate (24-48 hours)
| ID | Finding | Owner | Action |
|----|---------|-------|--------|
| FINDING-001 | Privilege Escalation | Auth Team | Add ownership check |

### Short-term (1 week)
{table}

### Medium-term (1 sprint)
{table}

---

## Penetration Testing Recommendation

**This security review is assisted analysis, not comprehensive audit.**

### Recommended Testing

1. **External Penetration Test**
   - Focus: Internet-facing applications
   - Frequency: Annually or after major changes

2. **Web Application Test**
   - Focus: OWASP Top 10, business logic
   - Frequency: Before major releases

### Testing Vendors
- Engage certified pentest vendors (CREST, OSCP certified)
- Request both automated and manual testing
- Include business logic testing in scope

---

## Human Review Required

All findings require verification because:
- Static analysis cannot verify exploitability
- Business context may provide mitigations
- False positives are possible

**Recommended verification steps:**
1. Review each CRITICAL/HIGH finding
2. Attempt to reproduce vulnerability
3. Verify remediation effectiveness
4. Add security regression tests

---

**Reviewer:** security-reviewer v2.0.0
**Accuracy Estimate:** 60-80% for in-scope vulnerabilities
```

---

## 5. Agent Prompt Specifications

### 5.1 Router Agent Context Passing

```yaml
# Context passed from router to reviewers
securityContext:
  request: "{original user request}"
  reviewType: "design | code | crypto | infrastructure | full"

  targets:
    design:
      paths: ["{design_doc_paths}"]
      formats: ["PDF", "MD", "YAML"]
    code:
      paths: ["{source_code_paths}"]
      languages: ["TypeScript", "JavaScript"]
    infrastructure:
      paths: ["{iac_paths}"]
      types: ["SAM", "CloudFormation", "Terraform"]

  skillReferences:
    owaspTop10: "skills/security-checklists/owasp-top10.md"
    designSecurity: "skills/security-checklists/design-security.md"
    cryptoPatterns: "skills/security-checklists/crypto-patterns.md"
    awsSecurity: "skills/security-checklists/aws-security.md"
```

### 5.2 Reviewer Invocation Template

```markdown
Task(
  subagent_type: "code-security-reviewer",
  model: "haiku",
  prompt: """
  Review source code for security vulnerabilities.

  ## Target
  - Paths: {code_paths}
  - Languages: TypeScript, JavaScript

  ## Focus Areas (Beyond SAST/DAST)
  1. Business logic authorization flaws
  2. Horizontal/vertical privilege escalation
  3. Race conditions (TOCTOU)
  4. State machine bypasses
  5. OWASP Top 10 (manual focus)

  ## Detection Patterns
  Reference: skills/security-checklists/owasp-top10.md

  ## Output Format
  For each finding:
  - Severity (CRITICAL/HIGH/MEDIUM/LOW)
  - Confidence (HIGH/MEDIUM/LOW)
  - Location (file:line)
  - Vulnerable code snippet
  - Impact description
  - Remediation code example
  - Why automated tools miss this

  ## Quality Requirements
  - Only report exploitable vulnerabilities
  - Include proof-of-concept where safe
  - Provide working remediation code
  - Explain business impact
  """
)
```

---

## 6. Skill File Specifications

### 6.1 SKILL.md Entry Point

**File:** `skills/security-checklists/SKILL.md`

```markdown
---
name: security-checklists
description: Security review checklists for OWASP Top 10, design security, cryptographic patterns, and AWS security. Use when conducting security reviews.
---

# Security Checklists Skill

This skill provides security review checklists for comprehensive assessment.

## Checklist Categories

| Category | File | Purpose |
|----------|------|---------|
| **OWASP Top 10** | `owasp-top10.md` | Web vulnerability checklist |
| **Design Security** | `design-security.md` | Security-first design review |
| **Crypto Patterns** | `crypto-patterns.md` | Cryptographic implementation |
| **AWS Security** | `aws-security.md` | AWS/Lambda security |

## Load by Review Type

| Review Type | Checklists to Load |
|-------------|-------------------|
| Design review | design-security.md |
| Code review | owasp-top10.md |
| Crypto review | crypto-patterns.md |
| Infrastructure | aws-security.md |
| Full review | All checklists |
```

### 6.2 OWASP Top 10 Checklist

**File:** `skills/security-checklists/owasp-top10.md`

```markdown
# OWASP Top 10 Checklist

## A01:2021 - Broken Access Control

### Check for:
- [ ] Missing authorization on endpoints
- [ ] Insecure Direct Object References (IDOR)
- [ ] Horizontal privilege escalation
- [ ] Vertical privilege escalation
- [ ] Directory traversal
- [ ] CORS misconfiguration

### Detection Patterns:
```bash
# Missing ownership check
Grep: "params.userId|params.id" near "db.get|findOne"
# Missing role check
Grep: "isAdmin|role" from "req.body"
```

---

## A02:2021 - Cryptographic Failures

### Check for:
- [ ] Weak hashing (MD5, SHA1 for security)
- [ ] Hardcoded encryption keys
- [ ] Insecure random numbers
- [ ] Missing encryption for sensitive data
- [ ] Weak TLS configuration

### Detection Patterns:
```bash
Grep: "createHash.*md5|sha1"
Grep: "Math.random.*token|secret"
Grep: "password.*=.*['\"]"
```

---

## A03:2021 - Injection

### Check for:
- [ ] SQL injection (especially dynamic queries)
- [ ] Command injection
- [ ] NoSQL injection
- [ ] XSS (context-specific)
- [ ] Template injection

---

## A04:2021 - Insecure Design

### Check for:
- [ ] Missing rate limiting
- [ ] Lack of account lockout
- [ ] Insufficient session management
- [ ] Missing security headers
- [ ] Weak password policies

---

{Continue for A05-A10}
```

### 6.3 Design Security Checklist

**File:** `skills/security-checklists/design-security.md`

```markdown
# Design Security Checklist

## Authentication Design

- [ ] Multi-factor authentication considered?
- [ ] Session management defined?
- [ ] Token expiration/refresh strategy?
- [ ] Account lockout policy?
- [ ] Password requirements specified?

## Authorization Design

- [ ] Principle of least privilege?
- [ ] Role separation defined?
- [ ] Resource ownership model clear?
- [ ] Admin privilege escalation path?
- [ ] API authorization documented?

## Data Protection

- [ ] Sensitive data identified?
- [ ] Encryption at rest defined?
- [ ] Encryption in transit defined?
- [ ] Data classification scheme?
- [ ] Data retention policies?

## API Security

- [ ] Rate limiting designed?
- [ ] Input validation strategy?
- [ ] Error handling (no info leak)?
- [ ] CORS policy defined?
- [ ] Authentication required?

## Network Security

- [ ] Defense in depth?
- [ ] Security boundaries defined?
- [ ] Internal/external separation?
- [ ] Firewall rules documented?
```

### 6.4 Crypto Patterns Checklist

**File:** `skills/security-checklists/crypto-patterns.md`

```markdown
# Cryptographic Patterns Checklist

## Encryption

### Secure Patterns
| Use Case | Recommended |
|----------|-------------|
| Symmetric encryption | AES-256-GCM |
| Asymmetric encryption | RSA-2048+, ECDSA |
| Data at rest | AES-256 |

### Vulnerable Patterns
| Pattern | Issue |
|---------|-------|
| AES-ECB | Pattern leak |
| DES/3DES | Weak |
| RC4 | Broken |

## Hashing

### For Passwords
| Algorithm | Status |
|-----------|--------|
| bcrypt | Recommended |
| Argon2 | Recommended |
| scrypt | Acceptable |
| PBKDF2 | Acceptable |
| MD5/SHA1 | VULNERABLE |

### For Integrity
| Algorithm | Status |
|-----------|--------|
| SHA-256+ | Recommended |
| SHA-1 | Deprecated |
| MD5 | VULNERABLE |

## Random Numbers

### Secure Sources
```typescript
// Node.js
crypto.randomBytes(32)
crypto.randomUUID()

// Browser
crypto.getRandomValues()
```

### Insecure Sources
```typescript
// NEVER for security
Math.random()
Date.now()
```

## JWT Security

### Checklist
- [ ] Algorithm explicitly set (not 'none')
- [ ] Strong signing secret (256+ bits)
- [ ] Expiration claim validated
- [ ] Audience claim validated
- [ ] Not stored in localStorage
```

### 6.5 AWS Security Checklist

**File:** `skills/security-checklists/aws-security.md`

```markdown
# AWS Security Checklist

## IAM Policies

### Principle of Least Privilege
- [ ] No wildcard (*) in Actions
- [ ] No wildcard (*) in Resources
- [ ] Specific service permissions only
- [ ] Condition statements where applicable

### Vulnerable Pattern
```yaml
# VULNERABLE
Action: '*'
Resource: '*'
```

### Secure Pattern
```yaml
# SECURE
Action:
  - s3:GetObject
  - s3:PutObject
Resource:
  - arn:aws:s3:::my-bucket/*
Condition:
  StringEquals:
    s3:x-amz-acl: private
```

## Lambda Security

### Configuration
- [ ] VPC configured (if needed)
- [ ] Security groups restrictive
- [ ] No secrets in environment variables
- [ ] Timeout appropriately set
- [ ] Memory limits set

### Secrets Management
```yaml
# Use Secrets Manager
SecretsManagerSecretArn: !Ref MySecret

# Or SSM Parameter Store
ParameterStoreArn: !Ref MyParameter
```

## API Gateway

### Security Checklist
- [ ] Authorization configured
- [ ] Rate limiting enabled
- [ ] WAF integrated
- [ ] CORS properly configured
- [ ] Request validation enabled

## S3 Buckets

### Checklist
- [ ] Public access blocked
- [ ] Encryption enabled
- [ ] Versioning enabled
- [ ] Access logging enabled
- [ ] Lifecycle policies set
```

---

## 7. Integration Patterns

### 7.1 Integration with Code Validator

```markdown
## Complementary Validation

| Aspect | Security Reviewer | Code Validator |
|--------|------------------|----------------|
| Focus | SECURITY | QUALITY |
| Depth | Deep security | Broad patterns |
| OWASP | Vulnerabilities | Standards |

**Combined Workflow:**
1. security-reviewer finds vulnerabilities
2. code-validator checks code quality
3. Both reports inform remediation
```

### 7.2 Integration with Documents Maintainer

```markdown
## Documentation Flow

1. security-reviewer generates SECURITY-REVIEW-REPORT.md
2. documents-maintainer incorporates security findings
3. Creates security section in project documentation
4. Includes remediation roadmap
```

---

## 8. Quality Assurance

### 8.1 Review Accuracy Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Issue detection | 60-80% | For in-scope vulnerabilities |
| False positive rate | <25% | Findings that aren't real |
| Evidence quality | 100% | Findings with PoC |
| Remediation quality | 100% | Findings with fix code |
| HITL reminder | 100% | Reports with disclaimer |

### 8.2 Testing Checklist

- [ ] Business logic flaws detected
- [ ] OWASP Top 10 assessment works
- [ ] Cryptographic issues found
- [ ] Infrastructure misconfigs detected
- [ ] Confidence levels assigned correctly
- [ ] Severity levels appropriate
- [ ] Remediation code works
- [ ] Pentest recommendation included

---

## 9. Related Documents

- **BRD:** `plugins_tier1a/security-reviewer/requirements/security-reviewer-brd.md`
- **HLD:** `plugins_tier1a/security-reviewer/requirements/security-reviewer-hld.md`
- **Plugin Guide:** `PLUGIN_DEVELOPMENT_GUIDE.md`

---

## 10. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Nov 27, 2025 | AI COE Team | Initial LLD with vulnerability detection patterns for business logic, authentication, injection, crypto, data security, and infrastructure. OWASP Top 10 implementation guide. Severity/confidence scoring. Finding templates. Skill file specifications for security checklists. |
| 1.2 | 2025-12-19 | AI COE Team | Version bump for plugin bundle release v1.2.0 |
| 1.3 | 2026-01-09 | AI COE Team | Version bump for release v1.3.0 |
| 1.4 | 2026-01-21 | AI COE Team | Version bump for unified release v1.4.0 |

---

**Document Owner:** AI COE Team

**Document Type:** Low-Level Design (LLD)

**Status:** Draft

**Consumer:** security-reviewer plugin agents
