# AIDLC-security Changelog

## **1.4.3** - Automatic Report Generation (2026-02-25)

### Bug Fixes

- **Automatic report saving**: Added `Write` tool to security-reviewer-router so `SECURITY-REVIEW-REPORT.md` is
  saved automatically — previously the report was generated but not written to disk
- **Universal report guarantee**: Phase 6 (Report Generation) is now enforced for all review types: design, code,
  crypto, infrastructure, dependencies, and data privacy — including when zero findings are identified
- **Dependency review routing**: Fixed `check-dependencies` skill to route through `security-reviewer-router` instead
  of directly to `dependency-security-reviewer`, ensuring report aggregation and saving always runs
- **Unified report naming**: Dependency reviews now produce `SECURITY-REVIEW-REPORT.md` (previously
  `DEPENDENCY-SECURITY-REPORT.md`) for consistent output across all review types

### Tests

- Added `automated_report_generation.test` covering mandatory file creation, default save path, no-user-action
  requirement, success messaging, and Write failure handling

**Related**: US801163 - Ensure Automatic Report Generation

---

## **1.4.2** - Commands to Skills Migration Cleanup (2026-02-16)

### Cleanup

- Removed obsolete commands/ directory (functionality already migrated to skills)
- Updated README.md to reflect skills-only architecture
- Updated documentation to show natural language invocation instead of slash commands
- All security review functionality now available through auto-invoked skills (review, check-security, check-dependencies)

**Related**: US795212 - Commands to Skills Migration (Iterations 2-3)

---

## **1.4.1** - Plugin Manifest Fix (2026-02-06)

### Bug Fixes

- Fixed plugin.json path references to match actual directory structure
- Removed non-existent infrastructure-security-reviewer agent reference
- Updated skills to use directory format (./skills/check-dependencies, ./skills/check-security)

---

## **1.4.0** - 2026.PI1.Iteration1 (2026-01-22)

**Sprint Period**: January 8 - January 22, 2026

### Plugin Performance Optimizations (F116882: Run Optimizer and Implement Recommendations)

- **US774969**: AIDLC-security optimization - 31% faster (10.6min→7.2min), modularized OWASP Top 10 into 11 files,
  split privacy compliance into 4 frameworks

---

## **1.2.0** - Release version 1.2.0 (2025-12-18)

- Security Validator Updates
