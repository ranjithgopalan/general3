---
name: check-dependencies
description: Analyze dependencies for CVEs, outdated packages, and security patches Use when the user requests this functionality.
---

## Agent Invocation

Use Task tool with `subagent_type="security-reviewer-router"` with the following enriched prompt:

Prompt: """
## User Request
Perform dependency security analysis: $ARGUMENTS

## Intent: DEPENDENCY REVIEW (Security Analysis)

### Review Scope
- Type: Dependency vulnerability analysis
- Focus: CVEs, outdated packages, security patches
- Delegate to: dependency-security-reviewer

## Instructions for Router:

### DEPENDENCY SECURITY ANALYSIS

### 1. Locate Package Manifests
Find package.json and lock files:
- package.json (dependencies)
- package-lock.json (npm)
- yarn.lock (yarn)
- pnpm-lock.yaml (pnpm)

### 2. Run Security Audit
Execute audit commands:
- `npm audit --json` for CVE detection
- `npm outdated --json` for outdated packages

### 3. Analyze Results
For each vulnerability:
- CVE ID and CVSS score
- Affected package and version
- Direct vs transitive dependency
- Fix availability

### 4. Generate Prioritized Report
Sort findings by:
- Severity (CRITICAL > HIGH > MEDIUM > LOW)
- Dependency type (Direct > Transitive)
- Fix availability (Easy fixes first)

### 5. Provide Remediation
For each finding:
- Specific npm/yarn command to fix
- Breaking change warnings
- Alternative packages if deprecated

### 6. Create Remediation Roadmap
- 🔴 Immediate (24-48h): CRITICAL vulnerabilities
- 🟠 Short-term (1 week): HIGH vulnerabilities
- 🟡 Medium-term (1 sprint): MEDIUM vulnerabilities
- 🟢 Backlog: LOW vulnerabilities

### Output Format
Generate SECURITY-REVIEW-REPORT.md with dependency focus:
- Audit summary (counts by severity)
- Detailed findings with CVE IDs
- Remediation commands
- Timeline-based roadmap
"""

Request to process: $ARGUMENTS