# Federation and SSO Patterns Checklist

Reference checklist for code-security-reviewer agent.

This checklist provides detection patterns for federation and Single Sign-On (SSO) security including SAML, OAuth 2.0, and OpenID Connect implementations.

---

## Quick Reference - Federation Standards

| Standard | Use Case | Required Validations |
|----------|----------|----------------------|
| SAML 2.0 | Enterprise SSO | Signature, Issuer, Audience, Conditions |
| OAuth 2.0 | API Authorization | Token validation, Scope, State parameter |
| OIDC | Authentication + Identity | ID Token signature, Issuer, Audience, Nonce, Expiration |

---

## Supported Federation Standards

SaaS applications must support at least one of:
- **SAML 2.0** - Enterprise identity federation
- **OAuth 2.0** - Authorization framework
- **OpenID Connect (OIDC)** - Authentication layer on OAuth 2.0

---

## Detection Patterns

### Federation Implementation Detection

```bash
# SAML detection
Grep: "saml|SAMLResponse|SAMLRequest|saml2"
Grep: "passport-saml|saml2-js|node-saml"
Grep: "AssertionConsumerService|SingleSignOnService"

# OAuth 2.0 detection
Grep: "oauth|OAuth|oauth2|authorization_code"
Grep: "passport-oauth|simple-oauth2|client-oauth2"
Grep: "access_token|refresh_token|grant_type"

# OIDC detection
Grep: "openid|oidc|id_token|OpenIdConnect"
Grep: "passport-openidconnect|openid-client|oidc-client"
Grep: "/.well-known/openid-configuration"
```

### Token Validation Detection

```bash
# Signature validation
Grep: "verify.*signature|validateSignature|signatureVerification"
Grep: "jwt.verify|verifyIdToken|validateToken"

# Issuer/Audience validation
Grep: "issuer|iss.*validate|validateIssuer"
Grep: "audience|aud.*validate|validateAudience"

# Expiration validation
Grep: "exp.*check|validateExpiration|isExpired"
Grep: "nbf|notBefore|iat"
```

### Custom Auth Detection (Potential Bypass)

```bash
# Custom auth that might bypass SSO
Grep: "localStrategy|LocalStrategy|local.*auth"
Grep: "password.*login|username.*password.*auth"
Grep: "bcrypt.*compare|comparePassword"
# Check if these coexist with SSO without proper integration
```

---

## Token Validation Checklist

All federation tokens must validate:

| Check | SAML | OAuth | OIDC | Severity if Missing |
|-------|------|-------|------|---------------------|
| Signature | Yes | N/A* | Yes | CRITICAL |
| Issuer | Yes | Yes | Yes | CRITICAL |
| Audience | Yes | Yes | Yes | CRITICAL |
| Expiration | Yes | Yes | Yes | HIGH |
| Not-Before | Yes | - | Yes | MEDIUM |
| Nonce | - | Yes (state) | Yes | HIGH |
| Subject | Yes | - | Yes | MEDIUM |

*OAuth access tokens are opaque; validation is via introspection or JWT verification

---

## FED-01: Missing SAML Signature Validation

**Severity:** CRITICAL | **CWE:** CWE-347

SAML assertions MUST have signature validation enabled.

```typescript
// VULNERABLE: Signature validation disabled
const samlStrategy = new SamlStrategy({
  entryPoint: 'https://idp.example.com/sso',
  issuer: 'my-app',
  cert: idpCert,
  wantAssertionsSigned: false,  // DANGEROUS!
  wantAuthnResponseSigned: false  // DANGEROUS!
}, (profile, done) => {
  return done(null, profile);
});

// VULNERABLE: No signature check
app.post('/sso/callback', (req, res) => {
  const samlResponse = req.body.SAMLResponse;
  const decoded = Buffer.from(samlResponse, 'base64').toString();
  const assertion = parseXml(decoded);  // No signature verification!
  const user = extractUserFromAssertion(assertion);
  req.login(user);
});

// SECURE: Proper SAML configuration
const samlStrategy = new SamlStrategy({
  entryPoint: 'https://idp.example.com/sso',
  issuer: 'my-app',
  cert: idpCert,
  wantAssertionsSigned: true,   // Require signed assertions
  wantAuthnResponseSigned: true, // Require signed response
  signatureAlgorithm: 'sha256', // Use strong algorithm
  digestAlgorithm: 'sha256',
  identifierFormat: 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
  validateInResponseTo: true,   // Prevent replay
  requestIdExpirationPeriodMs: 3600000  // 1 hour
}, (profile, done) => {
  // Profile is only provided if signature validated
  return done(null, profile);
});

// SECURE: Using saml2-js with explicit validation
const sp = new saml2.ServiceProvider({
  entity_id: 'my-app',
  private_key: privateKey,
  certificate: spCert,
  assert_endpoint: 'https://myapp.com/sso/callback'
});

const idp = new saml2.IdentityProvider({
  sso_login_url: 'https://idp.example.com/sso',
  certificates: [idpCert]
});

sp.post_assert(idp, { request_body: req.body }, (err, response) => {
  if (err) {
    // Signature validation failed
    return res.status(401).send('Invalid SAML response');
  }
  // response.user contains validated user info
});
```

**Finding Template:**
```markdown
**FED-01: Missing SAML Signature Validation**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** Federation Security / CWE-347
- **Location:** {file}:{line}
- **Issue:** SAML response/assertion processed without signature validation
- **Impact:** Attackers can forge SAML assertions to impersonate any user
- **Config Found:** wantAssertionsSigned: false
- **Remediation:** Enable wantAssertionsSigned and wantAuthnResponseSigned
```

---

## FED-02: Missing Issuer Validation

**Severity:** CRITICAL | **CWE:** CWE-287

All federation tokens must validate the issuer (iss) claim.

```typescript
// VULNERABLE: No issuer check
function validateJwt(token: string) {
  const decoded = jwt.verify(token, secret);
  return decoded;  // Accepts tokens from any issuer!
}

// VULNERABLE: OIDC without issuer validation
const decoded = jwt.decode(idToken);
if (decoded.aud === 'my-app') {  // Missing issuer check!
  authenticateUser(decoded);
}

// SECURE: Explicit issuer validation
const TRUSTED_ISSUERS = [
  'https://idp.example.com',
  'https://accounts.google.com'
];

function validateJwt(token: string) {
  const decoded = jwt.verify(token, secret, {
    issuer: TRUSTED_ISSUERS,  // Only accept from trusted issuers
    audience: 'my-app'
  });
  return decoded;
}

// SECURE: OIDC client with issuer validation
import { Issuer, Client } from 'openid-client';

const issuer = await Issuer.discover('https://idp.example.com');

// Issuer is validated during discovery
const client = new issuer.Client({
  client_id: 'my-app',
  client_secret: clientSecret
});

const tokenSet = await client.callback(redirectUri, params, { nonce });
// tokenSet.claims() contains validated claims
```

**Finding Template:**
```markdown
**FED-02: Missing Issuer Validation**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** Federation Security / CWE-287
- **Location:** {file}:{line}
- **Issue:** Token accepted without issuer (iss) validation
- **Impact:** Tokens from malicious issuers could be accepted
- **Remediation:** Add issuer to jwt.verify() options or validate manually
```

---

## FED-03: Missing Audience Validation

**Severity:** CRITICAL | **CWE:** CWE-287

All federation tokens must validate the audience (aud) claim.

```typescript
// VULNERABLE: No audience check
function validateToken(token: string) {
  const decoded = jwt.verify(token, secret);
  // Token for another app could be accepted!
  return decoded;
}

// VULNERABLE: SAML without audience restriction
const assertion = parseSamlResponse(response);
const user = assertion.subject;  // Missing audience check!

// SECURE: JWT with audience validation
function validateToken(token: string) {
  const decoded = jwt.verify(token, secret, {
    audience: 'my-app',  // Must match token's aud claim
    issuer: 'https://idp.example.com'
  });
  return decoded;
}

// SECURE: SAML audience validation
const samlStrategy = new SamlStrategy({
  // ... other options
  audience: 'https://myapp.com/saml/metadata',  // Expected audience
  // OR
  validateAudience: (audience, samlResponse) => {
    return audience === 'https://myapp.com/saml/metadata';
  }
}, callback);
```

**Finding Template:**
```markdown
**FED-03: Missing Audience Validation**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** Federation Security / CWE-287
- **Location:** {file}:{line}
- **Issue:** Token accepted without audience (aud) validation
- **Impact:** Tokens issued for other applications could be accepted
- **Remediation:** Add audience to jwt.verify() options
```

---

## FED-04: Missing Expiration Validation

**Severity:** HIGH | **CWE:** CWE-613

All tokens must be validated for expiration.

```typescript
// VULNERABLE: No expiration check
function validateToken(token: string) {
  const decoded = jwt.decode(token);  // decode() doesn't validate!
  return decoded;
}

// VULNERABLE: Ignoring expiration
const decoded = jwt.verify(token, secret, {
  ignoreExpiration: true  // DANGEROUS!
});

// SECURE: Default expiration validation
const decoded = jwt.verify(token, secret, {
  audience: 'my-app',
  issuer: 'https://idp.example.com'
  // expiration is validated by default
});

// SECURE: Custom clock tolerance for clock skew
const decoded = jwt.verify(token, secret, {
  clockTolerance: 30  // 30 seconds tolerance
});

// SECURE: SAML with time validation
const samlStrategy = new SamlStrategy({
  // ... other options
  acceptedClockSkewMs: 30000,  // 30 seconds tolerance
  maxAssertionAgeMs: 3600000   // 1 hour max age
}, callback);
```

**Finding Template:**
```markdown
**FED-04: Missing Expiration Validation**
**Severity:** HIGH
**Confidence:** HIGH

- **Category:** Federation Security / CWE-613
- **Location:** {file}:{line}
- **Issue:** Token expiration not validated (using decode() or ignoreExpiration)
- **Impact:** Expired/revoked tokens could be used indefinitely
- **Remediation:** Use jwt.verify() instead of jwt.decode(), remove ignoreExpiration
```

---

## FED-05: Missing Nonce/State Validation (CSRF)

**Severity:** HIGH | **CWE:** CWE-352

OAuth/OIDC flows must validate state/nonce to prevent CSRF.

```typescript
// VULNERABLE: No state parameter
app.get('/auth/login', (req, res) => {
  const authUrl = `https://idp.example.com/authorize?` +
    `client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code`;
  res.redirect(authUrl);  // Missing state parameter!
});

app.get('/auth/callback', async (req, res) => {
  const { code } = req.query;  // No state validation!
  const tokens = await exchangeCode(code);
});

// VULNERABLE: OIDC without nonce
const authUrl = `https://idp.example.com/authorize?` +
  `client_id=${clientId}&response_type=id_token&scope=openid`;
// Missing nonce for implicit flow!

// SECURE: State parameter for CSRF protection
app.get('/auth/login', (req, res) => {
  const state = crypto.randomBytes(32).toString('hex');
  req.session.oauthState = state;

  const authUrl = `https://idp.example.com/authorize?` +
    `client_id=${clientId}&redirect_uri=${redirectUri}` +
    `&response_type=code&state=${state}`;
  res.redirect(authUrl);
});

app.get('/auth/callback', async (req, res) => {
  const { code, state } = req.query;

  // Validate state
  if (state !== req.session.oauthState) {
    return res.status(403).send('Invalid state parameter');
  }
  delete req.session.oauthState;

  const tokens = await exchangeCode(code);
});

// SECURE: OIDC with nonce
app.get('/auth/login', (req, res) => {
  const state = crypto.randomBytes(32).toString('hex');
  const nonce = crypto.randomBytes(32).toString('hex');

  req.session.oauthState = state;
  req.session.oidcNonce = nonce;

  const authUrl = `https://idp.example.com/authorize?` +
    `client_id=${clientId}&response_type=code` +
    `&scope=openid&state=${state}&nonce=${nonce}`;
  res.redirect(authUrl);
});

// Validate nonce in ID token
const idToken = jwt.verify(tokenSet.id_token, publicKey);
if (idToken.nonce !== req.session.oidcNonce) {
  throw new Error('Invalid nonce');
}
```

**Finding Template:**
```markdown
**FED-05: Missing State/Nonce Validation**
**Severity:** HIGH
**Confidence:** HIGH

- **Category:** Federation Security / CWE-352
- **Location:** {file}:{line}
- **Issue:** OAuth/OIDC flow without state/nonce parameter
- **Impact:** Vulnerable to CSRF attacks, attackers can link victim accounts
- **Remediation:** Generate random state, store in session, validate on callback
```

---

## FED-06: Custom Authentication Bypassing SSO

**Severity:** HIGH | **CWE:** CWE-287

Applications using SSO should not have local authentication that bypasses it.

```typescript
// VULNERABLE: Local auth bypasses SSO
passport.use('local', new LocalStrategy(async (username, password, done) => {
  const user = await User.findOne({ username });
  if (user && await bcrypt.compare(password, user.hash)) {
    return done(null, user);  // Bypasses SSO completely!
  }
  return done(null, false);
}));

// Local login route alongside SSO
app.post('/login', passport.authenticate('local'));  // Bypasses SSO!
app.get('/sso/login', passport.authenticate('saml'));

// SECURE: SSO-only authentication
passport.use('saml', samlStrategy);

// No local authentication route
app.get('/login', (req, res) => {
  res.redirect('/sso/login');  // Always use SSO
});

// SECURE: If local auth is required (e.g., service accounts), restrict it
app.post('/api/service-auth', async (req, res) => {
  // Only allow for specific service account purposes
  const { serviceKey, serviceSecret } = req.body;

  if (!isValidServiceAccount(serviceKey, serviceSecret)) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  // Log service account usage
  logger.info({
    action: 'SERVICE_ACCOUNT_AUTH',
    serviceKey,
    ip: req.ip
  });

  // Issue limited-scope token
  const token = jwt.sign(
    { type: 'service', serviceKey },
    secret,
    { expiresIn: '1h' }
  );
  res.json({ token });
});
```

**Finding Template:**
```markdown
**FED-06: Local Authentication Bypassing SSO**
**Severity:** HIGH
**Confidence:** MEDIUM

- **Category:** Federation Security / CWE-287
- **Location:** {file}:{line}
- **Issue:** Local username/password authentication alongside SSO
- **Impact:** Users can bypass SSO controls and MFA
- **Remediation:** Remove local auth or restrict to service accounts only
```

---

## Detection Summary

| Issue | Grep Pattern | Severity |
|-------|-------------|----------|
| No SAML signature | `wantAssertionsSigned.*false` | CRITICAL |
| No issuer validation | `jwt.verify` without `issuer` option | CRITICAL |
| No audience validation | `jwt.verify` without `audience` option | CRITICAL |
| Using jwt.decode() | `jwt.decode\(` for auth decisions | CRITICAL |
| No state parameter | OAuth authorize without `state=` | HIGH |
| No nonce (OIDC) | OIDC flow without `nonce=` | HIGH |
| Local auth with SSO | `LocalStrategy` alongside `SamlStrategy` | HIGH |

---

## References

- AIG Federation and SSO Standards
- [OWASP Authentication Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html)
- [OWASP SAML Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/SAML_Security_Cheat_Sheet.html)
- [OAuth 2.0 Security Best Practices](https://datatracker.ietf.org/doc/html/draft-ietf-oauth-security-topics)
- [OpenID Connect Security](https://openid.net/specs/openid-connect-core-1_0.html#Security)
