# OWASP Top 10 (2021) Security Checklist

Reference checklist for code-security-reviewer agent.

This checklist provides comprehensive detection patterns for the OWASP Top 10 vulnerabilities with:
- Detection grep patterns
- Vulnerable code examples
- Secure code patterns
- CWE mappings
- Finding templates

---

## Quick Reference - OWASP Top 10

| Category | Risk | Detection Difficulty | CWE Examples |
|----------|------|---------------------|--------------|
| A01 Broken Access Control | User accesses unauthorized resources | LOW (needs context) | CWE-639, CWE-862, CWE-269 |
| A02 Cryptographic Failures | Sensitive data exposed | MEDIUM (pattern match) | CWE-327, CWE-328, CWE-798 |
| A03 Injection | Malicious input executed | MEDIUM-HIGH (pattern match) | CWE-79, CWE-89, CWE-78 |
| A04 Insecure Design | Flawed architecture | LOW (needs design review) | CWE-362, CWE-841 |
| A05 Security Misconfiguration | Insecure settings | HIGH (config scan) | CWE-16, CWE-200 |
| A06 Vulnerable Components | Known CVEs in dependencies | HIGH (automated) | CWE-1104 |
| A07 Auth Failures | Broken authentication | MEDIUM (pattern match) | CWE-287, CWE-384, CWE-613 |
| A08 Data Integrity Failures | Untrusted deserialization | LOW (needs context) | CWE-502, CWE-829 |
| A09 Logging Failures | Missing/insecure logging | LOW (needs review) | CWE-778, CWE-532 |
| A10 SSRF | Internal network access | MEDIUM (pattern match) | CWE-918 |

---

## A01:2021 - Broken Access Control

**Risk:** Users access data or perform actions outside their permissions.

### Detection Patterns

```bash
# Horizontal Privilege Escalation (IDOR)
Grep: "params.id|params.userId|params.resourceId"
Grep: "findById|getById|findOne.*id"
Grep: "req.body.id|req.body.userId"

# Vertical Privilege Escalation
Grep: "req.body.role|req.body.isAdmin|req.body.permissions"
Grep: "role.*=.*req|isAdmin.*=.*req"
Grep: "Object.assign.*req.body|spread.*req.body"

# Missing Authorization
Grep: "app.get|app.post|router.get|router.post"
# Check for absence of: authMiddleware, @Authorized, @UseGuards
Grep: "@Public|@SkipAuth|@AllowAnonymous"
```

### A01-01: Horizontal Privilege Escalation (IDOR)

**Severity:** CRITICAL | **CWE:** CWE-639

```typescript
// VULNERABLE: No ownership check
async getDocument(req: Request) {
  const doc = await Document.findById(req.params.id);
  return doc;  // Any user can access any document
}

// SECURE: Ownership validation
async getDocument(req: Request) {
  const doc = await Document.findById(req.params.id);
  if (doc.ownerId !== req.user.id) {
    throw new ForbiddenError('Access denied');
  }
  return doc;
}
```

**Finding Template:**
```markdown
**A01-IDOR-001: Horizontal Privilege Escalation**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** A01:2021 - Broken Access Control / CWE-639
- **Location:** {file}:{line}
- **Issue:** Resource accessed by ID without ownership validation
- **Impact:** Any authenticated user can access any user's data
- **PoC:** `GET /api/resources/{other-user-id}` with valid token
- **Remediation:** Add ownership check before returning resource
```

### A01-02: Vertical Privilege Escalation

**Severity:** CRITICAL | **CWE:** CWE-269

```typescript
// VULNERABLE: Role from client input
async updateUser(req: Request) {
  await User.updateOne(
    { _id: req.user.id },
    { $set: req.body }  // Can include { isAdmin: true }
  );
}

// SECURE: Whitelist allowed fields
async updateUser(req: Request) {
  const allowedFields = ['name', 'email', 'avatar'];
  const updates = pick(req.body, allowedFields);
  await User.updateOne({ _id: req.user.id }, { $set: updates });
}
```

### A01-03: Missing Function-Level Access Control

**Severity:** CRITICAL | **CWE:** CWE-862

```typescript
// VULNERABLE: Admin endpoint without auth
router.get('/admin/users', getAllUsers);  // No middleware!

// SECURE: Proper middleware chain
router.get('/admin/users', authMiddleware, adminOnly, getAllUsers);
```

---

## A02:2021 - Cryptographic Failures

**Risk:** Sensitive data exposed due to weak or missing cryptography.

### Detection Patterns

```bash
# Weak Hashing Algorithms
Grep: "createHash.*md5|createHash.*sha1"
Grep: "MD5|SHA1|sha1|md5"
Grep: "crypto.createHash\\(['\"]md5|crypto.createHash\\(['\"]sha1"

# Hardcoded Secrets
Grep: "password.*=.*['\"][^'\"]+['\"]"
Grep: "secret.*=.*['\"][^'\"]+['\"]"
Grep: "api[_-]?key.*=.*['\"][^'\"]+['\"]"
Grep: "AWS_SECRET|PRIVATE_KEY|JWT_SECRET"

# Weak Encryption
Grep: "createCipheriv.*ecb|aes-.*-ecb"
Grep: "DES|3DES|RC4|Blowfish"

# Insecure Random
Grep: "Math.random\\(\\)"
Grep: "Date.now\\(\\).*token|Date.now\\(\\).*id"
```

### A02-01: Weak Hashing for Passwords

**Severity:** CRITICAL | **CWE:** CWE-328

```typescript
// VULNERABLE: MD5/SHA1 for passwords
const hash = crypto.createHash('md5').update(password).digest('hex');

// SECURE: bcrypt with proper work factor
const hash = await bcrypt.hash(password, 12);
```

### A02-02: Hardcoded Secrets

**Severity:** CRITICAL | **CWE:** CWE-798

```typescript
// VULNERABLE: Hardcoded secrets
const JWT_SECRET = 'my-super-secret-key-123';
const dbPassword = 'admin123';

// SECURE: Environment variables or secrets manager
const JWT_SECRET = process.env.JWT_SECRET;
const dbPassword = await vault.getSecret('database/credentials');
```

### A02-03: Insecure Random Number Generation

**Severity:** CRITICAL | **CWE:** CWE-338

```typescript
// VULNERABLE: Math.random() for security tokens
const token = Math.random().toString(36).substring(2);
const sessionId = Date.now().toString();

// SECURE: Cryptographic randomness
const token = crypto.randomBytes(32).toString('hex');
const sessionId = crypto.randomUUID();
```

---

## A03:2021 - Injection

**Risk:** Untrusted data sent to interpreter as part of command or query.

### Detection Patterns

```bash
# SQL Injection
Grep: "query\\(.*\\$\\{|query\\(.*\\+.*req"
Grep: "SELECT.*\\$\\{|INSERT.*\\$\\{|UPDATE.*\\$\\{|DELETE.*\\$\\{"
Grep: "db.query\\(.*\\+|execute\\(.*\\+"

# NoSQL Injection
Grep: "find\\(.*req.body|findOne\\(.*req.body"
Grep: "\\$where|\\$regex.*req|\\$gt.*req|\\$ne.*req"

# Command Injection
Grep: "exec\\(.*req|spawn\\(.*req|execSync\\(.*req"
Grep: "child_process.*req|shell.*req"

# XSS
Grep: "innerHTML.*=|outerHTML.*=|document.write"
Grep: "dangerouslySetInnerHTML"
Grep: "v-html.*=|\\[innerHTML\\]"

# Template Injection
Grep: "eval\\(|new Function\\(|setTimeout\\(.*req"
Grep: "vm.runInContext|vm.createScript"
```

### A03-01: SQL Injection

**Severity:** CRITICAL | **CWE:** CWE-89

```typescript
// VULNERABLE: String concatenation
const query = `SELECT * FROM users WHERE id = ${userId}`;
const result = await db.query(query);

// Also vulnerable: Template literals
const result = await db.query(`SELECT * FROM users WHERE name = '${name}'`);

// SECURE: Parameterized queries
const result = await db.query('SELECT * FROM users WHERE id = $1', [userId]);

// SECURE: Query builder with proper escaping
const result = await db('users').where({ id: userId }).first();
```

### A03-02: Command Injection

**Severity:** CRITICAL | **CWE:** CWE-78

```typescript
// VULNERABLE: User input in shell command
const { exec } = require('child_process');
exec(`convert ${req.body.filename} output.png`);

// SECURE: Use array form with no shell
const { execFile } = require('child_process');
execFile('convert', [filename, 'output.png']);

// SECURE: Validate and sanitize input
const allowedChars = /^[a-zA-Z0-9_-]+$/;
if (!allowedChars.test(filename)) {
  throw new ValidationError('Invalid filename');
}
```

### A03-03: Cross-Site Scripting (XSS)

**Severity:** HIGH | **CWE:** CWE-79

```typescript
// VULNERABLE: Direct HTML injection
element.innerHTML = userInput;

// VULNERABLE: React dangerouslySetInnerHTML
<div dangerouslySetInnerHTML={{ __html: userInput }} />

// SECURE: Text content (auto-escaped)
element.textContent = userInput;

// SECURE: Sanitization library
import DOMPurify from 'dompurify';
element.innerHTML = DOMPurify.sanitize(userInput);
```

### A03-04: NoSQL Injection

**Severity:** HIGH | **CWE:** CWE-943

```typescript
// VULNERABLE: Object from request body
const user = await User.findOne({ username: req.body.username });
// Attack: { "username": { "$ne": null } } returns first user

// SECURE: Type validation
const username = String(req.body.username);
const user = await User.findOne({ username });

// SECURE: Schema validation with sanitization
const { username } = validateLogin(req.body); // Throws if not string
```

---

## A04:2021 - Insecure Design

**Risk:** Missing or ineffective security controls due to design flaws.

### Detection Patterns

```bash
# Race Conditions (TOCTOU)
Grep: "if.*await.*\\{.*await"
Grep: "getBalance|hasCredits|canPurchase|isAvailable"
Grep: "check.*then|verify.*then"

# State Machine Issues
Grep: "status.*=|state.*="
Grep: "workflow|transition|nextState"

# Missing Rate Limiting
Grep: "login|signin|authenticate|password"
# Check for absence of rate limiting middleware
```

### A04-01: Race Condition (TOCTOU)

**Severity:** HIGH | **CWE:** CWE-362

```typescript
// VULNERABLE: Check-then-act without atomicity
async purchase(userId: string, amount: number) {
  const balance = await getBalance(userId);  // CHECK
  if (balance >= amount) {
    await deductBalance(userId, amount);      // USE (race window)
    await processOrder();
  }
}

// SECURE: Atomic transaction with row locking
async purchase(userId: string, amount: number) {
  await db.transaction(async (tx) => {
    const balance = await tx.query(
      'SELECT balance FROM accounts WHERE user_id = $1 FOR UPDATE',
      [userId]
    );
    if (balance < amount) throw new InsufficientFundsError();
    await tx.query(
      'UPDATE accounts SET balance = balance - $1 WHERE user_id = $2',
      [amount, userId]
    );
  });
}
```

### A04-02: State Machine Bypass

**Severity:** HIGH | **CWE:** CWE-841

```typescript
// VULNERABLE: No state validation
async shipOrder(orderId: string) {
  await Order.update(orderId, { status: 'shipped' });
  // Missing: Check if paid!
}

// SECURE: Validate state transitions
const VALID_TRANSITIONS = {
  'pending': ['paid', 'cancelled'],
  'paid': ['shipped'],
  'shipped': ['delivered'],
};

async updateStatus(orderId: string, newStatus: string) {
  const order = await Order.findById(orderId);
  if (!VALID_TRANSITIONS[order.status]?.includes(newStatus)) {
    throw new InvalidTransitionError();
  }
  await Order.update(orderId, { status: newStatus });
}
```

---

## A05:2021 - Security Misconfiguration

**Risk:** Insecure default configurations, incomplete setup, or overly permissive settings.

### Detection Patterns

```bash
# Debug/Development Mode
Grep: "DEBUG.*=.*true|NODE_ENV.*development"
Grep: "console.log\\(.*password|console.log\\(.*secret"
Grep: "stack.*trace|error.*stack"

# CORS Misconfiguration
Grep: "Access-Control-Allow-Origin.*\\*"
Grep: "cors\\(\\)|cors\\(\\{\\s*\\}\\)"
Grep: "origin.*true|origin.*\\*"

# Default Credentials
Grep: "admin.*admin|password.*password|root.*root"
Grep: "default.*password|test.*credential"

# Verbose Error Messages
Grep: "res.send\\(.*error|res.json\\(.*error"
Grep: "catch.*res.send\\(err|catch.*res.json\\(err"
```

### A05-01: Verbose Error Exposure

**Severity:** MEDIUM | **CWE:** CWE-209

```typescript
// VULNERABLE: Stack trace exposed
app.use((err, req, res, next) => {
  res.status(500).json({
    error: err.message,
    stack: err.stack  // Exposes internal details
  });
});

// SECURE: Generic error for production
app.use((err, req, res, next) => {
  logger.error(err);  // Log full error internally
  res.status(500).json({
    error: 'An unexpected error occurred',
    requestId: req.id  // For correlation, not debugging
  });
});
```

### A05-02: Overly Permissive CORS

**Severity:** MEDIUM | **CWE:** CWE-942

```typescript
// VULNERABLE: Allow all origins
app.use(cors({ origin: '*' }));
app.use(cors({ origin: true }));

// SECURE: Whitelist specific origins
const allowedOrigins = ['https://myapp.com', 'https://admin.myapp.com'];
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('CORS not allowed'));
    }
  },
  credentials: true
}));
```

---

## A06:2021 - Vulnerable and Outdated Components

**Risk:** Using components with known vulnerabilities.

### Detection Patterns

```bash
# Run automated tools
npm audit --json
npm outdated --json
snyk test

# Check for known vulnerable patterns
Grep: "lodash.*4\\.17\\.[0-9]|lodash.*[<4]"  # Prototype pollution
Grep: "axios.*0\\.[0-9]\\.|axios.*0\\.1[0-8]"  # SSRF
Grep: "express.*[<4]\\.17"
```

### A06-01: Vulnerable Dependencies

**Severity:** Varies (CRITICAL to LOW) | **CWE:** CWE-1104

**Detection:** Use `npm audit`, Snyk, or OWASP Dependency-Check

**Common Vulnerable Packages:**
| Package | Vulnerability | Fixed Version |
|---------|--------------|---------------|
| lodash < 4.17.21 | Prototype Pollution | 4.17.21+ |
| axios < 0.21.1 | SSRF | 0.21.1+ |
| minimist < 1.2.6 | Prototype Pollution | 1.2.6+ |
| express < 4.17.3 | Open Redirect | 4.17.3+ |

---

## A07:2021 - Identification and Authentication Failures

**Risk:** Broken authentication allows attackers to compromise credentials or sessions.

### Detection Patterns

```bash
# JWT Issues
Grep: "jwt.verify\\(.*\\)|jsonwebtoken.*verify"
# Check for missing algorithms array
Grep: "jwt.decode\\("
Grep: "localStorage.*token|sessionStorage.*token"

# Session Issues
Grep: "session.*secret|cookie.*secret"
Grep: "secure.*false|httpOnly.*false"

# Password Issues
Grep: "password.*length.*[<6]|minLength.*[<8]"
Grep: "bcrypt.*rounds.*[<10]|saltRounds.*[<10]"
```

### A07-01: JWT Algorithm Confusion

**Severity:** CRITICAL | **CWE:** CWE-347

```typescript
// VULNERABLE: No algorithm restriction
const decoded = jwt.verify(token, secret);  // Accepts 'none' algorithm!

// VULNERABLE: Using decode() for auth decisions
const payload = jwt.decode(token);
if (payload.role === 'admin') { ... }  // No signature verification!

// SECURE: Explicit algorithm whitelist
const decoded = jwt.verify(token, secret, { algorithms: ['HS256'] });
```

### A07-02: Insecure Session Configuration

**Severity:** HIGH | **CWE:** CWE-614

```typescript
// VULNERABLE: Insecure cookie settings
app.use(session({
  secret: 'keyboard cat',  // Weak secret
  cookie: { secure: false, httpOnly: false }
}));

// SECURE: Proper session configuration
app.use(session({
  secret: process.env.SESSION_SECRET,  // Strong, from env
  cookie: {
    secure: true,       // HTTPS only
    httpOnly: true,     // No JavaScript access
    sameSite: 'strict', // CSRF protection
    maxAge: 3600000     // 1 hour expiry
  },
  resave: false,
  saveUninitialized: false
}));
```

### A07-03: Weak Password Policy

**Severity:** MEDIUM | **CWE:** CWE-521

```typescript
// VULNERABLE: No password requirements
if (password.length > 0) {
  await createUser(username, password);
}

// SECURE: Strong password validation
const passwordSchema = {
  minLength: 12,
  requireUppercase: true,
  requireLowercase: true,
  requireNumbers: true,
  requireSymbols: true,
  rejectCommon: true  // Check against known passwords
};

if (!validatePassword(password, passwordSchema)) {
  throw new WeakPasswordError();
}
```

---

### A07 Enterprise Threshold Values

Reference values for enterprise session management, account lockout, and password policies.

| Control | Standard Value | Detection Severity |
|---------|---------------|-------------------|
| Max session duration | 60 minutes | HIGH if exceeded |
| Idle timeout | 15 minutes | HIGH if exceeded |
| Remote re-auth | 12 hours | MEDIUM if exceeded |
| Failed login attempts | 6 attempts | HIGH if exceeded |
| Lockout duration | 30 minutes | HIGH if less |
| Human password length | 8 characters | MEDIUM if less |
| Non-human password length | 24 characters | HIGH if less |
| Password history | 13 previous | MEDIUM if less |
| Human password rotation | 90 days | MEDIUM if exceeded |
| Non-human password rotation | 365 days | LOW if exceeded |

### A07-04: Session Management Detection

**Detection Patterns:**
```bash
# Session Duration (should be <= 60 min)
Grep: "maxAge|expires|timeout"
Grep: "session.*duration|cookie.*max"
Grep: "expiresIn.*['\"]\\d+[hd]|expiresIn.*\\d{5,}"

# Idle Timeout (should be <= 15 min)
Grep: "idle.*timeout|inactivity.*timeout"
Grep: "rolling.*session|touch.*session"
```

**Vulnerable Patterns:**
```typescript
// VULNERABLE: Session too long (> 60 min)
app.use(session({
  cookie: { maxAge: 86400000 }  // 24 hours - exceeds 60 min limit
}));

jwt.sign(payload, secret, { expiresIn: '7d' });  // 7 days - exceeds limit

// SECURE: Compliant session duration
app.use(session({
  cookie: { maxAge: 3600000 }  // 60 minutes
}));

jwt.sign(payload, secret, { expiresIn: '1h' });  // 1 hour
```

### A07-05: Account Lockout Detection

**Detection Patterns:**
```bash
# Failed Attempt Threshold (should be <= 6)
Grep: "failedAttempts|loginAttempts|maxAttempts"
Grep: "attemptLimit|maxRetries"

# Lockout Duration (should be >= 30 min)
Grep: "lockout.*duration|lock.*time|lockoutPeriod"
Grep: "accountLock|isLocked|lockedUntil"
```

**Vulnerable Patterns:**
```typescript
// VULNERABLE: Too many attempts allowed (> 6)
const MAX_LOGIN_ATTEMPTS = 10;  // Exceeds 6 attempt limit

// VULNERABLE: Lockout too short (< 30 min)
const LOCKOUT_DURATION = 5 * 60 * 1000;  // 5 minutes - below 30 min

// VULNERABLE: Missing lockout implementation
async login(username, password) {
  const user = await User.findOne({ username });
  if (!await bcrypt.compare(password, user.hash)) {
    throw new UnauthorizedError();  // No attempt tracking!
  }
}

// SECURE: Compliant lockout policy
const MAX_LOGIN_ATTEMPTS = 6;
const LOCKOUT_DURATION = 30 * 60 * 1000;  // 30 minutes

async login(username, password) {
  const user = await User.findOne({ username });

  if (user.lockedUntil && user.lockedUntil > Date.now()) {
    throw new AccountLockedError();
  }

  if (!await bcrypt.compare(password, user.hash)) {
    user.failedAttempts = (user.failedAttempts || 0) + 1;
    if (user.failedAttempts >= MAX_LOGIN_ATTEMPTS) {
      user.lockedUntil = Date.now() + LOCKOUT_DURATION;
    }
    await user.save();
    throw new UnauthorizedError();
  }

  user.failedAttempts = 0;
  await user.save();
}
```

### A07-06: Password Policy Detection

**Detection Patterns:**
```bash
# Password Length (human >= 8, non-human >= 24)
Grep: "password.*length|minLength|maxLength"
Grep: "passwordValidator|passwordPolicy"

# Password History (should check >= 13 previous)
Grep: "passwordHistory|previousPasswords|oldPasswords"
Grep: "historyCount|passwordHistoryLength"

# Password Rotation (human <= 90 days, non-human <= 365 days)
Grep: "password.*expir|password.*rotation|passwordAge"
Grep: "lastPasswordChange|passwordChangedAt"
```

**Vulnerable Patterns:**
```typescript
// VULNERABLE: Password too short (< 8 for human)
const passwordSchema = z.string().min(4);  // Below 8 char minimum

// VULNERABLE: Service account password too short (< 24)
const servicePassword = 'MyServicePwd123!';  // 16 chars, needs 24

// VULNERABLE: Insufficient password history (< 13)
const PASSWORD_HISTORY_LENGTH = 5;  // Below 13 requirement

// VULNERABLE: Password expiration too long (> 90 days human)
const PASSWORD_EXPIRY_DAYS = 180;  // Exceeds 90 day limit

// SECURE: Compliant password policy
const humanPasswordSchema = z.string()
  .min(8)
  .regex(/[A-Z]/)
  .regex(/[a-z]/)
  .regex(/[0-9]/)
  .regex(/[!@#$%^&*]/);

const PASSWORD_HISTORY_LENGTH = 13;
const PASSWORD_EXPIRY_DAYS = 90;

async changePassword(userId, newPassword) {
  const history = await PasswordHistory.find({ userId }).limit(13);
  for (const old of history) {
    if (await bcrypt.compare(newPassword, old.hash)) {
      throw new PasswordReuseError('Cannot reuse last 13 passwords');
    }
  }
}
```

---

## A08:2021 - Software and Data Integrity Failures

**Risk:** Code or data integrity not verified, allowing tampering.

### Detection Patterns

```bash
# Insecure Deserialization
Grep: "JSON.parse\\(.*req|deserialize\\(.*req"
Grep: "unserialize|pickle.loads|yaml.load\\("
Grep: "eval\\(.*JSON|new Function\\(.*JSON"

# Missing Integrity Checks
Grep: "require\\(.*user|import\\(.*user"
Grep: "npm install.*--ignore-scripts"

# CI/CD Issues
Grep: "npm publish|docker push"
# Check for missing integrity verification
```

### A08-01: Insecure Deserialization

**Severity:** CRITICAL | **CWE:** CWE-502

```typescript
// VULNERABLE: Deserializing untrusted data
const data = JSON.parse(req.body.serializedData);
Object.assign(targetObject, data);  // Can pollute prototype

// VULNERABLE: eval-based deserialization
const config = eval('(' + configString + ')');

// SECURE: Schema validation after parsing
const parsed = JSON.parse(req.body.data);
const validated = schema.validate(parsed);  // Joi, Zod, etc.
if (validated.error) throw new ValidationError();
```

### A08-02: Prototype Pollution

**Severity:** HIGH | **CWE:** CWE-1321

```typescript
// VULNERABLE: Deep merge with user input
function deepMerge(target, source) {
  for (const key in source) {
    target[key] = source[key];  // Can set __proto__
  }
}

// SECURE: Check for dangerous keys
function safeMerge(target, source) {
  const dangerous = ['__proto__', 'constructor', 'prototype'];
  for (const key in source) {
    if (dangerous.includes(key)) continue;
    target[key] = source[key];
  }
}
```

---

## A09:2021 - Security Logging and Monitoring Failures

**Risk:** Insufficient logging prevents detection of breaches.

### Detection Patterns

```bash
# Missing Audit Logging
Grep: "login|authenticate|authorize"
# Check for absence of logging calls nearby

# Sensitive Data in Logs
Grep: "console.log.*password|logger.*password"
Grep: "log.*token|log.*secret|log.*key"

# Missing Error Logging
Grep: "catch\\s*\\(|catch\\s*\\{"
# Check for empty catch blocks or missing logging
```

### A09-01: Missing Security Event Logging

**Severity:** MEDIUM | **CWE:** CWE-778

```typescript
// VULNERABLE: No logging of security events
async login(username: string, password: string) {
  const user = await User.findByUsername(username);
  if (!user || !await bcrypt.compare(password, user.hash)) {
    throw new UnauthorizedError();  // No logging!
  }
  return createSession(user);
}

// SECURE: Comprehensive security logging
async login(username: string, password: string) {
  const user = await User.findByUsername(username);
  if (!user) {
    logger.warn('Login failed: unknown user', { username, ip: req.ip });
    throw new UnauthorizedError();
  }
  if (!await bcrypt.compare(password, user.hash)) {
    logger.warn('Login failed: invalid password', { userId: user.id, ip: req.ip });
    throw new UnauthorizedError();
  }
  logger.info('Login successful', { userId: user.id, ip: req.ip });
  return createSession(user);
}
```

### A09-02: Sensitive Data in Logs

**Severity:** HIGH | **CWE:** CWE-532

```typescript
// VULNERABLE: Logging sensitive data
logger.info('User login', { username, password });
logger.debug('API request', { headers: req.headers });  // Contains auth token

// SECURE: Redact sensitive fields
const sanitizeLog = (obj) => {
  const sensitive = ['password', 'token', 'secret', 'authorization'];
  const sanitized = { ...obj };
  for (const key of sensitive) {
    if (sanitized[key]) sanitized[key] = '[REDACTED]';
  }
  return sanitized;
};

logger.info('User login', sanitizeLog({ username, password }));
```

---

## A10:2021 - Server-Side Request Forgery (SSRF)

**Risk:** Server makes requests to attacker-controlled URLs, accessing internal resources.

### Detection Patterns

```bash
# URL from User Input
Grep: "fetch\\(.*req|axios\\(.*req|request\\(.*req"
Grep: "http.get\\(.*req|https.get\\(.*req"
Grep: "new URL\\(.*req|url.parse\\(.*req"

# URL Manipulation
Grep: "redirect.*req|location.*req"
Grep: "image.*url|file.*url|download.*url"
```

### A10-01: Basic SSRF

**Severity:** HIGH | **CWE:** CWE-918

```typescript
// VULNERABLE: Fetching user-provided URL
app.post('/fetch', async (req, res) => {
  const response = await fetch(req.body.url);
  res.send(await response.text());
});
// Attack: { "url": "http://169.254.169.254/latest/meta-data/" }

// SECURE: URL validation and whitelist
const ALLOWED_HOSTS = ['api.example.com', 'cdn.example.com'];

app.post('/fetch', async (req, res) => {
  const url = new URL(req.body.url);

  // Block internal IPs
  if (isPrivateIP(url.hostname)) {
    throw new ForbiddenError('Internal URLs not allowed');
  }

  // Whitelist hosts
  if (!ALLOWED_HOSTS.includes(url.hostname)) {
    throw new ForbiddenError('Host not allowed');
  }

  // Only allow HTTPS
  if (url.protocol !== 'https:') {
    throw new ForbiddenError('Only HTTPS allowed');
  }

  const response = await fetch(url.toString());
  res.send(await response.text());
});

// Helper: Check for private/internal IPs
function isPrivateIP(hostname: string): boolean {
  const ip = dns.lookup(hostname);
  return (
    ip.startsWith('10.') ||
    ip.startsWith('172.16.') ||
    ip.startsWith('192.168.') ||
    ip.startsWith('127.') ||
    ip === 'localhost' ||
    ip.startsWith('169.254.')  // AWS metadata
  );
}
```

---

## OWASP Top 10 Detection Summary

### Code Review Grep Patterns

```bash
# A01: Broken Access Control
Grep: "params.id|params.userId" # Check for ownership validation
Grep: "req.body.role|req.body.isAdmin" # Privilege escalation

# A02: Cryptographic Failures
Grep: "createHash.*md5|createHash.*sha1|Math.random"

# A03: Injection
Grep: "query.*\\$\\{|exec\\(.*req|innerHTML.*="

# A04: Insecure Design
Grep: "if.*await.*\\{.*await" # Race conditions

# A05: Security Misconfiguration
Grep: "cors\\(\\)|DEBUG.*true|stack.*trace"

# A06: Vulnerable Components
# Run: npm audit --json

# A07: Authentication Failures
Grep: "jwt.verify\\(|jwt.decode\\(|localStorage.*token"

# A08: Data Integrity Failures
Grep: "JSON.parse.*req|deserialize|__proto__"

# A09: Logging Failures
Grep: "console.log.*password|logger.*secret"

# A10: SSRF
Grep: "fetch\\(.*req|axios\\(.*req.body"
```

### Severity by Category

| Severity | Categories |
|----------|------------|
| **CRITICAL** | A01 (auth bypass), A02 (secrets), A03 (injection), A07 (JWT), A08 (deser) |
| **HIGH** | A01 (IDOR), A04 (race), A05 (debug), A09 (log secrets), A10 (SSRF) |
| **MEDIUM** | A05 (CORS), A07 (session), A09 (missing logs) |

---

## References

- [OWASP Top 10:2021](https://owasp.org/Top10/)
- [CWE Top 25](https://cwe.mitre.org/top25/)
- [OWASP Testing Guide](https://owasp.org/www-project-web-security-testing-guide/)
- [OWASP Cheat Sheet Series](https://cheatsheetseries.owasp.org/)
