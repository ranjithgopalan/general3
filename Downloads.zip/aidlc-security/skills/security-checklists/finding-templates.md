# Security Finding Templates and Standards

This skill provides standardized templates, confidence levels, severity definitions, and RP classification rules for all security reviewers to ensure consistent finding format.

## Purpose

- Single source of truth for finding standards
- Ensures all reviewers use consistent format
- Defines confidence levels and severity criteria
- Provides RP (Risk Priority) classification rules

---

## Confidence Levels

**All findings MUST include a confidence level to help users prioritize verification efforts.**

| Level | Criteria | Evidence Required | Verification Priority |
|-------|----------|-------------------|----------------------|
| **HIGH** | Clear code evidence + known vulnerability pattern | Exact code snippet showing vulnerability, known CVE/CWE pattern match | Verify first - high likelihood of true positive |
| **MEDIUM** | Pattern detected but context unclear | Code snippet present but missing runtime context or configuration details | Verify second - requires additional context |
| **LOW** | Unusual pattern that may have mitigating factors | Code snippet with potential mitigations observed | Verify last - may be false positive |

### HIGH Confidence Criteria
- Known vulnerability pattern (e.g., SQL injection, XSS, auth bypass)
- Code snippet clearly shows vulnerable behavior
- No visible mitigations in the reviewed code
- Matches established CWE/OWASP patterns
- Direct evidence of exploitability

### MEDIUM Confidence Criteria
- Vulnerability pattern detected
- Missing context (e.g., can't see if validation happens elsewhere)
- Possible mitigations not visible in current scope
- Requires cross-file analysis to confirm

### LOW Confidence Criteria
- Unusual pattern that suggests risk
- Potential mitigations partially visible
- Context suggests it may be safe
- Edge case or rare condition

---

## Severity Definitions

| Severity | Criteria | Impact | Action Timeline |
|----------|----------|--------|-----------------|
| **CRITICAL** | Data breach, authentication bypass, RCE, full system compromise | Immediate exploitability, direct access to sensitive data | 24-48 hours |
| **HIGH** | Significant security impact, privilege escalation, SQL injection | Exploitable with moderate effort, affects multiple users | 1 week |
| **MEDIUM** | Limited scope vulnerability, XSS, CSRF, information disclosure | Exploitable but limited impact or requires conditions | 1 sprint (2-4 weeks) |
| **LOW** | Defense in depth, best practice violations, minor information leaks | Low exploitability or minimal impact | Backlog |

### Severity Assignment Rules

**CRITICAL:**
- Authentication/authorization complete bypass
- Remote code execution (RCE)
- Direct database access without authentication
- Hardcoded credentials for production systems
- Full PII/PHI data exposure

**HIGH:**
- Vertical privilege escalation (user → admin)
- Horizontal privilege escalation (IDOR)
- SQL injection, command injection
- Insecure deserialization leading to RCE
- Missing encryption for sensitive data in transit

**MEDIUM:**
- Cross-site scripting (XSS)
- Cross-site request forgery (CSRF)
- Missing rate limiting on sensitive endpoints
- Weak password policies
- Information disclosure (internal paths, versions)

**LOW:**
- Missing HTTPS headers (HSTS, CSP)
- Verbose error messages in development
- Missing logging/monitoring
- Outdated dependencies without known exploits

---

## RP (Risk Priority) Classification

Enterprise standard for remediation timelines based on severity, exposure, and exploitability.

### RP Levels

| RP Level | Timeline | Criteria |
|----------|----------|----------|
| **RP1** | 24 hours - 7 days (Emergency) | CRITICAL severity + External exposure + Active exploitation or public PoC |
| **RP2** | 14 days (Urgent) | CRITICAL or HIGH severity + External exposure |
| **RP3** | 30 days (Priority) | HIGH severity (any exposure) |
| **RP4** | 60 days (Scheduled) | MEDIUM severity + External exposure |
| **RP5** | 90 days (Planned) | MEDIUM severity + Internal only |
| **RP6** | 180 days (Backlog) | LOW severity (any exposure) |
| **RP7** | 360 days (Informational) | Informational findings, best practices |

### RP Classification Logic

```
IF (severity == CRITICAL && external_exposure == true && (active_exploit || public_poc)) THEN RP1
ELSE IF (severity == CRITICAL && external_exposure == true) THEN RP2
ELSE IF (severity == CRITICAL && external_exposure == false) THEN RP2
ELSE IF (severity == HIGH) THEN RP3
ELSE IF (severity == MEDIUM && external_exposure == true) THEN RP4
ELSE IF (severity == MEDIUM && external_exposure == false) THEN RP5
ELSE IF (severity == LOW) THEN RP6
ELSE RP7
```

### External Exposure Definition

**External (internet-facing):**
- Public web applications
- Public APIs
- Mobile app backends
- Any service accessible outside corporate network

**Internal:**
- Private APIs behind VPN
- Internal microservices
- Database servers (not exposed)
- Admin panels on internal network only

---

## Finding Template Format

Every security finding MUST use this exact format:

```markdown
**{TYPE}-{ID}: {Vulnerability Title}**

| Attribute | Value |
|-----------|-------|
| **Severity** | CRITICAL / HIGH / MEDIUM / LOW |
| **Confidence** | HIGH / MEDIUM / LOW |
| **Category** | {OWASP Category} / CWE-{ID} |
| **Location** | {file_path}:{line_numbers} |
| **RP Level** | RP1 / RP2 / RP3 / RP4 / RP5 / RP6 / RP7 |

**Code Snippet:**
```{language}
{Exact vulnerable code from the file - at least 5 lines for context}
```

**Context Analysis:**
{What this code does and why it creates a vulnerability. Include:
- Function purpose
- Data flow
- Missing security controls
- Attack surface}

**Mitigations Checked:**
- [ ] {Mitigation 1} - Not found
- [ ] {Mitigation 2} - Not found
- [x] {Mitigation 3} - Found but insufficient (if applicable)

**Confidence Justification:**
{Detailed explanation of why this confidence level was assigned:
- For HIGH: "Clear {pattern} with no visible mitigations - {explain specific evidence}"
- For MEDIUM: "Pattern detected but {explain what context is missing}"
- For LOW: "Unusual pattern but {explain potential mitigating factors}"}

**Proof of Concept:**
```
{Request/response example or step-by-step exploitation instructions}

Example:
1. POST /api/users/123 with body: {"role": "admin"}
2. User 123 becomes admin without authorization check
3. Access /admin/users to confirm privilege escalation
```

**Remediation:**
```{language}
{Secure code fix with explanation}

// Add authorization check before update
async updateUser(req: Request) {
  const userId = req.params.id;

  // NEW: Verify ownership
  if (req.user.id !== userId && req.user.role !== 'admin') {
    throw new ForbiddenError('Cannot update other users');
  }

  // NEW: Whitelist allowed fields
  const allowedFields = ['name', 'email', 'phone'];
  const data = pick(req.body, allowedFields);

  await UserService.update(userId, data);
  res.json({ success: true });
}
```

**Why SAST/DAST Misses This:**
{Specific explanation of why automated tools cannot detect this vulnerability:
- SAST: "Static analysis sees findById() call but cannot determine if ownership is checked elsewhere"
- DAST: "Dynamic scanning would need valid tokens for multiple users and business logic understanding to test horizontal escalation"
- Business Logic: "Requires understanding that users should only update their own profiles"}
```

---

## Finding Type Codes

Use consistent type codes for finding IDs:

| Code | Meaning | Example |
|------|---------|---------|
| **A01** | OWASP A01 Broken Access Control | A01-IDOR-001 |
| **A02** | OWASP A02 Cryptographic Failures | A02-WEAK-HASH-001 |
| **A03** | OWASP A03 Injection | A03-SQL-001 |
| **A04** | OWASP A04 Insecure Design | A04-RACE-001 |
| **A05** | OWASP A05 Security Misconfiguration | A05-DEBUG-001 |
| **A07** | OWASP A07 Auth Failures | A07-JWT-001 |
| **A08** | OWASP A08 Data Integrity Failures | A08-DESER-001 |
| **A09** | OWASP A09 Logging Failures | A09-LOG-001 |
| **A10** | OWASP A10 SSRF | A10-SSRF-001 |
| **CRYPTO** | Cryptographic issues | CRYPTO-WEAK-001 |
| **INFRA** | Infrastructure misconfig | INFRA-IAM-001 |
| **PRIVACY** | Data privacy issues | PRIVACY-PII-001 |
| **BL** | Business Logic | BL-WORKFLOW-001 |

---

## Report Structure

Security review reports should follow this structure:

```markdown
# Security Review Report

**Date:** {YYYY-MM-DD}
**Reviewer:** {Agent Name}
**Scope:** {What was reviewed}
**Accuracy Estimate:** 60-80% (Human verification required)

## Executive Summary

- **Total Findings:** {count}
- **CRITICAL:** {count} | **HIGH:** {count} | **MEDIUM:** {count} | **LOW:** {count}
- **RP1:** {count} | **RP2:** {count} | **RP3:** {count} | **RP4:** {count} | **RP5:** {count} | **RP6:** {count} | **RP7:** {count}

## RP Summary Table

| RP | Count | Timeline | Action Required |
|----|-------|----------|-----------------|
| RP1 | X | 24h-7d | Emergency patching |
| RP2 | X | 14 days | Urgent fix |
| RP3 | X | 30 days | Priority sprint |
| RP4 | X | 60 days | Scheduled release |
| RP5 | X | 90 days | Planned work |
| RP6 | X | 180 days | Backlog |
| RP7 | X | 360 days | Informational |

## Findings

{Findings sorted by RP level (RP1 first), then by confidence (HIGH first)}

{Each finding using the template above}

## OWASP Top 10 Mapping

| OWASP Category | Findings Count |
|----------------|----------------|
| A01 Broken Access Control | {count} |
| A02 Cryptographic Failures | {count} |
| A03 Injection | {count} |
| A04 Insecure Design | {count} |
| A05 Security Misconfiguration | {count} |
| A07 Auth Failures | {count} |
| A08 Data Integrity Failures | {count} |
| A09 Logging Failures | {count} |
| A10 SSRF | {count} |

## Compliance Mapping (if applicable)

| Regulation | Findings | References |
|------------|----------|------------|
| GDPR | {count} | Article 32, 25 |
| CCPA | {count} | Section 1798.150 |
| PCI-DSS | {count} | Requirement 6.5 |
| HIPAA | {count} | §164.312 |

## Remediation Roadmap

### Phase 1: Emergency (RP1) - 24h-7d
{List of RP1 findings with assigned owners}

### Phase 2: Urgent (RP2) - 14 days
{List of RP2 findings}

### Phase 3: Priority (RP3) - 30 days
{List of RP3 findings}

### Phase 4: Scheduled (RP4-RP5) - 60-90 days
{List of RP4-RP5 findings}

### Phase 5: Backlog (RP6-RP7) - 180-360 days
{List of RP6-RP7 findings}

## Professional Penetration Testing Recommendation

**CRITICAL:** This automated review identifies potential vulnerabilities but CANNOT confirm exploitability.

**We strongly recommend:**
1. **Professional penetration testing** by certified security firm
2. **Code review** by security-specialized developers
3. **Vulnerability verification** before production deployment

**Why Professional Testing is Required:**
- Automated reviews have 60-80% accuracy (20-40% false positives/negatives)
- Cannot verify actual exploitability in runtime environment
- Cannot test complex attack chains or business logic thoroughly
- Cannot assess defense-in-depth effectiveness

**Recommended Next Steps:**
1. Prioritize findings by RP level
2. Verify HIGH confidence findings first
3. Engage professional pentest firm for comprehensive assessment
4. Implement fixes based on verification results

## Human-in-the-Loop (HITL) Disclaimer

⚠️ **IMPORTANT:** This review is performed by an AI security reviewer and requires human verification.

- **Accuracy:** Estimated 60-80% - false positives and false negatives are possible
- **Coverage:** Focuses on patterns that SAST/DAST miss - not a replacement for automated scanning
- **Verification:** All findings should be verified by security professionals
- **Exploitation:** Proof of concepts are theoretical - actual exploitation may differ
- **Production:** Never deploy to production based solely on this review

## Additional Recommendations

{Context-specific recommendations for:
- Security training needs
- Tool procurement (SAST/DAST/SCA)
- Process improvements
- Architecture changes}
```

---

## Usage by Agents

All security reviewer agents should:

1. **Reference this skill** instead of embedding templates
2. **Use consistent finding format** from this template
3. **Apply confidence levels** using defined criteria
4. **Calculate RP levels** using the classification logic
5. **Generate reports** following the structure above

### Example Agent Usage

```markdown
## Findings Format

For detailed finding template, confidence levels, severity definitions, and RP classification:
**Reference:** skills/security-checklists/finding-templates.md

Use the standardized template for EVERY finding to ensure consistency across all security reviews.
```

---

## Version History

- **v1.0.0** (2026-01-12): Initial creation for Phase 2 optimization
  - Extracted from multiple agents to eliminate duplication
  - Standardized confidence levels and severity definitions
  - Added RP classification rules
  - Defined complete finding template format
