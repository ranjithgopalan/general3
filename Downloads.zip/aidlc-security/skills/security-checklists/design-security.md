# Design Security Checklist

Reference checklist for design-security-reviewer agent.

---

## Authentication Design

### MFA (Multi-Factor Authentication)
- **Check:** Is MFA considered for sensitive operations?
- **Risk if missing:** Account takeover attacks
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Authentication
  - Primary: Username/password
  - Secondary: TOTP or SMS verification for:
    - Initial login from new device
    - Password changes
    - High-value transactions
  ```

### Session Management
- **Check:** Session lifecycle defined?
- **Risk if missing:** Session hijacking, fixation
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Session Management
  - Session timeout: 30 minutes idle
  - Absolute timeout: 8 hours
  - Regenerate session ID on authentication
  - Invalidate on logout
  - HttpOnly, Secure, SameSite cookies
  ```

### Token Lifecycle
- **Check:** Token expiration and refresh strategy?
- **Risk if missing:** Token replay, indefinite access
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Token Strategy
  - Access token: 15 minutes
  - Refresh token: 7 days
  - Refresh rotation: Issue new refresh on use
  - Revocation: Blacklist on logout/password change
  ```

### Account Lockout
- **Check:** Brute force protection defined?
- **Risk if missing:** Credential stuffing attacks
- **Severity:** MEDIUM
- **Expected in design:**
  ```markdown
  ## Account Lockout Policy
  - Lock after: 5 failed attempts
  - Lockout duration: 30 minutes
  - CAPTCHA after: 3 failed attempts
  - Notification: Email on lockout
  ```

### Password Policy
- **Check:** Password requirements specified?
- **Risk if missing:** Weak passwords
- **Severity:** MEDIUM
- **Expected in design:**
  ```markdown
  ## Password Requirements
  - Minimum length: 12 characters
  - Complexity: uppercase, lowercase, number, special
  - No common passwords (breach lists)
  - No password hints
  - Secure reset flow with time-limited tokens
  ```

---

## Authorization Design

### Principle of Least Privilege
- **Check:** Default permissions minimized?
- **Risk if missing:** Excessive access
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Default Permissions
  - New users: Read-only access
  - Elevated permissions: Request-based approval
  - Service accounts: Minimal required scope
  ```

### Role Separation (RBAC/ABAC)
- **Check:** Roles and permissions defined?
- **Risk if missing:** Privilege confusion
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Role Hierarchy
  | Role | Permissions |
  |------|-------------|
  | Viewer | Read own data |
  | Editor | Read/write own data |
  | Admin | Full access to org data |
  | Super Admin | System configuration |
  ```

### Resource Ownership
- **Check:** Ownership model documented?
- **Risk if missing:** Horizontal privilege escalation
- **Severity:** CRITICAL
- **Expected in design:**
  ```markdown
  ## Ownership Model
  - Resources belong to: User OR Organization
  - Access check: Owner OR Admin OR Explicit share
  - Ownership transfer: Admin approval required
  ```

### Admin Privilege Path
- **Check:** Admin escalation documented?
- **Risk if missing:** Unclear privilege escalation
- **Severity:** MEDIUM
- **Expected in design:**
  ```markdown
  ## Admin Access
  - Requires: Existing admin invitation
  - Approval: Dual approval from current admins
  - Audit: All admin actions logged
  - MFA: Required for admin operations
  ```

### API Authorization
- **Check:** Endpoint protection documented?
- **Risk if missing:** Unprotected endpoints
- **Severity:** CRITICAL
- **Expected in design:**
  ```markdown
  ## API Authorization
  | Endpoint | Auth Required | Roles |
  |----------|---------------|-------|
  | GET /users | Yes | Any |
  | POST /users | Yes | Admin |
  | DELETE /users/{id} | Yes | Admin, Owner |
  ```

---

## Data Protection

### Sensitive Data Classification
- **Check:** Data sensitivity levels defined?
- **Risk if missing:** Inconsistent protection
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Data Classification
  | Level | Examples | Protection |
  |-------|----------|------------|
  | Public | Marketing content | None |
  | Internal | User emails | Encrypted at rest |
  | Confidential | Passwords, SSN | Encrypted, masked, audited |
  | Restricted | Payment cards | PCI DSS compliance |
  ```

### Encryption at Rest
- **Check:** Storage encryption specified?
- **Risk if missing:** Data breach exposure
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Encryption at Rest
  - Database: AES-256 (AWS KMS managed)
  - File storage: S3 SSE-S3/SSE-KMS
  - Backups: Encrypted with separate keys
  - Key rotation: Annual or on compromise
  ```

### Encryption in Transit
- **Check:** Transport security defined?
- **Risk if missing:** Man-in-the-middle attacks
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Encryption in Transit
  - External: TLS 1.3 required
  - Internal: TLS 1.2+ (mTLS preferred)
  - Certificate management: AWS ACM
  - HSTS: Enabled with preload
  ```

### Data Retention
- **Check:** Retention policies defined?
- **Risk if missing:** Compliance violations, indefinite storage
- **Severity:** MEDIUM
- **Expected in design:**
  ```markdown
  ## Data Retention
  | Data Type | Retention | Deletion |
  |-----------|-----------|----------|
  | Logs | 90 days | Automatic |
  | User data | Account lifetime + 30 days | On request |
  | Audit logs | 7 years | Archive to cold storage |
  ```

### PII Handling
- **Check:** GDPR/CCPA compliance addressed?
- **Risk if missing:** Regulatory violations
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## PII Handling
  - Consent: Explicit opt-in required
  - Access: Self-service data export
  - Deletion: Right to be forgotten
  - Portability: Machine-readable export
  - Processing: Documented legal basis
  ```

---

## API Security

### Rate Limiting
- **Check:** Throttling strategy defined?
- **Risk if missing:** DoS, brute force attacks
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Rate Limiting
  | Endpoint | Limit | Window |
  |----------|-------|--------|
  | /login | 5 | 1 minute |
  | /api/* | 100 | 1 minute |
  | /search | 30 | 1 minute |
  | Response: 429 Too Many Requests
  ```

### Input Validation
- **Check:** Validation strategy documented?
- **Risk if missing:** Injection attacks
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Input Validation
  - Approach: Whitelist validation
  - Library: Joi/Yup/Zod schemas
  - Location: API Gateway + handler
  - Sanitization: Before storage
  ```

### Error Handling
- **Check:** Error response strategy defined?
- **Risk if missing:** Information disclosure
- **Severity:** MEDIUM
- **Expected in design:**
  ```markdown
  ## Error Handling
  - Production: Generic error messages
  - Logging: Full details server-side
  - User-facing: Reference IDs only
  - No stack traces in responses
  ```

### CORS Policy
- **Check:** CORS configuration documented?
- **Risk if missing:** Cross-origin attacks
- **Severity:** MEDIUM
- **Expected in design:**
  ```markdown
  ## CORS Configuration
  - Allowed origins: Explicit list (no wildcards)
  - Allowed methods: GET, POST, PUT, DELETE
  - Credentials: Only with explicit origins
  - Max age: 86400 seconds
  ```

---

## Network Security

### Defense in Depth
- **Check:** Multiple security layers?
- **Risk if missing:** Single point of failure
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Security Layers
  1. WAF: AWS WAF with managed rules
  2. API Gateway: Rate limiting, auth
  3. VPC: Private subnets for compute
  4. Security groups: Minimal ingress
  5. Application: Input validation
  ```

### Security Boundaries
- **Check:** Trust boundaries defined?
- **Risk if missing:** Lateral movement
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Trust Boundaries
  - Internet → WAF/CloudFront (untrusted)
  - WAF → API Gateway (semi-trusted)
  - API Gateway → Lambda (trusted)
  - Lambda → RDS (internal)
  ```

### Network Segmentation
- **Check:** Internal/external separation?
- **Risk if missing:** Flat network exposure
- **Severity:** HIGH
- **Expected in design:**
  ```markdown
  ## Network Segmentation
  - Public subnet: Load balancers only
  - Private subnet: Application tier
  - Isolated subnet: Database tier
  - VPC endpoints: AWS service access
  ```

---

## Checklist Summary

| Area | Critical Checks | Status |
|------|-----------------|--------|
| Authentication | MFA, Session, Tokens | [ ] |
| Authorization | RBAC, Ownership, API auth | [ ] |
| Data Protection | Classification, Encryption | [ ] |
| API Security | Rate limiting, Validation | [ ] |
| Network | Defense in depth, Segmentation | [ ] |
