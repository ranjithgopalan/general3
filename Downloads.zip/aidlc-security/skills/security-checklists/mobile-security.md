# Mobile Application Security Patterns Checklist

Reference checklist for code-security-reviewer agent.

This checklist provides detection patterns for mobile application security controls including screenshot prevention, secure storage, certificate pinning, and network security.

---

## Quick Reference - Mobile Security Controls

| Control | iOS | Android | React Native | Severity if Missing |
|---------|-----|---------|--------------|---------------------|
| Screenshot Prevention | `isSecureTextEntry`, window flag | `FLAG_SECURE` | `react-native-screen-capture` | HIGH |
| Secure Credential Storage | Keychain | Keystore | `react-native-keychain` | CRITICAL |
| Certificate Pinning | `URLSession` delegate | `OkHttp`, `TrustManager` | `ssl-pinning` | HIGH |
| Cleartext Traffic Block | ATS | `networkSecurityConfig` | N/A (native) | HIGH |
| Root/Jailbreak Detection | Various checks | `RootBeer`, SafetyNet | `jail-monkey` | MEDIUM |

---

## Detection Patterns

### Mobile Platform Detection

```bash
# Identify mobile code for review
# React Native
Grep: "react-native|expo|@react-native"
Grep: "AsyncStorage|SecureStore|Keychain"

# iOS (Swift/Objective-C)
Grep: "UIKit|SwiftUI|Foundation"
Grep: "Keychain|SecItem|LAContext"

# Android (Kotlin/Java)
Grep: "android\\.|androidx\\."
Grep: "SharedPreferences|KeyStore|EncryptedSharedPreferences"

# Flutter
Grep: "flutter|dart:io"
Grep: "flutter_secure_storage|shared_preferences"
```

### Insecure Storage Detection

```bash
# Insecure storage patterns
Grep: "AsyncStorage|localStorage|sessionStorage"
Grep: "SharedPreferences[^E]|getSharedPreferences"
Grep: "UserDefaults|NSUserDefaults"

# Credentials in storage
Grep: "AsyncStorage.*password|AsyncStorage.*token"
Grep: "SharedPreferences.*password|SharedPreferences.*token"
Grep: "UserDefaults.*password|UserDefaults.*token"
```

### Secure Storage Detection

```bash
# Secure storage (should be present for credentials)
Grep: "Keychain|SecItemAdd|SecItemCopyMatching"
Grep: "KeyStore|AndroidKeyStore|EncryptedSharedPreferences"
Grep: "react-native-keychain|SecureStore|flutter_secure_storage"
```

### Certificate Pinning Detection

```bash
# Certificate pinning
Grep: "certificatePinning|ssl-pinning|TrustManager"
Grep: "pinnedCertificates|pinnedPublicKeys"
Grep: "URLSession.*didReceiveChallenge|serverTrustPolicy"
Grep: "CertificatePinner|OkHttpClient.*certificatePinner"
```

### Network Security Detection

```bash
# Cleartext/HTTP traffic
Grep: "http://|cleartext.*true|usesCleartextTraffic"
Grep: "NSAllowsArbitraryLoads|NSExceptionAllowsInsecureHTTPLoads"
Grep: "android:usesCleartextTraffic"
```

---

## MOB-01: Insecure Credential Storage

**Severity:** CRITICAL | **CWE:** CWE-922

Credentials must be stored in platform-specific secure storage, not in plaintext or weakly protected storage.

### React Native

```typescript
// VULNERABLE: AsyncStorage (unencrypted)
import AsyncStorage from '@react-native-async-storage/async-storage';

async function storeToken(token: string) {
  await AsyncStorage.setItem('authToken', token);  // Not encrypted!
}

async function storeCredentials(username: string, password: string) {
  await AsyncStorage.setItem('credentials', JSON.stringify({ username, password }));
}

// SECURE: react-native-keychain
import * as Keychain from 'react-native-keychain';

async function storeToken(token: string) {
  await Keychain.setGenericPassword('authToken', token, {
    service: 'com.myapp.auth',
    accessible: Keychain.ACCESSIBLE.WHEN_UNLOCKED_THIS_DEVICE_ONLY
  });
}

async function storeCredentials(username: string, password: string) {
  await Keychain.setInternetCredentials(
    'api.myapp.com',
    username,
    password
  );
}

// SECURE: Expo SecureStore
import * as SecureStore from 'expo-secure-store';

async function storeToken(token: string) {
  await SecureStore.setItemAsync('authToken', token, {
    keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY
  });
}
```

### iOS (Swift)

```swift
// VULNERABLE: UserDefaults (unencrypted plist)
UserDefaults.standard.set(authToken, forKey: "authToken")
UserDefaults.standard.set(password, forKey: "password")

// SECURE: Keychain
import Security

func saveToKeychain(token: String, service: String) throws {
    let data = token.data(using: .utf8)!
    let query: [String: Any] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrService as String: service,
        kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
        kSecValueData as String: data
    ]

    let status = SecItemAdd(query as CFDictionary, nil)
    guard status == errSecSuccess else {
        throw KeychainError.unhandledError(status: status)
    }
}
```

### Android (Kotlin)

```kotlin
// VULNERABLE: SharedPreferences (plaintext XML)
val prefs = getSharedPreferences("auth", MODE_PRIVATE)
prefs.edit().putString("token", token).apply()
prefs.edit().putString("password", password).apply()

// SECURE: EncryptedSharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

val masterKey = MasterKey.Builder(context)
    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
    .build()

val securePrefs = EncryptedSharedPreferences.create(
    context,
    "secure_prefs",
    masterKey,
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
)

securePrefs.edit().putString("token", token).apply()

// SECURE: Android Keystore for cryptographic keys
val keyStore = KeyStore.getInstance("AndroidKeyStore")
keyStore.load(null)
val keyGenerator = KeyGenerator.getInstance(
    KeyProperties.KEY_ALGORITHM_AES,
    "AndroidKeyStore"
)
```

**Finding Template:**
```markdown
**MOB-01: Insecure Credential Storage**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** Mobile Security / CWE-922
- **Location:** {file}:{line}
- **Issue:** Credentials stored in {AsyncStorage|SharedPreferences|UserDefaults}
- **Impact:** Credentials accessible to attackers with device access or backup extraction
- **Remediation:** Use platform secure storage (Keychain/Keystore/react-native-keychain)
```

---

## MOB-02: Missing Screenshot Prevention

**Severity:** HIGH | **CWE:** CWE-200

Sensitive screens must prevent screenshot capture and app snapshots.

### React Native

```typescript
// VULNERABLE: No screenshot prevention
const SensitiveDataScreen = () => {
  return (
    <View>
      <Text>SSN: 123-45-6789</Text>
      <Text>Account Balance: $10,000</Text>
    </View>
  );
};

// SECURE: Screenshot prevention
import { usePreventScreenCapture } from 'expo-screen-capture';
// OR
import ScreenCapture from 'react-native-screen-capture';

const SensitiveDataScreen = () => {
  usePreventScreenCapture();  // Expo

  useEffect(() => {
    ScreenCapture.enableSecureView();  // react-native-screen-capture
    return () => ScreenCapture.disableSecureView();
  }, []);

  return (
    <View>
      <Text>SSN: 123-45-6789</Text>
    </View>
  );
};
```

### iOS (Swift)

```swift
// SECURE: Prevent screenshots
override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)

    // Blur view when app goes to background (prevents snapshot)
    NotificationCenter.default.addObserver(
        self,
        selector: #selector(willResignActive),
        name: UIApplication.willResignActiveNotification,
        object: nil
    )
}

@objc func willResignActive() {
    let blurView = UIVisualEffectView(effect: UIBlurEffect(style: .light))
    blurView.frame = view.bounds
    blurView.tag = 999
    view.addSubview(blurView)
}

// For text fields with sensitive data
let secureTextField = UITextField()
secureTextField.isSecureTextEntry = true
```

### Android (Kotlin)

```kotlin
// SECURE: Prevent screenshots
class SensitiveActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Prevent screenshots and screen recording
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        setContentView(R.layout.activity_sensitive)
    }
}
```

**Finding Template:**
```markdown
**MOB-02: Missing Screenshot Prevention**
**Severity:** HIGH
**Confidence:** MEDIUM

- **Category:** Mobile Security / CWE-200
- **Location:** {file}:{line}
- **Issue:** Screen displaying sensitive data without screenshot prevention
- **Impact:** Sensitive data captured in screenshots or app switcher snapshots
- **Remediation:** Add FLAG_SECURE (Android), blur on background (iOS), or screen capture prevention library
```

---

## MOB-03: Missing Certificate Pinning

**Severity:** HIGH | **CWE:** CWE-295

Apps must pin SSL certificates to prevent MITM attacks.

### React Native

```typescript
// VULNERABLE: No certificate pinning
const api = axios.create({
  baseURL: 'https://api.myapp.com'
});

// SECURE: Certificate pinning
import { fetch } from 'react-native-ssl-pinning';

const response = await fetch('https://api.myapp.com/data', {
  method: 'GET',
  sslPinning: {
    certs: ['cert1', 'cert2']  // Certificate names in assets
  }
});

// SECURE: Using TrustKit (iOS) or public key pinning
import TrustKit from 'react-native-trustkit';

TrustKit.initializeWithConfiguration({
  'api.myapp.com': {
    publicKeyHashes: [
      'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=',
      'BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB='
    ],
    includeSubdomains: true,
    enforcePinning: true
  }
});
```

### iOS (Swift)

```swift
// SECURE: URLSession certificate pinning
class APIManager: NSObject, URLSessionDelegate {
    func urlSession(_ session: URLSession,
                    didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {

        guard let serverTrust = challenge.protectionSpace.serverTrust,
              let certificate = SecTrustGetCertificateAtIndex(serverTrust, 0) else {
            completionHandler(.cancelAuthenticationChallenge, nil)
            return
        }

        // Compare with pinned certificate
        let pinnedCertificate = SecCertificateCreateWithData(nil, pinnedCertData as CFData)!

        if certificate == pinnedCertificate {
            completionHandler(.useCredential, URLCredential(trust: serverTrust))
        } else {
            completionHandler(.cancelAuthenticationChallenge, nil)
        }
    }
}
```

### Android (Kotlin)

```kotlin
// SECURE: OkHttp certificate pinning
val certificatePinner = CertificatePinner.Builder()
    .add("api.myapp.com", "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
    .add("api.myapp.com", "sha256/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=")
    .build()

val client = OkHttpClient.Builder()
    .certificatePinner(certificatePinner)
    .build()

// Network Security Config (res/xml/network_security_config.xml)
/*
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <domain-config>
        <domain includeSubdomains="true">api.myapp.com</domain>
        <pin-set>
            <pin digest="SHA-256">AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=</pin>
            <pin digest="SHA-256">BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=</pin>
        </pin-set>
    </domain-config>
</network-security-config>
*/
```

**Finding Template:**
```markdown
**MOB-03: Missing Certificate Pinning**
**Severity:** HIGH
**Confidence:** MEDIUM

- **Category:** Mobile Security / CWE-295
- **Location:** {file}:{line}
- **Issue:** HTTPS connections without certificate pinning
- **Impact:** Vulnerable to man-in-the-middle attacks even with HTTPS
- **Remediation:** Implement certificate or public key pinning using platform-appropriate method
```

---

## MOB-04: Cleartext Traffic Allowed

**Severity:** HIGH | **CWE:** CWE-319

Apps must not allow unencrypted HTTP traffic.

### iOS (Info.plist)

```xml
<!-- VULNERABLE: Allows all HTTP -->
<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsArbitraryLoads</key>
    <true/>
</dict>

<!-- SECURE: HTTPS enforced (default) or specific exceptions only -->
<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsArbitraryLoads</key>
    <false/>
    <key>NSExceptionDomains</key>
    <dict>
        <key>legacy.internal.com</key>
        <dict>
            <key>NSExceptionAllowsInsecureHTTPLoads</key>
            <true/>
            <key>NSIncludesSubdomains</key>
            <false/>
        </dict>
    </dict>
</dict>
```

### Android (AndroidManifest.xml)

```xml
<!-- VULNERABLE: Allows cleartext -->
<application
    android:usesCleartextTraffic="true"
    ...>

<!-- SECURE: Block cleartext (default in API 28+) -->
<application
    android:usesCleartextTraffic="false"
    android:networkSecurityConfig="@xml/network_security_config"
    ...>

<!-- network_security_config.xml -->
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system"/>
        </trust-anchors>
    </base-config>
</network-security-config>
```

**Finding Template:**
```markdown
**MOB-04: Cleartext Traffic Allowed**
**Severity:** HIGH
**Confidence:** HIGH

- **Category:** Mobile Security / CWE-319
- **Location:** {file}:{line}
- **Issue:** Application allows unencrypted HTTP traffic
- **Impact:** Network traffic can be intercepted and modified
- **Remediation:** Disable cleartext traffic in {Info.plist|AndroidManifest.xml}
```

---

## MOB-05: Missing Root/Jailbreak Detection

**Severity:** MEDIUM | **CWE:** CWE-919

Apps handling sensitive data should detect compromised devices.

```typescript
// React Native: jail-monkey
import JailMonkey from 'jail-monkey';

if (JailMonkey.isJailBroken()) {
  Alert.alert('Security Warning', 'This device appears to be compromised');
  // Consider restricting functionality
}

// Android: RootBeer
val rootBeer = RootBeer(context)
if (rootBeer.isRooted) {
    // Handle rooted device
}
```

---

## Detection Summary

| Issue | Grep Pattern | Severity |
|-------|-------------|----------|
| Insecure storage | `AsyncStorage.*token\|SharedPreferences.*password` | CRITICAL |
| Missing screenshot prevention | Screen with PII without `FLAG_SECURE\|preventScreenCapture` | HIGH |
| Missing cert pinning | HTTPS calls without `certificatePinner\|ssl-pinning` | HIGH |
| Cleartext allowed | `NSAllowsArbitraryLoads.*true\|usesCleartextTraffic.*true` | HIGH |
| Missing root detection | No `jail-monkey\|RootBeer\|isJailBroken` | MEDIUM |

---

## References

- [OWASP Mobile Security Testing Guide](https://owasp.org/www-project-mobile-security-testing-guide/)
- [OWASP Mobile Top 10](https://owasp.org/www-project-mobile-top-10/)
- [iOS Security Guide](https://support.apple.com/guide/security/)
- [Android Security Best Practices](https://developer.android.com/topic/security/best-practices)
