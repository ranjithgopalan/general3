# Web Services Security Patterns Checklist

Reference checklist for code-security-reviewer agent.

This checklist provides detection patterns for web services security controls including non-repudiation, DoS prevention, rate limiting, and secure channel enforcement.

---

## Quick Reference - Web Services Security Controls

| Control | Purpose | Severity if Missing |
|---------|---------|---------------------|
| Request Signing | Non-repudiation, integrity | HIGH |
| Timestamp Validation | Replay attack prevention | MEDIUM |
| Rate Limiting | DoS prevention | HIGH |
| Request Size Limits | DoS prevention | MEDIUM |
| Secure Channel (HTTPS) | Data confidentiality | CRITICAL |
| HSTS Headers | Downgrade attack prevention | HIGH |

---

## Detection Patterns

### Non-Repudiation Controls

```bash
# Request/response signing
Grep: "hmac|createHmac|crypto.createHmac"
Grep: "signature|x-signature|x-hub-signature"
Grep: "sign\\(|verify\\(|createSign|createVerify"

# Timestamp validation
Grep: "timestamp|nonce|x-timestamp"
Grep: "requestTime|createdAt.*validate"

# Replay prevention
Grep: "nonce|requestId|idempotencyKey"
Grep: "usedNonces|nonceStore|replayCheck"
```

### DoS Prevention Controls

```bash
# Request size limits
Grep: "bodyParser.*limit|json.*limit|urlencoded.*limit"
Grep: "maxBodySize|maxRequestSize|limit.*['\"]\\d+[mk]b"
Grep: "express.json.*limit|express.urlencoded.*limit"

# Rate limiting
Grep: "rateLimit|rateLimiter|express-rate-limit"
Grep: "throttle|slowDown|bottleneck"
Grep: "requestsPerMinute|windowMs|max.*requests"

# Query complexity (GraphQL)
Grep: "maxDepth|maxComplexity|depthLimit|costAnalysis"
Grep: "graphql-depth-limit|graphql-validation-complexity"

# File upload limits
Grep: "multer.*limit|fileSize|maxFileSize"
Grep: "upload.*limit|maxFiles"
```

### Secure Channel Detection

```bash
# HTTPS enforcement
Grep: "https://|http://"
Grep: "secure.*true|requireHTTPS|forceSSL"
Grep: "redirect.*https|upgradeInsecureRequests"

# HSTS headers
Grep: "Strict-Transport-Security|hsts|helmet.hsts"
Grep: "max-age.*includeSubDomains|preload"

# TLS configuration
Grep: "TLSv1\\.2|TLSv1\\.3|minVersion.*TLS"
Grep: "secureProtocol|ciphers|honorCipherOrder"
```

---

## WS-01: Missing Request Signing (Non-Repudiation)

**Severity:** HIGH | **CWE:** CWE-345

Critical operations should use signed requests to ensure integrity and non-repudiation.

```typescript
// VULNERABLE: No request validation
app.post('/api/webhook/payment', async (req, res) => {
  const { orderId, status, amount } = req.body;
  await processPaymentUpdate(orderId, status, amount);  // No verification!
});

// SECURE: HMAC signature validation
app.post('/api/webhook/payment', async (req, res) => {
  const signature = req.headers['x-webhook-signature'];
  const timestamp = req.headers['x-webhook-timestamp'];
  const payload = JSON.stringify(req.body);

  // Verify signature
  const expectedSignature = crypto
    .createHmac('sha256', WEBHOOK_SECRET)
    .update(`${timestamp}.${payload}`)
    .digest('hex');

  if (!crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(`sha256=${expectedSignature}`)
  )) {
    logger.warn({ action: 'WEBHOOK_SIGNATURE_INVALID' });
    return res.status(401).json({ error: 'Invalid signature' });
  }

  // Verify timestamp (prevent replay)
  const requestTime = parseInt(timestamp);
  const now = Date.now();
  if (Math.abs(now - requestTime) > 300000) {  // 5 minute tolerance
    logger.warn({ action: 'WEBHOOK_TIMESTAMP_INVALID' });
    return res.status(401).json({ error: 'Request expired' });
  }

  await processPaymentUpdate(req.body);
});

// SECURE: Request signing for outbound API calls
async function signedApiCall(endpoint: string, payload: object) {
  const timestamp = Date.now().toString();
  const nonce = crypto.randomUUID();
  const payloadString = JSON.stringify(payload);

  const signature = crypto
    .createHmac('sha256', API_SECRET)
    .update(`${timestamp}:${nonce}:${payloadString}`)
    .digest('hex');

  return axios.post(endpoint, payload, {
    headers: {
      'X-Timestamp': timestamp,
      'X-Nonce': nonce,
      'X-Signature': signature
    }
  });
}
```

**Finding Template:**
```markdown
**WS-01: Missing Request Signature Validation**
**Severity:** HIGH
**Confidence:** HIGH

- **Category:** Web Services Security / CWE-345
- **Location:** {file}:{line}
- **Issue:** Webhook/callback endpoint without signature validation
- **Impact:** Attackers can forge requests, leading to unauthorized actions
- **Remediation:** Implement HMAC signature validation with timing-safe comparison
```

---

## WS-02: Missing Replay Attack Prevention

**Severity:** MEDIUM | **CWE:** CWE-294

Signed requests should include nonce/timestamp to prevent replay attacks.

```typescript
// VULNERABLE: Signature but no replay prevention
app.post('/api/transaction', async (req, res) => {
  const signature = req.headers['x-signature'];
  // Validates signature but same request can be replayed!
  if (validateSignature(req.body, signature)) {
    await processTransaction(req.body);
  }
});

// SECURE: Nonce-based replay prevention
const usedNonces = new Set();  // In production, use Redis with TTL

app.post('/api/transaction', async (req, res) => {
  const { nonce, timestamp } = req.headers;

  // Check timestamp freshness
  if (Date.now() - parseInt(timestamp) > 300000) {
    return res.status(400).json({ error: 'Request expired' });
  }

  // Check nonce hasn't been used
  const nonceKey = `${timestamp}:${nonce}`;
  if (usedNonces.has(nonceKey)) {
    logger.warn({ action: 'REPLAY_ATTACK_DETECTED', nonce });
    return res.status(400).json({ error: 'Duplicate request' });
  }

  usedNonces.add(nonceKey);
  // Clean old nonces periodically

  await processTransaction(req.body);
});

// SECURE: Redis-based nonce storage
async function validateNonce(nonce: string, timestamp: number): Promise<boolean> {
  const key = `nonce:${nonce}`;
  const ttl = 300;  // 5 minutes

  // SETNX returns 1 if key was set (new nonce)
  const result = await redis.set(key, timestamp, 'EX', ttl, 'NX');
  return result === 'OK';
}
```

**Finding Template:**
```markdown
**WS-02: Missing Replay Attack Prevention**
**Severity:** MEDIUM
**Confidence:** MEDIUM

- **Category:** Web Services Security / CWE-294
- **Location:** {file}:{line}
- **Issue:** Signed requests without nonce/timestamp validation
- **Impact:** Valid signed requests can be captured and replayed
- **Remediation:** Add timestamp validation and nonce tracking
```

---

## WS-03: Missing Rate Limiting

**Severity:** HIGH | **CWE:** CWE-770

All API endpoints should have rate limiting to prevent abuse and DoS.

```typescript
// VULNERABLE: No rate limiting
app.post('/api/login', async (req, res) => {
  // Can be brute-forced
  const result = await authenticate(req.body);
});

app.get('/api/search', async (req, res) => {
  // Can be abused for DoS
  const results = await expensiveSearch(req.query);
});

// SECURE: Express rate limiting
import rateLimit from 'express-rate-limit';

// Global rate limit
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes
  max: 100,  // 100 requests per window
  message: { error: 'Too many requests' },
  standardHeaders: true,
  legacyHeaders: false
});

app.use(globalLimiter);

// Stricter limit for auth endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,  // 5 login attempts per 15 minutes
  message: { error: 'Too many login attempts' },
  skipSuccessfulRequests: true  // Don't count successful logins
});

app.post('/api/login', authLimiter, async (req, res) => {
  const result = await authenticate(req.body);
});

// SECURE: Per-user rate limiting
import { RateLimiterRedis } from 'rate-limiter-flexible';

const rateLimiter = new RateLimiterRedis({
  storeClient: redisClient,
  keyPrefix: 'rl',
  points: 10,  // 10 requests
  duration: 1  // per second
});

app.use(async (req, res, next) => {
  try {
    const key = req.user?.id || req.ip;
    await rateLimiter.consume(key);
    next();
  } catch {
    res.status(429).json({ error: 'Rate limit exceeded' });
  }
});
```

**Finding Template:**
```markdown
**WS-03: Missing Rate Limiting**
**Severity:** HIGH
**Confidence:** MEDIUM

- **Category:** Web Services Security / CWE-770
- **Location:** {file}:{line}
- **Issue:** API endpoint without rate limiting
- **Impact:** Vulnerable to brute force attacks and denial of service
- **Endpoint Type:** {authentication|search|resource-intensive}
- **Remediation:** Implement rate limiting using express-rate-limit or similar
```

---

## WS-04: Missing Request Size Limits

**Severity:** MEDIUM | **CWE:** CWE-770

Request body size must be limited to prevent memory exhaustion DoS.

```typescript
// VULNERABLE: No body size limit (default may be very high)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// SECURE: Explicit size limits
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: true, limit: '100kb' }));

// SECURE: Different limits for different routes
app.post('/api/data', express.json({ limit: '10kb' }), handleData);
app.post('/api/upload', express.json({ limit: '5mb' }), handleUpload);

// SECURE: File upload limits with multer
import multer from 'multer';

const upload = multer({
  limits: {
    fileSize: 5 * 1024 * 1024,  // 5MB max
    files: 5,  // Max 5 files
    fieldSize: 1024 * 1024  // 1MB max field size
  },
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'application/pdf'];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});

app.post('/api/upload', upload.single('file'), handleUpload);
```

**Finding Template:**
```markdown
**WS-04: Missing Request Size Limit**
**Severity:** MEDIUM
**Confidence:** HIGH

- **Category:** Web Services Security / CWE-770
- **Location:** {file}:{line}
- **Issue:** Body parser without explicit size limit
- **Impact:** Large payloads can exhaust server memory
- **Remediation:** Add explicit limit option to body parser middleware
```

---

## WS-05: Missing HTTPS/HSTS

**Severity:** CRITICAL | **CWE:** CWE-319

All traffic must use HTTPS with HSTS headers.

```typescript
// VULNERABLE: HTTP allowed
app.listen(80);

// VULNERABLE: No HSTS
app.use((req, res, next) => {
  // Missing Strict-Transport-Security header
  next();
});

// SECURE: Force HTTPS redirect
app.use((req, res, next) => {
  if (req.protocol === 'http' && process.env.NODE_ENV === 'production') {
    return res.redirect(301, `https://${req.hostname}${req.url}`);
  }
  next();
});

// SECURE: HSTS with helmet
import helmet from 'helmet';

app.use(helmet.hsts({
  maxAge: 31536000,  // 1 year
  includeSubDomains: true,
  preload: true
}));

// SECURE: Full helmet configuration
app.use(helmet({
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  },
  contentSecurityPolicy: true,
  frameguard: { action: 'deny' }
}));
```

**Finding Template:**
```markdown
**WS-05: Missing HTTPS/HSTS Enforcement**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** Web Services Security / CWE-319
- **Location:** {file}:{line}
- **Issue:** {HTTP allowed without redirect|Missing HSTS header}
- **Impact:** Traffic can be intercepted or downgraded to HTTP
- **Remediation:** Force HTTPS redirect and add HSTS header with 1-year max-age
```

---

## WS-06: GraphQL Query Complexity (DoS)

**Severity:** MEDIUM | **CWE:** CWE-770

GraphQL endpoints must limit query depth and complexity.

```typescript
// VULNERABLE: No query limits
const server = new ApolloServer({
  typeDefs,
  resolvers
});

// SECURE: Depth and complexity limits
import depthLimit from 'graphql-depth-limit';
import { createComplexityLimitRule } from 'graphql-validation-complexity';

const server = new ApolloServer({
  typeDefs,
  resolvers,
  validationRules: [
    depthLimit(5),  // Max 5 levels deep
    createComplexityLimitRule(1000, {
      scalarCost: 1,
      objectCost: 10,
      listFactor: 10
    })
  ]
});
```

---

## Detection Summary

| Issue | Grep Pattern | Severity |
|-------|-------------|----------|
| No request signing | Webhook without `hmac\|signature` | HIGH |
| No replay prevention | Signed endpoint without `nonce\|timestamp` | MEDIUM |
| No rate limiting | Auth/API without `rateLimit\|throttle` | HIGH |
| No body limit | `express.json()` without `limit` | MEDIUM |
| No HSTS | Missing `helmet.hsts\|Strict-Transport` | CRITICAL |
| No GraphQL limits | GraphQL without `depthLimit\|complexity` | MEDIUM |

---

## References

- AIG Web Services Security Requirements
- [OWASP REST Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/REST_Security_Cheat_Sheet.html)
- [OWASP GraphQL Security](https://cheatsheetseries.owasp.org/cheatsheets/GraphQL_Cheat_Sheet.html)
- [CWE-770: Resource Exhaustion](https://cwe.mitre.org/data/definitions/770.html)
