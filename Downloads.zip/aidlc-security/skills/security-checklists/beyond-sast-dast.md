# Beyond SAST/DAST - Manual Security Review Patterns

Reference checklist for security reviewers to identify vulnerabilities that automated SAST/DAST tools cannot detect.

This checklist focuses on security issues that require:
- Business logic understanding
- Design document analysis
- Context-aware code review
- Cross-file relationship analysis
- Domain knowledge

---

## Why Manual Review is Essential

| SAST/DAST Finds | Manual Review Finds |
|-----------------|---------------------|
| SQL injection patterns | Business logic authorization bypasses |
| XSS in templates | Horizontal/vertical privilege escalation |
| Hardcoded secrets (basic) | Race conditions (TOCTOU) |
| Known CVEs | State machine bypasses |
| CORS wildcards | Design-level security gaps |
| Missing encryption | Multi-tenant isolation failures |
| Basic auth issues | Context-dependent vulnerabilities |

---

## Part 1: Design Document Analysis

### What SAST/DAST Cannot Do
Automated tools cannot read design documents. Security gaps in architecture must be found through manual review.

### Design Security Gaps

| Gap Category | What to Look For | Why Tools Miss It |
|--------------|------------------|-------------------|
| **Authentication Design** | Missing MFA, weak session management, no lockout policy | No design doc parsing |
| **Authorization Model** | Missing RBAC/ABAC design, no least privilege | Cannot understand business roles |
| **Data Classification** | Unclassified PII/PHI, missing encryption requirements | No data sensitivity understanding |
| **API Security Design** | Missing rate limiting design, no auth per endpoint | Cannot analyze specifications |
| **Threat Model Gaps** | Missing trust boundaries, no attack surface analysis | No threat modeling capability |

### Detection Approach

```bash
# Find design documents
Glob: **/HLD*.md, **/architecture*.md, **/design*.md
Glob: **/api-spec*.yaml, **/openapi*.yaml, **/swagger*.yaml
Glob: **/TDD*.md, **/technical-design*.md

# Search for security sections
Grep: "authentication|authorization|encryption|security"
Grep: "MFA|session|token|RBAC|role"

# Check for gaps (absence of these indicates missing design)
# - No MFA mentioned → CRITICAL
# - No session timeout defined → HIGH
# - No rate limiting strategy → HIGH
# - No data classification → HIGH
```

### Finding Template - Design Gap

```markdown
**DESIGN-GAP-001: Missing Authentication Rate Limiting Design**
**Severity:** HIGH
**Confidence:** HIGH

- **Category:** Design Security / Authentication
- **Location:** docs/API-Design.md, Section 4.2
- **Issue:** Authentication design lacks rate limiting specification
- **Impact:** Without rate limiting design, implementation may lack brute force protection
- **Why SAST/DAST Misses:** Cannot parse design documents; only analyzes code
- **Remediation:** Add rate limiting requirements to authentication design section
```

---

## Part 2: Business Logic Vulnerabilities

### What SAST/DAST Cannot Understand

| Concept | Example SAST Sees | What It Misses |
|---------|-------------------|----------------|
| **Ownership** | `findById(id)` | That `id` must belong to current user |
| **Roles** | `req.body.role` | That roles should come from server, not client |
| **Workflow** | `status = 'shipped'` | That shipping requires payment first |
| **Timing** | `if(check) { action }` | That check and action must be atomic |
| **Business Rules** | Price calculation | That discounts have maximum limits |

### Business Logic Patterns

#### BL-01: Horizontal Privilege Escalation (IDOR)

**Detection Pattern:**
```bash
# Find resource lookups by ID from request
Grep: "params.id|params.userId|params.resourceId"
Grep: "findById|getById|findOne.*id"

# RED FLAG: ID from request used directly without ownership check
```

**Vulnerable Pattern:**
```typescript
// SAST sees: database query - OK
// Reality: Any user can access any document
async getDocument(documentId: string) {
  return await Document.findById(documentId);  // Missing: ownership check
}
```

**What's Missing (SAST cannot detect):**
```typescript
// REQUIRED: Ownership validation
if (document.ownerId !== currentUser.id) {
  throw new ForbiddenError();
}
```

**Finding Format:**
```markdown
**BL-IDOR-001: Horizontal Privilege Escalation - Document Access**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** A01:2021 - Broken Access Control / CWE-639
- **Location:** src/services/document.service.ts:45
- **Issue:** getDocument() retrieves by ID without ownership validation
- **Code:** `const doc = await Document.findById(id);`
- **Impact:** Any authenticated user can access any document
- **Why SAST Misses:** Cannot understand that documents belong to specific users
- **PoC:** GET /api/documents/{other-user-doc-id} with valid token
```

#### BL-02: Vertical Privilege Escalation

**Detection Pattern:**
```bash
# Find role/permission from client input
Grep: "req.body.role|req.body.isAdmin|req.body.permissions"
Grep: "Object.assign.*req.body|\\.\\.\\..req.body"
```

**Vulnerable Pattern:**
```typescript
// SAST sees: object update - OK
// Reality: User can set themselves as admin
async updateProfile(data: any) {
  await User.update(userId, { ...data });  // data may contain isAdmin: true
}
```

**Finding Format:**
```markdown
**BL-PRIV-001: Vertical Privilege Escalation via Profile Update**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** A01:2021 - Broken Access Control / CWE-269
- **Location:** src/handlers/user.handler.ts:78
- **Issue:** Profile update spreads all request body fields including role/isAdmin
- **Why SAST Misses:** Cannot know that 'isAdmin' should never come from client
```

#### BL-03: Race Condition (TOCTOU)

**Detection Pattern:**
```bash
# Find check-then-act patterns
Grep: "if.*await.*\\{[\\s\\S]*await"
Grep: "getBalance|hasCredits|canPurchase|isAvailable"
```

**Vulnerable Pattern:**
```typescript
// SAST sees: conditional logic - OK
// Reality: Race window allows double-spend
async purchase(userId: string, amount: number) {
  const balance = await getBalance(userId);  // CHECK at T1
  if (balance >= amount) {
    await deductBalance(userId, amount);      // USE at T2 (race window)
  }
}
```

**Finding Format:**
```markdown
**BL-RACE-001: Double-Spend via Race Condition**
**Severity:** HIGH
**Confidence:** HIGH

- **Category:** A04:2021 - Insecure Design / CWE-362
- **Location:** src/services/payment.service.ts:34
- **Issue:** Balance check and deduction not atomic
- **Why SAST Misses:** Cannot understand timing dependencies between operations
- **PoC:** Send 10 concurrent purchase requests with balance = $100, item = $100
```

#### BL-04: State Machine Bypass

**Detection Pattern:**
```bash
# Find state transitions
Grep: "status.*=|state.*=|\\\.status|\\\.state"
Grep: "pending|approved|shipped|completed"
```

**Vulnerable Pattern:**
```typescript
// SAST sees: status update - OK
// Reality: Can ship without payment
async shipOrder(orderId: string) {
  await Order.update(orderId, { status: 'shipped' });
  // Missing: Check if status === 'paid'
}
```

**Finding Format:**
```markdown
**BL-STATE-001: Order Shipped Without Payment**
**Severity:** HIGH
**Confidence:** HIGH

- **Category:** A04:2021 - Insecure Design / CWE-841
- **Location:** src/services/order.service.ts:123
- **Issue:** shipOrder() doesn't verify order is in 'paid' state
- **Why SAST Misses:** Cannot understand valid workflow sequences
```

---

## Part 3: Cross-File Relationship Analysis

### What SAST Often Misses

SAST tools analyze files in isolation. Security issues spanning multiple files require manual correlation.

| Pattern | Files Involved | What to Look For |
|---------|---------------|------------------|
| **Inconsistent Auth** | Routes + Middleware | Some routes missing auth middleware |
| **Shared Secrets** | Multiple services | Same secret used across services |
| **Incomplete Validation** | API + Service | Validation in API but not service |
| **Trust Boundary Violations** | Internal services | Internal service trusts external input |

### Detection Approach

```bash
# Find all route definitions
Grep: "app.get|app.post|router.get|router.post|@Get|@Post"

# Check for auth middleware presence
# RED FLAG: Route without authMiddleware in the chain

# Find all validation points
Grep: "validate|sanitize|Joi|Zod|yup"
# RED FLAG: Validation only at one layer
```

### Finding Template - Cross-File

```markdown
**CROSS-001: Inconsistent Authentication Middleware**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** A01:2021 - Broken Access Control / CWE-862
- **Locations:**
  - src/routes/user.routes.ts:15 - HAS auth middleware
  - src/routes/user.routes.ts:20 - MISSING auth middleware
- **Issue:** Related endpoints have inconsistent auth protection
- **Why SAST Misses:** Analyzes files in isolation; cannot correlate routes
```

---

## Part 4: Context-Dependent Vulnerabilities

### Vulnerabilities That Depend on Context

| Code Pattern | Secure Context | Insecure Context |
|--------------|---------------|------------------|
| `eval(input)` | Input from config file | Input from user |
| `MD5(data)` | Cache key generation | Password hashing |
| `http://url` | Internal service mesh | External communication |
| `jwt.decode()` | Logging/debugging | Authentication decisions |

### Detection Approach

```bash
# Find potentially dangerous patterns
Grep: "eval\\(|new Function\\(|setTimeout\\(.*,"
Grep: "createHash.*md5|createHash.*sha1"
Grep: "jwt.decode\\("

# For each: trace input source
# CRITICAL if: input comes from user/network
# LOW if: input comes from trusted config
```

### Finding Template - Context-Dependent

```markdown
**CTX-001: MD5 Used for Password Hashing**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** A02:2021 - Cryptographic Failures / CWE-328
- **Location:** src/services/auth.service.ts:45
- **Issue:** MD5 used for security-critical password hashing
- **Context:** Input is user password (security-critical)
- **Why SAST May Miss:** Some tools flag MD5 unconditionally; context matters
- **Note:** MD5 for non-security purposes (cache keys) is acceptable
```

---

## Part 5: Multi-Tenant Security

### What SAST Cannot Understand

Multi-tenant isolation requires understanding that data belongs to specific tenants.

| Tenant Issue | Detection Pattern | Risk |
|--------------|-------------------|------|
| **Data Leakage** | Query without tenant filter | Tenant A sees Tenant B data |
| **Cross-Tenant Access** | API without tenant validation | Access other tenant resources |
| **Tenant Escalation** | Tenant ID from client | Switch to different tenant |

### Detection Approach

```bash
# Find database queries
Grep: "find\\(|findOne\\(|query\\(|select.*from"

# Check for tenant filtering
# RED FLAG: Query without tenantId in WHERE clause
Grep: "tenantId|tenant_id|organizationId"
```

### Finding Template - Multi-Tenant

```markdown
**TENANT-001: Missing Tenant Isolation in Query**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** A01:2021 - Broken Access Control
- **Location:** src/repositories/document.repo.ts:34
- **Issue:** findAll() query lacks tenant filter
- **Code:** `SELECT * FROM documents WHERE type = ?` (missing: AND tenant_id = ?)
- **Impact:** Users can see documents from other tenants
- **Why SAST Misses:** Cannot understand multi-tenant data isolation requirements
```

---

## Part 6: API Design Security

### Design-Level API Security Issues

| Issue | What to Look For | Why SAST Misses |
|-------|------------------|-----------------|
| **Missing Rate Limiting** | No rate limit middleware | Doesn't analyze config/design |
| **Verbose Errors** | Stack traces in responses | May not trace to production |
| **CORS Wildcards** | `origin: '*'` with credentials | May not understand risk |
| **JWT in URL** | Token in query string | Doesn't understand logging risk |

### Detection in Code

```bash
# Find CORS configuration
Grep: "cors\\(|Access-Control-Allow-Origin"
# RED FLAG: origin: '*' or origin: true

# Find error handlers
Grep: "catch.*res\\.send|catch.*res\\.json"
# RED FLAG: err.stack or full error object in response

# Find JWT handling
Grep: "req.query.token|req.params.token"
# RED FLAG: Token in URL (logged in access logs)
```

---

## Part 7: Infrastructure-as-Code Security

### What SAST Tools Often Miss in IaC

| IaC Issue | Detection | Why Missed |
|-----------|-----------|------------|
| **Overly Permissive IAM** | `Action: '*'`, `Resource: '*'` | May not understand IAM risks |
| **Secrets in Env Vars** | Hardcoded in template | Not always flagged |
| **Public S3 Buckets** | Missing access blocks | May not trace to exposure |
| **Missing Encryption** | No encryption configuration | Doesn't understand defaults |

### Detection Patterns

```bash
# Find IaC files
Glob: **/template.yaml, **/*.tf, **/cdk*.ts

# Check IAM policies
Grep: "Action.*\\*|Resource.*\\*"
# RED FLAG: Wildcards in production IAM

# Check for secrets
Grep: "Environment.*Variables|env:"
# Then search for: password, secret, key, token

# Check security groups
Grep: "0\\.0\\.0\\.0/0|::/0"
# RED FLAG: Open to world on sensitive ports
```

---

## Summary: Manual Review Checklist

### For Every Security Review

- [ ] **Design Documents**: Review HLD, API specs for security gaps
- [ ] **Authorization Logic**: Check ownership validation on all resource access
- [ ] **Privilege Boundaries**: Verify role/permission comes from server
- [ ] **Race Conditions**: Find check-then-act patterns without atomicity
- [ ] **State Machines**: Verify state transitions are validated
- [ ] **Cross-File**: Check auth middleware consistency across routes
- [ ] **Multi-Tenant**: Verify tenant isolation in all queries
- [ ] **Context Analysis**: Trace inputs for dangerous functions

### Red Flags That Require Manual Analysis

```bash
# Business Logic
Grep: "params.id" without "ownerId|userId|currentUser"
Grep: "req.body.role|req.body.isAdmin"
Grep: "if.*await.*await" (check-then-act)
Grep: "status.*=.*req|state.*=.*req"

# Design Gaps
# Missing: MFA, rate limiting, session timeout in design docs

# Cross-File
# Routes without consistent auth middleware

# Multi-Tenant
# Queries without tenant filter
```

---

## References

- OWASP Testing Guide: Business Logic Testing
- CWE-639: Authorization Bypass Through User-Controlled Key
- CWE-362: Concurrent Execution Using Shared Resource
- CWE-841: Improper Enforcement of Behavioral Workflow
