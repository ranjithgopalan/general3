# Data Privacy Patterns - Compliance Index

Split by compliance framework for selective loading.

## Quick Reference

| Framework | File | Focus | Key Patterns |
|-----------|------|-------|--------------|
| **General PII** | `pii-detection.md` | PII pattern detection | SSN, credit cards, emails, phones |
| **GDPR** | `gdpr-compliance.md` | EU data protection | Consent, right to erasure, data portability |
| **CCPA** | `ccpa-compliance.md` | California privacy | Do Not Sell, opt-out, disclosure |
| **PCI-DSS** | `pci-dss-compliance.md` | Payment card security | Card data storage, transmission, logging |
| **HIPAA** | `hipaa-compliance.md` | Healthcare data | PHI protection, minimum necessary, audit trails |

## Usage with Grep

**Selective loading:**
```bash
# Check for PII patterns
Grep "SSN|credit.*card|\\d{3}-\\d{2}-\\d{4}" privacy/pii-detection.md

# Check GDPR requirements
Grep "consent|right.*erasure|data.*portability" privacy/gdpr-compliance.md

# Check for payment card data
Grep "card.*number|CVV|PAN" privacy/pci-dss-compliance.md
```

## Token Savings

**Before:** Single 711-line file (all frameworks loaded together)
**After:** Load only relevant framework (~150 lines each)
**Savings:** ~75% when checking single framework
