# General PII Detection Patterns

## Detection Patterns

```bash
# SSN (Social Security Number)
Grep: "\d{3}-\d{2}-\d{4}|\d{9}"

# Credit Card Numbers
Grep: "\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}"

# Email Addresses
Grep: "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"

# Phone Numbers
Grep: "\(?\d{3}\)?[-\s]?\d{3}[-\s]?\d{4}"

# IP Addresses
Grep: "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"
```

## Logging Hygiene

**Check for PII in logs:**
```bash
Grep: "log.*email|log.*ssn|log.*phone|log.*address"
Grep: "console.log.*user|logger.*password"
```

**Severity:** HIGH (PII exposure in logs)
**RP Level:** RP3 (30 days)
