# GDPR Compliance Patterns

**Regulation:** EU General Data Protection Regulation
**Key Articles:** Article 25 (Data Protection by Design), Article 32 (Security), Article 17 (Right to Erasure)

## Detection Patterns

```bash
# Consent management
Grep: "consent|opt-in|cookie.*accept"

# Right to erasure (delete user data)
Grep: "deleteUser|removeUser|eraseData"

# Data portability
Grep: "exportData|downloadData|dataExport"

# Data minimization
Grep: "SELECT \*|find\(\{\}\)"  # Over-collection
```

## Key Requirements

**Severity:** HIGH for GDPR violations
**Common Issues:** Missing consent, no data deletion, excessive data collection

Reference: `finding-templates.md` for compliance finding format.
