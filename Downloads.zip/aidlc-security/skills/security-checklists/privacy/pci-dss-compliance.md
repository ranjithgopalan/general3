# PCI-DSS Compliance Patterns

**Standard:** Payment Card Industry Data Security Standard
**Requirements:** 3 (Protect stored cardholder data), 4 (Encrypt transmission), 10 (Track and monitor)

## Detection Patterns

```bash
# Card data in code/logs
Grep: "card.*number|CVV|cvv|cardNumber"
Grep: "PAN|Primary.*Account.*Number"

# Unencrypted storage
Grep: "cardData.*=|creditCard.*="

# Card data in logs
Grep: "log.*card|log.*CVV|console.*card"
```

## Key Requirements

**CRITICAL:** Never store CVV/CV2, encrypt PAN at rest
**Severity:** CRITICAL for card data exposure
**RP Level:** RP1 (24-48 hours)

Reference: `finding-templates.md`
