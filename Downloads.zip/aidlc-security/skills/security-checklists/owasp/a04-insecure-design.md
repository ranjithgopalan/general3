# A04:2021 - Insecure Design

**Risk:** Flawed architecture or missing security controls by design.

**CWEs:** CWE-362 (Race Conditions), CWE-841 (State Machine Bypass)

## Detection Patterns

```bash
# Race Conditions (TOCTOU)
Grep: "if.*await.*{[^}]*await"
Grep: "getBalance.*deduct|check.*then"

# State Machine Bypass
Grep: "status.*=|state.*="
Grep: "workflow|transition"
```

## Key Example: Race Condition

**Vulnerable:**
```typescript
if (await getBalance(userId) >= amount) {
  await deduct Balance(userId, amount);  // Race window!
}
```

**Secure:**
```typescript
await db.transaction(async tx => {
  const balance = await tx.query('SELECT balance FOR UPDATE');
  if (balance < amount) throw new Error();
  await tx.query('UPDATE balance = balance - $1', [amount]);
});
```

**Reference:** See `business-logic-patterns.md` for detailed race condition examples.
