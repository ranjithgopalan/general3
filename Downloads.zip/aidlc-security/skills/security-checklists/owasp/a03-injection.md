# A03:2021 - Injection

**Risk:** Malicious input executed as code or commands.

**Severity:** CRITICAL to HIGH
**CWEs:** CWE-79 (XSS), CWE-89 (SQL Injection), CWE-78 (Command Injection), CWE-943 (NoSQL Injection)

---

## Detection Patterns

### SQL Injection
```bash
Grep: "query.*\\$\\{|SELECT.*\\$\\{|INSERT.*\\$\\{"
Grep: "query\\(.*\\+.*\\)|db\\.raw\\("
# Look for: String concatenation in SQL queries
```

### Command Injection
```bash
Grep: "exec\\(|execSync\\(|spawn\\("
Grep: "child_process"
# Look for: User input in shell commands
```

### XSS (Cross-Site Scripting)
```bash
Grep: "innerHTML|dangerouslySetInnerHTML"
Grep: "\\.html\\(|document\\.write"
# Look for: User input rendered as HTML
```

### NoSQL Injection
```bash
Grep: "find\\(req\\.body|find\\(.*query\\)"
Grep: "\\$where|\\$regex"
# Look for: User input in NoSQL queries without validation
```

---

## Key Examples (Reduced from 12 to 4)

### Example 1: SQL Injection

**Vulnerable:**
```typescript
async getUser(userId: string) {
  return await db.query(`SELECT * FROM users WHERE id = ${userId}`);
  // String concatenation = SQL injection!
}
```

**Secure:**
```typescript
async getUser(userId: string) {
  return await db.query('SELECT * FROM users WHERE id = $1', [userId]);
  // Parameterized query prevents injection
}
```

### Example 2: Command Injection

**Vulnerable:**
```typescript
import { exec } from 'child_process';

async convertFile(filename: string) {
  exec(`convert ${filename} output.pdf`);  // Command injection!
}
```

**Secure:**
```typescript
import { execFile } from 'child_process';

async convertFile(filename: string) {
  // Validate filename first
  if (!/^[a-zA-Z0-9_-]+\\.txt$/.test(filename)) {
    throw new Error('Invalid filename');
  }
  // Use execFile with array args (no shell interpretation)
  execFile('convert', [filename, 'output.pdf']);
}
```

### Example 3: XSS

**Vulnerable:**
```typescript
function displayMessage(msg: string) {
  document.getElementById('message').innerHTML = msg;  // XSS!
}
```

**Secure:**
```typescript
function displayMessage(msg: string) {
  document.getElementById('message').textContent = msg;  // Safe
  // Or use framework escaping: React, Angular auto-escape by default
}
```

### Example 4: NoSQL Injection

**Vulnerable:**
```typescript
async findUsers(query: any) {
  return await User.find(query);  // query = req.body directly!
  // Attack: {"$where": "sleep(5000) || true"}
}
```

**Secure:**
```typescript
async findUsers(name: string, role: string) {
  // Whitelist allowed fields
  const query: any = {};
  if (name) query.name = name;
  if (role) query.role = role;
  return await User.find(query);
}
```

---

## Finding Template

**Use:** `skills/security-checklists/finding-templates.md`

**Finding ID Format:** `A03-{TYPE}-{NUMBER}`
- `A03-SQL-001` - SQL injection
- `A03-CMD-001` - Command injection
- `A03-XSS-001` - Cross-site scripting
- `A03-NOSQL-001` - NoSQL injection

**Typical Severity:** CRITICAL (SQL/Command), HIGH (XSS/NoSQL)
**Typical RP Level:** RP2 (14 days)

---

## Why SAST/DAST Misses This

**SAST Can Find:**
- String concatenation patterns in SQL
- innerHTML usage

**SAST Cannot Determine:**
- Whether input comes from trusted vs untrusted source
- If sanitization happens in another file
- Complex data flow across functions

**DAST Can Find:**
- Some injection through fuzzing
- XSS with payloads

**DAST Cannot Find:**
- Second-order injection
- Blind injection without visible errors

**Requires:** Manual code review to trace data flow and validate input handling.
