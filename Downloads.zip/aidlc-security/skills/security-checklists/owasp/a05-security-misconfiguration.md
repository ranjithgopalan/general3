# A05:2021 - Security Misconfiguration

**Risk:** Insecure default configurations or exposed debug features.
**CWEs:** CWE-16, CWE-200, CWE-209

## Detection Patterns
```bash
Grep: "DEBUG.*true|NODE_ENV.*development"
Grep: "console.log|debugger"
Grep: "CORS.*\*|Access-Control-Allow-Origin.*\*"
Grep: "err.stack|error.stack"
```

## Key Example
**Vulnerable:** `CORS({ origin: '*' })`  
**Secure:** `CORS({ origin: process.env.ALLOWED_ORIGINS })`
