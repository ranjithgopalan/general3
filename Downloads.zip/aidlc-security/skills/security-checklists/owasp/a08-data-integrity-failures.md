# A08:2021 - Software and Data Integrity Failures

**Risk:** Insecure deserialization, untrusted updates.
**CWEs:** CWE-502 (Deserialization), CWE-829 (Untrusted Control Sphere)

## Detection Patterns
```bash
Grep: "JSON.parse.*req|deserialize"
Grep: "eval|Function\(|vm\.runInNewContext"
Grep: "__proto__|constructor\.prototype"
```

## Key Example
**Vulnerable:** `const data = JSON.parse(req.body); obj = {...obj, ...data}`  
**Secure:** Validate with schema, whitelist fields
