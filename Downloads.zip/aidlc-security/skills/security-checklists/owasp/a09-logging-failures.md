# A09:2021 - Security Logging and Monitoring Failures

**Risk:** Insufficient logging or sensitive data in logs.
**CWEs:** CWE-778 (Insufficient Logging), CWE-532 (Information Exposure Through Log Files)

## Detection Patterns
```bash
# Missing logging on security events
Grep: "login|authenticate" (check for audit logging)

# Sensitive data in logs
Grep: "log.*password|log.*token|log.*secret"
```

## Key Examples
**Bad:** `logger.info({user, password})`  
**Good:** `logger.info({user, action: 'login', success: true})`
