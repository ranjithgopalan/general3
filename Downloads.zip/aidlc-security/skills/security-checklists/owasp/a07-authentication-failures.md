# A07:2021 - Identification and Authentication Failures

**Risk:** Broken authentication allows attackers to assume user identities.

**Severity:** CRITICAL
**CWEs:** CWE-287 (Improper Auth), CWE-384 (Session Fixation), CWE-613 (Session Timeout)

---

## Detection Patterns

### JWT Vulnerabilities
```bash
Grep: "jwt\\.verify|jwt\\.decode"
Grep: "jsonwebtoken"
# Look for: Missing algorithm validation, decode vs verify
```

### Weak Session Management
```bash
Grep: "maxAge|expires|session"
Grep: "cookie.*httpOnly|cookie.*secure"
# Look for: Long sessions, insecure cookies
```

### Missing Re-authentication
```bash
Grep: "changePassword|updatePassword"
Grep: "currentPassword|oldPassword"
# Look for: Sensitive operations without re-auth
```

---

## Key Examples (2 only)

### Example 1: JWT Algorithm Confusion

**Vulnerable:**
```typescript
const decoded = jwt.verify(token, secret);  // Missing algorithms!
// Attack: Change alg to "none", remove signature
```

**Secure:**
```typescript
const decoded = jwt.verify(token, secret, {
  algorithms: ['HS256']  // Whitelist allowed algorithms
});
```

### Example 2: Session Too Long

**Vulnerable:**
```typescript
session({
  cookie: { maxAge: 86400000 }  // 24 hours > 60 min limit
})
```

**Secure:**
```typescript
session({
  cookie: {
    maxAge: 3600000,  // 60 minutes
    httpOnly: true,
    secure: true,
    sameSite: 'strict'
  }
})
```

---

## Finding Template

**Use:** `skills/security-checklists/finding-templates.md`

**Finding ID:** `A07-{TYPE}-{NUMBER}`
**Typical Severity:** CRITICAL to HIGH
**Typical RP Level:** RP2-RP3
