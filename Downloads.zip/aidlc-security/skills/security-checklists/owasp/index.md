# OWASP Top 10 (2021) - Category Index

Quick reference for OWASP Top 10 vulnerability categories. Each category has a dedicated file with detection patterns and examples.

## Quick Reference Table

| Category | File | Risk | Detection | Key CWEs |
|----------|------|------|-----------|----------|
| **A01** Broken Access Control | `a01-broken-access-control.md` | User accesses unauthorized resources | Context-dependent | CWE-639, CWE-862, CWE-269 |
| **A02** Cryptographic Failures | `a02-cryptographic-failures.md` | Sensitive data exposed | Pattern matching | CWE-327, CWE-328, CWE-798 |
| **A03** Injection | `a03-injection.md` | Malicious input executed | Pattern matching | CWE-79, CWE-89, CWE-78 |
| **A04** Insecure Design | `a04-insecure-design.md` | Flawed architecture | Design review | CWE-362, CWE-841 |
| **A05** Security Misconfiguration | `a05-security-misconfiguration.md` | Insecure settings | Config scan | CWE-16, CWE-200 |
| **A06** Vulnerable Components | `a06-vulnerable-components.md` | Known CVEs in dependencies | Automated | CWE-1104 |
| **A07** Auth Failures | `a07-authentication-failures.md` | Broken authentication | Pattern matching | CWE-287, CWE-384, CWE-613 |
| **A08** Data Integrity Failures | `a08-data-integrity-failures.md` | Untrusted deserialization | Context-dependent | CWE-502, CWE-829 |
| **A09** Logging Failures | `a09-logging-failures.md` | Missing/insecure logging | Review needed | CWE-778, CWE-532 |
| **A10** SSRF | `a10-server-side-request-forgery.md` | Internal network access | Pattern matching | CWE-918 |

## Usage

**From agents:**
```bash
# Use Grep to find specific category (more efficient than Read)
Grep -n "^## A01:" plugins/AIDLC-security/skills/security-checklists/owasp/

# Or read specific category file directly
Read plugins/AIDLC-security/skills/security-checklists/owasp/a01-broken-access-control.md
```

**Finding specific patterns:**
```bash
# Search for IDOR detection patterns
Grep "IDOR|Horizontal.*Escalation" plugins/AIDLC-security/skills/security-checklists/owasp/a01-broken-access-control.md

# Search for SQL injection patterns
Grep "SQL.*injection|query.*concatenation" plugins/AIDLC-security/skills/security-checklists/owasp/a03-injection.md
```

## File Contents

Each category file contains:
- **Detection Patterns** - Grep commands to find vulnerabilities
- **Key Examples** - 2-3 most common patterns (REDUCED from 10+)
- **Finding Reference** - Links to finding-templates.md for format

## Why Split?

**Before:** Single 993-line file loaded entirely
**After:** Load only needed category (~100 lines each)
**Token Savings:** ~85% when checking specific OWASP categories

## Categories by Severity

**CRITICAL (if exploited):**
- A01 - Broken Access Control
- A02 - Cryptographic Failures
- A03 - Injection
- A07 - Auth Failures

**HIGH:**
- A04 - Insecure Design
- A08 - Data Integrity Failures

**MEDIUM:**
- A05 - Security Misconfiguration
- A09 - Logging Failures
- A10 - SSRF

**MANAGED SEPARATELY:**
- A06 - Vulnerable Components (use dependency-security-reviewer)
