# A02:2021 - Cryptographic Failures

**Risk:** Sensitive data exposed due to weak or missing cryptography.

**Severity:** CRITICAL to HIGH
**CWEs:** CWE-327 (Weak Crypto), CWE-328 (Weak Hash), CWE-798 (Hardcoded Credentials)

---

## Detection Patterns

### Weak Hashing
```bash
Grep: "createHash.*md5|createHash.*sha1"
Grep: "MD5|SHA1|sha1|md5"
# Look for: MD5/SHA1 used for passwords or security
```

### Hardcoded Secrets
```bash
Grep: "password.*=.*['\"][^'\"]+['\"]"
Grep: "secret.*=.*['\"][^'\"]+['\"]"
Grep: "api[_-]?key.*=.*['\"]"
Grep: "JWT_SECRET|AWS_SECRET|PRIVATE_KEY"
# Look for: Secrets hardcoded in source
```

### Weak Encryption
```bash
Grep: "createCipheriv.*ecb|aes-.*-ecb"
Grep: "DES|3DES|RC4"
# Look for: ECB mode or deprecated algorithms
```

### Insecure Random
```bash
Grep: "Math.random\\(\\)"
Grep: "Date.now\\(\\).*token"
# Look for: Non-cryptographic randomness for security
```

---

## Key Examples (Reduced from 8 to 3)

### Example 1: Weak Password Hashing

**Vulnerable:**
```typescript
function hashPassword(password: string): string {
  return crypto.createHash('md5').update(password).digest('hex');
  // MD5 is weak, no salt!
}
```

**Secure:**
```typescript
import * as bcrypt from 'bcrypt';

async function hashPassword(password: string): Promise<string> {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
}
```

### Example 2: Hardcoded Secret

**Vulnerable:**
```typescript
const JWT_SECRET = "super-secret-key-12345";  // Hardcoded!

jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
```

**Secure:**
```typescript
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error('JWT_SECRET environment variable required');
}

jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
```

### Example 3: Insecure Random for Token

**Vulnerable:**
```typescript
function generateToken(): string {
  return Math.random().toString(36).substring(2);  // NOT cryptographic!
}
```

**Secure:**
```typescript
import * as crypto from 'crypto';

function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}
```

---

## Finding Template

**Use:** `skills/security-checklists/finding-templates.md`

**Finding ID Format:** `A02-{TYPE}-{NUMBER}`
- `A02-HASH-001` - Weak hashing algorithm
- `A02-SECRET-001` - Hardcoded secret
- `A02-RANDOM-001` - Insecure randomness

**Typical Severity:** CRITICAL (passwords, secrets), HIGH (tokens, encryption)
**Typical RP Level:** RP2-RP3 (14-30 days)

---

## Why SAST/DAST Misses This

**SAST Can Find:**
- MD5/SHA1 usage (pattern matching)
- Hardcoded strings that look like secrets

**SAST Cannot Determine:**
- Context: Is MD5 for cache key (OK) or password (BAD)?
- Whether hardcoded value is actually sensitive

**DAST Cannot See:**
- Server-side cryptographic implementations
- How secrets are managed

**Requires:** Manual review to understand security context.
