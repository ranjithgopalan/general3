# A01:2021 - Broken Access Control

**Risk:** Users access data or perform actions outside their permissions.

**Severity:** CRITICAL
**CWEs:** CWE-639 (IDOR), CWE-862 (Missing Auth), CWE-269 (Privilege Escalation)

---

## Detection Patterns

### Horizontal Privilege Escalation (IDOR)
```bash
Grep: "params.id|params.userId|params.resourceId"
Grep: "findById|getById|findOne.*id"
Grep: "req.body.id|req.body.userId"
# Look for: Direct ID usage without ownership check
```

### Vertical Privilege Escalation
```bash
Grep: "req.body.role|req.body.isAdmin|req.body.permissions"
Grep: "role.*=.*req|isAdmin.*=.*req"
Grep: "Object.assign.*req.body"
# Look for: Role/permission from client input
```

### Missing Authorization
```bash
Grep: "app.get|app.post|router.get|router.post"
Grep: "@Public|@SkipAuth|@AllowAnonymous"
# Look for: Routes without auth middleware
```

---

## Key Examples (Reduced from 10 to 3)

### Example 1: IDOR - No Ownership Check

**Vulnerable:**
```typescript
async getDocument(req: Request) {
  const doc = await Document.findById(req.params.id);
  return doc;  // Any user can access any document!
}
```

**Secure:**
```typescript
async getDocument(req: Request) {
  const doc = await Document.findById(req.params.id);
  if (doc.ownerId !== req.user.id) {
    throw new ForbiddenError('Access denied');
  }
  return doc;
}
```

### Example 2: Vertical Privilege Escalation

**Vulnerable:**
```typescript
async updateUser(req: Request) {
  await User.updateOne(
    { _id: req.user.id },
    { $set: req.body }  // Can include { isAdmin: true }
  );
}
```

**Secure:**
```typescript
async updateUser(req: Request) {
  const allowedFields = ['name', 'email', 'avatar'];
  const updates = pick(req.body, allowedFields);
  await User.updateOne({ _id: req.user.id }, { $set: updates });
}
```

### Example 3: Missing Function-Level Access Control

**Vulnerable:**
```typescript
router.get('/admin/users', getAllUsers);  // No auth middleware!
```

**Secure:**
```typescript
router.get('/admin/users', authMiddleware, adminOnly, getAllUsers);
```

---

## Finding Template

**Use standardized template from:** `skills/security-checklists/finding-templates.md`

**Finding ID Format:** `A01-{TYPE}-{NUMBER}`
- `A01-IDOR-001` - Horizontal privilege escalation
- `A01-PRIV-001` - Vertical privilege escalation
- `A01-AUTH-001` - Missing authorization

**Typical Severity:** CRITICAL
**Typical RP Level:** RP2 (14 days)

---

## Why SAST/DAST Misses This

**SAST Limitations:**
- Cannot understand business logic (e.g., "users should only see their own data")
- Cannot determine ownership requirements
- Sees `findById()` as legitimate database call

**DAST Limitations:**
- Would need multiple valid user tokens
- Requires understanding of authorization model
- Cannot enumerate all ID combinations

**Requires:** Manual review of authorization logic and business requirements.
