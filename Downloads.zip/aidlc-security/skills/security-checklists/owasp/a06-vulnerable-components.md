# A06:2021 - Vulnerable and Outdated Components

**Risk:** Known CVEs in dependencies.
**CWE:** CWE-1104

## Detection
Use `dependency-security-reviewer` agent which runs:
- `npm audit --json`
- `npm outdated`

## Patterns
```bash
Grep: "package.json|package-lock.json|yarn.lock"
```

**Note:** This category is best handled by automated tools (npm audit, Snyk, Dependabot).
