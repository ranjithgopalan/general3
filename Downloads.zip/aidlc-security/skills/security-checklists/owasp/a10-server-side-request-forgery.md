# A10:2021 - Server-Side Request Forgery (SSRF)

**Risk:** Server makes requests to attacker-controlled URLs.
**CWE:** CWE-918

## Detection Patterns
```bash
Grep: "fetch\(req|axios\(req|request\(req"
Grep: "http.get|https.request"
# Look for: User input in URL
```

## Key Example
**Vulnerable:**
```typescript
const data = await fetch(req.body.url);  // SSRF!
```

**Secure:**
```typescript
const allowedHosts = ['api.example.com'];
const url = new URL(req.body.url);
if (!allowedHosts.includes(url.hostname)) {
  throw new Error('Invalid URL');
}
```
