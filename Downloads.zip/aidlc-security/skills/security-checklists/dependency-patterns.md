# Dependency Security Patterns Checklist

Reference checklist for dependency-security-reviewer agent.

This checklist covers:
- Known CVE detection in dependencies
- Outdated packages with security patches
- Commonly vulnerable packages
- Prioritized remediation guidance
- Package manifest analysis

---

## Quick Reference - Audit Commands

| Package Manager | Audit Command | Outdated Command |
|----------------|---------------|------------------|
| npm | `npm audit --json` | `npm outdated --json` |
| yarn | `yarn audit --json` | `yarn outdated` |
| pnpm | `pnpm audit --json` | `pnpm outdated` |

---

## CVE Severity Mapping

| npm Audit Severity | CVSS Score Range | Action Timeline |
|-------------------|------------------|-----------------|
| **critical** | 9.0 - 10.0 | Immediate (24-48h) |
| **high** | 7.0 - 8.9 | Short-term (1 week) |
| **moderate** | 4.0 - 6.9 | Medium-term (1 sprint) |
| **low** | 0.1 - 3.9 | Backlog |

---

## Commonly Vulnerable Packages

### High-Risk Packages (Check Versions)

| Package | Known Issues | Vulnerable Versions | Fixed Version | CVEs |
|---------|--------------|--------------------| --------------|------|
| `lodash` | Prototype pollution | < 4.17.21 | 4.17.21+ | CVE-2021-23337, CVE-2020-8203 |
| `axios` | SSRF, header injection | < 1.6.0 | 1.6.0+ | CVE-2023-45857 |
| `jsonwebtoken` | Algorithm confusion | < 9.0.0 | 9.0.0+ | CVE-2022-23529 |
| `express` | Various | < 4.19.2 | 4.19.2+ | Multiple |
| `node-fetch` | SSRF | < 2.6.7 | 2.6.7+ | CVE-2022-0235 |
| `minimist` | Prototype pollution | < 1.2.6 | 1.2.6+ | CVE-2021-44906 |
| `qs` | Prototype pollution | < 6.10.3 | 6.10.3+ | CVE-2022-24999 |
| `shell-quote` | Command injection | < 1.7.3 | 1.7.3+ | CVE-2021-42740 |
| `ansi-regex` | ReDoS | < 5.0.1 | 5.0.1+ | CVE-2021-3807 |
| `glob-parent` | ReDoS | < 5.1.2 | 5.1.2+ | CVE-2020-28469 |

### Deprecated Packages (Replace)

| Package | Status | Recommended Replacement |
|---------|--------|------------------------|
| `moment` | Deprecated (maintenance only) | `date-fns`, `dayjs`, `luxon` |
| `request` | Deprecated | `axios`, `node-fetch`, `got` |
| `uuid` v3.x | Deprecated | `uuid` v9.x |
| `querystring` | Deprecated | `URLSearchParams` (built-in) |
| `url` | Deprecated | `URL` (built-in) |

### Supply Chain Attack Victims

| Package | Attack Type | Affected Versions | Notes |
|---------|-------------|-------------------|-------|
| `ua-parser-js` | Malicious code injection | 0.7.29, 0.8.0, 1.0.0 | Use 0.7.31+, 0.8.1+, 1.0.2+ |
| `coa` | Malicious code | 2.0.3, 2.0.4, 2.1.1, 2.1.3, 3.0.1, 3.1.3 | Use known safe versions |
| `rc` | Malicious code | 1.2.9, 1.3.9, 2.3.9 | Use 1.2.8 or verified versions |
| `event-stream` | Malicious dependency | 3.3.6 | Use 4.0.0+ |

---

## Vulnerability Categories

### Remote Code Execution (RCE) - CRITICAL

```bash
# Detection patterns in npm audit
Grep: "remote code execution|RCE|arbitrary code"
```

**High-Risk Patterns:**
- Prototype pollution leading to code injection
- Unsafe deserialization
- Template injection
- Command injection through shell libraries

**Example Vulnerable Code Path:**
```javascript
// Vulnerable: lodash < 4.17.21 prototype pollution
const _ = require('lodash');
_.merge({}, JSON.parse(userInput)); // Can lead to RCE
```

### Prototype Pollution - CRITICAL/HIGH

```bash
# Common vulnerable packages
Grep: "prototype pollution"
```

**Affected Packages:**
| Package | Vulnerable Function | Fix |
|---------|--------------------| ----|
| lodash | `merge`, `set`, `setWith` | Upgrade to 4.17.21+ |
| minimist | Argument parsing | Upgrade to 1.2.6+ |
| qs | Query string parsing | Upgrade to 6.10.3+ |
| deep-extend | Object merging | Upgrade to 0.6.0+ |

### Regular Expression Denial of Service (ReDoS) - MEDIUM

```bash
# Detection in audit
Grep: "ReDoS|regular expression denial"
```

**Affected Packages:**
| Package | Issue | Fix |
|---------|-------| ----|
| ansi-regex | ReDoS in regex | 5.0.1+ |
| glob-parent | ReDoS in path parsing | 5.1.2+ |
| trim-newlines | ReDoS | 3.0.1+ |
| normalize-url | ReDoS | 6.0.1+ |

### Server-Side Request Forgery (SSRF) - HIGH

```bash
# Detection patterns
Grep: "SSRF|server-side request"
```

**Affected Packages:**
| Package | Issue | Fix |
|---------|-------| ----|
| axios | Redirect following to internal IPs | 1.6.0+ |
| node-fetch | Redirect bypass | 2.6.7+ |
| got | URL parsing issues | Check latest |

---

## Package.json Analysis

### Reading Package Manifest

```bash
# Find all package.json files
Glob: **/package.json

# Exclude node_modules
# Focus on: root, packages/*, apps/*
```

### Key Fields to Check

```json
{
  "dependencies": {
    // Production dependencies - high priority
  },
  "devDependencies": {
    // Development only - lower priority but still check
  },
  "peerDependencies": {
    // May indicate compatibility constraints
  },
  "optionalDependencies": {
    // Check if actually used
  },
  "overrides": {
    // Check if used to force vulnerable versions
  },
  "resolutions": {
    // Yarn: check for forced versions
  }
}
```

### Version Range Analysis

| Range | Meaning | Risk |
|-------|---------|------|
| `^1.0.0` | Compatible with 1.x.x | May get vulnerable minor versions |
| `~1.0.0` | Compatible with 1.0.x | Safer, patch updates only |
| `1.0.0` | Exact version | No auto-updates, may miss patches |
| `*` | Any version | HIGH RISK - avoid |
| `>=1.0.0` | Any version 1.0.0+ | HIGH RISK - avoid |

---

## Lock File Analysis

### npm (package-lock.json)

```json
{
  "packages": {
    "node_modules/package-name": {
      "version": "1.0.0",  // Actual installed version
      "resolved": "https://registry.npmjs.org/...",
      "integrity": "sha512-...",  // Integrity hash
      "dependencies": {}
    }
  }
}
```

### Key Checks:
- Actual installed version vs package.json range
- Integrity hash presence
- Resolved URL (should be official registry)
- Dependency chain depth

---

## Audit Output Parsing

### npm audit --json Structure

```json
{
  "vulnerabilities": {
    "package-name": {
      "name": "package-name",
      "severity": "critical|high|moderate|low",
      "isDirect": true,
      "via": [
        {
          "source": 1234,
          "name": "package-name",
          "dependency": "package-name",
          "title": "Vulnerability title",
          "url": "https://github.com/advisories/GHSA-...",
          "severity": "critical",
          "cwe": ["CWE-xxx"],
          "cvss": {
            "score": 9.8,
            "vectorString": "CVSS:3.1/AV:N/AC:L/..."
          },
          "range": "<1.0.0"
        }
      ],
      "effects": [],
      "range": "<1.0.0",
      "nodes": ["node_modules/package-name"],
      "fixAvailable": true
    }
  },
  "metadata": {
    "vulnerabilities": {
      "critical": 1,
      "high": 2,
      "moderate": 3,
      "low": 4,
      "total": 10
    }
  }
}
```

---

## Remediation Commands

### Quick Fixes

```bash
# Auto-fix all possible vulnerabilities
npm audit fix

# Force fix (may install breaking changes)
npm audit fix --force

# Fix specific package
npm update package-name

# Install specific version
npm install package-name@1.2.3
```

### For Transitive Dependencies

```bash
# View dependency tree
npm ls vulnerable-package

# Find why package is installed
npm explain vulnerable-package

# Override in package.json (npm 8.3+)
{
  "overrides": {
    "vulnerable-package": "^1.2.3"
  }
}

# For yarn (resolutions in package.json)
{
  "resolutions": {
    "vulnerable-package": "^1.2.3"
  }
}
```

### For Breaking Changes

```bash
# Check what would change
npm update --dry-run

# Install with legacy peer deps (if needed)
npm install package@version --legacy-peer-deps

# Create lockfile backup first
cp package-lock.json package-lock.json.backup
```

---

## Priority Matrix

| Factor | High Priority | Lower Priority |
|--------|--------------|----------------|
| Severity | critical, high | moderate, low |
| Dependency Type | Direct | Transitive |
| Code Path | Used in production | Dev/test only |
| Fix Available | Yes | No (requires major upgrade) |
| Breaking Changes | None expected | Major version upgrade |

### Prioritization Formula

```
Priority Score = Severity Weight × Dependency Weight × Usage Weight

Where:
- Severity: critical=4, high=3, moderate=2, low=1
- Dependency: direct=2, transitive=1
- Usage: production=2, devDependency=1
```

---

## Monorepo Considerations

```bash
# For npm workspaces
npm audit --workspaces

# For specific workspace
npm audit --workspace=packages/frontend

# For yarn workspaces
yarn workspaces foreach npm audit

# For lerna
lerna exec -- npm audit
```

---

## CI/CD Integration

```bash
# Fail build on critical/high
npm audit --audit-level=high

# JSON output for parsing
npm audit --json > audit-report.json

# With specific severity threshold
npm audit --audit-level=critical
```

---

## Severity Matrix

| Issue | Severity | Confidence | Action |
|-------|----------|------------|--------|
| RCE in direct dependency | CRITICAL | HIGH | Immediate |
| Prototype pollution (exploitable) | CRITICAL | HIGH | Immediate |
| SSRF in HTTP client | HIGH | HIGH | 1 week |
| XSS in template engine | HIGH | HIGH | 1 week |
| ReDoS in parser | MEDIUM | HIGH | 1 sprint |
| Information disclosure | MEDIUM | MEDIUM | 1 sprint |
| Deprecated package | LOW | HIGH | Backlog |
| Dev dependency vuln | LOW* | MEDIUM | Backlog |

*Unless used in build pipeline that affects production artifacts

---

## Quick Reference - Safe Minimum Versions

| Package | Safe Minimum | Notes |
|---------|--------------|-------|
| lodash | 4.17.21 | Prototype pollution fixes |
| axios | 1.6.0 | SSRF fixes |
| express | 4.19.2 | Various fixes |
| jsonwebtoken | 9.0.0 | Algorithm confusion fix |
| node-fetch | 2.6.7 | SSRF fix |
| minimist | 1.2.6 | Prototype pollution fix |
| qs | 6.10.3 | Prototype pollution fix |
| ansi-regex | 5.0.1 | ReDoS fix |
| glob-parent | 5.1.2 | ReDoS fix |
| shell-quote | 1.7.3 | Command injection fix |

---

## References

- [npm Security Advisories](https://www.npmjs.com/advisories)
- [GitHub Advisory Database](https://github.com/advisories)
- [Snyk Vulnerability Database](https://snyk.io/vuln/)
- [NIST NVD](https://nvd.nist.gov/)
- [OWASP Dependency Check](https://owasp.org/www-project-dependency-check/)
