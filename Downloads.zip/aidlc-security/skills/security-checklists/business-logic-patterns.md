# Business Logic Security Patterns Checklist

Reference checklist for code-security-reviewer agent.

This checklist covers detection patterns for business logic flaws that automated SAST/DAST tools cannot detect:
- Horizontal privilege escalation (User A accesses User B's data)
- Vertical privilege escalation (User becomes Admin)
- Authorization bypass patterns
- Race conditions (TOCTOU - Time of Check vs Time of Use)
- State machine bypasses (Skipping workflow steps)

---

## Quick Reference - Critical Business Logic Flaws

| Flaw Type | Detection Pattern | Severity | CWE |
|-----------|------------------|----------|-----|
| Horizontal Privilege Escalation | `params.id` without ownership check | CRITICAL | CWE-639 |
| Vertical Privilege Escalation | `req.body.role` / `req.body.isAdmin` | CRITICAL | CWE-269 |
| Authorization Bypass | Missing auth middleware on routes | CRITICAL | CWE-862 |
| Race Condition (TOCTOU) | Check-then-act without transaction | HIGH | CWE-362 |
| State Machine Bypass | Direct state change without validation | HIGH | CWE-841 |

---

## Why Automated Tools Miss These

| Flaw Type | Why SAST/DAST Cannot Detect |
|-----------|----------------------------|
| **Horizontal Escalation** | Cannot understand business requirement for resource ownership |
| **Vertical Escalation** | Cannot know that roles should come from server, not client |
| **Authorization Bypass** | Cannot determine business intent of what needs protection |
| **Race Conditions** | Cannot understand timing dependencies between operations |
| **State Machine Bypass** | Cannot understand valid workflow sequences |

---

## 1. Horizontal Privilege Escalation (IDOR)

### Definition
User A can access, modify, or delete User B's resources by manipulating resource IDs.

### Detection Patterns

```bash
# Find resource lookups by ID from request
Grep: "params.id|params.userId|params.resourceId"
Grep: "req.body.id|req.body.userId"
Grep: "findById|getById|findOne.*id"

# Find missing ownership checks
Grep: "findById.*return" without "user.id|userId|ownerId"
```

### Vulnerable Code Patterns

```typescript
// VULNERABLE: No ownership check
async getDocument(req: Request) {
  const doc = await Document.findById(req.params.id);
  return doc;  // Any user can access any document
}

// VULNERABLE: ID from request body
async updateProfile(req: Request) {
  const user = await User.findById(req.body.userId);
  return user.update(req.body.data);  // Can update other users
}

// VULNERABLE: Batch operation without filtering
async deleteDocuments(req: Request) {
  await Document.deleteMany({ _id: { $in: req.body.ids } });
  // Can delete documents belonging to other users
}
```

### Secure Code Patterns

```typescript
// SECURE: Ownership validation
async getDocument(req: Request) {
  const doc = await Document.findById(req.params.id);
  if (doc.ownerId !== req.user.id) {
    throw new ForbiddenError('Not your document');
  }
  return doc;
}

// SECURE: Filter by user
async getDocuments(req: Request) {
  return Document.find({ ownerId: req.user.id });
}

// SECURE: Scope batch operations
async deleteDocuments(req: Request) {
  await Document.deleteMany({
    _id: { $in: req.body.ids },
    ownerId: req.user.id  // Only delete user's own documents
  });
}
```

### Finding Format

```markdown
**BL-IDOR-001: Horizontal Privilege Escalation - Document Access**
**Severity:** CRITICAL
**Confidence:** HIGH

- **Category:** A01:2021 - Broken Access Control / CWE-639
- **Location:** src/handlers/document.handler.ts:45
- **Issue:** getDocument() retrieves by ID without verifying ownership
- **Vulnerable Code:**
  ```typescript
  const doc = await Document.findById(req.params.id);
  return doc;
  ```
- **Impact:** Any authenticated user can read any document
- **PoC:** `GET /api/documents/{other-user-doc-id}` with valid token
- **Remediation:** Add ownership check before returning resource
- **Why SAST Misses:** Cannot understand that documents belong to specific users
```

---

## 2. Vertical Privilege Escalation

### Definition
A regular user can elevate their privileges to admin/moderator by manipulating role-related data.

### Detection Patterns

```bash
# Find role from client input
Grep: "req.body.role|req.body.isAdmin|req.body.permissions"
Grep: "role.*=.*req|permissions.*=.*req"
Grep: "body.role|body.isAdmin|body.isModerator"

# Find user update without field filtering
Grep: "update.*req.body|save.*req.body"
Grep: "Object.assign.*req.body|spread.*req.body"
```

### Vulnerable Code Patterns

```typescript
// VULNERABLE: Role from request body
async updateUser(req: Request) {
  const user = await User.findById(req.params.id);
  user.role = req.body.role;  // User sets their own role!
  await user.save();
}

// VULNERABLE: Spread operator copies all fields including role
async updateProfile(req: Request) {
  await User.updateOne(
    { _id: req.user.id },
    { $set: { ...req.body } }  // includes isAdmin if sent
  );
}

// VULNERABLE: Object.assign copies role
async patchUser(userId: string, data: any) {
  const user = await User.findById(userId);
  Object.assign(user, data);  // data may contain role
  await user.save();
}
```

### Secure Code Patterns

```typescript
// SECURE: Whitelist allowed fields
async updateProfile(req: Request) {
  const allowedFields = ['name', 'email', 'avatar', 'bio'];
  const updates = {};
  for (const field of allowedFields) {
    if (req.body[field] !== undefined) {
      updates[field] = req.body[field];
    }
  }
  await User.updateOne({ _id: req.user.id }, { $set: updates });
}

// SECURE: Explicit DTO without sensitive fields
interface UpdateProfileDto {
  name?: string;
  email?: string;
  avatar?: string;
}
// TypeScript enforces only these fields can be set

// SECURE: Separate admin-only endpoint
@Roles('superadmin')
async setUserRole(userId: string, role: Role) {
  // Only superadmins can reach this endpoint
  await User.updateOne({ _id: userId }, { role });
}
```

---

## 3. Authorization Bypass

### Definition
Endpoints or functionality that should require authentication/authorization are accessible without proper checks.

### Detection Patterns

```bash
# Find routes without auth middleware
Grep: "app.get|app.post|router.get|router.post"
# Then check for absence of: authMiddleware, @Authorized, @UseGuards

# Find public decorators
Grep: "@Public|@SkipAuth|@AllowAnonymous"

# Find admin routes
Grep: "/admin|/management|/internal"

# Find auth bypass conditions
Grep: "if.*admin|if.*auth|skipAuth|bypassAuth"
```

### Vulnerable Code Patterns

```typescript
// VULNERABLE: Admin route without auth
router.get('/admin/users', getAllUsers);  // No middleware!

// VULNERABLE: Inconsistent middleware application
router.get('/api/orders', authMiddleware, getOrders);     // Protected
router.get('/api/orders/:id', getOrderById);              // NOT protected
router.post('/api/orders', authMiddleware, createOrder);  // Protected

// VULNERABLE: Auth bypass for testing left in production
if (process.env.SKIP_AUTH === 'true' || req.headers['x-bypass-auth']) {
  return next();
}

// VULNERABLE: Missing else clause
function checkPermission(user: User, action: string) {
  if (user.role === 'admin') {
    return true;  // Admin allowed
  }
  if (user.role === 'moderator' && action === 'view') {
    return true;  // Moderator can view
  }
  // Missing: return false for other cases!
}
```

### Secure Code Patterns

```typescript
// SECURE: Consistent auth middleware
router.use('/admin', authMiddleware, adminOnlyMiddleware);
router.get('/admin/users', getAllUsers);
router.get('/admin/stats', getStats);

// SECURE: Explicit deny by default
function checkPermission(user: User, action: string): boolean {
  if (user.role === 'admin') return true;
  if (user.role === 'moderator' && action === 'view') return true;
  return false;  // Deny by default
}

// SECURE: Guard decorator pattern
@Controller('admin')
@UseGuards(AuthGuard, RolesGuard)
@Roles('admin')
export class AdminController {
  // All routes in this controller require admin role
}
```

---

## 4. Race Conditions (TOCTOU)

### Definition
Time-of-Check to Time-of-Use vulnerabilities where the state checked at T1 may have changed by T2 when it's used.

### Detection Patterns

```bash
# Find check-then-act patterns
Grep: "if.*await.*{.*await"
Grep: "getBalance|getCredits|hasCredits|canPurchase"
Grep: "check.*then|verify.*update"

# Find non-atomic operations
Grep: "findOne.*update|find.*save"
Grep: "SELECT.*UPDATE" without "FOR UPDATE"
```

### Vulnerable Code Patterns

```typescript
// VULNERABLE: Double-spend (balance)
async purchase(userId: string, amount: number) {
  const balance = await getBalance(userId);  // T1: Check
  if (balance >= amount) {
    await deductBalance(userId, amount);      // T2: Use
    await processOrder();
  }
}
// Attack: 2 concurrent requests both see balance=100 before either deducts

// VULNERABLE: Overselling (inventory)
async buyTicket(eventId: string) {
  const event = await Event.findById(eventId);
  if (event.availableTickets > 0) {
    event.availableTickets--;
    await event.save();
  }
}
// Attack: 100 requests when 1 ticket left = -99 tickets

// VULNERABLE: Coupon reuse
async applyCoupon(code: string) {
  const coupon = await Coupon.findOne({ code });
  if (!coupon.used) {
    await applyDiscount(coupon.discount);
    coupon.used = true;
    await coupon.save();
  }
}
```

### Secure Code Patterns

```typescript
// SECURE: Database transaction with row lock
async purchase(userId: string, amount: number) {
  await db.transaction(async (tx) => {
    const [{ balance }] = await tx.query(
      'SELECT balance FROM accounts WHERE user_id = $1 FOR UPDATE',
      [userId]
    );
    if (balance < amount) throw new Error('Insufficient funds');
    await tx.query(
      'UPDATE accounts SET balance = balance - $1 WHERE user_id = $2',
      [amount, userId]
    );
  });
}

// SECURE: Atomic decrement with condition
async buyTicket(eventId: string) {
  const result = await db.query(
    `UPDATE events
     SET available_tickets = available_tickets - 1
     WHERE id = $1 AND available_tickets > 0
     RETURNING id`,
    [eventId]
  );
  if (result.rowCount === 0) {
    throw new Error('No tickets available');
  }
}

// SECURE: Atomic compare-and-swap
async applyCoupon(code: string) {
  const result = await Coupon.updateOne(
    { code, used: false },
    { $set: { used: true } }
  );
  if (result.modifiedCount === 0) {
    throw new Error('Coupon invalid or already used');
  }
}
```

---

## 5. State Machine Bypass

### Definition
Skipping required workflow steps by directly manipulating state or calling endpoints out of sequence.

### Detection Patterns

```bash
# Find state assignments
Grep: "status.*=|state.*=|\.status.*=|\.state.*="
Grep: "update.*status|update.*state"

# Find workflow/state keywords
Grep: "pending|approved|rejected|shipped|completed|cancelled"
Grep: "workflow|transition|nextState|previousState"

# Find state from client input
Grep: "req.body.status|req.body.state"
```

### Vulnerable Code Patterns

```typescript
// VULNERABLE: Direct state change without validation
async shipOrder(orderId: string) {
  await Order.updateOne({ _id: orderId }, { status: 'shipped' });
  // Missing: Must check if paid first!
}

// VULNERABLE: State from client input
async updateOrder(orderId: string, data: any) {
  await Order.updateOne({ _id: orderId }, { status: data.status });
  // Client can set any status: pending → shipped directly
}

// VULNERABLE: Missing state prerequisite
async disburseLoan(loanId: string) {
  const loan = await Loan.findById(loanId);
  await transferFunds(loan.accountId, loan.amount);
  loan.status = 'disbursed';
  await loan.save();
  // Missing: Must check if approved first!
}
```

### Secure Code Patterns

```typescript
// SECURE: State machine with valid transitions
const ORDER_TRANSITIONS: Record<string, string[]> = {
  'pending': ['paid', 'cancelled'],
  'paid': ['processing'],
  'processing': ['shipped'],
  'shipped': ['delivered', 'returned'],
};

async updateOrderStatus(orderId: string, newStatus: string) {
  const order = await Order.findById(orderId);
  const validNextStates = ORDER_TRANSITIONS[order.status] || [];

  if (!validNextStates.includes(newStatus)) {
    throw new InvalidTransitionError(
      `Cannot go from ${order.status} to ${newStatus}`
    );
  }

  order.status = newStatus;
  await order.save();
}

// SECURE: Explicit prerequisite checks
async shipOrder(orderId: string) {
  const order = await Order.findById(orderId);

  if (order.status !== 'processing') {
    throw new Error('Order must be in processing state');
  }
  if (!order.paymentConfirmed) {
    throw new Error('Payment not confirmed');
  }
  if (!order.shippingAddress) {
    throw new Error('Shipping address required');
  }

  order.status = 'shipped';
  order.shippedAt = new Date();
  await order.save();
}
```

---

## Severity Matrix

| Flaw Type | Direct Exploitation | Data Breach Risk | Severity |
|-----------|--------------------| -----------------|----------|
| Horizontal Escalation | Easy | High (access other users' data) | CRITICAL |
| Vertical Escalation | Easy | Critical (full admin access) | CRITICAL |
| Authorization Bypass | Easy | Varies by endpoint | CRITICAL |
| Race Condition | Moderate | Financial loss | HIGH |
| State Machine Bypass | Moderate | Business logic violation | HIGH |

---

## Detection Checklist

### For Every Endpoint

- [ ] Does it access resources by ID? → Check ownership validation
- [ ] Does it modify user data? → Check field whitelisting
- [ ] Does it have auth middleware? → Check consistency
- [ ] Does it involve multiple steps? → Check atomicity
- [ ] Does it change state? → Check valid transitions

### Red Flags to Search For

```bash
# High confidence vulnerability indicators
Grep: "params.id.*findById.*return"  # IDOR
Grep: "req.body.role|req.body.isAdmin"  # Privilege escalation
Grep: "if.*await.*{.*await"  # Race condition
Grep: "status.*=.*req.body"  # State manipulation
```

---

## References

- OWASP Testing Guide: Business Logic Testing
- CWE-639: Authorization Bypass Through User-Controlled Key
- CWE-269: Improper Privilege Management
- CWE-362: Concurrent Execution using Shared Resource
- CWE-841: Improper Enforcement of Behavioral Workflow
