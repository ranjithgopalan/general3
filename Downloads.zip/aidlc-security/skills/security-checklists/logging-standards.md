# Enterprise Logging Standards Checklist

Reference checklist for code-security-reviewer agent.

This checklist provides detection patterns and requirements for enterprise logging compliance including structured logging, timestamp formats, and security event coverage.

---

## Quick Reference - Logging Requirements

| Requirement | Standard | Severity if Non-Compliant |
|-------------|----------|---------------------------|
| Log Format | Structured (JSON/XML) | MEDIUM |
| Timestamp Format | ISO 8601 with timezone | MEDIUM |
| Timestamp Position | Start of log entry | LOW |
| Required Fields | Action, Source, Destination, Description | MEDIUM |
| Security Event Logging | Auth, access, account events | HIGH |
| PII in Logs | Must be masked/redacted | CRITICAL |

---

## Required Log Format

All logs must use a structured format (JSON or XML) rather than unstructured text.

| Element | Description | Required |
|---------|-------------|----------|
| Timestamp | ISO 8601 with timezone (e.g., `2024-01-15T14:30:00.000Z`) | MANDATORY |
| Action | Type of action performed (e.g., `USER_LOGIN`, `DATA_ACCESS`) | MANDATORY |
| Source | User ID, IP address, session ID | MANDATORY |
| Destination | Resource accessed, API endpoint | MANDATORY |
| Description | Summary of what transpired | MANDATORY |
| Subsystem | Process/transaction identifiers | RECOMMENDED |
| Correlation ID | Request tracing identifier | RECOMMENDED |

---

## Detection Patterns

### Unstructured Logging Detection

```bash
# Console logging (unstructured)
Grep: "console.log|console.info|console.warn|console.error|console.debug"

# Print statements (unstructured)
Grep: "System.out.print|print\\(|println\\("

# String concatenation in logs (unstructured)
Grep: "logger.info\\(.*\\+|logger.warn\\(.*\\+|logger.error\\(.*\\+"
Grep: "log.info\\(.*\\+|log.warn\\(.*\\+|log.error\\(.*\\+"

# Template literals without structured logging
Grep: "logger.*\\`.*\\$\\{|log.*\\`.*\\$\\{"
```

### Timestamp Format Detection

```bash
# Check for timestamp configuration
Grep: "timestamp.*format|dateFormat|timeFormat"
Grep: "ISO.*8601|isoformat|toISOString"

# Non-compliant timestamp patterns
Grep: "new Date\\(\\).toString\\(\\)|Date.now\\(\\)"
Grep: "moment\\(\\).format\\([^I]|dayjs\\(\\).format\\([^I]"
```

### Missing Security Event Logging

```bash
# Auth endpoints that should log
Grep: "login|signin|logout|signout|authenticate"
Grep: "password.*change|password.*reset|forgotPassword"

# Account events that should log
Grep: "createUser|deleteUser|updateUser|disableUser"
Grep: "assignRole|revokeRole|updatePermissions"

# Check for logging calls near these patterns
```

---

## LOG-01: Unstructured Logging

**Severity:** MEDIUM | **CWE:** CWE-778

```typescript
// VULNERABLE: Unstructured console logging
console.log('User logged in: ' + username);
console.log(`API call to ${endpoint} returned ${status}`);

// VULNERABLE: String concatenation in logger
logger.info('Login attempt for user: ' + username + ' from IP: ' + ip);

// SECURE: Structured JSON logging
logger.info({
  action: 'USER_LOGIN',
  timestamp: new Date().toISOString(),
  source: { userId, ip, sessionId },
  destination: { service: 'auth-service' },
  description: 'User login attempt',
  outcome: 'SUCCESS'
});

// SECURE: Using structured logger (Winston, Pino, Bunyan)
import pino from 'pino';
const logger = pino({
  timestamp: pino.stdTimeFunctions.isoTime,
  formatters: {
    level: (label) => ({ level: label })
  }
});

logger.info({ userId, action: 'LOGIN', ip }, 'User authenticated');
```

**Finding Template:**
```markdown
**LOG-01: Unstructured Logging Detected**
**Severity:** MEDIUM
**Confidence:** HIGH

- **Category:** Logging Standards / CWE-778
- **Location:** {file}:{line}
- **Issue:** Using unstructured logging (console.log, string concatenation)
- **Impact:** Logs cannot be parsed, indexed, or searched effectively
- **Remediation:** Use structured logging library (Winston, Pino, Bunyan) with JSON format
```

---

## LOG-02: Non-Compliant Timestamp Format

**Severity:** MEDIUM | **CWE:** CWE-778

```typescript
// VULNERABLE: Non-ISO timestamp
logger.info({
  time: new Date().toString(),  // "Mon Jan 15 2024 14:30:00 GMT-0500"
  message: 'Event occurred'
});

// VULNERABLE: Unix timestamp without timezone
logger.info({
  timestamp: Date.now(),  // 1705343400000
  message: 'Event occurred'
});

// SECURE: ISO 8601 with timezone
logger.info({
  timestamp: new Date().toISOString(),  // "2024-01-15T19:30:00.000Z"
  message: 'Event occurred'
});

// SECURE: Configure logger for ISO timestamps
const logger = winston.createLogger({
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DDTHH:mm:ss.SSSZ' }),
    winston.format.json()
  )
});
```

**Finding Template:**
```markdown
**LOG-02: Non-Compliant Timestamp Format**
**Severity:** MEDIUM
**Confidence:** HIGH

- **Category:** Logging Standards / CWE-778
- **Location:** {file}:{line}
- **Issue:** Timestamp format is not ISO 8601 with timezone
- **Impact:** Log correlation and time-based analysis will be inaccurate
- **Remediation:** Use ISO 8601 format (YYYY-MM-DDTHH:mm:ss.SSSZ)
```

---

## LOG-03: Missing Required Log Fields

**Severity:** MEDIUM | **CWE:** CWE-778

```typescript
// VULNERABLE: Missing required fields
logger.info({ message: 'User action occurred' });  // Missing action, source, destination

// SECURE: All required fields present
logger.info({
  timestamp: new Date().toISOString(),
  action: 'USER_LOGIN',
  source: {
    userId: user.id,
    ip: req.ip,
    userAgent: req.headers['user-agent']
  },
  destination: {
    service: 'auth-service',
    endpoint: '/api/v1/login'
  },
  description: 'User authentication successful',
  correlationId: req.id,
  outcome: 'SUCCESS'
});
```

---

## LOG-04: Missing Security Event Logging

**Severity:** HIGH | **CWE:** CWE-778

### Security Events That MUST Be Logged

| Event Category | Specific Events | Required Data |
|----------------|-----------------|---------------|
| Authentication | Login success/failure, logout, MFA | User ID, IP, outcome |
| Authorization | Access granted/denied, permission check | User, resource, decision |
| Account Lifecycle | Create, modify, delete, lock, unlock | Actor, target user, changes |
| Session | Create, destroy, timeout, invalidate | Session ID, user, reason |
| Input Validation | Validation failures, sanitization | Input type, failure reason |
| Privileged Actions | Admin operations, config changes | Actor, action, before/after |

```typescript
// VULNERABLE: No logging of auth events
async login(username: string, password: string) {
  const user = await User.findByUsername(username);
  if (!user || !await bcrypt.compare(password, user.hash)) {
    throw new UnauthorizedError();  // No logging!
  }
  return createSession(user);
}

// SECURE: Comprehensive security event logging
async login(username: string, password: string, req: Request) {
  const user = await User.findByUsername(username);

  if (!user) {
    logger.warn({
      action: 'AUTH_LOGIN_FAILED',
      timestamp: new Date().toISOString(),
      source: { username, ip: req.ip },
      description: 'Login failed - unknown user',
      outcome: 'FAILURE',
      failureReason: 'USER_NOT_FOUND'
    });
    throw new UnauthorizedError();
  }

  if (!await bcrypt.compare(password, user.hash)) {
    logger.warn({
      action: 'AUTH_LOGIN_FAILED',
      timestamp: new Date().toISOString(),
      source: { userId: user.id, ip: req.ip },
      description: 'Login failed - invalid password',
      outcome: 'FAILURE',
      failureReason: 'INVALID_PASSWORD'
    });
    throw new UnauthorizedError();
  }

  logger.info({
    action: 'AUTH_LOGIN_SUCCESS',
    timestamp: new Date().toISOString(),
    source: { userId: user.id, ip: req.ip },
    description: 'User login successful',
    outcome: 'SUCCESS'
  });

  return createSession(user);
}
```

**Finding Template:**
```markdown
**LOG-04: Missing Security Event Logging**
**Severity:** HIGH
**Confidence:** MEDIUM

- **Category:** Logging Standards / CWE-778 (A09:2021)
- **Location:** {file}:{line}
- **Issue:** Security-relevant operation without audit logging
- **Impact:** Security incidents cannot be detected or investigated
- **Events to Log:** {authentication|authorization|account|session} events
- **Remediation:** Add structured logging for all security events
```

---

## LOG-05: Sensitive Data in Logs (Cross-reference with Data Privacy)

**Severity:** CRITICAL | **CWE:** CWE-532

See `data-privacy-patterns.md` for detailed PII/sensitive data detection.

```typescript
// VULNERABLE: Logging sensitive data
logger.info({ username, password, action: 'LOGIN' });  // Password logged!
logger.debug({ request: req.body });  // May contain tokens, credentials

// SECURE: Redact sensitive fields
const sanitize = (obj: any) => {
  const sensitive = ['password', 'token', 'secret', 'authorization', 'ssn', 'cardNumber'];
  const result = { ...obj };
  for (const key of Object.keys(result)) {
    if (sensitive.some(s => key.toLowerCase().includes(s))) {
      result[key] = '[REDACTED]';
    }
  }
  return result;
};

logger.info(sanitize({ username, password, action: 'LOGIN' }));
// Output: { username: 'john', password: '[REDACTED]', action: 'LOGIN' }
```

---

## Structured Logging Configuration Examples

### Winston (Node.js)

```typescript
import winston from 'winston';

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DDTHH:mm:ss.SSSZ' }),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  defaultMeta: { service: 'my-service' },
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'logs/app.log' })
  ]
});
```

### Pino (Node.js)

```typescript
import pino from 'pino';

const logger = pino({
  timestamp: () => `,"timestamp":"${new Date().toISOString()}"`,
  formatters: {
    level: (label) => ({ level: label.toUpperCase() })
  },
  redact: ['password', 'token', 'secret', 'authorization']
});
```

### Bunyan (Node.js)

```typescript
import bunyan from 'bunyan';

const logger = bunyan.createLogger({
  name: 'my-service',
  serializers: {
    req: bunyan.stdSerializers.req,
    err: bunyan.stdSerializers.err
  },
  streams: [
    { level: 'info', stream: process.stdout },
    { level: 'error', path: '/var/log/app-error.log' }
  ]
});
```

---

## Detection Summary

| Issue | Grep Pattern | Severity |
|-------|-------------|----------|
| Console logging | `console.log\|console.info\|console.warn` | MEDIUM |
| String concat in logs | `logger.*\\+\|log.*\\+` | MEDIUM |
| Non-ISO timestamp | `Date\\(\\).toString\|Date.now\\(\\)` | MEDIUM |
| Missing auth logging | Auth functions without `logger` nearby | HIGH |
| Sensitive data logged | `logger.*password\|log.*token` | CRITICAL |

---

## References

- AIG Logging and Monitoring Standard
- [OWASP Logging Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html)
- [CWE-778: Insufficient Logging](https://cwe.mitre.org/data/definitions/778.html)
- [CWE-532: Information Exposure Through Log Files](https://cwe.mitre.org/data/definitions/532.html)
