# Data Privacy Patterns Checklist

Reference checklist for data-privacy-reviewer agent.

This checklist covers detection patterns for:
- PII/PHI exposure (SSN, credit cards, health data)
- Data masking validation
- Logging hygiene (credentials, tokens, PII in logs)
- Timing attacks (user enumeration, password timing)
- Data retention policy violations
- Compliance requirements (GDPR, CCPA, PCI-DSS, HIPAA)

---

## Quick Reference - Critical Issues

| Issue | Severity | Detection Pattern | CWE | Compliance |
|-------|----------|------------------|-----|------------|
| SSN in response | CRITICAL | `ssn:.*user\.ssn` without masking | CWE-359 | GDPR, CCPA |
| Credit card logged | CRITICAL | `logger.*cardNumber`, `console.*card` | CWE-532 | PCI-DSS 3.4 |
| Password in logs | CRITICAL | `logger.*password`, `console.*password` | CWE-532 | All |
| PHI exposure | CRITICAL | `diagnosis`, `prescription` in logs/response | CWE-359 | HIPAA |
| User enumeration timing | MEDIUM | Different paths for valid/invalid users | CWE-208 | All |
| PII retained after deletion | HIGH | Soft delete without PII purge | CWE-359 | GDPR Art. 17 |

---

## PII Detection Patterns

### Social Security Numbers (SSN)

**Regex Patterns:**
```
# SSN format: 123-45-6789
\d{3}-\d{2}-\d{4}

# SSN without dashes: 123456789
\d{9}

# Variable names
ssn|socialSecurity|social_security|taxId|tax_id|sin|national_id
```

**Detection Patterns:**
```bash
# Find SSN in code
Grep: "ssn|socialSecurity|social_security|taxId|tax_id"
Grep: "\d{3}-\d{2}-\d{4}"

# Find SSN exposure in responses
Grep: "return.*ssn|res\.json.*ssn|response.*ssn"
```

**Vulnerable Patterns:**
```typescript
// CRITICAL - Full SSN in API response
return {
  name: user.name,
  ssn: user.ssn  // Full SSN exposed!
};

// CRITICAL - SSN in error message
throw new Error(`Invalid SSN: ${ssn}`);

// CRITICAL - SSN in logs
logger.info(`Processing user ${name}, SSN: ${ssn}`);
```

**Secure Patterns:**
```typescript
// SECURE - Masked SSN
function maskSSN(ssn: string): string {
  return `***-**-${ssn.slice(-4)}`;
}

return {
  name: user.name,
  ssnLast4: user.ssn.slice(-4),
  ssnMasked: maskSSN(user.ssn)
};

// SECURE - No SSN in logs
logger.info('Processing user', { userId: user.id });
```

### Credit Card Numbers (PAN)

**Regex Patterns:**
```
# Credit card format (with spaces/dashes)
\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}

# Credit card (continuous)
\d{13,19}

# Variable names
cardNumber|card_number|creditCard|credit_card|pan|ccNumber|cc_number|primaryAccountNumber
```

**PCI-DSS Requirements:**
| Requirement | Description |
|-------------|-------------|
| 3.3 | Mask PAN when displayed (show max first 6 and last 4 digits) |
| 3.4 | Render PAN unreadable anywhere it is stored |
| 4.1 | Use strong encryption for transmission over open networks |
| Never | Store CVV/CVC after authorization |

**Vulnerable Patterns:**
```typescript
// CRITICAL - Full card number in response
return {
  cardNumber: card.number,  // Full PAN exposed!
  cvv: card.cvv  // CVV should NEVER be stored/returned
};

// CRITICAL - Card number logged
logger.info(`Processing payment for card ${cardNumber}`);

// CRITICAL - Card number in error
throw new Error(`Card ${cardNumber} declined`);
```

**Secure Patterns:**
```typescript
// SECURE - Masked card number
function maskCardNumber(pan: string): string {
  const digits = pan.replace(/\D/g, '');
  return `**** **** **** ${digits.slice(-4)}`;
}

return {
  cardMasked: maskCardNumber(card.number),
  lastFour: card.number.slice(-4),
  brand: detectCardBrand(card.number)
  // CVV is NEVER stored or returned
};

// SECURE - Only last 4 in logs
logger.info('Processing payment', { cardLast4: cardNumber.slice(-4) });
```

### Protected Health Information (PHI)

**HIPAA Covered Identifiers (18 types):**
| Identifier | Examples |
|------------|----------|
| Names | Full name, maiden name |
| Geographic | Address, city, zip code |
| Dates | DOB, admission date, discharge date |
| Contact | Phone, fax, email |
| Identifiers | SSN, MRN, health plan ID |
| Device | Device IDs, serial numbers |
| Biometric | Fingerprints, voice prints |
| Photos | Full face photos |
| Unique | Any other unique identifier |

**Detection Patterns:**
```bash
# Find PHI in code
Grep: "diagnosis|prescription|patient|medical|health|treatment"
Grep: "icd|cpt|medicalRecord|medical_record|mrn"
Grep: "dateOfBirth|dob|date_of_birth"

# Find PHI in logs
Grep: "logger.*patient|console.*diagnosis|log.*prescription"
```

**Vulnerable Patterns:**
```typescript
// CRITICAL - PHI in logs
logger.info(`Patient ${patient.name} diagnosis: ${patient.diagnosis}`);

// CRITICAL - PHI in response without need-to-know
return {
  ...patient,  // Includes all PHI!
  medicalHistory: patient.history
};

// CRITICAL - PHI in error messages
throw new Error(`Cannot process prescription for ${patient.name}`);
```

**Secure Patterns:**
```typescript
// SECURE - Minimal logging with IDs only
logger.info('Accessed patient record', {
  patientId: patient.id,
  action: 'view_diagnosis',
  accessedBy: currentUser.id
});

// SECURE - Return only required fields
return {
  patientId: patient.id,
  appointmentDate: patient.nextAppointment
  // PHI only through secure, access-controlled channels
};

// SECURE - Audit logging for PHI access
await auditLog.record({
  action: 'PHI_ACCESS',
  resourceType: 'diagnosis',
  resourceId: patient.id,
  accessedBy: currentUser.id,
  timestamp: new Date(),
  ipAddress: req.ip
});
```

### Email Addresses

**Regex Pattern:**
```
[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}
```

**Detection:**
```bash
Grep: "email|e_mail|emailAddress|email_address"
Grep: "logger.*email|console.*@"
```

### Phone Numbers

**Regex Patterns:**
```
# US format
\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}

# International
\+[0-9]{1,3}[-.\s]?[0-9]{4,14}
```

---

## Logging Hygiene Patterns

### Credentials in Logs (CRITICAL)

**Detection Patterns:**
```bash
# Password logging
Grep: "logger.*password|console.*password|log.*password"
Grep: "info.*password|error.*password|debug.*password"

# Token logging
Grep: "logger.*token|console.*token|log.*token"
Grep: "logger.*apiKey|console.*apiKey|log.*api_key"

# Secret logging
Grep: "logger.*secret|console.*secret|log.*credential"
```

**Vulnerable Patterns:**
```typescript
// CRITICAL - Password logged
logger.error(`Login failed for ${email} with password ${password}`);

// CRITICAL - Token logged
logger.debug(`Auth token: ${authToken}`);

// CRITICAL - API key logged
console.log(`Using API key: ${apiKey}`);

// CRITICAL - Full request body logged (may contain passwords)
app.use((req, res, next) => {
  logger.info('Request', { body: req.body });
  next();
});
```

**Secure Patterns:**
```typescript
// SECURE - No credentials logged
logger.warn('Login failed', { email, reason: 'invalid_credentials' });

// SECURE - Token masked
const maskedToken = `${token.slice(0, 8)}...${token.slice(-4)}`;
logger.debug('Authenticating', { tokenPrefix: maskedToken });

// SECURE - Sanitized request logging
const SENSITIVE_FIELDS = ['password', 'token', 'apiKey', 'ssn', 'cardNumber', 'cvv'];

function sanitizeForLogging(obj: any): any {
  if (!obj || typeof obj !== 'object') return obj;

  const sanitized = { ...obj };
  for (const field of SENSITIVE_FIELDS) {
    if (sanitized[field]) {
      sanitized[field] = '[REDACTED]';
    }
  }
  return sanitized;
}

app.use((req, res, next) => {
  logger.info('Request', {
    method: req.method,
    path: req.path,
    body: sanitizeForLogging(req.body)
  });
  next();
});
```

### Session/Auth Tokens in Logs

**Detection Patterns:**
```bash
Grep: "logger.*session|console.*session"
Grep: "logger.*jwt|console.*jwt|log.*bearer"
Grep: "logger.*cookie|console.*cookie"
```

**Vulnerable Patterns:**
```typescript
// CRITICAL - Session ID logged
logger.info(`User session: ${sessionId}`);

// CRITICAL - JWT logged
logger.debug(`JWT token: ${jwt}`);

// CRITICAL - Cookie header logged
logger.info(`Request cookies: ${req.headers.cookie}`);
```

### PII in Logs

**Detection Patterns:**
```bash
# Generic PII logging
Grep: "logger.*user\.|console.*user\."
Grep: "logger.*name|logger.*email|logger.*phone"
Grep: "JSON\.stringify.*user"
```

**Vulnerable Patterns:**
```typescript
// HIGH - Full user object logged
logger.info('User action', { user: JSON.stringify(user) });

// HIGH - PII in log messages
logger.info(`Processing request for ${user.name} (${user.email})`);

// HIGH - Error with user details
logger.error(`Error processing ${user.ssn}`, error);
```

**Secure Patterns:**
```typescript
// SECURE - Only IDs logged
logger.info('User action', { userId: user.id, action: 'purchase' });

// SECURE - Hashed/masked identifiers for correlation
const userHash = crypto.createHash('sha256')
  .update(user.email)
  .digest('hex')
  .slice(0, 8);
logger.info('Processing request', { userRef: userHash });
```

---

## Timing Attack Patterns

### User Enumeration (CWE-208)

**Detection Patterns:**
```bash
# Find auth patterns with early return
Grep: "findByEmail|findByUsername|getUserBy"
Grep: "if.*!user.*return|if.*user.*null.*return"

# Find different error paths
Grep: "user not found|invalid user|no such user"
```

**Vulnerable Pattern - Different Code Paths:**
```typescript
// VULNERABLE - Fast path reveals user doesn't exist
async login(email: string, password: string) {
  const user = await this.userRepo.findByEmail(email);

  if (!user) {
    return { error: 'Invalid credentials' };  // Returns in ~5ms
  }

  const valid = await bcrypt.compare(password, user.passwordHash);  // Takes ~100ms
  if (!valid) {
    return { error: 'Invalid credentials' };
  }

  return { token: generateToken(user) };
}
// Attack: Time responses - fast = user doesn't exist, slow = user exists
```

**Secure Pattern - Constant Time:**
```typescript
// SECURE - Always run password comparison
async login(email: string, password: string) {
  const user = await this.userRepo.findByEmail(email);

  // Always perform bcrypt comparison (constant time)
  const DUMMY_HASH = '$2b$12$dummyhashfordummyusertopreventtimingattack';
  const hashToCompare = user?.passwordHash || DUMMY_HASH;

  const valid = await bcrypt.compare(password, hashToCompare);

  if (!user || !valid) {
    return { error: 'Invalid credentials' };  // Same response, same timing
  }

  return { token: generateToken(user) };
}
```

### Password Timing (CWE-208)

**Detection Patterns:**
```bash
# Find direct string comparison
Grep: "password\s*===|password\s*!==|secret\s*===|token\s*==="
Grep: "apiKey\s*===|api_key\s*==="
```

**Vulnerable Pattern:**
```typescript
// VULNERABLE - String comparison leaks timing
function verifyApiKey(provided: string, stored: string): boolean {
  return provided === stored;  // Early exit on first mismatch!
}

// VULNERABLE - Non-constant-time HMAC verification
function verifySignature(payload: string, signature: string, secret: string) {
  const expected = crypto.createHmac('sha256', secret)
    .update(payload)
    .digest('hex');
  return signature === expected;  // Timing attack possible!
}
```

**Secure Pattern:**
```typescript
import { timingSafeEqual } from 'crypto';

// SECURE - Constant-time comparison
function verifyApiKey(provided: string, stored: string): boolean {
  const providedBuf = Buffer.from(provided);
  const storedBuf = Buffer.from(stored);

  // Length check is unavoidable, but reveals no partial info
  if (providedBuf.length !== storedBuf.length) {
    return false;
  }

  return timingSafeEqual(providedBuf, storedBuf);
}

// SECURE - Constant-time HMAC verification
function verifySignature(payload: string, signature: string, secret: string) {
  const expected = crypto.createHmac('sha256', secret)
    .update(payload)
    .digest();
  const sigBuf = Buffer.from(signature, 'hex');

  if (expected.length !== sigBuf.length) {
    return false;
  }

  return timingSafeEqual(expected, sigBuf);
}
```

---

## Data Retention Patterns

### No Data Expiration (GDPR Art. 5(1)(e))

**Detection Patterns:**
```bash
# Find creates without expiration
Grep: "create|insert|save" without "expir|ttl|retention"
Grep: "userRepo.create|db.insert"
```

**Vulnerable Pattern:**
```typescript
// VULNERABLE - No retention policy
async createUser(data: CreateUserDto) {
  return this.userRepo.create({
    ...data,
    ssn: data.ssn,
    createdAt: new Date()
    // No expiresAt, no retention policy!
  });
}
```

**Secure Pattern:**
```typescript
// SECURE - Retention policy implemented
async createUser(data: CreateUserDto) {
  const RETENTION_YEARS = 7;  // Based on legal requirements

  return this.userRepo.create({
    ...data,
    ssn: encrypt(data.ssn),  // Encrypted at rest
    createdAt: new Date(),
    retentionExpiresAt: addYears(new Date(), RETENTION_YEARS),
    dataClassification: 'PII'
  });
}

// Scheduled job to purge expired data
@Scheduled('0 0 * * *')  // Daily
async purgeExpiredData() {
  await this.userRepo.deleteWhere({
    retentionExpiresAt: { $lt: new Date() }
  });
}
```

### Soft Delete Retaining PII (GDPR Art. 17)

**Detection Patterns:**
```bash
# Find soft delete patterns
Grep: "isDeleted|is_deleted|deletedAt|deleted_at"
Grep: "softDelete|soft_delete"
```

**Vulnerable Pattern:**
```typescript
// VULNERABLE - Soft delete retains all PII
async deleteUser(userId: string) {
  await this.userRepo.update(userId, {
    isDeleted: true,
    deletedAt: new Date()
    // SSN, name, email, address all retained!
  });
}
```

**Secure Pattern:**
```typescript
// SECURE - Purge PII on deletion
async deleteUser(userId: string) {
  // Option 1: Purge PII, keep anonymized record
  await this.userRepo.update(userId, {
    ssn: null,
    name: '[DELETED]',
    email: `deleted-${userId}@redacted.local`,
    phone: null,
    address: null,
    isDeleted: true,
    deletedAt: new Date(),
    piiPurgedAt: new Date()
  });

  // Option 2: Hard delete after grace period
  await this.scheduler.schedule('hard-delete-user', {
    userId,
    executeAt: addDays(new Date(), 30)  // 30-day grace period
  });
}
```

---

## Compliance Requirements

### GDPR (General Data Protection Regulation)

| Article | Requirement | Detection Focus |
|---------|-------------|-----------------|
| Art. 5(1)(c) | Data minimization | Return only necessary fields |
| Art. 5(1)(e) | Storage limitation | Retention policies, expiration |
| Art. 17 | Right to erasure | PII deletion on request |
| Art. 25 | Privacy by design | Encryption, pseudonymization |
| Art. 32 | Security of processing | Encryption, access controls |
| Art. 33 | Breach notification | Logging, audit trails |

### CCPA (California Consumer Privacy Act)

| Right | Requirement | Detection Focus |
|-------|-------------|-----------------|
| Right to know | Disclose data collected | Data inventory |
| Right to delete | Delete on request | Deletion implementation |
| Right to opt-out | Opt-out of sale | Consent tracking |
| Non-discrimination | No penalty for exercising rights | Equal service |

### PCI-DSS (Payment Card Industry)

| Requirement | Description | Detection Focus |
|-------------|-------------|-----------------|
| 3.3 | Mask PAN when displayed | Display max first 6/last 4 |
| 3.4 | Render PAN unreadable in storage | Encryption at rest |
| 4.1 | Encrypt transmission | TLS for card data |
| 7.1 | Restrict access to cardholder data | Access controls |
| 10.2 | Audit trail | Logging access to card data |

### HIPAA (Health Insurance Portability and Accountability Act)

| Section | Requirement | Detection Focus |
|---------|-------------|-----------------|
| 164.312(a)(1) | Access control | Authentication, authorization |
| 164.312(b) | Audit controls | PHI access logging |
| 164.312(c)(1) | Integrity | Data integrity controls |
| 164.312(d) | Person authentication | User identity verification |
| 164.312(e)(1) | Transmission security | Encryption in transit |

---

## Severity Matrix

| Issue | Severity | Confidence | CWE | Compliance Impact |
|-------|----------|------------|-----|-------------------|
| Password in logs | CRITICAL | HIGH | CWE-532 | All regulations |
| SSN in API response | CRITICAL | HIGH | CWE-359 | GDPR, CCPA |
| Credit card logged | CRITICAL | HIGH | CWE-532 | PCI-DSS 3.4 |
| PHI in logs | CRITICAL | HIGH | CWE-532 | HIPAA 164.312(b) |
| CVV stored/returned | CRITICAL | HIGH | CWE-311 | PCI-DSS |
| User enumeration timing | MEDIUM | HIGH | CWE-208 | All |
| Non-constant-time comparison | MEDIUM | MEDIUM | CWE-208 | All |
| PII retained after deletion | HIGH | HIGH | CWE-359 | GDPR Art. 17 |
| No data retention policy | HIGH | MEDIUM | CWE-359 | GDPR Art. 5 |
| Unmasked SSN in response | CRITICAL | HIGH | CWE-200 | All |
| Full request body logged | HIGH | MEDIUM | CWE-532 | All |
| Session token logged | HIGH | HIGH | CWE-532 | All |

---

## Quick Reference

### Masking Functions

```typescript
// SSN masking
function maskSSN(ssn: string): string {
  return `***-**-${ssn.slice(-4)}`;
}

// Credit card masking
function maskCardNumber(pan: string): string {
  const digits = pan.replace(/\D/g, '');
  return `**** **** **** ${digits.slice(-4)}`;
}

// Email masking
function maskEmail(email: string): string {
  const [user, domain] = email.split('@');
  return `${user.slice(0, 2)}***@${domain}`;
}

// Phone masking
function maskPhone(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  return `***-***-${digits.slice(-4)}`;
}
```

### Logging Sanitization

```typescript
const SENSITIVE_FIELDS = [
  'password', 'passwd', 'pwd',
  'token', 'accessToken', 'refreshToken', 'authToken',
  'apiKey', 'api_key', 'secret',
  'ssn', 'socialSecurity', 'taxId',
  'cardNumber', 'creditCard', 'pan', 'cvv', 'cvc',
  'accountNumber', 'routingNumber'
];

function sanitizeForLogging(obj: any): any {
  if (!obj || typeof obj !== 'object') return obj;

  const sanitized = Array.isArray(obj) ? [...obj] : { ...obj };

  for (const key of Object.keys(sanitized)) {
    if (SENSITIVE_FIELDS.some(f => key.toLowerCase().includes(f.toLowerCase()))) {
      sanitized[key] = '[REDACTED]';
    } else if (typeof sanitized[key] === 'object') {
      sanitized[key] = sanitizeForLogging(sanitized[key]);
    }
  }

  return sanitized;
}
```

### Constant-Time Comparison

```typescript
import { timingSafeEqual } from 'crypto';

function secureCompare(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);

  if (bufA.length !== bufB.length) {
    // Compare with dummy to maintain constant time for length mismatch
    const dummy = Buffer.alloc(bufA.length);
    timingSafeEqual(bufA, dummy);
    return false;
  }

  return timingSafeEqual(bufA, bufB);
}
```
