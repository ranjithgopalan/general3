---
name: security-checklists
description: Comprehensive security checklists including OWASP Top 10, crypto patterns, and privacy compliance Use when the user requests this functionality.
---

# Security Checklists Skill

This skill provides comprehensive security checklists for the security-reviewer plugin's specialized agents.

## ⚡ NEW: Split Structure for Efficiency (Phase 3)

**OWASP Top 10** and **Data Privacy** patterns are now **split by category** for selective loading using Grep.

## Available Checklists

| Checklist | Purpose | Used By | Structure |
|-----------|---------|---------|-----------|
| `owasp/` | OWASP Top 10 2021 vulnerabilities | code-security-reviewer | **SPLIT** (10 files) |
| `privacy/` | Data privacy compliance patterns | data-privacy-reviewer | **SPLIT** (5 files) |
| `finding-templates.md` | Standardized finding format | All reviewers | Single file |
| `business-logic-patterns.md` | Business logic vulnerabilities | code-security-reviewer | Single file |
| `design-security.md` | Security-first design review | design-security-reviewer | Single file |
| `crypto-patterns.md` | Cryptographic implementation | crypto-security-reviewer | Single file |
| `aws-security.md` | AWS/IaC security | infrastructure-security-reviewer | Single file |

## Usage

### Traditional (Single File)
```bash
# Read entire checklist
Read skills/security-checklists/crypto-patterns.md
```

### NEW: Selective Loading with Grep (RECOMMENDED)
```bash
# OWASP - Use Grep for specific category
Grep "IDOR|Horizontal" skills/security-checklists/owasp/a01-broken-access-control.md
Grep "SQL.*injection" skills/security-checklists/owasp/a03-injection.md

# Or Read specific category file
Read skills/security-checklists/owasp/a01-broken-access-control.md

# Privacy - Use Grep for specific framework
Grep "consent|GDPR" skills/security-checklists/privacy/gdpr-compliance.md
Grep "card.*number|PAN" skills/security-checklists/privacy/pci-dss-compliance.md
```

### Why Grep Instead of Read?

**Token Efficiency:**
- **Before:** Read 993-line owasp-top10.md = ~43K tokens
- **After:** Grep + Read specific category = ~100 lines = ~4K tokens
- **Savings:** ~90% tokens when checking specific OWASP category

**Speed:**
- Grep is faster for finding specific patterns
- Load only what you need

## Checklist Structure

Each checklist follows this format:

```markdown
## Category Name

### Check Item
- **Risk:** Description of security risk
- **Detection:** How to find this issue
- **Severity:** CRITICAL | HIGH | MEDIUM | LOW
- **Remediation:** How to fix
```

## Severity Definitions

| Severity | Criteria | Action Timeline |
|----------|----------|-----------------|
| CRITICAL | Data breach, authentication bypass | 24-48 hours |
| HIGH | Significant security impact | 1 week |
| MEDIUM | Limited scope vulnerability | 1 sprint |
| LOW | Defense in depth, best practice | Backlog |

## Confidence Levels

| Level | Criteria |
|-------|----------|
| HIGH | Clear vulnerable pattern, no mitigations visible |
| MEDIUM | Pattern suggests vulnerability, context unclear |
| LOW | Unusual pattern, may have mitigations |

## Integration

These checklists complement (not replace):
- npm audit / Snyk for dependency CVEs
- SAST tools for pattern-based scanning
- Professional penetration testing for exploitation verification
