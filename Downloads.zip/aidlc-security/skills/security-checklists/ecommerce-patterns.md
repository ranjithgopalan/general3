# E-Commerce Security Patterns Checklist

Reference checklist for code-security-reviewer agent.

This checklist provides detection patterns for e-commerce security controls including fraud detection, transaction integrity, idempotency, and audit logging.

---

## Quick Reference - E-Commerce Security Controls

| Control | Purpose | Severity if Missing |
|---------|---------|---------------------|
| Fraud Detection | Detect anomalous transactions | MEDIUM |
| Idempotency | Prevent duplicate transactions | HIGH |
| Transaction Integrity | Validate transaction data | HIGH |
| Transaction Logging | Audit trail for all transactions | HIGH |
| Price Validation | Server-side price verification | CRITICAL |
| Inventory Atomicity | Prevent overselling | HIGH |

---

## Detection Patterns

### Payment/Transaction Handler Detection

```bash
# Identify e-commerce code that needs review
Grep: "processPayment|processTransaction|checkout|purchase"
Grep: "createOrder|submitOrder|placeOrder"
Grep: "charge|refund|capture|authorize"
Grep: "stripe|paypal|braintree|square|adyen"
Grep: "cart.*checkout|basket.*purchase"
```

### Idempotency Detection

```bash
# Check for idempotency implementation
Grep: "idempotency|idempotent|idempotencyKey"
Grep: "requestId|transactionId|orderId.*unique"
Grep: "dedup|deduplicate|duplicate.*check"

# Missing idempotency indicators
Grep: "POST.*payment|POST.*order|POST.*transaction"
# Check if these have idempotency key handling
```

### Fraud Detection Detection

```bash
# Check for fraud detection logic
Grep: "fraud|suspicious|anomaly"
Grep: "velocity|rateLimit.*transaction"
Grep: "maxAmount|transactionLimit|dailyLimit"
Grep: "deviceFingerprint|ipReputation"
```

### Transaction Logging Detection

```bash
# Check for transaction audit logging
Grep: "auditLog|transactionLog|orderLog"
Grep: "logger.*transaction|logger.*payment|logger.*order"
Grep: "audit.*trail|transaction.*history"
```

---

## ECOM-01: Missing Idempotency

**Severity:** HIGH | **CWE:** CWE-799

Payment operations must be idempotent to prevent duplicate charges from retries.

```typescript
// VULNERABLE: No idempotency - duplicate charges possible on retry
app.post('/api/payments', async (req, res) => {
  const { amount, cardToken } = req.body;
  const charge = await stripe.charges.create({
    amount,
    source: cardToken
  });
  res.json({ chargeId: charge.id });
});

// SECURE: Idempotency key prevents duplicates
app.post('/api/payments', async (req, res) => {
  const { amount, cardToken, idempotencyKey } = req.body;

  // Check if already processed
  const existing = await PaymentLog.findOne({ idempotencyKey });
  if (existing) {
    return res.json({ chargeId: existing.chargeId, cached: true });
  }

  const charge = await stripe.charges.create(
    { amount, source: cardToken },
    { idempotencyKey }  // Stripe handles idempotency
  );

  await PaymentLog.create({
    idempotencyKey,
    chargeId: charge.id,
    amount,
    createdAt: new Date()
  });

  res.json({ chargeId: charge.id });
});

// SECURE: Database-level idempotency with unique constraint
await db.transaction(async (tx) => {
  // This will fail on duplicate requestId
  await tx.insert('transactions', {
    requestId: req.body.requestId,  // Unique constraint
    amount: req.body.amount,
    status: 'pending'
  });

  const result = await processPayment(req.body);

  await tx.update('transactions', {
    status: 'completed',
    externalId: result.id
  }, { requestId: req.body.requestId });
});
```

**Finding Template:**
```markdown
**ECOM-01: Missing Idempotency on Payment Operation**
**Severity:** HIGH
**Confidence:** HIGH

- **Category:** E-Commerce Security / CWE-799
- **Location:** {file}:{line}
- **Issue:** Payment/transaction endpoint without idempotency handling
- **Impact:** Network retries or user double-clicks can cause duplicate charges
- **Remediation:** Implement idempotency key checking before processing payments
```

---

## ECOM-02: Missing Fraud Detection

**Severity:** MEDIUM | **CWE:** CWE-799

E-commerce applications should detect anomalous transaction patterns.

```typescript
// VULNERABLE: No fraud checks
app.post('/api/checkout', async (req, res) => {
  const { amount, userId } = req.body;
  await processPayment(amount);  // No fraud validation!
});

// SECURE: Fraud detection before processing
app.post('/api/checkout', async (req, res) => {
  const { amount, userId } = req.body;

  // Velocity check - transactions per time window
  const recentTxCount = await Transaction.count({
    userId,
    createdAt: { $gt: Date.now() - 3600000 }  // Last hour
  });
  if (recentTxCount > 10) {
    logger.warn({ userId, action: 'FRAUD_VELOCITY_EXCEEDED' });
    throw new FraudDetectedError('Too many transactions');
  }

  // Amount threshold check
  const dailyTotal = await Transaction.sum('amount', {
    userId,
    createdAt: { $gt: startOfDay() }
  });
  if (dailyTotal + amount > MAX_DAILY_AMOUNT) {
    logger.warn({ userId, amount, dailyTotal, action: 'FRAUD_LIMIT_EXCEEDED' });
    throw new FraudDetectedError('Daily limit exceeded');
  }

  // Device/IP reputation check
  const riskScore = await fraudService.assessRisk({
    userId,
    amount,
    ip: req.ip,
    deviceFingerprint: req.body.deviceId
  });
  if (riskScore > RISK_THRESHOLD) {
    logger.warn({ userId, riskScore, action: 'FRAUD_HIGH_RISK' });
    throw new FraudDetectedError('Transaction flagged for review');
  }

  await processPayment(amount);
});
```

**Finding Template:**
```markdown
**ECOM-02: Missing Fraud Detection**
**Severity:** MEDIUM
**Confidence:** MEDIUM

- **Category:** E-Commerce Security / CWE-799
- **Location:** {file}:{line}
- **Issue:** Transaction processing without fraud detection checks
- **Impact:** Fraudulent transactions may go undetected
- **Checks Missing:** {velocity|amount limits|device fingerprint|IP reputation}
- **Remediation:** Implement fraud detection before processing transactions
```

---

## ECOM-03: Missing Transaction Integrity Validation

**Severity:** HIGH | **CWE:** CWE-345

Transaction data must be validated server-side, not trusted from client.

```typescript
// VULNERABLE: Trusting client-side price
app.post('/api/checkout', async (req, res) => {
  const { productId, price, quantity } = req.body;
  const total = price * quantity;  // Client-provided price!
  await chargeCustomer(total);
});

// VULNERABLE: No signature validation on webhook
app.post('/api/webhook/payment', async (req, res) => {
  const { orderId, status } = req.body;
  await Order.update(orderId, { status });  // No verification!
});

// SECURE: Server-side price lookup
app.post('/api/checkout', async (req, res) => {
  const { productId, quantity } = req.body;

  // Fetch price from database, not from request
  const product = await Product.findById(productId);
  if (!product) throw new NotFoundError();

  const total = product.price * quantity;

  // Verify inventory is available (atomically)
  const updated = await Product.updateOne(
    { _id: productId, inventory: { $gte: quantity } },
    { $inc: { inventory: -quantity } }
  );
  if (updated.modifiedCount === 0) {
    throw new OutOfStockError();
  }

  await chargeCustomer(total);
});

// SECURE: Webhook signature validation
app.post('/api/webhook/payment', async (req, res) => {
  const signature = req.headers['x-webhook-signature'];
  const expectedSig = crypto
    .createHmac('sha256', WEBHOOK_SECRET)
    .update(JSON.stringify(req.body))
    .digest('hex');

  if (!crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSig)
  )) {
    throw new UnauthorizedError('Invalid webhook signature');
  }

  const { orderId, status } = req.body;
  await Order.update(orderId, { status });
});
```

**Finding Template:**
```markdown
**ECOM-03: Client-Side Price Trusted**
**Severity:** HIGH
**Confidence:** HIGH

- **Category:** E-Commerce Security / CWE-345
- **Location:** {file}:{line}
- **Issue:** Transaction amount from client request, not server-verified
- **Impact:** Attackers can modify prices to pay less than actual cost
- **Remediation:** Always fetch prices from server-side data source
```

---

## ECOM-04: Missing Transaction Logging

**Severity:** HIGH | **CWE:** CWE-778

All financial transactions must have complete audit trails.

```typescript
// VULNERABLE: No transaction logging
async processPayment(orderId: string, amount: number) {
  const result = await stripe.charges.create({ amount });
  await Order.update(orderId, { status: 'paid' });
  return result;
}

// SECURE: Comprehensive transaction logging
async processPayment(orderId: string, amount: number, userId: string) {
  const transactionId = crypto.randomUUID();

  // Log transaction start
  logger.info({
    action: 'TRANSACTION_INITIATED',
    transactionId,
    orderId,
    userId,
    amount,
    timestamp: new Date().toISOString()
  });

  try {
    const result = await stripe.charges.create({ amount });

    // Log success
    logger.info({
      action: 'TRANSACTION_COMPLETED',
      transactionId,
      orderId,
      userId,
      amount,
      externalId: result.id,
      status: 'SUCCESS',
      timestamp: new Date().toISOString()
    });

    // Persist audit record
    await TransactionAudit.create({
      transactionId,
      orderId,
      userId,
      amount,
      externalId: result.id,
      status: 'COMPLETED',
      metadata: {
        paymentMethod: 'card',
        lastFour: result.source.last4
      }
    });

    await Order.update(orderId, { status: 'paid', transactionId });
    return result;

  } catch (error) {
    // Log failure
    logger.error({
      action: 'TRANSACTION_FAILED',
      transactionId,
      orderId,
      userId,
      amount,
      error: error.message,
      errorCode: error.code,
      timestamp: new Date().toISOString()
    });

    await TransactionAudit.create({
      transactionId,
      orderId,
      userId,
      amount,
      status: 'FAILED',
      errorMessage: error.message
    });

    throw error;
  }
}
```

**Finding Template:**
```markdown
**ECOM-04: Missing Transaction Audit Logging**
**Severity:** HIGH
**Confidence:** MEDIUM

- **Category:** E-Commerce Security / CWE-778
- **Location:** {file}:{line}
- **Issue:** Financial transaction without audit logging
- **Impact:** Cannot investigate disputes, fraud, or reconciliation issues
- **Required Fields:** transactionId, orderId, userId, amount, status, timestamp
- **Remediation:** Add comprehensive logging for transaction lifecycle
```

---

## ECOM-05: Race Condition in Inventory

**Severity:** HIGH | **CWE:** CWE-362

Inventory checks must be atomic to prevent overselling.

```typescript
// VULNERABLE: Non-atomic inventory check (TOCTOU)
async checkout(productId: string, quantity: number) {
  const product = await Product.findById(productId);

  if (product.inventory >= quantity) {  // CHECK
    // Race window: another request could decrement inventory here
    product.inventory -= quantity;       // USE
    await product.save();
    await createOrder(productId, quantity);
  }
}

// SECURE: Atomic inventory decrement
async checkout(productId: string, quantity: number) {
  // Atomic update with condition
  const result = await Product.updateOne(
    {
      _id: productId,
      inventory: { $gte: quantity }  // Only if enough inventory
    },
    { $inc: { inventory: -quantity } }
  );

  if (result.modifiedCount === 0) {
    throw new OutOfStockError('Insufficient inventory');
  }

  await createOrder(productId, quantity);
}

// SECURE: Database transaction with row locking
async checkout(productId: string, quantity: number) {
  await db.transaction(async (tx) => {
    const [product] = await tx.query(
      'SELECT * FROM products WHERE id = $1 FOR UPDATE',
      [productId]
    );

    if (product.inventory < quantity) {
      throw new OutOfStockError();
    }

    await tx.query(
      'UPDATE products SET inventory = inventory - $1 WHERE id = $2',
      [quantity, productId]
    );

    await tx.query(
      'INSERT INTO orders (product_id, quantity) VALUES ($1, $2)',
      [productId, quantity]
    );
  });
}
```

---

## ECOM-06: Insufficient Cart Validation

**Severity:** HIGH | **CWE:** CWE-20

Cart contents must be validated at checkout time.

```typescript
// VULNERABLE: Stale cart data at checkout
async checkout(cartId: string) {
  const cart = await Cart.findById(cartId);
  // Cart prices may be stale from when items were added
  await chargeCustomer(cart.total);
}

// SECURE: Re-validate all cart items at checkout
async checkout(cartId: string) {
  const cart = await Cart.findById(cartId).populate('items.product');

  let validatedTotal = 0;
  const validationErrors = [];

  for (const item of cart.items) {
    // Check product still exists and is available
    if (!item.product || !item.product.isActive) {
      validationErrors.push(`Product ${item.productId} no longer available`);
      continue;
    }

    // Check inventory
    if (item.product.inventory < item.quantity) {
      validationErrors.push(`Insufficient inventory for ${item.product.name}`);
      continue;
    }

    // Use current server-side price
    validatedTotal += item.product.price * item.quantity;
  }

  if (validationErrors.length > 0) {
    throw new CartValidationError(validationErrors);
  }

  await chargeCustomer(validatedTotal);
}
```

---

## Detection Summary

| Issue | Grep Pattern | Severity |
|-------|-------------|----------|
| No idempotency | Payment POST without `idempotency` | HIGH |
| No fraud check | Transaction without `fraud\|velocity\|limit` | MEDIUM |
| Client-side price | `req.body.price\|req.body.amount` in charge | HIGH |
| No tx logging | Payment without `logger\|audit` | HIGH |
| Non-atomic inventory | `if.*inventory.*>=` pattern | HIGH |

---

## References

- AIG E-Commerce Security Requirements
- [OWASP E-Commerce Security](https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/10-Business_Logic_Testing/)
- [PCI DSS Requirements](https://www.pcisecuritystandards.org/)
- [Stripe Idempotency](https://stripe.com/docs/api/idempotent_requests)
