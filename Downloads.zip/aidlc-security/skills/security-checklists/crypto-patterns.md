# Cryptographic Patterns Checklist

Reference checklist for crypto-security-reviewer agent.

This checklist covers detection patterns for:
- Weak algorithms (MD5, SHA1, ECB mode)
- Hardcoded keys and weak key derivation
- Math.random() for security purposes
- JWT algorithm confusion vulnerabilities
- Unsalted password hashing

---

## Quick Reference - Critical Issues

| Issue | Severity | Detection Pattern | CWE |
|-------|----------|------------------|-----|
| MD5/SHA1 for security | CRITICAL | `createHash('md5')`, `createHash('sha1')` | CWE-328 |
| ECB mode encryption | HIGH | `aes-*-ecb`, `algorithm.*ECB` | CWE-327 |
| Hardcoded secrets | CRITICAL | `secret = "..."`, `key = "..."` | CWE-798 |
| Weak key derivation | HIGH | `createHash('sha256').update(password)` | CWE-916 |
| Math.random() for security | CRITICAL | `Math.random()` for tokens/IDs | CWE-338 |
| JWT algorithm confusion | CRITICAL | `jwt.verify(token, secret)` without algorithms | CWE-347 |
| Unsalted passwords | CRITICAL | Hash without salt/bcrypt/argon2 | CWE-916 |

---

## Encryption Algorithms

### Weak Symmetric Encryption
| Algorithm | Status | Issue | Alternative | CWE |
|-----------|--------|-------|-------------|-----|
| DES | **BROKEN** | 56-bit key, brute forceable | AES-256-GCM | CWE-327 |
| 3DES | **DEPRECATED** | Meet-in-middle attack | AES-256-GCM | CWE-327 |
| RC4 | **BROKEN** | Statistical bias attacks | AES-256-GCM | CWE-327 |
| Blowfish | **LEGACY** | 64-bit block size | AES-256-GCM | CWE-327 |
| AES-ECB | **INSECURE** | Pattern leakage (penguin problem) | AES-GCM | CWE-327 |

### Secure Symmetric Encryption
| Algorithm | Use Case | Notes |
|-----------|----------|-------|
| AES-256-GCM | General encryption | Authenticated encryption |
| AES-256-CBC | Legacy systems | Requires separate MAC |
| ChaCha20-Poly1305 | Mobile/constrained | Alternative to AES-GCM |

### Detection Patterns
```typescript
// INSECURE - ECB mode
crypto.createCipher('aes-256-ecb', key);
crypto.createCipheriv('aes-256-ecb', key, iv);

// INSECURE - Deprecated API
crypto.createCipher('aes-256-cbc', password);  // Key from password

// SECURE - GCM with proper IV
const iv = crypto.randomBytes(16);
const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
const authTag = cipher.getAuthTag();
```

---

## Hashing Algorithms

### Weak Hash Functions
| Algorithm | Security Use | Issue | CWE |
|-----------|--------------|-------|-----|
| MD5 | **NEVER** | Collision attacks proven | CWE-328 |
| SHA1 | **NEVER** | Collision attacks proven | CWE-328 |
| SHA256 (unsalted) | **NOT FOR PASSWORDS** | Rainbow tables | CWE-916 |
| SHA512 (unsalted) | **NOT FOR PASSWORDS** | Rainbow tables | CWE-916 |

### Secure Hash Functions
| Use Case | Algorithm | Notes |
|----------|-----------|-------|
| Passwords | bcrypt (cost 12+) | Recommended |
| Passwords | Argon2id | Best, if supported |
| Passwords | scrypt | Good alternative |
| Passwords | PBKDF2 (100k+ iterations) | Acceptable |
| Data integrity | SHA-256 | With HMAC for auth |
| Data integrity | SHA-3 | Latest standard |

### Unsalted Password Hashing (CRITICAL)

**CWE-916: Use of Password Hash With Insufficient Computational Effort**

Unsalted password hashing is a critical vulnerability that enables rainbow table attacks.

#### Detection Patterns

```bash
# Find unsalted password hashing
Grep: "createHash.*update.*password"
Grep: "sha256.*password|sha512.*password"
Grep: "hash\\(password\\)|hash.*password.*\\)"

# Find missing bcrypt/argon2
Grep: "password.*createHash|password.*digest"
```

#### Vulnerable Patterns - Unsalted Hashes

```typescript
// CRITICAL - No salt, fast hash
const hash = crypto.createHash('sha256').update(password).digest('hex');

// CRITICAL - Weak salt concatenation
const hash = crypto.createHash('sha256').update(salt + password).digest('hex');

// CRITICAL - Using SHA512 for passwords (fast, unsalted)
const hash = crypto.createHash('sha512').update(password).digest('hex');

// CRITICAL - MD5 for passwords
const hash = crypto.createHash('md5').update(password).digest('hex');
```

#### Why Unsalted Hashes Are Critical

| Attack | Impact |
|--------|--------|
| **Rainbow Tables** | Pre-computed hash lookups crack passwords instantly |
| **Hash Lookup** | Common password hashes are indexed online |
| **GPU Cracking** | SHA256 can be computed at billions/second |
| **No Salt** | Identical passwords have identical hashes (reveals duplicates) |

#### Secure Patterns - Proper Password Hashing

```typescript
// SECURE - bcrypt with cost factor 12+
import * as bcrypt from 'bcrypt';
const hash = await bcrypt.hash(password, 12);
const isValid = await bcrypt.compare(password, hash);

// SECURE - Argon2id (best current option)
import * as argon2 from 'argon2';
const hash = await argon2.hash(password, { type: argon2.argon2id });
const isValid = await argon2.verify(hash, password);

// SECURE - scrypt (built-in Node.js)
const salt = crypto.randomBytes(16);
const hash = crypto.scryptSync(password, salt, 64);

// SECURE - PBKDF2 with high iterations
const salt = crypto.randomBytes(16);
const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512');
```

### Detection Patterns
```typescript
// INSECURE - MD5 for security
crypto.createHash('md5').update(password).digest('hex');

// INSECURE - SHA1 for security
crypto.createHash('sha1').update(data).digest('hex');

// INSECURE - Plain SHA256 for passwords
crypto.createHash('sha256').update(password).digest('hex');

// SECURE - bcrypt for passwords
const hash = await bcrypt.hash(password, 12);
const match = await bcrypt.compare(password, hash);

// SECURE - Argon2 for passwords
const hash = await argon2.hash(password, { type: argon2.argon2id });
```

---

## Key Management

### Hardcoded Secrets (CRITICAL)
```typescript
// INSECURE - Hardcoded secret
const JWT_SECRET = "super-secret-key-12345";
const API_KEY = "sk-example-replace-with-real-key";
const DB_PASSWORD = "admin123";

// SECURE - Environment variable (Lambda)
const secret = process.env.JWT_SECRET;

// SECURE - AWS Secrets Manager
const client = new SecretsManagerClient({});
const secret = await client.send(
  new GetSecretValueCommand({ SecretId: 'my-secret' })
);

// SECURE - HashiCorp Vault
const secret = await vault.read('secret/data/my-app');
```

### Detection Patterns
```bash
# Find hardcoded secrets
Grep: "secret.*=.*['\"][^'\"]+['\"]"
Grep: "password.*=.*['\"][^'\"]+['\"]"
Grep: "apiKey.*=.*['\"][^'\"]+['\"]"
Grep: "key.*=.*['\"][a-zA-Z0-9]{16,}['\"]"
```

### Weak Key Derivation
```typescript
// INSECURE - Direct hash of password as key
const key = crypto.createHash('sha256').update(password).digest();

// SECURE - PBKDF2 derivation
const key = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');

// SECURE - scrypt derivation
const key = crypto.scryptSync(password, salt, 32);
```

### Key Rotation
- **Issue:** Static keys in code
- **Severity:** MEDIUM
- **Expected:** Key rotation strategy documented

---

## Random Number Generation

### Insecure Random (CRITICAL)
```typescript
// INSECURE - Predictable
const token = Math.random().toString(36);
const sessionId = Date.now().toString();
const id = Math.floor(Math.random() * 1000000);

// SECURE - Cryptographically secure
const token = crypto.randomBytes(32).toString('hex');
const sessionId = crypto.randomUUID();
const id = crypto.randomInt(1000000);
```

### Detection Patterns
```bash
# Find insecure random
Grep: "Math.random\\(\\)"
Grep: "Date.now\\(\\).*token|id|session"
```

### Use Cases
| Use Case | Insecure | Secure |
|----------|----------|--------|
| Session IDs | Math.random() | crypto.randomBytes(32) |
| Tokens | Date.now() | crypto.randomUUID() |
| CSRF tokens | Math.random() | crypto.randomBytes(16) |
| Password reset | UUID v1 | crypto.randomBytes(32) |

---

## JWT Security

### Algorithm Confusion Attack (CRITICAL)

**CWE-347: Improper Verification of Cryptographic Signature**

JWT algorithm confusion is one of the most critical JWT vulnerabilities. It occurs when the server doesn't properly validate or restrict which algorithms are accepted for token verification.

#### Attack Types

| Attack | Description | Severity |
|--------|-------------|----------|
| **'none' algorithm** | Attacker sets alg: 'none', server accepts unsigned token | CRITICAL |
| **RS256 to HS256** | Attacker uses public key as HMAC secret | CRITICAL |
| **Key confusion** | Asymmetric verification accepts symmetric key | CRITICAL |

#### Detection Patterns

```bash
# Find jwt.verify without algorithm restriction
Grep: "jwt.verify\\([^,]+,[^,]+\\)\\s*[;)]"  # jwt.verify(token, secret) - no options
Grep: "jwt.verify.*secret\\)"                 # jwt.verify ending without options

# Find 'none' algorithm acceptance
Grep: "algorithm.*none|algorithms.*none"

# Find decode vs verify misuse
Grep: "jwt.decode.*\\.[a-zA-Z]+"              # jwt.decode() followed by property access
```

#### Vulnerable Patterns

```typescript
// CRITICAL - No algorithm restriction (accepts 'none')
jwt.verify(token, secret);

// CRITICAL - Explicitly allows 'none' algorithm
jwt.verify(token, secret, { algorithms: ['HS256', 'none'] });

// CRITICAL - RS256/HS256 confusion vulnerability
// When server expects asymmetric but accepts symmetric
jwt.verify(token, publicKey, { algorithms: ['RS256', 'HS256'] });

// CRITICAL - Using decode instead of verify for auth
const payload = jwt.decode(token);
if (payload.admin) { /* Attacker can modify payload */ }
```

#### Secure Patterns

```typescript
// SECURE - Explicit algorithm restriction
jwt.verify(token, secret, { algorithms: ['HS256'] });

// SECURE - Asymmetric with strict algorithm
jwt.verify(token, publicKey, { algorithms: ['RS256'] });

// SECURE - With full validation
jwt.verify(token, secret, {
  algorithms: ['HS256'],
  issuer: 'my-app',
  audience: 'my-api',
  clockTolerance: 30
});
```

#### Attack Scenario: RS256 to HS256

1. Server uses RS256 (asymmetric) - has public/private key pair
2. Public key is often exposed (in JWKS endpoint, config files)
3. Attacker creates JWT with `alg: 'HS256'` (symmetric)
4. Attacker signs JWT using the **public key** as the HMAC secret
5. Server's jwt.verify() accepts HS256 algorithm
6. Server uses public key (now as HMAC secret) to verify
7. Signature matches - token accepted, authentication bypassed

### Weak JWT Secret
```typescript
// INSECURE - Short/weak secret
const token = jwt.sign(payload, 'secret');
const token = jwt.sign(payload, '12345');

// SECURE - Strong secret (256+ bits)
const token = jwt.sign(payload, process.env.JWT_SECRET); // 64+ char random
```

### Missing Claims
```typescript
// INSECURE - No expiration
jwt.sign({ userId: 123 }, secret);

// SECURE - With expiration and issuer
jwt.sign(
  { userId: 123 },
  secret,
  {
    expiresIn: '15m',
    issuer: 'my-app',
    audience: 'my-api'
  }
);
```

### JWT Decode vs Verify
```typescript
// INSECURE - decode doesn't verify signature
const payload = jwt.decode(token);
if (payload.admin) { /* VULNERABLE */ }

// SECURE - verify checks signature
const payload = jwt.verify(token, secret, { algorithms: ['HS256'] });
if (payload.admin) { /* Safe */ }
```

### JWT Storage (Client-Side)
```typescript
// INSECURE - localStorage (XSS vulnerable)
localStorage.setItem('token', jwt);

// SECURE - HttpOnly cookie
res.cookie('token', jwt, {
  httpOnly: true,
  secure: true,
  sameSite: 'strict'
});
```

---

## TLS/SSL Configuration

### Weak TLS Versions
| Version | Status |
|---------|--------|
| SSL 2.0 | **BROKEN** |
| SSL 3.0 | **BROKEN** (POODLE) |
| TLS 1.0 | **DEPRECATED** |
| TLS 1.1 | **DEPRECATED** |
| TLS 1.2 | Acceptable |
| TLS 1.3 | **RECOMMENDED** |

### Weak Cipher Suites
- RC4-based ciphers
- DES/3DES ciphers
- Export ciphers
- NULL ciphers
- MD5-based ciphers

### Secure Configuration
```typescript
const https = require('https');
const options = {
  minVersion: 'TLSv1.2',
  ciphers: [
    'ECDHE-ECDSA-AES256-GCM-SHA384',
    'ECDHE-RSA-AES256-GCM-SHA384',
    'ECDHE-ECDSA-CHACHA20-POLY1305',
    'ECDHE-RSA-CHACHA20-POLY1305'
  ].join(':')
};
```

---

## Severity Matrix

| Issue | Severity | Confidence | CWE | OWASP |
|-------|----------|------------|-----|-------|
| Hardcoded secrets | CRITICAL | HIGH | CWE-798 | A02:2021 |
| MD5/SHA1 for security | CRITICAL | HIGH | CWE-328 | A02:2021 |
| Unsalted password hashing | CRITICAL | HIGH | CWE-916 | A02:2021 |
| JWT algorithm confusion | CRITICAL | HIGH | CWE-347 | A02:2021 |
| JWT 'none' algorithm | CRITICAL | HIGH | CWE-347 | A02:2021 |
| jwt.decode() for auth | CRITICAL | HIGH | CWE-345 | A02:2021 |
| Math.random() for security | CRITICAL | HIGH | CWE-338 | A02:2021 |
| AES-ECB mode | HIGH | HIGH | CWE-327 | A02:2021 |
| DES/3DES/RC4 encryption | HIGH | HIGH | CWE-327 | A02:2021 |
| Weak key derivation | HIGH | MEDIUM | CWE-916 | A02:2021 |
| JWT in localStorage | HIGH | HIGH | CWE-922 | A02:2021 |
| SHA256 unsalted passwords | CRITICAL | HIGH | CWE-916 | A02:2021 |
| Missing JWT expiration | MEDIUM | HIGH | CWE-613 | A02:2021 |
| No key rotation | MEDIUM | LOW | CWE-320 | A02:2021 |
| Weak TLS version | MEDIUM | HIGH | CWE-326 | A02:2021 |

---

## Quick Reference

### Secure Defaults
```typescript
// Encryption
const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);

// Passwords
const hash = await bcrypt.hash(password, 12);

// Random
const token = crypto.randomBytes(32).toString('hex');

// JWT
jwt.verify(token, secret, { algorithms: ['HS256'] });

// Key derivation
const key = crypto.scryptSync(password, salt, 32);
```
