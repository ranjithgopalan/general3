---
name: check-security
description: Focused security review of a specific path - analyzes code, design docs, or IaC for vulnerabilities Use when the user requests this functionality.
---

## Agent Invocation

Use Task tool with `subagent_type="security-reviewer-router"` with the following enriched prompt:

Prompt: """
## User Request
Perform focused security review on: $ARGUMENTS

## Intent: FOCUSED SECURITY REVIEW

### 1. Validate Target Path
- Verify the path exists
- Glob for files in the path
- Report error if path not found

### 2. Detect Review Type from File Types
Automatically determine reviewers based on files found:

| File Pattern | Reviewer |
|--------------|----------|
| *.ts, *.js, *.handler.ts, *.service.ts | code-security-reviewer |
| *.md, *.pdf (architecture, HLD, TDD) | design-security-reviewer |
| *.yaml, *.yml (SAM, CloudFormation) | infrastructure-security-reviewer |
| *.tf, *.tfvars (Terraform) | infrastructure-security-reviewer |
| Files with crypto/jwt/hash imports | crypto-security-reviewer |
| Files with user/pii/ssn/card patterns | data-privacy-reviewer |
| package.json, package-lock.json | dependency-security-reviewer |

### 3. Present Detection Results
Before reviewing, show:
- Files found in path
- Detected file types
- Reviewers to be invoked
- Wait for user confirmation (unless path is small)

### 4. Execute Focused Review
- Skip full codebase scan
- Focus only on specified path
- Apply relevant security checks based on file types

### 5. Generate Focused Report
Output: SECURITY-REVIEW-REPORT.md with:
- Scope: Files reviewed in specified path
- Findings with severity and confidence
- Remediation recommendations
- Note: Limited scope review - recommend full review for comprehensive analysis

### 6. Error Handling
- Path not found: Report error, suggest alternatives
- Permission denied: Report specific files, continue with accessible files
- Parse error: Report file with error, continue with other files
- No security-relevant files: Report "No security-relevant files found in path"
"""

Target path: $ARGUMENTS