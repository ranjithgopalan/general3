# AIDLC-security

Comprehensive security review plugin with multi-agent architecture. Identifies vulnerabilities that automated SAST/DAST tools miss.

## Version

**v1.4.0** - Multi-agent architecture with specialized reviewers including data privacy

## Description

This plugin orchestrates comprehensive security assessments using specialized review agents. It focuses on identifying complex vulnerabilities that automated tools cannot detect, including business logic flaws, authorization bypasses, race conditions, cryptographic weaknesses, infrastructure misconfigurations, dependency vulnerabilities, and data privacy violations.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                  security-reviewer-router                        │
│                      (Orchestrator)                              │
├─────────────────────────────────────────────────────────────────┤
│  Analyze Request → Get Paths → Plan → Delegate → Aggregate      │
└─────────────────────────────────────────────────────────────────┘
                              │
        ┌──────────┬──────────┼──────────┬──────────┬──────────┐
        │          │          │          │          │          │
        ▼          ▼          ▼          ▼          ▼          ▼
┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐
│  design-  │ │   code-   │ │  crypto-  │ │  infra-   │ │dependency-│ │   data-   │
│ security- │ │ security- │ │ security- │ │ structure-│ │ security- │ │  privacy- │
│ reviewer  │ │ reviewer  │ │ reviewer  │ │ security- │ │ reviewer  │ │ reviewer  │
│  (Haiku)  │ │  (Haiku)  │ │  (Haiku)  │ │ reviewer  │ │  (Haiku)  │ │  (Haiku)  │
│           │ │           │ │           │ │  (Haiku)  │ │           │ │           │
└───────────┘ └───────────┘ └───────────┘ └───────────┘ └───────────┘ └───────────┘
```

## Agents

| Agent | Model | Purpose |
|-------|-------|---------|
| `security-reviewer-router` | Inherit | Request analysis, routing, report aggregation |
| `design-security-reviewer` | Haiku | Architecture, API specs, auth design review |
| `code-security-reviewer` | Haiku | Business logic flaws, OWASP Top 10 |
| `crypto-security-reviewer` | Haiku | Encryption, hashing, JWT, key management |
| `infrastructure-security-reviewer` | Haiku | IAM, Lambda, API Gateway, S3, security groups |
| `dependency-security-reviewer` | Haiku | CVE detection, outdated packages, dependency chains |
| `data-privacy-reviewer` | Haiku | PII/PHI detection, GDPR, CCPA, PCI-DSS, HIPAA compliance |

## What It Finds (That SAST/DAST Misses)

| Category | Examples |
|----------|----------|
| **Business Logic** | Authorization bypasses, race conditions, state machine flaws |
| **Access Control** | Horizontal/vertical privilege escalation, IDOR |
| **Cryptographic** | Weak algorithms, hardcoded secrets, JWT vulnerabilities |
| **Design Gaps** | Missing MFA, session management, rate limiting |
| **Infrastructure** | Overly permissive IAM, secrets in env, open security groups |
| **Dependencies** | Known CVEs, outdated packages, vulnerable transitive deps |
| **Data Privacy** | PII/PHI exposure, logging hygiene, timing attacks, compliance gaps |

## Usage

### Skills-Based Invocation

The plugin provides comprehensive security review through skills that are automatically invoked based on your request:

**Comprehensive Security Review:**
```
Perform a security review of my application
Review the code in ./src for security issues
Check our infrastructure for security vulnerabilities
Review ./docs/architecture for design security
Analyze my Lambda functions for cryptographic weaknesses
Review our code for data privacy issues and PII exposure
```

**Focused Security Reviews:**
```
Review security of ./src/services/auth
Check ./infrastructure for security issues
Analyze dependencies for vulnerabilities
```

**Available Skills:**
- `review` - Comprehensive multi-agent security review
- `check-security` - Focused security review with auto-detection
- `check-dependencies` - CVE detection and dependency analysis
- `security-checklists` - OWASP Top 10, crypto patterns, AWS security, data privacy

**Review Workflow:**
1. Analyzes request to determine scope
2. Asks for target paths (if not specified)
3. Presents review plan for approval
4. Delegates to specialized reviewers
5. Aggregates findings by severity
6. **Automatically** generates and saves `SECURITY-REVIEW-REPORT.md` (no user action required)
7. Recommends professional penetration testing

## Skills

### security-checklists

Reference checklists for specialized reviewers:

| Checklist | Used By |
|-----------|---------|
| `owasp-top10.md` | code-security-reviewer |
| `design-security.md` | design-security-reviewer |
| `crypto-patterns.md` | crypto-security-reviewer |
| `aws-security.md` | infrastructure-security-reviewer |
| `dependency-patterns.md` | dependency-security-reviewer |
| `business-logic-patterns.md` | code-security-reviewer |
| `beyond-sast-dast.md` | All reviewers |
| `data-privacy-patterns.md` | data-privacy-reviewer |

## Severity & Confidence Levels

### Severity
| Level | Criteria | Timeline |
|-------|----------|----------|
| **CRITICAL** | Auth bypass, data breach, secrets exposed | 24-48 hours |
| **HIGH** | Privilege escalation, race conditions | 1 week |
| **MEDIUM** | Missing encryption, limited scope flaws | 1 sprint |
| **LOW** | Defense in depth, best practices | Backlog |

### Confidence
| Level | Criteria |
|-------|----------|
| **HIGH** | Clear vulnerable pattern, no mitigations visible |
| **MEDIUM** | Pattern suggests vulnerability, context unclear |
| **LOW** | Unusual pattern, may have mitigations |

## Output

The plugin **automatically generates and saves** `SECURITY-REVIEW-REPORT.md` to the current working directory containing:

- Executive summary with severity counts
- OWASP Top 10 mapping
- Compliance mapping (GDPR, CCPA, PCI-DSS, HIPAA) for data privacy findings
- Detailed findings with:
  - Severity and confidence levels
  - File location and code snippets
  - Proof of concept (safe demonstration)
  - Remediation code
  - Why automated tools miss it
- Remediation roadmap by priority
- Professional penetration testing recommendation

## Important Disclaimer

**This is AI-assisted security review with inherent limitations:**

| Limitation | Impact |
|------------|--------|
| Static analysis only | Cannot verify runtime behavior |
| Pattern-based | May miss novel vulnerabilities |
| No exploitation | Cannot confirm exploitability |
| Context limits | Business logic understanding limited |

**Human-In-The-Loop (HITL) is MANDATORY before remediation.**

## What This Plugin Does NOT Do

- Replace professional penetration testing
- Guarantee security
- Exploit vulnerabilities
- Test production systems

## Example Prompts

```
Perform a security review of my Angular application at ./src
```

```
Review the authentication design in ./docs/HLD.md
```

```
Check our Lambda infrastructure templates in ./infrastructure for security issues
```

```
I need a crypto security review of ./src/services/auth
```

```
Check my project's dependencies for vulnerabilities
```

```
Review our code for data privacy issues and PII exposure
```

## File Structure

```
AIDLC-security/
├── .claude-plugin/
│   └── plugin.json
├── agents/
│   ├── security-reviewer-router.md       # Orchestrator
│   ├── design-security-reviewer.md       # Design review (Haiku)
│   ├── code-security-reviewer.md         # Code review (Haiku)
│   ├── crypto-security-reviewer.md       # Crypto review (Haiku)
│   ├── infrastructure-security-reviewer.md  # Infra review (Haiku)
│   ├── dependency-security-reviewer.md   # Dependency review (Haiku)
│   └── data-privacy-reviewer.md          # Data privacy review (Haiku)
├── skills/
│   └── security-checklists/
│       ├── SKILL.md
│       ├── owasp-top10.md
│       ├── design-security.md
│       ├── crypto-patterns.md
│       ├── aws-security.md
│       ├── dependency-patterns.md
│       ├── business-logic-patterns.md
│       ├── beyond-sast-dast.md
│       └── data-privacy-patterns.md
├── requirements/
│   ├── security-reviewer-brd.md
│   ├── security-reviewer-hld.md
│   └── security-reviewer-lld.md
├── __tests__/
│   ├── security_analysis.test
│   ├── beyond_sast_dast.test
│   ├── owasp_top10_review.test
│   ├── design_security_review.test
│   ├── infrastructure_security.test
│   ├── crypto_implementation_review.test
│   ├── dependency_vulnerabilities.test
│   ├── security_report_generation.test
│   ├── remediation_roadmap.test
│   ├── confidence_levels.test
│   └── data_privacy_review.test
├── acceptance-criteria.md
└── README.md
```

## Requirements Documentation

- **BRD**: Business requirements for security review capabilities
- **HLD**: Multi-agent architecture design
- **LLD**: Vulnerability detection patterns and finding templates

## Version History

| Version | Changes |
|---------|---------|
| 1.3.0 | Added data-privacy-reviewer for PII/PHI detection and compliance (GDPR, CCPA, PCI-DSS, HIPAA) |
| 1.2.0 | Added dependency-security-reviewer for CVE detection |
| 1.1.0 | Added business-logic-patterns and beyond-sast-dast checklists |
| 1.0.0 | Multi-agent architecture with design, code, crypto, infrastructure reviewers |
