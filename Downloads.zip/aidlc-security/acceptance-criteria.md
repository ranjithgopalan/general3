# Security Reviewer - Acceptance Criteria

## Must-Haves

### 1. Comprehensive Security Analysis (Beyond SAST/DAST)
Given a codebase and/or design documents, when I run `/security-review`, then the plugin must perform a deep security analysis identifying vulnerabilities that automated SAST/DAST tools cannot detect:

**Core Capability: Manual-Review-Only Findings**
The plugin focuses on security issues that require human understanding and cannot be detected by automated tools:

| What SAST/DAST Finds | What This Plugin Finds |
|---------------------|------------------------|
| SQL injection patterns | Business logic authorization bypasses |
| XSS in templates | Horizontal/vertical privilege escalation |
| Basic hardcoded secrets | Race conditions (TOCTOU) |
| Known CVEs | State machine workflow bypasses |
| CORS wildcards | Design-level security gaps |
| Missing encryption | Multi-tenant isolation failures |

**Analyzes Both Documents and Source Code:**
- **Design Documents:** HLD, architecture docs, API specifications, TDD
  - Missing MFA design
  - Weak authorization model
  - Missing data classification
  - Incomplete rate limiting strategy
- **Source Code:** Handlers, services, controllers, repositories
  - IDOR without ownership check
  - Role from client input
  - Check-then-act without atomicity
  - State changes without validation

**Finding Format Requirements:**
Each finding MUST include:
- **File path and line numbers** (e.g., `src/services/user.service.ts:45`)
- **Code snippet** showing the vulnerable pattern
- **Severity level** (CRITICAL/HIGH/MEDIUM/LOW)
- **Confidence level** (HIGH/MEDIUM/LOW)
- **Why SAST/DAST Misses** - explanation of why automated tools cannot detect this
- **OWASP/CWE mapping** for categorization
- **Proof of concept** describing how to exploit
- **Remediation code** showing secure alternative

**Cross-File Relationship Analysis:**
- Inconsistent auth middleware across routes
- Shared secrets between services
- Validation at one layer but not another
- Trust boundary violations

**Context-Dependent Vulnerability Detection:**
- MD5 for password hashing (CRITICAL) vs cache keys (acceptable)
- eval() with user input (CRITICAL) vs config input (acceptable)
- JWT decode() for logging (OK) vs authentication (CRITICAL)

**Test Coverage:**
- `__tests__/security_analysis.test`
- `__tests__/beyond_sast_dast.test`

### 2. OWASP Top 10 Assessment
Given code to review, when the plugin analyzes it, then it must check for all OWASP Top 10 (2021) vulnerabilities:

**A01:2021 - Broken Access Control:**
- Horizontal privilege escalation / IDOR (CRITICAL - CWE-639)
- Vertical privilege escalation (CRITICAL - CWE-269)
- Missing function-level access control (CRITICAL - CWE-862)
- Detection: `params.id`, `findById`, `req.body.role`, routes without auth middleware

**A02:2021 - Cryptographic Failures:**
- Weak hashing algorithms MD5/SHA1 (CRITICAL - CWE-328)
- Hardcoded secrets in source code (CRITICAL - CWE-798)
- Insecure random number generation (CRITICAL - CWE-338)
- Detection: `createHash('md5')`, `Math.random()`, `password = "..."`

**A03:2021 - Injection:**
- SQL injection (CRITICAL - CWE-89)
- Command injection (CRITICAL - CWE-78)
- Cross-site scripting / XSS (HIGH - CWE-79)
- NoSQL injection (HIGH - CWE-943)
- Detection: Template literals in queries, `exec()`, `innerHTML`, `find(req.body)`

**A04:2021 - Insecure Design:**
- Race conditions / TOCTOU (HIGH - CWE-362)
- State machine bypass (HIGH - CWE-841)
- Missing rate limiting on auth endpoints
- Detection: Check-then-act patterns, status changes without validation

**A05:2021 - Security Misconfiguration:**
- Debug mode in production (HIGH - CWE-489)
- Verbose error messages (MEDIUM - CWE-209)
- Overly permissive CORS (MEDIUM - CWE-942)
- Detection: `DEBUG=true`, `err.stack`, `origin: '*'`

**A06:2021 - Vulnerable Components:**
- Known CVEs in dependencies (Varies - CWE-1104)
- Outdated packages with security patches
- Detection: `npm audit`, Snyk, OWASP Dependency-Check

**A07:2021 - Authentication Failures:**
- JWT algorithm confusion (CRITICAL - CWE-347)
- Using jwt.decode() for auth decisions (CRITICAL - CWE-345)
- Insecure session configuration (HIGH - CWE-614)
- Weak password policy (MEDIUM - CWE-521)
- Detection: `jwt.verify` without algorithms, `jwt.decode()`, `secure: false`

**A08:2021 - Data Integrity Failures:**
- Insecure deserialization (CRITICAL - CWE-502)
- Prototype pollution (HIGH - CWE-1321)
- Detection: `JSON.parse(untrusted) + Object.assign`, deep merge with `__proto__`

**A09:2021 - Logging Failures:**
- Missing security event logging (MEDIUM - CWE-778)
- Sensitive data in logs (HIGH - CWE-532)
- Detection: Auth endpoints without logging, `logger.info({password})`

**A10:2021 - Server-Side Request Forgery (SSRF):**
- User-controlled URL fetching (HIGH - CWE-918)
- Missing URL validation and allowlisting
- Detection: `fetch(req.body.url)`, `axios(userInput)`

**Finding Requirements:**
- Each finding must include OWASP category (A01-A10)
- Must include CWE reference
- Must include severity level (CRITICAL/HIGH/MEDIUM/LOW)
- Must include vulnerable code snippet with file:line
- Must include remediation recommendation

**Test Coverage:**
- `__tests__/owasp_top10_review.test`
- `__tests__/input_validation_review.test`
- `__tests__/authentication_review.test`
- `__tests__/api_security_review.test`

### 3. Business Logic Flaw Detection
Given application code with business logic, when security review executes, then the plugin must identify business logic flaws that automated SAST/DAST tools cannot detect:

**Horizontal Privilege Escalation (User A accesses User B's data):**
- IDOR (Insecure Direct Object Reference) patterns (CRITICAL - CWE-639)
- Missing ownership validation on resource access by ID
- Batch operations without user scope filtering
- Detection: `params.id`, `findById` without ownership check
- WHY SAST MISSES: Cannot understand that resources belong to specific users

**Vertical Privilege Escalation (User becomes Admin):**
- Role/permission from client input (CRITICAL - CWE-269)
- Spread operator copying sensitive fields (`...req.body`)
- Missing field whitelisting on user updates
- Detection: `req.body.role`, `req.body.isAdmin`, `Object.assign(user, data)`
- WHY SAST MISSES: Cannot know that roles should come from server, not client

**Authorization Bypass Patterns:**
- Missing auth middleware on routes (CRITICAL - CWE-862)
- Inconsistent middleware application across related endpoints
- Auth bypass conditions left in production code
- Missing default deny in permission checks
- Detection: Routes without `authMiddleware`, `@Public` decorators
- WHY SAST MISSES: Cannot determine business intent of what needs protection

**Race Conditions (TOCTOU - Time of Check vs Time of Use):**
- Double-spend vulnerabilities on balance/credits (HIGH - CWE-362)
- Overselling/overbooking (inventory checked then decremented non-atomically)
- Coupon/code reuse through concurrent requests
- Non-atomic check-then-act patterns
- Detection: `if (balance >= amount) { deduct() }` pattern without transaction
- WHY SAST MISSES: Cannot understand timing dependencies between operations

**State Machine Bypass (Skipping workflow steps):**
- Direct state changes without transition validation (HIGH - CWE-841)
- State from client input allowing arbitrary status changes
- Missing prerequisite checks before state transitions
- Detection: `status = req.body.status`, state assignment without validation
- WHY SAST MISSES: Cannot understand valid workflow sequences

**Finding Format Requirements:**
- Each finding must include "WHY SAST/DAST MISSES" explanation
- Must include CWE reference for the vulnerability class
- Must include proof-of-concept attack description
- Must include both vulnerable and secure code patterns

**Test Coverage:**
- `__tests__/security_analysis.test`

### 4. Security Report Generation
Given completed security analysis, when the review finishes, then the plugin must generate a comprehensive security report with findings categorized by severity, specific code locations, and remediation recommendations.

**Test Coverage:**
- `__tests__/security_report_generation.test`

### 5. Remediation Roadmap
Given security findings with different severity levels, when the report is generated, then the plugin must provide a remediation roadmap that groups findings by timeline to enable priority-based planning:
- **CRITICAL:** Immediate (24-48 hours) - P0 priority, block deployments
- **HIGH:** Short-term (1 week) - P1 priority, fix within current sprint
- **MEDIUM:** Medium-term (1 sprint) - P2 priority, plan for upcoming sprint
- **LOW:** Long-term (backlog) - P3 priority, address when capacity allows

The roadmap must include:
- Findings grouped by remediation timeline
- Priority levels (P0-P3) for each group
- SLA targets for each timeline
- Recommended actions for each priority level
- Summary table with counts and target completion dates

**Test Coverage:**
- `__tests__/remediation_roadmap.test`

### 6. Confidence Levels with Evidence
Given security findings identified during review, when findings are reported, then each finding must include a confidence level (HIGH/MEDIUM/LOW) with supporting evidence to help users prioritize verification efforts:

**Confidence Level Definitions:**
- **HIGH:** Clear code evidence with known vulnerability pattern
  - Exact code snippet showing vulnerable behavior
  - Matches established CWE/OWASP patterns
  - No visible mitigations in reviewed code
- **MEDIUM:** Pattern detected but context unclear
  - Suspicious pattern that often indicates vulnerability
  - Missing visibility into runtime behavior or configuration
  - Cannot confirm if mitigations exist elsewhere
- **LOW:** Unusual pattern that may have mitigating factors
  - Code deviates from best practices
  - Partial mitigations may be in place
  - Vulnerability depends on specific runtime conditions

**Evidence Requirements (for each finding):**
- Code snippet with file:line reference
- Pattern match (CWE/OWASP category)
- Context analysis explaining why it's vulnerable
- List of mitigations checked and their status
- Confidence justification explaining the assigned level

**Test Coverage:**
- `__tests__/confidence_levels.test`

### 7. Design Security Review (Security-First Architecture)
Given design documents (HLD, API specs, architecture documents), when the plugin reviews them, then it must identify security gaps before code is written to enable security-first architecture:

**Authentication Design Review:**
- MFA design and enforcement rules
- Session management (timeout, invalidation, storage)
- Token strategy (type, expiration, refresh, revocation)
- Account lockout and brute force protection
- Password policy and credential storage

**Authorization Design Review:**
- Least privilege principle (default-deny)
- Role separation (RBAC/ABAC design)
- Resource ownership model
- Admin privilege isolation
- Object-level and function-level authorization

**Data Protection Review:**
- Data classification scheme (sensitivity levels)
- Encryption at rest (database, files, backups)
- Encryption in transit (TLS version, certificates)
- Key management strategy and rotation
- Data retention and disposal policies
- Compliance requirements (GDPR, CCPA)

**API Security Review:**
- Rate limiting strategy (per-endpoint, per-user)
- Input validation and schema enforcement
- Error handling (no information disclosure)
- CORS policy (restricted origins, no wildcards)
- Authentication requirements per endpoint

**Supported Document Types:**
- High-Level Design (HLD)
- API Specifications (OpenAPI/Swagger)
- Architecture Documents
- Technical Design Documents (TDD)
- Data Flow Diagrams

**Test Coverage:**
- `__tests__/design_security_review.test`

### 8. AWS Infrastructure Security Review
Given SAM/CloudFormation/Terraform templates, when the plugin reviews infrastructure code, then it must identify security misconfigurations to discover infrastructure vulnerabilities:

**IAM Policy Review (Least Privilege Validation):**
- Validates that IAM policies follow least privilege principle
- Detects wildcard actions (Action: '*', s3:*, ec2:*)
- Detects wildcard resources (Resource: '*')
- Identifies dangerous IAM actions (iam:PassRole, iam:CreateRole, sts:AssumeRole)
- Checks for missing conditions (IP/VPC/MFA restrictions)
- Flags admin policies (AdministratorAccess, PowerUserAccess, *FullAccess)

**Lambda Security Review (Secrets & Configuration):**
- Checks Lambda environment variables for exposed secrets
- Detects hardcoded passwords, API keys, tokens, credentials
- Validates connection strings don't contain embedded passwords
- Checks for missing VPC configuration on data-processing Lambdas
- Validates timeout and resource limits

**SAM/CloudFormation Template Review:**
- Reviews template structure for security misconfigurations
- Validates resource policies and permissions
- Checks for missing encryption configurations
- Identifies public resource exposure

**Security Group Review (Network Security):**
- Identifies overly permissive security groups (0.0.0.0/0)
- Detects sensitive ports open to internet (SSH/22, RDP/3389, databases)
- Checks for all ports/protocols open (-1, 0-65535)
- Validates egress rules for data exfiltration prevention

**API Gateway Security Review:**
- Checks for missing authentication on endpoints
- Validates authorizer configuration (Cognito, Lambda, IAM)
- Detects CORS wildcards (AllowOrigin: '*')
- Checks for rate limiting and throttling
- Validates WAF integration

**Supported IaC Formats:**
- AWS SAM (template.yaml)
- CloudFormation (*.yaml, *.json)
- Terraform (*.tf)
- AWS CDK (cdk*.ts)

**Test Coverage:**
- `__tests__/infrastructure_security.test`
- `__tests__/iam_least_privilege.test`
- `__tests__/lambda_secrets_exposure.test`
- `__tests__/security_groups.test`
- `__tests__/api_gateway_auth.test`

## Nice-to-Haves

### 9. Dependency Vulnerability Analysis
Given a project with dependencies via `/check-dependencies`, when the plugin analyzes them, then it must identify and report on third-party vulnerabilities:

**CVE Detection:**
- Run `npm audit --json` to identify known CVEs
- Extract CVE IDs and CVSS scores
- Map vulnerabilities to OWASP A06:2021 - Vulnerable and Outdated Components
- Identify severity levels (critical, high, moderate, low)

**Outdated Package Detection:**
- Run `npm outdated --json` to find packages with updates
- Flag packages with security patches available
- Identify deprecated packages needing replacement
- Note packages significantly behind latest version

**Dependency Chain Analysis:**
- Distinguish direct vs transitive dependencies
- Show dependency chain for transitive vulnerabilities
- Identify which direct dependencies bring in vulnerable transitive deps
- Use `npm ls` and `npm explain` for chain visualization

**Package Manifest Support:**
- Work with package.json for dependency declarations
- Work with package-lock.json for actual installed versions
- Support yarn.lock and pnpm-lock.yaml
- Handle npm workspaces and monorepos

**Prioritized Remediation:**
- **CRITICAL (CVE 9.0-10.0):** Immediate fix required (24-48 hours)
  - RCE, prototype pollution leading to RCE, auth bypass
  - Provide: `npm audit fix` or `npm install pkg@version`
- **HIGH (CVE 7.0-8.9):** Fix within 1 week
  - SSRF, significant data exposure, privilege escalation
  - Provide specific update commands
- **MEDIUM (CVE 4.0-6.9):** Fix within 1 sprint
  - ReDoS, limited impact vulnerabilities
  - Schedule for sprint planning
- **LOW (CVE 0.1-3.9):** Backlog
  - Minor impact, theoretical risks
  - Include in maintenance cycles

**Remediation Output:**
- Specific npm/yarn commands for each fix
- Breaking change warnings for major version updates
- Alternative package suggestions for deprecated deps
- Override/resolution configuration for transitive deps

**Test Coverage:**
- `__tests__/dependency_vulnerabilities.test`

### 10. Cryptographic Implementation Review
Given code using cryptography, when security review runs, then the plugin must assess cryptographic implementations and detect encryption misuse:

**Weak Algorithm Detection:**
- MD5 used for any security purpose (CRITICAL - CWE-328)
- SHA1 used for any security purpose (CRITICAL - CWE-328)
- AES-ECB mode encryption (HIGH - CWE-327, pattern leakage)
- DES/3DES/RC4 usage (HIGH - CWE-327, broken/deprecated)

**Key Management Review:**
- Hardcoded secrets in source code (CRITICAL - CWE-798)
- Weak key derivation (hash of password as key) (HIGH - CWE-916)
- Keys in environment variables without secrets manager
- Missing key rotation strategy

**Random Number Generation:**
- Math.random() for security tokens/IDs (CRITICAL - CWE-338)
- Date.now() for security purposes (HIGH - predictable)
- Recommend crypto.randomBytes() or crypto.randomUUID()

**JWT Security:**
- Algorithm confusion vulnerability (CRITICAL - CWE-347)
  - jwt.verify() without algorithms array restriction
  - Acceptance of 'none' algorithm
  - RS256/HS256 key confusion
- jwt.decode() used for authentication decisions (CRITICAL - CWE-345)
- Weak JWT secrets (HIGH)
- Missing expiration claims (MEDIUM - CWE-613)
- JWT stored in localStorage (HIGH - CWE-922, XSS vulnerable)

**Password Hashing:**
- Unsalted password hashing (CRITICAL - CWE-916)
- SHA256/SHA512 used directly for passwords (CRITICAL - rainbow tables)
- Weak salt concatenation patterns (HIGH)
- Missing bcrypt/Argon2/scrypt/PBKDF2 for passwords

**Test Coverage:**
- `__tests__/crypto_implementation_review.test`

### 11. Data Privacy and PII/PHI Detection
Given code that handles sensitive data, when the data-privacy-reviewer analyzes it, then it must identify sensitive data exposure, privacy violations, and compliance gaps:

**PII/PHI Detection:**
- SSN patterns in responses without masking (CRITICAL - CWE-359)
- Credit card numbers (PAN) in logs or responses (CRITICAL - CWE-532, PCI-DSS 3.3)
- Protected Health Information (PHI) in logs (CRITICAL - CWE-532, HIPAA)
- Email, phone, address exposure in inappropriate contexts (HIGH)

**Data Masking Validation:**
- Unmasked SSN in API responses (CRITICAL - GDPR Art. 5)
- Full credit card numbers returned (CRITICAL - PCI-DSS 3.3)
- PII in error messages (HIGH)
- Detection: `ssn`, `cardNumber`, `socialSecurity` in return statements

**Logging Hygiene:**
- Passwords or credentials in logs (CRITICAL - CWE-532)
- Auth tokens or session IDs logged (HIGH - CWE-532)
- PII in log messages (HIGH)
- Full request body logging without sanitization (HIGH)
- Detection: `logger.*password`, `console.*token`, `log.*ssn`

**Timing Attack Detection:**
- User enumeration via different response paths (MEDIUM - CWE-208)
- Non-constant-time secret comparison (MEDIUM - CWE-208)
- Password validation timing leaks
- Detection: Different code paths for valid/invalid users, `===` for secrets

**Data Retention Issues:**
- Soft delete retaining PII (HIGH - GDPR Art. 17)
- No data expiration policy (HIGH - GDPR Art. 5)
- GDPR right-to-erasure gaps
- Detection: `isDeleted` patterns without PII purge

**Compliance Mapping:**
Each finding must be mapped to applicable regulations:
- **GDPR:** Art. 5 (minimization), Art. 17 (erasure), Art. 32 (security)
- **CCPA:** Right to delete, right to know, opt-out of sale
- **PCI-DSS:** Req. 3.3 (mask PAN), Req. 3.4 (encrypt storage), Req. 4.1 (TLS)
- **HIPAA:** 164.312 (access controls), 164.308 (audit controls)

**Test Coverage:**
- `__tests__/data_privacy_review.test`

---

## Enterprise Security Standards (Code-Analyzable Controls)

The following acceptance criteria are derived from enterprise security standards documented in `reference/code-analyzable-controls.txt`. These controls can be verified through static code analysis, SAST tools, or manual code review.

### 12. Session Management Standards Validation
Given code containing session configuration, when the plugin reviews authentication implementations, then it should validate session timeouts against enterprise standards:

**Session Timeout Requirements:**
- **Maximum session duration:** 60 minutes
  - Severity: HIGH
- **Idle timeout (re-authentication):** 15 minutes
  - Severity: HIGH
- **Remote session re-authentication:** Within 12 hours
  - Severity: MEDIUM

**Detection Approach:**
The reviewer should look for patterns related to:
- Session duration and expiration configuration
- Cookie and token expiration settings
- Idle timeout implementations
- Session middleware configuration

**Finding Requirements:**
- Each finding should include current configured value vs required maximum
- Should include file:line reference to configuration
- Should provide remediation guidance

**Test Coverage:**
- `__tests__/session_management_standards.test`

### 13. Account Lockout Policy Validation
Given authentication code, when the plugin reviews login implementations, then it should validate account lockout policies against enterprise standards:

**Lockout Requirements:**
- **Maximum failed attempts:** 6 consecutive invalid attempts
  - Severity: HIGH for excessive thresholds
- **Minimum lockout duration:** 30 minutes
  - Severity: HIGH
- **Missing lockout implementation:** No failed attempt tracking
  - Severity: HIGH

**Detection Approach:**
The reviewer should look for patterns related to:
- Login attempt counters and tracking
- Lockout duration settings
- Account lock/unlock functions
- Rate limiting on authentication endpoints

**Lockout Bypass Detection:**
- Counter reset on partial success
- IP-based only lockout (without account-based)
- Lockout state stored client-side only

**Test Coverage:**
- `__tests__/account_lockout_standards.test`

### 14. Password Policy Enforcement Validation
Given password handling code, when the plugin reviews authentication, then it should validate password policies against enterprise standards:

**Password Requirements:**
| Account Type | Min Length | Complexity | History | Rotation |
|--------------|-----------|------------|---------|----------|
| Human accounts | 8 characters | Upper, lower, numeric, special | 13 previous | 90 days |
| Non-human accounts | 24 characters | Upper, lower, numeric, special | N/A | 365 days |

**Detection Approach:**
The reviewer should look for patterns related to:
- Password length validation
- Password history storage and comparison
- Password expiration/age tracking
- Complexity requirement implementations

**Checks Required:**
- Password validation allowing less than minimum length
- Service account credentials below required length
- Insufficient password history checking
- Missing password history implementation
- Password expiration exceeding limits

**Test Coverage:**
- `__tests__/password_policy_standards.test`

### 15. Logging Format and Standards Compliance
Given logging implementations, when the plugin reviews code, then it should validate logging against enterprise logging standards:

**Format Requirements:**
- **Structured format:** JSON or similar structured format (no unstructured text logs)
- **Timestamp format:** Standard format (e.g., ISO 8601) with timezone

**Required Log Elements:**
| Element | Description | Required |
|---------|-------------|----------|
| Timestamp | Standard format at start | MANDATORY |
| Action | Type of action performed | MANDATORY |
| Source identifiers | User, IP, etc. | MANDATORY |
| Destination identifiers | Resources accessed | MANDATORY |
| Description | Summary of what transpired | MANDATORY |
| Subsystem action | Process/transaction identifiers | RECOMMENDED |

**Security Event Logging Coverage:**
- Success and failed authentications
- Privileged authentications
- Account lifecycle events (creation, deletion, locks, modification)
- Access right alterations
- Input validation failures
- Session management events
- Application errors and system events

**Detection Approach:**
The reviewer should look for patterns related to:
- Logger configuration
- Unstructured logging statements
- Timestamp format settings
- Authentication event logging
- Error handling without logging

**Test Coverage:**
- `__tests__/logging_standards.test`

### 16. Debug and Test Code Detection
Given source code, when the plugin scans for production readiness, then it should detect debug, test, and development artifacts:

**Detection Categories:**
| Category | Description | Severity |
|----------|-------------|----------|
| Console statements | Debug output statements | MEDIUM |
| Debug flags | Development mode configurations | HIGH |
| Test credentials | Common test usernames/passwords | CRITICAL |
| Commented code | Large blocks with sensitive info | MEDIUM |
| Debug endpoints | Development-only routes | HIGH |

**Detection Approach:**
The reviewer should look for patterns related to:
- Console output and debugger statements
- Environment/debug flag checks
- TODO/FIXME style comments
- Development-only routes
- Test fixtures with realistic-looking data

**Test Coverage:**
- `__tests__/debug_test_code_detection.test`

### 17. E-Commerce Security Controls
Given e-commerce or transaction processing code, when the plugin reviews it, then it should validate e-commerce specific security controls:

**Required Controls:**
- **Fraud detection:** Transaction anomaly detection, velocity checks
  - Severity: MEDIUM
- **Transaction integrity:** Checksums, signatures, anti-replay
  - Severity: HIGH
- **Idempotency:** Prevent duplicate transactions
  - Severity: HIGH
- **Transaction logging:** Complete audit trail
  - Severity: HIGH

**Detection Approach:**
The reviewer should look for patterns related to:
- Transaction and payment handlers
- Fraud and anomaly detection logic
- Idempotency implementations
- Transaction logging statements

**Test Coverage:**
- `__tests__/ecommerce_security.test`

### 18. Mobile Application Security Controls
Given mobile application code (React Native, Flutter, iOS, Android), when the plugin reviews it, then it should validate mobile-specific security controls:

**Required Controls:**
| Control | Description | Severity if Missing |
|---------|-------------|---------------------|
| Screenshot prevention | Prevent screen capture on sensitive screens | HIGH |
| Secure credential storage | Platform-specific secure storage (Keychain, Keystore) | CRITICAL |
| Certificate pinning | SSL/TLS certificate pinning | HIGH |
| Cleartext traffic block | Prevent unencrypted network traffic | HIGH |

**Detection Approach:**
The reviewer should look for patterns related to:
- Screen security flags and settings
- Secure storage usage vs insecure storage
- Certificate pinning configurations
- Network security configurations
- Credential storage in local storage

**Test Coverage:**
- `__tests__/mobile_security.test`

### 19. Vulnerability Remediation SLA Classification
Given security findings, when the plugin generates reports, then it should assign Risk Priority (RP) classifications for enterprise vulnerability management:

**RP Classification Matrix:**
| RP Level | Timeline | Criteria |
|----------|----------|----------|
| RP1 | 24 hours - 7 days | CRITICAL + external-facing + actively exploited |
| RP2 | 14 days | CRITICAL or HIGH + external-facing |
| RP3 | 30 days | HIGH severity vulnerabilities |
| RP4 | 60 days | MEDIUM severity, external exposure |
| RP5 | 90 days | MEDIUM severity, internal only |
| RP6 | 180 days | LOW severity, limited impact |
| RP7 | 360 days | Informational, best practice gaps |

**Report Requirements:**
- Each finding should include RP classification
- Report should include summary by RP level
- Remediation roadmap should group by RP timeline

**Test Coverage:**
- `__tests__/remediation_sla_classification.test`

### 20. API Gateway and Backend Exposure Validation
Given infrastructure code, when the plugin reviews API configurations, then it should validate approved API gateway usage:

**Requirements:**
- API Gateway should be configured for inbound requests
- No direct Lambda/backend exposure to internet
- Proper authorizer configuration
- No endpoints without authentication (except explicitly public)

**Detection Approach:**
The reviewer should look for patterns related to:
- API Gateway resources in IaC
- Direct Lambda/service exposure
- Authorizer configurations

**Test Coverage:**
- `__tests__/api_gateway_enforcement.test`

### 21. Re-authentication Requirements Validation
Given sensitive operation handlers, when the plugin reviews them, then it should validate re-authentication requirements:

**Re-auth Required For:**
- Password/credential changes (current password required)
- Email/username changes
- MFA configuration changes
- Account deletion
- Payment method changes
- Admin privilege assignments
- Extended sessions for remote access

**Detection Approach:**
The reviewer should look for patterns related to:
- Password change handlers
- Profile/account update endpoints
- Admin operation handlers
- Re-authentication middleware/guards
- Current password confirmation

**Test Coverage:**
- `__tests__/reauth_requirements.test`

### 22. Default Credential and Configuration Detection
Given code and configuration files, when the plugin scans them, then it should detect default credentials and configurations:

**Default Usernames to Flag:**
- Common default usernames (admin, root, guest, test, etc.)
- Database default accounts
- Default service account names

**Default Passwords to Flag:**
- Common default passwords
- Vendor-specific defaults
- Sequential/simple passwords

**Other Defaults:**
- Default encryption keys or secrets
- Default session secrets
- Hardcoded default ports without override capability

**Detection Approach:**
The reviewer should look for patterns related to:
- Common default usernames and passwords
- Hardcoded credentials
- Default configuration values

**Test Coverage:**
- `__tests__/default_credential_detection.test`

### 23. Web Services Non-Repudiation and DoS Protection
Given web service implementations, when the plugin reviews them, then it should validate non-repudiation and DoS protection controls:

**Non-Repudiation Requirements:**
- Request/response signing for critical operations
- HMAC or digital signature validation
- Timestamp validation for replay prevention

**DoS Prevention Requirements:**
- Request body size limits
- Array/collection size limits
- File upload size limits
- Query complexity limits (GraphQL)
- Rate limiting on endpoints

**Detection Approach:**
The reviewer should look for patterns related to:
- Message signing implementations
- Request size limit configurations
- Rate limiter middleware
- Transport security settings

**Test Coverage:**
- `__tests__/web_services_security.test`

### 24. Database Access Scope Validation
Given database access code, when the plugin reviews it, then it should validate least privilege principles:

**Checks Required:**
- SELECT * without specific column lists (flag for review)
- Queries accessing multiple schemas without justification
- Dynamic table/column name construction
- Dynamic SQL with user input
- Overly permissive database roles

**Detection Approach:**
The reviewer should look for patterns related to:
- SELECT * patterns
- Dynamic SQL construction
- Database role/permission configurations

**Test Coverage:**
- `__tests__/database_access_scope.test`

### 25. Client-Side Data Exposure Prevention
Given frontend/client-side code, when the plugin reviews it, then it should detect sensitive data exposure:

**Exposure Categories:**
| Category | Description | Severity |
|----------|-------------|----------|
| Internal URLs | Internal endpoints in client bundles | HIGH |
| Stack traces | Error details sent to client | MEDIUM |
| Server paths | File system paths in responses | MEDIUM |
| Version info | Server/framework versions disclosed | LOW |
| Business logic | Calculations that should be server-side | MEDIUM |

**Detection Approach:**
The reviewer should look for patterns related to:
- Internal hostnames in client code
- Error response structures
- Client-side business calculations
- Verbose error configurations

**Test Coverage:**
- `__tests__/client_side_exposure.test`

### 26. Federation and SSO Standard Compliance
Given authentication integration code, when the plugin reviews it, then it should validate federation standards:

**Required Federation Standards:**
SaaS applications should support one of:
- SAML 2.0
- OAuth 2.0
- OpenID Connect (OIDC)

**Validation Requirements:**
- Proper signature validation on tokens
- Issuer verification
- Audience validation
- Expiration checking
- No custom authentication bypassing SSO

**Detection Approach:**
The reviewer should look for patterns related to:
- SAML, OAuth, OIDC configurations
- Token validation implementations
- IdP/SSO integration code
- Custom authentication implementations

**Test Coverage:**
- `__tests__/federation_sso_compliance.test`

---

## Quick Reference: Enterprise Security Standards Values

| Standard | Value | Reference |
|----------|-------|-----------|
| Max session duration | 60 minutes | Session Management |
| Idle timeout | 15 minutes | Session Management |
| Remote re-auth | 12 hours | Session Management |
| Failed login attempts | 6 attempts | Account Lockout |
| Lockout duration | 30 minutes | Account Lockout |
| Human password length | 8 characters | Password Policy |
| Non-human password length | 24 characters | Password Policy |
| Password history | 13 previous | Password Policy |
| Human password rotation | 90 days | Password Policy |
| Non-human password rotation | 365 days | Password Policy |
| TLS minimum version | TLS 1.2 | Cryptography |
| RP1 remediation | 24 hours - 7 days | Vulnerability Management |
| RP2 remediation | 14 days | Vulnerability Management |
| RP3 remediation | 30 days | Vulnerability Management |
| RP4 remediation | 60 days | Vulnerability Management |
| RP5 remediation | 90 days | Vulnerability Management |
| RP6 remediation | 180 days | Vulnerability Management |
| RP7 remediation | 360 days | Vulnerability Management |

---

## Additional Test Coverage

The following tests cover important aspects of the Security Reviewer plugin:

- **Error Handling Security:** `__tests__/error_handling_security.test`
