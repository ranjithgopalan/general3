# AIDLC-springboot

Java Spring Boot generation for modernization programmes whose relational schema
**already exists and must not change**.

## Why this plugin exists separately from AIDLC-lambda

`AIDLC-lambda` generates Node.js/TypeScript on AWS Lambda. Its router, generator,
enforcer and test-generator arrangement is a good structure, and this plugin
borrows it — but none of its content transfers, so it is a sibling rather than an
extension. `AIDLC-lambda` stays installed and unchanged for the applications that
use it.

## The constraint that shapes everything

A conventional Spring Boot generator treats JPA entities as the source of truth and
lets Hibernate shape the schema. This plugin is built for the opposite situation:

- existing tables are used **without modification**
- existing stored procedures are **reused as-is**
- `spring.jpa.hibernate.ddl-auto` is **always** `none`
- Flyway runs **baseline + validate**; additive migrations need recorded DBA approval
- business logic already in a procedure is **called**, never reimplemented

Programmes routinely ask for "JPA and Flyway" *and* "do not change the schema".
Those are compatible in exactly one configuration, documented in
[`skills/springboot-patterns/immutable-schema.md`](skills/springboot-patterns/immutable-schema.md).
When a request falls outside it, the plugin says so rather than generating the
`ALTER` — that is the one failure mode which cannot be walked back.

## Commands

| Skill | Purpose |
|-------|---------|
| `/AIDLC-springboot:implement` | Generate a module from an approved Service-TDD |
| `/AIDLC-springboot:validate` | Check code against layering, schema and security rules |
| `/AIDLC-springboot:test` | Generate JUnit 5 / Mockito / MockMvc / Testcontainers suites |
| `/AIDLC-springboot:explore` | Read-only analysis of an existing module |

## Agents

| Agent | Generates |
|-------|-----------|
| `router` | Routing, plan confirmation, schema-authority gate |
| `rest-service-generator` | `@RestController`, mappings, validation, DTOs, OpenAPI |
| `service-layer-generator` | `@Service` logic with transaction and error boundaries |
| `repository-generator` | JPA entities and repositories as read-only mappings |
| `datasource-config-generator` | JDBC/Hibernate config, pooling, health checks |
| `migration-generator` | Flyway baseline/validate plus approved additive templates |
| `stored-procedure-dao-generator` | `CallableStatement` wrappers and explicit row mappers |
| `spring-batch-generator` | Job, Step, reader/processor/writer, restart, reconciliation |
| `messaging-generator` | Listeners and publishers with retry, idempotency, DLQ |
| `exception-handler-generator` | `@ControllerAdvice`, typed errors, correlation ID |
| `security-config-generator` | OIDC resource server, authority mapping, fixtures |
| `springboot-test-generator` | JUnit 5, Mockito, MockMvc, Testcontainers |
| `build-config-generator` | `build.gradle`, Dockerfile, CI pipeline, quality gates |

## Prerequisites

1. **An approved Service-TDD.** The plugin reads requirements from it; it does not
   infer them from a file listing.
2. **A schema snapshot** for every datasource the module reads — table columns with
   nullability, and stored-procedure signatures with **parameter directions**. A
   direction registered wrongly produces code that compiles, runs and silently
   returns nothing.
3. **The schema-authority decision recorded.** If the TDD does not state whether
   the schema may change, the router asks. It does not guess in either direction.

## Generation order

Later agents read what earlier ones produced:

```
datasource-config  ->  stored-procedure-dao  ->  repository  ->  service
                                                                   |
build-config  <-  springboot-test  <-  security  <-  exception  <-  rest-service
```

`spring-batch-generator` and `messaging-generator` run after the service layer,
when the TDD describes scheduled or asynchronous work.

## What this plugin refuses

- Emitting DDL against a pre-existing table, view or procedure
- Generating data access without a schema snapshot
- Reimplementing stored-procedure logic while the procedure remains in use
- `flyway.clean` in any profile
- Positional result-set reads
- Any `ddl-auto` value other than `none`

Each refusal is reported with the reason and the safe alternative.

## Validation

```bash
python scripts/validate-plugins.py --plugin AIDLC-springboot --verbose
```

The rules the plugin generates to are also the rules
`/AIDLC-springboot:validate` enforces — see
[`skills/springboot-patterns/validation-checklist.md`](skills/springboot-patterns/validation-checklist.md).
CRITICAL findings there are the ones that can reach production data.
