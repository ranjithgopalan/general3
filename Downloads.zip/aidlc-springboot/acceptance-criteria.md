# Acceptance Criteria - AIDLC-springboot

**Plugin:** AIDLC-springboot
**Version:** 1.0.0
**Document Type:** Acceptance Criteria

---

## IMPORTANT DISCLAIMER: Generative AI Limitations and HITL Requirement

**This plugin is powered by Generative AI (Large Language Model)** and has
inherent limitations:

| Limitation | Description | Implication |
|------------|-------------|-------------|
| **Hallucination risk** | Generated Java may compile and still be wrong | A mis-mapped column is a financial defect |
| **Non-determinism** | Two runs may decompose services differently | Review each run; do not diff-and-assume |
| **Schema inference** | The model may guess a column or parameter it cannot see | Never generate data access without a snapshot |
| **Confident errors** | No calibrated uncertainty | A clean-looking DAO may bind the wrong direction |

**Human-In-The-Loop (HITL) is MANDATORY:**

- NEVER deploy generated data-access code without reviewing it against the schema snapshot
- NEVER apply a generated migration without DBA approval
- NEVER accept a stored-procedure DAO without an integration test against a restored copy
- ALWAYS have a qualified Java developer review generated output
- ALWAYS verify parameter directions and column nullability against the snapshot

**This tool is an assistant, NOT a replacement for a developer or a DBA.**

---

## AC1: Schema authority is established before data access

- **Given** a Service-TDD that does not state whether the schema may change
- **When** data-access generation is requested
- **Then** the router asks rather than assuming, and generates nothing until answered

## AC2: No DDL against pre-existing objects

- **Given** any generation request
- **When** output is produced
- **Then** no ALTER, DROP or TRUNCATE names a pre-existing object, and `ddl-auto`
  is `none` in every profile

## AC3: Stored-procedure reuse

- **Given** a snapshot containing a procedure that implements a business rule
- **When** data access for that rule is generated
- **Then** a CallableStatement wrapper is produced and the logic is not
  reimplemented as a derived query

## AC4: Parameter fidelity

- **Given** a procedure with IN, OUT and return parameters
- **When** the DAO is generated
- **Then** every parameter is registered with the direction and type from the
  snapshot, and every result column is read by name

## AC5: Null semantics

- **Given** a nullable numeric column
- **When** the row mapper is generated
- **Then** null is carried through as null, distinct from zero, and a test asserts it

## AC6: Undiscoverable result shapes

- **Given** a procedure whose first result set cannot be described
- **When** the DAO is generated
- **Then** a TODO(schema) records the procedure and reason, an assertion test is
  generated, and no column list is invented

## AC7: Flyway posture

- **Given** a request for Flyway configuration
- **When** it is generated
- **Then** baseline-on-migrate and validate-on-migrate are enabled, clean-disabled
  is true, and additive scripts carry an approval reference

## AC8: Layering

- **Given** a generated module
- **When** it is validated
- **Then** controllers hold no business logic, no entity crosses the HTTP boundary,
  and exactly one transaction boundary exists per business operation

## AC9: Error contract

- **Given** any generated endpoint
- **When** it fails
- **Then** no stack trace, SQL text or schema object name appears in the response,
  and a correlation ID is present

## AC10: Security

- **Given** a generated security configuration
- **When** it is reviewed
- **Then** authorization denies by default, tokens are validated against the
  issuer, no secret is a literal, and negative authorization tests exist

## AC11: Separate builds

- **Given** generated UI and generated API
- **When** each is built
- **Then** they build independently and produce separate release artifacts

## AC12: Refusal reporting

- **Given** a request that would violate AC2, AC3 or AC7
- **When** it is refused
- **Then** the refusal names the requirement, the conflict, and the safe alternative

---

## Definition of Done

- [ ] `python scripts/validate-plugins.py --plugin AIDLC-springboot` passes
- [ ] Generated output compiles under `./gradlew build`
- [ ] DAO integration tests pass against a restored copy, never production
- [ ] A schema diff before and after shows the target schema unchanged
- [ ] Every CRITICAL item in `validation-checklist.md` is clear
