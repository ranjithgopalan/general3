# Changelog - AIDLC-springboot

## **1.0.0** - Initial release (2026-08-10)

### Added

- `router` agent with a schema-authority gate. Refuses to dispatch data-access
  generation until the immutable-vs-managed posture is established, because
  guessing risks generated DDL reaching a production table.
- 12 generator agents covering the REST layer, service layer, JPA repositories,
  datasource configuration, Flyway, stored-procedure DAOs, Spring Batch,
  messaging, exception handling, OIDC security, tests and build configuration.
- `springboot-patterns` reference skill with `immutable-schema.md`,
  `stored-procedure-patterns.md` and `validation-checklist.md`.
- `implement`, `validate`, `test` and `explore` skills.

### Design decisions

- **`ddl-auto` is `none` and there is no setting to change it.** This plugin
  targets programmes whose schema is owned externally.
- **Stored procedures are wrapped before repositories are written.** Logic already
  held in a procedure is the business rule; reimplementing it as a derived query
  reimplements logic nobody has fully specified.
- **Parameter directions come from a schema snapshot, never a guess.** An OUT
  parameter registered as IN compiles, runs, and silently returns nothing.
- **Undiscoverable result shapes are recorded, not invented.** A procedure built
  with dynamic SQL cannot be described by the catalogue, so the DAO gets a
  TODO(schema) plus an assertion test rather than a fabricated column list.
- **Structure borrowed from AIDLC-lambda, content not.** AIDLC-lambda stays
  installed and unchanged for Node.js and Lambda applications.
