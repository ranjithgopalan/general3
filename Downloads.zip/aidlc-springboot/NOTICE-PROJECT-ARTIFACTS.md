# Project Artifact Notice

The following files in this directory are project-specific instance artifacts that were
checked in during development. They should NOT be committed to the plugin repository.

**Files to relocate:**
- `domain-pack.json` → move to `workspaces/<your-project>/domain-pack.json`
- `db/epic-5/schema-snapshot.json` → move to `workspaces/<your-project>/schema/schema-snapshot.json`
- `db/epic-5/sp-catalog.json` → move to `workspaces/<your-project>/schema/sp-catalog.json`

These files are left in place temporarily to avoid breaking existing workflows.
Add them to `.gitignore` to prevent future commits:
```
domain-pack.json
db/
```
