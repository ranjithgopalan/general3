---
name: validate
description: Validate generated Java Spring Boot code against layering, transaction, immutable-schema and security rules. Reports severity, file and line, and remediation.
triggers:
  - "validate spring boot"
  - "validate java"
  - "check spring conventions"
  - "springboot validate"
---

# AIDLC-springboot: validate

Checks generated or hand-written Spring Boot code against the rules this plugin
generates to.

## Agent Invocation

Use the Task tool with `subagent_type="router"` and the following prompt:

"""
## User Request
$ARGUMENTS

## Intent: VALIDATE

Report violations with severity, file:line and remediation. Do not modify code.

Read `skills/springboot-patterns/validation-checklist.md` and apply every rule.
Treat these as CRITICAL, because each one can reach production data:

- any `ddl-auto` value other than `none`
- any DDL naming a pre-existing object
- `flyway.clean` enabled in any profile
- a stored-procedure parameter whose registered direction differs from the schema
  snapshot
- a positional result-set read where a named read is required
- a cascade or orphan removal crossing a legacy relationship
- a stack trace, SQL text or schema object name in a response body
- `permitAll` or `authenticated()` where the TDD requires a scope
- a credential, connection string or signing key as a literal

Report HIGH for layering violations: business logic in a controller, a
transaction declared in a controller or DAO, an entity crossing the HTTP
boundary, an HTTP or persistence type in a service signature.
"""

## Output

A compliance report: severity, file:line, the rule violated, and the remediation.
No code changes.
