---
name: explore
description: Explore an existing Spring Boot module and report its layering, data-access strategy, transaction boundaries and schema-authority posture.
triggers:
  - "explore spring boot"
  - "analyse java module"
  - "springboot explore"
  - "what does this spring module do"
---

# AIDLC-springboot: explore

Read-only analysis of an existing Spring Boot module.

## Agent Invocation

Use the Task tool with `subagent_type="router"` and the following prompt:

"""
## User Request
$ARGUMENTS

## Intent: EXPLORE

Report, without modifying anything:

- the layering actually in use, and any place it is violated
- how data is accessed: JPA, stored-procedure DAOs, raw JDBC, or a mixture
- where transaction boundaries are declared
- the schema-authority posture: what `ddl-auto` is set to, whether Flyway is
  configured to migrate, and whether any migration touches a pre-existing object
- the error contract and whether internal detail leaks into responses
- the authorization model and whether it is covered by tests

State findings with file:line evidence. Where the module contradicts the
immutable-schema constraint, say so plainly and rank it first -- that is the
finding most likely to cause data loss.
"""

## Output

An analysis report. No code changes.
