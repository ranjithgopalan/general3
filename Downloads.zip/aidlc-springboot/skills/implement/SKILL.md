---
name: implement
description: "Generate Java Spring Boot code (M3 api-code). Produces controllers, services, security, messaging, batch, S3 document service, report exports, Dockerfile, Jenkinsfile, static openapi.yaml, and build.gradle. Data access (DAOs, datasource config, Flyway) is exclusively owned by M4 (db-integration)."
triggers:
  - "implement spring boot"
  - "generate spring boot"
  - "generate the api"
  - "springboot implement"
  - "implement the service tdd"
---

# AIDLC-springboot: implement

Generates a Spring Boot module from an approved Service-TDD.

**This skill complies with** [`AIDLC-PLUGIN-EXECUTION-CONTRACT.md`](../AIDLC-PLUGIN-EXECUTION-CONTRACT.md)

---

## Phase 0 — Mode Detection

```powershell
# Always read config (never renamed to .bak)
$cfg = Get-Content "aidlc.config.json" -Raw | ConvertFrom-Json
$isLocalMode = [System.Environment]::GetEnvironmentVariable("AIDLC_RUN_ID") -eq "local"

Write-Host "Mode: $(if ($isLocalMode) { 'LOCAL' } else { 'ECS' })"
```

## Phase 1 — Discover Design Prerequisites (M1/lld Service-TDD + domain-pack)

M3 (api-code) requires Service-TDD and domain-pack from the M1 design stage (lld). Discover both from temp directory (local) or API (ECS).

**Local Mode**: Search `%TEMP%\aidlc-ws\{wsId}\lld\` for Service-TDD and `domain-pack.json`  
**ECS Mode**: Query `{central_base_url}/pipeline-runs?workspace_id={wsId}&stage_key=lld`

Gate check: Must find Service-TDD before proceeding. If not found, throw error.

**domain-pack.json discovery (priority order):**
1. `%TEMP%\aidlc-ws\{wsId}\lld\domain-pack.json` — sidecar written by `springboot-tdd-designer`
2. `src/workspaces/<project>/domain-pack.json` — hand-maintained fallback

> ⛔ **HARD STOP — if domain-pack.json is not found at either location:**
>
> "domain-pack.json not found.
> M1 (LLD stage) must complete first so `springboot-tdd-designer` can generate the domain pack.
> Re-run the LLD stage, then re-run M3 (api-code)."
>
> Do NOT ask the user to provide fields inline. Do NOT proceed without the domain pack.
> The domain pack is the authoritative source for service names, stored-procedure families,
> messaging topics, batch jobs, RBAC roles, and hard constraints — none can be safely
> improvised from a prompt. Proceeding without it risks generating incorrect service wiring,
> missing generators (batch/messaging/reports), and a CRITICAL FAIL from `springboot-code-validator`.

When the sidecar (source 1) is found, use it directly — no manual domain pack needed.

---

## Agent Invocation

Use the Task tool with `subagent_type="router"` and the following prompt:

"""
## User Request
$ARGUMENTS

## Intent: IMPLEMENT

Generate a Spring Boot module from the Service-TDD.

1. Read the Service-TDD before anything else. Do not infer requirements from a
   file listing.
2. Establish the schema-authority posture. If the TDD does not state whether the
   target schema may change, ask -- do not assume. On an immutable schema:
     - `ddl-auto` is `none`
     - existing stored procedures are called, never reimplemented
     - Flyway runs baseline/validate only
     - no DDL is emitted against any pre-existing object
3. Require a schema snapshot before generating data access. Procedure signatures
   and column nullability must come from the snapshot, not from a guess.
4. Dispatch in dependency order for **M3 (api-code)**:
   service layer → controllers → exception handling → security (Okta OIDC +
   row-level scope) → messaging (SQS/SNS/SES, only if domain pack has a
   `messaging` block) → Spring Batch jobs (only if domain pack has a `batch`
   block) → S3 document service (only if domain pack has a `documents` block) →
   report exports / Excel / PDF (only if domain pack has a `reports` block) →
   build configuration.

   **Build configuration — generate all three unconditionally (Gradle only — see `build-config-generator`):**
   - `build.gradle` + `settings.gradle` + committed wrapper (`gradlew`, `gradlew.bat`,
     `gradle/wrapper/*`) — include the `org.springdoc.openapi-gradle-plugin` so the
     static spec can be generated via `./gradlew generateOpenApiDocs`.
   - `Dockerfile` — multi-stage build: `gradle:8-jdk21` builder stage runs
     `./gradlew clean build -x test`; runtime stage is `eclipse-temurin:21-jre-alpine`
     and copies the fat jar. EXPOSE the service port declared in `application.yml`.
     ENTRYPOINT `["java", "-jar", "app.jar"]`.
   - `Jenkinsfile` — declarative pipeline with stages: Checkout → `./gradlew build`
     → `docker build` → `docker push` to ECR (using `AWS_ECR_REPO` env var) →
     ECS deploy via `aws ecs update-service --force-new-deployment`.

   **Static OpenAPI spec — generate after controllers are written:**
   Write `src/main/resources/openapi.yaml` by deriving it from the controller
   endpoint signatures and all `@Operation` / `@ApiResponse` annotations. Use
   the service `artifactId` as the API `title`, `1.0.0` as `version`, and every
   controller base path as a `paths` entry. This static file satisfies the
   `api-openapi` artifact declared by uw-cr-mini.yaml and is **required** by
   AIDLC-integrator's api-integrator (Step 5) to build the merged cross-epic
   OpenAPI spec. If it is absent, the integrator's merge produces an empty spec.

   **DO NOT generate in M3** (exclusively owned by M4 — db-integration):
   - Datasource config / `application-datasource.yml`
   - Stored-procedure DAO classes (`*Dao.java` / `*DaoImpl.java`)
   - JPA entities or repositories for the target schema
   - Flyway migration or baseline scripts
   If the Service-TDD references stored procedures or a datasource, note them as
   open items in SUMMARY.md (e.g. `OI-xx: DAO for SP_GetPolicy deferred to M4`)
   — do not generate stubs here. M4 will download the M3 api-source artifact and
   add the data-access layer on top; any DAO stubs committed in M3 will conflict.

   **DO NOT generate any test files** (JUnit, Mockito, MockMvc, Testcontainers,
   @SpringBootTest, @WebMvcTest, @DataJpaTest). Test generation is exclusively
   owned by the api-test stage (M6) via AIDLC-springboot:test — writing tests
   here creates duplicate files and conflicts when M6 runs.

4b. Dispatch for **M4 (db-integration)**:

   This stage generates the data access layer for a legacy SQL Server database
   being modernized to Spring Boot. It NEVER connects to a live database.

   **Step 1 — Locate schema input files**

   Check for schema files in this priority order:

   Priority 1 — DB folder for this epic:
     `plugins/AIDLC-springboot/db/{epic_id}/sp-catalog.json`
     `plugins/AIDLC-springboot/db/{epic_id}/schema-snapshot.json`

   The epic_id comes from `aidlc.config.json` → `workspace_id`, which follows
   the pattern `{workspace}-{epic_id}` (e.g. `test-nk-ev2--epic-5` → epic_id
   is `epic-5`). Look for the db subfolder matching that epic_id.

   Priority 2 — Infer from M3 api-code (fallback when db folder is absent):
     Read `workspaces/{workspace_id}/api-code/SUMMARY.md` open items — M3
     lists every deferred DAO (e.g. `OI-01: DAO for SP_GetPolicy deferred to M4`).
     Read service layer Java files to understand expected method signatures and
     return types. Generate skeleton DAOs with correct structure but mark
     parameter types as `/* TODO: verify SP signature */` and log a warning in
     SUMMARY.md under "Schema Input Missing".

   **NEVER** call `schema-reverse-engineer` or `procedure-introspector` in M4.
   Those agents exist only for live database introspection. In this flow the
   user provides schema files manually from SSMS — those files are the ground
   truth. Do not attempt any live JDBC or ODBC connection at any point.

   **Step 2 — Read sp-catalog.json**

   Format expected:
   ```json
   {
     "database": "CreditRisk",
     "schema": "dbo",
     "procedures": [
       {
         "name": "SP_GetPolicyByNumber",
         "parameters": [
           { "name": "@PolicyNumber", "type": "VARCHAR(20)", "direction": "IN" }
         ],
         "returns": [
           { "column": "PolicyId",    "type": "INT" },
           { "column": "PolicyNumber","type": "VARCHAR(20)" },
           { "column": "Status",      "type": "VARCHAR(10)" }
         ]
       }
     ]
   }
   ```

   If sp-catalog.json is absent and fallback inference is used, generate a
   skeleton sp-catalog.json in the output `db-integration/` folder populated
   from what the api-code reveals, so the user can fill in accurate types.

   **Step 3 — Read schema-snapshot.json (optional)**

   Format expected:
   ```json
   {
     "tables": [
       {
         "name": "PolicyHeader",
         "schema": "dbo",
         "columns": [
           { "name": "PolicyId",     "type": "INT",         "nullable": false, "pk": true },
           { "name": "PolicyNumber", "type": "VARCHAR(20)", "nullable": false }
         ]
       }
     ]
   }
   ```

   If absent, derive row mapper field types from the `returns` array in
   sp-catalog.json. If both are absent, use the DTO classes in M3 api-code
   as the field source.

   **Step 4 — Dispatch generators in order**

   datasource-config-generator → stored-procedure-dao-generator → migration-generator

   datasource-config-generator:
     - Read `database` and `schema` from sp-catalog.json (or domain-pack.json
       `datasource` block if sp-catalog.json has no connection details).
     - Generate `src/main/resources/application-datasource.yml`:
       ```yaml
       spring:
         datasource:
           url: jdbc:sqlserver://${DB_SERVER}:${DB_PORT};databaseName=${DB_NAME};trustServerCertificate=true;encrypt=true
           username: ${DB_LOGIN}
           password: ${DB_PASSWORD}
           driver-class-name: com.microsoft.sqlserver.jdbc.SQLServerDriver
         jpa:
           hibernate:
             ddl-auto: none
       ```
     - All connection values are environment variable placeholders — no
       hardcoded server names or credentials in generated files.

   stored-procedure-dao-generator:
     - For each procedure in sp-catalog.json generate:
       - `dao/{SpName}Dao.java` — interface with one method per SP
       - `dao/impl/{SpName}DaoImpl.java` — CallableStatement implementation
       - `dao/mapper/{SpName}RowMapper.java` — maps result set to return DTO
     - Use `{schema}.{SP_name}` as the fully-qualified call string.
     - OUT parameters must use `registerOutParameter` before `execute()`.
     - If sp-catalog.json was inferred (not provided), mark uncertain parameter
       types with `/* TODO: verify against actual SP signature */`.

   migration-generator:
     - Generate Flyway baseline config in `src/main/resources/db/migration/`:
       `V1__baseline.sql` — contains only `-- Baseline: schema managed externally`
       (no DDL — the schema already exists in the legacy database).
     - Generate `flyway.properties` with `baselineOnMigrate=true`,
       `validateOnMigrate=true`, `outOfOrder=false`.

   **Step 5 — Output structure**

   All M4 output goes to `workspaces/{workspace_id}/db-integration/`:
   ```
   db-integration/
     src/main/java/{base_package}/dao/
       {SpName}Dao.java
       impl/{SpName}DaoImpl.java
       mapper/{SpName}RowMapper.java
     src/main/resources/
       application-datasource.yml
       db/migration/
         V1__baseline.sql
         flyway.properties
     SUMMARY.md
   ```

   This is a drop-in addition to the M3 module — paths mirror the M3 source
   tree so the integrator can merge them without path conflicts.

   **Step 6 — Write SUMMARY.md**

   Write `workspaces/{workspace_id}/db-integration/SUMMARY.md`:
   - Schema source used (db folder / inferred from api-code)
   - List of SPs processed and DAOs generated
   - List of tables used for row mappers
   - Any TODO markers left (uncertain parameter types)
   - Open items for M6 api-test (DAO unit tests needed)

5. Check if `aidlc.config.json` exists in the current working directory. If it does NOT exist, this is a headless ECS server run — log the implementation plan and proceed to generate all files immediately without waiting for confirmation. If it does exist, present the plan and wait for explicit user confirmation before generating.
6. Write generated UI and generated API into separate directories. They must
   build independently.
7. After writing all source files, write a `SUMMARY.md` to the stage output directory
   (e.g. `workspaces/{workspace_id}/api-code/SUMMARY.md`).
   CRITICAL: This file is machine-parsed by subsequent epics (Step 0A of router) to prevent
   duplicate controller/service/SP-family generation. Use this EXACT structured format:

   ```markdown
   ---
   epic: {epic_id}
   workspace: {workspace_id}
   generated_at: {ISO-8601 timestamp}
   ---

   ## Controllers
   | Class | Base Path | Operations |
   |---|---|---|
   | PolicyController | /api/policies | GET list, POST create, PUT update |

   ## Services
   | Class | Key Dependencies | Responsibilities |
   |---|---|---|
   | PolicyService | PolicyDao, QuoteService | Business logic for policy lifecycle |

   ## SP Families
   | Family | Procedures | Owning Service |
   |---|---|---|
   | Policy | SP_GetPolicy, SP_SavePolicy | PolicyDao |

   ## Messaging
   | Type | Name | Direction |
   |---|---|---|
   | SQS Queue | policy-events | Consumer |

   ## Imported from Prior Epics
   | Name | Source Epic | Usage in This Epic |
   |---|---|---|
   | QuoteService | epic-1 | Injected into PolicyService |

   ## Files Generated
   | Layer | Count | Sample |
   |---|---|---|
   | Controllers | 2 | PolicyController.java, QuoteController.java |
   | Services | 3 | PolicyService.java |
   | Build | 3 | build.gradle, Dockerfile, Jenkinsfile |
   | Total | 24 | |

   ## Open Items (M4)
   | ID | Description |
   |---|---|
   | OI-01 | DAO for SP_GetPolicy deferred to M4 |
   ```

   Omit `## Messaging` if the domain pack has no `messaging` block.
   For each M4-deferred concern (DAOs, datasource config, Flyway), add an entry under
   `## Open Items (M4)` so the db-integration run knows what to generate.
"""

## Prerequisites

- An approved Service-TDD
- A schema snapshot for any datasource the module reads
- The schema-authority decision recorded (immutable, or managed by this app)

## Refuses

- Generating DDL against an existing table, view or procedure
- Generating data access without a schema snapshot
- Reimplementing stored-procedure logic while the procedure remains in use
- Connecting to a live database at any point during M4
- Calling `schema-reverse-engineer` during M4 — user provides schema-snapshot.json manually
- Calling `procedure-introspector` during M4 — user provides sp-catalog.json manually

---

## Reporting to the AIDLC Platform (ECS UI tracking)

> **SERVER CLI GUARD:** If `aidlc.config.json` does **not** exist in your current
> working directory, skip this entire ECS section and run only the main workflow
> above. These steps are for the **local Claude Code session only**.

The local session creates the ECS run and monitors progress. All generation
is performed by the ECS server CLI — do **not** generate or copy files locally.

This skill covers two pipeline stages — set `$STAGE` accordingly:

| Launcher invocation | `$STAGE` value | Approver |
|---------------------|---------------|----------|
| M3 — API Code Generation | `api-code` | Developer |
| M4 — DB Integration pass | `db-integration` | Developer |

---

**Step 0 — Read config**
```powershell
# Resolve absolute path at startup so the script works regardless of working directory drift
$cfgPath = (Resolve-Path "aidlc.config.json" -ErrorAction Stop).Path
$cfg     = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
$BASE    = $cfg.central_base_url.TrimEnd('/')
$TOKEN   = [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env)
# Fall back to relay file if env var is not set
if (-not $TOKEN) {
    $relayFile = Join-Path (Split-Path $cfgPath) ".aidlc_token"
    if (Test-Path $relayFile) { $TOKEN = (Get-Content $relayFile -Raw -Encoding UTF8).Trim() }
}
$WS    = $cfg.workspace_id
$HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
$STAGE = "api-code"   # change to "db-integration" for M4

# M4 only — locate db schema input folder for this epic
if ($STAGE -eq "db-integration") {
    # Derive epic_id from workspace_id (e.g. "test-nk-ev2--epic-5" -> "epic-5")
    $epicId   = ($WS -split '--')[-1]
    $dbFolder = Join-Path (Split-Path $cfgPath) "plugins\AIDLC-springboot\db\$epicId"
    $spCatalog      = Join-Path $dbFolder "sp-catalog.json"
    $schemaSnapshot = Join-Path $dbFolder "schema-snapshot.json"

    if (Test-Path $spCatalog) {
        Write-Host "  DB schema source : $dbFolder"
        Write-Host "  sp-catalog.json  : FOUND"
        Write-Host "  schema-snapshot  : $(if (Test-Path $schemaSnapshot) { 'FOUND' } else { 'not provided — will infer from api-code' })"
    } else {
        Write-Host "  ⚠ No db folder found at: $dbFolder"
        Write-Host "    Falling back to inferring schema from M3 api-code SUMMARY.md"
        Write-Host "    To provide schema: create plugins\AIDLC-springboot\db\$epicId\sp-catalog.json"
    }
}
```

**Step 1 — Smart run management: cancel queued / attach running / create fresh**
```powershell
# Check for an existing active run for this stage
$existing = $null
try {
    $existing = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS&stage_key=$STAGE" -Headers $HDR).items |
        Where-Object { $_.state -in @("queued", "running") } |
        Sort-Object queued_at -Descending |
        Select-Object -First 1
} catch {}

if ($existing -and $existing.state -eq "queued") {
    # Queued but not started — cancel immediately and restart fresh
    Invoke-RestMethod "$BASE/pipeline-runs/$($existing.run_id)/cancel" -Headers $HDR -Method Post | Out-Null
    Write-Host "Cancelled queued run $($existing.run_id) — creating fresh run."
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true; force=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
} elseif ($existing -and $existing.state -eq "running") {
    # Already being processed by the worker — attach and monitor, do NOT cancel
    $RUN_ID = $existing.run_id
    Write-Host "Run already in progress: $RUN_ID — attaching to monitor."
} else {
    # No active run — create a fresh one
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true; force=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
}
```

**Step 2 — Monitor and display elapsed time**
```powershell
do {
    Start-Sleep -Seconds 15
    # API wraps response in a "run" envelope — unwrap before accessing fields
    $run     = (Invoke-RestMethod "$BASE/pipeline-runs/$RUN_ID" -Headers $HDR).run
    $elapsed = if ($run.started_at) {
        $s = [datetime]::Parse($run.started_at)
        $e = if ($run.finished_at) { [datetime]::Parse($run.finished_at) } else { Get-Date }
        "$([int]($e - $s).TotalSeconds)s"
    } else { "queued" }
    $files = if ($run.files_written) { $run.files_written.Count } else { 0 }
    Write-Host "  [$elapsed]  state=$($run.state)  files=$files"
} while ($run.state -notin @("waiting_for_approval","completed","failed","cancelled"))
```

**Step 3 — Final timing summary**
```powershell
$fmt = { param($t) if ($t) { [datetime]::Parse($t).ToLocalTime().ToString("HH:mm:ss") } else { "—" } }
$sec = if ($run.started_at -and $run.finished_at) {
    [int]([datetime]::Parse($run.finished_at) - [datetime]::Parse($run.started_at)).TotalSeconds
} else { 0 }
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
Write-Host "  Run     : $RUN_ID"
Write-Host "  Stage   : $STAGE"
Write-Host "  State   : $($run.state)"
Write-Host "  Queued  : $(& $fmt $run.queued_at)"
Write-Host "  Started : $(& $fmt $run.started_at)"
Write-Host "  Finished: $(& $fmt $run.finished_at)"
Write-Host "  Elapsed : ${sec}s"
Write-Host "  Files   : $($run.files_written.Count) written"
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
```

**Step 4 — Generation Summary**
```powershell
$files  = $run.files_written
$isM4   = ($STAGE -eq "db-integration")

if (-not $isM4) {
    # M3 api-code summary
    $groups = [ordered]@{
        "Controllers"        = @($files | Where-Object { $_ -like "*/controller/*" })
        "Services"           = @($files | Where-Object { $_ -like "*/service/*" })
        "Domain / Entities"  = @($files | Where-Object { $_ -like "*/domain/*" })
        "DTOs"               = @($files | Where-Object { $_ -like "*/dto/*" })
        "Exception Handling" = @($files | Where-Object { $_ -like "*/exception/*" })
        "Messaging / Events" = @($files | Where-Object { $_ -like "*/messaging/*" -or $_ -like "*/event/*" })
        "Batch"              = @($files | Where-Object { $_ -like "*/batch/*" })
        "S3 / Integration"   = @($files | Where-Object { $_ -like "*/integration/*" -or $_ -like "*/s3/*" -or $_ -like "*/document/*" })
        "Report Exports"     = @($files | Where-Object { $_ -like "*/report/*" -or $_ -like "*/export/*" })
        "Config / Security"  = @($files | Where-Object { $_ -like "*/config/*" -or $_ -like "*/security/*" })
        "Build"              = @($files | Where-Object { $_ -match "pom\.xml|Dockerfile|Jenkinsfile" })
        "OpenAPI Spec"       = @($files | Where-Object { $_ -like "*/openapi.yaml" -or $_ -like "*/openapi.json" })
        "Tests"              = @($files | Where-Object { $_ -like "*/test/*" })
        "Build / Resources"  = @($files | Where-Object { $_ -like "*/resources/*" })
    }
    Write-Host ""
    Write-Host "┌──────────────────────────────────────────────────────────────────┐"
    Write-Host "│              GENERATION SUMMARY — api-code (M3)                  │"
    Write-Host "├──────────────────────────────┬─────────┬────────────────────────┤"
    Write-Host "│ Category                     │  Count  │ Sample files           │"
    Write-Host "├──────────────────────────────┼─────────┼────────────────────────┤"
    foreach ($key in $groups.Keys) {
        $items = $groups[$key]
        if ($items.Count -gt 0) {
            $sample = ($items | ForEach-Object { [System.IO.Path]::GetFileName($_) } | Select-Object -First 2) -join ", "
            if ($sample.Length -gt 24) { $sample = $sample.Substring(0,21) + "..." }
            Write-Host ("│ {0,-28} │ {1,7} │ {2,-22} │" -f $key, $items.Count, $sample)
        }
    }
    Write-Host "├──────────────────────────────┼─────────┼────────────────────────┤"
    Write-Host ("│ {0,-28} │ {1,7} │ {2,-22} │" -f "TOTAL", $files.Count, "")
    Write-Host "└──────────────────────────────┴─────────┴────────────────────────┘"

    # Warn if Dockerfile, Jenkinsfile, or openapi.yaml are absent
    $missingBuild = @()
    if (-not ($files | Where-Object { $_ -match "Dockerfile" }))    { $missingBuild += "Dockerfile" }
    if (-not ($files | Where-Object { $_ -match "Jenkinsfile" }))   { $missingBuild += "Jenkinsfile" }
    if (-not ($files | Where-Object { $_ -like "*/openapi.yaml" })) { $missingBuild += "openapi.yaml" }
    if ($missingBuild) {
        Write-Host ""
        Write-Host "  ⚠ Missing required build artifacts: $($missingBuild -join ', ')"
        Write-Host "    These are needed by AIDLC-integrator. Re-run M3 to regenerate."
    }
    $wsPath = Join-Path (Split-Path $cfgPath) "workspaces\$WS\api-code"

} else {
    # M4 db-integration summary
    $groups = [ordered]@{
        "DAO Interfaces"     = @($files | Where-Object { $_ -like "*/dao/*Dao.java" -and $_ -notlike "*/impl/*" })
        "DAO Implementations"= @($files | Where-Object { $_ -like "*/dao/impl/*" })
        "Row Mappers"        = @($files | Where-Object { $_ -like "*/dao/mapper/*" -or $_ -like "*/mapper/*" })
        "Datasource Config"  = @($files | Where-Object { $_ -like "*datasource*" -or $_ -like "*application-datasource*" })
        "Flyway / Migration" = @($files | Where-Object { $_ -like "*/migration/*" -or $_ -like "*flyway*" })
        "Summary"            = @($files | Where-Object { $_ -like "*.md" })
    }
    Write-Host ""
    Write-Host "┌──────────────────────────────────────────────────────────────────┐"
    Write-Host "│           GENERATION SUMMARY — db-integration (M4)               │"
    Write-Host "├──────────────────────────────┬─────────┬────────────────────────┤"
    Write-Host "│ Category                     │  Count  │ Sample files           │"
    Write-Host "├──────────────────────────────┼─────────┼────────────────────────┤"
    foreach ($key in $groups.Keys) {
        $items = $groups[$key]
        if ($items.Count -gt 0) {
            $sample = ($items | ForEach-Object { [System.IO.Path]::GetFileName($_) } | Select-Object -First 2) -join ", "
            if ($sample.Length -gt 24) { $sample = $sample.Substring(0,21) + "..." }
            Write-Host ("│ {0,-28} │ {1,7} │ {2,-22} │" -f $key, $items.Count, $sample)
        }
    }
    Write-Host "├──────────────────────────────┼─────────┼────────────────────────┤"
    Write-Host ("│ {0,-28} │ {1,7} │ {2,-22} │" -f "TOTAL", $files.Count, "")
    Write-Host "└──────────────────────────────┴─────────┴────────────────────────┘"

    # Warn if key M4 artifacts are absent
    $missingM4 = @()
    if (-not ($files | Where-Object { $_ -like "*Dao.java" }))              { $missingM4 += "DAO classes" }
    if (-not ($files | Where-Object { $_ -like "*datasource*" }))           { $missingM4 += "application-datasource.yml" }
    if (-not ($files | Where-Object { $_ -like "*/migration/*" }))          { $missingM4 += "Flyway baseline" }
    if ($missingM4) {
        Write-Host ""
        Write-Host "  ⚠ Missing required M4 artifacts: $($missingM4 -join ', ')"
        Write-Host "    Check db-integration/SUMMARY.md for details. Re-run M4 to regenerate."
    }
    $wsPath = Join-Path (Split-Path $cfgPath) "workspaces\$WS\db-integration"
}

Write-Host ""
Write-Host "  Output path : $wsPath"
```

**Step 5 — Review in ECS UI**
```
https://poc-ecs-build-ui.npsdlchgapp.us-east-1.aws.aig.net/aidlc-platform-management/pipeline
```

Approval persona: **Developer**