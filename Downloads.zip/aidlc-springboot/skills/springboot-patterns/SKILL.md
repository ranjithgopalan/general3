---
name: springboot-patterns
description: Spring Boot layering, transaction, data-access and error-handling patterns for modernization targets whose relational schema is immutable
---

# Spring Boot Patterns

Reference material for the AIDLC-springboot agents. Load the specific file you
need rather than reading everything.

| File | Covers |
|------|--------|
| `immutable-schema.md` | The rules that apply when the target schema must not change |
| `stored-procedure-patterns.md` | CallableStatement, parameter directions, row mapping |
| `validation-checklist.md` | What must hold before generated output is returned |
| `aws-integration.md` | SQS / SNS / SES / S3 / Secrets Manager / EventBridge usage |
| `domain-pack-contract.md` | Which `domain-pack.json` keys each agent reads — application specifics are configuration |

## Layering

```
Controller   HTTP mapping, validation, DTO translation.        No business rule.
   |
Service      Business rules, transaction boundary, exception   No HTTP type.
   |         translation.
   |
DAO / Repo   Data access only.                                 No transaction.
   |
Database     Owned externally on an immutable-schema programme.
```

Each layer speaks only to the one below it, and passes only its own types. A DTO
does not reach the DAO; an entity does not reach the controller.

## Transactions

One boundary per business operation, declared in the service layer. Read paths
are `@Transactional(readOnly = true)`. A transaction declared in a controller
holds a connection for the duration of serialization; one declared in a DAO
cannot span the two calls a business operation needs.

## Dependency injection

Constructor injection only, fields `final`. Field injection hides a dependency
from the constructor, which makes the class untestable without a container and
makes a circular dependency invisible until startup.

## Error handling

Translate at each boundary. A data-access exception becomes a domain exception in
the service; a domain exception becomes a status and a problem detail in the
controller advice. Never let a framework exception reach a client, and never put
SQL text or schema object names in a response.
