# Domain-Pack Contract — what each AIDLC-springboot agent reads

The plugin is application-neutral. Every application-specific fact lives in
`src/workspaces/<project>/domain-pack.json`. Agents read the keys below and **stop and ask**
when a required key is missing — they never invent names, schedules or tables.
To modernise a different application, write a new domain pack; do not edit agents.

| Key | Required by | Meaning |
|---|---|---|
| `project.id`, `project.config_prefix` | all | Property/env prefix and artefact naming |

| `hard_constraints[]` | all | Free-text constraints; validator maps each to a check |
| `target_architecture.bands.band_3.services[]` | rest-service, service-layer, validator | Service ids, names, what each owns, SP families it calls |
| `target_architecture.bands.band_4.constraint` | repository, stored-procedure-dao, migration | JPA / DDL / Flyway posture |
| `database.datasource_name`, `database.kb_api` | datasource-config, stored-procedure-dao | Datasource id and KB endpoint for snapshots |
| `database.stored_procedures.families` | stored-procedure-dao, validator | Family → member SPs; family = one DAO with a variant (e.g. business unit) parameter |
| `database.jpa_lookup_tables[]` (optional) | repository | Only tables that may get read-only JPA entities |
| `rbac.roles[]`, `rbac.okta_groups_to_roles`, `rbac.identity_provider` | security-config, rest-service | Roles, group mapping, issuer |
| `rbac.data_scope` | security-config, stored-procedure-dao, report-export | Row-level scope dimensions and their source tables |
| `rbac.audit` | security-config, service-layer | Audit targets written by services |
| `messaging.topics[]`, `messaging.queues[]`, `messaging.email.*` | messaging, validator | Publishers, listeners, SES templates and recipient sources |
| `batch.jobs[]` | spring-batch, validator | Job name, schedule, reader, steps, writer, replaces |
| `documents.*` | document-storage, spring-batch (inbound feeds), validator | Buckets, upload types, TTL, retention |
| `reports.*` | report-export, validator | Engines, output bucket, shared filters, catalogue source |
| `ui.modules[]`, `ui.modernisation_rules[]` | (AIDLC-axis) | UI modules and rules — listed here for cross-plugin consistency |
| `source_application.legacy_integrations` | all (mapping reports) | Legacy mechanism → replacement, used to produce "what replaced what" reports |

Minimal pack for a new programme: `project`, `hard_constraints`, `target_architecture`,
`database`, `rbac`. Add `messaging`, `batch`, `documents`, `reports` when those bands exist.

## Instruction overrides (how a developer tunes an agent for one application)

```
src/workspaces/<project>/agent-config/<stage-key>.md        injected into that stage's prompt by the platform
src/workspaces/<project>/agent-config/agents/<agent>.md     read by that sub-agent before generating
```
Precedence: run request > stage override > agent override > domain pack > plugin defaults.
See `fe_core/pipeline/project_config.py`. Selecting a target stack (Angular+Axis / Spring Boot / DB) is
`target_architecture.stack` in the domain pack plus the project's `TargetFramework` (`fe_core/projects/stacks.py`),
which decides which plugins the pipeline needs.
