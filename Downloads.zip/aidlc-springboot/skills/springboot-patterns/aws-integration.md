# AWS Integration Patterns (Spring Cloud AWS 3.x)

Reference for `messaging-generator`, `spring-batch-generator`, `document-storage-generator`,
`report-export-generator`, `datasource-config-generator` and `security-config-generator`.
Application-specific names (topics, buckets, jobs, secrets paths) always come from the
domain pack; this file only fixes *how* each AWS service is used.

## Dependencies (BOM-managed, Groovy DSL)

```groovy
// Spring Cloud AWS 3.x starters — versions managed by the Spring Cloud AWS BOM
implementation 'io.awspring.cloud:spring-cloud-aws-starter-sqs'
implementation 'io.awspring.cloud:spring-cloud-aws-starter-sns'
implementation 'io.awspring.cloud:spring-cloud-aws-starter-ses'
implementation 'io.awspring.cloud:spring-cloud-aws-starter-s3'
implementation 'io.awspring.cloud:spring-cloud-aws-starter-secrets-manager'
implementation 'io.awspring.cloud:spring-cloud-aws-starter-parameter-store'
```

Testcontainers `LocalStackContainer` for SQS/SNS/S3/SES in integration tests.

## Configuration sources

| Concern | Source | Placeholder style |
|---|---|---|
| Credentials, connection strings, signing material | Secrets Manager `/<env>/<datasource>/…` | `${DB_URL}` via `spring.config.import=aws-secretsmanager:` |
| Topic/queue ARNs, bucket names, issuer URI, schedules, TTLs | Parameter Store `/<env>/<app.id>/…` | `${<PREFIX>_TOPIC_X}` via `aws-parameterstore:` |
| Region | env `AWS_REGION` | `spring.cloud.aws.region.static` |

Never a literal in Java or YAML. `config_prefix` in the domain pack (`project.config_prefix`)
is the property/env prefix generated code uses (e.g. `uwcr.messaging.topics.bl-submitted`).

## SQS / SNS / SES
See `messaging-generator.md`: SNS publish with `eventType` + tenant/business-unit attributes;
`@SqsListener` with `ON_SUCCESS` ack, dedup outside the immutable DB, redrive to DLQ (`maxReceiveCount` 5),
DLQ-depth alarm; SES `NotificationService` with Thymeleaf templates, recipients from lookup DAOs.

## S3
See `document-storage-generator.md`: presigned PUT/GET, SSE-KMS, block public access, versioning,
lifecycle from `documents.retention_days`; key `<type>/<ownerRef>/<uuid>-<file>`; S3 event → SQS for
inbound feed buckets.

## EventBridge Scheduler
One rule per `batch.jobs[].schedule`; target = ECS RunTask (batch task definition) or the
service's `/internal/batch/{job}` endpoint secured for the scheduler's IAM role via API GW IAM auth.
Cron expressions live in Parameter Store.

## Observability
Micrometer → CloudWatch (`spring-cloud-aws-starter-metrics` optional); batch counts, DLQ depth,
export durations as metrics; structured JSON logs with correlation ID; no PII or object keys in logs.

## IAM (least privilege, per service task role)
Publisher: `sns:Publish` on its topics only. Consumer: `sqs:ReceiveMessage/DeleteMessage/ChangeMessageVisibility`
on its queues. Documents: `s3:GetObject/PutObject` on its bucket prefixes + `kms:Decrypt/GenerateDataKey`.
Config: `secretsmanager:GetSecretValue`, `ssm:GetParametersByPath` on its paths only.
