# Validation Checklist

Run before returning generated output. CRITICAL items can reach production data,
so they block; HIGH items are design defects that will be expensive later.

## CRITICAL

- [ ] `ddl-auto` is `none` in every profile
- [ ] No DDL names a pre-existing table, view or procedure
- [ ] `flyway.clean` is disabled in every profile
- [ ] `flyway.out-of-order` is false
- [ ] Every additive migration carries a recorded DBA approval reference
- [ ] Every stored-procedure parameter direction matches the schema snapshot
- [ ] Every result-set column is read by name, not by position
- [ ] Nullable columns are read through `wasNull()` and keep null distinct from zero
- [ ] No cascade or orphan removal crosses a legacy relationship
- [ ] No stack trace, SQL text or schema object name appears in a response body
- [ ] No credential, connection string or signing key appears as a literal
- [ ] Authorization denies by default; no `permitAll` where a scope is required

## HIGH

- [ ] Controllers contain no business logic, data access or transactions
- [ ] No entity crosses the HTTP boundary
- [ ] Exactly one transaction boundary per business operation, in the service layer
- [ ] Read paths are marked `readOnly = true`
- [ ] No HTTP or persistence type appears in a service signature
- [ ] Data-access exceptions are translated with the cause retained
- [ ] Constructor injection only; no field injection
- [ ] `open-in-view` is disabled

## COVERAGE (against the domain pack — each miss is HIGH)

- [ ] Every service in `target_architecture.bands.band_3.services[]` exists
- [ ] Every SP family in `database.stored_procedures.families` has a DAO with a variant parameter
- [ ] JPA entities exist only for `database.jpa_lookup_tables`
- [ ] Every topic / queue / email template in `messaging` has generated code
- [ ] Every job in `batch.jobs[]` exists with steps in order and a schedule; batch repo on a separate datasource
- [ ] `documents` → `DocumentService`; `reports` → `ReportCatalog`
- [ ] Roles used in security config ⊆ `rbac.roles[]`; `ScopeContext` used by scoped DAOs

## MEDIUM

- [ ] Every operation carries OpenAPI annotations
- [ ] Every response carries a correlation ID
- [ ] Batch steps are restartable and their counts balance
- [ ] Message consumers deduplicate on a durable key
- [ ] Retries are bounded with backoff, then dead-lettered
- [ ] Dependency and plugin versions are pinned
- [ ] Coverage and dependency gates fail the build rather than warn
- [ ] The container image is non-root and holds no secret

## SONAR CODE QUALITY (every generated or hand-edited Java class — report as HIGH)

- [ ] **Cognitive complexity ≤ 15 per method/constructor.** Nested `if`/`for`/`try` blocks
      and chained boolean operators (`&&`/`||`) each add up fast. Fix by: extracting guard
      clauses (early `return`/`throw` instead of nesting), moving inner loops or branches
      into a named private helper method, and consolidating a condition that is repeated
      across branches into one helper.
- [ ] **≤ 7 parameters per method/constructor.** A signature that needs an 8th parameter
      should instead take a request/response `record` (or a small parameter object) that
      groups the related values — this also gives the parameter set a name and a single
      place to add validation.
- [ ] **No empty `catch` block** — every caught exception is logged (with the original
      exception as cause) or rethrown wrapped in a domain exception; never swallowed silently.
- [ ] **No unused imports.**
- [ ] **No magic numbers in business logic** — extract to a named `private static final`
      constant so the value's meaning is visible at the declaration site.
- [ ] **Test coverage > 65% for the module, 80%+ for newly generated service/DAO logic** —
      measured by the module's configured coverage tool (JaCoCo if present in `build.gradle`);
      if none is configured, flag missing coverage tooling as a finding rather than skipping
      the check.

How to check without a SonarQube scanner available: if the module's `build.gradle` configures
the `pmd` or `jacoco` Gradle plugins, run them (e.g. `./gradlew pmdMain`, `./gradlew jacocoTestReport`)
and treat its output as authoritative.
If none is configured, estimate manually: count `if`/`else if`/`for`/`while`/`catch`/`&&`/`||`
occurrences per method body via Grep to flag candidates over the complexity budget, and count
comma-separated parameters per method signature.

## Reporting

For each violation give severity, `file:line`, the rule, and the remediation.
Where output contradicts the immutable-schema constraint, rank it first regardless
of count: it is the finding most likely to cause data loss.
