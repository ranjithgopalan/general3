# Immutable Schema Rules

These apply when the target relational schema already exists and the programme has
committed to leaving it unchanged. On such a programme the schema is the
specification and the code conforms to it, which inverts most Spring Boot defaults.

## The five rules

1. **`ddl-auto` is `none`, in every profile.** No exceptions, no per-environment
   override. `update` will quietly alter a production table the first time an
   entity drifts from it.
2. **No DDL against a pre-existing object.** Not `ALTER`, not `DROP`, not
   `TRUNCATE`, and not an annotation whose side effect is DDL.
3. **Existing logic is called, not reimplemented.** A stored procedure that
   encodes a business rule is the rule. Reimplementing it as a derived query
   reimplements logic nobody has fully specified, and divergence shows up as
   wrong money.
4. **Flyway baselines and validates.** It manages only new objects the programme
   owns. `clean` is disabled everywhere.
5. **Entities are mappings, not designs.** Explicit table and column names,
   nullability from the schema snapshot, `@Immutable` where the programme never
   writes, and no cascade across a legacy relationship.

## Reconciling "use JPA and Flyway" with "do not change the schema"

Programmes routinely ask for both. They are compatible in exactly one
configuration:

| Requested | Safe form |
|-----------|-----------|
| JPA entities | Read-only mappings over existing tables; `ddl-auto=none` |
| Hibernate manages the schema | Schema owned outside the application |
| Flyway migrations | `baseline` + `validate`; additive only, DBA-approved |
| Derived query methods | Stored-procedure DAOs for logic that already exists |
| ORM relationship mapping | Explicit result-set row mappers |
| New tables | Additive migration with recorded approval |

If asked for something outside the right-hand column, say so rather than
generating it. A silent `ALTER` is the one failure mode that cannot be walked
back.

## What to do when the posture is unstated

Ask. Do not default to either answer. Defaulting to "immutable" produces code that
cannot evolve a schema the programme actually owns; defaulting to "managed"
produces DDL against a production table.
