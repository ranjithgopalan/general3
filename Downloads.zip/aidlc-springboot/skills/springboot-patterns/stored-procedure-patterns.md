# Stored Procedure Patterns

## Parameter directions are load-bearing

An `OUT` parameter registered as `IN` produces code that compiles, runs, and
silently returns nothing. There is no exception and no log line. Take every
direction from the schema snapshot.

| Snapshot direction | Registration |
|--------------------|--------------|
| `in` | `cs.setXxx(ordinal, value)` |
| `out` | `cs.registerOutParameter(ordinal, Types.XXX)` |
| `inout` | both, in that order |
| `return` | `registerOutParameter` at ordinal 1, with the call in `{? = call ...}` form |

## Row mapping is explicit and by name

```java
final class ExposureLineRowMapper implements RowMapper<ExposureLine> {
    @Override
    public ExposureLine mapRow(ResultSet rs, int rowNum) throws SQLException {
        BigDecimal limit = rs.getBigDecimal("CreditLimit");
        return new ExposureLine(
            rs.getLong("FacilityId"),
            rs.getString("FacilityType"),
            rs.wasNull() ? null : limit,     // null means unlimited, not zero
            rs.getBigDecimal("Utilised")
        );
    }
}
```

Positional reads break the first time somebody adds a column to the procedure's
`SELECT`, and that change will not be visible in this repository.

## Null is not zero

On a credit system a null limit frequently means "unlimited" while zero means "no
facility". Collapsing them is a financial defect. Read nullable columns through
`wasNull()` and carry the null through the domain type.

## Undiscoverable result shapes

A procedure that builds its result with dynamic SQL cannot be described by the
catalogue. When the snapshot reports the shape as undiscoverable:

- generate the DAO with a `TODO(schema)` naming the procedure and the reason
- generate an integration test asserting the actual column set against a restored
  copy, so the shape is pinned by a test rather than a guess
- state the gap in the summary

Never invent a column list.

## Multiple result sets

Iterate with `getMoreResults()` and map each into its own type. Reading only the
first is a data-loss bug, and a test written from the same assumption will not
catch it.

## Transactions

A DAO never opens a transaction. It participates in one the service layer owns.
