---
name: context-budget
description: Selective reading strategy to prevent context overflow in large SDLC artifacts — defines per-call line limits, TOC-first reading, Grep-before-Read, and priority ordering for all AIDLC agents.
license: Proprietary
metadata:
  author: AIDLC Platform Team
  version: "0.1.0"
  organization: AIG
  plugin: AIDLC-springboot
tools: Read, Glob, Grep
---

# context-budget — selective reading strategy

Large SDLC workspaces accumulate Feature-TDDs, Service-TDDs, FSDs, schema
snapshots, and source trees that together far exceed a single context window.
Every AIDLC agent MUST apply the strategy defined here to stay within budget
without silently dropping required inputs.

---

## Hard limits

| Constraint | Value |
|---|---|
| Maximum lines per `Read` call | **400** |
| TOC scan limit (first Read of any large document) | **150 lines** |
| Token warning threshold | **500 lines** — apply windowed reading above this |

---

## Strategy 1 — TOC-first

Always read the **first 150 lines** of any large document before reading specific
sections. The opening lines of a well-formed SDLC document contain a table of
contents, section anchors, or a high-level summary. Use that to decide which
sections you actually need, then read only those sections.

```
Read(file_path, limit=150)          # find the TOC / headings
Read(file_path, offset=N, limit=400) # read the relevant section
```

Never read a large file from the beginning to the end in a single call.

---

## Strategy 2 — Grep-before-Read

Use `Grep` to locate specific sections by heading or keyword **before** using
`Read` with an offset. This avoids loading irrelevant content.

```
Grep(pattern="## Controller Specification", path=tdd_file)
# returns the line number → then Read(offset=line-1, limit=400)
```

Pattern examples:
- Section headings: `## API Endpoints`, `## Stored Procedures`, `## Batch Jobs`
- Class names: `CustomerService`, `PolicyController`
- Annotations: `@RestController`, `@Transactional`
- Schema objects: `tbl_policy`, `usp_get_policy`

---

## Strategy 3 — Windowed reading for large documents

If a document is estimated to be over 500 lines (or you cannot see an end
sentinel after a 150-line TOC scan), apply windowed reading:

1. Read window 1: `offset=0, limit=400`
2. Extract what you need from window 1; note the last offset.
3. Read window 2: `offset=400, limit=400`
4. Repeat until you have all required sections or reach the end of the document.

Never load entire Feature-TDD, Service-TDD, Master TDD, or FSD files in a
single `Read` call when they exceed 300 lines.

---

## Strategy 4 — Source tree scanning

For source trees, always scan with `Glob` + targeted `Grep` before reading
individual files. Never attempt to read entire directories recursively.

```
Glob("src/main/java/**/*.java")          # find candidate files
Grep("class CustomerController", ...)   # confirm the right file
Read(matched_file, limit=400)            # read only the confirmed file
```

---

## Context budget priority order

When context is tight, load artifacts in this order and drop lower-priority
items first:

| Priority | Category |
|---|---|
| 1 (highest) | System instructions and skill rules |
| 2 | Tool schemas needed for the current phase |
| 3 | Required inputs (Service-TDD, domain-pack, schema-snapshot) |
| 4 | Reference material (pattern guides, immutable-schema rules) |
| 5 (lowest) | Examples and supplementary documentation |

---

## Rules summary

- **400-line cap per Read call** — no exceptions, including stub files.
- **TOC-first** — read the first 150 lines of any large document before
  deciding what to load next.
- **Grep-before-Read** — locate section offsets with Grep; do not scan manually.
- **500-line warning** — documents above this threshold require windowed reading.
- **Never load entire Feature-TDD, Service-TDD, Master TDD, or FSD** in one
  Read call when they exceed 300 lines.
- **Glob + Grep before Read** for source trees — never read entire directories
  recursively.
- **Priority order** — drop examples and reference material before required
  inputs when context is tight.
