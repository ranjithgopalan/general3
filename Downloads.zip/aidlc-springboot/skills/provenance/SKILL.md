---
name: provenance
description: Standard provenance metadata block for all AIDLC-generated artifacts — defines the _provenance key for JSON outputs and the YAML frontmatter block for Markdown outputs, plus the artifact-ID naming convention and authorship rules.
license: Proprietary
metadata:
  author: AIDLC Platform Team
  version: "0.1.0"
  organization: AIG
  plugin: AIDLC-springboot
tools: Read, Write, Edit
---

# provenance — standard artifact provenance block

Every artifact produced by an AIDLC agent MUST carry a provenance block that
records who generated it, from what inputs, and with which plugin version. This
skill defines the canonical formats and the rules governing them.

---

## JSON artifact format

Add a `_provenance` key at the **top level** of every generated JSON file:

```json
"_provenance": {
  "generated_by": "<agent-name>",
  "model": "<claude-model-id>",
  "timestamp": "<ISO8601>",
  "plugin_version": "<plugin-version>",
  "source_artifact_ids": ["<FSD-id>", "<TDD-id>"],
  "artifact_id": "<plugin>-<feature>-<type>-<version>"
}
```

Example:

```json
{
  "_provenance": {
    "generated_by": "AIDLC-springboot:rest-service-generator",
    "model": "claude-sonnet-4-6",
    "timestamp": "2026-10-01T09:00:00Z",
    "plugin_version": "0.1.0",
    "source_artifact_ids": [
      "inputs/FSD-customer-portal.md",
      "lld/service-tdd-customer-portal.md"
    ],
    "artifact_id": "aidlc-springboot-customer-portal-controller-v1"
  },
  ...
}
```

---

## Markdown artifact format

Add a YAML frontmatter block at the **top** of every generated Markdown file:

```yaml
---
generated_by: <agent-name>
model: <claude-model-id>
timestamp: <ISO8601>
plugin_version: <plugin-version>
source_artifact_ids: [<FSD-id>, <TDD-id>]
artifact_id: <plugin>-<feature>-<type>-v1
---
```

Example:

```yaml
---
generated_by: AIDLC-design:springboot-tdd-designer
model: claude-sonnet-4-6
timestamp: 2026-10-01T09:00:00Z
plugin_version: 0.1.0
source_artifact_ids: [inputs/FSD-customer-portal.md]
artifact_id: aidlc-design-customer-portal-service-tdd-v1
---
```

---

## Artifact ID naming convention

```
{plugin-id}-{feature-slug}-{artifact-type}-v{major}
```

| Segment | Rule |
|---|---|
| `plugin-id` | Kebab-case plugin identifier, e.g. `aidlc-springboot`, `aidlc-design`, `aidlc-axis` |
| `feature-slug` | Kebab-case feature or epic name, e.g. `customer-portal`, `batch-feed-import` |
| `artifact-type` | One of: `controller`, `service`, `dao`, `entity`, `service-tdd`, `feature-tdd`, `ui-tdd`, `migration`, `domain-pack`, `report`, `openapi` |
| `v{major}` | Integer version starting at `v1`; increment only on breaking schema changes |

Examples:
- `aidlc-springboot-customer-service-controller-v1`
- `aidlc-design-batch-feed-import-service-tdd-v1`
- `aidlc-axis-policy-renewal-feature-tdd-v2`

---

## Rules

1. **Every agent MUST write a provenance block** to its primary output before handing
   off to the next pipeline stage. A generated file without a provenance block is
   incomplete.

2. **`source_artifact_ids` must list the actual input file paths or document IDs**
   that drove the output — not a generic description. Use the path relative to the
   workspace root (e.g. `inputs/FSD-customer-portal.md`) or the stable artifact ID
   of the upstream artifact.

3. **Never omit `artifact_id`.** Downstream agents and the integration validator
   use it to track lineage and detect stale re-generations.

4. **`timestamp` must be ISO 8601 UTC** (e.g. `2026-10-01T09:00:00Z`). Use the
   actual generation time, not a placeholder.

5. **`plugin_version`** is the version string from the plugin's `plugin.json`
   (or `package.json`). Read it at generation time — do not hardcode.

6. **Do not modify a provenance block** once another agent has consumed the
   artifact. Instead, increment the `v{major}` suffix and write a new artifact.
