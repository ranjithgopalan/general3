﻿---
name: generate
description: Generate Feature-TDD, UI-TDD, or Service-TDD design documents from requirements. Use when creating design specifications from Feature Specification Documents.
---

# Generate Design Documents Skill (M1 - lld)

Generates Feature-TDD, UI-TDD, or Service-TDD design documents from requirements.

**This skill complies with** [`AIDLC-PLUGIN-EXECUTION-CONTRACT.md`](../AIDLC-PLUGIN-EXECUTION-CONTRACT.md)

## Unified Execution Model (M1 is first stage — no prerequisites)

- **Config**: Always read `aidlc.config.json` directly (never renamed to `.bak`)
- **Mode Detection**: Check `$env:AIDLC_RUN_ID` to determine local vs ECS execution
- **Prerequisites**: M1 is the first stage — requires FSD (Feature Specification Document) from user/input
- **Output**: ALWAYS write to temp directory: `%TEMP%\aidlc-ws\{wsId}\lld\` (never to project root)

## When to Use

Use this skill when:
- Creating Feature-TDD (architecture combining UI + Services)
- Creating UI-TDD (component specifications for axis-tools)
- Creating Service-TDD (Lambda specifications for nodejs-pair-programmer)
- Converting Feature Specification Documents to technical designs

## Usage

[Extended thinking: This skill generates design documents - Feature-TDD, UI-TDD, or Service-TDD. It enriches the request with context, verifies critical patterns (protocol specification, async operations >16s, Lambda config 1024MB/30s), and routes to the appropriate designer agent.]

---

## Phase 0 — Mode Detection

```powershell
if (-not (Test-Path "aidlc.config.json")) {
    # Not in launcher mode — user is running skill directly
    $isLocalMode = $false
    $workspaceId = $null
} else {
    $cfg = Get-Content "aidlc.config.json" -Raw | ConvertFrom-Json
    $workspaceId = $cfg.workspace_id
    $isLocalMode = [System.Environment]::GetEnvironmentVariable("AIDLC_RUN_ID") -eq "local"
    Write-Host "Mode: $(if ($isLocalMode) { 'LOCAL API' } else { 'ECS' })"
}
```

## Phase 1 — Output Path Resolution

```powershell
if ($workspaceId) {
    # Launcher mode: output to temp directory (stage directory created by worker)
    $outputPath = Join-Path (Join-Path (Join-Path $env:TEMP "aidlc-ws") $workspaceId) "lld"
} else {
    # Direct invocation: output to project root (for backward compatibility)
    $outputPath = "./design-output"
}

Write-Host "Output path: $outputPath"
```

---

## Agent Invocation

> ⚡ **AIDLC Launcher mode**: If `aidlc.config.json` **exists** in the current working directory,
> read it and output to the temp directory path above. Mode detection via `$env:AIDLC_RUN_ID`.
> Both local and ECS modes use the same workflow.

Use Task tool with `subagent_type="design-agent"` with the following enriched prompt:

Prompt: """
## User Request
$ARGUMENTS

## Intent: GENERATE (Create Design Documents)

### 1. Analyze User Intent
- Identify document type: Feature-TDD | UI-TDD | Service-TDD
- Extract file paths mentioned in request
- Identify any constraints or preferences

### 2. ADLC Required Context
- For Feature-TDD: Locate FSD, Master TDD, Common Library TDD
- For UI-TDD: Locate Feature-TDD, FSD
- For Service-TDD: Locate Feature-TDD, FSD, Common Library TDD
  → Also run Step 2.5 (runtime detection) before gathering additional context

### 2.5. Detect Target Runtime (Service-TDD only)

Grep the FSD or Feature-TDD for runtime indicators:
- **Spring Boot indicators**: "Spring Boot", "Java", "@SpringBootApplication", "JPA", "stored procedure", "Flyway", "JDBC"
- **Lambda indicators**: "Lambda", "Node.js", "DynamoDB", "AWS Lambda", "handler", "nodejs-pair-programmer"

| Detection result | `targetRuntime` | Additional context to locate |
|-----------------|-----------------|------------------------------|
| Spring Boot indicators found (or no indicators either way) | `springboot` | `schema-snapshot.json` (stored-procedure catalog), `domain-pack.json` (schema-authority posture) |
| Lambda/Node.js indicators found explicitly | `lambda` | Common Library TDD already sufficient |
| Both sets found or genuinely ambiguous | — | Ask the user: "Is this service targeting Java/Spring Boot or Node.js/Lambda?" |

Default is `springboot` — only switch to `lambda` when Lambda indicators are explicitly present and no Spring Boot indicators conflict.

### 3. Output Path Discovery
- Tier 1: Check input documents for outputPath metadata
- Tier 2: Check workspace structure (.claude_kb/workspaces/EPIC-XXX/technical/design/)
- Tier 3: Prompt user only if Tier 1 & 2 fail

### 4. Present Plan Before Execution
- Summarize what you understood
- List what you will generate
- Identify which agent to delegate to (state the detected `targetRuntime` for Service-TDD)
- **If `targetRuntime == "springboot"`**: verify schema-authority posture (immutable vs owned); confirm `schema-snapshot.json` is available; confirm stored-procedure catalog coverage
- **If `targetRuntime == "lambda"`**: verify critical patterns — protocol specification, async operations >16s, Lambda config 1024MB/30s
- Check if `aidlc.config.json` exists in the current working directory. If it does NOT exist, this is a headless ECS server run — log the plan and proceed immediately without waiting for confirmation. If it does exist, wait for explicit user confirmation before proceeding.

### 5. Delegate to Appropriate Agent
- feature-tdd-designer → Feature Technical Design documents
- ui-tdd-designer → UI Technical Design documents
- For Service-TDD — route by `targetRuntime`:
  - **springboot-tdd-designer** (default) → Java/Spring Boot Service Technical Design: controller/service/repository layers, stored-procedure DAOs, immutable-schema rules
  - service-tdd-designer (only when `targetRuntime == "lambda"`) → Lambda/Node.js Service Technical Design: three-layer Lambda, DynamoDB, go-style errors, `@inscore/common-lib`

> ⚠️ **domain-pack.json is only generated by `springboot-tdd-designer`.** If you are
> generating a Feature-TDD, UI-TDD, or Lambda Service-TDD — and have NOT also run a
> Spring Boot Service-TDD in this M1 stage — `domain-pack.json` will NOT be present
> when M3 (api-code) runs. M3 has a mandatory hard gate on domain-pack.json and will
> block with:
> _"domain-pack.json not found. M1 (LLD stage) must complete first."_
>
> **To unblock M3**: re-run M1 and include the Spring Boot Service-TDD request so
> `springboot-tdd-designer` generates `domain-pack.json` as a sidecar artifact.

### 6. Include Full Context in Delegation
- Original user request
- Source documents (FSD, TDD, etc.)
- Output path and naming conventions
- Critical pattern verification checklist
"""

Request to process: $ARGUMENTS

---

## Reporting to the AIDLC Platform (ECS UI tracking)

> **SERVER CLI GUARD:** If `aidlc.config.json` does **not** exist in your current
> working directory, skip this entire ECS section and run only the main workflow
> above. These steps are for the **local Claude Code session only**.

The local session creates the ECS run and monitors progress. All generation
is performed by the ECS server CLI — do **not** generate or copy files locally.

---

**Step 0 — Read config**
```powershell
$cfg   = Get-Content "aidlc.config.json" | ConvertFrom-Json
$BASE  = $cfg.central_base_url
$TOKEN = [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env)
$WS    = $cfg.workspace_id
$HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
$STAGE = "lld"
```

**Step 1 — Smart run management: cancel queued / attach running / create fresh**
```powershell
# Check for an existing active run for this stage
$existing = $null
try {
    $existing = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS&stage_key=$STAGE" -Headers $HDR).items |
        Where-Object { $_.state -in @("queued", "running") } |
        Sort-Object queued_at -Descending |
        Select-Object -First 1
} catch {}

if ($existing -and $existing.state -eq "queued") {
    # Queued but not started — cancel immediately and restart fresh
    Invoke-RestMethod "$BASE/pipeline-runs/$($existing.run_id)/cancel" -Headers $HDR -Method Post | Out-Null
    Write-Host "Cancelled queued run $($existing.run_id) — creating fresh run."
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
} elseif ($existing -and $existing.state -eq "running") {
    # Already being processed by the worker — attach and monitor, do NOT cancel
    $RUN_ID = $existing.run_id
    Write-Host "Run already in progress: $RUN_ID — attaching to monitor."
} else {
    # No active run — create a fresh one
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
}
```

**Step 2 — Monitor and display elapsed time**
```powershell
do {
    Start-Sleep -Seconds 15
    $run     = Invoke-RestMethod "$BASE/pipeline-runs/$RUN_ID" -Headers $HDR
    $elapsed = if ($run.started_at) {
        $s = [datetime]::Parse($run.started_at)
        $e = if ($run.finished_at) { [datetime]::Parse($run.finished_at) } else { Get-Date }
        "$([int]($e - $s).TotalSeconds)s"
    } else { "queued" }
    $files = if ($run.files_written) { $run.files_written.Count } else { 0 }
    Write-Host "  [$elapsed]  state=$($run.state)  files=$files"
} while ($run.state -notin @("waiting_for_approval","completed","failed","cancelled"))
```

**Step 3 — Final timing summary**
```powershell
$fmt = { param($t) if ($t) { [datetime]::Parse($t).ToString("HH:mm:ss") } else { "—" } }
$sec = if ($run.started_at -and $run.finished_at) {
    [int]([datetime]::Parse($run.finished_at) - [datetime]::Parse($run.started_at)).TotalSeconds
} else { 0 }
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
Write-Host "  Run     : $RUN_ID"
Write-Host "  Stage   : $STAGE"
Write-Host "  State   : $($run.state)"
Write-Host "  Queued  : $(& $fmt $run.queued_at)"
Write-Host "  Started : $(& $fmt $run.started_at)"
Write-Host "  Finished: $(& $fmt $run.finished_at)"
Write-Host "  Elapsed : ${sec}s"
Write-Host "  Files   : $($run.files_written.Count) written"
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
```

**Step 3.5 — Post-run domain-pack.json existence check (Spring Boot runs only)**

After the run reaches `completed` or `waiting_for_approval`, check whether the stage produced `domain-pack.json`:

```powershell
# Only applies when a Spring Boot Service-TDD was part of this run
$domainPackPath = Join-Path $env:TEMP "aidlc-ws\$WS\lld\domain-pack.json"
$domainPackInFiles = $run.files_written | Where-Object { $_ -like "*domain-pack.json" }

if ($domainPackInFiles -or (Test-Path $domainPackPath)) {
    Write-Host ""
    Write-Host "  ✓ domain-pack.json confirmed: $domainPackPath"
    Write-Host "    M3 (api-code) can proceed."
} else {
    Write-Host ""
    Write-Host "  ⚠ domain-pack.json was NOT found at: $domainPackPath"
    Write-Host ""
    Write-Host "  If this run included a Spring Boot Service-TDD, this is a problem:"
    Write-Host "    - springboot-tdd-designer must write domain-pack.json as a sidecar"
    Write-Host "    - M3 (api-code) has a hard gate on this file and will BLOCK"
    Write-Host ""
    Write-Host "  If this run was Feature-TDD or UI-TDD only (no Spring Boot Service-TDD):"
    Write-Host "    - domain-pack.json is not generated on this path (expected)"
    Write-Host "    - Re-run M1 including the Spring Boot Service-TDD before starting M3"
}
```

> ⛔ **Do NOT start M3 (api-code) if domain-pack.json is absent** after a Spring Boot
> Service-TDD run — M3 will immediately HARD STOP and require you to re-run M1 anyway.

**Step 4 — Review in ECS UI**
```
https://poc-ecs-build-ui.npsdlchgapp.us-east-1.aws.aig.net/aidlc-platform-management/pipeline
```

Approval persona: **Architect**
