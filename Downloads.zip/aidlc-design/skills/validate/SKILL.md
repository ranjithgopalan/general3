---
name: validate
description: Validate design document coverage against source requirements. Use when checking Feature-TDD, UI-TDD, or Service-TDD completeness and compliance with critical patterns.
---

# Validate Design Documents Skill

Validates design document coverage against source requirements and critical patterns.

## When to Use

Use this skill when:
- Validating Feature-TDD coverage against FSD
- Validating UI-TDD coverage against Feature-TDD and FSD
- Validating Service-TDD coverage against Feature-TDD and FSD
- Checking compliance with critical patterns (protocol specification, async operations, Lambda config)

## Usage

[Extended thinking: This skill validates design documents - checking Feature-TDD coverage against FSD, TDD coverage against Feature-TDD. It enriches the request with validation context and verifies critical patterns (protocol specification, async operations >16s, Lambda config 1024MB/30s).]

## Agent Invocation

Use Task tool with `subagent_type="design-agent"` with the following enriched prompt:

Prompt: """
## User Request
$ARGUMENTS

## Intent: VALIDATE (Check Design Coverage)

### 1. Identify Validation Scope
- If Feature-TDD provided: Validate against FSD
- If UI-TDD provided: Validate against Feature-TDD and FSD
- If Service-TDD provided: Validate against Feature-TDD and FSD

### 2. Load Source Documents
- Locate the ground truth documents (FSD, Feature-TDD)
- Extract all requirements and specifications
- Build requirement traceability map

### 3. Analyze Coverage
For each requirement in source:
- Check if addressed in target document
- Identify gaps and missing items
- Check for consistency
- Verify critical patterns: protocol specification, async operations >16s, Lambda config 1024MB/30s
- Verify HLR-12 compliance: no NgModule declarations, FeatureModule references, NgRx patterns, or non-design-relevant UI Standards sections present
- Verify required sections completeness: TypeScript interfaces, validators, signals, component specs, API integration, accessibility, error handling all present

### 4. Report Findings
- Coverage percentage
- List of gaps (requirements not addressed)
- Inconsistencies found
- Critical pattern violations (missing protocol, wrong Lambda config, missing async pattern)
- HLR-12 violations (unexpected constructs present or required design sections missing)
- Suggestions for resolution

### 5. Summary
- Overall coverage score
- Priority gaps to address
- Critical pattern compliance
- Recommendations
"""

Request to process: $ARGUMENTS
