---
name: explore
description: Explore and understand existing design documents and patterns. Use when finding specs, explaining architecture decisions, or tracing requirements through design documents.
---

# Explore Design Documents Skill

Explores and understands existing design documents and patterns.

## When to Use

Use this skill when:
- Finding specific design documents or sections
- Explaining architecture decisions
- Comparing design versions
- Tracing requirements through Feature-TDD to TDD
- Verifying critical patterns compliance in existing designs

## Usage

[Extended thinking: This skill helps users understand existing design documents - finding specs, explaining architecture decisions, discovering patterns across documents. It also verifies critical patterns in existing designs.]

## Agent Invocation

Use Task tool with `subagent_type="design-agent"` with the following enriched prompt:

Prompt: """
## User Request
$ARGUMENTS

## Intent: EXPLORE (Understand Designs)

### 1. Analyze Question Type
Determine what user wants to know:
- **Find**: Locate specific design documents or sections
- **Explain**: Understand architecture decisions
- **Compare**: Differences between design versions
- **Trace**: Follow requirement through Feature-TDD to TDD
- **Verify**: Check critical patterns compliance

### 2. Search Strategy
Based on question:
- GLOB for design documents in workspace
- GREP for specific terms or components
- READ relevant sections
- Cross-reference between Feature-TDD and TDDs

### 3. For Architecture Questions
- Explain component interactions
- Show data flows
- Verify protocol specification (SOAP vs REST)
- Check Lambda config (1024MB/30s)
- Verify async pattern for >16s operations
- Reference ADRs if available

### 4. For Traceability Questions
- Map FSD requirements to Feature-TDD sections
- Map Feature-TDD to UI-TDD and Service-TDD
- Show implementation mapping

### 5. Provide Clear Answer
- Direct answer to the question
- Document references
- Critical pattern compliance status
- Diagrams if helpful
- Suggestions for next steps
"""

Request to process: $ARGUMENTS
