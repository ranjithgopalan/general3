---
name: help
description: Display comprehensive help documentation for AIDLC-design plugin including commands, workflows, and quality checklists. Use when users need guidance on using design tools.
---

# AIDLC-design Help Skill

Comprehensive help documentation for the AIDLC-design plugin.

## When to Use

Use this skill when:
- User asks for help with AIDLC-design
- User needs to understand design document types
- User wants workflow guidance
- User asks about quality checklists

## Help Content

# Design Agent Plugin - Help

Expert Design Agent specializing in creating implementation-ready technical specifications for UI components, APIs, and Lambda services.

## Overview

The Design Agent bridges the gap between high-level business requirements and code implementation. It transforms Features (from product-owner) and User Stories (from scrum-master) into detailed technical design documents (TDD) that serve as blueprints for code generation.

## Role in SDLC Workflow

```
Business Analyst → Product Owner → Scrum Master → Design Agent → Pair Programmers
    (EPIC/BRD)      (Feature/PRD)   (User Stories)   (TDD Specs)   (Code Implementation)
```

**Input**: Feature Specification Documents (FSD), Master TDD, Common Library TDD
**Output**: Feature-TDD.md, UI-TDD.md, Service-TDD.md

## Skills

### AIDLC-design:generate

Unified skill for design document generation. Routes intelligently based on your request.

**Usage:**
```bash
# Feature-TDD Generation (Architecture)
Invoke generate skill: create Feature-TDD from ./requirements/feature-spec.md
Invoke generate skill: create architecture for claims processing feature

# UI-TDD Generation (Component Specs for axis-tools)
Invoke generate skill: create UI-TDD from the Feature-TDD
Invoke generate skill: create component specifications for axis-tools
Invoke generate skill: generate form validators and signal definitions

# Service-TDD Generation (Lambda Specs for nodejs-pair-programmer)
Invoke generate skill: create Service-TDD from the Feature-TDD
Invoke generate skill: create consolidated Service-TDD for all Lambda services
Invoke generate skill: generate Lambda handler specs with validation rules
```

**Routing Logic:**

| Triggers | Design Type | Agent | Output |
|----------|-------------|-------|--------|
| Feature-TDD, architecture, high-level design | Feature-TDD | feature-tdd-designer | `{feature}-Feature-TDD.md` |
| UI-TDD, component specs, axis-tools | UI-TDD | ui-tdd-designer | `{feature}-UI-TDD.md` |
| Service-TDD, API specs, Lambda, nodejs | Service-TDD | service-tdd-designer | `{feature}-Service-TDD.md` (consolidated) |

### AIDLC-design:validate

Validate design document coverage against source requirements.

**Usage:**
```bash
Invoke validate skill: validate Feature-TDD against FSD
Invoke validate skill: check Service-TDD for customer-search
```

### AIDLC-design:explore

Explore and understand existing design documents.

**Usage:**
```bash
Invoke explore skill: What services are in customer-portal Feature-TDD?
Invoke explore skill: Does customer-search Service-TDD specify SOAP or REST?
```

## Document Flow

```
Phase 1: Feature-TDD Generation (Architecture)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FSD + Master TDD + Common Library TDD
                │
                ▼
    Invoke generate skill from [FSD path]
                │
                ▼
       feature-tdd-designer
    (presents plan → user confirms)
                │
                ▼
        {feature}-Feature-TDD.md
                │
        (Human Review)


Phase 2: TDD Generation (Specifications)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{feature}-Feature-TDD.md (approved) + FSD
                │
      ┌─────────┴─────────┐
      ▼                   ▼
 Generate UI-TDD    Generate Service-TDD
      │                   │
      ▼                   ▼
ui-tdd-designer    service-tdd-designer
(plan → confirm)   (plan → confirm)
      │                   │
      ▼                   ▼
{feature}-UI-TDD.md    {feature}-Service-TDD.md
      │                (consolidated - all services)
      ▼                         │
  axis-tools                    ▼
                       nodejs-pair-programmer
```

## Three Design Document Types

### 1. Feature-TDD (Feature Technical Design Document)
- Combined UI + Services architecture
- For human review before TDD generation
- Contains system architecture decisions
- Single high-level document

### 2. UI-TDD (UI Technical Design Document)
- Component specifications with TypeScript interfaces
- Inputs, outputs, methods, lifecycle hooks
- State management patterns (Angular Signals)
- Form validators and cross-field validation
- Consumed by `axis-tools` for code generation

### 3. Service-TDD (Service Technical Design Document)
- Consolidated TDD containing ALL Lambda services
- Lambda handler specs with validation rules
- API contracts with request/response schemas
- Three-layer architecture (handler, processor, helpers)
- Go-style error handling
- Consumed by `nodejs-pair-programmer` for code generation

## Document Storage

All design documents are stored in the workspace structure:

```
.claude_kb/workspaces/EPIC-XXX/technical/design/
├── {feature}-Feature-TDD.md  (Architecture)
├── {feature}-UI-TDD.md        (UI specifications)
└── {feature}-Service-TDD.md   (All Lambda services)
```

## Comprehensive Specifications Include

- Component inputs, outputs, methods, lifecycle hooks
- State management patterns and data models
- API endpoints with request/response schemas
- Lambda trigger types and event structures
- Data validation rules and business logic
- Error handling and edge cases
- Testing requirements and acceptance criteria
- Accessibility and security considerations

## Policy Object Model (POM) Integration

Design agent focuses on **relevant POM sections** for each feature:
- Not the entire POM (too large)
- Only fields needed for the specific workflow
- Mapped to UI components and API endpoints
- Validated against business rules

## Confirmation Workflow

All design agents follow a **Plan → Confirm → Generate** workflow:

1. Agent reads all input documents
2. Agent analyzes and creates a structured plan
3. Agent presents plan to user for confirmation
4. User reviews and confirms (or requests modifications)
5. Agent generates output documents

## Quality Checklist

Before completion, design specs verify:
- [ ] All user story acceptance criteria addressed
- [ ] Component inputs/outputs clearly defined
- [ ] API contracts complete with schemas
- [ ] Data validation rules specified
- [ ] Error handling scenarios covered
- [ ] Accessibility requirements included
- [ ] Security considerations documented
- [ ] Testing requirements defined
- [ ] POM field mappings accurate
- [ ] Ready for code generation by pair programmers

## Key Distinctions

| This Plugin | vs Other Plugins |
|-------------|------------------|
| `AIDLC-design` | Creates design specs (Feature-TDD, UI-TDD, Service-TDD) |
| `AIDLC-axis` | Generates Angular code from UI-TDD |
| `AIDLC-lambda` | Generates Lambda code from Service-TDD |
| `AIDLC-docs` | Documents existing code |

## Version

- **Plugin Version**: 1.4.0
- **Output Location**: `.claude_kb/workspaces/EPIC-XXX/technical/design/`
