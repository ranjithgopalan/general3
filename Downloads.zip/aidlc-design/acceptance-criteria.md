# Design Agent - Acceptance Criteria

## High-Level Requirements (HLR)

### HLR-1: Cross-Field Validation in UI-TDD
**Requirement:** For UI component designs, specifications must include client-side validation rules that account for cross-field dependencies and relationships with other UI inputs within the component or form.

**Test:** `ui_tdd_cross_field_validation.test`

### HLR-2: Server-Side Validation in Services-TDD (Rules-as-a-Service)
**Requirement:** When generating specifications for Lambda functions, the documents must specify integration with Rules-as-a-Service API for validation. NO embedded validation logic is permitted. Documents must include Rules-as-a-Service endpoint, request/response format, and fallback strategies.

**Test:** `services_tdd_rules_as_service_validation.test`

### HLR-3: Complete Data Flow Documentation
**Requirement:** Given feature requirements, when the plugin creates design specifications, then it must document the complete data flow: UI captures user data and loads the POM, external APIs are called to enrich the POM, the combined UI-captured data and enriched POM data is stored to DynamoDB, and after business criteria are met, the data from DynamoDB is persisted to PostgreSQL.

**Test:** `complete_data_flow.test`

### HLR-4: POM Subsection Focus
**Requirement:** Given a Feature Specification Document (FSD) as input, when the plugin creates design specifications for a feature or workflow, then it should understand the Policy Object Model (POM) data structure and identify which subsection of the POM is relevant to focus on, rather than including the entire POM.

**Test:** `pom_subsection_focus.test`

### HLR-5: Master TDD-Driven Design
**Requirement:** Given Master TDD (which covers feature-level architecture) and Feature Specification Document (FSD), when the plugin generates design specifications, then it must use Master TDD patterns as source of truth and generate the final TDD: (1) Service-TDD (ONE consolidated document for ALL backend services), (2) UI-TDD. 

**Test:** `master_tdd_driven_design.test`

### HLR-6: Async Operations Pattern (Mandatory for >16s)
**Requirement:** When generating Services-TDD, agent must identify ALL operations that may take >16 seconds and specify complete async pattern including: (1) POST /api/{service}/async endpoint returning 202 with requestId, (2) GET /api/{service}/status/{requestId} polling endpoint, (3) operation-status DynamoDB table with complete schema, (4) async sequence diagram showing background processing.

**Test:** `async_operations_pattern.test`

### HLR-7: SOAP vs REST Protocol Specification (NO Assumptions)
**Requirement:** When generating Services-TDD for external API integrations, agent must check SOAP vs REST Endpoint Inventory and explicitly specify protocol. For SOAP: include SOAP envelope structure, XML parsing approach, Function 8 (buildSOAPRequest), Function 10 (parseAndTransformResponse). Agent must NEVER assume REST protocol.

**Test:** `soap_protocol_specification.test`

### HLR-8: Complete 11-Function Flow Engine Breakdown
**Requirement:** When generating Services-TDD for services using Flow Engine, agent must specify ALL 11 functions with complete breakdown including: Function 1 (extractBearerToken), Function 2 (validateToken), Function 3 (checkUserPermissions), Function 4 (validateRequest), Function 5 (loadConfiguration), Function 6 (determineAsyncPattern - CRITICAL), Function 7 (retrieveCredentials), Function 8 (buildRequest - CRITICAL), Function 9 (invokeService), Function 10 (parseAndTransformResponse - CRITICAL), Function 11 (formatSuccessResponse).

**Test:** `flow_engine_11_function_breakdown.test`

### HLR-9: Detailed Sequence Diagrams
**Requirement:** When generating Services-TDD, agent must create detailed sequence diagrams showing: (1) Sync sequence with all 11 Flow Engine functions labeled, (2) Async sequence with background Lambda invocation and polling pattern, (3) SOAP/REST protocol indicators, (4) Rules-as-a-Service API calls, (5) operation-status table interactions.

**Test:** `detailed_sequence_diagrams.test`

### HLR-10: Anti-Pattern Validation (8 Critical Checks)
**Requirement:** Before generating any Services-TDD output, agent must validate against 8 critical anti-patterns: (1) No synchronous calls for >16s operations, (2) No hardcoded endpoints, (3) No try-catch blocks (use go-style [error, result]), (4) No embedded validation logic (use Rules-as-a-Service), (5) No protocol assumption (explicit SOAP or REST), (6) No schema generation for relational DBs, (7) No missing Flow Engine functions, (8) No insufficient Lambda config (must be 1024MB/30s).

**Test:** `anti_pattern_validation.test`

### HLR-11: Lambda Configuration Standards
**Requirement:** When generating Services-TDD, agent must specify Lambda configuration as Memory: 1024MB, Timeout: 30s (NOT 512MB/16s) to support SOAP processing and async patterns.

**Test:** `lambda_configuration_standards.test`

### HLR-12: Axis UI Generator (AUG) Compliance
**Requirement:** When generating UI-TDD, the agent must specify component layout using Axis UI Generator (AUG)
JSON schema. No raw Angular HTML templates shall appear in TDD output. All form/layout component definitions
must follow the JSON-based design approach with `*.aug.json` structure specifications. Conditional field behavior
must use AUG `displayIf`/`requiredIf` properties — not Angular `*ngIf` directives.

**Test:** `axis_ui_generator_compliance.test`

### HLR-13: PlantUML and Mermaid Sequence Diagrams in UI-TDD
**Requirement:** When generating UI-TDD, the agent must include sequence diagrams in both Mermaid and PlantUML
formats. Diagrams must show component interaction flows (initialization, form submission, and cross-component
communication where applicable) that reflect the component interactions described in the specification.
Generated diagram syntax must be valid and renderable.

**Test:** `ui_tdd_sequence_diagrams.test`

### HLR-15: Custom Component Generation for Premium Features
**Requirement:** When generating UI-TDD or Feature-TDD for premium features with complex component structures,
the agent must: (1) classify components into a multi-tiered model (Tier 1–4: Page Container → Feature Container
→ Composite → Widget/Presentational), (2) document multi-tiered hierarchies with 3+ levels for complex premium
features, (3) provide a component relationship context table documenting @Input/@Output bindings and data flow at
each tier boundary, and (4) identify custom component types (Wizard, Dashboard Panel, Tab Container, Composite
Form, Data Grid) where applicable. Standard 2-tier Smart/Presentational features do not require the full tier
classification.

**Test:** `custom_component_generation.test`

### HLR-14: Minimal Source Code in TDD Output
**Requirement:** Source code in TDD documents must be limited to concise illustrative examples necessary for
design clarity. Full implementation code blocks must be excluded from TDD output. Component interfaces must
be documented via tables (inputs, outputs, methods) rather than TypeScript code blocks. Validator specifications
must use only function name, field names, condition, error key, and error message — not full implementations.
Feature-TDD must contain no implementation source code; architecture is expressed through Mermaid diagrams,
tables, and descriptions only. Output length must be measurably reduced without losing design fidelity.

**Test:** `ui_tdd_generation.test` (validates completeness with specification-level input and minimal code output)

### HLR-15: No Unnecessary Angular Constructs or UI Standard Sections
**Requirement:** Generated TDD output must not include unnecessary Angular constructs (NgModule declarations, module-based architecture patterns such as NgRx, FeatureModule references) or non-design-relevant UI Standard sections (typography, color schemes, responsive breakpoints, visual styling guidelines). Output must be concise and contain only design-essential content consumed by axis-tools and nodejs-pair-programmer.

**Test:** `no_unnecessary_angular_constructs.test`

### HLR-16: Axis/Custom Validators in TDD Output
**Requirement:** When generating UI-TDD, field-level validators must be specified using the Axis `UIValidators` interface (object notation: `{ required: true, minLength: 5 }`) and Axis custom validators (`axisEmail`, `axisRange`, `axisNumerics`, `axisAlphabets`, `axisCurrency`, `axisDecimal`, `axisAlphaNumerics`). Angular `Validators.*` class methods must not appear in field-level validator documentation. Cross-field validators (HLR-1) remain as custom `ValidatorFn` functions since Axis has no cross-field validation mechanism.

**Test:** `axis_validators_compliance.test`

### HLR-17: Respect Field Exclusion Rules from Specifications
**Requirement:** When an input FSD contains exclusion markers — `[EXCLUDED]` appended to a section header or field
entry, or a `## Out of Scope` / `## Excluded Sections` block — the design agent must not include the marked sections
or fields in any generated TDD output. Exclusion must be detected and applied before the planning step. Agents must
list detected exclusions in the confirmation plan.

**Test:** `field_exclusion_rules.test`

## Command-Specific Criteria

### Service-TDD Generation (`/design-agent:services-tdd`)
- Generates Service-TDD (ONE consolidated document for ALL backend services)
- Includes complete async patterns (POST /async, GET /status, operation-status table) for >16s operations
- Specifies SOAP or REST protocols explicitly (from Endpoint Inventory, NO assumptions)
- Includes complete 11-function Flow Engine breakdown with Functions 6/8/10 detailed
- Integrates Rules-as-a-Service for validation (NO embedded validation logic)
- Includes sync + async sequence diagrams with all 11 functions, SOAP/REST indicators
- Specifies Lambda config: 1024MB/30s
- Runs 8 anti-pattern validation checks before output
- Output is for nodejs-pair-programmer code generation

**Test:** `services_tdd_generation.test`

### UI-TDD Generation (`/design-agent:ui-tdd`)
- Generates UI-TDD with detailed component specifications for axis-tools
- Documents inputs/outputs with TypeScript types using tables (not code blocks)
- Includes field validators using UIValidators interface / Axis custom validators (HLR-16) and cross-field validators (HLR-1) as concise specs (name + fields + condition + error key)
- Maps to POM when provided (instruction-driven)
- Includes state management strategy (Signals/Services)
- Documents component communication patterns
- **Specifies AUG JSON schema (`*.aug.json`) for all form/layout components (HLR-12)**
- **No raw Angular HTML templates in TDD output (HLR-12)**
- **Uses displayIf/requiredIf for conditional logic — not *ngIf (HLR-12)**
- **Includes Mermaid sequence diagrams for component interaction flows (HLR-13)**
- **Includes PlantUML sequence diagrams for component interaction flows (HLR-13)**
- **Diagrams reflect component interactions from the spec with valid, renderable syntax (HLR-13)**
- **Code limited to concise illustrative examples only — no full implementations (HLR-14)**
- **Component interfaces documented via Input/Output/Method tables — not TypeScript code blocks (HLR-14)**
- **Premium features with 3+ tier hierarchies include multi-tiered component classification and relationship context (HLR-15)**
- **Custom component types (Wizard, Dashboard, Tab, Composite) identified and classified by tier when applicable (HLR-15)**
- Output is for axis-tools code generation

**Test:** `ui_tdd_generation.test`

### Validate Coverage (`/design-agent:validate-coverage`)
- Validates 100% feature coverage
- Checks all features from FSD against design documents
- Reports coverage percentage
- Lists missing coverage by feature

**Test:** `validate_coverage.test`

## Reference Materials

### Master TDD and Templates
- **Master TDD (Updated)**: `__tests__/reference/master-tdd-full-updated.md` (Version 2.4, 2025-12-16)
- **Service TDD Template**: `reference/service-tdd-template.md` (Version 2.1, 2025-12-09)
  - Section 2.3: Lambda Configuration (1024MB/30s with rationale)
  - Section 5.2: Sequence Diagram Requirements
  - Section 6.2: Asynchronous Operations Pattern (>16s)
  - Section 6.3: Integration Protocol Specification (SOAP vs REST)
  - Section 9.3: Rules-as-a-Service Integration
  - Section 16: Anti-Pattern Validation Checklist
- **UI TDD Template**: `reference/ui-tdd-template 1.md`

### Common Library Specifications
- **Flow Engine**: `reference/3. DynamoDB/2. Common Library/flow-engine.md`
- **Entitlements Library**: `reference/3. DynamoDB/2. Common Library/entitlements-library.md`
- **Vault Lambda Extension**: `reference/3. DynamoDB/2. Common Library/vault-lambda-extension-tdd.md`
- **Validate Token Library**: `reference/3. DynamoDB/2. Common Library/validate-token-library.md`
- **Correlation ID Library**: `reference/3. DynamoDB/2. Common Library/correlationId-spec.md`
- **Externalizing Environment Variables**: `reference/3. DynamoDB/2. Common Library/externalizing-env-variables-library-tdd.md`

### Master TDD Examples
- **Master TDD Full**: `reference/3. DynamoDB/1.Master TDD/master-tdd-full.md`
- **UI Components Service**: `reference/3. DynamoDB/1.Master TDD/ui-components-service.md`

### External API Resources
- **Rules-as-a-Service Instructions**: `__tests__/reference/inscore-Raas-validation-instructions-samples.pdf`
- **TDD Validator Architect Guide**: `__tests__/reference/tdd-validator-architect-agent.pdf`

## Test Coverage Summary

| Test File | HLR Coverage | Description | Reference Materials |
|-----------|--------------|-------------|---------------------|
| ui_tdd_cross_field_validation.test | HLR-1 | Cross-field validation in UI-TDD | ui-tdd-template.md |
| services_tdd_rules_as_service_validation.test | HLR-2 | Rules-as-a-Service validation in Services-TDD | service-tdd-template.md Section 9.3 |
| complete_data_flow.test | HLR-3 | Data flow documentation | master-tdd-full-updated.md |
| pom_subsection_focus.test | HLR-4 | POM subsection identification | master-tdd-full-updated.md |
| master_tdd_driven_design.test | HLR-5 | Master TDD as source of truth (NO Feature-TDD) | master-tdd-full-updated.md, flow-engine.md |
| async_operations_pattern.test | HLR-6 | Async pattern for >16s operations | service-tdd-template.md Section 6.2 |
| soap_protocol_specification.test | HLR-7 | SOAP vs REST explicit specification | service-tdd-template.md Section 6.3 |
| flow_engine_11_function_breakdown.test | HLR-8 | Complete 11-function Flow Engine breakdown | flow-engine.md, service-tdd-template.md |
| detailed_sequence_diagrams.test | HLR-9 | Detailed sync + async sequence diagrams | service-tdd-template.md Sections 5.2, 6.2, 6.3, 9.3 |
| anti_pattern_validation.test | HLR-10 | 8 critical anti-pattern checks | service-tdd-template.md Section 16 |
| lambda_configuration_standards.test | HLR-11 | Lambda config 1024MB/30s | service-tdd-template.md Section 2.3 |
| axis_ui_generator_compliance.test | HLR-12 | AUG JSON-based design, no raw HTML templates | dynamic-ui-generator.md, ui-tdd-designer.md |
| ui_tdd_sequence_diagrams.test | HLR-13 | PlantUML and Mermaid sequence diagrams in UI-TDD | ui-tdd-designer.md, design-guidelines.md |
| ui_tdd_generation.test | HLR-14 | Minimal code output — tables for interfaces, concise validator specs, no full implementations | ui-tdd-designer.md |
| no_unnecessary_angular_constructs.test | HLR-15 | No NgModule or UI Standards sections in TDD output | ui-tdd-designer.md, feature-tdd-designer.md |
| axis_validators_compliance.test | HLR-16 | Axis/Custom validators replace Angular Validators.* | ui-tdd-designer.md, validation.types.ts |
| field_exclusion_rules.test | HLR-17 | Excluded sections/fields absent from TDD output | ui-tdd-designer.md, design-guidelines.md |
| custom_component_generation.test | HLR-18 | Custom component types, multi-tiered hierarchy (3+ levels), nested relationships, component relationship context | ui-tdd-designer.md, design-guidelines.md |
| services_tdd_generation.test | Command | Service-TDD generation | All service-tdd-template.md sections |
| ui_tdd_generation.test | Command | UI-TDD generation for axis-tools (with AUG + sequence diagrams + minimal code) | ui-tdd-template.md, dynamic-ui-generator.md |
| validate_coverage.test | Command | Coverage validation | master-tdd-full-updated.md |
