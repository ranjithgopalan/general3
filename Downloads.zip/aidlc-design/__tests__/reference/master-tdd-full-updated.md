# Master Technical Design Document - Inscore Policy Booking Application (Updated)

## Modification History

| Version | Date       | Author       | Description of Changes |
| ------- | ---------- | ------------ | ---------------------- |
| 1.0     | 2025-01-XX | TDD Team     | Initial master TDD creation with serverless-first architecture, core services (Booking Management Service, UI Components Service), shared libraries (Flow Engine, Validate Token, Entitlements), DynamoDB and PostgreSQL Aurora integration |
| 2.0     | 2025-01-21 | TDD Team     | Comprehensive service catalog update:<br/>- Added **Integration-Proxy-Service** with 10-function Flow Engine orchestration and Vault integration for secure external API calls<br/>- Added **Reference-Data-Sync-Service** with dual sync paths (RDM REST API and PostgreSQL Aurora) to DynamoDB<br/>- Expanded **UI-Components-Service** documentation to show single service serving 7 functional areas (Initiate Booking, Client Information, Producer Information, Policy Details, Coinsurance, Risk Location, General Components)<br/>- Added 4 new shared libraries: **Vault-Lambda-Extension**, **PostgreSQL-Aurora-Connection**, **Correlation-ID-Library**, **Externalizing-Env-Variables-Library**<br/>- Enhanced Section 3.2 (Core Services) with Document Reference column linking to individual service TDDs<br/>- Enhanced Section 3.2.2 (Shared Libraries) with detailed integration patterns and usage descriptions<br/>- Updated Section 15 (Lambda Function Specifications) with detailed specifications for Integration Proxy Service and Reference Data Sync Service including environment variables, VPC configurations, flow functions, and transformation rules<br/>- Consolidated all database references to **PostgreSQL Aurora** (removed PostgreSQL RDS)<br/>- All services now include runtime specifications, memory allocations, timeout configurations, invocation patterns, dependencies, and document references |
| 2.1     | 2025-11-29 | TDD Team     | Updated **Reference Data Sync Service** architecture to SQS-based parallel processing:<br/>- **Architecture Change**: Split single Lambda into Enqueue Lambda (256MB, 60s, concurrency=1) and Worker Lambda (1024MB, 300s, concurrency=40)<br/>- **SQS Integration**: Added SQS message queue for parallel RDM table processing with Dead Letter Queue<br/>- **PostgreSQL Sync**: Recurring scheduled sync via EventBridge (similar to RDM sync)<br/>- **RDM Sync**: Daily scheduled via EventBridge at 2 AM UTC<br/>- **Secret Management**: Changed from HashiCorp Vault to AWS Secrets Manager for RDM credentials<br/>- **Integration Pattern**: Changed from synchronous sequential execution to asynchronous parallel processing via SQS<br/>- Updated Section 3.4.2, 3.4.4, 3.4.5, 3.4.8, and 14.1.4 to reflect new architecture<br/>- Updated architecture diagram to show Enqueue/Worker Lambda configuration |
| 2.2     | 2025-12-09 | TDD Team     | Added **Reference Lookup Service** comprehensive specification to Section 14.1.7:<br/>- **Service Purpose**: Centralized reference data lookup service with single unified endpoint (GET /api/reference)<br/>- **Header-Based Routing**: Automatic country detection via X-Country-Code header for transparent country-specific data routing<br/>- **Intelligent Data Merging**: Batch query pattern retrieving BOTH global (refGroupCode="000000") and country-specific reference data when country code present, with country-specific values overriding global values for same dataElementCode<br/>- **DynamoDB Access Patterns**: GSI1 query for COUNTRY-PARAMS resolution (1 RCU) + batch base table queries for reference data (2-4 RCU with country code, 1-2 RCU without)<br/>- **Axis-Compatible Format**: Response transformation to {id, name, isSelected} structure for frontend dropdown/select components<br/>- **Performance Metrics**: 40-80ms avg latency with country code (3-5 RCU), 20-40ms without country code (1-2 RCU)<br/>- **Multi-Language Support**: Language selection via X-Language-Id header (default: 1)<br/>- **Automatic Fallback**: Global reference data fallback when country code absent or COUNTRY-PARAMS not found<br/>- **Caching Strategy**: Multi-layer caching with API Gateway and client-side caching<br/>- **Document Reference**: design/7. Integration/inscore-referencelookup-service.md |
| 2.3     | 2025-12-10 | TDD Team     | Comprehensive TypeScript migration and architectural enhancements across multiple services:<br/>- **TypeScript Migration**: Migrated Node.js service implementations from JavaScript to TypeScript across all Lambda functions and common libraries<br/>- **Client Individual Service**: Enhanced TypeScript implementation with improved type safety, updated API documentation (design/5. Client Information/3. Lambda/client-individual-service.md) with comprehensive request/response examples<br/>- **Client Information UI**: Updated UI TDD with booking reference lookup integration for country, marital status, gender, and language dropdowns; enhanced sequence diagrams to reflect reference data flow (design/5. Client Information/1. UI/client-information-ui-design.md)<br/>- **Integration Proxy Service**: Updated request/response format to latest standard; integrated Entitlements API calls for authorization checks; enhanced documentation with detailed API call structures (design/5. Client Information/3. Lambda/integration-proxy-service.md)<br/>- **Entitlements Library Enhancement**: Migrated checkUserPermissions function (Function 3) to resource-action pair format instead of simple action strings; updated authorization model to resource-based permission system; added Common Library Section 6.3 reference for entitlements pattern<br/>- **Common Library Updates**: Added PostgreSQL Aurora connection library implementation; renamed Correlation-ID interceptor to global.interceptor for broader scope and consistent naming<br/>- **UI Architecture Correction**: Removed all references to direct Common Library calls from UI components; corrected service invocation flow to **UI → API Gateway → Integration Proxy Lambda → Common Library modules** across all success and failure sequence diagrams<br/>- **AXIS Framework Integration**: Updated references to AXIS Components 18.0.0+ throughout UI component specifications and integration patterns<br/>- **Okta Configuration**: Updated environment configuration with actual Okta values for 7454-InsCore non-prod environment; reflected real Okta URLs in authentication sequence diagrams (design/7. Integration/generic-okta-login-tdd.md)<br/>- **Role-Based Dashboard**: Introduced role-specific dashboard rendering logic in success sequence diagrams showing different user experiences based on entitlements<br/>- **Master TDD Updates**: Updated Node.js runtime specifications from JavaScript to TypeScript notation across all service specifications in Section 3.2 (Core Services) and Section 3.2.2 (Shared Libraries) |
| 2.4     | 2025-12-16 | TDD Team     | **Integration Proxy Service v1.4 and Common Library v1.3.0 Updates + Architecture Correction**:<br/>- **Integration Proxy Service (v1.4, 2025-12-13)**: 1) **Configuration Management**: Moved 11 URL environment variables to YAML config file (api-endpoints.yml); updated all references from process.env to apiConfig object; separated API endpoints (config file) from infrastructure variables (env vars); added loadConfigFile utility integration from @inscore/common-lib/config. 2) **Dev Environment URLs**: Replaced all model/example endpoints with actual Dev environment URLs for Entitlements API (entitlement-api-v1-dev.dev.ss.hip10.npuweks.us-east-1.aws.aig.net) and MDM Gateway API (mdm-gateway-api-v1-dev.dev.ss.hip10.npuweks.us-east-1.aws.aig.net); added comprehensive environment-specific URL documentation (Dev/UAT/Prod). 3) **Authorization Payloads**: Added Party Operations Authorization Context table with permission check payloads; implemented hyphenated resource names (Client-Organization, Client-Individual, Producer); added determineRequiredPermissions helper function; documented complete HTTP request examples with actual Dev endpoints. 4) **Memory and Timeout**: Increased memory from 512MB to 1024MB for YAML config processing; increased timeout from 30s to 300s (5 minutes) to support both sync and async operations. 5) **Flow Functions Update**: Added Function 6 (determineRequiredPermissions) as new helper function; updated Function 5 from loadMDMConfiguration to loadConfiguration to reflect YAML config loading; renumbered remaining flow functions accordingly (now 12 functions total)<br/>- **Common Library v1.3.0 (2025-01-09)**: Enhanced Entitlements Module Check User Roles API documentation with hierarchical organization structure; documented APP → COUNTRY → PRODUCT/LANGUAGE group hierarchy pattern with parent-child relationships via parentGroupId references; added comprehensive nested entities array examples showing multi-level hierarchy; enhanced groupType values documentation (APP, COUNTRY, PRODUCT, LANGUAGE); clarified defaultFlag behavior for LANGUAGE groupType indicating default language preference<br/>- **Architecture Correction - Integration Consumer Lambda Removal**: 1) **Removed Incorrect Architecture**: Eliminated references to separate "Integration Consumer Lambda" as this component does not exist. 2) **Corrected Async Pattern**: Clarified that Integration Proxy Service Lambda ITSELF consumes from SQS queue via Event Source Mapping for async operations. 3) **Single Lambda Architecture**: Updated all diagrams, sequence flows, and documentation to reflect that same Integration Proxy Service Lambda handles BOTH synchronous (API Gateway) and asynchronous (SQS Event Source Mapping) invocations. 4) **Architecture Diagram Updates**: Removed "Integration Consumer" worker node; updated Integration Proxy specs to 1024MB/300s timeout; updated flow connections to show SQS → Event Source Mapping → Integration Proxy Service. 5) **Section Updates**: Removed entire Section 14.1.5 "Integration Consumer Lambda"; renumbered Section 14.1.6 → 14.1.5 (Reference Data Sync); updated Section 3.4.2, 3.4.4 async flow descriptions to reflect correct architecture<br/>- **Master TDD Updates**: Updated Section 3.2 (Integration-Proxy-Service row) to reflect 1024MB memory, configuration-driven architecture, and api-endpoints.yml config file; updated Section 3.2.2 (Entitlements-Library row) to include hierarchical organization structure support; updated Section 3.4.3 (Entitlements Library description) with detailed hierarchical structure explanation; updated Section 14.1.4 (Integration Proxy Service Lambda specification) with comprehensive configuration architecture, API endpoints configuration file structure, environment-specific URLs, updated responsibilities, and complete flow functions list with Party Operations Authorization Context table; updated Section 20.5.1 (Common Library Modules) to enhance entitlements module description with hierarchical structure capabilities; corrected all Integration Proxy Service async architecture references to reflect Event Source Mapping pattern |

## 1. Introduction

This Master Technical Design Document (TDD) outlines the architectural blueprint and core technical specifications for the **Inscore Policy Booking Application**. It serves as the primary reference for all technical development, ensuring consistency and alignment across various components. This document would be a living artefact during the course of Inscore **Policy Booking** development, laying the groundwork for a scalable and robust system. Subsequent Feature TDDss will delve into the granular details of the UI and individual Lambda functions.

## 2. Architecture Overview

The Inscore application adopts a **serverless-first architecture** leveraging AWS services to provide a highly scalable, resilient, and cost-effective solution. The core components include an Angular frontend, an API Gateway, AWS Lambda functions for business logic, DynamoDB for session and stage management, and PostgreSQL Aurora for persistent policy data.

### 2.1. Key Components:

- **User Interface (UI)**: Developed using **Angular**, providing a dynamic and responsive experience for policy booking.

- **API Gateway**: Acts as the **single entry point** for all UI requests, routing them to the appropriate backend Lambda functions. It handles request/response transformations, authentication, and throttling.

- **AWS Lambda (Business APIs)**: A set of **stateless functions** triggered by API Gateway. These lambdas encapsulate the core business logic for processing policy-related requests from the UI.

- **AWS Lambda (Event-Driven Backend)**: Additional **event-driven lambdas** will handle asynchronous tasks, data processing, and data retrieval from various sources. These are triggered by events (e.g., SQS, SNS, DynamoDB Streams).

- **AWS DynamoDB**: A **NoSQL database** used for high-performance key-value storage. It will primarily manage **user sessions** and track the **stages of the policy booking process**.

- **PostgreSQL Aurora**: A **relational database** for **final persistence of policy data**. This ensures data integrity and supports complex querying for reporting and analytical purposes.

## 3. Service Library

### 3.1 Service Architecture Overview

The Inscore application implements a service-oriented architecture with clear separation of concerns. Services are categorized into Core Services, Integration Services, and External Services, each with specific responsibilities in the policy booking flow.

### 3.2 Core Services and Shared Libraries


This Service Library will keep getting modified as we proceed with New Services development
| Service Name | Runtime | Memory | Invocation | Integration | Description | Data Flow Responsibility | Document Reference |
|-------------|---------|---------|------------|-------------|-------------|-------------------------|-------------------|
| **Booking-Management-Service** | Node.js 20.x.x Lambda | 512MB | Sync | API Gateway, Shared Libraries | Handles booking initiation using Flow Engine, Validate Token, and Entitlements libraries | Creates booking sessions in PostgreSQL Aurora booking_sessions table and updates booking-ui-sessions table | design/4. Initiate Booking/3. Lambda/booking-management-service.md |
| **Client-Individual-Service** | Node.js 20.x.x Lambda | 512MB | Sync | API Gateway, Integration Proxy Service, Shared Libraries, PostgreSQL Aurora | Manages client individual data operations including search, create, update, and retrieval with Flow Engine orchestration | Queries and stores client individual data in PostgreSQL Aurora client_individuals table; invoked by Integration Proxy Service for client search and management | design/5. Client Information/3. Lambda/client-individual-service.md |
| **UI-Components-Service** | Node.js 20.x.x Lambda | 768MB | Sync | API Gateway, Shared Libraries, S3, DynamoDB | Single service managing UI component delivery for 7 functions: Initiate Booking, Client Information, Producer Information, Policy Details, Coinsurance, Risk Location, and other workflow components | Queries DynamoDB ui-component-catalog, booking-component-status, booking-reference-lookup tables; retrieves POM schemas from S3 | design/1.Master TDD/ui-components-service.md |
| **Integration-Proxy-Service** | Node.js 20.x.x Lambda | 1024MB | Sync | API Gateway, Vault, MDM API, Client Individual Service | Secure proxy invoked by UI via API Gateway for MDM calls (Client Organization, Producers, Coinsurers, Reinsurers, Reinsurer Brokers, Cedants) and Client Individual Service for client individuals; uses Vault for credential management with 10-function Flow Engine orchestration; configuration-driven architecture with API endpoints in YAML config file | Retrieves credentials from Vault; transforms requests/responses; calls MDM API for organization entities and Client Individual Service for client individuals; loads API endpoints from api-endpoints.yml configuration file | design/7. Integration/Integration-proxy-service.md |
| **Reference-Data-Sync-Service** | Node.js 20.x.x Lambda | 1024MB | EventBridge (scheduled), Jenkins (on-demand) | RDM API, PostgreSQL Aurora, DynamoDB, Vault | Synchronizes reference data from RDM and PostgreSQL treftab to DynamoDB with dual independent sync paths | Fetches from RDM REST API and PostgreSQL Aurora treftab; transforms and loads into DynamoDB booking-reference-lookup table | design/7. Integration/reference-data-sync-lambda-design.md |

#### 3.2.2 Shared Libraries (Reusable Components)
| Library Name | Runtime | Deployment | Integration | Description | Usage Pattern | Document Reference |
|-------------|---------|-------------|------------|-------------|---------------|-------------------|
| **Flow-Engine-Library** | Node.js 20.x.x | Lambda Layer / npm package | DynamoDB (service-function-flows table) | Single reusable library for configurable function flow execution with dynamic function chains | Used by all business services for dynamic workflow execution based on endpoint-to-flow mappings | design/2. Common Library/flow-engine.md |
| **Validate-Token-Library** | Node.js 20.x.x | Lambda Layer / npm package | Okta / External Auth Provider | Centralized JWT token validation service with Okta integration | Shared across all services requiring authentication; validates Bearer tokens and extracts user information | design/2. Common Library/validate-token-library.md |
| **Entitlements-Library** | Node.js 20.x.x | Lambda Layer / npm package | Entitlements API, Vault | Unified user permission checking service (RBAC) with AppId 7454 and Vault integration for credentials; supports hierarchical organization structure (APP → COUNTRY → PRODUCT/LANGUAGE groups) with parent-child relationships via parentGroupId | Used by all services for authorization decisions; checks user roles and permissions via CheckUserRole and CheckUserPermissions functions; retrieves complete hierarchical entities array with nested group structures | design/2. Common Library/entitlements-library.md |
| **Vault-Lambda-Extension** | Node.js 20.x.x | Lambda Extension / npm package (node-vault) | HashiCorp Vault | Secure secrets management library for retrieving credentials from Vault using AWS IAM authentication (no static credentials) | Used by services requiring external API credentials; retrieves secrets from /v1/secret/data/inscore/{environment}/{service}/config | design/2. Common Library/vault-lambda-extension-tdd.md |
| **PostgreSQL-Aurora-Connection** | Node.js 20.x.x | Lambda Layer / npm package | PostgreSQL Aurora | Standardized PostgreSQL Aurora connection library with connection pooling and IAM authentication | Used by services requiring database access; provides consistent connection management patterns | design/2. Common Library/postgresql-rds-connection.md |
| **Correlation-ID-Library** | Node.js 20.x.x | Lambda Layer / npm package | CloudWatch Logs | End-to-end request tracing library using UUID v4 format in X-Correlation-ID header | Used by all services for distributed tracing; extracts or generates correlation ID and logs to CloudWatch | design/2. Common Library/correlationId-spec.md |
| **Externalizing-Env-Variables-Library** | Node.js 20.x.x | Lambda Layer / npm package | Lambda Environment | Environment variable management and configuration library | Used for consistent environment variable handling across services | design/2. Common Library/externalizing-env-variables-library-tdd.md |

#### 3.2.3 Integration Services
| Service Name | Runtime | Memory | Invocation | Integration | Description | Data Flow Responsibility |
|-------------|---------|---------|------------|-------------|-------------|-------------------------|
| **Product-Reference-Data-Service** | Node.js 20.x.x Lambda / ECS Fastify* | 2GB | Sync, Async | API Gateway | **INSCORE DEVELOPMENT: Returns static product data from Lambda layer** | Provides product hierarchy for POM structure |
| **Reference-Data-Service** | Node.js 20.x.x Lambda / ECS Fastify* | 2GB | Sync | API Gateway | **INSCORE DEVELOPMENT: Returns static reference data from Lambda layer** | Supplies reference data for dropdowns/lookups |
| **Policy-Retrieval** | Node.js 20.x.x Lambda | 2GB | Batch, Async | API Gateway, Step Function, PostgreSQL Aurora | Fetches existing policies for ENDORSEMENT/MTA with pagination | Retrieves from PostgreSQL Aurora, converts to POM JSON |

*Note: Product-Reference-Data-Service and Reference-Data-Service will initially be deployed as Lambda functions for rapid development during Inscore development. Post-development, they can be migrated to ECS containers with Fastify framework if performance requirements demand it.

### 3.3 Service Orchestration with Complete Service Architecture

#### 3.3.1 High-Level Architecture Diagram

```mermaid
flowchart TB
    %% Frontend Layer
    subgraph FRONTEND["🌐 PRESENTATION LAYER"]
        UI["<b>Angular SPA</b><br/>━━━━━━━━━━━━<br/>• Okta SSO Authentication<br/>• Dynamic Form Rendering<br/>• POM Schema Integration"]
    end

    %% API Gateway Layer
    subgraph APIGW["⚡ API GATEWAY LAYER"]
        AG["<b>AWS API Gateway</b><br/>━━━━━━━━━━━━<br/>• Request Routing<br/>• Authentication<br/>• Rate Limiting"]
    end

    %% Business Services Layer
    subgraph BUSINESS["🔧 BUSINESS SERVICES LAYER"]
        BMS["<b>Booking Management</b><br/>━━━━━━━━━━━━<br/>512MB | 16s timeout<br/>• Booking Initiation<br/>• Session Management"]
        CIS["<b>Client Individual Service</b><br/>━━━━━━━━━━━━<br/>512MB | 16s timeout<br/>• Client Search & CRUD<br/>• PostgreSQL Storage"]
        UICS["<b>UI Components Service</b><br/>━━━━━━━━━━━━<br/>768MB | 16s timeout<br/>• 7 Workflow Functions<br/>• Dynamic UI Delivery"]
    end

    %% Integration Layer
    subgraph INTEGRATION["🔗 INTEGRATION LAYER"]
        IPS["<b>Integration Proxy</b><br/>━━━━━━━━━━━━<br/>1024MB | 300s timeout<br/>• MDM Connector<br/>• Client Individual Proxy<br/>• SQS Event Source Mapping<br/>• Sync & Async Operations"]
        RDSS["<b>Reference Data Sync</b><br/>━━━━━━━━━━━━<br/>Enqueue: 256MB | 60s<br/>Worker: 1024MB | 300s | 40 concurrent<br/>• SQS-Based Parallel Processing<br/>• RDM & PostgreSQL Daily Sync"]
    end

    %% Async Queue Layer
    subgraph ASYNCQUEUE["📨 MESSAGE QUEUE LAYER"]
        SQS["<b>SQS Queues</b><br/>━━━━━━━━━━━━<br/>• int-async-queue (per country)<br/>• int-async-dlq (DLQ)"]
    end

    %% Data Layer
    subgraph DATALAYER["💾 DATA PERSISTENCE LAYER"]
        direction LR
        PGA[("<b>PostgreSQL Aurora</b>")]
        DDB[("<b>DynamoDB</b><br/>━━━━━━━━━━━━<br/>• ui-component-catalog<br/>• booking-component-status<br/>• service-function-flows<br/>• booking-reference-lookup<br/>• operation-status")]
        S3[("<b>S3 Buckets</b><br/>━━━━━━━━━━━━<br/>• POM Schemas<br/>• Policy Documents")]
    end

    %% External Systems
    subgraph EXTERNAL["🌍 EXTERNAL SYSTEMS"]
        direction LR
        VAULT["<b>HashiCorp Vault</b><br/>━━━━━━━━━━━━<br/>Secrets Management"]
        MDM["<b>MDM API</b><br/>━━━━━━━━━━━━<br/>Master Data"]
        RDM["<b>RDM API</b><br/>━━━━━━━━━━━━<br/>Reference Data"]
    end

    %% Shared Libraries
    subgraph LIBRARIES["📚 SHARED LIBRARIES LAYER"]
        LIBS["<b>7 Reusable Libraries</b><br/>━━━━━━━━━━━━━━━━━━━━<br/>Flow Engine • Validate Token • Entitlements<br/>Vault Extension • PostgreSQL Connection<br/>Correlation ID • Environment Variables"]
    end

    %% Flow Connections
    UI -->|HTTPS| AG
    AG -->|Invoke| BMS
    AG -->|Invoke| UICS
    AG -->|Invoke| IPS

    BMS -.->|Lambda Call| UICS
    IPS -.->|Lambda Call| CIS

    BMS --> PGA
    CIS --> PGA
    UICS --> DDB
    UICS --> S3

    IPS -->|Sync < 16s| MDM
    IPS -->|Async > 16s| SQS
    SQS -->|Event Source Mapping| IPS
    IPS -->|Async MDM Call| MDM

    RDSS -->|Batch Fetch| RDM
    RDSS --> DDB

    LIBS -.->|Used by all services| BUSINESS
    LIBS -.->|Used by all services| INTEGRATION

    %% Styling
    classDef frontend fill:#e3f2fd,stroke:#1565c0,stroke-width:3px,color:#000
    classDef gateway fill:#fff3e0,stroke:#e65100,stroke-width:3px,color:#000
    classDef business fill:#f3e5f5,stroke:#6a1b9a,stroke-width:2px,color:#000
    classDef integration fill:#fce4ec,stroke:#c2185b,stroke-width:2px,color:#000
    classDef asyncqueue fill:#fff3e0,stroke:#ff6f00,stroke-width:2px,color:#000
    classDef data fill:#e8f5e9,stroke:#2e7d32,stroke-width:2px,color:#000
    classDef external fill:#fff9c4,stroke:#f57f17,stroke-width:2px,color:#000
    classDef library fill:#e0f2f1,stroke:#00695c,stroke-width:2px,color:#000

    class UI frontend
    class AG gateway
    class BMS,CIS,UICS business
    class IPS,RDSS integration
    class SQS asyncqueue
    class PGA,DDB,S3 data
    class VAULT,MDM,RDM external
    class LIBS library
```

### 3.4 Enhanced Service Orchestration Components

#### 3.4.1 Business Services Layer
- **Booking Management Service**: Handles booking initiation requests with configurable function flows; creates booking sessions in PostgreSQL Aurora
- **Client Individual Service**: Manages client individual data operations including search, create, update, and retrieval with Flow Engine orchestration; stores and queries client individual data in PostgreSQL Aurora; invoked by Integration Proxy Service
- **UI Components Service**: Single service managing dynamic UI component delivery with POM schema loading from S3 and reference data loading from DynamoDB; serves 7 separate functions:
  1. Initiate Booking workflow
  2. Client Information workflow
  3. Producer Information workflow
  4. Policy Details workflow
  5. Coinsurance workflow
  6. Risk Location workflow
  7. Other workflow components

#### 3.4.2 Integration Services Layer
- **Integration Proxy Service**: Invoked by UI via API Gateway; secure proxy for MDM API calls and Client Individual Service with Flow Engine orchestration; retrieves credentials from HashiCorp Vault (no static secrets); transforms requests/responses between internal and external formats
  - **Invocation**: API Gateway (called directly by UI)
  - **Architecture Pattern**: Queue-based asynchronous processing for long-running MDM calls (> 16 seconds)
  - **SQS Integration**: Country-specific queues for regional isolation (e.g., int-async-queue-iberia-dev)
  - **MDM Integration**: Retrieves Client Organization, Producers, Coinsurers, Reinsurers, Reinsurer Brokers, Cedants
  - **Client Individual Service Integration**: Invokes Client Individual Service for client individual search, create, update, and retrieval operations
  - **Async Operations Support**:
    - Synchronous flow (< 16 seconds): Direct API Gateway → Integration Proxy Service → MDM → Response
    - Asynchronous flow (> 16 seconds): API Gateway → Integration Proxy Service (creates PENDING status in DynamoDB) → SQS Queue → Integration Proxy Service (triggered via Event Source Mapping) → MDM → DynamoDB (COMPLETED status)
    - UI Polling: Client polls operation status using requestId to retrieve final results
  - **SQS Event Source Mapping**: Integration Proxy Service Lambda is triggered by SQS queue via Event Source Mapping to process long-running MDM calls asynchronously (1024MB, 300s timeout)
  - **Dead Letter Queue**: Failed messages after 3 retry attempts stored in DLQ for manual investigation
- **Reference Data Sync Service**: SQS-based parallel processing architecture for RDM and PostgreSQL reference data synchronization:
  - **RDM Scheduled Sync**: EventBridge triggers Enqueue Lambda daily at 2 AM UTC → SQS queue → 40 concurrent Worker Lambdas
  - **PostgreSQL Scheduled Sync**: EventBridge triggers Enqueue Lambda daily (recurring scheduled sync similar to RDM)
  - **Architecture**: Enqueue Lambda reads table configs from environment variables → Creates SQS messages → Worker Lambdas process tables in parallel (~40 concurrent - TBC)
  - **Data Flow**: RDM REST API and PostgreSQL Aurora → DynamoDB booking-reference-lookup (recurring daily for both)
  - On-demand sync capability via Jenkins pipeline for both RDM and PostgreSQL

#### 3.4.3 Shared Libraries Layer (7 Libraries)
- **Flow Engine Library**: Configurable function flow execution across all services; loads flow configurations from DynamoDB service-function-flows table
- **Validate Token Library**: JWT token validation with Okta integration; extracts user information from Bearer tokens
- **Entitlements Library**: RBAC with AppId 7454; checks user roles and permissions via CheckUserRole and CheckUserPermissions; integrates with Vault for credentials; supports hierarchical organization structure (APP → COUNTRY → PRODUCT/LANGUAGE groups) with detailed entities array containing parent-child relationships via parentGroupId; includes groupType values (APP, COUNTRY, PRODUCT, LANGUAGE) and defaultFlag for language preference indication
- **Vault Lambda Extension**: Secure secrets management using HashiCorp Vault with AWS IAM authentication; no static credentials
- **PostgreSQL-Aurora-Connection**: Standardized PostgreSQL Aurora connection library with connection pooling and IAM authentication
- **Correlation-ID Library**: End-to-end request tracing using UUID v4 format in X-Correlation-ID header; logs to CloudWatch
- **Externalizing-Env-Variables-Library**: Consistent environment variable management across all services

#### 3.4.4 Service Integration Patterns
- **Booking Management Service → Libraries**: Flow Engine, Validate Token, Entitlements, PostgreSQL-Aurora-Connection, Correlation-ID
- **Client Individual Service → Libraries**: Flow Engine, Validate Token, Entitlements, PostgreSQL-Aurora-Connection, Correlation-ID
- **UI Components Service → Libraries**: Flow Engine, Validate Token, Entitlements, Vault Lambda Extension, Correlation-ID
- **Integration Proxy Service → Integration**:
  - Libraries: Flow Engine, Validate Token, Vault Lambda Extension, Correlation-ID
  - Async Pattern: SQS Queue (int-async-queue-{country}-{env}) with Event Source Mapping, DynamoDB operation-status table
  - Lambda Function: Same Integration Proxy Service Lambda handles both sync (API Gateway) and async (SQS Event Source) invocations
- **Reference Data Sync Service → Integration**: SQS (async message queue), AWS Secrets Manager (RDM credentials), PostgreSQL-Aurora-Connection (for PostgreSQL sync)

#### 3.4.5 Data Storage Patterns
- **PostgreSQL Aurora**:
  - `booking_sessions`: Booking session data (Booking Management Service)
  - `booking-ui-sessions`: UI session tracking (Booking Management Service)
  - `client_individuals`: Client individual data storage (Client Individual Service)
  - `treftab`: Reference data source for recurring scheduled sync (Reference Data Sync Service)
- **DynamoDB Tables**:
  - `ui-component-catalog`: UI component configurations (UI Components Service)
  - `booking-component-status`: Component status tracking and workflow progression (UI Components Service)
  - `service-function-flows`: Flow configurations for Flow Engine Library (All services)
  - `booking-reference-lookup`: Cached reference data from RDM and PostgreSQL (UI Components Service, Reference Data Sync Service)
  - `operation-status`: Asynchronous operation tracking for long-running tasks (> 16 seconds) across all services with TTL-based auto-cleanup (Integration Proxy Service, all domain services)
- **S3 Buckets**:
  - POM Schemas for dynamic form generation (UI Components Service)
- **External Systems**:
  - **HashiCorp Vault**: Secrets management for external API credentials (Integration Proxy Service, UI Components Service)
  - **AWS Secrets Manager**: RDM API credentials management (Reference Data Sync Service)
  - **RDM REST API**: Reference data source - daily scheduled sync (Reference Data Sync Service only)
  - **MDM External API**: Master Data Management integration for organization entities (Integration Proxy Service)
  - **SQS**: Asynchronous message queue for parallel RDM table processing (Reference Data Sync Service)

#### 3.4.6 Lambda-to-Lambda Communication Patterns
- **Booking Management Service → UI Components Service**: Synchronous invocation to initialize workflow after booking creation
- **Integration Proxy Service → Client Individual Service**: Synchronous invocation (InvocationType: RequestResponse) for client individual search, create, update, and retrieval operations

#### 3.4.7 API Gateway Invocation Patterns
- **UI → Integration Proxy Service**: Direct API Gateway calls from UI for:
  - MDM entity retrieval (Client Organization, Producers, Coinsurers, Reinsurers, Reinsurer Brokers, Cedants)
  - Client individuals operations (Integration Proxy Service invokes Client Individual Service via lambda-to-lambda)

#### 3.4.8 Event-Driven Patterns
- **EventBridge Scheduled Triggers** (CRON Batch Jobs):
  - Reference Data Sync Service: Daily schedule at 2 AM UTC (RDM and PostgreSQL sync)
    - Triggers Enqueue Lambda → SQS queue → 40 parallel Worker Lambdas
    - Syncs RDM and PostgreSQL reference data to DynamoDB booking-reference-lookup
- **Jenkins On-Demand Triggers**:
  - Reference Data Sync Service: Manual sync invocation for both RDM and PostgreSQL (on-demand)
- **SQS Queue-Based Async Patterns** (Long-Running Operations):
  - Integration Proxy Service Async Operations: For MDM calls exceeding 16 seconds
    - Pattern: API Gateway → Integration Proxy Service → SQS Queue → Integration Proxy Service (Event Source Mapping) → MDM
    - Status Tracking: DynamoDB operation-status table (PENDING → IN_PROGRESS → COMPLETED/FAILED)
    - UI Polling: Client polls status endpoint using requestId to retrieve results
    - Architecture: 1 queue per country for regional isolation (e.g., int-async-queue-iberia-dev)
    - Event Source Mapping: Same Integration Proxy Service Lambda triggered by SQS (1024MB, 300s timeout)
    - Retry Mechanism: SQS visibility timeout (360s), max 3 retry attempts, DLQ for failed messages
    - Benefits: Decouples long-running MDM operations from synchronous API Gateway constraints

Note: pol-booking-json-store is designed but NOT implemented for Inscore development

### 3.6 Data Flow Validation

**Transient Save Flow (ui-component-service → DynamoDB):**
1. ui-component-service receives stage data from UI
2. Validates against POM schema
3. Stores in booking-component-status
4. Updates booking-component-status with completion status
5. Maintains session state in ui-sessions
✅ **Achievable**: Service design supports incremental stage saves

**Permanent Save Flow (Validation → PostgreSQL Aurora):**
1. Business-Validate-Service performs final validation
2. On success, publishes event to EventBridge
3. Persistence Lambda triggered via SQS
4. Connects to PostgreSQL Aurora for data persistence
5. Transforms complete POM JSON to relational model
6. Writes to PostgreSQL tables
7. Archives complete JSON to S3
8. Status-Update-Service updates booking status to COMPLETED
✅ **Achievable**: Service architecture ensures validated data reaches PostgreSQL with optimized connection management

### 3.4 Service Dependencies Matrix

| Service | Upstream Dependencies | Downstream Dependencies | Critical for |
|---------|----------------------|------------------------|--------------|
| booking-management-service | None (Entry point) | ui-component-service | Transaction initiation |
| ui-component-service | booking-management-service | DynamoDB Streams (triggers validation) | Stage data management |
| Business-Validate-Service | DynamoDB Streams (async trigger) | Status-Update-Service, EventBridge | Async data validation |
| Status-Service | None (Read-only) | None (Query service) | Status visibility |
| Status-Update-Service | EventBridge, Business-Validate-Service | None (Terminal service) | Event-driven updates |
| Product-Reference-Data-Service | None (Master data) | ui-component-service (provides product data) | Product configuration |
| Policy-Retrieval | PostgreSQL Aurora | ui-component-service (provides existing policy) | Non-NB transactions |
| Reference-Data-Service | None (Master data) | ui-component-service (provides reference data) | Master data |

**Dependency Flow Clarification:**
- **booking-management-service** → **ui-component-service**: booking-management-service creates booking ID, then calls ui-component-service to initialize session (**INSCORE DEVELOPMENT: No Secrets Manager call**)
- **ui-component-service** → **DynamoDB**: Saves stage data immediately without validation blocking
- **DynamoDB Streams** → **Business-Validate-Service**: Async validation triggered by data changes
- **Business-Validate-Service** → **pol-booking-stage-errors**: Records validation failures for UI polling (**INSCORE DEVELOPMENT: Using embedded validation logic**)
- **Final Submit Validation**: Aggregates all stage validation statuses before allowing PostgreSQL persistence

## 4. Data Model

The application will utilize a **hybrid data storage approach** to optimize for different data access patterns and consistency requirements.

### 4.1. AWS DynamoDB (Session & Stage Management)

DynamoDB will store **transient and rapidly changing data** related to the user's current session and booking progress.

- **Purpose**: Fast read/write access for session management and tracking the current stage of a policy application.

- **Key Entities**:
    - Session: Stores user session tokens, expiration times, and potentially basic user identifiers.
    - BookingStage: Tracks the current step of a policy application for a given user, including partially captured data.

#### 4.1.1 DynamoDB Tables Overview

The application uses five primary DynamoDB tables for different purposes:

**1. UI Component Catalog Table (`ui-component-catalog`)**
- **Purpose**: Store UI component configurations organized by transaction type for dynamic Angular UI generation
- **Primary Key**: `transactionType` (PK) + `componentId` (SK)
- **Use Case**: Dynamic form generation, component-based UI rendering
- **Used By**: UI Components Service

**2. Booking Component Status Table (`booking-component-status`)**
- **Purpose**: Track status and progress of individual components within booking workflows
- **Primary Key**: `bookingId` (PK) + `componentId` (SK)
- **Use Case**: Workflow progression tracking, component state management
- **Used By**: UI Components Service

**3. Service Function Flows Table (`service-function-flows`)**
- **Purpose**: Store function flow configurations for different services and flow types
- **Primary Key**: `flowId` (PK) + `version` (SK)
- **Use Case**: Configurable function flow execution with versioning support
- **Used By**: Flow Engine Library (all business services)

**4. Booking Reference Lookup Table (`booking-reference-lookup`)**
- **Purpose**: Store cached reference data from RDM and PostgreSQL for fast lookups
- **Primary Key**: `refGroupCode` (PK) + `dataElementName` (SK)
- **Use Case**: Populate dropdowns, validate input values, reduce external API calls
- **Used By**: UI Components Service, Reference Data Sync Service

**5. Operation Status Table (`operation-status`)**
- **Purpose**: Track status and results of asynchronous long-running operations (> 16 seconds) across all services
- **Primary Key**: `requestId` (PK, UUID v4)
- **Key Design Features**:
  - **Generic Design**: Supports any operation type across all Lambda services (party search/create, document generation, rating engine calls, batch operations)
  - **TTL Auto-Cleanup**: Automatic deletion after 24 hours to minimize storage costs
  - **UI Polling Pattern**: UI polls this table via API Gateway to check operation status
  - **Not Party-Specific**: Reusable tracking mechanism for any async operation
- **Use Cases**:
  - MDM party search operations (18-25 seconds)
  - MDM party creation operations (20-30 seconds)
  - External document generation services (15-60 seconds)
  - Rating engine calculations (20-45 seconds)
  - Third-party API integrations with high latency
  - Batch processing operations
- **Key Attributes**:
  - `requestId`: Unique request identifier (UUID v4)
  - `operationType`: Type of operation (SEARCH, CREATE, UPDATE, DELETE, GENERATE, CALCULATE, BATCH)
  - `operationCategory`: Category (PARTY, DOCUMENT, RATING, POLICY, BATCH, INTEGRATION)
  - `serviceName`: Lambda service handling the operation
  - `status`: Operation status (IN_PROGRESS, COMPLETED, FAILED, TIMEOUT)
  - `progress`: Progress percentage (0-100)
  - `message`: Status message for user display
  - `requestPayload`: Original request (for retry/debugging)
  - `result`: Operation result data (populated on COMPLETED)
  - `error`: Error details (populated on FAILED/TIMEOUT)
  - `estimatedWaitTime`: Expected completion time in seconds
  - `elapsedTime`: Actual elapsed time in seconds
  - `userId`: User who initiated the operation
  - `correlationId`: Correlation ID for distributed tracing
  - `bookingId`: Associated booking ID (if applicable)
  - `createdAt`: ISO 8601 timestamp when request was initiated
  - `completedAt`: ISO 8601 timestamp when operation completed/failed
  - `ttl`: Unix epoch timestamp for DynamoDB TTL (createdAt + 24 hours)
- **Access Patterns**:
  1. Check operation status (UI polling): `GetItem` by `requestId`
  2. List operations by user: Query with GSI on `userId` (if needed)
  3. Monitor operations by service: Query with GSI on `serviceName` (if needed)
  4. Debug failed operations: Scan with filter on `status = "FAILED"` (administrative only)
- **Integration Points**:
  - **Integration Proxy Service**: Creates initial record with IN_PROGRESS status
  - **Domain Lambda Services**: Updates status to COMPLETED/FAILED after async execution
  - **UI Components**: Polls status via `GET /api/integration-proxy/operation/status/{requestId}`
  - **CloudWatch**: Metrics and alarms for monitoring async operations
- **TTL Configuration**:
  - Attribute: `ttl` (Unix epoch timestamp)
  - Expiration: 24 hours after `createdAt`
  - Calculation: `ttl = Math.floor(Date.parse(createdAt) / 1000) + 86400`
- **CloudWatch Monitoring**:
  - Monitor `FAILED` status count per service
  - Monitor `TIMEOUT` status count per service
  - Alert on high failure rates (> 5% in 5 minutes)
  - Track average `elapsedTime` per operation type
- **Used By**: Integration Proxy Service, all domain Lambda services requiring async operation tracking

**Note**: For detailed schema specifications, data models, access patterns, and GSI configurations, refer to `dynamodb-specification.md`.

### 4.2. PostgreSQL Aurora (Policy Persistence)

PostgreSQL Aurora will serve as the **source of truth for all finalized policy data**, leveraging its relational capabilities for complex data structures and ACID compliance.

- **Purpose**: Reliable, structured storage for complete policy information, supporting complex queries and reporting.

- **Key Entities (Initial Inscore Development Focus based on POM XSD/JSON)**:
    - Policy: Main policy details.
    - Client: Information about the policyholder.
    - Location: Details of insured locations.
    - Product: Product-specific attributes.
    - *Further entities from POM XSD/JSON will be integrated in subsequent phases.*

## 5. API Design (Frontend-Backend)

The Angular UI will communicate with the backend via **RESTful APIs** exposed through API Gateway.

### 5.1. API Endpoints (Updated with Initiate Booking and Client Information)

#### 5.1.1 Initiate Booking Endpoints (Booking Management Service)
- **POST /booking/initiate**: Start a new policy booking session, returning a bookingId
  - Headers: Authorization (Bearer JWT), X-Config-Key (optional)
  - Request: `{"transactionType": "NB"}`
  - Response: `{"success": true, "data": {"bookingId": "BK-2024-001234567", "transactionType": "NB", "userId": "user123", "status": "INITIATED", "createdAt": "ISO-8601"}, "timestamp": "ISO-8601"}`

#### 5.1.2 Client Information Endpoints (UI Components Service)
- **GET /ui/booking/{bookingId}/nextComponent**: Get next component based on current booking position
  - Query: `transactionType` (required)
  - Response: Component configuration with POM schema for dynamic form generation

- **PUT /ui/booking/{bookingId}/components/status**: Save component data and optionally navigate to next component
  - Request: Component data with optional `nextComponentId` for navigation
  - Response: Save confirmation with next component information

- **GET /ui/booking/{bookingId}/components**: Get component by componentId and transactionType
  - Query: `componentId`, `transactionType` (both required)
  - Response: Specific component configuration and POM schema

- **GET /ui/booking/{bookingId}/pom-schema**: Get POM schema for component
  - Query: `componentId`, `transactionType` (both required)
  - Response: Policy Object Model schema for dynamic form generation

#### 5.1.3 Integration Notes
- Both services use shared libraries (Flow Engine, Validate Token, Entitlements) for consistent behavior
- All endpoints support configurable function flows based on X-Config-Key header
- Authentication and authorization handled through shared library integration

### 5.2. Request/Response Structure

- All requests and responses will use **JSON format**.
- Standard HTTP status codes will indicate success or failure.
- Error responses will include a clear error code and message.

## 6. Backend Processing (Event-Driven)

Beyond the direct API lambdas, event-driven lambdas will handle asynchronous operations, promoting a decoupled and scalable backend.

### 6.1. Event Sources

- **DynamoDB Streams**: Changes to BookingStage items in DynamoDB can trigger lambdas to perform actions like:
    - **Data Validation**: Perform deeper, asynchronous validation of stage data.
    - **Progress Notifications**: Send notifications (e.g., email, in-app) about booking progress.

- **SQS/SNS**: For tasks that don't require immediate processing or need to be retried, messages can be sent to SQS queues or SNS topics, which then trigger lambdas.
    - **Policy Finalization**: A message to an SQS queue could trigger a lambda to move data from DynamoDB to PostgreSQL Aurora after a booking is marked complete.

## 7. Security Considerations

Security will be a paramount concern throughout the application lifecycle.

- **Authentication**: Users will authenticate to obtain a **session token**, which will be validated by API Gateway.
- **Authorization**: API Gateway will enforce **access control** based on the authenticated user's permissions.
- **Database Security**: IAM-based authentication for PostgreSQL Aurora, eliminating the need to store database credentials.
- **Data Encryption**: Data at rest (DynamoDB, PostgreSQL Aurora) and in transit (API Gateway, Lambda) will be **encrypted**.
- **Input Validation**: All API inputs will be rigorously **validated** to prevent common vulnerabilities.

## 8. Deployment Strategy

For Inscore development, a streamlined deployment process will be used.

- **Infrastructure as Code (IaC)**: AWS CloudFormation or Serverless Framework will define and deploy all AWS resources (Lambdas, API Gateway, DynamoDB, Aurora). DBs and API gateway are part of IaC, lambda are part of application CI/CD
- **CI/CD (Basic)**: A simple CI/CD pipeline will automate building, testing, and deploying the application components.

## 9. Monitoring & Logging

Observability is crucial for a serverless application.

- **AWS CloudWatch**: All Lambda logs will be sent to CloudWatch Logs. Custom metrics and alarms will be configured for critical application performance indicators.
- **Database Metrics**: Monitor database connections and query latency through CloudWatch.
- **Distributed Tracing**: AWS X-Ray will be used to trace requests across services, including database calls, aiding in debugging and performance optimization.

## 10. Future Enhancements (Beyond Initial Development)

Beyond the initial development, the Inscore application will evolve to include:

- **Comprehensive Policy Management**: Full CRUD operations for all policy elements defined in POM.
- **Advanced Workflow Engine**: Orchestration of complex, multi-step policy processing.
- **Integration with External Systems**: Third-party services for underwriting, payment processing, etc.
- **Reporting & Analytics**: Landing Page insights/Enquiry Dashboard.
- **Enhanced Security**: Okta Authentication.

## 11. Feature TDDs

This master TDD will be complemented by detailed Feature TDDss for each major component:

- **UI TDD**: Specifics of the Angular frontend design, components, state management, and interaction patterns.
- **Lambda TDDs**: Individual design documents for each Lambda function, detailing its purpose, input/output contracts, business logic, and error handling.

## 12. UI Architecture & POM Data Capture

### 12.1 Overview
The UI will implement a tab-based navigation system that mirrors the hierarchical structure of the POM (Policy Object Model) defined in pom-sub.xsd. Each level of the POM hierarchy corresponds to specific UI tabs and sections, with dynamic stage progression tracked in DynamoDB.

### 12.2 POM-to-UI Mapping

```
POM Hierarchy → UI Structure
├── L0: BookingPolicy → Main Policy Tab
│   ├── Policy Details Section
│   ├── Transaction Type Selector
│   └── Date Management Section
├── L1: Client → Client Information Tab
│   ├── Client Type Selection
│   ├── Individual/Organization Forms
│   └── Address Management
├── L1: Producer → Producer Tab
│   ├── Producer Selection
│   └── Commission Configuration
├── L2: Product → Product Configuration Tab
│   ├── Product Selection
│   └── Premium Calculation
├── L3: Location → Locations Tab
│   ├── Location List
│   └── Address Details
├── L4: Section → Sections Sub-Tab
│   └── Coverage Groups
├── L5: Risk → Risks Sub-Tab
│   └── Risk Objects
└── L6: Coverage → Coverage Sub-Tab
    └── Coverage Details
```

### 12.3 Stage Management Architecture (Based on Actual DynamoDB Design)

#### 12.3.1 DynamoDB Table Schemas

Please refer to "dynamodb-specification.md" for dynamodb schema & data details

#### 12.3.2 Stage Configuration for Transaction Types

**New Business Stages:**
```json
[
  { "stageId": 1, "stageName": "Client Info", "required": true },
  { "stageId": 2, "stageName": "Producer Info", "required": true },
  { "stageId": 3, "stageName": "Product & Policy Info", "required": true },
  { "stageId": 4, "stageName": "Location Details", "required": true },
  { "stageId": 5, "stageName": "Sections & Risks", "required": true },
  { "stageId": 6, "stageName": "Coverage Selection", "required": true },
  { "stageId": 7, "stageName": "Rating", "required": true },
  { "stageId": 8, "stageName": "Submit", "required": true }
]
```

**Endorsement Stages:**
```json
[
  { "stageId": 1, "stageName": "Policy Selection", "required": true },
  { "stageId": 2, "stageName": "Endorsement Type", "required": true },
  { "stageId": 3, "stageName": "Modification Details", "required": true },
  { "stageId": 4, "stageName": "Rating", "required": true },
  { "stageId": 5, "stageName": "Submit", "required": true }
]
```

#### 12.3.3 S3 Storage Structure
```
s3://inscore-policy-data/
├── bookings/
│   └── <pol-booking-id>/
│       ├── complete-pom.json
│       └── stages/
│           ├── stage-1-client-info.json
│           ├── stage-2-producer-info.json
│           ├── stage-3-product-policy.json
│           └── ...
├── submitted/
│   └── <policy-no>/
│       └── <pol-booking-id>/
│           └── final-policy.json
└── archives/
    └── <year>/<month>/<day>/
        └── <policy-no>-<pol-booking-id>.json
```

## 13. API Design & Data Flow Patterns

### 13.1 Core API Endpoints (Service-Based Architecture)

#### 13.1.1 booking-management-service APIs
```yaml
POST /booking/initiate:
  description: Create new booking ID and initialize transaction
  service: booking-management-service
  request:
    transaction-type: "NEW_BUSINESS|ENDORSEMENT|RENEWAL"
    user-code: string
    pol-office-cd: string
  response:
    pol-booking-id: string
    api-config: object # from Secrets Manager
    stages: array (transaction-specific stages)
```

#### 13.1.2 ui-component-service APIs
```yaml
GET /ui/booking/{bookingId}/nextComponent:
  description: Automatically retrieve the next UI component based on current workflow position
  service: ui-component-service
  parameters:
    bookingId: string (path, required)
    transactionType: string (query, required)
  headers:
    Authorization: Bearer {JWT_TOKEN}
    X-Config-Key: string (optional, defaults to "default")
  response:
    success: boolean
    data:
      bookingId: string
      componentId: string (automatically determined from currentPosition = true)
      componentConfiguration: object (componentSpecifications from ui-component-catalog)
      pomSchema: object (from S3)
        modelName: string
        version: string
        fields: object
      workflowMetadata: object
        currentStep: number
        totalSteps: number
        previousComponent: string
        nextComponent: string
        canGoBack: boolean
        canProceed: boolean
    timestamp: string

POST /ui/booking/{bookingId}/workflow/initialize:
  description: Initialize booking workflow and retrieve current component configuration
  service: ui-component-service
  parameters:
    bookingId: string (path, required)
  headers:
    Authorization: Bearer {JWT_TOKEN}
    X-Config-Key: string (optional, defaults to "default")
  request:
    transactionType: string (required)
  response:
    success: boolean
    data:
      bookingId: string
      componentConfiguration: object
        componentId: string
        formFields: array
        actionUrls: object
        layout: object
      pomSchema: object
        modelName: string
        version: string
        fields: object
      workflowMetadata: object
        currentStep: number
        totalSteps: number
        percentageComplete: number
        componentStatus: string
        allowedActions: array
    timestamp: string

PUT /ui/booking/{bookingId}/components/status:
  description: Update component status and manage workflow progression
  service: ui-component-service
  parameters:
    bookingId: string (path, required)
    componentId: string (query, required)
    nextComponentId: string (query, optional - for sidebar navigation)
  headers:
    Authorization: Bearer {JWT_TOKEN}
    X-Config-Key: string (optional, defaults to "default")
  request:
    status: string (required - "IN_PROGRESS|COMPLETED|NOT_STARTED")
    transactionType: string (required)
    componentData: object (required - POM schema conformant data)
  response:
    success: boolean
    data:
      bookingId: string
      componentId: string
      status: string
      nextComponentId: string
      updatedAt: string (ISO 8601)
      workflowProgress: object
        currentStep: number
        totalSteps: number
        percentageComplete: number
    timestamp: string

GET /ui/booking/{bookingId}/components:
  description: Retrieve specific UI component configuration by componentId and transactionType
  service: ui-component-service
  parameters:
    bookingId: string (path, required)
    componentId: string (query, required)
    transactionType: string (query, required)
  headers:
    Authorization: Bearer {JWT_TOKEN}
    X-Config-Key: string (optional, defaults to "default")
  response:
    success: boolean
    data:
      bookingId: string
      componentId: string
      componentConfiguration: object (componentSpecifications from ui-component-catalog)
      pomSchema: object
        modelName: string
        version: string
        fields: object
      workflowMetadata: object
        currentStep: number
        totalSteps: number
        percentageComplete: number
        componentStatus: string
        allowedActions: array
    timestamp: string
```

#### 13.1.3 Business-Validate-Service APIs
```yaml
POST /validate/stage:
  description: Validate stage data against business rules
  service: Business-Validate-Service #  Uses  OPA
  request:
    booking-id: string
    stage-name: string
    stage-data: object
  response:
    validation-status: "PASSED|FAILED"
    errors: array
    warnings: array

POST /validate/submit:
  description: Final validation before submission
  service: Business-Validate-Service # Uses  OPA
  request:
    booking-id: string
    complete-pom: object
  response:
    validation-status: "PASSED|FAILED"
    policy-eligible: boolean
```

#### 13.1.4 Reference Data APIs
```yaml
GET /reference/producers:
  description: Retrieve producer list for selection 
  parameters:
    searchTerm: string
    limit: number
  response:
    producers: array

GET /reference/clients/{clientNo}:
  description: Retrieve client details 
  response:
    clientData: object

GET /reference/products:
  description: Retrieve available products 
  parameters:
    transactionType: string
  response:
    products: array
```



## 14. Lambda Function Specifications (Service-Based Architecture)

### 14.1 Core Service Lambdas

#### 14.1.1 Booking Management Service Lambda (From Child TDD)
```yaml
Function: Booking-Management-Service
Runtime: Node.js 20.x.x
Memory: 512 MB
Timeout: 16 seconds
Invocation: Sync
Integration: API Gateway, Flow Engine Library
Environment:
  POSTGRESQL_HOST: PostgreSQL database host
  POSTGRESQL_PORT: PostgreSQL database port
  POSTGRESQL_DATABASE: PostgreSQL database name
  POSTGRESQL_USERNAME: PostgreSQL database username
  POSTGRESQL_PASSWORD: PostgreSQL database password
  FLOW_CONFIGURATIONS_TABLE: service-function-flows
  DYNAMODB_REGION: us-east-1
Dependencies:
  Upstream: API Gateway
  Downstream: Flow Engine Library, Validate Token Library, Entitlements Library
Responsibilities:
  - Handle booking initiation requests (POST /booking/initiate)
  - Execute configurable function flows based on X-Config-Key header
  - Generate unique booking IDs (BK-YYYY-XXXXXXXXX format)
  - Store booking sessions in PostgreSQL booking_sessions table
  - Update booking-ui-sessions table in RDS
  - Integrate JWT token validation and user permissions
  - Return booking confirmation with user and transaction details
Flow Functions:
  - extractBearerToken: Extract JWT from Authorization header
  - validateToken: Validate JWT and extract user information
  - checkUserPermissions: Verify user has booking initiation permissions
  - validateRequestParameters: Validate transactionType and other request data
  - generateBookingId: Create unique booking identifier
  - saveBookingId: Store booking session in PostgreSQL booking_sessions table
  - updateUISession: Update booking-ui-sessions table in RDS
  - formatResponse: Format success response with booking details
```

#### 14.1.2 Client Individual Service Lambda
```yaml
Function: Client-Individual-Service
Runtime: Node.js 20.x.x
Memory: 512 MB
Timeout: 16 seconds
Invocation: Sync (Lambda-to-Lambda from Integration Proxy Service)
Integration: Integration Proxy Service, PostgreSQL Aurora, Flow Engine Library
Environment:
  POSTGRESQL_HOST: PostgreSQL database host
  POSTGRESQL_PORT: PostgreSQL database port
  POSTGRESQL_DATABASE: PostgreSQL database name
  POSTGRESQL_USERNAME: PostgreSQL database username
  POSTGRESQL_PASSWORD: PostgreSQL database password
  FLOW_CONFIGURATIONS_TABLE: service-function-flows
  DYNAMODB_REGION: us-east-1
Dependencies:
  Upstream: Integration Proxy Service (Lambda-to-Lambda invocation)
  Downstream: Flow Engine Library, Validate Token Library, Entitlements Library, PostgreSQL-Aurora-Connection Library
Responsibilities:
  - Handle client individual search requests
  - Handle client individual create operations
  - Handle client individual update operations
  - Handle client individual retrieval by ID
  - Execute configurable function flows based on operation type
  - Store and query client individual data in PostgreSQL Aurora client_individuals table
  - Validate client individual data against business rules
  - Transform data between internal and external formats
Flow Functions:
  - extractBearerToken: Extract JWT from Authorization header
  - validateToken: Validate JWT and extract user information
  - checkUserPermissions: Verify user has client management permissions
  - validateRequestPayload: Validate client individual data structure
  - searchClientIndividuals: Query PostgreSQL for client individuals based on search criteria
  - createClientIndividual: Insert new client individual record in PostgreSQL
  - updateClientIndividual: Update existing client individual record in PostgreSQL
  - getClientIndividual: Retrieve client individual by ID from PostgreSQL
  - transformResponse: Transform database records to API response format
  - formatResponse: Format success response with client individual data
Document Reference:
  - design/5. Client Information/3. Lambda/client-individual-service.md
```

#### 14.1.3 UI Components Service Lambda
```yaml
Function: UI-Components-Service
Runtime: Node.js 20.x.x
Memory: 768 MB
Timeout: 16 seconds
Invocation: Sync
Integration: API Gateway, Flow Engine Library
Environment:
  COMPONENT_CATALOG_TABLE: ui-component-catalog
  BOOKING_COMPONENT_STATUS_TABLE: booking-component-status
  BOOKING_REFERENCE_LOOKUP_TABLE: booking-reference-lookup
  OPERATION_STATUS_TABLE: operation-status
  FLOW_CONFIGURATIONS_TABLE: service-function-flows
  DYNAMODB_REGION: us-east-1
  S3_POM_BUCKET: S3 bucket for POM schemas
  S3_REGION: us-east-1
  ENTITLEMENTS_API_BASE_URL: Entitlements API endpoint
  VAULT_ADDR: HashiCorp Vault address
  VAULT_ROLE: Lambda Vault role
Dependencies:
  Upstream: API Gateway
  Downstream: Flow Engine Library, Validate Token Library, Entitlements Library, Vault Library
Service Functions (7 Functional Areas):
  1. Initiate Booking: Booking initiation workflow components
  2. Client Information: Client data capture workflow components
  3. Producer Information: Producer selection workflow components
  4. Policy Details: Policy configuration workflow components
  5. Coinsurance: Coinsurance workflow components
  6. Risk Location: Risk location workflow components
  7. General Components: Common workflow components across all functions
Responsibilities:
  - Single service handling UI component requests for all booking workflow functions
  - POST /ui/booking/{bookingId}/workflow/initialize - Initialize workflow and get current component
  - GET /ui/booking/{bookingId}/nextComponent - Get next component based on currentPosition
  - PUT /ui/booking/{bookingId}/components/status - Save component data with navigation
  - GET /ui/booking/{bookingId}/components - Get specific component by componentId
  - Load reference data from DynamoDB booking-reference-lookup table (cached from RDM/PostgreSQL)
  - Execute configurable flows for different endpoints
  - Dynamic form generation using POM schemas from S3
  - Component navigation logic (Save vs Sidebar patterns)
  - Serve different functional areas based on transactionType and componentId parameters
Flow Configurations:
  - workflow-initialize: Initialize booking workflow
  - next-component-get: 8 functions including determineCurrentComponent
  - component-status-update: Save data and handle navigation
  - ui-components-get: Return component configurations for dynamic form generation
Document References:
  - design/1.Master TDD/ui-components-service.md (Master specification)
  - design/4. Initiate Booking/3. Lambda/ui-components-service.md (Initiate Booking function)
  - design/5. Client Information/3. Lambda/ui-components-service.md (Client Information function)
  - design/6. Producer Information/3 . Lambda/ui-components-service.md (Producer Information function)
  - design/Policy Details/Lambda/Policy_Details_Service_TDD_v1.5.md (Policy Details function)
  - design/10. Coinsurance/2. Lambda/ui-components-service.md (Coinsurance function)
  - design/Risk Location/Lambda/risk-location-lambda-service.md (Risk Location function)
```

#### 14.1.4 Integration Proxy Service Lambda
```yaml
Function: Integration-Proxy-Service
Runtime: Node.js 20.x.x
Memory: 1024 MB (increased for YAML config processing and SOAP/XML transformation)
Timeout: 300 seconds (5 minutes - supports both sync and async operations)
Invocation: Sync (API Gateway)
Integration: API Gateway, Vault, MDM API, Client Individual Service, SQS, DynamoDB, Flow Engine Library
Configuration Architecture:
  API Endpoints: Loaded from api-endpoints.yml configuration file via @inscore/common-lib/config
  Infrastructure: Environment variables
  Pattern: Separation of API endpoints (config file) from infrastructure variables (env vars)
Environment:
  VAULT_ADDR: HashiCorp Vault address
  VAULT_ROLE: Lambda Vault role
  FLOW_CONFIGURATIONS_TABLE: service-function-flows
  DYNAMODB_TABLE_OPERATION_STATUS: operation-status
  DYNAMODB_REGION: us-east-1
  LOG_LEVEL: INFO
  CLIENT_INDIVIDUAL_SERVICE_ARN: ARN of Client Individual Service Lambda
  ASYNC_QUEUE_URL: Country-specific SQS queue URL (e.g., int-async-queue-iberia-dev)
  ASYNC_THRESHOLD_SECONDS: 16 (threshold for async pattern)
  COUNTRY_CODE: Country code for routing (e.g., iberia)
  CONFIG_FILE_PATH: /opt/config/api-endpoints.yml (path to YAML configuration file)
API Endpoints Configuration File (api-endpoints.yml):
  entitlements_api_base_url: https://entitlement-api-v1-dev.dev.ss.hip10.npuweks.us-east-1.aws.aig.net
  entitlements_api_check_roles_path: /v2/user/groups/{appId}/roles
  entitlements_api_check_permissions_path: /v2/user/group/{groupId}/checkResourceAccess
  mdm_gateway_api_base_url: https://mdm-gateway-api-v1-dev.dev.ss.hip10.npuweks.us-east-1.aws.aig.net
  mdm_gateway_api_party_get_path: /party/get
  mdm_gateway_api_party_search_path: /party/search
  mdm_gateway_api_party_create_path: /party/create
  okta_token_introspection_url: https://aig.okta.com/oauth2/v1/introspect
  okta_jwks_uri: https://aig.okta.com/oauth2/v1/keys
  client_individual_service_url: (loaded from CLIENT_INDIVIDUAL_SERVICE_ARN env var)
  vault_secret_path: /v1/secret/data/inscore/{environment}/integration-proxy/config
Environment-Specific URLs:
  Dev: entitlement-api-v1-dev.dev.ss.hip10.npuweks.us-east-1.aws.aig.net, mdm-gateway-api-v1-dev.dev.ss.hip10.npuweks.us-east-1.aws.aig.net
  UAT: entitlement-api-v1-uat.uat.ss.hip10.npuweks.us-east-1.aws.aig.net, mdm-gateway-api-v1-uat.uat.ss.hip10.npuweks.us-east-1.aws.aig.net
  Prod: entitlement-api-v1-prod.prod.ss.hip10.npuweks.us-east-1.aws.aig.net, mdm-gateway-api-v1-prod.prod.ss.hip10.npuweks.us-east-1.aws.aig.net
Dependencies:
  Upstream: API Gateway (invoked directly by UI)
  Downstream: Vault, MDM API, Client Individual Service (Lambda-to-Lambda), SQS Queue, DynamoDB, Flow Engine Library
Responsibilities:
  - Secure proxy for MDM API calls (Client Organization, Producers, Coinsurers, Reinsurers, Reinsurer Brokers, Cedants)
  - Proxy for Client Individual Service for client individual search, create, update, and retrieval operations
  - Load API endpoints from api-endpoints.yml configuration file at runtime
  - Retrieve credentials from HashiCorp Vault for MDM (no static secrets)
  - Transform requests and responses between internal and external formats
  - Execute Flow Engine orchestration with configurable function flows
  - Determine async pattern requirement based on estimated MDM call duration
  - Create PENDING status in DynamoDB operation-status table for async operations
  - Send messages to country-specific SQS queue for long-running MDM calls (> 16 seconds)
  - Immediately respond with HTTP 202 and requestId for async operations
  - Log all external API calls and service invocations for audit trail
  - Handle authentication and authorization for external services with resource-action permission checks
  - Use hyphenated resource names for authorization (Client-Organization, Client-Individual, Producer)
MDM Entity Types Supported:
  - Client Organization
  - Producers
  - Coinsurers
  - Reinsurers
  - Reinsurer Brokers
  - Cedants
Internal Service Calls:
  - Client Individual Service: Client individual search, create, update, and retrieval operations
Async Operation Flow:
  - Synchronous (< 16s): Direct MDM call → Response
  - Asynchronous (> 16s): Create PENDING status → Send to SQS → Return requestId → Worker Lambda processes
Flow Functions:
  1. extractBearerToken: Extract JWT from Authorization header
  2. validateToken: Validate internal JWT token
  3. checkUserPermissions: Verify user has external service access permissions using resource-action pairs (e.g., Client-Organization:read, Producer:create)
  4. validateRequestPayload: Validate request structure and identify target (MDM or Client Individual Service)
  5. loadConfiguration: Load API endpoints from api-endpoints.yml configuration file via @inscore/common-lib/config loadConfigFile utility
  6. determineRequiredPermissions: Helper function to map operation type and party type to required resource-action permission pairs
  7. determineAsyncPattern: Determine if async pattern required based on estimated duration
  8. retrieveMDMCredentials: Retrieve MDM credentials from Vault (if sync call)
  9. buildMDMSOAPRequest: Build SOAP XML envelope for MDM
  10. invokeMDMAPI: Execute HTTPS request to MDM API or send to SQS for async
  11. parseAndTransformResponse: Transform external/service response to internal format
  12. formatResponse: Format final response
Party Operations Authorization Context:
  - Client Organization GET: {resource: "Client-Organization", action: "read"}
  - Client Organization POST: {resource: "Client-Organization", action: "create"}
  - Client Individual GET: {resource: "Client-Individual", action: "read"}
  - Client Individual POST: {resource: "Client-Individual", action: "create"}
  - Producer GET: {resource: "Producer", action: "read"}
  - Producer POST: {resource: "Producer", action: "create"}
Document Reference:
  - design/7. Integration/Integration-proxy-service.md
  - design/6. Producer Information/3. Lambda/integration-proxy-producer-service.md
```

#### 14.1.5 Reference Data Sync Service Lambda

**Note**: The data sync approach for the Reference Data Sync Service is currently being finalized. Detailed specifications will be provided once the architecture and implementation strategy are confirmed.

#### 14.1.6 Reference Lookup Service Lambda
```yaml
Function: Inscore-ReferenceLookup-Service
Runtime: Node.js 20.x.x
Memory: 512 MB
Timeout: 10 seconds
Invocation: Sync
Integration: API Gateway (REST API), DynamoDB, Shared Libraries (Flow Engine, Validate Token, Entitlements)
Environment:
  BOOKING_REFERENCE_LOOKUP_TABLE: booking-reference-lookup
  GSI1_INDEX_NAME: dataElementCode-dataElementName-index
  DYNAMODB_REGION: us-east-1
  ENVIRONMENT: dev|uat|prod
  ENABLE_CACHING: true
  DEFAULT_LANGUAGE_ID: 1
  DEFAULT_REF_GROUP_CODE: 000000
  LOG_LEVEL: INFO
  NODE_ENV: production
Dependencies:
  Upstream: API Gateway, Okta (JWT token validation)
  Downstream: DynamoDB (booking-reference-lookup table), CloudWatch, AWS KMS, Flow Engine Library, Validate Token Library, Entitlements Library
Responsibilities:
  - Provide centralized reference data lookup capabilities for Inscore Policy Booking application
  - Extract country code from HTTP headers (X-Country-Code) for country-specific data routing
  - Query COUNTRY-PARAMS using GSI1 to resolve refGroupCode and policyOfficeCode from country code
  - Retrieve BOTH global (refGroupCode="000000") and country-specific reference data in parallel when country code is present
  - Merge global and country-specific results with country-specific values taking precedence over global values for same dataElementCode
  - Return reference data in Axis-compatible format {id, name, isSelected} for dropdown lists and UI components
  - Automatic global fallback to refGroupCode="000000" when country code is not present in headers
  - Support multi-language reference data retrieval based on languageId header
API Endpoint:
  - GET /api/reference?elementName={element}
    Query Parameters: elementName (required)
    Headers: Authorization (required), X-Country-Code (optional), X-Language-Id (optional, default: 1)
    Response: {"elementName": [{"id": "code", "name": "description", "isSelected": false}]}
DynamoDB Access Patterns:
  - GSI1 Query (when X-Country-Code header present):
    - Index: dataElementCode-dataElementName-index
    - GSI1 PK: countryCode from X-Country-Code header
    - GSI1 SK: "COUNTRY-PARAMS"
    - Purpose: Resolve refGroupCode from country code
    - RCU: 1 per query
  - Base Table Query (with country code - batch query):
    - PK IN: ("000000", countrySpecificRefGroupCode)
    - SK begins_with: "{elementName}#{languageId}"
    - Filter: status = "ACTIVE"
    - Purpose: Retrieve both global and country-specific reference values
    - RCU: 2-4 per query (queries both global and country-specific)
  - Base Table Query (without country code - single query):
    - PK: "000000"
    - SK begins_with: "{elementName}#{languageId}"
    - Filter: status = "ACTIVE"
    - Purpose: Retrieve global reference values only
    - RCU: 1-2 per query
Performance Metrics:
  - With Country Code: 40-80ms avg latency, 3-5 RCU per request
  - Without Country Code: 20-40ms avg latency, 1-2 RCU per request
  - Cold Start Duration: 800-1200ms
  - Warm Execution Duration: 50-150ms
Key Features:
  - Single unified endpoint for all reference data lookups
  - Header-based country detection for transparent routing
  - Automatic data merging with override logic (country-specific overrides global)
  - Axis-compatible response format with isSelected field
  - Multi-layer caching strategy (client, API Gateway)
  - Exponential backoff retry logic for transient failures
  - Circuit breaker pattern for DynamoDB protection
Document Reference:
  - design/7. Integration/inscore-referencelookup-service.md
```

## 15. Data Transformation & Validation



### 15.1 Validation Rules Engine 

```yaml
# CODATHON: These rules are embedded in Business-Validate-Service
# No external OPA engine needed
ValidationRules:
  PolicyLevel:
    - Field: policyInceptDate
      Rules:
        - type: required
        - type: date_format
        - type: future_date
    - Field: insuredName
      Rules:
        - type: required
        - type: min_length
          value: 1
        - type: max_length
          value: 90
  
  ClientLevel:
    - Field: clientTypeCd
      Rules:
        - type: required
        - type: enum
          values: ["01", "02"]
    - Field: clientIndividual
      Rules:
        - type: conditional_required
          condition: clientTypeCd == "02"
  
  ProductLevel:
    - Field: premium.total
      Rules:
        - type: required
        - type: decimal
          precision: 21
          scale: 4
```

## 16. Security & Error Handling

### 16.1 API Security Layers

```mermaid
graph LR
    subgraph "Security Layers"
        CF[CloudFront WAF]
        CF --> AG[API Gateway]
        AG --> AUTH[Authorizer Lambda]
        AUTH --> VAL[Request Validation]
        VAL --> LAMBDA[Business Lambda]
        LAMBDA --> PG[PostgreSQL Aurora]
    end

    subgraph "Security Controls"
        JWT[JWT Validation]
        RBAC[Role-Based Access]
        RATE[Rate Limiting]
        IAM[IAM Database Auth]
        ENC[Encryption at Rest/Transit]
    end
```

### 16.2 Error Response Standards

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Stage validation failed",
    "details": [
      {
        "field": "client.clientNo",
        "message": "Client number is required",
        "rule": "required"
      }
    ],
    "correlationId": "uuid",
    "timestamp": "ISO-8601"
  }
}
```

## 17. Monitoring & Observability

To be determined (TBD)

## 18. Development & Testing Strategy

### 18.1 Local Development Setup

```yaml
LocalStack Services:
  - DynamoDB
  - S3
  - Lambda
  - EventBridge
  - SQS
  - SNS

SAM Local:
  - API Gateway emulation
  - Lambda function testing
  - Event generation

Docker Compose:
  - PostgreSQL Aurora
  - Redis (for caching - future)
  - LocalStack
```

### 18.2 Testing Pyramid

```
Unit Tests (70%)
├── Lambda function logic
├── Embedded validation rules (no OPA)
└── Data transformations

Integration Tests (20%)
├── API endpoint testing
├── DynamoDB operations
├── PostgreSQL Aurora connection testing (in AWS)
└── S3 interactions

E2E Tests (10%)
├── Complete booking flow
├── Event processing chains
├── Database persistence
└── Error scenarios
```

## 19. CI/CD Pipeline Integration

### 19.1 Pipeline Stages

```mermaid
graph LR
    subgraph "CI Pipeline"
        CODE[Code Commit] --> LINT[Linting]
        LINT --> UNIT[Unit Tests]
        UNIT --> BUILD[Build]
        BUILD --> PACKAGE[Package]
    end
    
    subgraph "CD Pipeline"
        PACKAGE --> DEV[Dev Deploy]
        DEV --> INTTEST[Integration Tests]
        INTTEST --> UAT[UAT Deploy]
        UAT --> SMOKE[Smoke Tests]
        SMOKE --> PROD[Prod Deploy]
    end
```

### 19.2 Infrastructure as Code

```yaml
CloudFormation/CDK Resources:
  APIs:
    - API Gateway
    - Lambda Functions
    - Lambda Layers (static data)

  Storage:
    - DynamoDB Tables
    - S3 Buckets

  Database:
    - PostgreSQL Aurora Cluster

  Events:
    - EventBridge Rules
    - SQS Queues
    - SNS Topics
    
  Monitoring:
    - CloudWatch Dashboards
    - Alarms
    - Log Groups
```

## 20. Lambda Code Generation Template

This section provides the standardized project structure, folder organization, and architectural specifications for developing AWS Lambda functions in the Inscore Policy Booking Application. This template is based on proven patterns from existing AIG projects and ensures consistency, maintainability, and scalability across all Lambda services.

### 20.1 Repository Model

**One Lambda = One Repository**

Each Lambda service is maintained in its own dedicated Git repository:

| Lambda Service | Repository Name | Primary Responsibility |
|----------------|----------------|------------------------|
| UI Components Service | `inscore-ui-component-service` | Handles UI component delivery for all booking workflows (4 endpoints) |
| Booking Management Service | `inscore-booking-management-service` | Manages booking initiation and session creation |
| Integration Proxy Service | `inscore-integration-proxy-service` | Secure proxy for MDM API calls and BMS integration |
| Reference Data Sync Service | `inscore-reference-data-sync-service` | Scheduled CRON batch job for reference data synchronization |

**Shared Common Library:** Maintained as a separate Git repository (`inscore-common-lib`) and published as a private NPM package to **JFrog Artifactory**. Each Lambda installs the common library via `npm install @inscore/common-lib`.

### 20.2 Single Lambda, Multiple Endpoints Pattern

Each Lambda function serves multiple API endpoints through a **single entry point (handler.ts)** with internal routing.

**Example: UI Components Service**

| HTTP Method | Path | Purpose |
|-------------|------|---------|
| POST | `/ui/booking/{bookingId}/workflow/initialize` | Initialize workflow and get current component |
| GET | `/ui/booking/{bookingId}/nextComponent` | Get next component based on current position |
| PUT | `/ui/booking/{bookingId}/components/status` | Save component data with navigation |
| GET | `/ui/booking/{bookingId}/components` | Get specific component by componentId |

**Architecture:** Single Lambda → Single handler.ts → Router → Controllers → Services → Data Layer

### 20.3 Lambda Repository Structure

Each Lambda repository follows this standardized folder structure:

```
[service-name]/
├── src/
│   ├── handler.ts                   # Lambda entry point (exports.handler)
│   ├── router.ts                    # HTTP method + path routing logic
│   ├── controllers/                 # Request handling and response formatting
│   │   ├── [controller-1].ts
│   │   └── [controller-2].ts
│   ├── services/                    # Business logic layer
│   │   ├── [service-1].ts
│   │   └── [service-2].ts
│   ├── validators/                  # Input validation modules
│   │   └── [validator].ts
│   ├── transformers/                # Data transformation modules
│   │   └── [transformer].ts
│   ├── types/                       # TypeScript type definitions
│   │   ├── models.ts                # Data model interfaces
│   │   ├── requests.ts              # Request type definitions
│   │   └── responses.ts             # Response type definitions
│   └── utils/                       # Service-specific utilities
│       └── [utility].ts
├── test/
│   ├── unit/                        # Unit tests
│   │   ├── handler.test.ts
│   │   ├── router.test.ts
│   │   ├── controllers/
│   │   │   └── [controller].test.ts
│   │   └── services/
│   │       └── [service].test.ts
│   └── integration/                 # Integration tests
│       └── [integration-tests].test.ts
├── resources/                       # Static resources (optional)
│   └── [templates, schemas, etc.]
├── config/                          # Configuration template
│   └── config.json                  # Template with placeholder values (not environment-specific)
├── dist/                            # TypeScript build output (gitignored)
│   └── [compiled-js-files].js
├── coverage/                        # Test coverage (gitignored)
├── node_modules/                    # NPM dependencies (gitignored)
│   └── @inscore/
│       └── common-lib/              # Installed from JFrog Artifactory
├── package.json
├── package-lock.json
├── tsconfig.json                    # TypeScript compiler configuration
├── jest.config.js                   # Jest testing configuration with ts-jest
├── .gitignore
└── README.md
```

### 20.4 Architectural Layers and Responsibilities

#### 20.4.1 Handler Layer (`handler.ts`)

**Purpose:** Single entry point for AWS Lambda function

**Responsibilities:**
- Export `handler` function as Lambda entry point
- Load configuration from S3 or local file system
- Extract HTTP method, path, headers, query parameters, path parameters, and body from API Gateway event
- Pass request details to Router layer
- Handle top-level errors and return formatted error responses
- Return standardized success/error responses to API Gateway
- Log Lambda invocation details with correlation ID

**Input:** AWS Lambda event and context objects from API Gateway
**Output:** HTTP response object (statusCode, headers, body)

#### 20.4.2 Router Layer (`router.ts`)

**Purpose:** Route incoming requests to appropriate controllers based on HTTP method and path

**Responsibilities:**
- Define routing table mapping HTTP method + path patterns to controller functions
- Match incoming request path and method against routing table
- Extract path parameters (e.g., `{bookingId}` from `/ui/booking/BK-2024-001/nextComponent`)
- Invoke matched controller function with request data
- Return 404 error for unmapped routes
- Support parameterized paths with variable extraction

**Input:** HTTP method, path, headers, query parameters, path parameters, body
**Output:** Controller function response

**Example Routing Table for UI Components Service:**

| HTTP Method | Path Pattern | Controller | Function |
|-------------|--------------|------------|----------|
| POST | `/ui/booking/:bookingId/workflow/initialize` | workflow-controller | `initializeWorkflow` |
| GET | `/ui/booking/:bookingId/nextComponent` | component-controller | `getNextComponent` |
| PUT | `/ui/booking/:bookingId/components/status` | component-controller | `saveComponentStatus` |
| GET | `/ui/booking/:bookingId/components` | component-controller | `getComponent` |

#### 20.4.3 Controller Layer (`controllers/`)

**Purpose:** Handle HTTP requests and format responses for specific endpoints

**Responsibilities:**
- Receive routed request from Router layer
- Extract and validate request parameters (path, query, body)
- Call appropriate Service layer functions
- Transform service layer responses into HTTP response format
- Handle controller-level errors
- Return structured JSON responses

**Input:** Extracted request data (bookingId, transactionType, componentId, body)
**Output:** Formatted JSON response with success/error structure

**Example Controllers for UI Components Service:**

**workflow-controller.ts**
- `initializeWorkflow(bookingId, requestBody)`: Initialize booking workflow and return first component

**component-controller.ts**
- `getNextComponent(bookingId, queryParams)`: Get next component based on current position
- `saveComponentStatus(bookingId, requestBody)`: Save component data and handle navigation
- `getComponent(bookingId, queryParams)`: Get specific component by componentId

#### 20.4.4 Service Layer (`services/`)

**Purpose:** Implement business logic, database operations, and external integrations

**Responsibilities:**
- Execute business logic and workflows
- Integrate with Flow Engine Library for configurable function execution
- Call DynamoDB operations via common/dynamo-utils
- Call PostgreSQL operations via common/postgresql-connection
- Invoke external APIs via common/api-utils
- Use common libraries (Validate Token, Entitlements, Vault, Correlation ID)
- Transform data between internal and external formats
- Implement retry logic and error handling
- Cache configuration values for performance

**Input:** Business-level parameters (bookingId, transactionType, componentData)
**Output:** Processed business data

**Example Services for UI Components Service:**

**workflow-service.ts**
- Load flow configurations from DynamoDB `service-function-flows` table
- Execute Flow Engine with configured function chain
- Query `ui-component-catalog` and `booking-component-status` tables
- Determine current workflow position
- Return workflow component configuration

**component-service.ts**
- Retrieve component configurations from `ui-component-catalog`
- Fetch component status from `booking-component-status`
- Load reference data from `booking-reference-lookup`
- Retrieve POM schemas from S3
- Save component data to DynamoDB
- Handle navigation logic (Save vs Sidebar patterns)

#### 20.4.5 Validator Layer (`validators/`)

**Purpose:** Validate input data against business rules

**Responsibilities:**
- Validate request parameters (required fields, data types, formats)
- Validate against POM schemas
- Perform business rule validation
- Return validation errors with detailed field-level messages

**Input:** Request data objects
**Output:** Validation result (valid: true/false, errors: [])

#### 20.4.6 Transformer Layer (`transformers/`)

**Purpose:** Transform data between different formats

**Responsibilities:**
- Transform API Gateway event to internal request format
- Transform service responses to API response format
- Convert between database models and business objects
- Map external API responses to internal structures

**Input:** Source data format
**Output:** Target data format

### 20.5 Common Library (NPM Package from JFrog Artifactory)

**Package Name:** `@inscore/common-lib`
**Repository:** `inscore-common-lib` (separate Git repository, published to JFrog Artifactory)
**Integration:** Installed as NPM dependency via `npm install @inscore/common-lib`

#### 20.5.1 Common Library Modules

| Module | Purpose | Used By |
|--------|---------|---------|
| **flow-engine** | Configurable function flow execution from DynamoDB configurations | All business services |
| **validate-token** | JWT token validation with Okta integration | All services requiring authentication |
| **entitlements** | RBAC with AppId 7454, checks user roles and permissions; supports hierarchical organization structure (APP → COUNTRY → PRODUCT/LANGUAGE) with parent-child relationships; retrieves complete nested entities array | All services requiring authorization |
| **vault-extension** | HashiCorp Vault integration for secrets retrieval using AWS IAM auth | Services requiring external API credentials |
| **postgresql-connection** | PostgreSQL Aurora connection with IAM authentication | Services requiring database access |
| **correlation-id** | UUID v4 generation and extraction from X-Correlation-ID header | All services for distributed tracing |
| **config** | Configuration management (S3 or local file loading) | All services |
| **logging** | Centralized logging with AWS Lambda Powertools | All services |
| **errors** | Custom error classes (ValidationError, NotFoundError, DatabaseError, etc.) | All services |
| **aws-utils** | AWS SDK utilities for Lambda invocation, S3 operations | Services requiring AWS service calls |
| **dynamo-utils** | DynamoDB CRUD operations, batch operations, query/scan | Services using DynamoDB |
| **api-utils** | HTTP request/response formatting, API call utilities | Services calling external APIs |

**Note:** Flow Engine is a submodule within the Common Library, not a separate architectural layer.

#### 20.5.2 NPM Package Configuration (JFrog Artifactory)

**NPM Registry Configuration:**

NPM registry configuration for JFrog Artifactory is managed by the DevOps pipeline. The `.npmrc` file is NOT committed to the repository and will be generated during the CI/CD build process with appropriate authentication tokens.

**Example NPM Registry Configuration (managed by DevOps):**

```ini
registry=https://your-org.jfrog.io/artifactory/api/npm/npm-inscore/
@inscore:registry=https://your-org.jfrog.io/artifactory/api/npm/npm-inscore/
//your-org.jfrog.io/artifactory/api/npm/npm-inscore/:_auth=${JFROG_AUTH_TOKEN}
//your-org.jfrog.io/artifactory/api/npm/npm-inscore/:always-auth=true
```

**Adding Common Library to Lambda Repository:**

```bash
# Add to package.json dependencies
npm install @inscore/common-lib

# package.json will contain:
# "dependencies": {
#   "@inscore/common-lib": "^1.0.0"
# }
```

**Updating Common Library:**

```bash
# Update to latest version
npm update @inscore/common-lib

# Or install specific version
npm install @inscore/common-lib@1.2.3
```

**Usage in Lambda Code:**

```javascript
// Import common library modules
const config = require('@inscore/common-lib/config');
const logger = require('@inscore/common-lib/logging');
const { validateToken } = require('@inscore/common-lib/validate-token');
const flowEngine = require('@inscore/common-lib/flow-engine');
```

### 20.6 File Responsibilities Summary

| File/Folder | Responsibility | Layer |
|-------------|----------------|-------|
| `src/handler.ts` | Lambda entry point, configuration loading, error handling | Entry Point |
| `src/router.ts` | HTTP method + path routing to controllers | Routing |
| `src/controllers/*.ts` | Request handling, parameter extraction, response formatting | Controller |
| `src/services/*.ts` | Business logic, database operations, external API calls | Service |
| `src/validators/*.ts` | Input validation against schemas and business rules | Validation |
| `src/transformers/*.ts` | Data format transformations | Transformation |
| `src/types/*.ts` | TypeScript type definitions and interfaces | Types |
| `src/utils/*.ts` | Service-specific utility functions | Utilities |
| `node_modules/@inscore/common-lib/*` | Shared library installed from JFrog Artifactory | Common |
| `test/unit/**/*.test.ts` | Unit tests with mocked dependencies | Testing |
| `test/integration/*.test.ts` | Integration tests with real/local dependencies | Testing |
| `config/config.json` | Configuration template with placeholder values | Configuration |
| `package.json` | Dependencies (including @inscore/common-lib), build scripts, metadata | Build |
| `tsconfig.json` | TypeScript compiler configuration | Build |
| `jest.config.js` | Test framework configuration with ts-jest | Testing |
| `.gitignore` | Git ignore patterns | Version Control |

### 20.7 Request Flow Example

**Example: GET /ui/booking/BK-2024-001/nextComponent?transactionType=NB**

1. **API Gateway** → Invokes Lambda with event containing HTTP method, path, headers, query parameters
2. **handler.ts** → Loads config, extracts request details, passes to router
3. **router.ts** → Matches `GET /ui/booking/:bookingId/nextComponent` → Routes to `component-controller.getNextComponent`
4. **component-controller.ts** → Extracts `bookingId` (BK-2024-001) and `transactionType` (NB), calls `component-service.getNextComponent`
5. **component-service.ts** →
   - Queries DynamoDB `booking-component-status` for current position
   - Queries DynamoDB `ui-component-catalog` for next component
   - Uses Flow Engine Library to execute workflow logic
   - Returns component configuration
6. **component-controller.ts** → Formats response as JSON
7. **router.ts** → Returns controller response
8. **handler.ts** → Returns HTTP 200 with JSON body to API Gateway

### 20.8 Package Configuration

#### 20.8.1 Lambda package.json Structure

```json
{
  "name": "[service-name]",
  "version": "1.0.0",
  "description": "Lambda function for [description]",
  "main": "dist/handler.js",
  "scripts": {
    "prebuild": "Clean dist folder",
    "build": "Compile TypeScript and bundle Lambda with esbuild, target Node.js 20, external AWS SDK",
    "pretest": "Clean coverage folder",
    "test": "Run Jest with ts-jest and coverage, minimum 80% threshold",
    "test:watch": "Run tests in watch mode",
    "lint": "Run ESLint on src files",
    "type-check": "Run TypeScript compiler for type checking"
  },
  "dependencies": {
    "@aws-sdk/client-dynamodb": "AWS SDK for DynamoDB",
    "@aws-sdk/client-lambda": "AWS SDK for Lambda invocation",
    "@aws-sdk/client-s3": "AWS SDK for S3",
    "@aws-sdk/lib-dynamodb": "DynamoDB Document Client"
  },
  "devDependencies": {
    "@types/aws-lambda": "Type definitions for AWS Lambda",
    "@types/jest": "Type definitions for Jest",
    "@types/node": "Type definitions for Node.js",
    "@typescript-eslint/eslint-plugin": "ESLint plugin for TypeScript",
    "@typescript-eslint/parser": "ESLint parser for TypeScript",
    "aws-sdk-client-mock": "Mock AWS SDK clients for testing",
    "cross-env": "Cross-platform environment variables",
    "esbuild": "JavaScript/TypeScript bundler",
    "eslint": "Linter",
    "jest": "Test framework",
    "ts-jest": "Jest transformer for TypeScript",
    "typescript": "TypeScript compiler",
    "shx": "Cross-platform shell commands"
  },
  "engines": {
    "node": ">=20.x"
  }
}
```

#### 20.8.2 Build Script Specification

**Purpose:** Compile TypeScript and bundle Lambda function into single JavaScript file for deployment

**Tool:** esbuild with TypeScript support
**Entry Point:** `src/handler.ts`
**Target:** Node.js 20.x (ES2020)
**Platform:** node
**Output:** `dist/[service-name].js`
**Externals:** AWS SDK packages (already available in Lambda runtime)
**Bundling:** All dependencies except externals
**Source Maps:** Generated for debugging
**Type Checking:** Run separately via `tsc --noEmit` before build

#### 20.8.3 Test Script Specification

**Framework:** Jest with ts-jest
**Environment:** Node.js test environment
**TypeScript Support:** ts-jest transformer for TypeScript test files
**Coverage Threshold:** 80% (branches, functions, lines, statements)
**Environment Variables:** NODE_ENV=unit-test, AWS_REGION=us-east-1
**Mock Strategy:** Mock all external dependencies (AWS SDK, databases, external APIs)

### 20.9 Jest Configuration

#### 20.9.1 Jest Configuration File Specification

**File:** `jest.config.js`

**Settings:**
- Test environment: node
- Preset: ts-jest (for TypeScript support)
- Transform: ts-jest for `.ts` files
- Module file extensions: ts, js, json
- Coverage collection: enabled
- Coverage sources: `src/**/*.ts` (exclude test files)
- Coverage directory: `<rootDir>/coverage`
- Coverage reporters: text, lcov
- Coverage thresholds: 80% for branches, functions, lines, statements
- Test roots: `<rootDir>`
- Test match patterns: `**/test/**/*.test.ts`
- TypeScript configuration: Reference `tsconfig.json`

### 20.10 Testing Strategy

#### 20.10.1 Unit Testing Specification

**Location:** `test/unit/`
**Scope:** Individual functions and modules in isolation
**Mocking:** All external dependencies mocked (AWS SDK, common libraries, databases, APIs)
**Coverage Requirement:** Minimum 80%

**Test Files:**
- `handler.test.js`: Test Lambda handler entry point
- `router.test.js`: Test routing logic
- `controllers/*.test.js`: Test controller functions
- `services/*.test.js`: Test business logic
- `validators/*.test.js`: Test validation logic
- `transformers/*.test.js`: Test data transformations

**Test Structure:**
- Arrange: Set up test data and mocks
- Act: Execute function under test
- Assert: Verify expected outcomes

#### 20.10.2 Integration Testing Specification

**Location:** `test/integration/`
**Scope:** End-to-end flows with real or local dependencies
**Dependencies:** LocalStack for AWS services, local PostgreSQL
**Purpose:** Verify integration between layers and external services

### 20.11 Configuration Management

#### 20.11.1 Configuration File Structure

**Repository Configuration File:**
- `config/config.json`: Configuration template with placeholder values (committed to repository)

**Purpose:**
- Serves as template for developers during local development
- Contains all required configuration keys with placeholder values
- Actual values are externally managed by DevOps pipelines
- Environment-specific configurations are injected during deployment

**Configuration Sections:**
- `dynamodb`: Table names, region
- `postgresql`: Host, database, port
- `vault`: Vault address, role
- `external_apis`: MDM, RDM, Entitlements API base URLs
- `processing`: Timeouts, retry counts, batch sizes
- `validation`: Business rules, thresholds
- `flow_engine`: Default flow configurations

**Example Configuration Template (config/config.json):**

```json
{
  "dynamodb": {
    "region": "us-east-1",
    "ui_component_catalog_table": "ui-component-catalog-PLACEHOLDER",
    "booking_component_status_table": "booking-component-status-PLACEHOLDER",
    "service_function_flows_table": "service-function-flows-PLACEHOLDER",
    "booking_reference_lookup_table": "booking-reference-lookup-PLACEHOLDER",
    "operation_status_table": "operation-status-PLACEHOLDER"
  },
  "postgresql": {
    "host": "PLACEHOLDER-aurora-cluster.us-east-1.rds.amazonaws.com",
    "database": "inscore",
    "port": 5432
  },
  "vault": {
    "address": "https://vault.aig.com",
    "role": "PLACEHOLDER-lambda-role"
  },
  "external_apis": {
    "mdm_base_url": "https://mdm-api.aig.com",
    "rdm_base_url": "https://rdm-api.aig.com",
    "entitlements_base_url": "https://entitlements-api.aig.com"
  },
  "processing": {
    "max_retries": 3,
    "timeout_ms": 30000,
    "batch_size": 25
  },
  "validation": {
    "enable_strict_validation": true
  },
  "flow_engine": {
    "enable_caching": true,
    "cache_ttl_seconds": 300
  }
}
```

#### 20.11.2 Configuration Loading Strategy

**Local/Test Environments:**
- Load from local `config/config.json` file (developers use template with placeholder values)
- Triggered by NODE_ENV=local or NODE_ENV=unit-test
- Developers replace PLACEHOLDER values with local/test environment values

**AWS Environments (Dev/UAT/Prod):**
- Load from S3 bucket (environment-specific buckets)
- Bucket name from environment variable: `S3_CONFIG_BUCKET_NAME`
- Object key from environment variable: `S3_CONFIG_OBJECT_KEY` (always `config.json`)
- DevOps pipeline injects environment-specific configuration to S3 during deployment

**S3 Configuration Pattern:**
- Dev: `s3://inscore-config-dev/config.json`
- UAT: `s3://inscore-config-uat/config.json`
- Prod: `s3://inscore-config-prod/config.json`

**Configuration Injection Process:**
1. DevOps pipeline stores actual configuration values in pipeline variables/secrets
2. During deployment, pipeline generates environment-specific `config.json` from variables
3. Pipeline uploads `config.json` to environment-specific S3 bucket
4. Lambda loads configuration from S3 at runtime

**Benefits:**
- No sensitive values committed to repository
- Single source of truth for configuration (DevOps pipeline)
- Environment-specific values managed centrally
- Consistent configuration structure across environments

**Note:** Environment-specific values (table names, endpoints, ports, etc.) should be configured in `config.json` and managed by DevOps pipeline, not as separate environment variables.

### 20.12 Naming Conventions

#### 20.12.1 Repository Naming
- Pattern: `inscore-[service-name]`
- Example: `inscore-ui-component-service`, `inscore-booking-management-service`
- Format: kebab-case

#### 20.12.2 File Naming
- Pattern: `[module-name].js`
- Example: `workflow-controller.js`, `component-service.js`
- Format: kebab-case

#### 20.12.3 Function Naming
- Pattern: `camelCase`
- Example: `getNextComponent()`, `saveComponentStatus()`, `initializeWorkflow()`

#### 20.12.4 Class Naming
- Pattern: `PascalCase`
- Example: `ValidationError`, `DatabaseError`, `NotFoundError`

#### 20.12.5 Constants Naming
- Pattern: `UPPER_SNAKE_CASE`
- Example: `MAX_RETRY_COUNT`, `DEFAULT_TIMEOUT`, `TABLE_NAME`

#### 20.12.6 DynamoDB Table Naming
- Pattern: `[table-name]-[environment]`
- Example: `ui-component-catalog-dev`, `booking-component-status-prod`
- Format: kebab-case

### 20.13 Git Ignore Pattern

**File:** `.gitignore`

**Patterns:**
- `node_modules/`: All npm dependencies
- `dist/`: Build output folder
- `coverage/`: Test coverage reports
- `*.log`: Log files
- `.env`, `.env.local`: Environment files
- `.vscode/`, `.idea/`: IDE configuration
- `.DS_Store`, `Thumbs.db`: OS files

### 20.14 Code Organization Best Practices

#### 20.14.1 Separation of Concerns
- Handler handles Lambda lifecycle
- Router handles request routing
- Controllers handle HTTP request/response
- Services handle business logic
- Validators handle input validation
- Transformers handle data format conversion

#### 20.14.2 Single Responsibility Principle
- Each file has one clear purpose
- Each function performs one operation
- Each class represents one concept

#### 20.14.3 DRY Principle
- Common functionality in common library (NPM package from JFrog Artifactory)
- Service-specific utilities in `utils/` folder
- Avoid code duplication across layers

#### 20.14.4 Error Handling
- Use try-catch blocks at handler level
- Use custom error classes from common/errors
- Return meaningful error messages with error codes
- Log all errors with correlation ID

#### 20.14.5 Logging
- Log Lambda invocation with correlation ID
- Log all service operations with context
- Log external API calls and responses
- Use structured logging with Lambda Powertools

### 20.15 Security Guidelines

#### 20.15.1 Secrets Management
- **Never hardcode secrets** in code or configuration files
- Use HashiCorp Vault for external API credentials
- Use AWS IAM authentication for database connections
- Use environment variables for non-sensitive configuration

#### 20.15.2 Input Validation
- Validate all request parameters before processing
- Use POM schemas for data validation
- Sanitize inputs to prevent injection attacks
- Return detailed validation errors to clients

#### 20.15.3 IAM Roles
- Use IAM roles for Lambda execution
- Grant least privilege permissions
- Use IAM authentication for PostgreSQL
- Use IAM authentication for Vault

#### 20.15.4 Encryption
- Encrypt sensitive data at rest in DynamoDB and PostgreSQL
- Use HTTPS for all external API calls
- Encrypt data in transit between services

### 20.16 Deployment Artifacts

#### 20.16.1 Build Output Specification

**Artifact:** `dist/[service-name].js`
**Format:** Single bundled JavaScript file
**Size Limit:** < 50MB (uncompressed)
**Bundling:** All dependencies except AWS SDK
**Minification:** Not required (Lambda runtime is internal)
**Source Maps:** Optional for debugging

#### 20.16.2 Lambda Configuration Requirements

**Runtime:** Node.js 20.x
**Handler:** `dist/[service-name].handler`
**Memory:** As specified in Section 14 (512MB, 768MB, 1024MB depending on service)
**Timeout:** 16 seconds (except Reference Data Sync: 300 seconds)
**Configuration:** Loaded from S3 bucket via `config.json` (managed by DevOps pipeline)

### 20.17 CI/CD Pipeline Integration

#### 20.17.1 Build Stage Specification

**Steps:**
1. Generate `.npmrc` for JFrog Artifactory authentication (managed by DevOps pipeline)
2. Install dependencies: `npm install` (includes `@inscore/common-lib` from JFrog)
3. Build Lambda artifact: `npm run build`
4. Verify dist/ folder contains bundled JavaScript

**Output:** `dist/[service-name].js`

#### 20.17.2 Test Stage Specification

**Steps:**
1. Run unit tests: `npm test`
2. Generate coverage report
3. Verify minimum 80% coverage threshold
4. Upload coverage reports to code quality tools

**Exit Criteria:** All tests pass and coverage >= 80%

#### 20.17.3 Deploy Stage Specification

**Steps:**
1. Generate environment-specific `config.json` from pipeline variables/secrets
2. Upload `config.json` to environment-specific S3 bucket (`s3://inscore-config-{env}/config.json`)
3. Package Lambda artifact as zip file (includes common library from JFrog Artifactory)
4. Deploy to AWS Lambda using CloudFormation/CDK/Terraform
5. Update Lambda configuration (environment variables, memory, timeout)
6. Run smoke tests against deployed Lambda

**Configuration Injection Details:**
- Pipeline stores actual configuration values (table names, endpoints, etc.) in pipeline variables/secrets
- Pipeline generates complete `config.json` with actual values (no placeholders)
- Configuration uploaded to S3 before Lambda deployment
- Lambda loads configuration from S3 at runtime

**Environments:** dev → uat → prod (with approvals)

### 20.18 Summary

This Lambda Code Generation Template provides comprehensive specifications for:

✅ **Repository Model:** One Lambda = One Repository (not monorepo)
✅ **Request Handling:** Single handler.js with router for multiple endpoints
✅ **Architectural Layers:** Handler → Router → Controller → Service → Data Layer
✅ **File Organization:** Standardized folder structure across all Lambda services
✅ **Common Library:** NPM package published to JFrog Artifactory (`@inscore/common-lib`)
✅ **Configuration:** DevOps-managed configuration injected to S3, single config.json template in repository
✅ **Testing:** Jest framework with 80% coverage requirement
✅ **Environment Variables:** Standard variables for all Lambda functions
✅ **Naming Conventions:** Consistent naming across files, functions, and resources
✅ **Security:** Vault for secrets, IAM for authentication, input validation
✅ **CI/CD Integration:** Build, test, and deploy pipeline specifications with configuration injection

**Next Steps:** UI and API Gateway templates will be added in subsequent sections as per your requirement.

---

**Note:** This template contains specifications only without implementation code. Development teams should refer to the reference implementation at `C:\S3 Migration\Reference\dtp-quote-7417` for code examples while following these specifications<parameter name="new_string">### 20.4 Architectural Layers and Responsibilities

#### 20.4.1 Handler Layer (`handler.ts`)

**Purpose:** Single entry point for AWS Lambda function

**Responsibilities:**
- Export `handler` function as Lambda entry point
- Load configuration from S3 or local file system
- Extract HTTP method, path, headers, query parameters, path parameters, and body from API Gateway event
- Pass request details to Router layer
- Handle top-level errors and return formatted error responses
- Return standardized success/error responses to API Gateway
- Log Lambda invocation details with correlation ID

**Input:** AWS Lambda event and context objects from API Gateway
**Output:** HTTP response object (statusCode, headers, body)

#### 20.4.2 Router Layer (`router.ts`)

**Purpose:** Route incoming requests to appropriate controllers based on HTTP method and path

**Responsibilities:**
- Define routing table mapping HTTP method + path patterns to controller functions
- Match incoming request path and method against routing table
- Extract path parameters (e.g., `{bookingId}` from `/ui/booking/BK-2024-001/nextComponent`)
- Invoke matched controller function with request data
- Return 404 error for unmapped routes
- Support parameterized paths with variable extraction

**Input:** HTTP method, path, headers, query parameters, path parameters, body
**Output:** Controller function response

**Example Routing Table for UI Components Service:**

| HTTP Method | Path Pattern | Controller | Function |
|-------------|--------------|------------|----------|
| POST | `/ui/booking/:bookingId/workflow/initialize` | workflow-controller | `initializeWorkflow` |
| GET | `/ui/booking/:bookingId/nextComponent` | component-controller | `getNextComponent` |
| PUT | `/ui/booking/:bookingId/components/status` | component-controller | `saveComponentStatus` |
| GET | `/ui/booking/:bookingId/components` | component-controller | `getComponent` |

#### 20.4.3 Controller Layer (`controllers/`)

**Purpose:** Handle HTTP requests and format responses for specific endpoints

**Responsibilities:**
- Receive routed request from Router layer
- Extract and validate request parameters (path, query, body)
- Call appropriate Service layer functions
- Transform service layer responses into HTTP response format
- Handle controller-level errors
- Return structured JSON responses

**Input:** Extracted request data (bookingId, transactionType, componentId, body)
**Output:** Formatted JSON response with success/error structure

**Example Controllers for UI Components Service:**

**workflow-controller.ts**
- `initializeWorkflow(bookingId, requestBody)`: Initialize booking workflow and return first component

**component-controller.ts**
- `getNextComponent(bookingId, queryParams)`: Get next component based on current position
- `saveComponentStatus(bookingId, requestBody)`: Save component data and handle navigation
- `getComponent(bookingId, queryParams)`: Get specific component by componentId

#### 20.4.4 Service Layer (`services/`)

**Purpose:** Implement business logic, database operations, and external integrations

**Responsibilities:**
- Execute business logic and workflows
- Integrate with Flow Engine Library for configurable function execution
- Call DynamoDB operations via common/dynamo-utils
- Call PostgreSQL operations via common/postgresql-connection
- Invoke external APIs via common/api-utils
- Use common libraries (Validate Token, Entitlements, Vault, Correlation ID)
- Transform data between internal and external formats
- Implement retry logic and error handling
- Cache configuration values for performance

**Input:** Business-level parameters (bookingId, transactionType, componentData)
**Output:** Processed business data

**Example Services for UI Components Service:**

**workflow-service.ts**
- Load flow configurations from DynamoDB `service-function-flows` table
- Execute Flow Engine with configured function chain
- Query `ui-component-catalog` and `booking-component-status` tables
- Determine current workflow position
- Return workflow component configuration

**component-service.ts**
- Retrieve component configurations from `ui-component-catalog`
- Fetch component status from `booking-component-status`
- Load reference data from `booking-reference-lookup`
- Retrieve POM schemas from S3
- Save component data to DynamoDB
- Handle navigation logic (Save vs Sidebar patterns)

#### 20.4.5 Validator Layer (`validators/`)

**Purpose:** Validate input data against business rules

**Responsibilities:**
- Validate request parameters (required fields, data types, formats)
- Validate against POM schemas
- Perform business rule validation
- Return validation errors with detailed field-level messages

**Input:** Request data objects
**Output:** Validation result (valid: true/false, errors: [])

#### 20.4.6 Transformer Layer (`transformers/`)

**Purpose:** Transform data between different formats

**Responsibilities:**
- Transform API Gateway event to internal request format
- Transform service responses to API response format
- Convert between database models and business objects
- Map external API responses to internal structures

**Input:** Source data format
**Output:** Target data format

### 20.5 Common Library (NPM Package from JFrog Artifactory)

**Package Name:** `@inscore/common-lib`
**Repository:** `inscore-common-lib` (separate Git repository, published to JFrog Artifactory)
**Integration:** Installed as NPM dependency via `npm install @inscore/common-lib`

#### 20.5.1 Common Library Modules

| Module | Purpose | Used By |
|--------|---------|---------|
| **flow-engine** | Configurable function flow execution from DynamoDB configurations | All business services |
| **validate-token** | JWT token validation with Okta integration | All services requiring authentication |
| **entitlements** | RBAC with AppId 7454, checks user roles and permissions; supports hierarchical organization structure (APP → COUNTRY → PRODUCT/LANGUAGE) with parent-child relationships; retrieves complete nested entities array | All services requiring authorization |
| **vault-extension** | HashiCorp Vault integration for secrets retrieval using AWS IAM auth | Services requiring external API credentials |
| **postgresql-connection** | PostgreSQL Aurora connection with IAM authentication | Services requiring database access |
| **correlation-id** | UUID v4 generation and extraction from X-Correlation-ID header | All services for distributed tracing |
| **config** | Configuration management (S3 or local file loading) | All services |
| **logging** | Centralized logging with AWS Lambda Powertools | All services |
| **errors** | Custom error classes (ValidationError, NotFoundError, DatabaseError, etc.) | All services |
| **aws-utils** | AWS SDK utilities for Lambda invocation, S3 operations | Services requiring AWS service calls |
| **dynamo-utils** | DynamoDB CRUD operations, batch operations, query/scan | Services using DynamoDB |
| **api-utils** | HTTP request/response formatting, API call utilities | Services calling external APIs |

**Note:** Flow Engine is a submodule within the Common Library, not a separate architectural layer.

#### 20.5.2 NPM Package Configuration (JFrog Artifactory)

**NPM Registry Configuration:**

NPM registry configuration for JFrog Artifactory is managed by the DevOps pipeline. The `.npmrc` file is NOT committed to the repository and will be generated during the CI/CD build process with appropriate authentication tokens.

**Example NPM Registry Configuration (managed by DevOps):**

```ini
registry=https://your-org.jfrog.io/artifactory/api/npm/npm-inscore/
@inscore:registry=https://your-org.jfrog.io/artifactory/api/npm/npm-inscore/
//your-org.jfrog.io/artifactory/api/npm/npm-inscore/:_auth=${JFROG_AUTH_TOKEN}
//your-org.jfrog.io/artifactory/api/npm/npm-inscore/:always-auth=true
```

**Adding Common Library to Lambda Repository:**

```bash
# Add to package.json dependencies
npm install @inscore/common-lib

# package.json will contain:
# "dependencies": {
#   "@inscore/common-lib": "^1.0.0"
# }
```

**Updating Common Library:**

```bash
# Update to latest version
npm update @inscore/common-lib

# Or install specific version
npm install @inscore/common-lib@1.2.3
```

**Usage in Lambda Code:**

```javascript
// Import common library modules
const config = require('@inscore/common-lib/config');
const logger = require('@inscore/common-lib/logging');
const { validateToken } = require('@inscore/common-lib/validate-token');
const flowEngine = require('@inscore/common-lib/flow-engine');
```

### 20.6 File Responsibilities Summary

| File/Folder | Responsibility | Layer |
|-------------|----------------|-------|
| `src/handler.ts` | Lambda entry point, configuration loading, error handling | Entry Point |
| `src/router.ts` | HTTP method + path routing to controllers | Routing |
| `src/controllers/*.ts` | Request handling, parameter extraction, response formatting | Controller |
| `src/services/*.ts` | Business logic, database operations, external API calls | Service |
| `src/validators/*.ts` | Input validation against schemas and business rules | Validation |
| `src/transformers/*.ts` | Data format transformations | Transformation |
| `src/types/*.ts` | TypeScript type definitions and interfaces | Types |
| `src/utils/*.ts` | Service-specific utility functions | Utilities |
| `node_modules/@inscore/common-lib/*` | Shared library installed from JFrog Artifactory | Common |
| `test/unit/**/*.test.ts` | Unit tests with mocked dependencies | Testing |
| `test/integration/*.test.ts` | Integration tests with real/local dependencies | Testing |
| `config/config.json` | Configuration template with placeholder values | Configuration |
| `package.json` | Dependencies (including @inscore/common-lib), build scripts, metadata | Build |
| `tsconfig.json` | TypeScript compiler configuration | Build |
| `jest.config.js` | Test framework configuration with ts-jest | Testing |
| `.gitignore` | Git ignore patterns | Version Control |

### 20.7 Request Flow Example

**Example: GET /ui/booking/BK-2024-001/nextComponent?transactionType=NB**

1. **API Gateway** → Invokes Lambda with event containing HTTP method, path, headers, query parameters
2. **handler.ts** → Loads config, extracts request details, passes to router
3. **router.ts** → Matches `GET /ui/booking/:bookingId/nextComponent` → Routes to `component-controller.getNextComponent`
4. **component-controller.ts** → Extracts `bookingId` (BK-2024-001) and `transactionType` (NB), calls `component-service.getNextComponent`
5. **component-service.ts** →
   - Queries DynamoDB `booking-component-status` for current position
   - Queries DynamoDB `ui-component-catalog` for next component
   - Uses Flow Engine Library to execute workflow logic
   - Returns component configuration
6. **component-controller.ts** → Formats response as JSON
7. **router.ts** → Returns controller response
8. **handler.ts** → Returns HTTP 200 with JSON body to API Gateway

### 20.8 Package Configuration Specification

#### 20.8.1 Lambda package.json Structure

**Required Fields:**
- `name`: Service name (kebab-case)
- `version`: Semantic version
- `description`: Service description
- `main`: Entry point (`src/handler.js`)
- `scripts`: Build, test, lint commands
- `dependencies`: Runtime dependencies (AWS SDK, axios, pg, uuid)
- `devDependencies`: Build and test tools (esbuild, jest, eslint)
- `engines`: Node.js version requirement (>=20.x)

#### 20.8.2 Build Script Specification

**Purpose:** Compile TypeScript and bundle Lambda function into single JavaScript file for deployment

**Tool:** esbuild with TypeScript support
**Entry Point:** `src/handler.ts`
**Target:** Node.js 20.x (ES2020)
**Platform:** node
**Output:** `dist/[service-name].js`
**Externals:** AWS SDK packages (already available in Lambda runtime)
**Bundling:** All dependencies except externals
**Source Maps:** Generated for debugging
**Type Checking:** Run separately via `tsc --noEmit` before build

#### 20.8.3 Test Script Specification

**Framework:** Jest with ts-jest
**Environment:** Node.js test environment
**TypeScript Support:** ts-jest transformer for TypeScript test files
**Coverage Threshold:** 80% (branches, functions, lines, statements)
**Environment Variables:** NODE_ENV=unit-test, AWS_REGION=us-east-1
**Mock Strategy:** Mock all external dependencies (AWS SDK, databases, external APIs)

### 20.9 Jest Configuration Specification

**File:** `jest.config.js`

**Required Settings:**
- Test environment: node
- Coverage collection: enabled
- Coverage sources: `src/**/*.js` (exclude test files)
- Coverage directory: `<rootDir>/coverage`
- Coverage reporters: text, lcov
- Coverage thresholds: 80% for branches, functions, lines, statements
- Test roots: `<rootDir>`
- Test match patterns: `**/test/**/*.test.js`

### 20.10 Testing Strategy Specification

#### 20.10.1 Unit Testing

**Location:** `test/unit/`
**Scope:** Individual functions and modules in isolation
**Mocking:** All external dependencies mocked (AWS SDK, common libraries, databases, APIs)
**Coverage Requirement:** Minimum 80%

**Test Files:**
- `handler.test.js`: Test Lambda handler entry point
- `router.test.js`: Test routing logic
- `controllers/*.test.js`: Test controller functions
- `services/*.test.js`: Test business logic
- `validators/*.test.js`: Test validation logic
- `transformers/*.test.js`: Test data transformations

**Test Structure:**
- Arrange: Set up test data and mocks
- Act: Execute function under test
- Assert: Verify expected outcomes

#### 20.10.2 Integration Testing

**Location:** `test/integration/`
**Scope:** End-to-end flows with real or local dependencies
**Dependencies:** LocalStack for AWS services, local PostgreSQL
**Purpose:** Verify integration between layers and external services

### 20.11 Configuration Management Specification

#### 20.11.1 Configuration File Structure

**Repository Configuration File:**
- `config/config.json`: Configuration template with placeholder values (committed to repository)

**Purpose:**
- Serves as template for developers during local development
- Contains all required configuration keys with placeholder values
- Actual values are externally managed by DevOps pipelines
- Environment-specific configurations are injected during deployment

**Configuration Sections:**
- `dynamodb`: Table names, region
- `postgresql`: Host, database, port
- `vault`: Vault address, role
- `external_apis`: MDM, RDM, Entitlements API base URLs
- `processing`: Timeouts, retry counts, batch sizes
- `validation`: Business rules, thresholds
- `flow_engine`: Default flow configurations

**Example Configuration Template (config/config.json):**

```json
{
  "dynamodb": {
    "region": "us-east-1",
    "ui_component_catalog_table": "ui-component-catalog-PLACEHOLDER",
    "booking_component_status_table": "booking-component-status-PLACEHOLDER",
    "service_function_flows_table": "service-function-flows-PLACEHOLDER",
    "booking_reference_lookup_table": "booking-reference-lookup-PLACEHOLDER",
    "operation_status_table": "operation-status-PLACEHOLDER"
  },
  "postgresql": {
    "host": "PLACEHOLDER-aurora-cluster.us-east-1.rds.amazonaws.com",
    "database": "inscore",
    "port": 5432
  },
  "vault": {
    "address": "https://vault.aig.com",
    "role": "PLACEHOLDER-lambda-role"
  },
  "external_apis": {
    "mdm_base_url": "https://mdm-api.aig.com",
    "rdm_base_url": "https://rdm-api.aig.com",
    "entitlements_base_url": "https://entitlements-api.aig.com"
  },
  "processing": {
    "max_retries": 3,
    "timeout_ms": 30000,
    "batch_size": 25
  },
  "validation": {
    "enable_strict_validation": true
  },
  "flow_engine": {
    "enable_caching": true,
    "cache_ttl_seconds": 300
  }
}
```

#### 20.11.2 Configuration Loading Strategy

**Local/Test Environments:**
- Load from local `config/config.json` file (developers use template with placeholder values)
- Triggered by NODE_ENV=local or NODE_ENV=unit-test
- Developers replace PLACEHOLDER values with local/test environment values

**AWS Environments (Dev/UAT/Prod):**
- Load from S3 bucket (environment-specific buckets)
- Bucket name from environment variable: `S3_CONFIG_BUCKET_NAME`
- Object key from environment variable: `S3_CONFIG_OBJECT_KEY` (always `config.json`)
- DevOps pipeline injects environment-specific configuration to S3 during deployment

**S3 Configuration Pattern:**
- Dev: `s3://inscore-config-dev/config.json`
- UAT: `s3://inscore-config-uat/config.json`
- Prod: `s3://inscore-config-prod/config.json`

**Configuration Injection Process:**
1. DevOps pipeline stores actual configuration values in pipeline variables/secrets
2. During deployment, pipeline generates environment-specific `config.json` from variables
3. Pipeline uploads `config.json` to environment-specific S3 bucket
4. Lambda loads configuration from S3 at runtime

**Benefits:**
- No sensitive values committed to repository
- Single source of truth for configuration (DevOps pipeline)
- Environment-specific values managed centrally
- Consistent configuration structure across environments

**Note:** Environment-specific values (table names, endpoints, ports, etc.) should be configured in `config.json` and managed by DevOps pipeline, not as separate environment variables.

### 20.12 Naming Conventions

#### 20.12.1 Repository Naming
- Pattern: `inscore-[service-name]`
- Example: `inscore-ui-component-service`, `inscore-booking-management-service`
- Format: kebab-case

#### 20.12.2 File Naming
- Pattern: `[module-name].js`
- Example: `workflow-controller.js`, `component-service.js`
- Format: kebab-case

#### 20.12.3 Function Naming
- Pattern: `camelCase`
- Example: `getNextComponent()`, `saveComponentStatus()`, `initializeWorkflow()`

#### 20.12.4 Class Naming
- Pattern: `PascalCase`
- Example: `ValidationError`, `DatabaseError`, `NotFoundError`

#### 20.12.5 Constants Naming
- Pattern: `UPPER_SNAKE_CASE`
- Example: `MAX_RETRY_COUNT`, `DEFAULT_TIMEOUT`, `TABLE_NAME`

#### 20.12.6 DynamoDB Table Naming
- Pattern: `[table-name]-[environment]`
- Example: `ui-component-catalog-dev`, `booking-component-status-prod`
- Format: kebab-case

### 20.13 Git Ignore Pattern

**File:** `.gitignore`

**Required Patterns:**
- `node_modules/`: All npm dependencies
- `dist/`: Build output folder
- `coverage/`: Test coverage reports
- `*.log`: Log files
- `.env`, `.env.local`: Environment files
- `.vscode/`, `.idea/`: IDE configuration
- `.DS_Store`, `Thumbs.db`: OS files

### 20.14 Code Organization Best Practices

#### 20.14.1 Separation of Concerns
- Handler handles Lambda lifecycle
- Router handles request routing
- Controllers handle HTTP request/response
- Services handle business logic
- Validators handle input validation
- Transformers handle data format conversion

#### 20.14.2 Single Responsibility Principle
- Each file has one clear purpose
- Each function performs one operation
- Each class represents one concept

#### 20.14.3 DRY Principle
- Common functionality in common library (NPM package from JFrog Artifactory)
- Service-specific utilities in `utils/` folder
- Avoid code duplication across layers

#### 20.14.4 Error Handling
- Use try-catch blocks at handler level
- Use custom error classes from common/errors
- Return meaningful error messages with error codes
- Log all errors with correlation ID

#### 20.14.5 Logging
- Log Lambda invocation with correlation ID
- Log all service operations with context
- Log external API calls and responses
- Use structured logging with Lambda Powertools

### 20.15 Security Guidelines

#### 20.15.1 Secrets Management
- **Never hardcode secrets** in code or configuration files
- Use HashiCorp Vault for external API credentials
- Use AWS IAM authentication for database connections
- Use environment variables for non-sensitive configuration

#### 20.15.2 Input Validation
- Validate all request parameters before processing
- Use POM schemas for data validation
- Sanitize inputs to prevent injection attacks
- Return detailed validation errors to clients

#### 20.15.3 IAM Roles
- Use IAM roles for Lambda execution
- Grant least privilege permissions
- Use IAM authentication for PostgreSQL
- Use IAM authentication for Vault

#### 20.15.4 Encryption
- Encrypt sensitive data at rest in DynamoDB and PostgreSQL
- Use HTTPS for all external API calls
- Encrypt data in transit between services

### 20.16 Deployment Artifacts Specification

#### 20.16.1 Build Output

**Artifact:** `dist/[service-name].js`
**Format:** Single bundled JavaScript file
**Size Limit:** < 50MB (uncompressed)
**Bundling:** All dependencies except AWS SDK
**Minification:** Not required (Lambda runtime is internal)
**Source Maps:** Optional for debugging

#### 20.16.2 Lambda Configuration Requirements

**Runtime:** Node.js 20.x
**Handler:** `dist/[service-name].handler`
**Memory:** As specified in Section 14 (512MB, 768MB, 1024MB depending on service)
**Timeout:** 16 seconds (except Reference Data Sync: 300 seconds)
**Configuration:** Loaded from S3 bucket via `config.json` (managed by DevOps pipeline)

### 20.17 CI/CD Pipeline Integration Specification

#### 20.17.1 Build Stage

**Steps:**
1. Generate `.npmrc` for JFrog Artifactory authentication (managed by DevOps pipeline)
2. Install dependencies: `npm install` (includes `@inscore/common-lib` from JFrog)
3. Build Lambda artifact: `npm run build`
4. Verify dist/ folder contains bundled JavaScript

**Output:** `dist/[service-name].js`

#### 20.17.2 Test Stage

**Steps:**
1. Run unit tests: `npm test`
2. Generate coverage report
3. Verify minimum 80% coverage threshold
4. Upload coverage reports to code quality tools

**Exit Criteria:** All tests pass and coverage >= 80%

#### 20.17.3 Deploy Stage

**Steps:**
1. Generate environment-specific `config.json` from pipeline variables/secrets
2. Upload `config.json` to environment-specific S3 bucket (`s3://inscore-config-{env}/config.json`)
3. Package Lambda artifact as zip file (includes common library from JFrog Artifactory)
4. Deploy to AWS Lambda using CloudFormation/CDK/Terraform
5. Update Lambda configuration (environment variables, memory, timeout)
6. Run smoke tests against deployed Lambda

**Configuration Injection Details:**
- Pipeline stores actual configuration values (table names, endpoints, etc.) in pipeline variables/secrets
- Pipeline generates complete `config.json` with actual values (no placeholders)
- Configuration uploaded to S3 before Lambda deployment
- Lambda loads configuration from S3 at runtime

**Environments:** dev → uat → prod (with approvals)

### 20.18 Lambda Development Antipatterns - What NOT to Do

This section documents common Lambda antipatterns that must be avoided in the Inscore Policy Booking application. These antipatterns are based on the **AIG Lambda Antipatterns - Common List (November 21, 2025)**.

**Purpose:** Ensure all Lambda code generated for Inscore follows AWS best practices and avoids known problematic patterns.

#### 20.18.1 Architecture & Design Antipatterns

**❌ ANTIPATTERN #1: Monolithic Lambda Functions**

**Problem:** Creating large Lambda functions that handle too many responsibilities violates the Single Responsibility Principle and makes code difficult to maintain, test, and scale.

**What NOT to do:**
- Single Lambda function handling multiple unrelated business operations (policy creation, premium calculation, document generation, notifications)
- Lambda functions with thousands of lines of code
- Mixing multiple bounded contexts in one function

**Correct Approach:**
- Create separate Lambda functions for distinct business operations
- Each Lambda should have a single, well-defined responsibility
- Use the Router pattern for related operations within a single domain

**For Inscore:**
- Follow the one-repository-per-Lambda model specified in Section 20.2
- Use Router for multiple endpoints within the same bounded context (e.g., `GET /policies`, `POST /policies`, `PUT /policies/:id`)
- Create separate Lambdas for distinct operations (e.g., `policy-booking-lambda`, `premium-calculation-lambda`, `document-generation-lambda`)

---

**❌ ANTIPATTERN #2: Synchronous Lambda-to-Lambda Invocations**

**Problem:** Calling Lambda functions synchronously from another Lambda creates tight coupling, increases latency, and can lead to cascading failures.

**What NOT to do:**
```javascript
// ❌ WRONG - Synchronous Lambda invocation
const lambda = new AWS.Lambda();
const result = await lambda.invoke({
  FunctionName: 'anotherLambda',
  InvocationType: 'RequestResponse',
  Payload: JSON.stringify(data)
}).promise();
```

**Correct Approach:**
- Use asynchronous event-driven patterns (EventBridge, SQS, SNS)
- Direct API calls via API Gateway for user-initiated flows
- Step Functions for orchestrated workflows

**For Inscore:**
- Use EventBridge for event-driven communication between services
- Use Step Functions for policy booking workflows that span multiple services
- Use API Gateway + Lambda for synchronous API endpoints
- Publish domain events (e.g., "PolicyCreated") to EventBridge, let other services subscribe

---

**❌ ANTIPATTERN #3: Not Using Lambda Layers for Shared Dependencies**

**Problem:** Bundling the same dependencies in every Lambda function increases deployment package size, slows deployments, and wastes storage.

**What NOT to do:**
- Copy-pasting shared utility code across Lambda repositories
- Bundling node_modules in every Lambda deployment package
- Duplicating common libraries in multiple Lambda functions

**Correct Approach:**
- Use shared libraries published to artifact repositories (NPM, JFrog Artifactory)
- Use Lambda Layers for runtime dependencies shared across functions
- Version shared libraries properly

**For Inscore:**
- **Use `@inscore/common-lib` NPM package from JFrog Artifactory** (as specified in Section 20.6)
- All Lambda functions install `@inscore/common-lib` as a dependency
- Common library includes: configuration loader, database utilities, Flow Engine integration, logging utilities
- DO NOT use Lambda Layers - use NPM package distribution instead

---

**❌ ANTIPATTERN #4: Using Lambda for Long-Running Tasks**

**Problem:** Lambda has a maximum timeout of 15 minutes. Using it for long-running tasks leads to timeouts and wasted compute time.

**What NOT to do:**
- Batch processing jobs that take > 10 minutes
- Large data migrations or ETL jobs
- Video transcoding or large file processing
- Tasks that require hours of processing time

**Correct Approach:**
- Use ECS/Fargate for long-running tasks (> 15 minutes)
- Use Step Functions for workflows that span long durations
- Break large jobs into smaller, parallelizable chunks processed by multiple Lambda invocations
- Use AWS Batch for batch processing workloads

**For Inscore:**
- Lambda functions should complete within 30-60 seconds for typical operations
- Policy booking operations are transactional and short-lived (suitable for Lambda)
- For batch operations (e.g., end-of-day processing), use Step Functions to orchestrate multiple Lambda invocations
- Set appropriate timeout values (Section 20.14): 30 seconds for API endpoints, up to 300 seconds for batch operations

---

**❌ ANTIPATTERN #5: Lambda in VPC Without Proper Planning**

**Problem:** Attaching Lambda to VPC without proper subnet and ENI planning can cause cold start delays, IP exhaustion, and deployment failures.

**What NOT to do:**
- Attaching Lambda to VPC when not needed (e.g., accessing public APIs)
- Using public subnets for Lambda functions
- Not reserving sufficient IP addresses in subnets
- Not using VPC endpoints for AWS service access

**Correct Approach:**
- Only use VPC when Lambda needs to access VPC resources (RDS, private APIs)
- Use private subnets with NAT Gateway for outbound internet access
- Use VPC endpoints for AWS services (S3, DynamoDB, Secrets Manager)
- Reserve adequate IP addresses (15+ per Lambda function at scale)
- Consider Lambda Hyperplane ENI sharing for reduced cold starts

**For Inscore:**
- Lambda functions accessing RDS must be deployed in VPC private subnets
- Use VPC endpoints for S3 (config.json), Secrets Manager (database credentials)
- Ensure subnets have adequate IP address space (/24 or larger)
- Configure security groups to allow Lambda → RDS communication on port 5432 (PostgreSQL)

---

#### 20.18.2 Code Structure Antipatterns

**❌ ANTIPATTERN #6: Initializing Clients Inside Handler Function**

**Problem:** Creating SDK clients, database connections, or HTTP clients on every invocation wastes time and doesn't leverage Lambda container reuse.

**What NOT to do:**
```javascript
// ❌ WRONG - Client created on every invocation
exports.handler = async (event, context) => {
  const s3Client = new AWS.S3();  // Created every time
  const dbConnection = await createConnection();  // Created every time
  // ... use clients
};
```

**Correct Approach:**
```javascript
// ✅ CORRECT - Initialize clients outside handler
const AWS = require('aws-sdk');
const s3Client = new AWS.S3();  // Initialized once, reused across invocations
let dbConnection;  // Lazy initialization

exports.handler = async (event, context) => {
  // Reuse pre-initialized clients
  if (!dbConnection) {
    dbConnection = await createConnection();
  }
  // ... use clients
};
```

**For Inscore:**
- Initialize AWS SDK clients (S3, Secrets Manager) at module level (outside handler)
- Initialize database connection pool at module level with lazy initialization
- Use `@inscore/common-lib` modules initialized at module level
- Connection pooling strategy: maintain connections across invocations, handle stale connections

---

**❌ ANTIPATTERN #7: No Proper Error Handling**

**Problem:** Not handling errors properly leads to generic 500 errors, poor debugging experience, and lack of observability.

**What NOT to do:**
```javascript
// ❌ WRONG - Generic error handling
exports.handler = async (event) => {
  try {
    // business logic
  } catch (error) {
    console.log('Error:', error);  // Insufficient logging
    return { statusCode: 500, body: 'Error' };  // Generic response
  }
};
```

**Correct Approach:**
```javascript
// ✅ CORRECT - Detailed error handling
const { AppError, errorHandler } = require('@inscore/common-lib/errors');

exports.handler = async (event) => {
  try {
    // business logic
  } catch (error) {
    console.error('Error processing request:', {
      correlationId: event.headers['x-correlation-id'],
      error: error.message,
      stack: error.stack,
      event: JSON.stringify(event)
    });

    if (error instanceof AppError) {
      return {
        statusCode: error.statusCode,
        body: JSON.stringify({ error: error.message, code: error.code })
      };
    }

    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
};
```

**For Inscore:**
- Use standardized error classes from `@inscore/common-lib/errors`
- Include correlation ID in all error logs (Section 20.11)
- Return appropriate HTTP status codes (400 for validation, 404 for not found, 500 for server errors)
- Log full error details (message, stack trace, input event) for debugging
- Do NOT log sensitive data (PII, credentials)

---

**❌ ANTIPATTERN #8: Recursive Lambda Invocations**

**Problem:** Lambda functions that invoke themselves recursively can lead to infinite loops, runaway costs, and account throttling.

**What NOT to do:**
```javascript
// ❌ WRONG - Recursive invocation
exports.handler = async (event) => {
  if (event.remainingItems > 0) {
    await lambda.invoke({
      FunctionName: context.functionName,  // Invoking itself
      Payload: JSON.stringify({ remainingItems: event.remainingItems - 1 })
    }).promise();
  }
};
```

**Correct Approach:**
- Use Step Functions for iterative workflows
- Use SQS for queue-based processing with visibility timeout
- Use DynamoDB Streams + Lambda for change data capture patterns
- Implement circuit breakers and depth limits

**For Inscore:**
- DO NOT implement recursive Lambda invocations
- Use Step Functions for workflows requiring iteration or retries
- Use SQS for asynchronous job processing with retries
- Implement maximum retry limits in error handling logic

---

**❌ ANTIPATTERN #9: Hardcoded Configuration**

**Problem:** Hardcoding configuration values (database URLs, API endpoints, table names) in code makes it impossible to promote code across environments and requires code changes for configuration updates.

**What NOT to do:**
```javascript
// ❌ WRONG - Hardcoded configuration
const DB_HOST = 'inscore-db-dev.amazonaws.com';
const API_URL = 'https://api-dev.inscore.com';
const TABLE_NAME = 'policies-dev';
```

**Correct Approach:**
```javascript
// ✅ CORRECT - Configuration loaded at runtime
const { loadConfig } = require('@inscore/common-lib/config');

let config;

exports.handler = async (event) => {
  if (!config) {
    config = await loadConfig();  // Load from S3
  }

  const dbHost = config.database.host;
  const apiUrl = config.api.baseUrl;
  const tableName = config.database.tables.policies;
};
```

**For Inscore:**
- Follow configuration management pattern in Section 20.7
- All configuration loaded from `config.json` in S3 (`s3://inscore-config-{env}/config.json`)
- Use `@inscore/common-lib/config` for configuration loading
- Environment variables only for AWS metadata (Section 20.14)
- DevOps team manages configuration injection via CI/CD pipeline (Section 20.17.3)

---

**❌ ANTIPATTERN #10: Including Unnecessary Dependencies**

**Problem:** Including large, unused dependencies increases cold start time, deployment package size, and Lambda costs.

**What NOT to do:**
- Including entire AWS SDK when only needing 1-2 services
- Including large libraries for simple operations (e.g., moment.js for basic date formatting)
- Not using tree-shaking or bundling tools
- Including devDependencies in production bundles

**Correct Approach:**
- Use minimal, focused dependencies
- Use AWS SDK v3 with modular imports
- Use bundlers (webpack, esbuild) to remove unused code
- Keep deployment packages < 10 MB (unzipped)

**For Inscore:**
- Use AWS SDK v3 with modular imports: `@aws-sdk/client-s3` instead of `aws-sdk`
- Use `esbuild` or `webpack` for bundling (Section 20.17.1)
- Analyze `package.json` dependencies and remove unused packages
- Target deployment package size < 5 MB (unzipped)
- `@inscore/common-lib` should include only essential utilities

---

#### 20.18.3 Performance Antipatterns

**❌ ANTIPATTERN #11: Not Optimizing Memory Allocation**

**Problem:** Using default 128 MB memory allocation or not tuning memory based on workload leads to slow execution or unnecessary costs.

**What NOT to do:**
- Using 128 MB for CPU-intensive operations
- Using 3008 MB for simple CRUD operations
- Not testing memory requirements
- Ignoring the relationship between memory and CPU allocation

**Correct Approach:**
- Lambda CPU allocation is proportional to memory (1769 MB = 1 vCPU)
- Test functions with different memory settings
- Monitor memory usage in CloudWatch Logs
- Use AWS Lambda Power Tuning tool to find optimal memory setting
- Balance cost vs. performance

**For Inscore:**
- Default memory allocation: 512 MB for API endpoints (Section 20.14)
- CPU-intensive operations (premium calculations): 1024 MB
- Simple CRUD operations: 256-512 MB
- Test with Lambda Power Tuning and adjust based on actual usage
- Monitor max memory used in CloudWatch Logs

---

**❌ ANTIPATTERN #12: Sequential API Calls When Parallel Is Possible**

**Problem:** Making API calls or database queries sequentially when they could run in parallel increases latency significantly.

**What NOT to do:**
```javascript
// ❌ WRONG - Sequential calls (3 seconds total)
const user = await fetchUser(userId);  // 1 second
const policy = await fetchPolicy(policyId);  // 1 second
const coverage = await fetchCoverage(coverageId);  // 1 second
```

**Correct Approach:**
```javascript
// ✅ CORRECT - Parallel calls (1 second total)
const [user, policy, coverage] = await Promise.all([
  fetchUser(userId),
  fetchPolicy(policyId),
  fetchCoverage(coverageId)
]);
```

**For Inscore:**
- Use `Promise.all()` for independent async operations
- Parallel database queries where possible (different tables, no dependencies)
- Parallel API calls to external services
- Be mindful of connection pool limits when parallelizing database queries

---

**❌ ANTIPATTERN #13: Reading Large Files Into Memory**

**Problem:** Reading large files entirely into memory can exceed Lambda memory limits and cause out-of-memory errors.

**What NOT to do:**
```javascript
// ❌ WRONG - Loading entire file into memory
const file = await s3.getObject({ Bucket, Key }).promise();
const content = file.Body.toString();  // Entire file in memory
```

**Correct Approach:**
- Use streaming for large files
- Process files in chunks
- Use S3 Select for querying data in S3
- Store large files in S3, process references

**For Inscore:**
- Stream large documents from S3 instead of loading entirely
- For document generation, stream output directly to S3
- For CSV/Excel processing, use streaming parsers
- Maximum file size for in-memory processing: 10 MB

---

**❌ ANTIPATTERN #14: Not Using Connection Pooling for Databases**

**Problem:** Creating new database connections on every Lambda invocation wastes time and can exhaust database connection limits.

**What NOT to do:**
```javascript
// ❌ WRONG - New connection every invocation
exports.handler = async (event) => {
  const connection = await createConnection(dbConfig);
  const result = await connection.query('SELECT * FROM policies');
  await connection.close();
  return result;
};
```

**Correct Approach:**
```javascript
// ✅ CORRECT - Connection pooling with reuse
let pool;

async function getPool() {
  if (!pool) {
    pool = createPool(dbConfig);
  }
  return pool;
}

exports.handler = async (event) => {
  const pool = await getPool();
  const result = await pool.query('SELECT * FROM policies');
  return result;  // Connection returned to pool, not closed
};
```

**For Inscore:**
- Use RDS Proxy for connection pooling (Section 20.9.2)
- Initialize connection pool at module level, reuse across invocations
- Configure appropriate pool size based on Lambda concurrency
- Handle stale connections with health checks
- Use `@inscore/common-lib/database` for connection management

---

**❌ ANTIPATTERN #15: Not Using Provisioned Concurrency for Critical Paths**

**Problem:** Cold starts on critical user-facing paths lead to poor user experience and SLA violations.

**What NOT to do:**
- Relying on on-demand Lambda for latency-sensitive APIs
- Not planning for cold start impact during traffic spikes
- Ignoring cold start monitoring

**Correct Approach:**
- Use Provisioned Concurrency for critical, latency-sensitive functions
- Implement gradual warming strategies
- Monitor cold start frequency and P99 latency
- Use Application Auto Scaling for Provisioned Concurrency

**For Inscore:**
- Evaluate Provisioned Concurrency for critical API endpoints (policy search, policy retrieve)
- Start with minimal Provisioned Concurrency (2-5 instances) in production
- Monitor P99 latency and cold start percentage in CloudWatch
- Use Provisioned Concurrency with Auto Scaling based on traffic patterns
- NOT required for batch processing Lambdas

---

#### 20.18.4 Security Antipatterns

**❌ ANTIPATTERN #16: Overly Permissive IAM Roles**

**Problem:** Granting Lambda functions broad IAM permissions (e.g., `s3:*`, `dynamodb:*`) violates the principle of least privilege and increases security risk.

**What NOT to do:**
```json
{
  "Effect": "Allow",
  "Action": "s3:*",
  "Resource": "*"
}
```

**Correct Approach:**
```json
{
  "Effect": "Allow",
  "Action": [
    "s3:GetObject"
  ],
  "Resource": "arn:aws:s3:::inscore-config-prod/config.json"
}
```

**For Inscore:**
- Grant minimum required permissions for each Lambda
- Scope permissions to specific resources (specific S3 buckets, specific RDS instances)
- Use separate IAM roles for different Lambda functions
- Example: `policy-booking-lambda` needs `rds:DescribeDBInstances`, `secretsmanager:GetSecretValue`, `s3:GetObject` on config bucket only
- Review IAM policies regularly, remove unused permissions

---

**❌ ANTIPATTERN #17: Logging Sensitive Information**

**Problem:** Logging PII, credentials, or sensitive business data in CloudWatch Logs creates compliance violations and security risks.

**What NOT to do:**
```javascript
// ❌ WRONG - Logging sensitive data
console.log('Processing policy:', JSON.stringify(event.body));  // Contains PII
console.log('Database password:', dbPassword);
console.log('API key:', apiKey);
```

**Correct Approach:**
```javascript
// ✅ CORRECT - Sanitized logging
const sanitizedEvent = {
  ...event,
  body: '[REDACTED]',
  headers: { ...event.headers, authorization: '[REDACTED]' }
};
console.log('Processing request:', JSON.stringify(sanitizedEvent));
```

**For Inscore:**
- DO NOT log PII (SSN, email, phone, address)
- DO NOT log credentials (passwords, API keys, tokens)
- Use log sanitization utilities from `@inscore/common-lib/logging`
- Log correlation IDs, request IDs, timestamps
- Log business events (policy created, premium calculated) without sensitive details
- Enable CloudWatch Logs encryption at rest

---

**❌ ANTIPATTERN #18: Storing Secrets in Environment Variables**

**Problem:** Environment variables are visible in Lambda console, CloudFormation templates, and to anyone with Lambda read permissions.

**What NOT to do:**
```javascript
// ❌ WRONG - Secrets in environment variables
const DB_PASSWORD = process.env.DB_PASSWORD;
const API_KEY = process.env.API_KEY;
```

**Correct Approach:**
```javascript
// ✅ CORRECT - Secrets from Secrets Manager
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager();

async function getSecret(secretName) {
  const secret = await secretsManager.getSecretValue({ SecretId: secretName }).promise();
  return JSON.parse(secret.SecretString);
}

const dbCredentials = await getSecret('inscore/database/credentials');
```

**For Inscore:**
- Store ALL secrets in HashiCorp Vault or AWS Secrets Manager (Section 20.13)
- Database credentials: Vault (`inscore/database/rds-credentials`)
- API keys: Vault (`inscore/api-keys/external-services`)
- Use `@inscore/common-lib/vault` for Vault integration
- Rotate secrets regularly (90 days)
- Cache secrets in Lambda container for 5-10 minutes, refresh on expiration

---

**❌ ANTIPATTERN #19: Not Validating Input**

**Problem:** Not validating input data leads to injection attacks, data corruption, and application errors.

**What NOT to do:**
```javascript
// ❌ WRONG - No input validation
exports.handler = async (event) => {
  const { policyId } = JSON.parse(event.body);
  const policy = await db.query(`SELECT * FROM policies WHERE id = ${policyId}`);  // SQL injection risk
};
```

**Correct Approach:**
```javascript
// ✅ CORRECT - Input validation + parameterized queries
const Joi = require('joi');

const schema = Joi.object({
  policyId: Joi.string().uuid().required(),
  effectiveDate: Joi.date().iso().required()
});

exports.handler = async (event) => {
  const body = JSON.parse(event.body);
  const { error, value } = schema.validate(body);

  if (error) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Invalid input', details: error.details })
    };
  }

  const policy = await db.query('SELECT * FROM policies WHERE id = $1', [value.policyId]);
};
```

**For Inscore:**
- Validate ALL input at handler layer (Section 20.12.1)
- Use validation library (Joi, Yup, or custom validators in `@inscore/common-lib/validators`)
- Use parameterized queries for SQL (NEVER string concatenation)
- Validate data types, formats, ranges, required fields
- Return 400 Bad Request with detailed validation errors
- Sanitize input before logging

---

**❌ ANTIPATTERN #20: Not Implementing Request Throttling**

**Problem:** Not implementing rate limiting allows abuse, runaway costs, and potential DDoS attacks.

**What NOT to do:**
- No rate limiting on Lambda functions
- No throttling configuration in API Gateway
- No protection against repeated failed authentication attempts

**Correct Approach:**
- Use API Gateway throttling (requests per second, burst limits)
- Implement application-level rate limiting using DynamoDB
- Use AWS WAF for advanced protection
- Monitor for unusual traffic patterns

**For Inscore:**
- Configure API Gateway throttling: 1000 requests/second, burst 2000 (adjust based on testing)
- Implement per-user rate limiting using DynamoDB for authentication endpoints
- Use AWS WAF for SQL injection, XSS protection
- Monitor throttling metrics in CloudWatch
- Return 429 Too Many Requests with Retry-After header

---

#### 20.18.5 Operational Antipatterns

**❌ ANTIPATTERN #21: Insufficient Logging and Monitoring**

**Problem:** Not logging enough information makes debugging production issues nearly impossible and violates observability principles.

**What NOT to do:**
```javascript
// ❌ WRONG - Insufficient logging
exports.handler = async (event) => {
  const result = await processPolicy(event);
  return result;
};
```

**Correct Approach:**
```javascript
// ✅ CORRECT - Comprehensive logging
exports.handler = async (event) => {
  const correlationId = event.headers['x-correlation-id'] || generateId();

  console.log('Lambda invocation started', {
    correlationId,
    functionName: context.functionName,
    requestId: context.requestId,
    httpMethod: event.httpMethod,
    path: event.path
  });

  try {
    const result = await processPolicy(event);

    console.log('Lambda invocation succeeded', {
      correlationId,
      duration: context.getRemainingTimeInMillis(),
      statusCode: 200
    });

    return result;
  } catch (error) {
    console.error('Lambda invocation failed', {
      correlationId,
      error: error.message,
      stack: error.stack
    });
    throw error;
  }
};
```

**For Inscore:**
- Log request start, success, failure with correlation ID (Section 20.11)
- Log key business events (policy created, premium calculated)
- Log performance metrics (duration, memory usage)
- Use structured logging (JSON format)
- Use `@inscore/common-lib/logging` for consistent log formatting
- Create CloudWatch dashboards for monitoring
- Set up alarms for error rates, latency, throttling

---

**❌ ANTIPATTERN #22: Not Using Dead Letter Queues (DLQ)**

**Problem:** Not configuring DLQs for asynchronous Lambda invocations leads to silent failures and lost events.

**What NOT to do:**
- No DLQ configuration for EventBridge-triggered Lambdas
- No DLQ configuration for SQS-triggered Lambdas
- Not monitoring DLQ depth

**Correct Approach:**
- Configure SQS DLQ for asynchronous Lambda invocations
- Configure DLQ for EventBridge rules
- Monitor DLQ depth with CloudWatch alarms
- Implement DLQ processing and replay mechanisms

**For Inscore:**
- Configure DLQ for all asynchronous Lambda invocations
- Use SQS queues as DLQs
- Set maximum retry attempts before sending to DLQ: 2 retries
- Create CloudWatch alarms when DLQ depth > 0
- Implement manual DLQ processing Lambda for investigation and replay
- Log detailed context when sending to DLQ

---

**❌ ANTIPATTERN #23: Mixing Infrastructure and Application Code**

**Problem:** Hardcoding infrastructure concerns (resource creation, IAM policies) in application code creates tight coupling and deployment issues.

**What NOT to do:**
```javascript
// ❌ WRONG - Infrastructure in application code
const s3 = new AWS.S3();
await s3.createBucket({ Bucket: 'inscore-documents-prod' }).promise();
```

**Correct Approach:**
- Separate infrastructure provisioning (CloudFormation/Terraform/CDK)
- Application code assumes infrastructure exists
- Use environment-specific configuration for resource names

**For Inscore:**
- All infrastructure provisioned via IaC (Infrastructure as Code)
- Lambda code loads resource names from `config.json`
- DO NOT create AWS resources from Lambda code (S3 buckets, DynamoDB tables, etc.)
- Exception: Writing data to existing resources (S3 objects, DynamoDB items)

---

**❌ ANTIPATTERN #24: Not Implementing Idempotency**

**Problem:** Not ensuring idempotent operations leads to duplicate processing, data inconsistencies, and financial errors.

**What NOT to do:**
```javascript
// ❌ WRONG - Non-idempotent operation
exports.handler = async (event) => {
  const policy = await createPolicy(event.body);  // Creates duplicate on retry
  await sendEmail(policy.ownerEmail);  // Sends duplicate email on retry
  return policy;
};
```

**Correct Approach:**
```javascript
// ✅ CORRECT - Idempotent operation with idempotency key
exports.handler = async (event) => {
  const idempotencyKey = event.headers['idempotency-key'];

  // Check if already processed
  const existingResult = await getIdempotentResponse(idempotencyKey);
  if (existingResult) {
    return existingResult;
  }

  // Process and store result with idempotency key
  const policy = await createPolicy(event.body);
  await storeIdempotentResponse(idempotencyKey, policy);

  return policy;
};
```

**For Inscore:**
- Implement idempotency for all state-changing operations (POST, PUT, DELETE)
- Use idempotency keys in API requests (client-generated UUID)
- Store idempotency keys in DynamoDB with TTL (24 hours)
- Use `@inscore/common-lib/idempotency` for idempotency utilities
- Critical for financial operations (premium calculation, payment processing)

---

**❌ ANTIPATTERN #25: Setting Inappropriate Timeout Values**

**Problem:** Setting timeout too low causes premature failures; setting it too high masks performance issues and wastes costs.

**What NOT to do:**
- Using default 3-second timeout for database operations
- Setting 15-minute timeout for simple CRUD operations
- Not monitoring actual execution duration

**Correct Approach:**
- Set timeout based on P99 execution duration + buffer
- Monitor actual duration in CloudWatch
- API endpoints: 30 seconds
- Background processing: 300 seconds
- Adjust based on actual performance

**For Inscore:**
- API endpoint Lambdas: 30 seconds timeout (Section 20.14)
- Batch processing Lambdas: 300 seconds (5 minutes)
- Integration Lambdas (external API calls): 60 seconds
- Monitor P99 duration and adjust timeouts accordingly
- Alert when executions approach timeout threshold

---

**❌ ANTIPATTERN #26: Not Optimizing Cold Starts**

**Problem:** Ignoring cold start optimization leads to poor user experience on initial requests and after scaling events.

**What NOT to do:**
- Loading large dependencies inside handler
- Not using lazy initialization
- Ignoring cold start metrics
- Large deployment packages (> 50 MB)

**Correct Approach:**
- Minimize deployment package size
- Initialize heavy dependencies outside handler
- Use lazy initialization where possible
- Monitor cold start frequency and duration
- Consider Provisioned Concurrency for critical paths

**For Inscore:**
- Target cold start duration < 2 seconds
- Initialize AWS SDK clients at module level
- Lazy-load infrequently used modules
- Use bundling to reduce package size (Section 20.17.1)
- Monitor cold start percentage (target < 5% of invocations)
- Use Provisioned Concurrency for critical API endpoints if needed

---

**❌ ANTIPATTERN #27: Not Implementing Circuit Breaker Pattern**

**Problem:** Not protecting against cascading failures when downstream services are unavailable leads to resource exhaustion and poor error handling.

**What NOT to do:**
```javascript
// ❌ WRONG - No circuit breaker
exports.handler = async (event) => {
  const result = await callExternalAPI();  // Fails repeatedly if service is down
  return result;
};
```

**Correct Approach:**
```javascript
// ✅ CORRECT - Circuit breaker pattern
const CircuitBreaker = require('opossum');

const breaker = new CircuitBreaker(callExternalAPI, {
  timeout: 3000,
  errorThresholdPercentage: 50,
  resetTimeout: 30000
});

exports.handler = async (event) => {
  try {
    const result = await breaker.fire();
    return result;
  } catch (error) {
    if (breaker.opened) {
      return { statusCode: 503, body: 'Service temporarily unavailable' };
    }
    throw error;
  }
};
```

**For Inscore:**
- Implement circuit breaker for external API calls (Flow Engine, external rating services)
- Use circuit breaker library (opossum) or implement in `@inscore/common-lib/resilience`
- Configure thresholds: 50% error rate, 30-second reset timeout
- Return graceful degradation responses when circuit is open
- Monitor circuit breaker state transitions

---

**❌ ANTIPATTERN #28: Using Default Lambda Concurrency Limits**

**Problem:** Not configuring reserved concurrency can lead to one Lambda consuming all account concurrency, starving other functions.

**What NOT to do:**
- Leaving all Lambdas with unreserved concurrency
- Not setting concurrency limits for batch processing functions
- Not monitoring concurrency usage

**Correct Approach:**
- Set reserved concurrency for critical functions
- Set concurrency limits for batch/background functions to prevent resource exhaustion
- Monitor concurrent executions in CloudWatch
- Plan concurrency allocation across all functions

**For Inscore:**
- Critical API endpoints: Reserved concurrency 50-100 (based on expected load)
- Batch processing: Reserved concurrency 10 (prevent runaway scaling)
- Total account concurrency limit: 1000 (default, can request increase)
- Monitor concurrent executions and throttling
- Request concurrency limit increase if needed

---

**❌ ANTIPATTERN #29: Not Leveraging EventBridge for Decoupling**

**Problem:** Creating tight coupling between services through direct invocations or API calls instead of using event-driven architecture.

**What NOT to do:**
- Lambda directly invoking another Lambda
- Lambda directly calling microservice APIs for event notifications
- Not publishing domain events

**Correct Approach:**
- Publish domain events to EventBridge
- Services subscribe to events they care about
- Loose coupling between services
- Easy to add new subscribers without modifying publishers

**For Inscore:**
- Publish domain events to EventBridge: `PolicyCreated`, `PremiumCalculated`, `DocumentGenerated`
- Use custom event bus: `inscore-policy-booking-events`
- Event schema: include correlation ID, timestamp, event type, payload
- Services subscribe to relevant events (e.g., notification service subscribes to `PolicyCreated`)
- Use EventBridge Schema Registry for event schema management

---

**❌ ANTIPATTERN #30: Deploying Without Proper Testing**

**Problem:** Deploying Lambda code without adequate testing leads to production defects, rollbacks, and poor customer experience.

**What NOT to do:**
- Deploying without unit tests
- Not testing integration with AWS services
- Not testing error scenarios
- No smoke tests after deployment

**Correct Approach:**
- Write unit tests with 80%+ coverage
- Write integration tests for AWS service interactions
- Test error scenarios and edge cases
- Run smoke tests after deployment
- Use canary deployments for gradual rollout

**For Inscore:**
- Minimum 80% code coverage for all Lambda functions (Section 20.15)
- Unit tests: Jest framework, test all business logic
- Integration tests: Test database operations, S3 operations, external API calls
- Use LocalStack or AWS SAM for local testing
- Smoke tests: Automated tests in dev environment after deployment
- Consider canary deployments (10% traffic for 5 minutes before full rollout)

---

### 20.19 Summary

This Lambda Code Generation Template provides comprehensive specifications for:

✅ **Repository Model:** One Lambda = One Repository (not monorepo)
✅ **Request Handling:** Single handler.js with router for multiple endpoints
✅ **Architectural Layers:** Handler → Router → Controller → Service → Data Layer
✅ **File Organization:** Standardized folder structure across all Lambda services
✅ **Common Library:** NPM package published to JFrog Artifactory (`@inscore/common-lib`, includes Flow Engine)
✅ **Configuration:** DevOps-managed configuration injected to S3, single config.json template in repository
✅ **Testing:** Jest framework with 80% coverage requirement
✅ **Environment Variables:** Standard variables for all Lambda functions
✅ **Naming Conventions:** Consistent naming across files, functions, and resources
✅ **Security:** Vault for secrets, IAM for authentication, input validation
✅ **CI/CD Integration:** Build, test, and deploy pipeline specifications with configuration injection

**Next Steps:** UI and API Gateway templates will be added in subsequent sections as per your requirement.

---

**Note:** This template contains specifications only without implementation code examples. Development teams should refer to the reference implementation at `C:\S3 Migration\Reference\dtp-quote-7417` for code patterns while following these specifications.

---

## 21. UI Application Template (Angular with AXIS Framework)

This section provides comprehensive specifications for building the Inscore Policy Booking UI application using Angular and the AIG AXIS framework.

### 21.1 UI Technology Stack

**Framework:** Angular 18.x
**UI Component Library:** AXIS Components (AIG standard UI framework)
**Authentication:** Okta (OAuth 2.0 / OpenID Connect)
**State Management:** Angular Signals + RxJS Services
**HTTP Client:** Angular HttpClient with Interceptors
**Routing:** Angular Router with Guards
**Forms:** Axis UI Generator (AUG) - JSON-based dynamic form generation
**Data Grid:** ag-Grid Enterprise
**Styling:** SCSS with AXIS design system
**Testing:** Jasmine + Karma
**Build Tool:** Angular CLI
**Package Manager:** npm

### 21.2 Repository Structure

**Repository Model:** One UI Application = One Repository

**Repository Name:** `inscore-policy-booking-ui`

**Folder Structure:**

```
inscore-policy-booking-ui/
├── src/
│   ├── app/
│   │   ├── _shared/                    # Shared modules and components
│   │   │   ├── axis-shared.module.ts
│   │   │   ├── shared.module.ts
│   │   │   └── components/
│   │   │       ├── [shared-component-1]/
│   │   │       └── [shared-component-2]/
│   │   ├── _layout/                    # Layout components (header, footer, sidebar)
│   │   │   ├── header/
│   │   │   ├── footer/
│   │   │   └── sidebar/
│   │   ├── _directives/                # Custom directives
│   │   │   └── [directive-name].directive.ts
│   │   ├── common/                     # Common services, guards, interceptors
│   │   │   ├── services/               # Business services
│   │   │   │   ├── config.service.ts
│   │   │   │   ├── auth.service.ts
│   │   │   │   ├── booking.service.ts
│   │   │   │   └── index.ts
│   │   │   ├── guards/                 # Route guards
│   │   │   │   └── auth.guard.ts
│   │   │   ├── interceptors/           # HTTP interceptors
│   │   │   │   └── auth.interceptor.ts
│   │   │   ├── models/                 # TypeScript interfaces and types
│   │   │   │   └── [model-name].interface.ts
│   │   │   ├── constants/              # Application constants
│   │   │   │   └── app.constants.ts
│   │   │   └── utils/                  # Utility functions
│   │   │       └── utility.ts
│   │   ├── features/                   # Feature modules (lazy-loaded)
│   │   │   ├── dashboard/
│   │   │   │   ├── dashboard.component.ts
│   │   │   │   ├── dashboard.component.html
│   │   │   │   ├── dashboard.component.scss
│   │   │   │   ├── dashboard.module.ts
│   │   │   │   └── dashboard-routing.module.ts
│   │   │   ├── policy-booking/
│   │   │   │   ├── policy-booking.component.ts
│   │   │   │   ├── policy-booking.module.ts
│   │   │   │   ├── policy-booking-routing.module.ts
│   │   │   │   ├── services/
│   │   │   │   │   └── policy-booking-data.service.ts
│   │   │   │   └── components/         # Feature-specific components
│   │   │   │       ├── policy-details/
│   │   │   │       ├── risk-location/
│   │   │   │       └── coverage-selection/
│   │   │   └── [other-features]/
│   │   ├── app.component.ts            # Root component
│   │   ├── app.component.html
│   │   ├── app.component.scss
│   │   ├── app.module.ts               # Root module
│   │   └── app-routing.module.ts       # Root routing
│   ├── assets/                         # Static assets
│   │   ├── config/
│   │   │   └── config.json             # Runtime configuration (loaded at app startup)
│   │   ├── images/
│   │   ├── icons/
│   │   └── i18n/                       # Internationalization files (if needed)
│   ├── environments/                   # Build-time environment files
│   │   ├── environment.ts              # Development environment
│   │   └── environment.prod.ts         # Production environment
│   ├── styles/                         # Global styles
│   │   └── main.scss
│   ├── index.html
│   ├── main.ts                         # Application bootstrap
│   ├── polyfills.ts
│   └── test.ts
├── node_modules/                       # NPM dependencies (gitignored)
├── dist/                               # Build output (gitignored)
├── coverage/                           # Test coverage (gitignored)
├── e2e/                                # End-to-end tests (optional)
├── angular.json                        # Angular CLI configuration
├── package.json                        # Dependencies and scripts
├── package-lock.json
├── tsconfig.json                       # TypeScript configuration
├── tsconfig.app.json                   # App-specific TypeScript config
├── tsconfig.spec.json                  # Test-specific TypeScript config
├── karma.conf.js                       # Karma test runner config
├── .gitignore
├── .editorconfig
└── README.md
```

### 21.3 Application Architecture

#### 21.3.1 Module Architecture

**Core Module:** Contains singleton services (configuration, authentication, logging)
**Shared Module:** Contains reusable components, directives, pipes
**Feature Modules:** Lazy-loaded modules for each major feature area
**AXIS Shared Module:** Imports AXIS framework components

**Module Loading Strategy:**
- Eager loading: Core module, shared module, app module
- Lazy loading: All feature modules (loaded on route activation)

#### 21.3.2 Component Architecture

**Container Components (Smart Components):**
- Manage state and business logic
- Communicate with services
- Pass data to presentational components via `@Input()`
- Handle events from presentational components via `@Output()`

**Presentational Components (Dumb Components):**
- Receive data via `@Input()` properties
- Emit events via `@Output()` EventEmitters
- No direct service dependencies
- Highly reusable

#### 21.3.3 Routing Strategy

**Route Configuration:**
- Root routes defined in `app-routing.module.ts`
- Feature routes defined in feature-specific routing modules
- Lazy-loaded feature modules using `loadChildren`
- Route guards for authentication and authorization

**Example Routing Structure:**

| Path | Module | Guard | Description |
|------|--------|-------|-------------|
| `/` | Dashboard | AuthGuard | Dashboard home page |
| `/booking/new` | PolicyBooking | AuthGuard | Initiate new policy booking |
| `/booking/:bookingId/edit` | PolicyBooking | AuthGuard | Edit existing booking |
| `/booking/:bookingId/review` | PolicyBooking | AuthGuard | Review booking before submission |
| `/logout` | - | - | Logout component |

### 21.4 Configuration Management

#### 21.4.1 Runtime Configuration (config.json)

**Location:** `src/assets/config/config.json`

**Loading Strategy:**
- Configuration loaded at application startup via `APP_INITIALIZER`
- ConfigService fetches `config.json` before application bootstrap
- Configuration values stored in singleton service for global access
- DevOps pipeline manages environment-specific configuration

**Configuration Template (config.json):**

```json
{
  "appTitle": "Inscore Policy Booking",
  "apiBaseUrl": "PLACEHOLDER-api-gateway-url",
  "apiTimeout": 30000,
  "okta": {
    "clientId": "PLACEHOLDER-okta-client-id",
    "issuer": "PLACEHOLDER-okta-issuer",
    "loginRedirectUri": "/implicit/callback",
    "logoutRedirectUri": "/logout",
    "scopes": ["openid", "email", "profile", "gi-apps"]
  },
  "menuLinks": {
    "dashboard": "PLACEHOLDER-dashboard-url",
    "uwConsole": "PLACEHOLDER-uw-console-url"
  },
  "featureToggles": {
    "enableAdvancedSearch": true,
    "enableBulkUpload": false
  },
  "agGridLicenseKey": "PLACEHOLDER-ag-grid-license-key",
  "sessionTimeout": 3600000,
  "logLevel": "INFO"
}
```

**DevOps Configuration Injection:**
- Pipeline replaces PLACEHOLDER values with environment-specific values
- Configuration deployed to CDN or application server
- Different `config.json` per environment (dev, uat, prod)

#### 21.4.2 Build-Time Environment Configuration

**Purpose:** Build-time flags for enabling/disabling features during compilation

**Files:**
- `environment.ts` (development)
- `environment.prod.ts` (production)

**Example environment.ts:**

```typescript
export const environment = {
  production: false,
  hmr: false,
  skipAuthenticationForLocalTesting: false
};
```

**Note:** Sensitive values (API URLs, credentials) should NEVER be in environment.ts files. Use runtime `config.json` instead.

### 21.5 Authentication & Authorization

#### 21.5.1 Okta Integration

**Authentication Flow:**
1. User navigates to application
2. `APP_INITIALIZER` loads configuration from `config.json`
3. Application initializes Okta SDK with configuration
4. User redirected to Okta login if not authenticated
5. Okta redirects back to application with authorization code
6. Application exchanges code for tokens (ID token, access token)
7. Tokens stored securely and used for API calls

**Implementation:**
- Use `@okta/okta-auth-js` library for authentication
- Use AXIS framework's `AuthorizationService` for integration
- Store tokens in secure storage (not localStorage for sensitive data)

#### 21.5.2 Route Guards

**AuthGuard:**
- Protects routes requiring authentication
- Redirects unauthenticated users to login
- Implemented in `common/guards/auth.guard.ts`

**RoleGuard:**
- Protects routes based on user roles
- Checks entitlements via common library
- Returns 403 Forbidden if user lacks permissions

#### 21.5.3 HTTP Interceptors

**AuthInterceptor:**
- Attaches Bearer token to all outgoing API requests
- Adds `Authorization: Bearer <access-token>` header

**ErrorInterceptor:**
- Handles HTTP errors globally
- Displays user-friendly error messages
- Redirects to login on 401 Unauthorized

### 21.6 API Communication

#### 21.6.1 Service Layer

**Location:** `src/app/common/services/` (global) or `src/app/features/[feature]/services/` (feature-specific)

**Service Responsibilities:**
- Make HTTP calls to backend APIs
- Handle request/response transformations
- Manage loading states
- Cache data when appropriate
- Error handling

**Example Service Structure:**

```typescript
@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private baseUrl: string;

  constructor(
    private http: HttpClient,
    private configService: ConfigService
  ) {
    this.baseUrl = this.configService.getApiBaseUrl();
  }

  getBooking(bookingId: string): Observable<Booking> {
    return this.http.get<Booking>(`${this.baseUrl}/bookings/${bookingId}`);
  }

  createBooking(booking: BookingRequest): Observable<BookingResponse> {
    return this.http.post<BookingResponse>(`${this.baseUrl}/bookings`, booking);
  }
}
```

#### 21.6.2 API Integration with Lambda Services

**UI Components Service Integration:**
- POST `/ui/booking/{bookingId}/workflow/initialize` - Initialize workflow
- GET `/ui/booking/{bookingId}/nextComponent` - Get next component
- PUT `/ui/booking/{bookingId}/components/status` - Save component data
- GET `/ui/booking/{bookingId}/components?componentId=X` - Get specific component

**Booking Management Service Integration:**
- POST `/booking/initiate` - Create new booking
- GET `/booking/{bookingId}` - Get booking details
- PUT `/booking/{bookingId}` - Update booking

**Integration Proxy Service Integration:**
- All MDM/RDM calls proxied through Integration Proxy Service
- No direct external API calls from UI

### 21.7 State Management

**Strategy:** RxJS + Services (No NgRx for this application)

**State Storage:**
- Global state: Singleton services with BehaviorSubject / Angular Signals
- Component state: Angular Signals (WritableSignal, Computed)
- Form state: Axis UI Generator (AUG) with JSON schema

**Example State Service:**

```typescript
@Injectable({
  providedIn: 'root'
})
export class BookingStateService {
  private bookingSubject = new BehaviorSubject<Booking | null>(null);
  public booking$ = this.bookingSubject.asObservable();

  setBooking(booking: Booking): void {
    this.bookingSubject.next(booking);
  }

  clearBooking(): void {
    this.bookingSubject.next(null);
  }
}
```

### 21.8 AXIS Framework Integration

#### 21.8.1 AXIS Components

**Core AXIS Packages:**
- `axis-components` - Standard UI components (buttons, inputs, modals, etc.)
- `axis-ui-generator` - Dynamic form generation from JSON schemas
- `axis-datagrid` - Data grid component (wrapper for ag-Grid)
- `axis-common-lib` - Common utilities and services
- `axis-notification` - Toast notifications and alerts
- `axis-abc-portal-menu` - Application menu integration

**Installation:**
- AXIS packages published to AIG Artifactory
- Installed via npm from private registry

#### 21.8.2 AXIS UI Generator

**Purpose:** Generate dynamic forms from JSON UI configuration

**Usage:**
- UI configuration stored in DynamoDB (`ui-component-catalog` table)
- UI Components Service returns UI configuration JSON
- AXIS UI Generator renders form controls dynamically from AUG JSON schema
- Form state managed by axis-ui-generator at runtime

**Benefits:**
- No code changes required for UI updates
- Configuration-driven UI
- Consistent look and feel

### 21.9 Testing Strategy

#### 21.9.1 Unit Testing

**Framework:** Jasmine + Karma
**Coverage Target:** 80% minimum
**Test Location:** `*.spec.ts` files co-located with components/services

**Testing Responsibilities:**
- Component logic testing
- Service method testing with mocked HTTP calls
- Pipe and directive testing
- Guard and interceptor testing

**Test Execution:**
```bash
npm test                          # Run tests with code coverage
npm run test:headless             # Run in headless Chrome (CI/CD)
```

#### 21.9.2 End-to-End Testing

**Framework:** Protractor or Cypress (optional)
**Test Location:** `e2e/` folder
**Purpose:** Test critical user journeys

### 21.10 Build & Deployment

#### 21.10.1 Build Configuration

**Build Command:**
```bash
ng build --configuration production
```

**Build Output:**
- Location: `dist/inscore-policy-booking-ui/`
- Output: Bundled and minified JavaScript, CSS, HTML
- Assets: Copied to dist folder

**Build Optimizations:**
- Ahead-of-Time (AOT) compilation
- Tree-shaking unused code
- Code splitting with lazy-loaded modules
- CSS minification
- Source map generation (optional for production)

#### 21.10.2 Deployment Strategy

**Deployment Target:** AWS S3 + CloudFront CDN

**Deployment Steps:**
1. Build application: `ng build --configuration production`
2. DevOps pipeline generates environment-specific `config.json`
3. Upload `config.json` to `dist/inscore-policy-booking-ui/assets/config/`
4. Upload entire `dist/` folder to S3 bucket
5. Invalidate CloudFront cache
6. Application accessible via CloudFront URL

**Environment-Specific Deployments:**
- Dev: `s3://inscore-ui-dev/` → `https://dev-inscore-ui.aig.net`
- UAT: `s3://inscore-ui-uat/` → `https://uat-inscore-ui.aig.net`
- Prod: `s3://inscore-ui-prod/` → `https://inscore-ui.aig.net`

### 21.11 CI/CD Pipeline Integration

#### 21.11.1 Build Stage

**Steps:**
1. Install dependencies: `npm install`
2. Lint code: `ng lint`
3. Run unit tests: `npm test`
4. Build application: `ng build --configuration production`
5. Generate environment-specific `config.json` from pipeline variables
6. Copy `config.json` to `dist/inscore-policy-booking-ui/assets/config/`

#### 21.11.2 Deploy Stage

**Steps:**
1. Upload build artifacts to S3 bucket
2. Set appropriate S3 bucket policies and CORS
3. Configure CloudFront distribution
4. Invalidate CloudFront cache for immediate updates
5. Run smoke tests against deployed application

**Deployment Approval:**
- Dev: Automatic deployment
- UAT: Automatic deployment after successful dev deployment
- Prod: Manual approval required

### 21.12 Naming Conventions

#### 21.12.1 File Naming

- Components: `[component-name].component.ts`
- Services: `[service-name].service.ts`
- Modules: `[module-name].module.ts`
- Guards: `[guard-name].guard.ts`
- Interceptors: `[interceptor-name].interceptor.ts`
- Models/Interfaces: `[model-name].interface.ts` or `[model-name].model.ts`
- Format: kebab-case

#### 21.12.2 Class Naming

- Components: `PascalCase` with `Component` suffix (e.g., `PolicyBookingComponent`)
- Services: `PascalCase` with `Service` suffix (e.g., `BookingService`)
- Interfaces: `PascalCase` (e.g., `Booking`, `BookingRequest`)
- Enums: `PascalCase` (e.g., `BookingStatus`)

#### 21.12.3 TypeScript Property Naming

- Properties: `camelCase`
- Constants: `UPPER_SNAKE_CASE`
- Private properties: prefix with `private` keyword

### 21.13 Security Guidelines

#### 21.13.1 Input Validation

- Validate all user inputs on client side
- Use AUG JSON field validators (required, minLength, maxLength, pattern, etc.)
- Implement cross-field validators for complex business rules
- Sanitize HTML inputs to prevent XSS attacks
- Use DomSanitizer for displaying dynamic HTML

#### 21.13.2 Secure Token Storage

- Never store tokens in localStorage (vulnerable to XSS)
- Use secure cookie storage or memory storage
- Use HttpOnly and Secure flags for cookies

#### 21.13.3 CORS Configuration

- Configure API Gateway to allow requests from UI domain
- Use credentials: 'include' for cross-origin requests with cookies

#### 21.13.4 Content Security Policy (CSP)

- Define CSP headers in index.html or server configuration
- Restrict script sources to prevent XSS attacks

### 21.14 Error Handling

#### 21.14.1 Global Error Handler

**Implementation:** Custom Angular ErrorHandler

**Responsibilities:**
- Log errors to monitoring service (CloudWatch, Datadog, etc.)
- Display user-friendly error messages
- Capture unhandled promise rejections

#### 21.14.2 HTTP Error Handling

**Implementation:** ErrorInterceptor

**HTTP Status Handling:**
- 401 Unauthorized: Redirect to login
- 403 Forbidden: Display "Access Denied" message
- 404 Not Found: Display "Resource Not Found"
- 500 Internal Server Error: Display "System Error" message
- Network errors: Display "Connection Error" message

### 21.15 Performance Optimization

#### 21.15.1 Lazy Loading

- Load feature modules on demand
- Reduces initial bundle size
- Improves Time to Interactive (TTI)

#### 21.15.2 Change Detection Strategy

- Use OnPush change detection for presentational components
- Reduces unnecessary change detection cycles
- Improves rendering performance

#### 21.15.3 Bundle Size Optimization

- Use lazy loading for feature modules
- Analyze bundle size with `ng build --stats-json`
- Eliminate unused dependencies
- Use tree-shakeable imports

#### 21.15.4 Caching Strategy

- Cache static assets with CloudFront
- Cache API responses in services when appropriate
- Use HTTP cache headers

### 21.16 Accessibility (A11y)

- Follow WCAG 2.1 Level AA standards
- Use semantic HTML elements
- Provide ARIA labels for screen readers
- Ensure keyboard navigation support
- Test with screen readers (JAWS, NVDA)

### 21.17 Summary

This UI Application Template provides comprehensive specifications for:

✅ **Technology Stack:** Angular 15 with AXIS framework
✅ **Architecture:** Modular architecture with lazy-loaded feature modules
✅ **Configuration:** Runtime config.json managed by DevOps pipeline
✅ **Authentication:** Okta OAuth 2.0 integration
✅ **API Integration:** Integration with Lambda services via API Gateway
✅ **State Management:** RxJS + Services pattern
✅ **AXIS Framework:** Dynamic UI generation with AXIS UI Generator
✅ **Testing:** Jasmine + Karma with 80% coverage requirement
✅ **Deployment:** S3 + CloudFront CDN deployment
✅ **Security:** Secure authentication, input validation, XSS prevention
✅ **Performance:** Lazy loading, OnPush change detection, bundle optimization

**Reference Implementation:** Development teams should refer to `C:\S3 Migration\Reference\scup-dwf-dc-ui-6225` for code examples while following these specifications.

