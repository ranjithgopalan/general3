# DynamoDB Design Specification

## Table of Contents
1. [System Overview](#system-overview)
2. [Table Schemas](#table-schemas)
   - [UI Component Catalog Table](#ui-component-catalog-table)
   - [Booking Component Status Table](#booking-component-status-table)
   - [Booking Reference Lookup Table](#booking-reference-lookup-table)
   - [Service Function Flows Table](#service-function-flows-table)
3. [Data Models](#data-models)
4. [Available Data](#available-data)
5. [Access Patterns](#access-patterns)
6. [Global Secondary Indexes (GSI)](#global-secondary-indexes-gsi)
7. [Best Practices](#best-practices)
8. [Implementation Considerations](#implementation-considerations)

## System Overview

This DynamoDB design supports two primary systems:

1. **Dynamic Angular UI System**: Where UI configurations are stored in the database and retrieved by a Node.js Lambda backend to generate dynamic frontend components
2. **Function Flow Configuration System**: For storing configurable function flow definitions that control the execution sequence of functions within Lambda services

### Technology Stack Compatibility
- **AWS DynamoDB**: Latest version compatible with AWS SDK v3.x
- **Runtime Integration**: Node.js 20.x Lambda functions
- **AWS SDK**: v3.x (DynamoDB client optimized for Node.js 20.x)
- **Data Format**: JSON documents with UTF-8 encoding
- **Query Libraries**: AWS SDK DynamoDB DocumentClient v3.x
- **Monitoring**: CloudWatch integration (compatible with Node.js 20.x runtime)

### Key Features
- Hierarchical UI structure (Applications > Pages > Sections > Components)
- Role-based access control
- Versioning support
- Dynamic component definitions
- Field validation rules
- Data binding configurations
- Layout and styling information
- Sequential function execution patterns
- Context object model for data passing

## Table Schemas

### UI Component Catalog Table

**Table Name**: `ui-component-catalog`
**Purpose**: Store UI component configurations organized by transaction type for dynamic Angular UI generation.

**Primary Key Structure**:
- **Partition Key**: `transactionType` (String) - Transaction type identifier (can be empty/blank for common components across all transaction types)
- **Sort Key**: `componentId` (String) - Component identifier

**Uniqueness Constraint**:
- **Unique Record**: Combination of `transactionType` + `componentId`
- **Duplicate Components Allowed**: Same componentId can exist with different transactionTypes
- **Record Identification**: Each record represents one component configuration for a specific transaction type

**Key Design Decisions**:
- Composite key design for transaction-specific component configurations
- Partition by transaction type for optimal querying and distribution
- Sort key enables multiple components per transaction type
- Supports both transaction-specific and common components (empty transactionType)
- Component specifications contain complete UI configuration

**Attributes**:
- `transactionType` (String): Transaction type identifier (can be empty/blank for common components)
- `componentId` (String): Component identifier
- `componentName` (String): Human-readable component name
- `componentSpecifications` (Map): Complete component specifications and configuration in JSON format

### Booking Component Status Table

**Table Name**: `booking-component-status`
**Purpose**: Track the status and progress of individual components within booking workflows for each booking session.

**Primary Key Structure**:
- **Partition Key**: `bookingId` (String) - Booking session identifier (not unique alone)
- **Sort Key**: `componentId` (String) - Component identifier within the booking

**Uniqueness Constraint**:
- **Unique Record**: Combination of `bookingId` + `componentId` (DynamoDB Primary Key)
- **Non-Unique Fields**: `bookingId` alone is not unique (same booking can have multiple components)
- **Record Identification**: Each record represents one component status for a specific booking

**Key Design Decisions**:
- Single table design for all booking component statuses
- Partition by booking ID for component grouping within each booking
- Sort key enables multiple components per booking
- Support for hierarchical component tracking within booking workflows
- Metadata field for component-specific flexible data storage
- Transaction type stored as attribute for context and filtering

**Attributes**:

| Attribute Name | Type | Description | Required |
|---------------|------|-------------|----------|
| `bookingId` | String | Unique booking session identifier (e.g., "550e8400-e29b-41d4-a716-446655440000") | Yes |
| `componentId` | String | Component identifier (e.g., "CLIENT_INFO", "breadCrumHeader") | Yes |
| `status` | String | Component status: "NOT_STARTED", "IN_PROGRESS", "COMPLETED" | Yes |
| `transactionType` | String | Transaction type identifier (e.g., "NB", "ENDORSEMENT", "RENEWAL") | Yes |
| `startedAt` | String | ISO 8601 timestamp when component was started | No |
| `completedAt` | String | ISO 8601 timestamp when component was completed | No |
| `lastUpdated` | String | ISO 8601 timestamp of last status update | Yes |
| `updatedBy` | String | User or system that updated the status | Yes |
| `componentOrder` | Number | Sequence order of component in workflow | No |
| `isRequired` | Boolean | Whether component is mandatory for completion | No |
| `currentPosition` | Boolean | Whether this component is the current active position in the workflow | No |
| `metadata` | Map | Component-specific metadata (JSON object, varies by component) | No |

### Booking Reference Lookup Table

**Table Name**: `booking-reference-lookup`
**Purpose**: Store reference data for various lookups used across the application (e.g., country codes, element values, policy office codes).

**Primary Key Structure**:
- **Partition Key**: `refGroupCode` (String) - Reference group code identifier (e.g., "COUNTRY", "PRODUCT", "CLIENT_TYPE")
- **Sort Key**: `dataElementName` (String) - Data element name identifier (e.g., "country", "productType", "clientType")

**Uniqueness Constraint**:
- **Unique Record**: Combination of `refGroupCode` + `dataElementName` + `dataElementCode`
- **Multiple Values per Group**: Same refGroupCode can have multiple dataElementName entries
- **Record Identification**: Each record represents one reference value within a reference group

**Key Design Decisions**:
- Single table design for all reference lookups
- Partition by reference group code for optimal querying and distribution
- Sort key enables multiple data elements per reference group
- ElementMap field provides flexible key-value pair storage for element-specific data
- Metadata fields for tracking status and updates

**Attributes**:

| Attribute Name | Type | Description | Required |
|---------------|------|-------------|----------|
| `refGroupCode` | String | Reference group code (e.g., "COUNTRY", "PRODUCT", "CLIENT_TYPE") | Yes |
| `dataElementName` | String | Data element name (e.g., "country", "productType", "clientType") | Yes |
| `dataElementCode` | String | Unique code for the data element (e.g., "167" for Spain country code) | Yes |
| `elementMap` | Map | Element-specific data in key-value format (e.g., countryCode, refcode, officecode, elementdesc) | Yes |
| `status` | String | Status of the reference data: "ACTIVE", "INACTIVE", "DEPRECATED" | Yes |
| `createdAt` | String | ISO 8601 timestamp when reference was created | Yes |
| `createdBy` | String | User or system that created the reference | Yes |
| `updatedAt` | String | ISO 8601 timestamp of last update | Yes |
| `updatedBy` | String | User or system that last updated the reference | Yes |

**Example Records**:

```json
{
  "refGroupCode": "COUNTRY",
  "dataElementName": "country",
  "dataElementCode": "167",
  "elementMap": {
    "countryCode": "167",
    "refcode": "0",
    "officecode": "0",
    "elementdesc": "spain"
  },
  "status": "ACTIVE",
  "createdAt": "2024-01-01T00:00:00Z",
  "createdBy": "system-admin",
  "updatedAt": "2024-01-15T10:00:00Z",
  "updatedBy": "system-admin"
}
```

```json
{
  "refGroupCode": "COUNTRY",
  "dataElementName": "country",
  "dataElementCode": "840",
  "elementMap": {
    "countryCode": "840",
    "refcode": "0",
    "officecode": "US01",
    "elementdesc": "united states"
  },
  "status": "ACTIVE",
  "createdAt": "2024-01-01T00:00:00Z",
  "createdBy": "system-admin",
  "updatedAt": "2024-01-15T10:00:00Z",
  "updatedBy": "system-admin"
}
```

```json
{
  "refGroupCode": "PRODUCT",
  "dataElementName": "productType",
  "dataElementCode": "VB-INT-HOL",
  "elementMap": {
    "productCode": "VB-INT-HOL",
    "refcode": "0",
    "officecode": "MULTI",
    "elementdesc": "VARIOUS BENEFITS-INT.HOLIDAY"
  },
  "status": "ACTIVE",
  "createdAt": "2024-01-01T00:00:00Z",
  "createdBy": "system-admin",
  "updatedAt": "2024-01-15T10:00:00Z",
  "updatedBy": "system-admin"
}
```

### Service Function Flows Table

**Table Name**: `service-function-flows`
**Purpose**: Store function flow configurations for different services and flow types

**Primary Key Structure**:
- **Partition Key**: `flowId` (String) - Unique flow identifier (e.g., "booking-initiate", "booking-submit")
- **Sort Key**: `version` (String) - Version identifier (e.g., "v1.0.0", "v1.1.0")

**Key Design Decisions**:
- Single table design for all service flows
- Partition by flow ID for optimal distribution
- Sort key enables versioning support
- Support for sequential function execution patterns
- Context object model for data passing

**Attributes**:

| Attribute Name | Type | Description | Required |
|---------------|------|-------------|----------|
| `flowId` | String | Unique flow identifier (e.g., "booking-initiate") | Yes |
| `version` | String | Version identifier (e.g., "v1.0.0") | Yes |
| `serviceId` | String | Service identifier (e.g., "booking-management-service") | Yes |
| `flowType` | String | Type of flow (e.g., "initiate", "submit", "cancel") | Yes |
| `flowName` | String | Human-readable flow name | Yes |
| `description` | String | Flow description and purpose | No |
| `isActive` | Boolean | Whether this flow version is currently active | Yes |
| `functions` | List | Sequential list of function definitions | Yes |
| `contextSchema` | Map | Expected context object schema | No |
| `createdAt` | String | ISO 8601 timestamp | Yes |
| `updatedAt` | String | ISO 8601 timestamp | Yes |
| `createdBy` | String | User who created the flow | Yes |
| `updatedBy` | String | User who last updated the flow | Yes |

## Data Models

### Function Definition Structure

Each function in the `functions` list contains:

| Attribute Name | Type | Description | Required |
|---------------|------|-------------|----------|
| `functionName` | String | Name of the function to execute | Yes |
| `order` | Number | Execution order (sequential) | Yes |
| `enabled` | Boolean | Whether the function is enabled for execution (if false, execution will be ignored) | Yes |
| `description` | String | Function description | No |
| `timeout` | Number | Function timeout in milliseconds | No |
| `retryPolicy` | Map | Retry configuration for the function | No |
| `configKeys` | List | List of configKeys where this function should execute | Yes |
| `skipConfigKeys` | List | List of configKeys where this function should be skipped | No |

### Retry Policy Structure

| Attribute Name | Type | Description | Required |
|---------------|------|-------------|----------|
| `maxRetries` | Number | Maximum number of retries | No |
| `backoffType` | String | Backoff strategy (exponential, linear, fixed) | No |
| `baseDelay` | Number | Base delay in milliseconds | No |

## Available Data

### UI Component Data

**Header Component**:
```json
{
  "transactionType": "",
  "componentId": "breadCrumHeader",
  "componentName": "Bread Crum Header",
  "componentSpecifications": {
    "type": "header",
    "layout": "horizontal",
    "backgroundColor": "#2E5266",
    "fields": [
      {
        "fieldId": "country",
        "label": "Country",
        "position": 1,
        "styling": {
          "color": "#FFFFFF",
          "fontWeight": "normal",
          "padding": "12px"
        }
      },
      {
        "fieldId": "clientName",
        "label": "Client Name",
        "position": 2,
        "styling": {
          "color": "#FFFFFF",
          "fontWeight": "normal",
          "padding": "12px"
        }
      },
      {
        "fieldId": "producerName",
        "label": "Producer Name",
        "position": 3,
        "styling": {
          "color": "#FFFFFF",
          "fontWeight": "normal",
          "padding": "12px"
        }
      }
    ],
    "styling": {
      "height": "60px",
      "borderBottom": "1px solid #1A3A4A",
      "display": "flex",
      "alignItems": "center"
    }
  }
}
```

**NB Footer Component**:
```json
{
  "transactionType": "NB",
  "componentId": "breadCrumFooter",
  "componentName": "Bread Crum Footer",
  "componentSpecifications": {
    "type": "footer",
    "layout": "horizontal",
    "backgroundColor": "#2E5266",
    "buttons": [
      {
        "buttonId": "clientData",
        "label": "Client Data",
        "position": 1,
        "type": "secondary",
        "styling": {
          "backgroundColor": "#FFFFFF",
          "color": "#333333",
          "border": "1px solid #CCCCCC",
          "borderRadius": "4px",
          "padding": "8px 16px",
          "fontSize": "14px",
          "fontWeight": "normal",
          "margin": "0 8px"
        }
      },
      {
        "buttonId": "policyRemarks",
        "label": "Policy Remarks",
        "position": 2,
        "type": "secondary",
        "styling": {
          "backgroundColor": "#FFFFFF",
          "color": "#333333",
          "border": "1px solid #CCCCCC",
          "borderRadius": "4px",
          "padding": "8px 16px",
          "fontSize": "14px",
          "fontWeight": "normal",
          "margin": "0 8px"
        }
      },
      {
        "buttonId": "cancel",
        "label": "Cancel",
        "position": 3,
        "type": "secondary",
        "styling": {
          "backgroundColor": "#FFFFFF",
          "color": "#333333",
          "border": "1px solid #CCCCCC",
          "borderRadius": "4px",
          "padding": "8px 16px",
          "fontSize": "14px",
          "fontWeight": "normal",
          "margin": "0 8px"
        }
      },
      {
        "buttonId": "next",
        "label": "Next",
        "position": 4,
        "type": "primary",
        "action": {
          "url": "TBD",
          "method": "POST"
        },
        "styling": {
          "backgroundColor": "#FFFFFF",
          "color": "#333333",
          "border": "1px solid #CCCCCC",
          "borderRadius": "4px",
          "padding": "8px 16px",
          "fontSize": "14px",
          "fontWeight": "normal",
          "margin": "0 8px"
        }
      }
    ],
    "styling": {
      "height": "60px",
      "borderTop": "1px solid #1A3A4A",
      "display": "flex",
      "alignItems": "center",
      "justifyContent": "space-between",
      "padding": "0 20px"
    }
  }
}
```

**NB Client Information Component**:
```json
{
  "transactionType": "NB",
  "componentId": "clientInformation",
  "componentName": "Client Information",
  "componentSpecifications": {
    "type": "form",
    "layout": "grid",
    "backgroundColor": "#FFFFFF",
    "sections": [
      {
        "sectionId": "clientDetails",
        "title": "Client Information",
        "position": 1,
        "fields": [
          {
            "fieldId": "clientName",
            "label": "Client Name",
            "type": "text",
            "required": true,
            "position": 1,
            "gridColumn": "1 / 2",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "clientNumber",
            "label": "Client Number",
            "type": "text",
            "required": false,
            "position": 2,
            "gridColumn": "2 / 3",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "searchButton",
            "label": "Search",
            "type": "button",
            "position": 3,
            "gridColumn": "3 / 4",
            "action": {
              "url": "TBD",
              "method": "GET"
            },
            "styling": {
              "backgroundColor": "#F0F0F0",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px",
              "padding": "8px 16px",
              "cursor": "pointer"
            }
          },
          {
            "fieldId": "country",
            "label": "Country",
            "type": "text",
            "required": false,
            "position": 4,
            "gridColumn": "1 / 2",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "dAndBNumber",
            "label": "D&B Number",
            "type": "text",
            "required": false,
            "position": 5,
            "gridColumn": "2 / 3",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "clientType",
            "label": "Client Type",
            "type": "dropdown",
            "required": false,
            "position": 6,
            "gridColumn": "3 / 4",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "addAdditionalInsured",
            "label": "Add Additional Insured",
            "type": "link",
            "position": 7,
            "gridColumn": "3 / 4",
            "styling": {
              "color": "#0066CC",
              "textDecoration": "underline",
              "cursor": "pointer",
              "fontSize": "14px"
            }
          }
        ]
      },
      {
        "sectionId": "addressDetails",
        "title": "Address Details",
        "position": 2,
        "fields": [
          {
            "fieldId": "addressLine1",
            "label": "Address Line 1",
            "type": "text",
            "required": false,
            "position": 1,
            "gridColumn": "1 / 2",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "addressLine2",
            "label": "Address Line 2",
            "type": "text",
            "required": false,
            "position": 2,
            "gridColumn": "2 / 3",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "addressLine3",
            "label": "Address Line 3",
            "type": "text",
            "required": false,
            "position": 3,
            "gridColumn": "3 / 4",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "cityTown",
            "label": "City/Town",
            "type": "text",
            "required": false,
            "position": 4,
            "gridColumn": "1 / 2",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "postalCode",
            "label": "Postal Code",
            "type": "text",
            "required": false,
            "position": 5,
            "gridColumn": "2 / 3",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "addressCountry",
            "label": "Country",
            "type": "text",
            "required": false,
            "position": 6,
            "gridColumn": "3 / 4",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "language",
            "label": "Language",
            "type": "text",
            "required": false,
            "position": 7,
            "gridColumn": "1 / 2",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "email",
            "label": "Email",
            "type": "email",
            "required": false,
            "position": 8,
            "gridColumn": "2 / 3",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "phoneNumber",
            "label": "Phone Number",
            "type": "tel",
            "required": false,
            "position": 9,
            "gridColumn": "3 / 4",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "fiscalCode",
            "label": "Fiscal Code",
            "type": "text",
            "required": false,
            "position": 10,
            "gridColumn": "1 / 2",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "directDebit",
            "label": "Direct Debit",
            "type": "checkbox",
            "required": false,
            "position": 11,
            "gridColumn": "2 / 3",
            "styling": {
              "marginTop": "8px"
            }
          }
        ]
      }
    ],
    "styling": {
      "padding": "20px",
      "border": "1px solid #CCCCCC",
      "borderRadius": "8px",
      "backgroundColor": "#FFFFFF",
      "display": "grid",
      "gridTemplateColumns": "1fr 1fr 1fr",
      "gap": "16px"
    }
  }
}
```

**NB Sidebar Component**:
```json
{
  "transactionType": "NB",
  "componentId": "breadCrumSidebar",
  "componentName": "Bread crum Sidebar",
  "componentSpecifications": {
    "type": "sidebar",
    "layout": "vertical",
    "backgroundColor": "#F8F9FA",
    "width": "250px",
    "menuItems": [
      {
        "itemId": "clientInformation",
        "label": "Client Information",
        "position": 1,
        "isSection": false,
        "styling": {
          "color": "#333333",
          "fontSize": "14px",
          "padding": "8px 16px",
          "borderBottom": "1px solid #E0E0E0"
        }
      },
      {
        "itemId": "producerInformation",
        "label": "Producer Information",
        "position": 2,
        "isSection": false,
        "styling": {
          "color": "#333333",
          "fontSize": "14px",
          "padding": "8px 16px",
          "borderBottom": "1px solid #E0E0E0"
        }
      },
      {
        "itemId": "productPolicyInformation",
        "label": "Product & Policy Information",
        "position": 3,
        "isSection": false,
        "styling": {
          "color": "#333333",
          "fontSize": "14px",
          "padding": "8px 16px",
          "borderBottom": "1px solid #E0E0E0"
        }
      },
      {
        "itemId": "policyDetails",
        "label": "Policy Details",
        "position": 4,
        "isSection": false,
        "styling": {
          "color": "#333333",
          "fontSize": "14px",
          "padding": "8px 16px",
          "borderBottom": "1px solid #E0E0E0"
        }
      },
      {
        "itemId": "multinational",
        "label": "Multinational",
        "position": 5,
        "isSection": false,
        "styling": {
          "color": "#333333",
          "fontSize": "14px",
          "padding": "8px 16px",
          "borderBottom": "1px solid #E0E0E0"
        }
      },
      {
        "itemId": "addressLocation",
        "label": "Address/Location",
        "position": 6,
        "isSection": false,
        "styling": {
          "color": "#333333",
          "fontSize": "14px",
          "padding": "8px 16px",
          "borderBottom": "1px solid #E0E0E0"
        }
      },
      {
        "itemId": "rating",
        "label": "Rating",
        "position": 7,
        "isSection": false,
        "styling": {
          "color": "#333333",
          "fontSize": "14px",
          "padding": "8px 16px",
          "borderBottom": "1px solid #E0E0E0"
        }
      },
      {
        "itemId": "coinsurance",
        "label": "Coinsurance",
        "position": 8,
        "isSection": false,
        "styling": {
          "color": "#333333",
          "fontSize": "14px",
          "padding": "8px 16px",
          "borderBottom": "1px solid #E0E0E0"
        }
      },
      {
        "itemId": "reinsurance",
        "label": "Reinsurance",
        "position": 9,
        "isSection": false,
        "styling": {
          "color": "#333333",
          "fontSize": "14px",
          "padding": "8px 16px",
          "borderBottom": "1px solid #E0E0E0"
        }
      },
      {
        "itemId": "feesCharges",
        "label": "Fees & Charges",
        "position": 10,
        "isSection": false,
        "styling": {
          "color": "#333333",
          "fontSize": "14px",
          "padding": "8px 16px",
          "borderBottom": "1px solid #E0E0E0"
        }
      },
      {
        "itemId": "bookingSummary",
        "label": "Booking Summary",
        "position": 11,
        "isSection": false,
        "styling": {
          "color": "#333333",
          "fontSize": "14px",
          "padding": "8px 16px",
          "borderBottom": "1px solid #E0E0E0"
        }
      }
    ],
    "styling": {
      "border": "1px solid #D0D0D0",
      "borderRadius": "4px",
      "boxShadow": "0 2px 4px rgba(0,0,0,0.1)"
    }
  }
}
```

### Function Flow Data

**Booking Management Service - Initiate Flow**:
```json
{
  "flowId": "booking-initiate",
  "version": "v1.0.0",
  "serviceId": "booking-management-service",
  "flowType": "initiate",
  "flowName": "Booking Initiation Flow",
  "description": "Configurable flow for initiating booking sessions with different execution paths",
  "isActive": true,
  "functions": [
    {
      "functionName": "extractBearerToken",
      "order": 1,
      "enabled": true,
      "description": "Extract bearer token from Authorization header",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "validateToken",
      "order": 2,
      "enabled": true,
      "description": "Validate JWT bearer token",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "checkUserPermissions",
      "order": 3,
      "enabled": true,
      "description": "Check user permissions for booking initiation",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium"],
      "skipConfigKeys": ["express"]
    },
    {
      "functionName": "validatePremiumLimits",
      "order": 4,
      "enabled": true,
      "description": "Validate premium user limits and quotas",
      "timeout": 3000,
      "configKeys": ["premium"]
    },
    {
      "functionName": "validateRequestParameters",
      "order": 5,
      "enabled": true,
      "description": "Validate incoming request parameters",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "generateBookingId",
      "order": 6,
      "enabled": true,
      "description": "Generate unique booking identifier",
      "timeout": 2000,
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "saveBookingId",
      "order": 7,
      "enabled": true,
      "description": "Save booking record to PostgreSQL database",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 3,
        "backoffType": "exponential",
        "baseDelay": 1000
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "formatResponse",
      "order": 8,
      "enabled": true,
      "description": "Format success response",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    }
  ],
  "contextSchema": {
    "headers": "Map",
    "body": "Map",
    "user": "Map",
    "permissions": "Map",
    "booking": "Map",
    "response": "Map"
  },
  "createdAt": "2024-01-15T10:00:00Z",
  "updatedAt": "2024-01-15T10:00:00Z",
  "createdBy": "system-admin",
  "updatedBy": "system-admin"
}
```

**UI Components Service - Next Component Flow**:
```json
{
  "flowId": "next-component-get",
  "version": "v1.0.0",
  "serviceId": "ui-components-service",
  "flowType": "get",
  "flowName": "Next Component Retrieval Flow",
  "description": "Configurable flow for automatically retrieving the next UI component based on currentPosition in booking workflow",
  "isActive": true,
  "functions": [
    {
      "functionName": "extractBearerToken",
      "order": 1,
      "enabled": true,
      "description": "Extract bearer token from Authorization header",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "validateToken",
      "order": 2,
      "enabled": true,
      "description": "Validate JWT bearer token",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "checkUserPermissions",
      "order": 3,
      "enabled": true,
      "description": "Check user permissions for UI component access",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium"],
      "skipConfigKeys": ["express"]
    },
    {
      "functionName": "validateRequestParameters",
      "order": 4,
      "enabled": true,
      "description": "Validate incoming request parameters (bookingId, transactionType) and extract context.transactionType from query parameters",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "determineCurrentComponent",
      "order": 5,
      "enabled": true,
      "description": "Query booking-component-status table to find component with currentPosition = true for specified transactionType and set context.componentId",
      "timeout": 3000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "queryUIComponent",
      "order": 6,
      "enabled": true,
      "description": "Query UI component from DynamoDB ui-component-catalog table with transactionType fallback logic: (1) Query with specific transactionType, (2) If not found, query with blank transactionType for common components",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 3,
        "backoffType": "exponential",
        "baseDelay": 1000
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "queryPOMSchema",
      "order": 7,
      "enabled": true,
      "description": "Query POM schema from S3 based on component configuration",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "loadReferenceData",
      "order": 8,
      "enabled": true,
      "description": "Load reference data from booking-reference-lookup table for component fields (e.g., country dropdown). Query by refGroupCode and filter for ACTIVE status. Results include elementMap with element-specific data. Add results to context.referenceData",
      "timeout": 3000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "queryBookingComponentMetadata",
      "order": 9,
      "enabled": true,
      "description": "Query booking-component-status table to retrieve component metadata and add to context.workflowMetadata",
      "timeout": 3000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "formatResponse",
      "order": 10,
      "enabled": true,
      "description": "Format success response with componentConfiguration, pomSchema, referenceData, and workflowMetadata",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    }
  ],
  "contextSchema": {
    "headers": "Map",
    "pathParameters": "Map",
    "queryParameters": "Map",
    "user": "Map",
    "permissions": "Map",
    "componentId": "String",
    "transactionType": "String",
    "componentData": "Map",
    "pomSchema": "Map",
    "referenceData": "Map",
    "workflowMetadata": "Map",
    "response": "Map"
  },
  "createdAt": "2024-01-15T10:00:00Z",
  "updatedAt": "2024-01-15T10:00:00Z",
  "createdBy": "system-admin",
  "updatedBy": "system-admin"
}
```

**UI Components Service - Get Component Flow**:
```json
{
  "flowId": "ui-components-get",
  "version": "v1.0.0",
  "serviceId": "ui-components-service",
  "flowType": "get",
  "flowName": "UI Component Retrieval Flow",
  "description": "Configurable flow for retrieving specific UI component configurations by componentId and transactionType",
  "isActive": true,
  "functions": [
    {
      "functionName": "extractBearerToken",
      "order": 1,
      "enabled": true,
      "description": "Extract bearer token from Authorization header",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "validateToken",
      "order": 2,
      "enabled": true,
      "description": "Validate JWT bearer token",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "checkUserPermissions",
      "order": 3,
      "enabled": true,
      "description": "Check user permissions for component access",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium"],
      "skipConfigKeys": ["express"]
    },
    {
      "functionName": "validateRequestParameters",
      "order": 4,
      "enabled": true,
      "description": "Validate incoming request parameters (bookingId, componentId, transactionType) and extract context parameters",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "queryUIComponent",
      "order": 5,
      "enabled": true,
      "description": "Query UI component from DynamoDB ui-component-catalog table with transactionType fallback logic",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 3,
        "backoffType": "exponential",
        "baseDelay": 1000
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "queryPOMSchema",
      "order": 6,
      "enabled": true,
      "description": "Query POM schema from S3 based on component configuration",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "loadReferenceData",
      "order": 7,
      "enabled": true,
      "description": "Load reference data from booking-reference-lookup table for component fields (e.g., country dropdown). Query by refGroupCode and filter for ACTIVE status. Results include elementMap with element-specific data. Add results to context.referenceData",
      "timeout": 3000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "queryBookingComponentMetadata",
      "order": 8,
      "enabled": true,
      "description": "Query booking-component-status table to retrieve component metadata and workflow information",
      "timeout": 3000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "formatResponse",
      "order": 9,
      "enabled": true,
      "description": "Format success response with componentConfiguration, pomSchema, referenceData, and workflowMetadata",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    }
  ],
  "contextSchema": {
    "headers": "Map",
    "pathParameters": "Map",
    "queryParameters": "Map",
    "user": "Map",
    "permissions": "Map",
    "componentId": "String",
    "transactionType": "String",
    "componentData": "Map",
    "pomSchema": "Map",
    "referenceData": "Map",
    "workflowMetadata": "Map",
    "response": "Map"
  },
  "createdAt": "2024-01-15T10:00:00Z",
  "updatedAt": "2024-01-15T10:00:00Z",
  "createdBy": "system-admin",
  "updatedBy": "system-admin"
}
```

**UI Components Service - Initialize Booking Workflow Flow**:
```json
{
  "flowId": "booking-workflow-initialize",
  "version": "v1.0.0",
  "serviceId": "ui-components-service",
  "flowType": "initialize",
  "flowName": "Booking Workflow Initialization Flow",
  "description": "Configurable flow for initializing booking workflow and retrieving current component configuration with workflow metadata",
  "isActive": true,
  "functions": [
    {
      "functionName": "extractBearerToken",
      "order": 1,
      "enabled": true,
      "description": "Extract bearer token from Authorization header",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "validateToken",
      "order": 2,
      "enabled": true,
      "description": "Validate JWT bearer token",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "checkUserPermissions",
      "order": 3,
      "enabled": true,
      "description": "Check user permissions for booking state access",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium"],
      "skipConfigKeys": ["express"]
    },
    {
      "functionName": "validateRequestParameters",
      "order": 4,
      "enabled": true,
      "description": "Validate incoming request parameters (bookingId, transactionType)",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "checkBookingExists",
      "order": 5,
      "enabled": true,
      "description": "Check if booking and transactionType exist in booking-component-status table and set context.bookingExists flag",
      "timeout": 3000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "determineCurrentComponent",
      "order": 6,
      "enabled": true,
      "description": "If booking doesn't exist, initialize components and set context.componentId. If exists, query booking-component-status for currentPosition=true component and set context.componentId",
      "timeout": 8000,
      "retryPolicy": {
        "maxRetries": 3,
        "backoffType": "exponential",
        "baseDelay": 1000
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "queryUIComponent",
      "order": 7,
      "enabled": true,
      "description": "Query ui-component-catalog table using context.componentId with transaction-specific and common component fallback",
      "timeout": 3000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "queryPOMSchema",
      "order": 8,
      "enabled": true,
      "description": "Query POM schema from S3 based on component configuration",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "loadReferenceData",
      "order": 9,
      "enabled": true,
      "description": "Load reference data from booking-reference-lookup table for component fields (e.g., country dropdown). Query by refGroupCode and filter for ACTIVE status. Results include elementMap with element-specific data. Add results to context.referenceData",
      "timeout": 3000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "queryBookingComponentMetadata",
      "order": 10,
      "enabled": true,
      "description": "Query booking-component-status table to retrieve component metadata and add to context.workflowMetadata",
      "timeout": 3000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "formatResponse",
      "order": 11,
      "enabled": true,
      "description": "Format success response with componentConfiguration, pomSchema, referenceData, and workflowMetadata",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    }
  ],
  "contextSchema": {
    "headers": "Map",
    "pathParameters": "Map",
    "queryParameters": "Map",
    "user": "Map",
    "permissions": "Map",
    "bookingExists": "Boolean",
    "componentsInitialized": "Boolean",
    "currentComponentId": "String",
    "componentData": "Map",
    "pomSchema": "Map",
    "referenceData": "Map",
    "workflowMetadata": "Map",
    "stateData": "Map",
    "response": "Map"
  },
  "createdAt": "2024-01-15T10:00:00Z",
  "updatedAt": "2024-01-15T10:00:00Z",
  "createdBy": "system-admin",
  "updatedBy": "system-admin"
}
```

**UI Components Service - Update Component Status Flow**:
```json
{
  "flowId": "component-status-update",
  "version": "v1.0.0",
  "serviceId": "ui-components-service",
  "flowType": "update",
  "flowName": "Component Status Update Flow",
  "description": "Configurable flow for updating component status with business validations and workflow progression",
  "isActive": true,
  "functions": [
    {
      "functionName": "extractBearerToken",
      "order": 1,
      "enabled": true,
      "description": "Extract bearer token from Authorization header",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "validateToken",
      "order": 2,
      "enabled": true,
      "description": "Validate JWT bearer token",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "checkUserPermissions",
      "order": 3,
      "enabled": true,
      "description": "Check user permissions for component status updates",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium"],
      "skipConfigKeys": ["express"]
    },
    {
      "functionName": "validateRequestParameters",
      "order": 4,
      "enabled": true,
      "description": "Validate incoming request parameters (bookingId, componentId, status) and extract context parameters",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "validateComponentDataAgainstPOM",
      "order": 5,
      "enabled": true,
      "description": "Validate component data against POM schema from S3",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "businessValidations",
      "order": 6,
      "enabled": true,
      "description": "Execute business validation logic using context.componentId and context.body payload - Placeholder for component-specific business rules, external system cross-references, and validation logic",
      "timeout": 8000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 1000
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "updateComponentStatus",
      "order": 7,
      "enabled": true,
      "description": "Update component status in booking-component-status table",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 3,
        "backoffType": "exponential",
        "baseDelay": 1000
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "updateWorkflowProgression",
      "order": 8,
      "enabled": true,
      "description": "Update workflow progression based on navigation type (sidebar vs next button) and manage currentPosition flags",
      "timeout": 5000,
      "retryPolicy": {
        "maxRetries": 2,
        "backoffType": "exponential",
        "baseDelay": 500
      },
      "configKeys": ["default", "premium", "express"]
    },
    {
      "functionName": "formatResponse",
      "order": 9,
      "enabled": true,
      "description": "Format success response with updated status and workflow progress",
      "timeout": 1000,
      "configKeys": ["default", "premium", "express"]
    }
  ],
  "contextSchema": {
    "headers": "Map",
    "pathParameters": "Map",
    "queryParameters": "Map",
    "body": "Map",
    "user": "Map",
    "permissions": "Map",
    "componentId": "String",
    "nextComponentId": "String",
    "validatedComponentData": "Map",
    "businessValidationResults": "Map",
    "statusUpdateResult": "Map",
    "workflowProgression": "Map",
    "response": "Map"
  },
  "createdAt": "2024-01-15T10:00:00Z",
  "updatedAt": "2024-01-15T10:00:00Z",
  "createdBy": "system-admin",
  "updatedBy": "system-admin"
}
```

## Access Patterns

### UI Component Catalog Access Patterns

1. **Get All Components for Specific Transaction Type**
   - PK: `{transactionType}` (e.g., "NEW_BUSINESS", "ENDORSEMENT")
   - Query all components for that transaction type

2. **Get Common Components (All Transaction Types)**
   - PK: `""` (empty string)
   - Query all components that are common across transaction types

3. **Get Specific Component**
   - PK: `{transactionType}` or `""` for common components
   - SK: `{componentId}`

4. **Get All Components (Transaction-Specific + Common)**
   - Query PK = `{transactionType}` for transaction-specific components
   - Query PK = `""` for common components
   - Combine results in application logic

5. **Get Components by Display Order**
   - Use GSI on displayOrder to get components sorted by order

### Booking Reference Lookup Access Patterns

1. **Get All Reference Values for a Reference Group**
   - PK: `{refGroupCode}` (e.g., "COUNTRY", "PRODUCT")
   - Query all data elements for that reference group
   - **Usage**: Populate dropdown lists, validate input values for all elements in a group

2. **Get Specific Reference Value by Data Element**
   - PK: `{refGroupCode}` (e.g., "COUNTRY")
   - SK: `{dataElementName}` (e.g., "country")
   - **Usage**: Retrieve specific data element configuration and associated metadata

3. **Get Specific Reference Value by Code**
   - PK: `{refGroupCode}`
   - SK: `{dataElementName}`
   - Filter: `dataElementCode = "{code}"` (e.g., "167" for Spain)
   - **Usage**: Validate specific reference code, retrieve element details

4. **Get Active Reference Values**
   - PK: `{refGroupCode}`
   - Filter: `status = "ACTIVE"`
   - **Usage**: Populate UI dropdowns with only active values

5. **Get Reference Values by Office Code**
   - Query with `refGroupCode` and filter by `elementMap.officecode`
   - **Usage**: Filter reference data by office location

6. **Get Reference Value by Element Description**
   - Query with `refGroupCode` and filter by `elementMap.elementdesc`
   - **Usage**: Search reference data by human-readable description

### Function Flow Access Patterns

#### Primary Access Patterns

1. **Get Specific Flow Version**
   - **Pattern**: Get specific flow version
   - **Key**: `flowId = "booking-initiate"` AND `version = "v1.0.0"`
   - **Usage**: Lambda runtime flow execution

2. **Get Latest Active Flow**
   - **Pattern**: Get latest active version of a flow
   - **Key**: `flowId = "booking-initiate"` with filter `isActive = true`
   - **Usage**: Runtime flow execution when version is not specified

3. **List All Versions of Flow**
   - **Pattern**: Get all versions of a specific flow
   - **Key**: `flowId = "booking-initiate"`
   - **Usage**: Flow version management and rollback

#### Secondary Access Patterns

4. **Get Flows by Service**
   - **Usage**: Service configuration management
   - **Implementation**: GSI query on `serviceId`

5. **Get Flows by Type**
   - **Usage**: Flow type analysis across services
   - **Implementation**: GSI query on `flowType`

6. **Get Active Flows**
   - **Usage**: Configuration validation and deployment
   - **Implementation**: GSI query on `isActive = true`

## Global Secondary Indexes (GSI)

### UI Component Catalog GSIs

#### GSI1: EntityType-Status-Index
**GSI1PK**: EntityType (String)
**GSI1SK**: Status#UpdatedAt (String)
**Purpose**: Query entities by type and status, ordered by update time
**Use Cases**:
- Get all active pages
- Get all draft components
- Get recently updated entities

#### GSI2: ParentId-Order-Index
**GSI2PK**: ParentId (String)
**GSI2SK**: Order (Number)
**Purpose**: Query child entities ordered by display order
**Use Cases**:
- Get all sections of a page in display order
- Get all fields of a form in order

#### GSI3: CreatedBy-CreatedAt-Index
**GSI3PK**: CreatedBy (String)
**GSI3SK**: CreatedAt (String)
**Purpose**: Query entities by creator
**Use Cases**:
- Get all entities created by a user
- Audit trail queries

#### GSI4: DataSource-Index
**GSI4PK**: DataSourceId (String)
**GSI4SK**: EntityType#EntityId (String)
**Purpose**: Find all entities using a specific data source
**Use Cases**:
- Impact analysis when data source changes
- Data source dependency tracking

### Function Flow GSIs

#### GSI1: serviceId-flowType-index

**Purpose**: Query flows by service and flow type

| Attribute Name | Key Type |
|---------------|----------|
| `serviceId` | Partition Key |
| `flowType` | Sort Key |

**Projected Attributes**: ALL

**Use Cases**:
- Get all flows for a specific service
- Get flows by type within a service
- Service configuration management

#### GSI2: flowType-isActive-index

**Purpose**: Query flows by type and active status

| Attribute Name | Key Type |
|---------------|----------|
| `flowType` | Partition Key |
| `isActive` | Sort Key |

**Projected Attributes**: ALL

**Use Cases**:
- Get all active flows by type
- Cross-service flow type analysis
- Configuration deployment validation

#### GSI3: isActive-updatedAt-index

**Purpose**: Query active flows and recently updated flows

| Attribute Name | Key Type |
|---------------|----------|
| `isActive` | Partition Key |
| `updatedAt` | Sort Key |

**Projected Attributes**: ALL

**Use Cases**:
- Get all active flows
- Get recently updated flows
- Configuration change monitoring

## Best Practices

### 1. Data Modeling
- Use composite keys to enable efficient querying
- Denormalize data to avoid multiple queries
- Use single-table design where possible
- Store related data together using sort key prefixes

### 2. Access Patterns
- Design keys based on access patterns, not entity relationships
- Use GSIs sparingly - only for essential access patterns
- Batch related queries using composite keys
- Use begins_with() for hierarchical queries

### 3. Performance Optimization
- Use consistent naming conventions for keys
- Keep item sizes under 400KB
- Use projection expressions to fetch only needed attributes
- Implement pagination for large result sets

### 4. Versioning Strategy
- Use "latest" as a special version identifier
- Keep version history for rollback capabilities
- Implement soft deletes using status field
- Use timestamps for audit trails

### 5. Security
- Implement row-level security through access control
- Use IAM roles for service-to-service authentication
- Encrypt sensitive data at rest and in transit
- Audit all configuration changes

### 6. Caching Strategy
- Cache frequently accessed configurations in Redis/ElastiCache
- Use TTL for cache invalidation
- Implement cache warming for critical configurations
- Use ETag headers for client-side caching

## Implementation Considerations

### 1. Error Handling
- Implement comprehensive error handling for missing configurations
- Provide fallback configurations for critical components
- Log all configuration access for debugging
- Use circuit breaker pattern for external data sources

### 2. Migration Strategy
- Use blue-green deployment for configuration updates
- Implement configuration validation before deployment
- Maintain backward compatibility during transitions
- Use feature flags for gradual rollouts

### 3. Monitoring and Observability
- Monitor DynamoDB performance metrics
- Track configuration usage patterns
- Set up alerts for configuration failures
- Implement distributed tracing for debugging

### 4. Table Configuration

#### Capacity Settings

**Provisioned Mode** (recommended for predictable workloads):
- **Read Capacity Units**: 10 RCU
- **Write Capacity Units**: 5 WCU

**On-Demand Mode** (recommended for variable workloads):
- Auto-scaling based on demand

#### Additional Settings

- **Point-in-time Recovery**: Enabled
- **Encryption**: AWS managed keys
- **Backup**: Daily automated backups
- **TTL**: Not applicable (configuration data)
- **Streams**: Enabled for configuration change notifications

This comprehensive DynamoDB design provides a scalable, flexible foundation for both dynamic Angular UI systems and configurable function flows, supporting complex hierarchical structures, role-based access control, versioning, and maintaining optimal performance characteristics.