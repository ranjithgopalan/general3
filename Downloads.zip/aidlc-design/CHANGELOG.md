# AIDLC-design Plugin Changelog

## **1.5.1** - Remove Angular Reactive Forms References from TDD Output (2026-02-28)

### Breaking Changes

- **US801185**: Complete removal of Angular Reactive Forms references from all TDD output
  - Replaced all Reactive Forms patterns with AUG (Axis UI Generator) JSON-based form generation
  - TDD output now exclusively references AUG patterns for form specifications
  - This is a **breaking change** for teams expecting Reactive Forms patterns in generated TDDs

### Agent Updates

- **design-guidelines.md** (Lines 18-21, 348-395, 589-593):
  - Updated `UIPatterns` capability from "Reactive forms" to "AUG-based form specifications"
  - Completely rewrote "Forms and Validation" section (Lines 348-395):
    - Removed: Reactive Forms Setup, `NonNullableFormBuilder`, `FormGroup`, `FormArray`
    - Added: AUG-Based Form Specification (HLR-12 Compliant) with `*.aug.json` schema patterns
    - Updated: Cross-Field Validation to use TypeScript functions with concise spec format (HLR-14)
    - Added: Field-Level Validators, Async Validators, Conditional Field Behavior via `displayIf`/`requiredIf`
    - Updated: Form State Management to reference axis-ui-generator runtime behavior
  - Updated "Data Flow Guidelines" Stage 1 (Lines 589-593):
    - Changed from "Angular forms" to "Axis UI forms (dynamically generated from AUG JSON schema)"
    - Changed from "reactive forms" to "axis-ui-generator at runtime"

### Test Updates

- **ui_tdd_generation.test** (Lines 141-142):
  - Removed `FormGroup` and `Reactive-Forms` from expected keywords
  - Tests now expect AUG-related terms in generated TDD output

- **ui_tdd_cross_field_validation.test** (Lines 14, 47-224, 282-287):
  - Updated Master TDD Context from "Reactive forms with custom validators" to "AUG-based form generation (HLR-12)"
  - Replaced full TypeScript component class (with `FormGroup` signals) with component interface tables (HLR-14 compliant)
  - Added complete AUG JSON schema example for form structure
  - Replaced 5 full validator implementations (~125 lines) with concise validator specifications (~25 lines) - **80% reduction**
  - Updated expected keywords: removed `ValidatorFn`, `AbstractControl`, `FormGroup`, `Reactive-Forms`; added `HLR-1`, `HLR-12`, `HLR-14`, `concise-spec`, `Input-Output-table`, `component-interface`

### Reference Documentation Updates

- **master-tdd-full-updated.md** (Lines 3589, 3904, 3950, 4077):
  - Updated Technology Stack: "Angular Reactive Forms" → "Axis UI Generator (AUG) - JSON-based dynamic form generation"
  - Updated State Management: "Form state: Angular Reactive Forms" → "Form state: Axis UI Generator (AUG) with JSON schema"
  - Updated Dynamic UI Usage: "Form data bound to Angular Reactive Forms" → "Form state managed by axis-ui-generator at runtime"
  - Updated Input Validation: "Use Angular Reactive Forms validators" → "Use AUG JSON field validators (required, minLength, maxLength, pattern, etc.)"

### Validation Results

- ✅ **Zero Reactive Forms references** remain in the plugin (verified via automated grep search)
- ✅ **All AUG patterns correctly implemented** across 4 files
- ✅ **Full alignment with HLR-12** (AUG Conformance), **HLR-14** (Code Minimalism), and **HLR-1** (Cross-Field Validation)
- ✅ **No contradictions** between agent operational constraints and design guidelines

### Impact Summary

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Validator Specs (Lines)** | ~125 lines (5 full implementations) | ~25 lines (5 concise specs) | 80% reduction |
| **Test File Size** | 289 lines | 189 lines | 35% reduction |
| **Overall Plugin Size** | Baseline | -90 lines net | Leaner, more maintainable |

### Files Modified

| File | Lines Changed | Net Change |
|------|---------------|------------|
| `agents/design-guidelines.md` | ~50 | +7 |
| `__tests__/ui_tdd_generation.test` | 2 | -1 |
| `__tests__/ui_tdd_cross_field_validation.test` | ~200 | -100 |
| `__tests__/reference/master-tdd-full-updated.md` | 4 | +4 |
| **TOTAL** | **~256** | **-90** |

### Migration Guide for Users

**If you are upgrading from v1.5.0 or earlier:**

1. **Expect different TDD output format:**
   - Generated UI-TDDs will now contain AUG JSON schemas (*.aug.json) instead of Reactive Forms code
   - Component interfaces will be documented via tables, not TypeScript code blocks
   - Validators will be concise specifications, not full implementations

2. **Update your expectations:**
   - DO expect: `displayIf`, `requiredIf`, `axis-ui-generator`, AUG JSON structure
   - DO NOT expect: `FormGroup`, `FormBuilder`, `FormControl`, `ReactiveFormsModule`

3. **Regenerate existing TDDs** if they were created with older versions and need to align with current standards
### New Features

- **US801180 (HLR-18)**: Custom component generation for premium features with multi-tiered and nested structures

  **TA2232990 — Analysis and documentation of premium feature component patterns:**
  - Analyzed premium feature component patterns: Page Container (Tier 1), Feature Container (Tier 2),
    Composite (Tier 3), and Widget/Presentational (Tier 4) requiring a 4-tier classification model
  - Documented custom component types: Dashboard Panel, Tab Container, Wizard, Composite Form, Data Grid
  - Identified that multi-tiered hierarchies (3+ levels) require component relationship context tables with
    @Input/@Output binding contracts at each tier boundary to accurately represent nested structures
  - Results documented in `acceptance-criteria.md` (HLR-18) and `design-guidelines.md` (new HLR-18 section)

  **TA2232991 — Updated design agent context with custom component and nested structure instructions:**
  - Added `CustomComponentHierarchy` capability to `ui-tdd-designer` agent covering custom component type
    classification, multi-tiered hierarchy documentation (Tier 1–4), nested component specs, and inter-tier
    Input/Output binding contracts
  - Added `MultiTieredSupport` behavioral trait to `ui-tdd-designer`: identifies and documents 3+ tier
    structures for premium features with nested relationship context (HLR-18)
  - Updated guardrails in `ui-tdd-designer`:
    - ALWAYS: `identify custom component types (Composite, Wizard, Dashboard, Tab-based) | document multi-tiered
      hierarchies (3+ levels) with parent-child-grandchild relationships | include component relationship context
      with Input/Output bindings at each tier boundary (HLR-18)`
    - NEVER: `flatten multi-tiered hierarchies into 2-level Smart/Presentational only when deeper structures
      exist (HLR-18) | omit component relationship context for nested component structures (HLR-18)`
  - Added `CustomComponentsDocumented` quality principle to `ui-tdd-designer`
  - Added "Custom Component Definitions (Premium Features — HLR-18)" section to UI-TDD document structure:
    - Component type classification table with Tier column (Tier 1–4)
    - Component type definitions table (Page Container, Feature Container, Composite, Wizard, Dashboard, Tab)
    - Multi-tiered hierarchy Mermaid diagram template (4+ levels)
    - Component relationship context table template (@Input, @Output, Data Flow at each tier boundary)
  - Updated Plan Format to include Tier column in Components Identified table with note for when to use
    2-tier vs 4-tier model
  - Added 5 HLR-18 items to UI-TDD Quality Checklist
  - Added `MultiTieredComponents` behavioral trait to `feature-tdd-designer` agent
  - Updated `feature-tdd-designer` guardrails (ALWAYS/NEVER) with HLR-18 multi-tier requirements
  - Updated Feature-TDD Section 4.1 Component Hierarchy to provide both standard 2-tier and premium 4-tier
    Mermaid diagram templates with component relationship context table
  - Updated Feature-TDD Plan Format UI Architecture table with Tier column
  - Added 3 HLR-18 items to Feature-TDD Quality Checklist
  - Added `CustomComponentPatterns` capability to `design-guidelines` agent
  - Added "Custom Component Patterns for Premium Features (HLR-18)" section to `design-guidelines.md`:
    - Component tier model table (Tier 1–4: name, pattern, state ownership, data source)
    - Custom component types table (Page Container, Feature Container, Composite, Wizard, Dashboard, Tab, Data Grid)
    - Multi-tiered hierarchy Mermaid diagram pattern
    - Component relationship context documentation guidelines with level-by-level context table
    - Example component relationship context table with real-world Premium Dashboard scenario
    - Anti-patterns for premium components table (6 anti-patterns with correct alternatives)
    - HLR-18 Custom Component Checklist (6 items)
  - Updated Specification Validation Checklist in `design-guidelines.md` with HLR-18 entry
  - Bumped `design-guidelines.md` version to 1.3.0

  **In `acceptance-criteria.md`:**
  - Added HLR-18: Custom Component Generation for Premium Features requirement with full specification
  - Updated UI-TDD Generation command criteria with 2 HLR-18 bullet points
  - Added `custom_component_generation.test` to test coverage summary table

  **TA2232992 — Test for multi-tiered output validation:**
  - Created `custom_component_generation.test` (HLR-18)
    - Tests 4-tier premium dashboard scenario (PremiumDashboardPageComponent → PolicyOverviewContainer →
      PolicyCardGroupComponent → PolicyCardComponent)
    - Validates component tier classification (Tier 1–4 keywords)
    - Validates custom component types (Dashboard, Tab-Container, Composite)
    - Validates component relationship context (@Input/@Output bindings per tier)
    - Validates multi-tiered hierarchy Mermaid diagram
    - Validates integration with HLR-12 (AUG JSON) and HLR-13 (sequence diagrams)

---

## **1.5.0** - AUG Compliance, Sequence Diagrams, Minimal Code Output, Axis Validators, No Angular Constructs, and Field Exclusion Rules (2026-02-26)

### New Features

- **US801182 (HLR-13)**: PlantUML and Mermaid sequence diagrams in UI-TDD output
  - Added `SequenceDiagrams` capability to `ui-tdd-designer` agent (Mermaid + PlantUML patterns)
  - Added `SequenceDiagramRequired` behavioral trait enforcing both diagram formats in UI-TDD
  - Added `SequenceDiagramsIncluded` quality principle
  - Updated guardrails: ALWAYS include Mermaid and PlantUML sequence diagrams (HLR-13); NEVER omit them
  - Added Section 9 "Sequence Diagrams (HLR-13)" to UI-TDD document structure with:
    - Section 9.1: Component Initialization Flow (Mermaid + PlantUML templates)
    - Section 9.2: Form Submission Flow showing cross-field validation (HLR-1) (Mermaid + PlantUML templates)
    - Section 9.3: Cross-Component Communication Flow (optional, Mermaid + PlantUML templates)
  - Updated Plan Format to include sequence diagram planning table
  - Added 6 sequence diagram items to Quality Checklist

- **US801188 (HLR-14)**: Minimize unnecessary source code in TDD output
  - Added `CodeMinimal` behavioral trait to `ui-tdd-designer` agent: restricts code output to concise illustrative
    examples; documents component interfaces via Input/Output/Method tables — not TypeScript code blocks
  - Added `CodeMinimal` quality principle to `ui-tdd-designer`: validator specs show signature + fields + condition
    + error key only; no full implementations in output
  - Updated guardrails in `ui-tdd-designer`:
    - ALWAYS: "document component interfaces via Input/Output/Method tables | document cross-field validators with
      concise spec (signature + fields + error key) | limit code to concise illustrative examples only (HLR-14)"
    - NEVER: "include full component implementation code blocks (HLR-14) | reproduce TypeScript interface definitions
      as code (HLR-14) | generate full validator implementations (HLR-14)"
  - Replaced TypeScript interface code block in Section 1.1 of UI-TDD document structure with a design note
    directing agents to use the Input/Output/Method tables below it (HLR-14)
  - Replaced full 8-line cross-field validator implementation in Cross-Field Validation section with a concise
    illustrative spec format: validator name, fields compared, condition, error key, error message (HLR-14)
  - Added 3 code-minimization items to UI-TDD Quality Checklist

- **US801188 (HLR-14) in `feature-tdd-designer`**:
  - Added `CodeMinimal` behavioral trait: Feature-TDD contains no implementation source code; architecture via
    Mermaid diagrams, tables, and descriptions only
  - Updated NEVER: "include source code implementations in Feature-TDD output (HLR-14)"
  - Added `CodeMinimal` quality principle and checklist item

- **HLR-13 and HLR-14 in `acceptance-criteria.md`**:
  - HLR-13: Both Mermaid and PlantUML formats mandatory; diagrams must reflect component interactions
  - HLR-14: Full implementations excluded; interfaces via tables; validators as concise specs
  - Updated UI-TDD Generation command criteria and test coverage summary table

- **design-guidelines.md**: Added "UI Component Sequence Diagrams (HLR-13)" reference section
  - Mermaid sequence diagram pattern for UI components with conventions
  - PlantUML sequence diagram pattern for UI components with naming conventions
  - Diagram scope requirements table (initialization, form submission, cross-component)
  - HLR-13 sequence diagram checklist
  - Updated Specification Validation Checklist with HLR-13 item
  - Updated Documentation Quality checklist with PlantUML item
  - Version bumped to 1.2.0

- **US801179 (HLR-12)**: Enforce AUG (Axis UI Generator) JSON-based design approach in UI-TDD output
  - Added `AUGCompliant` behavioral trait to `ui-tdd-designer` agent
  - Added `AUGConformant` quality principle enforcing `*.aug.json` schema specs
  - Replaced "Template Specifications" section (raw HTML) with "AUG Component Definitions" (JSON-based)
  - Added AUG JSON structure, field type mapping, and `displayIf`/`requiredIf` conditional logic patterns
  - Updated guardrails: NEVER produce raw Angular HTML templates in TDD output
  - Added 6 AUG compliance items to Quality Checklist

- **HLR-12 in acceptance-criteria.md**: Axis UI Generator compliance requirement
  - No raw Angular HTML templates in TDD output
  - All form/layout components specify `*.aug.json` AUG JSON schema
  - Conditional logic via `displayIf`/`requiredIf` (not `*ngIf`)

- **design-guidelines.md**: Added "Axis UI Generator (AUG) JSON-Based Design" reference section
  - AUG JSON schema structure with examples
  - Field type mapping table (text, dropdown, date, checkbox, radio, number, textarea, button)
  - AUG anti-patterns table showing what to avoid and correct alternatives
  - Conditional logic patterns (`displayIf`, `requiredIf`)
  - HLR-12 AUG conformance checklist

### Enhancements (US801181)

- **TA2232993 (Audit/Define)**: Defined exclusion marker convention for input FSD documents — two supported formats:
  `[EXCLUDED]` tag on section headers and field entries; `## Out of Scope` / `## Excluded Sections` dedicated block
- **TA2232994 (Prompts)**: Added `ExclusionRespect` behavioral trait to `ui-tdd-designer` and `feature-tdd-designer`;
  updated ALWAYS/NEVER constraints to enforce exclusion detection before planning; added "Exclusion Detection (HLR-17)"
  sub-step to Step 2 of ui-tdd-designer; added "Excluded Sections / Fields" table to the confirmation plan format;
  documented convention in `design-guidelines` under "Exclusion Markers (HLR-17)" section
- **TA2232995 (Test)**: Created `field_exclusion_rules.test` for HLR-17 with EXPECTED (included field names) and
  UNEXPECTED (excluded field names from [EXCLUDED] section and Out of Scope block) keyword assertions

### Enhancements (US801184)

- **TA2233002 (Audit)**: Catalogued unnecessary Angular constructs and UI Standard sections in TDD output
- **TA2233003 (Prompts)**: Added explicit exclusion rules to `ui-tdd-designer` and `feature-tdd-designer` agents
- **TA2233004 (Validate)**: Extended validate skill to verify HLR-15 compliance (exclusion + completeness)

### Enhancements (US801183)

- **TA2232999 (Audit)**: Catalogued Angular `Validators.*` references in UI-TDD agent prompts and test files
- **TA2233000 (Prompts)**: Updated `ui-tdd-designer` and `design-guidelines` agents to use Axis `UIValidators` interface
  and Axis custom validators for field-level validation; Angular `Validators.*` class methods excluded from all field
  validator documentation
- **TA2233001 (Test)**: Updated existing tests and created `axis_validators_compliance.test` for HLR-16 compliance

### Agent Changes

- **ui-tdd-designer**: Added `StandaloneComponents` behavioral trait; extended `NEVER` constraint to exclude NgModule
  declarations and UI Standards sections (typography, colors, visual design, responsive breakpoints); removed
  `**Module:** {ModuleName}Module` field from component spec template; added HLR-15 checks to Quality Checklist;
  added `AxisValidators` behavioral trait; extended `NEVER` constraint to prohibit `Validators.*` class methods for
  field validation; updated Section 3.2 with Axis Validator Reference block and `UIValidators` column headers;
  updated cross-field validator example to clearly distinguish field-level `UIValidators` from cross-field `ValidatorFn`;
  added HLR-16 checks to Quality Checklist
- **feature-tdd-designer**: Added `StandaloneComponents` behavioral trait; extended `NEVER` constraint to exclude
  NgModule declarations and UI Standards sections; removed `FEAT[FeatureModule]` from component hierarchy Mermaid
  template (replaced with `FEAT[Feature]`); removed NgRx from state management options (standalone patterns only);
  added HLR-15 checks to Quality Checklist
- **design-guidelines**: Updated "Reactive Forms Setup" to reference `UIValidators` interface and `UIErrorMessages`;
  updated "Custom Validators" to distinguish field-level Axis validators from cross-field `ValidatorFn` (HLR-1)

### Acceptance Criteria

- Added **HLR-15**: No Unnecessary Angular Constructs or UI Standard Sections — covers NgModule declarations,
  FeatureModule references, NgRx patterns, and non-design-relevant UI Standard sections
- Added **HLR-16**: Axis/Custom Validators in TDD Output — field validators use `UIValidators` object notation and
  Axis custom validators (`axisEmail`, `axisRange`, `axisNumerics`, `axisAlphabets`, `axisCurrency`, `axisDecimal`,
  `axisAlphaNumerics`); Angular `Validators.*` class methods must not appear; cross-field `ValidatorFn` permitted
- Added **HLR-17**: Respect Field Exclusion Rules — `[EXCLUDED]` tag and `## Out of Scope` block honoured; excluded
  items absent from TDD output; agents list exclusions in confirmation plan
- Fixed UI-TDD Generation criteria: state management now reads `(Signals/Services)` instead of `(Signals/NgRx/Services)`

### Test Coverage

- Added `no_unnecessary_angular_constructs.test` for HLR-15 with both EXPECTED (completeness) and UNEXPECTED
  (exclusion) keyword assertions
- Created `axis_validators_compliance.test` for HLR-16 with EXPECTED (`UIValidators`, `axisEmail`, `axisNumerics`,
  `axisAlphabets`, `axisRange`) and UNEXPECTED (`Validators.required`, `Validators.email`, `Validators.min`) keyword
  assertions
- Created `field_exclusion_rules.test` for HLR-17 with EXPECTED (included field names) and UNEXPECTED
  (excluded field names from [EXCLUDED] section and Out of Scope block) keyword assertions
- Created `ui_tdd_sequence_diagrams.test` (HLR-13) — TA2232997/TA2232998: tests component initialization flow and
  form submission flow in both Mermaid + PlantUML
- Created `axis_ui_generator_compliance.test` (HLR-12) — TA2232989
- Updated `ui_tdd_generation.test`: acceptance criteria updated with HLR-16 reference; EXPECTED KEYWORDS updated
  to include `UIValidators`, AUG terms, and sequence diagram terms; `Signals/NgRx/Services` changed to `Signals/Services`;
  PROMPT converted to specification-level input (no full source code) — TA2233016
- Updated `ui_tdd_cross_field_validation.test`: field-level validators converted from `Validators.*` array notation to
  `UIValidators` object notation; EXPECTED KEYWORDS updated to include `UIValidators`, `UIErrorMessages`, and AUG terms

### Validate Skill

- Extended `validate/SKILL.md` Step 3 to check HLR-15 compliance: absence of unnecessary constructs and presence of
  all required design sections (TypeScript interfaces, validators, signals, API integration, accessibility)

### Bug Fixes

- Restored missing `help` and `validate` skills in `plugin.json` — both were accidentally dropped in v1.4.1 when
  deduplicating a duplicate `"skills"` key. The fix kept only `generate` and `explore`, incorrectly labelling `validate`
  as non-existent. Both skill directories (`skills/help/`, `skills/validate/`) were present and valid throughout.

---

## **1.4.1** - Plugin Manifest Fix (2026-02-06)

### Bug Fixes

- Fixed plugin.json path references to match actual directory structure
- Removed duplicate "skills" key in plugin.json
- Updated skills to use directory format (./skills/generate, ./skills/explore)
- **Known regression**: accidentally dropped `help` and `validate` skills during deduplication (restored in v1.5.0)

---

## 2025/2026IterationIP v1.3.0 (2026-01-09)

### Performance Optimizations

- **US774966**: Optimize AIDLC-design Plugin for Token Efficiency and Speed - 85-90% token reduction (131K→10-20K), 60-70% faster execution (222s→60-90s)

---

## 2025.PI5.Iteration4

### Design Agent Enhancements

- **US767451**: Agent Critical Gap: Missing Async Operations Pattern for LongRunning APIs
- **US767453**: Agent Critical Gap: Missing Flow Engine Function Breakdown
- **US767454**: Agent Gap: Incomplete Sequence Diagrams (Missing Detail)
- **US767588**: Document Consolidation: Merge all separately generated TDD into combined TDD
- **US769313**: Update the lambda memory checks when processing XML
- **US769324**: Address gap between manually created doc and agent created one

---

## **1.2.0** - Release version 1.2.0 (2025-12-18)

- Design Agent Review Feedback for V1.2 Release
- Review Feedback of Design Agent - Added Acceptance Criteria, BRD, Test Cases
- Updates with Missing Master TDD References, Test suites

---

## [1.1.1] - 2025-12-11

### Fixed
- **UI-TDD Designer Agent**: Updated ui-tdd-designer agent with explicit Master TDD reference instructions in document structure template
- **Feature-TDD Designer Agent**: Updated feature-tdd-designer agent with explicit Master TDD reference instructions in document structure template
- Fixed issue where Master TDD references weren't appearing in generated UI-TDD and Feature-TDD documents

### Changed
- Updated feature-tdd-designer.md document structure to include Master TDD references
- Updated ui-tdd-designer.md document structure to include Master TDD references
- Updated service-tdd-designer.md document structure to include Master TDD references

### Technical Details
- All three designer agents (service-tdd, ui-tdd, feature-tdd) now have explicit Master TDD references in their document structure templates
- References appear immediately after section headers before content
- **Behavioral Trait**: `MasterTDDReferences,"Add Master TDD section references to all major sections in generated TDD documents"`
- **Quality Principle**: `MasterTDDSectionReferences,"All major sections include Master TDD reference callouts"`
- **Format**: `> **Master TDD Reference**: Section X.Y - Description`

## [1.1.0] - 2025-12-08

### Major Changes
- **Complete Architecture Refactoring**: Transitioned from HLD/LLD terminology to TDD (Technical Design Document) nomenclature across all agents and documentation
- **Review Feedback Integration**: Consolidated comprehensive review feedback from design agent evaluation
- **Enhanced Documentation**: Major updates to requirements documents (BRD, HLD, LLD) with improved structure and clarity (Internally created Claude code agent docs)

### Agent Updates
- **Feature-TDD Designer**: Enhanced agent with improved feature-level design generation
- **Service-TDD Designer**: Refined Lambda service specification generation with better patterns
- **UI-TDD Designer**: Improved UI component specification with enhanced validation patterns

### Test Suite Overhaul
#### Added Test Cases (9 new tests):
#### Removed Deprecated Tests (6 tests):
#### Modified Test Cases (3 tests):

### Requirements Documentation Updates
- **design-agent-brd.md**: Comprehensive business requirements update
  - Enhanced business context and objectives
  - Refined functional and non-functional requirements
  - Improved acceptance criteria alignment
- **design-agent-hld.md**: High-level design updates
  - Updated architecture patterns and diagrams
  - Enhanced integration patterns documentation
  - Improved service orchestration specifications
- **design-agent-lld.md**: Low-level design updates
  - Detailed component specifications
  - Enhanced interface definitions and schemas
  - Improved validation rules and error handling patterns

### Acceptance Criteria Updates
- Updated `acceptance-criteria.md` with review feedback changes
- Aligned criteria with new TDD-based approach
- Added validation rules for Master TDD references
- Enhanced pattern enforcement requirements

### Windows Compatibility
- Fixed evaluation test file paths for Windows systems
- Updated all 14 test files with correct file path handling

## [1.0.0] - Earlier versions
- Previous iterations of design document generation
