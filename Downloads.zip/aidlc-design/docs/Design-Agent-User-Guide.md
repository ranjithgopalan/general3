# Design Agent - User Guide

**Your AI-powered Technical Design Assistant**

Generate implementation-ready technical design documents (TDD) for UI components and Lambda services from high-level requirements.

---

## Table of Contents

### Getting Started
- [Quick Start](#quick-start)
- [Installation](#installation)
- [Understanding the Plugin](#understanding-the-plugin)
  - [What Does AIDLC-design Do?](#what-does-AIDLC-design-do)
  - [Role in SDLC Workflow](#role-in-sdlc-workflow)
  - [Three Document Types](#three-document-types)
- [Basic Usage](#basic-usage)

### Skills-Based Architecture
- [Migration from Commands to Skills](#migration-from-commands-to-skills)
  - [What Changed](#what-changed)
  - [Key Differences](#key-differences)
  - [Why Skills?](#why-skills)
- [Available Skills](#available-skills)
  - [1. AIDLC-design:generate](#1-AIDLC-designgenerate)
  - [2. AIDLC-design:validate](#2-AIDLC-designvalidate)
  - [3. AIDLC-design:explore](#3-AIDLC-designexplore)
  - [4. AIDLC-design:help](#4-AIDLC-designhelp)

### Complete Workflows
- [End-to-End Feature Design](#end-to-end-feature-design)
  - [Workflow 1: Complete Feature Design](#workflow-1-complete-feature-design-all-three-documents)
  - [Workflow 2: Quick UI-Only Design](#workflow-2-quick-ui-only-design)
  - [Workflow 3: Service-Only Design](#workflow-3-service-only-design-backend-lambda)
  - [Workflow 4: Iterative Design Updates](#workflow-4-iterative-design-updates)
  - [Workflow 5: Design Review and Troubleshooting](#workflow-5-design-review-and-troubleshooting)
  - [Workflow 6: Cross-Document Traceability](#workflow-6-cross-document-traceability)

### Critical Pattern Enforcement
- [Understanding Critical Patterns](#understanding-critical-patterns)
- [Protocol Specification](#protocol-specification)
- [Endpoint Verification](#endpoint-verification)
- [Async Operations Pattern](#async-operations-pattern)
- [Lambda Configuration](#lambda-configuration)
- [11-Function Flow Engine](#11-function-flow-engine)
- [Rules-as-a-Service](#rules-as-a-service)
- [Reference-Data Dropdown Pattern](#reference-data-dropdown-pattern)
- [Sequence Diagrams](#sequence-diagrams)
- [Master TDD References](#master-tdd-references)

### Advanced Topics
- [Policy Object Model (POM) Integration](#policy-object-model-pom-integration)
- [Selective Reading for Large Documents](#selective-reading-for-large-documents)
- [Quality Checklist](#quality-checklist)

### Examples & Reference
- [Real-World Examples](#real-world-examples)
  - [Example 1: Generating Feature-TDD from FSD](#example-1-generating-feature-tdd-from-fsd)
  - [Example 2: Creating UI-TDD for Angular Components](#example-2-creating-ui-tdd-for-angular-components)
  - [Example 3: Generating Service-TDD for Lambda](#example-3-generating-service-tdd-for-lambda)
  - [Example 4: Validating Design Coverage](#example-4-validating-design-coverage)
  - [Example 5: Exploring Existing Designs](#example-5-exploring-existing-designs)
- [Troubleshooting](#troubleshooting)

---

# Getting Started

## Quick Start

**Think of this plugin as:** Your personal technical architect that reads business requirements and generates
implementation-ready design documents for your development team.

**What you can do:**
- "Generate Feature-TDD from the customer-portal FSD"
- "Create UI-TDD for the search component"
- "Generate Service-TDD for the claims-enrichment Lambda"
- "Validate Feature-TDD against the original requirements"
- "Show me all services in the customer-portal Feature-TDD"

**Time to value:** 5 minutes from requirements document to implementation-ready technical design

---

## Installation

The AIDLC-design plugin is part of the genlite-aig-claude marketplace. If you've installed the marketplace, the
plugin is already available.

**Verify installation:**
```bash
# List all installed plugins
/plugin list

# Should show: AIDLC-design
```

**Add marketplace (if not already installed):**
```bash
/plugin marketplace add https://github.aig.net/christle/genlite-aig-claude.git#dev
```

---

## Understanding the Plugin

### What Does AIDLC-design Do?

AIDLC-design bridges the gap between business requirements and code implementation by transforming high-level
Feature Specification Documents (FSD) into detailed technical design documents (TDD) that serve as blueprints for
code generation.

**Input:**
- Feature Specification Documents (FSD)
- Master TDD (architecture reference)
- Common Library TDD (shared components)

**Output:**
- Feature-TDD (high-level architecture combining UI + Services)
- UI-TDD (Angular component specifications for axis-tools)
- Service-TDD (Lambda specifications for nodejs-pair-programmer)

### Role in SDLC Workflow

```
Business Analyst → Product Owner → Scrum Master → Design Agent → Pair Programmers
    (EPIC/BRD)      (Feature/PRD)   (User Stories)   (TDD Specs)   (Code Implementation)
```

AIDLC-design sits between planning and implementation:
1. **Receives:** Feature requirements from Product Owner/Scrum Master
2. **Analyzes:** Technical architecture and patterns needed
3. **Generates:** Detailed specifications with critical patterns
4. **Passes to:** Code generation plugins (AIDLC-axis for UI, AIDLC-lambda for services)

### Three Document Types

| Document Type | Purpose | Consumer |
|---------------|---------|----------|
| **Feature-TDD** | Combined UI + Services architecture | Technical overview for teams |
| **UI-TDD** | Angular component specifications with Axis framework patterns | AIDLC-axis plugin |
| **Service-TDD** | Consolidated Lambda specifications with critical patterns | AIDLC-lambda plugin |

**Key terminology change (v5.0+):**
- HLD → Feature-TDD (High-Level Design)
- UI-LLD → UI-TDD (UI Low-Level Design)
- Services-LLD → Service-TDD (Services Low-Level Design)

---

## Basic Usage

AIDLC-design uses a **skills-based architecture** where you invoke skills using natural language requests:

**Generate design documents:**
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD from the customer-portal FSD located at ./requirements/customer-portal-fsd.md
```

**Validate coverage:**
```bash
Skill: AIDLC-design:validate
Validate the customer-portal Feature-TDD against the FSD
```

**Explore existing designs:**
```bash
Skill: AIDLC-design:explore
What services are defined in the customer-portal Feature-TDD?
```

**Get help:**
```bash
Skill: AIDLC-design:help
Show me how to use AIDLC-design
```

---

# Skills-Based Architecture

## Migration from Commands to Skills

**AIDLC-design migrated from slash commands to skills in version 1.4.0.** This provides better integration with
Claude Code's natural language processing and improved auto-invocation.

### What Changed

**Before (Commands - NO LONGER SUPPORTED):**
```bash
# Old slash command syntax
/AIDLC-design:generate Feature-TDD from customer-portal FSD
/AIDLC-design:validate Feature-TDD against FSD
/AIDLC-design:explore What services are in customer-portal?
```

**After (Skills - CURRENT):**
```bash
# New skill invocation syntax
Skill: AIDLC-design:generate
Generate Feature-TDD from the customer-portal FSD

Skill: AIDLC-design:validate
Validate Feature-TDD against FSD

Skill: AIDLC-design:explore
What services are in customer-portal Feature-TDD?
```

### Key Differences

| Aspect | Commands (Old) | Skills (New) |
|--------|----------------|--------------|
| **Invocation** | `/AIDLC-design:command args` | `Skill: AIDLC-design:skill` + request |
| **Syntax** | Slash command prefix | Skill tool invocation |
| **Arguments** | Inline with command | Natural language in request |
| **Auto-invoke** | Limited | Enhanced detection |
| **Structure** | `commands/*.md` | `skills/*/SKILL.md` |

### Why Skills?

**Benefits of the skills-based approach:**
- **Natural Language Requests**: Conversational requests instead of rigid command syntax
- **Better Context Understanding**: Extended thinking for improved routing
- **Auto-Invocation**: Claude Code can automatically invoke skills based on user intent
- **Standardized Structure**: Follows agentskills.io specification format
- **Improved Discovery**: Skills are easier to discover and document

---

## Available Skills

AIDLC-design provides four skills for design document generation, validation, exploration, and help.

### 1. AIDLC-design:generate

**Purpose:** Generate Feature-TDD, UI-TDD, or Service-TDD design documents from requirements.

**When to Use:**
- Creating Feature-TDD (architecture combining UI + Services)
- Creating UI-TDD (component specifications for axis-tools)
- Creating Service-TDD (Lambda specifications for nodejs-pair-programmer)
- Converting Feature Specification Documents to technical designs

**Basic Usage:**
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD from customer-portal FSD

Skill: AIDLC-design:generate
Create UI-TDD for customer-portal

Skill: AIDLC-design:generate
Generate Service-TDD for customer-search Lambda
```

**Advanced Usage with File Paths:**
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD from ./requirements/claims-processing-fsd.md
Use Master TDD at ./reference/master-tdd.md
Use Common Library TDD at ./reference/common-library-tdd.md

Skill: AIDLC-design:generate
Create UI-TDD for claims-submission feature
Source Feature-TDD: ./workspace/EPIC-12345/technical/design/claims-submission-Feature-TDD.md
Source FSD: ./requirements/claims-submission-fsd.md

Skill: AIDLC-design:generate
Generate consolidated Service-TDD for all Lambda services in claims-processing
Include: claims-validator, claims-processor, claims-enrichment services
```

**How It Works:**
1. **Analyzes user intent** - Identifies document type (Feature-TDD | UI-TDD | Service-TDD)
2. **ADLCs required context** - Locates FSD, Master TDD, Common Library TDD, Feature-TDD
3. **Uses selective reading** - Efficiently processes large documents (Master TDD ~41K tokens)
4. **Verifies critical patterns:**
   - Endpoint URLs verified (no guessing/hallucination)
   - Protocol specification (SOAP vs REST)
   - Async operations >16s with polling
   - Lambda config 1024MB/30s
   - 11-function Flow Engine for multi-step workflows
   - Rules-as-a-Service integration
   - Reference-data dropdown pattern
   - Sequence diagrams (Mermaid + PlantUML)
   - AUG (Axis UI Generator) JSON-based design
   - Minimal code output (HLR-14)
5. **Presents plan** - Shows what will be generated and waits for user confirmation
6. **Delegates to specialized agent:**
   - `feature-tdd-designer` → `{feature}-Feature-TDD.md`
   - `ui-tdd-designer` → `{feature}-UI-TDD.md`
   - `service-tdd-designer` → `{feature}-Service-TDD.md` (consolidated)

**Output Location:** `.claude_kb/workspaces/EPIC-XXX/technical/design/`

**Generated Files:**
- `{feature-name}-Feature-TDD.md` - Combined UI + Services architecture
- `{feature-name}-UI-TDD.md` - UI component specifications (for axis-tools)
- `{feature-name}-Service-TDD.md` - Consolidated Lambda specifications (for nodejs-pair-programmer)

---

### 2. AIDLC-design:validate

**Purpose:** Validate design document coverage against source requirements and critical patterns.

**When to Use:**
- Validating Feature-TDD coverage against FSD
- Validating UI-TDD coverage against Feature-TDD and FSD
- Validating Service-TDD coverage against Feature-TDD and FSD
- Checking compliance with critical patterns

**Basic Usage:**
```bash
Skill: AIDLC-design:validate
Validate Feature-TDD against FSD

Skill: AIDLC-design:validate
Check Service-TDD for customer-search
```

**Advanced Usage:**
```bash
Skill: AIDLC-design:validate
Validate claims-submission-Feature-TDD against the original FSD
Check for:
- Complete requirement coverage
- Critical pattern compliance
- Protocol specifications
- Lambda configuration accuracy

Skill: AIDLC-design:validate
Validate claims-submission-UI-TDD
Verify:
- All components from Feature-TDD are included
- AUG JSON schema compliance
- Cross-field validation rules
- Sequence diagrams present (Mermaid + PlantUML)
```

**What It Checks:**

**Requirement Coverage:**
- All FSD requirements addressed in target document
- No missing features or capabilities
- Traceability from FSD to TDD

**Critical Pattern Compliance:**
- Protocol specification (SOAP vs REST) for all external services
- Async operations pattern for >16s operations
- Lambda config (1024MB / 30s timeout)
- 11-function Flow Engine breakdown
- Rules-as-a-Service integration
- Reference-data dropdown pattern
- Sequence diagrams (both Mermaid and PlantUML)
- AUG JSON-based design (UI-TDD)
- Minimal code output (HLR-14)

**Consistency:**
- Cross-document consistency checks
- Component references match between Feature-TDD and UI-TDD
- Service definitions match between Feature-TDD and Service-TDD

**Anti-Pattern Violations:**
- 10-point checklist validation
- Identifies common design flaws

**Output:**
- Coverage percentage
- List of gaps (missing requirements)
- Inconsistencies found
- Critical pattern violations
- Priority recommendations

---

### 3. AIDLC-design:explore

**Purpose:** Explore and understand existing design documents and patterns.

**When to Use:**
- Finding specific design documents or sections
- Explaining architecture decisions
- Comparing design versions
- Tracing requirements through Feature-TDD to TDD
- Verifying critical patterns in existing designs

**Basic Usage:**
```bash
Skill: AIDLC-design:explore
What services are in customer-portal Feature-TDD?

Skill: AIDLC-design:explore
Does customer-search Service-TDD specify SOAP or REST?
```

**Advanced Usage:**
```bash
Skill: AIDLC-design:explore
Show me the data flow for the claims submission process
Trace from FSD through Feature-TDD to UI-TDD and Service-TDD

Skill: AIDLC-design:explore
Compare the async operations pattern used in customer-search Service-TDD
with the pattern specified in the Master TDD

Skill: AIDLC-design:explore
List all external service integrations in the claims-processing Feature-TDD
Include protocol specifications and endpoint URLs

Skill: AIDLC-design:explore
Explain the 11-function Flow Engine breakdown for claims-enrichment service
Show which functions handle validation, processing, and persistence
```

**Query Types:**

| Query Type | Example | What It Does |
|------------|---------|--------------|
| **Find** | "Locate the claims-processing UI-TDD" | Searches workspace for specific documents |
| **Explain** | "Explain the async pattern in customer-search" | Analyzes architecture decisions |
| **Compare** | "Compare Feature-TDD v1 vs v2" | Shows differences between versions |
| **Trace** | "Trace requirement R-123 through designs" | Follows requirement from FSD → Feature-TDD → TDD |
| **Verify** | "Check protocol specs in all Service-TDDs" | Validates critical pattern compliance |

**Search Strategy:**
- GLOB for design documents in workspace
- GREP for specific terms or components
- READ relevant sections
- Cross-reference between Feature-TDD and TDDs

---

### 4. AIDLC-design:help

**Purpose:** Display comprehensive help documentation for AIDLC-design plugin.

**When to Use:**
- Need guidance on using design tools
- Understanding design document types
- Learning workflow sequences
- Reviewing quality checklists

**Usage:**
```bash
Skill: AIDLC-design:help
Show me how to use AIDLC-design

Skill: AIDLC-design:help
What are the three design document types?
```

**Help Topics Covered:**
- Plugin overview and SDLC role
- All four skills with usage examples
- Document flow and generation workflow
- Three design document types (Feature-TDD, UI-TDD, Service-TDD)
- Document storage locations
- Comprehensive specifications
- POM integration approach
- Confirmation workflow (Plan → Confirm → Generate)
- Quality checklist
- Plugin distinctions

---

# Complete Workflows

## End-to-End Feature Design

This section provides complete examples for common design scenarios using the skills-based approach.

### Workflow 1: Complete Feature Design (All Three Documents)

**Scenario:** Generate complete design documentation for a new claims-submission feature.

**Step 1: Generate Feature-TDD (Architecture)**
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD for claims-submission feature
Source FSD: ./requirements/claims-submission-fsd.md
Master TDD: ./reference/master-tdd.md
Common Library: ./reference/common-library-tdd.md
```

**Agent Response:**
```
I will generate Feature-TDD with the following approach:
1. Read FSD from ./requirements/claims-submission-fsd.md
2. Extract Master TDD Section 20 (Lambda patterns)
3. Identify 5 UI components and 3 Lambda services
4. Verify protocol specifications for external services
5. Create claims-submission-Feature-TDD.md

Proceed? (yes/no)
```

**You:** "Yes, proceed"

**Output:** `.claude_kb/workspaces/EPIC-12345/technical/design/claims-submission-Feature-TDD.md`

---

**Step 2: Generate UI-TDD (Component Specifications)**
```bash
Skill: AIDLC-design:generate
Create UI-TDD for claims-submission feature
Use Feature-TDD at ./workspace/EPIC-12345/technical/design/claims-submission-Feature-TDD.md
Include AUG JSON schemas and sequence diagrams
```

**Agent Response:**
```
I will generate UI-TDD with the following approach:
1. Read claims-submission-Feature-TDD.md
2. Extract UI component specifications
3. Create AUG JSON schemas for 5 components
4. Generate Mermaid and PlantUML sequence diagrams
5. Create claims-submission-UI-TDD.md

Proceed? (yes/no)
```

**You:** "Yes, proceed"

**Output:** `.claude_kb/workspaces/EPIC-12345/technical/design/claims-submission-UI-TDD.md`

---

**Step 3: Generate Service-TDD (Lambda Specifications)**
```bash
Skill: AIDLC-design:generate
Generate consolidated Service-TDD for claims-submission
Include all Lambda services: validator, processor, enrichment
Use Feature-TDD at ./workspace/EPIC-12345/technical/design/claims-submission-Feature-TDD.md
```

**Agent Response:**
```
I will generate Service-TDD with the following approach:
1. Read claims-submission-Feature-TDD.md
2. Extract Lambda service specifications (3 services)
3. Apply critical patterns:
   - Protocol: REST with JSON
   - Lambda config: 1024MB / 30s
   - Async pattern for processor (>16s operation)
   - 11-function Flow Engine for enrichment
   - Rules-as-a-Service integration
4. Generate sequence diagrams for all services
5. Create claims-submission-Service-TDD.md

Proceed? (yes/no)
```

**You:** "Yes, proceed"

**Output:** `.claude_kb/workspaces/EPIC-12345/technical/design/claims-submission-Service-TDD.md`

---

**Step 4: Validate Complete Design**
```bash
Skill: AIDLC-design:validate
Validate all three TDD documents for claims-submission
Check coverage, critical patterns, and consistency
```

**Agent Response:**
```
Validation Report: claims-submission Design Documents

Feature-TDD Coverage: 100% (12/12 requirements)
✓ All FSD requirements addressed
✓ Protocol specifications present
✓ Lambda configuration correct

UI-TDD Coverage: 100% (5/5 components)
✓ AUG JSON schemas present
✓ Sequence diagrams (Mermaid + PlantUML)
✓ Cross-field validation rules

Service-TDD Coverage: 100% (3/3 services)
✓ Async pattern for processor service
✓ 11-function Flow Engine for enrichment
✓ Rules-as-a-Service integration
✓ Sequence diagrams for all services

Consistency: PASS
✓ Components match between Feature-TDD and UI-TDD
✓ Services match between Feature-TDD and Service-TDD

No gaps or violations found. Design is ready for code generation.
```

---

**Step 5: Pass to Code Generation**
```bash
# UI-TDD → AIDLC-axis plugin
/AIDLC-axis:implement claims-submission UI from ./workspace/EPIC-12345/technical/design/claims-submission-UI-TDD.md

# Service-TDD → AIDLC-lambda plugin
/AIDLC-lambda:implement claims-submission services from ./workspace/EPIC-12345/technical/design/claims-submission-Service-TDD.md
```

---

### Workflow 2: Quick UI-Only Design

**Scenario:** Generate only UI component specifications for a simple form.

**Step 1: Generate Feature-TDD (Lightweight)**
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD for customer-profile-form
This is a simple form feature with no backend services
FSD: ./requirements/customer-profile-fsd.md
```

**Step 2: Generate UI-TDD**
```bash
Skill: AIDLC-design:generate
Create UI-TDD for customer-profile-form
Include form validators, AUG JSON schemas, and component interactions
```

**Step 3: Validate UI-TDD**
```bash
Skill: AIDLC-design:validate
Validate customer-profile-form UI-TDD against Feature-TDD
Check AUG compliance and sequence diagrams
```

**Step 4: Generate Angular Components**
```bash
# Pass UI-TDD to AIDLC-axis plugin
/AIDLC-axis:implement customer-profile-form from ./workspace/EPIC-12345/technical/design/customer-profile-form-UI-TDD.md
```

---

### Workflow 3: Service-Only Design (Backend Lambda)

**Scenario:** Generate Lambda service specifications for a new API service.

**Step 1: Generate Feature-TDD (Architecture)**
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD for claims-enrichment service
Focus on backend architecture - API Gateway + Lambda + DynamoDB
FSD: ./requirements/claims-enrichment-fsd.md
```

**Step 2: Generate Service-TDD**
```bash
Skill: AIDLC-design:generate
Generate Service-TDD for claims-enrichment
Include all critical patterns:
- Protocol specification (REST)
- Async operations for long-running enrichment
- 11-function Flow Engine breakdown
- Rules-as-a-Service integration
```

**Step 3: Explore Generated Design**
```bash
Skill: AIDLC-design:explore
Show me the 11-function breakdown for claims-enrichment
Explain the async operations pattern
```

**Agent Response:**
```
Claims-Enrichment Service: 11-Function Flow Engine Breakdown

1. validateInput() - Validate enrichment request structure
2. checkPermissions() - Verify user authorization
3. fetchClaims() - Retrieve claims data from DynamoDB
4. enrichData() - Enrich claims with external data sources
5. applyBusinessRules() - Validate via Rules-as-a-Service
6. transformData() - Transform enriched data to output format
7. persistResults() - Save enriched claims to DynamoDB
8. publishEvents() - Publish enrichment events to SNS
9. updateOperationStatus() - Update operation-status table
10. formatResponse() - Format success/failure response
11. handleError() - Go-style error handling wrapper

Async Operations Pattern:
- POST /api/enrichment/async → Returns operation ID, starts background processor
- GET /api/enrichment/status/{id} → Polls operation-status table
- Background processor: Executes 11 functions, updates status table
```

**Step 4: Validate Service-TDD**
```bash
Skill: AIDLC-design:validate
Validate claims-enrichment Service-TDD
Check Lambda config, protocol specs, and async pattern compliance
```

**Step 5: Generate Lambda Code**
```bash
# Pass Service-TDD to AIDLC-lambda plugin
/AIDLC-lambda:implement claims-enrichment from ./workspace/EPIC-12345/technical/design/claims-enrichment-Service-TDD.md
```

---

### Workflow 4: Iterative Design Updates

**Scenario:** Update existing design documents after requirement changes.

**Step 1: Explore Current Design**
```bash
Skill: AIDLC-design:explore
Show me the current claims-submission Feature-TDD
What services are currently defined?
```

**Agent Response:**
```
Claims-Submission Feature-TDD (v1.0)

Services Defined:
1. claims-validator - Validates claim structure and business rules
2. claims-processor - Processes approved claims
3. claims-enrichment - Enriches claims with external data

UI Components:
1. ClaimsSubmissionFormComponent
2. ClaimsValidatorPanelComponent
3. ClaimsHistoryListComponent
```

---

**Step 2: Regenerate Feature-TDD with Updates**
```bash
Skill: AIDLC-design:generate
Update Feature-TDD for claims-submission
New requirements: Add claims-notification service
Updated FSD: ./requirements/claims-submission-fsd-v2.md
```

**Step 3: Regenerate Service-TDD**
```bash
Skill: AIDLC-design:generate
Update Service-TDD for claims-submission
Add claims-notification service specifications
Include SNS topic integration
```

**Step 4: Validate Updated Design**
```bash
Skill: AIDLC-design:validate
Validate updated claims-submission Service-TDD
Ensure new notification service follows critical patterns
```

**Step 5: Compare Versions**
```bash
Skill: AIDLC-design:explore
Compare claims-submission-Service-TDD v1 vs v2
Show differences in service architecture
```

**Agent Response:**
```
Comparison: claims-submission-Service-TDD v1 → v2

Added Services:
+ claims-notification - Sends claim status notifications via SNS

Updated Services:
• claims-processor
  - Added notification trigger after processing
  - Added SNS topic ARN configuration

New Integrations:
+ SNS Topic: claims-notifications-topic
+ Protocol: SNS Publish API (REST)

Impact Analysis:
- Additional Lambda: claims-notification (1024MB / 30s)
- New IAM permissions: SNS Publish
- New environment variable: NOTIFICATIONS_TOPIC_ARN
```

---

### Workflow 5: Design Review and Troubleshooting

**Scenario:** Review and fix issues in existing design documents.

**Step 1: Validate Existing Design**
```bash
Skill: AIDLC-design:validate
Validate customer-portal Service-TDD
Check for critical pattern violations
```

**Agent Response:**
```
Validation Report: customer-portal-Service-TDD

Critical Pattern Violations:

✗ Protocol Specification Missing
  - customer-search service has no protocol specification (SOAP vs REST)
  - address-validation service has placeholder URL "https://example.com/api"

✗ Lambda Configuration Incorrect
  - customer-search Lambda: 512MB / 16s (should be 1024MB / 30s)

✗ Async Pattern Missing
  - customer-search operation takes >16s but has no async pattern

Recommendation:
1. Specify protocol for all external services
2. Update Lambda configuration
3. Add async operations pattern for customer-search
```

---

**Step 2: Explore Specific Issues**
```bash
Skill: AIDLC-design:explore
Show all external service integrations in customer-portal Service-TDD
Which ones are missing protocol specifications?
```

**Agent Response:**
```
External Service Integrations: customer-portal-Service-TDD

Missing Protocol Specifications:
1. customer-search service → CRM API
   - URL: Not specified (placeholder)
   - Protocol: Not specified

2. address-validation service → USPS API
   - URL: https://example.com/api (placeholder)
   - Protocol: Not specified

Services with Complete Specifications:
✓ customer-authentication → OAuth Provider
  - URL: https://auth.example.com/oauth2
  - Protocol: REST with JSON
```

---

**Step 3: Explore Master TDD for Guidance**
```bash
Skill: AIDLC-design:explore
Show the async operations pattern from Master TDD
Compare with customer-search service implementation
```

**Agent Response:**
```
Master TDD: Async Operations Pattern (Section 20.8)

Required Components:
1. POST /api/resource/async → Returns { operationId }
2. GET /api/resource/status/{operationId} → Returns { status, result }
3. Background processor Lambda → Executes operation, updates status table
4. DynamoDB operation-status table → Stores operation state

Current Implementation: customer-search Service-TDD
✗ Missing: POST /async endpoint
✗ Missing: GET /status/{id} endpoint
✗ Missing: Background processor Lambda
✗ Missing: operation-status DynamoDB table

Gap Analysis:
The current customer-search service only has:
- POST /api/customers/search → Synchronous, times out after 16s

Needs:
- Refactor to async pattern with 3 endpoints
- Add background processor
- Add operation-status table
```

---

**Step 4: Regenerate with Fixes**
```bash
Skill: AIDLC-design:generate
Regenerate customer-portal Service-TDD
Fix protocol specifications for all external services
Update Lambda config to 1024MB / 30s
Add async pattern for customer-search (>16s operation)
```

**Agent Response:**
```
I will regenerate Service-TDD with the following fixes:
1. Specify REST protocol for customer-search CRM API
2. Replace placeholder URL for address-validation USPS API
3. Update Lambda config: 1024MB / 30s for all services
4. Add async pattern for customer-search:
   - POST /api/customers/search/async
   - GET /api/customers/search/status/{id}
   - Background processor Lambda
   - operation-status DynamoDB table

Proceed? (yes/no)
```

**You:** "Yes, proceed"

---

**Step 5: Re-validate**
```bash
Skill: AIDLC-design:validate
Validate updated customer-portal Service-TDD
Confirm all critical patterns are now compliant
```

**Agent Response:**
```
Validation Report: customer-portal-Service-TDD (Updated)

Critical Pattern Compliance: PASS

✓ Protocol Specification
  - All external services have protocol specified (REST)
  - All URLs are verified (no placeholders)

✓ Lambda Configuration
  - All Lambdas: 1024MB / 30s

✓ Async Operations Pattern
  - customer-search has complete async pattern:
    • POST /async endpoint
    • GET /status/{id} endpoint
    • Background processor Lambda
    • operation-status DynamoDB table

No violations found. Design is ready for code generation.
```

---

### Workflow 6: Cross-Document Traceability

**Scenario:** Trace requirements from FSD through all design documents.

**Step 1: Explore FSD Requirements**
```bash
Skill: AIDLC-design:explore
List all requirements in claims-processing FSD
Group by feature area (UI, Services, Integration)
```

**Agent Response:**
```
Claims-Processing FSD Requirements

UI Requirements:
- R-101: Claims submission form with validation
- R-102: Claims history dashboard
- R-103: Real-time claim status updates

Service Requirements:
- R-201: Claims validation service
- R-202: Claims processing workflow
- R-203: Claims enrichment with external data

Integration Requirements:
- R-301: Integration with claims database (DynamoDB)
- R-302: Integration with external validation service (REST)
- R-303: Integration with notification service (SNS)
```

---

**Step 2: Trace to Feature-TDD**
```bash
Skill: AIDLC-design:explore
Trace requirement R-456 "Claims auto-validation"
Show how it's addressed in Feature-TDD
```

**Agent Response:**
```
Requirement R-456: Claims Auto-Validation
Source: claims-processing-fsd.md, Section 3.2

Feature-TDD Coverage:
✓ Section 4.2: Business Logic
  - "Claims validation performed via Rules-as-a-Service"
  - "External OPA service validates claims structure and business rules"

✓ Section 5.1: Service Architecture
  - "claims-validator Lambda service"
  - "Integrates with Rules-as-a-Service for validation logic"

✓ Section 6.3: UI Components
  - "ClaimsValidatorPanelComponent displays validation results"
  - "Real-time validation feedback to user"
```

---

**Step 3: Trace to UI-TDD**
```bash
Skill: AIDLC-design:explore
Show how requirement R-456 maps to UI-TDD components
Which validators and form fields implement this requirement?
```

**Agent Response:**
```
Requirement R-456: Claims Auto-Validation
Mapped to UI-TDD: claims-processing-UI-TDD.md

Components:
1. ClaimsSubmissionFormComponent (Section 3.1)
   - Method: validateClaim()
   - Calls: claims-validator service API
   - Displays: Real-time validation errors

2. ClaimsValidatorPanelComponent (Section 3.3)
   - Displays: Validation results from Rules-as-a-Service
   - Shows: Business rule violations with error codes

Form Fields with Validation:
- claimNumber: Required, format validation
- claimAmount: Required, range validation (1-1000000)
- claimDate: Required, date validation (not future date)
- claimType: Required, enum validation (AUTO, HOME, LIFE)

Sequence Diagram Reference:
- Figure 3.1: Claims Validation Flow (Mermaid)
- Figure 3.2: UI → Service → Rules-as-a-Service (PlantUML)
```

---

**Step 4: Trace to Service-TDD**
```bash
Skill: AIDLC-design:explore
Show how requirement R-456 maps to Service-TDD
Which Lambda services handle auto-validation?
```

**Agent Response:**
```
Requirement R-456: Claims Auto-Validation
Mapped to Service-TDD: claims-processing-Service-TDD.md

Lambda Services:
1. claims-validator (Section 4.1)
   - Handler: validateClaimHandler()
   - Processor: ClaimValidationProcessor.validate()
   - Integration: Rules-as-a-Service (OPA) at https://rules.example.com/v1/data/claims/validate
   - Protocol: REST with JSON
   - Response: { valid: boolean, violations: [] }

11-Function Flow Engine (claims-validator):
1. validateInput() - Validate request structure
2. checkPermissions() - Verify user authorization
3. fetchClaim() - Retrieve claim from DynamoDB
4. enrichContext() - Add context for validation
5. callRulesService() - POST to Rules-as-a-Service OPA
6. parseRulesResponse() - Extract validation results
7. mapViolations() - Map rule violations to user messages
8. persistResults() - Save validation results
9. publishEvents() - Publish validation events
10. formatResponse() - Format validation response
11. handleError() - Error handling wrapper

Critical Patterns:
✓ Protocol: REST with JSON
✓ Rules-as-a-Service: External OPA validator
✓ Lambda Config: 1024MB / 30s
✓ Sequence Diagram: Section 4.1.5 (Mermaid + PlantUML)
```

---

**Step 5: Generate Traceability Report**
```bash
Skill: AIDLC-design:validate
Validate requirement traceability for R-456
Confirm it's fully covered in all three TDD documents
```

**Agent Response:**
```
Traceability Report: R-456 "Claims Auto-Validation"

Source: claims-processing-fsd.md, Section 3.2

Feature-TDD Coverage: ✓ COMPLETE
- Section 4.2: Business validation via Rules-as-a-Service
- Section 5.1: claims-validator Lambda service
- Section 6.3: ClaimsValidatorPanelComponent

UI-TDD Coverage: ✓ COMPLETE
- ClaimsSubmissionFormComponent.validateClaim()
- ClaimsValidatorPanelComponent displays results
- Form field validation rules
- Sequence diagrams present

Service-TDD Coverage: ✓ COMPLETE
- claims-validator Lambda service
- 11-function Flow Engine breakdown
- Rules-as-a-Service integration
- Protocol: REST with JSON
- Sequence diagrams present

Traceability: PASS
Requirement R-456 is fully traced through all three TDD documents with complete implementation specifications.
```

---

# Critical Pattern Enforcement

## Understanding Critical Patterns

AIDLC-design enforces **10 critical patterns** in all generated design documents to ensure implementation readiness
and architectural consistency. These patterns are based on Master TDD (Section 20) and represent proven architectural
approaches for enterprise Angular and AWS Lambda applications.

**Why Critical Patterns Matter:**
- **Prevent Common Mistakes**: Avoids anti-patterns like synchronous long operations, missing error handling
- **Ensure Scalability**: Async patterns, caching, and proper Lambda configuration
- **Enable Code Generation**: LLM pair programmers need specific patterns to generate correct code
- **Maintain Consistency**: All services follow the same architectural standards

---

## Protocol Specification

**Pattern:** All external service integrations must specify protocol (SOAP vs REST) - no assumptions.

**Why It Matters:**
- Different protocols require different client libraries (SOAP: xml2js, REST: axios)
- SOAP requires WSDL parsing and envelope construction
- REST uses JSON payloads and standard HTTP methods

**Example (Correct):**
```markdown
### External Service Integration: Customer Validation

**Protocol:** REST with JSON
**Endpoint:** POST https://api.example.com/v2/customers/validate
**Request Format:**
```json
{
  "customerId": "string",
  "validationType": "enum"
}
```

**Response Format:**
```json
{
  "valid": boolean,
  "errors": []
}
```
```

**Example (Incorrect - Missing Protocol):**
```markdown
### External Service Integration: Customer Validation

**Endpoint:** https://api.example.com/customers/validate
<!-- ✗ Protocol not specified - pair programmer doesn't know SOAP vs REST -->
```

**Validation Check:**
```bash
Skill: AIDLC-design:validate
Check protocol specifications in customer-portal Service-TDD

# Output:
✗ Protocol Specification Missing
  - customer-validation service has no protocol specification
```

---

## Endpoint Verification

**Pattern:** All external service endpoint URLs must be verified - NEVER guess or use placeholders.

**Why It Matters:**
- Placeholder URLs like `https://example.com/api` break production code
- Guessed endpoints lead to integration failures
- Pair programmers will use the exact URL in generated code

**Example (Correct - Verified URL):**
```markdown
### External Service Integration: Address Validation

**Protocol:** REST with JSON
**Endpoint:** POST https://secure.shippingapis.com/ShippingAPI.dll?API=Verify
**API Documentation:** https://www.usps.com/business/web-tools-apis/address-information-api.htm
**Authentication:** API Key in query parameter
```

**Example (Incorrect - Placeholder URL):**
```markdown
### External Service Integration: Address Validation

**Protocol:** REST
**Endpoint:** https://example.com/api/validate
<!-- ✗ Placeholder URL - will not work in production -->
```

**How to Handle Unknown URLs:**
If the actual endpoint URL is not available, the design document should:
1. Mark the URL as "TO BE DETERMINED" with a clear action item
2. Document the expected URL pattern based on vendor documentation
3. Include instructions for obtaining the actual URL (e.g., "Contact vendor for production URL")

**Example (Correct - URL TBD):**
```markdown
### External Service Integration: Credit Score API

**Protocol:** REST with JSON
**Endpoint:** [TO BE DETERMINED - Contact Equifax for production URL]
**Expected Pattern:** https://api.equifax.com/v2/credit-score
**API Documentation:** https://developer.equifax.com/credit-score-api
**Action Item:** Product Owner to request production API URL from Equifax account manager
```

**Validation Check:**
```bash
Skill: AIDLC-design:validate
Check endpoint URLs in claims-processing Service-TDD

# Output:
✗ Endpoint Verification Failed
  - address-validation service has placeholder URL "https://example.com/api"
  - credit-score service URL not specified
```

---

## Async Operations Pattern

**Pattern:** Operations taking >16s must use 3-endpoint async pattern with operation-status table and polling.

**Why It Matters:**
- API Gateway has 30s timeout limit
- Lambda synchronous execution times out after 30s (even with 1024MB)
- Long operations need background processing with status polling

**When to Use:**
- Data enrichment from slow external APIs (>16s)
- Batch processing operations
- Complex multi-step workflows
- Report generation

**Required Components:**
1. **POST /api/resource/async** → Returns `{ operationId }`, starts background processor
2. **GET /api/resource/status/{operationId}** → Returns `{ status, result }`
3. **Background processor Lambda** → Executes operation, updates operation-status table
4. **DynamoDB operation-status table** → Stores operation state

**Example (Correct - Async Pattern):**
```markdown
### Service: Claims Enrichment

**Operation Time:** ~45 seconds (external data sources)

**Async Pattern:**

#### 1. Initiate Enrichment
**Endpoint:** POST /api/claims/enrich/async
**Handler:** initiateEnrichmentHandler()
**Flow:**
1. Validate request structure
2. Generate operationId (UUID)
3. Store in operation-status table with status: "PENDING"
4. Publish message to enrichment-queue (SQS)
5. Return { operationId } immediately

#### 2. Check Status
**Endpoint:** GET /api/claims/enrich/status/{operationId}
**Handler:** checkEnrichmentStatusHandler()
**Flow:**
1. Query operation-status table by operationId
2. Return { status: "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED", result }

#### 3. Background Processor
**Trigger:** SQS enrichment-queue
**Handler:** processEnrichmentHandler()
**Flow:**
1. Receive message from SQS
2. Execute enrichment (call external APIs)
3. Update operation-status table:
   - Status: "PROCESSING" → "COMPLETED"
   - Result: enriched claims data
4. Delete message from SQS

#### DynamoDB Table: operation-status
**Partition Key:** operationId (String)
**Attributes:**
- status: String (PENDING, PROCESSING, COMPLETED, FAILED)
- result: Map (enriched data or error details)
- createdAt: Number (timestamp)
- updatedAt: Number (timestamp)
- ttl: Number (24h expiration)
```

**Example (Incorrect - Synchronous with Timeout):**
```markdown
### Service: Claims Enrichment

**Endpoint:** POST /api/claims/enrich
**Handler:** enrichClaimsHandler()
**Flow:**
1. Validate request
2. Call external APIs to enrich claims (45s)
3. Return enriched claims

<!-- ✗ No async pattern - will timeout after 30s -->
```

**Validation Check:**
```bash
Skill: AIDLC-design:validate
Check async pattern in claims-enrichment Service-TDD

# Output:
✗ Async Operations Pattern Missing
  - claims-enrichment operation takes >16s but has no async pattern
  - Missing: POST /async endpoint
  - Missing: GET /status/{id} endpoint
  - Missing: Background processor Lambda
  - Missing: operation-status DynamoDB table
```

---

## Lambda Configuration

**Pattern:** All Lambda functions must use 1024MB memory / 30s timeout (not 512MB / 16s).

**Why It Matters:**
- 1024MB provides better CPU performance (proportional to memory)
- 30s timeout accommodates API Gateway timeout limit
- 512MB / 16s is too conservative for most enterprise operations

**Example (Correct):**
```markdown
### Lambda Configuration

**Memory:** 1024 MB
**Timeout:** 30 seconds
**Runtime:** Node.js 20.x
**Environment Variables:**
- CLAIMS_TABLE_NAME: claims-table
- RULES_SERVICE_URL: https://rules.example.com/v1/data/claims/validate
```

**Example (Incorrect):**
```markdown
### Lambda Configuration

**Memory:** 512 MB
**Timeout:** 16 seconds
<!-- ✗ Too conservative - should be 1024MB / 30s -->
```

**Validation Check:**
```bash
Skill: AIDLC-design:validate
Check Lambda configuration in customer-portal Service-TDD

# Output:
✗ Lambda Configuration Incorrect
  - customer-search Lambda: 512MB / 16s (should be 1024MB / 30s)
```

---

## 11-Function Flow Engine

**Pattern:** Multi-step workflows must be broken down into 11 standardized functions for clarity and testability.

**Why It Matters:**
- Prevents monolithic handler functions (1000+ lines)
- Enables unit testing of individual steps
- Provides clear separation of concerns
- Makes code generation more precise

**Standard 11 Functions:**
1. **validateInput()** - Validate request structure and required fields
2. **checkPermissions()** - Verify user authorization and access control
3. **fetchData()** - Retrieve data from DynamoDB or external API
4. **enrichContext()** - Add contextual data needed for processing
5. **processBusinessLogic()** - Execute core business logic
6. **applyBusinessRules()** - Validate via Rules-as-a-Service
7. **transformData()** - Transform data to output format
8. **persistResults()** - Save results to DynamoDB
9. **publishEvents()** - Publish events to SNS/EventBridge
10. **formatResponse()** - Format success response
11. **handleError()** - Go-style error handling wrapper

**Example (Correct - 11-Function Breakdown):**
```markdown
### Lambda Service: Claims Processor

**Handler:** processClaimHandler()

**11-Function Flow Engine:**

1. **validateInput(event)**
   - Validate claim structure
   - Check required fields: claimId, claimType, claimAmount
   - Return: [error, validatedClaim]

2. **checkPermissions(userId, claim)**
   - Verify user has permission to process claim
   - Check role: CLAIMS_PROCESSOR or ADMIN
   - Return: [error, authorized]

3. **fetchClaim(claimId)**
   - Query DynamoDB: claims-table
   - Return: [error, claim]

4. **enrichContext(claim)**
   - Fetch customer details from customer-table
   - Fetch policy details from policy-table
   - Return: [error, enrichedClaim]

5. **processBusinessLogic(enrichedClaim)**
   - Calculate claim approval amount
   - Determine processing status
   - Return: [error, processedClaim]

6. **applyBusinessRules(processedClaim)**
   - POST to Rules-as-a-Service: https://rules.example.com/v1/data/claims/process
   - Validate claim against business rules
   - Return: [error, validatedClaim]

7. **transformData(validatedClaim)**
   - Transform to output format
   - Return: [error, transformedClaim]

8. **persistResults(transformedClaim)**
   - Update DynamoDB: claims-table
   - Set status: PROCESSED
   - Return: [error, savedClaim]

9. **publishEvents(savedClaim)**
   - Publish to SNS: claims-processed-topic
   - Event: { claimId, status, amount }
   - Return: [error, publishResult]

10. **formatResponse(savedClaim)**
    - Format success response
    - Return: { statusCode: 200, body: savedClaim }

11. **handleError(error)**
    - Log error to CloudWatch
    - Return structured error response
    - Return: { statusCode: 500, body: { error } }

**Main Handler Flow:**
```javascript
async function processClaimHandler(event) {
  const [validateErr, validatedClaim] = await validateInput(event);
  if (validateErr) return handleError(validateErr);

  const [permErr, authorized] = await checkPermissions(event.userId, validatedClaim);
  if (permErr) return handleError(permErr);

  const [fetchErr, claim] = await fetchClaim(validatedClaim.claimId);
  if (fetchErr) return handleError(fetchErr);

  // ... continue through all 11 functions
}
```
```

**Example (Incorrect - Monolithic Handler):**
```markdown
### Lambda Service: Claims Processor

**Handler:** processClaimHandler()

**Flow:**
1. Validate claim
2. Process claim
3. Save to DynamoDB
4. Return response

<!-- ✗ No function breakdown - monolithic handler -->
```

**Validation Check:**
```bash
Skill: AIDLC-design:validate
Check 11-function Flow Engine in claims-processor Service-TDD

# Output:
✗ 11-Function Flow Engine Missing
  - claims-processor has no function breakdown
  - Expected: 11 functions (validateInput, checkPermissions, etc.)
```

---

## Rules-as-a-Service

**Pattern:** Business validation must use external OPA (Open Policy Agent) service - no embedded validation logic.

**Why It Matters:**
- Business rules change frequently without code deployment
- Non-technical users can update rules via OPA Rego
- Separation of policy from code (compliance requirement)
- Centralized rule management across services

**Example (Correct - Rules-as-a-Service):**
```markdown
### Business Validation: Claims Rules

**Rules Engine:** OPA (Open Policy Agent)
**Endpoint:** POST https://rules.example.com/v1/data/claims/validate
**Protocol:** REST with JSON

**Request Format:**
```json
{
  "input": {
    "claim": {
      "claimId": "C123456",
      "claimType": "AUTO",
      "claimAmount": 5000,
      "policyStatus": "ACTIVE"
    },
    "user": {
      "userId": "U789",
      "role": "CLAIMS_PROCESSOR"
    }
  }
}
```

**Response Format:**
```json
{
  "result": {
    "valid": true,
    "violations": [],
    "warnings": []
  }
}
```

**Lambda Integration:**
```javascript
async function applyBusinessRules(claim) {
  const response = await axios.post('https://rules.example.com/v1/data/claims/validate', {
    input: { claim, user: event.user }
  });

  if (!response.data.result.valid) {
    return [{ code: 'RULE_VIOLATION', violations: response.data.result.violations }, null];
  }

  return [null, claim];
}
```
```

**Example (Incorrect - Embedded Validation Logic):**
```markdown
### Business Validation: Claims Rules

**Lambda Function:** validateClaimBusinessRules()

**Rules:**
1. Claim amount must be < $10,000 for AUTO claims
2. Claim amount must be < $50,000 for HOME claims
3. Policy must be ACTIVE status
4. User must have CLAIMS_PROCESSOR role

<!-- ✗ Embedded rules in Lambda code - should use Rules-as-a-Service -->
```

**Validation Check:**
```bash
Skill: AIDLC-design:validate
Check Rules-as-a-Service integration in claims-validator Service-TDD

# Output:
✗ Rules-as-a-Service Missing
  - claims-validator has embedded validation logic
  - Expected: External OPA service integration
```

---

## Reference-Data Dropdown Pattern

**Pattern:** Dropdown fields populated from Reference Data Management (RDM) API with caching strategy (24h TTL).

**Why It Matters:**
- Centralized reference data management (states, countries, claim types)
- Caching reduces API calls and improves performance
- Reference data changes without code deployment

**Example (Correct - RDM with Caching):**
```markdown
### Dropdown Field: Claim Type

**Data Source:** Reference Data Management (RDM) API
**Endpoint:** GET https://rdm.example.com/v1/reference-data/claim-types
**Protocol:** REST with JSON
**Caching:** 24-hour TTL (Time-To-Live)

**Caching Strategy:**
1. UI component checks localStorage for cached data
2. If cache exists and not expired (< 24h), use cached data
3. If cache missing or expired, fetch from RDM API
4. Store response in localStorage with timestamp

**Response Format:**
```json
{
  "claimTypes": [
    { "code": "AUTO", "description": "Auto Insurance Claim" },
    { "code": "HOME", "description": "Home Insurance Claim" },
    { "code": "LIFE", "description": "Life Insurance Claim" }
  ]
}
```

**Angular Service Implementation:**
```typescript
@Injectable({ providedIn: 'root' })
export class ReferenceDataService {
  private readonly CACHE_KEY = 'rdm_claim_types';
  private readonly CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours

  async getClaimTypes(): Promise<ClaimType[]> {
    const cached = this.getCachedData(this.CACHE_KEY);
    if (cached) return cached;

    const response = await this.http.get('https://rdm.example.com/v1/reference-data/claim-types').toPromise();
    this.setCachedData(this.CACHE_KEY, response.claimTypes);
    return response.claimTypes;
  }

  private getCachedData(key: string): any {
    const cached = localStorage.getItem(key);
    if (!cached) return null;

    const { data, timestamp } = JSON.parse(cached);
    if (Date.now() - timestamp > this.CACHE_TTL) {
      localStorage.removeItem(key);
      return null;
    }

    return data;
  }

  private setCachedData(key: string, data: any): void {
    localStorage.setItem(key, JSON.stringify({ data, timestamp: Date.now() }));
  }
}
```
```

**Example (Incorrect - Hardcoded Dropdown):**
```markdown
### Dropdown Field: Claim Type

**Options:**
- AUTO
- HOME
- LIFE

<!-- ✗ Hardcoded values - should use RDM API with caching -->
```

**Validation Check:**
```bash
Skill: AIDLC-design:validate
Check reference-data dropdown pattern in claims-submission UI-TDD

# Output:
✗ Reference-Data Dropdown Pattern Missing
  - claimType dropdown has hardcoded values
  - Expected: RDM API integration with 24h TTL caching
```

---

## Sequence Diagrams

**Pattern:** ALL services must have sequence diagrams in both Mermaid and PlantUML formats showing complete flow.

**Why It Matters:**
- Visual documentation of request/response flow
- Shows interaction between UI, Lambda, external services
- Helps pair programmers understand the complete flow
- PlantUML for detailed documentation, Mermaid for quick visualization

**Example (Correct - Both Formats):**
```markdown
### Sequence Diagram: Claims Validation Flow

#### Mermaid Diagram
```mermaid
sequenceDiagram
    participant UI as Claims UI
    participant Lambda as claims-validator
    participant Rules as Rules-as-a-Service (OPA)
    participant DB as DynamoDB

    UI->>Lambda: POST /api/claims/validate
    Lambda->>Lambda: validateInput()
    Lambda->>DB: fetchClaim()
    DB-->>Lambda: claim data
    Lambda->>Rules: POST /v1/data/claims/validate
    Rules-->>Lambda: validation result
    Lambda->>DB: persistResults()
    Lambda-->>UI: validation response
```

#### PlantUML Diagram
```plantuml
@startuml
actor User
participant "Claims UI" as UI
participant "claims-validator\nLambda" as Lambda
participant "Rules-as-a-Service\n(OPA)" as Rules
database "DynamoDB" as DB

User -> UI: Submit claim
UI -> Lambda: POST /api/claims/validate\n{claimId, claimData}

Lambda -> Lambda: 1. validateInput()
note right: Validate request structure

Lambda -> DB: 2. fetchClaim(claimId)
DB --> Lambda: claim data

Lambda -> Lambda: 3. enrichContext()
note right: Add customer/policy context

Lambda -> Rules: 4. applyBusinessRules()\nPOST /v1/data/claims/validate
note right: External OPA validation
Rules --> Lambda: {valid, violations}

alt validation passed
    Lambda -> DB: 5. persistResults()\nUpdate status: VALIDATED
    Lambda --> UI: 200 OK\n{valid: true}
    UI --> User: Success message
else validation failed
    Lambda --> UI: 400 Bad Request\n{violations}
    UI --> User: Error message
end
@enduml
```
```

**Example (Incorrect - Missing Diagrams):**
```markdown
### Claims Validation Flow

1. UI submits claim
2. Lambda validates claim
3. Rules service checks business rules
4. Lambda returns validation result

<!-- ✗ No sequence diagrams - should have both Mermaid and PlantUML -->
```

**Validation Check:**
```bash
Skill: AIDLC-design:validate
Check sequence diagrams in claims-validator Service-TDD

# Output:
✗ Sequence Diagrams Missing
  - claims-validator has no Mermaid diagram
  - claims-validator has no PlantUML diagram
  - Expected: Both formats required
```

---

## Master TDD References

**Pattern:** All major sections must include references to Master TDD sections for traceability (v5.0.1+).

**Why It Matters:**
- Ensures alignment with enterprise architecture strategy
- Provides traceability to design patterns and standards
- Helps developers understand the rationale behind design decisions
- Enables consistency across all technical design documents

**Example (Correct - Master TDD References):**
```markdown
# Claims-Validator Service Technical Design Document

> **Master TDD Reference**: Section 20 - Lambda Code Generation Template
> **Service Type**: Consolidated Service Technical Design Document

## 1. Introduction

> **Master TDD Reference**: Section 3.2 - Core Services and Shared Libraries

This document specifies the technical design for the claims-validator service...

## 2. Technical Architecture

> **Master TDD Reference**: Section 20.4 - Architectural Layers and Responsibilities

The claims-validator service follows the three-layer architecture pattern:
- Handler Layer
- Processor Layer
- Helper Layer

## 3. Business Validation

> **Master TDD Reference**: Section 20.8 - Rules-as-a-Service Integration

Business validation is performed via external OPA (Open Policy Agent) service...

## 4. Async Operations Pattern

> **Master TDD Reference**: Section 20.9 - Async Operations Pattern for Long-Running Operations

Operations taking >16 seconds use the 3-endpoint async pattern...
```

**Example (Incorrect - No Master TDD References):**
```markdown
# Claims-Validator Service Technical Design Document

## 1. Introduction

This document specifies the technical design for the claims-validator service...

<!-- ✗ No Master TDD references - missing traceability -->
```

**Validation Check:**
```bash
Skill: AIDLC-design:validate
Check Master TDD references in claims-validator Service-TDD

# Output:
✗ Master TDD References Missing
  - Document header missing Master TDD reference
  - Section 2 (Technical Architecture) missing reference
  - Section 3 (Business Validation) missing reference
```

---

# Advanced Topics

## Policy Object Model (POM) Integration

The Policy Object Model (POM) defines the data structure for insurance policies, claims, and related entities.
AIDLC-design focuses on **relevant POM subsections** for each feature rather than the entire model.

**Design Principle: Instruction-Driven**
- POM integration only occurs when user explicitly provides POM subsection
- Not automatic - user must specify which POM fields to use
- Only fields needed for the specific workflow are mapped

**Example: Mapping POM to UI Components**

**User Request:**
```bash
Skill: AIDLC-design:generate
Generate UI-TDD for claims-submission form
POM subsection: Claims.Submission (fields: claimNumber, claimDate, claimAmount, claimType)
Map to form components with validation rules
```

**Generated UI-TDD:**
```markdown
### Component: ClaimsSubmissionFormComponent

**POM Mapping:**

| POM Field | UI Field | Type | Validation |
|-----------|----------|------|------------|
| Claims.Submission.claimNumber | claimNumberInput | string | Required, pattern: /^C\d{6}$/ |
| Claims.Submission.claimDate | claimDatePicker | Date | Required, not future date |
| Claims.Submission.claimAmount | claimAmountInput | number | Required, range: 1-1000000 |
| Claims.Submission.claimType | claimTypeDropdown | enum | Required, values: AUTO, HOME, LIFE |

**Form Structure:**
```typescript
export interface ClaimsSubmissionForm {
  claimNumber: string;      // POM: Claims.Submission.claimNumber
  claimDate: Date;          // POM: Claims.Submission.claimDate
  claimAmount: number;      // POM: Claims.Submission.claimAmount
  claimType: ClaimTypeEnum; // POM: Claims.Submission.claimType
}
```
```

**Why Instruction-Driven?**
- **Large POM**: Complete POM can be 10K+ fields across all insurance lines
- **Feature-Specific**: Each feature only needs 5-20 fields
- **Avoids Noise**: Automatic POM inclusion would add irrelevant context
- **User Control**: User specifies which POM subsection to use

---

## Selective Reading for Large Documents

Master TDD is ~41K tokens. AIDLC-design uses **selective reading** to efficiently process large reference documents.

**Technique: Section-Based Reading**
1. Read Master TDD table of contents (first 500 lines)
2. Identify relevant section (e.g., Section 20: Lambda Code Generation)
3. Read only that section (typically 2K-5K tokens)
4. Extract patterns needed for current design task

**Example:**
```bash
Skill: AIDLC-design:generate
Generate Service-TDD for claims-validator Lambda

# Agent reads:
# 1. Master TDD TOC → Finds "Section 20: Lambda Code Generation Template"
# 2. Master TDD Section 20 → Extracts 11-function Flow Engine, Lambda config
# 3. Master TDD Section 20.8 → Extracts Rules-as-a-Service pattern
# 4. Skips: UI patterns, Angular components, DynamoDB schemas (not needed for Lambda)
```

**Why Selective Reading?**
- **Token Efficiency**: Reduces token usage by 85-90%
- **Faster Processing**: Reads 5K tokens instead of 41K tokens
- **Focused Context**: Only relevant patterns loaded into context
- **Cost Reduction**: Lower API costs for large document processing

---

## Quality Checklist

Before completion, AIDLC-design verifies all generated documents against a **24-point quality checklist**.

**Checklist Items:**

**Requirements Coverage (4 items):**
- [ ] All FSD features addressed in Feature-TDD
- [ ] All components from Feature-TDD included in UI-TDD
- [ ] All services from Feature-TDD included in Service-TDD
- [ ] POM field mappings accurate (if provided)

**Component Specifications (3 items):**
- [ ] Component inputs/outputs clearly defined (UI-TDD)
- [ ] State management patterns (Angular Signals) specified
- [ ] Lifecycle hooks documented

**Critical Patterns (10 items):**
- [ ] Protocol specification (SOAP or REST) for all external services
- [ ] Endpoint URLs verified (NEVER guess or use placeholders like example.com)
- [ ] Async pattern for operations >16s with operation-status table
- [ ] Lambda config: 1024MB / 30s timeout (not 512MB/16s)
- [ ] 11-function Flow Engine for multi-step workflows
- [ ] Rules-as-a-Service integration (no embedded validation logic)
- [ ] Reference-data dropdown pattern with RDM integration (when applicable)
- [ ] Enhanced sequence diagrams showing all functions + protocol + async branching
- [ ] Manual TDD references (Master TDD, Common Library TDD) included
- [ ] Anti-pattern validation passed (10-point checklist)

**Error Handling (2 items):**
- [ ] Error handling with go-style pattern ([error, result])
- [ ] Error logging and CloudWatch integration

**Security & Accessibility (2 items):**
- [ ] Accessibility requirements included (WCAG 2.1 Level AA)
- [ ] Security considerations documented (OWASP guidelines)

**Testing & Documentation (3 items):**
- [ ] Testing requirements defined (unit, integration, E2E)
- [ ] Sequence diagrams present (Mermaid + PlantUML)
- [ ] Ready for code generation by pair programmers

**Run Quality Check:**
```bash
Skill: AIDLC-design:validate
Run quality checklist for claims-submission Feature-TDD

# Output:
Quality Checklist: claims-submission-Feature-TDD

✓ Requirements Coverage: 12/12 (100%)
✓ Component Specifications: 5/5 (100%)
✓ Critical Patterns: 10/10 (100%)
✓ Error Handling: 2/2 (100%)
✓ Security & Accessibility: 2/2 (100%)
✓ Testing & Documentation: 3/3 (100%)

Overall: 34/34 (100%) - READY FOR CODE GENERATION
```

---

# Examples & Reference

## Real-World Examples

### Example 1: Generating Feature-TDD from FSD

**Context:** Starting a new feature for customer-portal. Have an FSD document with requirements.

**Conversation:**

```
You: Generate Feature-TDD from the customer-portal FSD

Claude: Let me locate the FSD and Master TDD reference documents.

[Searches workspace for FSD files]
[Finds: ./requirements/customer-portal-fsd.md]

Feature-TDD Generation Plan:

1. Read FSD: ./requirements/customer-portal-fsd.md
2. Extract Master TDD Section 20 (Lambda patterns)
3. Extract Master TDD Section 15 (Angular components)
4. Identify UI components and Lambda services
5. Verify protocol specifications for external services
6. Create customer-portal-Feature-TDD.md

Identified Components:
- UI: CustomerSearchComponent, CustomerProfileComponent, CustomerHistoryComponent
- Services: customer-search Lambda, customer-profile Lambda, customer-history Lambda

Identified External Integrations:
- CRM API (customer data) - Need to verify protocol
- USPS API (address validation) - Need to verify protocol

Would you like me to proceed with this plan?

You: The CRM API is REST with JSON at https://api.crm.example.com/v2/customers. The USPS API is also REST at https://secure.shippingapis.com/ShippingAPI.dll?API=Verify. Proceed.

Claude: Thank you for the endpoint details. Generating Feature-TDD...

[Delegates to feature-tdd-designer agent]
[Reads FSD]
[Extracts Master TDD patterns]
[Generates Feature-TDD]

✅ Generated: .claude_kb/workspaces/EPIC-12345/technical/design/customer-portal-Feature-TDD.md

Summary:
- 3 UI components (Angular + Axis framework)
- 3 Lambda services (Node.js with three-layer architecture)
- 2 external integrations (REST with JSON)
- Master TDD references included in all major sections

Next steps:
1. Generate UI-TDD for component specifications
2. Generate Service-TDD for Lambda specifications
```

**Key Takeaways:**
- Agent presents plan before generation
- User provides endpoint URLs (no guessing/placeholders)
- Master TDD patterns automatically applied
- Output location follows convention

---

### Example 2: Creating UI-TDD for Angular Components

**Context:** Feature-TDD is complete. Need detailed component specifications for AIDLC-axis.

**Conversation:**

```
You: Create UI-TDD for customer-portal feature

Claude: Let me locate the Feature-TDD to extract component specifications.

[Searches workspace]
[Finds: ./workspace/EPIC-12345/technical/design/customer-portal-Feature-TDD.md]

UI-TDD Generation Plan:

1. Read customer-portal-Feature-TDD.md
2. Extract 3 UI components:
   - CustomerSearchComponent
   - CustomerProfileComponent
   - CustomerHistoryComponent
3. Generate AUG JSON schemas for each component
4. Create Mermaid and PlantUML sequence diagrams
5. Map POM fields (if provided)
6. Create customer-portal-UI-TDD.md

Would you like me to include POM field mapping?

You: Yes, use POM subsection Customer.Profile (fields: customerId, firstName, lastName, email, phone)

Claude: Generating UI-TDD with POM mapping...

[Delegates to ui-tdd-designer agent]
[Reads Feature-TDD]
[Extracts component specs]
[Creates AUG JSON schemas]
[Generates sequence diagrams]
[Maps POM fields]

✅ Generated: .claude_kb/workspaces/EPIC-12345/technical/design/customer-portal-UI-TDD.md

Summary:
- 3 Angular components with Axis framework patterns
- AUG JSON schemas for dynamic UI rendering
- POM field mapping: Customer.Profile → CustomerProfileComponent
- Sequence diagrams (Mermaid + PlantUML)
- Cross-field validation rules
- Ready for AIDLC-axis code generation

Next steps:
1. Pass UI-TDD to AIDLC-axis plugin
2. Generate Angular components
```

**Key Takeaways:**
- Agent locates Feature-TDD automatically
- User specifies POM subsection for mapping
- AUG JSON schemas generated for dynamic UI
- Sequence diagrams in both formats

---

### Example 3: Generating Service-TDD for Lambda

**Context:** Feature-TDD is complete. Need consolidated Lambda specifications for all services.

**Conversation:**

```
You: Generate Service-TDD for customer-portal Lambda services

Claude: Let me locate the Feature-TDD to extract service specifications.

[Searches workspace]
[Finds: ./workspace/EPIC-12345/technical/design/customer-portal-Feature-TDD.md]

Service-TDD Generation Plan:

1. Read customer-portal-Feature-TDD.md
2. Extract 3 Lambda services:
   - customer-search (REST, async pattern - 20s operation)
   - customer-profile (REST, synchronous)
   - customer-history (REST, synchronous)
3. Apply critical patterns:
   - Protocol: REST with JSON
   - Lambda config: 1024MB / 30s
   - Async pattern for customer-search (>16s)
   - 11-function Flow Engine for all services
   - Rules-as-a-Service integration
4. Generate sequence diagrams (Mermaid + PlantUML)
5. Create customer-portal-Service-TDD.md

Identified Critical Patterns:
✓ customer-search requires async pattern (20s operation)
✓ All services use REST protocol
✓ Integration with CRM API (REST)
✓ Integration with USPS API (REST)

Would you like me to proceed?

You: Yes, proceed

Claude: Generating Service-TDD with critical patterns...

[Delegates to service-tdd-designer agent]
[Reads Feature-TDD]
[Extracts service specs]
[Applies critical patterns]
[Generates sequence diagrams]

✅ Generated: .claude_kb/workspaces/EPIC-12345/technical/design/customer-portal-Service-TDD.md

Summary:
- 3 Lambda services with three-layer architecture
- Async pattern for customer-search:
  • POST /api/customers/search/async
  • GET /api/customers/search/status/{id}
  • Background processor Lambda
  • operation-status DynamoDB table
- 11-function Flow Engine breakdown for all services
- Protocol specifications: REST with JSON
- Lambda config: 1024MB / 30s
- Sequence diagrams (Mermaid + PlantUML)
- Master TDD references included
- Ready for AIDLC-lambda code generation

Critical Patterns Applied:
✓ Async operations pattern (customer-search)
✓ 11-function Flow Engine (all services)
✓ Rules-as-a-Service integration
✓ Protocol specification (REST)
✓ Endpoint verification (no placeholders)

Next steps:
1. Pass Service-TDD to AIDLC-lambda plugin
2. Generate Lambda services
```

**Key Takeaways:**
- Agent identifies need for async pattern (20s operation)
- All critical patterns automatically applied
- Consolidated Service-TDD for all Lambda services
- Ready for code generation

---

### Example 4: Validating Design Coverage

**Context:** Feature-TDD, UI-TDD, and Service-TDD are complete. Need to validate coverage and compliance.

**Conversation:**

```
You: Validate all three TDD documents for customer-portal

Claude: Let me validate coverage and critical pattern compliance.

[Locates all three TDD documents]
[Reads original FSD]
[Validates coverage]
[Checks critical patterns]

Validation Report: customer-portal Design Documents

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Feature-TDD Coverage

Requirements Coverage: 100% (15/15 requirements)
✓ Customer search functionality (R-101)
✓ Customer profile display (R-102)
✓ Customer history tracking (R-103)
✓ Address validation (R-104)
✓ CRM integration (R-105)
[... 10 more requirements]

Critical Patterns: PASS
✓ Protocol specifications present (REST with JSON)
✓ Endpoint URLs verified (no placeholders)
✓ Lambda configuration correct (1024MB / 30s)
✓ Master TDD references included

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

2. UI-TDD Coverage

Component Coverage: 100% (3/3 components)
✓ CustomerSearchComponent
✓ CustomerProfileComponent
✓ CustomerHistoryComponent

Critical Patterns: PASS
✓ AUG JSON schemas present
✓ Sequence diagrams (Mermaid + PlantUML)
✓ Cross-field validation rules
✓ POM field mappings accurate

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

3. Service-TDD Coverage

Service Coverage: 100% (3/3 services)
✓ customer-search Lambda
✓ customer-profile Lambda
✓ customer-history Lambda

Critical Patterns: PASS
✓ Async pattern for customer-search
✓ 11-function Flow Engine for all services
✓ Rules-as-a-Service integration
✓ Protocol specifications (REST)
✓ Sequence diagrams (Mermaid + PlantUML)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

4. Cross-Document Consistency

✓ Components match between Feature-TDD and UI-TDD
✓ Services match between Feature-TDD and Service-TDD
✓ External integrations consistent across all documents

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Overall: PASS (100% coverage, no violations)

Design is ready for code generation.

You: Great! Can you check if there are any potential issues or improvements?

Claude: Let me perform a deeper analysis...

[Analyzes design patterns]
[Checks for anti-patterns]
[Reviews architecture decisions]

Design Review: Potential Improvements

1. Performance Optimization
   ⚠️ customer-history Lambda fetches all history records
   Recommendation: Add pagination support (limit 50 records per page)

2. Caching Strategy
   ⚠️ customer-profile Lambda fetches from CRM on every request
   Recommendation: Add Redis cache for customer profiles (5-minute TTL)

3. Error Handling
   ✓ All services use go-style error handling ([error, result])
   ✓ CloudWatch logging configured

4. Security
   ✓ OAuth 2.0 authentication
   ✓ API Gateway authorization
   ⚠️ Consider adding rate limiting for customer-search API

Overall: Design is solid. Optional improvements suggested for performance and scalability.

You: Add those improvements to the Service-TDD

Claude: Updating Service-TDD with performance and scalability improvements...

[Updates Service-TDD]
[Adds pagination to customer-history]
[Adds Redis cache to customer-profile]
[Adds rate limiting to customer-search]

✅ Updated: customer-portal-Service-TDD.md

Changes:
1. customer-history: Added pagination (limit 50, offset parameter)
2. customer-profile: Added Redis cache (5-minute TTL)
3. customer-search: Added rate limiting (100 requests/minute per user)

Design is now optimized for production workloads.
```

**Key Takeaways:**
- Validation checks coverage, critical patterns, and consistency
- Agent provides recommendations for improvements
- User can request updates to address recommendations
- Validation report is detailed and actionable

---

### Example 5: Exploring Existing Designs

**Context:** Need to understand how async pattern is implemented across multiple services.

**Conversation:**

```
You: Show me all services using the async operations pattern

Claude: Let me search for services with async pattern across all TDD documents.

[Searches workspace for Service-TDD files]
[Greps for async pattern keywords]
[Reads relevant sections]

Services Using Async Operations Pattern:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. customer-search (customer-portal-Service-TDD.md)

Operation Time: ~20 seconds (CRM API + USPS API)

Async Pattern:
✓ POST /api/customers/search/async → Returns { operationId }
✓ GET /api/customers/search/status/{id} → Returns { status, result }
✓ Background processor: customer-search-processor Lambda
✓ DynamoDB table: customer-search-operations

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

2. claims-enrichment (claims-processing-Service-TDD.md)

Operation Time: ~45 seconds (external data sources)

Async Pattern:
✓ POST /api/claims/enrich/async → Returns { operationId }
✓ GET /api/claims/enrich/status/{id} → Returns { status, result }
✓ Background processor: claims-enrichment-processor Lambda
✓ DynamoDB table: claims-enrichment-operations

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

3. report-generation (reporting-Service-TDD.md)

Operation Time: ~30 seconds (large dataset aggregation)

Async Pattern:
✓ POST /api/reports/generate/async → Returns { operationId }
✓ GET /api/reports/status/{id} → Returns { status, result }
✓ Background processor: report-generation-processor Lambda
✓ DynamoDB table: report-operations

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Summary: 3 services use async pattern (all operations >16s)

You: Compare the async pattern in customer-search with the Master TDD specification

Claude: Comparing customer-search async pattern with Master TDD...

[Reads Master TDD Section 20.8: Async Operations Pattern]
[Reads customer-search Service-TDD async pattern]
[Performs comparison]

Comparison: customer-search vs Master TDD Async Pattern

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Master TDD Specification (Section 20.8):

Required Components:
1. POST /api/resource/async → Returns { operationId }
2. GET /api/resource/status/{operationId} → Returns { status, result }
3. Background processor Lambda
4. DynamoDB operation-status table with TTL (24h)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

customer-search Implementation:

✓ POST /api/customers/search/async → Returns { operationId }
✓ GET /api/customers/search/status/{id} → Returns { status, result }
✓ Background processor: customer-search-processor Lambda
✓ DynamoDB table: customer-search-operations
✗ TTL not specified (should be 24h)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Compliance: 90% (4/5 requirements met)

Recommendation: Add TTL configuration to customer-search-operations table

You: Add the TTL configuration

Claude: Updating customer-portal-Service-TDD with TTL configuration...

[Updates Service-TDD]
[Adds TTL attribute to operation-status table]

✅ Updated: customer-portal-Service-TDD.md

Changes:
- DynamoDB table: customer-search-operations
  • Added TTL attribute (24h expiration)
  • TTL attribute name: expiresAt
  • Automatically set to: currentTimestamp + 86400 seconds

Async pattern now 100% compliant with Master TDD specification.
```

**Key Takeaways:**
- Explore skill searches across all TDD documents
- Compares implementation with Master TDD specification
- Identifies gaps and provides recommendations
- User can request updates to fix gaps

---

## Troubleshooting

### Issue 1: Old Slash Commands Not Working

**Problem:**
```bash
/AIDLC-design:generate Feature-TDD
# Error: Command not found
```

**Solution:**
The plugin migrated to skills in v1.4.0. Use the new skill syntax:
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD from ./requirements/feature-spec.md
```

---

### Issue 2: Skill Not Auto-Invoked

**Problem:** Saying "generate a Feature-TDD" doesn't automatically invoke the skill.

**Solution:** Use explicit skill invocation:
```bash
Skill: AIDLC-design:generate
[Your request here]
```

Auto-invocation depends on Claude Code's context understanding. Be explicit when needed.

---

### Issue 3: Plan Confirmation Required

**Problem:** Agent shows a plan but doesn't generate the document.

**Solution:** The `generate` skill requires explicit confirmation:
```
Agent: [Presents plan]
User: "Yes, proceed with the plan"
```

This is a feature, not a bug - it ensures you review the approach before generation.

---

### Issue 4: Can't Find Input Documents

**Problem:**
```
Agent: "Could not locate FSD at ./requirements/feature-spec.md"
```

**Solution:** Provide absolute or correct relative paths:
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD
FSD: C:/workspace/requirements/feature-spec.md
# Or use explore first
```

Or use explore to find documents:
```bash
Skill: AIDLC-design:explore
Find all FSD documents in the workspace
```

---

### Issue 5: Wrong Document Type Generated

**Problem:** Asked for UI-TDD but got Service-TDD.

**Solution:** Be explicit about document type:
```bash
Skill: AIDLC-design:generate
Create UI-TDD (not Service-TDD) for customer-portal
Component specifications for axis-tools
```

---

### Issue 6: Missing Critical Patterns

**Problem:** Validation reports missing protocol specifications or Lambda configuration.

**Solution:** Regenerate with explicit requirements:
```bash
Skill: AIDLC-design:generate
Regenerate customer-portal Service-TDD
Requirements:
- Protocol: REST with JSON for all external services
- Lambda config: 1024MB / 30s
- Async pattern for customer-search (>16s operation)
- 11-function Flow Engine for all services
```

---

### Issue 7: Master TDD References Missing

**Problem:** Generated documents don't include Master TDD section references.

**Solution:** Verify plugin version (v5.0.1+):
```bash
# Check plugin version
cat plugins/AIDLC-design/.claude-plugin/plugin.json | grep version

# Should show: "version": "5.0.1" or higher
```

If version is correct but references still missing, regenerate the document:
```bash
Skill: AIDLC-design:generate
Regenerate Feature-TDD with Master TDD section references
```

---

### Issue 8: Large Documents Timing Out

**Problem:** Generating design documents from large FSD (>20K tokens) times out.

**Solution:** AIDLC-design uses selective reading, but you can help by providing specific sections:
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD from ./requirements/large-fsd.md
Focus on Section 3: Customer Portal (ignore other sections)
```

---

## FAQ: Skills vs Commands

**Q: Why did AIDLC-design migrate from commands to skills?**

A: Skills provide better integration with Claude Code's natural language processing, improved auto-invocation, and
follow the agentskills.io specification standard.

---

**Q: Are old slash commands still supported?**

A: No. Slash commands (`/AIDLC-design:command`) were fully replaced by skills (`Skill: AIDLC-design:skill`) in
version 1.4.0+.

---

**Q: Can I still use command syntax?**

A: No. The `commands/` directory was removed. Use the skill syntax with natural language requests.

---

**Q: What's the difference between `Skill:` and `/command`?**

A:
- **Skills** accept natural language requests and use extended thinking for better routing
- **Commands** used rigid argument syntax (no longer supported)

---

**Q: How do I know which skill to use?**

A: Use this decision tree:

```
Need to create/update design documents?
  → Use AIDLC-design:generate

Need to check coverage/compliance?
  → Use AIDLC-design:validate

Need to find/understand existing designs?
  → Use AIDLC-design:explore

Need help using the plugin?
  → Use AIDLC-design:help
```

---

**Q: Can I chain multiple skill invocations?**

A: Yes, but invoke them sequentially:

```bash
# Step 1
Skill: AIDLC-design:generate
Generate Feature-TDD

# Wait for completion, then Step 2
Skill: AIDLC-design:validate
Validate Feature-TDD

# Wait for completion, then Step 3
Skill: AIDLC-design:explore
Show all services in Feature-TDD
```

---

**Q: Where can I find skill implementation details?**

A: Skills are located in `plugins/AIDLC-design/skills/*/SKILL.md`:
- `skills/generate/SKILL.md` - Generation logic
- `skills/validate/SKILL.md` - Validation logic
- `skills/explore/SKILL.md` - Exploration logic
- `skills/help/SKILL.md` - Help content

---

## Version & Support

**Current Version:** 5.0.1 (2025-12-10)

**Version History:**
- **5.0.1** (2025-12-10): Added Master TDD section references to all generated documents
- **1.4.1** (2026-02-06): Plugin manifest fixes, restored help and validate skills
- **1.4.0** (2026-01-XX): Migrated from slash commands to Claude Code skills
- **1.3.0** (2026-01-09): Token efficiency optimization (85-90% reduction)

**For Issues or Questions:**
1. Check this user guide and troubleshooting section
2. Review `README.md` for technical details
3. Run `Skill: AIDLC-design:help` for interactive help
4. Examine `acceptance-criteria.md` for requirements and test cases

---

**Last Updated:** February 28, 2026
