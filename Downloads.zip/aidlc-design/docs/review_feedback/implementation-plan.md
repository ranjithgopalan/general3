# AIDLC-Design Plugin - Implementation Plan

## Document Information
- **Date**: 2025-12-08
- **Source**: [review-feedback.md](review-feedback.md) + [assessment-report.md](assessment-report.md)
- **Target**: `plugins/AIDLC-design/`

---

## Executive Summary

This plan addresses **13 critical action items** identified in the design agent review, focusing on:
1. Naming convention updates (HLD→Feature-TDD, LLD→TDD)
2. Async operations pattern for >16s operations
3. SOAP vs REST protocol specifications
4. 11-function Flow Engine breakdown
5. Enhanced sequence diagrams
6. External validation service (Rules-as-a-Service)
7. Correct Lambda configurations (1024MB/30s)
8. operation-status DynamoDB table
9. Anti-pattern checks
10. Removal of embedded validation logic

**Estimated Impact**: 20+ files across agents, templates, commands, and tests

---

## Part 1: Naming Convention Updates

### Action Item #1: Update Terminology

#### Current Naming
- Feature-HLD → High-Level Design
- UI-LLD → UI Low-Level Design
- Services-LLD / API-LLD → Services Low-Level Design

#### New Naming (Aligned with Review Feedback)
- **Feature-HLD** → **Feature-TDD** (Technical Design Document)
- **UI-LLD** → **UI-TDD** (UI Technical Design Document)
- **Services-LLD** → **Service-TDD** (Service Technical Design Document)

### Files to Update

#### 1. Agent Files

**File: `agents/design-agent.md`**
- Line 3: Update description references
- Line 42-45: Update AvailableAgents table
  ```markdown
  # OLD:
  hld-designer,"Generates Feature High-Level Design from FSD"
  ui-lld-designer,"Generates UI Low-Level Design for axis-tools"
  services-lld-designer,"Generates per-service TDD for nodejs-pair-programmer"

  # NEW:
  feature-tdd-designer,"Generates Feature Technical Design Document from FSD"
  ui-tdd-designer,"Generates UI Technical Design Document for axis-tools"
  service-tdd-designer,"Generates per-service Technical Design Document for nodejs-pair-programmer"
  ```

- Line 51-56: Update AgentSelectionMatrix
  ```markdown
  # OLD:
  HLD,"FSD + Master TDD + Common Library TDD",hld-designer,"{feature}-HLD.md"
  UI-LLD,"Feature-HLD + FSD",ui-lld-designer,"{feature}-UI-LLD.md"
  Services-LLD,"Feature-HLD + FSD + Common Library TDD",services-lld-designer,"{service}-TDD.md per service"

  # NEW:
  Feature-TDD,"FSD + Master TDD + Common Library TDD",feature-tdd-designer,"{feature}-Feature-TDD.md"
  UI-TDD,"Feature-TDD + FSD",ui-tdd-designer,"{feature}-UI-TDD.md"
  Service-TDD,"Feature-TDD + FSD + Common Library TDD",service-tdd-designer,"{service}-Service-TDD.md per service"
  ```

- Line 61-66: Update IntentIndicators
- Throughout file: Replace all "HLD" → "Feature-TDD", "UI-LLD" → "UI-TDD", "Services-LLD" → "Service-TDD"

**File: `agents/hld-designer.md`**
- Rename agent: `hld-designer` → `feature-tdd-designer`
- Line 2: Update name field
- Line 3: Update description
- Throughout: Replace "Feature-HLD" → "Feature-TDD"
- Update output file naming convention

**File: `agents/services-lld-designer.md`**
- Rename agent: `services-lld-designer` → `service-tdd-designer`
- Line 2: Update name field
- Line 3: Update description
- Throughout: Replace "Services-LLD" → "Service-TDD"

**File: `agents/ui-lld-designer.md`**
- Rename agent: `ui-lld-designer` → `ui-tdd-designer`
- Line 2: Update name field
- Line 3: Update description
- Throughout: Replace "UI-LLD" → "UI-TDD"

#### 2. Template Files

**File: `reference/service-tdd-template.md`**
- Line 1: Update title to "Backend/API Feature Technical Design Document Template"
- Update all section references

#### 3. Command Files

**Update all command files:**
- `commands/explore.md`
- `commands/generate.md`
- `commands/help.md`
- `commands/validate.md`

Replace terminology throughout.

#### 4. Test Files

**Update all test files in `__tests__/`:**
- `fsd_driven_design.test`
- `services_hld_generation.test` → Rename to `services_tdd_generation.test`
- `services_lld_generation.test` → Rename to `service_tdd_generation.test`
- `services_lld_server_validation.test` → Rename to `service_tdd_server_validation.test`
- `ui_hld_generation.test` → Rename to `ui_tdd_generation.test`
- `ui_lld_cross_field_validation.test` → Rename to `ui_tdd_cross_field_validation.test`
- `ui_lld_generation.test` → Rename to `ui_tdd_generation.test`

Update expected keywords and output file names in all tests.

#### 5. Plugin Configuration

**File: `.claude-plugin/plugin.json`**
- Update agent names
- Update descriptions
- Update command descriptions

#### 6. Documentation

**File: `README.md`**
- Update all terminology references
- Update workflow examples

---

## Part 2: Critical Pattern Additions

### Action Item #3: Async Operations Pattern (>16s)

**Rationale**: Lambda timeout handling for long-running external calls (from assessment report lines 163-168, 556-557)

**Add to: `reference/service-tdd-template.md`**

**New Section: 6.2 Asynchronous Operations Pattern**

```markdown
### 6.2 Asynchronous Operations Pattern

**When to Use**: Operations expected to exceed 16 seconds (e.g., external API calls, batch processing)

#### 6.2.1 Architecture

```mermaid
sequenceDiagram
    participant Client
    participant SyncHandler
    participant AsyncHandler
    participant DynamoDB
    participant ExternalService

    Client->>SyncHandler: POST /resource/async
    SyncHandler->>DynamoDB: Write operation-status (IN_PROGRESS)
    SyncHandler->>AsyncHandler: Invoke (Event mode)
    SyncHandler-->>Client: 202 Accepted {requestId}

    AsyncHandler->>ExternalService: Long operation
    ExternalService-->>AsyncHandler: Result
    AsyncHandler->>DynamoDB: Update operation-status (COMPLETED)

    Client->>SyncHandler: GET /resource/status/{requestId}
    SyncHandler->>DynamoDB: Query operation-status
    SyncHandler-->>Client: 200 OK {status, result}
```

#### 6.2.2 API Endpoints

**Async Request Endpoint**
```yaml
Path: /api/v1/{resource}/async
Method: POST
Response: 202 Accepted
Body:
  {
    "requestId": "uuid-v4",
    "status": "IN_PROGRESS",
    "message": "Operation initiated"
  }
```

**Poll Status Endpoint**
```yaml
Path: /api/v1/{resource}/status/{requestId}
Method: GET
Response: 200 OK
Body:
  {
    "requestId": "uuid-v4",
    "status": "IN_PROGRESS | COMPLETED | FAILED",
    "progress": 75,
    "result": {} // Only when COMPLETED
  }
```

#### 6.2.3 operation-status DynamoDB Table Schema

| Attribute | Type | Key | Description | TTL |
|-----------|------|-----|-------------|-----|
| requestId | S | HASH | Unique operation ID (UUID v4) | - |
| operationType | S | - | Type of operation (e.g., "MDM_SEARCH") | - |
| status | S | - | IN_PROGRESS, COMPLETED, FAILED | - |
| progress | N | - | Percentage complete (0-100) | - |
| result | S | - | JSON string of result (when COMPLETED) | - |
| error | S | - | Error details (when FAILED) | - |
| initiatedAt | N | - | Timestamp (Unix epoch) | - |
| completedAt | N | - | Timestamp (Unix epoch) | - |
| ttl | N | - | TTL for auto-deletion | 7 days |

**GSI**: `operationType-initiatedAt-index` (for querying by type)

#### 6.2.4 Implementation Pattern

**Sync Handler (Function 6: determineAsyncPattern)**
```typescript
async function determineAsyncPattern(estimatedDuration: number): Promise<boolean> {
  // Decision logic
  if (estimatedDuration > 16) {
    return true; // Use async pattern
  }
  return false; // Use sync pattern
}

// In handler
const shouldAsync = await determineAsyncPattern(estimatedDuration);

if (shouldAsync) {
  // Async pattern
  const requestId = generateUUID();
  await writeOperationStatus({
    requestId,
    status: 'IN_PROGRESS',
    operationType: 'MDM_SEARCH'
  });

  await invokeLambdaAsync({
    FunctionName: process.env.FUNCTION_NAME,
    InvocationType: 'Event',
    Payload: JSON.stringify({ requestId, ...input })
  });

  return {
    statusCode: 202,
    body: JSON.stringify({ requestId, status: 'IN_PROGRESS' })
  };
}
```

**Async Handler**
```typescript
async function processAsync(requestId: string, input: Input) {
  try {
    // Long-running operation
    const result = await externalService.call(input);

    // Update status
    await updateOperationStatus({
      requestId,
      status: 'COMPLETED',
      result: JSON.stringify(result),
      completedAt: Date.now()
    });
  } catch (error) {
    await updateOperationStatus({
      requestId,
      status: 'FAILED',
      error: error.message,
      completedAt: Date.now()
    });
  }
}
```

**Poll Status Handler**
```typescript
async function getOperationStatus(requestId: string) {
  const status = await dynamoDB.get({
    TableName: 'operation-status',
    Key: { requestId }
  });

  return {
    statusCode: 200,
    body: JSON.stringify(status.Item)
  };
}
```

#### 6.2.5 Decision Criteria

Use async pattern when:
- External API calls with unpredictable response time
- Estimated duration > 16 seconds
- Operations involving multiple external calls
- Batch processing

Use sync pattern when:
- Internal Lambda-to-Lambda calls (same environment)
- DynamoDB operations
- Operations < 16 seconds
- Real-time user interactions required
```

---

### Action Item #4: SOAP vs REST Protocol Specification

**Rationale**: External APIs may use SOAP (not JSON/REST) - must be explicitly specified (assessment report lines 197-209, 634-643)

**Add to: `reference/service-tdd-template.md`**

**New Section: 6.3 Integration Protocol Specification**

```markdown
### 6.3 Integration Protocol Specification

#### 6.3.1 Protocol Inventory

**CRITICAL**: Do NOT assume JSON/REST for all external services. Specify protocol explicitly.

| Service | Protocol | Content-Type | Authentication | Endpoint |
|---------|----------|--------------|----------------|----------|
| [Service Name] | SOAP 1.2 / REST | text/xml / application/json | Basic Auth / OAuth | [Actual URL] |

**Example:**
| Service | Protocol | Content-Type | Authentication | Endpoint |
|---------|----------|--------------|----------------|----------|
| MDM Producer Search | SOAP 1.2 | text/xml | Basic Auth (Vault) | https://mdm-gateway-api-v1-uat.example.com/soap/producer |
| RDM Reference Data | REST | application/json | OAuth 2.0 | https://rdm-api-v2.example.com/reference |

#### 6.3.2 SOAP Integration Pattern

**When service uses SOAP:**

##### Function 8: buildSOAPRequest

```typescript
function buildSOAPRequest(operation: string, params: Record<string, any>): string {
  return `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <soap:Header>
    <AuthHeader>
      <Username>${params.username}</Username>
      <Password>${params.password}</Password>
    </AuthHeader>
  </soap:Header>
  <soap:Body>
    <${operation}>
      ${Object.entries(params.body)
        .map(([key, value]) => `<${key}>${value}</${key}>`)
        .join('\n      ')}
    </${operation}>
  </soap:Body>
</soap:Envelope>`;
}
```

##### Function 10: parseSOAPResponse

```typescript
import { XMLParser } from 'fast-xml-parser';

function parseSOAPResponse(xmlResponse: string): Record<string, any> {
  const parser = new XMLParser({
    ignoreAttributes: false,
    removeNSPrefix: true // Remove namespace prefixes
  });

  const parsed = parser.parse(xmlResponse);
  const body = parsed?.Envelope?.Body;

  // Extract data from SOAP body
  return transformXMLtoJSON(body);
}
```

##### HTTP Client Configuration

```typescript
import axios from 'axios';

const soapClient = axios.create({
  headers: {
    'Content-Type': 'text/xml; charset=utf-8',
    'SOAPAction': operation
  },
  timeout: 25000 // 25s (under 30s Lambda timeout)
});

const [error, response] = await soapClient.post(endpoint, soapEnvelope);
```

#### 6.3.3 REST Integration Pattern

**When service uses REST:**

```typescript
import axios from 'axios';

const restClient = axios.create({
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
});

const [error, response] = await restClient.get(endpoint, { params });
```

#### 6.3.4 Anti-Pattern: Protocol Hallucination

**❌ WRONG: Assuming REST/JSON without verification**
```typescript
// DON'T DO THIS - assumes REST
const response = await axios.get(mdmEndpoint, { params: { name } });
```

**✅ CORRECT: Verify protocol first, implement accordingly**
```typescript
// Verify from service inventory
if (service.protocol === 'SOAP') {
  const soapEnvelope = buildSOAPRequest('searchProducer', params);
  const response = await soapClient.post(endpoint, soapEnvelope);
  const data = parseSOAPResponse(response.data);
} else {
  const response = await restClient.get(endpoint, { params });
  const data = response.data;
}
```
```

---

### Action Item #5: 11-Function Flow Engine Breakdown

**Rationale**: Multi-step workflows must use flow engine with explicit function definitions (assessment report lines 443-461, 774-791)

**Add to: `reference/service-tdd-template.md`**

**New Section: 7.2 Flow Engine Integration (11-Function Pattern)**

```markdown
### 7.2 Flow Engine Integration (11-Function Pattern)

**When to Use**: Services with multi-step workflows requiring configurable execution order

#### 7.2.1 Function Breakdown

All services using Flow Engine must define **11 standard functions**:

| Function # | Name | Purpose | Returns |
|------------|------|---------|---------|
| 1 | extractBearerToken | Extract JWT from Authorization header | [error, token] |
| 2 | validateToken | Validate JWT using @project-name/common/auth | [error, claims] |
| 3 | checkUserPermissions | Verify user entitlements (AppId check) | [error, permissions] |
| 4 | validateRequest | Validate input parameters (schema + business rules) | [error, validatedInput] |
| 5 | loadConfiguration | Load service configuration from DynamoDB | [error, config] |
| 6 | determineAsyncPattern | Decide sync vs async based on estimated duration | [error, shouldAsync] |
| 7 | retrieveCredentials | Get external service credentials from Vault | [error, credentials] |
| 8 | buildRequest | Build request (SOAP XML or REST JSON) | [error, request] |
| 9 | invokeExternalService | Call external service (MDM, RDM, etc.) | [error, response] |
| 10 | parseAndTransformResponse | Parse response (XML→JSON or JSON transform) | [error, transformedData] |
| 11 | formatSuccessResponse | Format final API response | [error, response] |

#### 7.2.2 Flow Engine Configuration

**DynamoDB Table: service-function-flows**

```typescript
{
  "serviceId": "integration-proxy-producer",
  "version": "1.0",
  "functions": [
    {
      "order": 1,
      "name": "extractBearerToken",
      "module": "@project-name/common/auth",
      "required": true,
      "errorBehavior": "stop"
    },
    {
      "order": 2,
      "name": "validateToken",
      "module": "@project-name/common/auth",
      "required": true,
      "errorBehavior": "stop"
    },
    // ... functions 3-11
  ]
}
```

#### 7.2.3 Implementation Pattern

```typescript
import { FlowEngine } from '@project-name/common/flow-engine';

export const handler = async (event: APIGatewayEvent) => {
  // Load flow configuration
  const [error, flowConfig] = await loadFlowConfig('integration-proxy-producer');
  if (error) return errorResponse(error);

  // Initialize flow engine
  const engine = new FlowEngine(flowConfig);

  // Execute all functions in order
  const [flowError, result] = await engine.execute({
    event,
    context: {}
  });

  if (flowError) {
    return errorResponse(flowError);
  }

  return successResponse(result);
};
```

#### 7.2.4 Function Implementations

**Function 6: determineAsyncPattern (CRITICAL)**
```typescript
async function determineAsyncPattern(context: FlowContext): Promise<[Error | null, boolean]> {
  const estimatedDuration = estimateOperationDuration(context.operation);

  if (estimatedDuration > 16) {
    return [null, true]; // Use async pattern
  }

  return [null, false]; // Use sync pattern
}
```

**Function 8: buildRequest (SOAP vs REST)**
```typescript
async function buildRequest(context: FlowContext): Promise<[Error | null, string | object]> {
  const { protocol, operation, params } = context;

  if (protocol === 'SOAP') {
    // Build SOAP XML envelope
    const soapEnvelope = buildSOAPEnvelope(operation, params);
    return [null, soapEnvelope];
  } else {
    // Build REST JSON
    return [null, params];
  }
}
```

**Function 10: parseAndTransformResponse (XML → JSON)**
```typescript
async function parseAndTransformResponse(context: FlowContext): Promise<[Error | null, any]> {
  const { protocol, response } = context;

  if (protocol === 'SOAP') {
    // Parse XML to JSON
    const [error, data] = parseSOAPResponse(response);
    if (error) return [error, null];
    return [null, data];
  } else {
    // Already JSON
    return [null, response.data];
  }
}
```

#### 7.2.5 Sequence Diagram with 11 Functions

```mermaid
sequenceDiagram
    participant Client
    participant FlowEngine
    participant Function1-11
    participant ExternalService
    participant Database

    Client->>FlowEngine: API Request
    FlowEngine->>Function1: extractBearerToken
    Function1-->>FlowEngine: [null, token]
    FlowEngine->>Function2: validateToken
    Function2-->>FlowEngine: [null, claims]
    FlowEngine->>Function3: checkUserPermissions
    Function3-->>FlowEngine: [null, permissions]
    FlowEngine->>Function4: validateRequest
    Function4-->>FlowEngine: [null, validatedInput]
    FlowEngine->>Function5: loadConfiguration
    Function5->>Database: Query config
    Database-->>Function5: Config data
    Function5-->>FlowEngine: [null, config]
    FlowEngine->>Function6: determineAsyncPattern
    Function6-->>FlowEngine: [null, false]
    FlowEngine->>Function7: retrieveCredentials
    Function7-->>FlowEngine: [null, credentials]
    FlowEngine->>Function8: buildRequest
    Function8-->>FlowEngine: [null, soapEnvelope]
    FlowEngine->>Function9: invokeExternalService
    Function9->>ExternalService: SOAP Request
    ExternalService-->>Function9: XML Response
    Function9-->>FlowEngine: [null, response]
    FlowEngine->>Function10: parseAndTransformResponse
    Function10-->>FlowEngine: [null, jsonData]
    FlowEngine->>Function11: formatSuccessResponse
    Function11-->>FlowEngine: [null, response]
    FlowEngine-->>Client: 200 OK
```
```

---

### Action Item #7: External Validation Service (Rules-as-a-Service)

**Rationale**: Validation logic must be externalized to OPA-based rules service (review feedback lines 26-29, action #2 & #11)

**Add to: `reference/service-tdd-template.md`**

**New Section: 9.3 Rules-as-a-Service Integration**

```markdown
### 9.3 Rules-as-a-Service Integration

**CRITICAL**: Validation rules are externalized to an OPA (Open Policy Agent) based rules engine. Do NOT embed validation logic in Lambda code.

#### 9.3.1 Architecture

```mermaid
graph LR
    Lambda[Lambda Service] -->|POST /validate| RulesService[Rules-as-a-Service]
    RulesService -->|Query .rego files| OPA[OPA Engine]
    OPA -->|Return| RulesService
    RulesService -->|Validation Result| Lambda
```

#### 9.3.2 API Endpoint (Mock Specification)

**Rules Validation Endpoint**
```yaml
URL: https://rules-api.example.com/v1/validate
Method: POST
Headers:
  - Content-Type: application/json
  - Authorization: Bearer {token}
  - X-Correlation-Id: {uuid}

Request Body:
{
  "ruleSet": "producer-validation",
  "version": "1.0",
  "data": {
    "producerNumber": "000123456",
    "producerName": "John Doe",
    "policyInceptionDate": "2024-01-15",
    "commissionPercent": 15.5
  }
}

Response (Success - 200):
{
  "valid": true,
  "ruleSet": "producer-validation",
  "version": "1.0",
  "evaluatedAt": "2024-01-15T10:30:00Z",
  "violations": []
}

Response (Validation Failed - 200):
{
  "valid": false,
  "ruleSet": "producer-validation",
  "version": "1.0",
  "evaluatedAt": "2024-01-15T10:30:00Z",
  "violations": [
    {
      "rule": "PRD_R002",
      "field": "producerExpirationDate",
      "message": "Producer license expired",
      "severity": "error"
    }
  ]
}

Response (Error - 4xx/5xx):
{
  "error": {
    "code": "RULES_ENGINE_ERROR",
    "message": "Failed to evaluate rules",
    "correlationId": "uuid"
  }
}
```

#### 9.3.3 Integration Pattern

```typescript
import axios from 'axios';

interface ValidationRequest {
  ruleSet: string;
  version: string;
  data: Record<string, any>;
}

interface ValidationResult {
  valid: boolean;
  violations: Array<{
    rule: string;
    field: string;
    message: string;
    severity: 'error' | 'warning';
  }>;
}

async function validateWithRulesService(
  ruleSet: string,
  data: Record<string, any>
): Promise<[Error | null, ValidationResult | null]> {
  try {
    const response = await axios.post(
      process.env.RULES_SERVICE_URL,
      {
        ruleSet,
        version: '1.0',
        data
      },
      {
        headers: {
          'Authorization': `Bearer ${await getToken()}`,
          'X-Correlation-Id': getCorrelationId()
        },
        timeout: 5000 // 5s timeout
      }
    );

    return [null, response.data];
  } catch (error) {
    return [error, null];
  }
}
```

#### 9.3.4 Usage in Service

```typescript
// In processor layer
export async function processProducerData(input: ProducerInput): Promise<[Error | null, any]> {
  // Step 1: Basic schema validation (local)
  const [schemaError] = validateSchema(input);
  if (schemaError) return [schemaError, null];

  // Step 2: Business rule validation (external)
  const [rulesError, validationResult] = await validateWithRulesService(
    'producer-validation',
    input
  );

  if (rulesError) {
    return [new Error('Rules service unavailable'), null];
  }

  if (!validationResult.valid) {
    return [new ValidationError(validationResult.violations), null];
  }

  // Step 3: Continue processing
  // ...
}
```

#### 9.3.5 Rule Repository Ownership

**Team Ownership**:
- **Service team**: Owns `.rego` rule files in Git repository
- **Rules-as-a-Service team**: Deploys and operates OPA infrastructure
- **Handoff process**: Service team commits .rego files → Rules team deploys to OPA

**Example .rego file structure**:
```
rules/
  ├── producer-validation/
  │   ├── producer-rules.rego
  │   ├── commission-rules.rego
  │   └── expiration-rules.rego
```

#### 9.3.6 Anti-Pattern: Embedded Validation

**❌ WRONG: Embedding validation logic in Lambda**
```typescript
// DON'T DO THIS
function validateProducer(data: ProducerData): boolean {
  if (data.commissionPercent > 100) return false;
  if (isExpired(data.expirationDate)) return false;
  // ... more hardcoded rules
}
```

**✅ CORRECT: Calling external rules service**
```typescript
// DO THIS
const [error, result] = await validateWithRulesService('producer-validation', data);
if (!result.valid) {
  return [new ValidationError(result.violations), null];
}
```
```

---

### Action Item #8: Lambda Configuration Update

**Rationale**: SOAP processing and async operations require more resources (assessment report line 569, 1367-1370)

**Update in: `reference/service-tdd-template.md` + all agent files**

**Changes:**

```markdown
### 1.3 Runtime Specifications

| Attribute | Value | Rationale |
|-----------|-------|-----------|
| Runtime | Node.js 20.x | Latest LTS |
| Memory | 1024 MB | SOAP XML parsing + async operations |
| Timeout | 30 seconds | Async pattern decision window |
| Trigger | API Gateway / SQS / EventBridge | - |

**OLD VALUES** (Remove):
- Memory: 512 MB ❌
- Timeout: 16 seconds ❌

**NEW VALUES**:
- Memory: 1024 MB ✅
- Timeout: 30 seconds ✅
```

**Update in agents:**
- `agents/hld-designer.md` line 211
- `agents/services-lld-designer.md` line 211
- `reference/service-tdd-template.md` line 73

---

### Action Item #9: Enhanced Sequence Diagrams

**Rationale**: Diagrams must show 11-function flow, SOAP calls, and async branching (assessment report lines 179-193, 556-560)

**Update in: `reference/service-tdd-template.md`**

**Section 5.2: Sequence Diagrams**

**Add Requirements:**

```markdown
### 5.2 Sequence Diagrams

**REQUIREMENTS**: All sequence diagrams must include:
1. ✅ All 11 Flow Engine functions (for flow-based services)
2. ✅ Protocol indication (SOAP vs REST)
3. ✅ Async decision branching (Function 6)
4. ✅ Error paths
5. ✅ Correlation ID propagation

**Minimum Diagrams:**
- **Sync Flow (Happy Path)**: Complete flow including all 11 functions
- **Async Flow**: Background processing with polling
- **Error Flow**: Validation failures and external service errors

See Section 7.2.5 for 11-function sequence diagram example.
```

---

### Action Item #10: Anti-Pattern Checks

**Rationale**: Generated designs must be scanned against Master TDD anti-patterns (review feedback lines 59-61)

**Add to: `reference/service-tdd-template.md`**

**New Section: 14. Anti-Pattern Validation**

```markdown
## 14. Anti-Pattern Validation

Before finalizing this TDD, verify it does NOT contain these anti-patterns from Master TDD:

### 14.1 Anti-Pattern Checklist

| Anti-Pattern | Check | Status |
|--------------|-------|--------|
| **AP-001**: Embedded validation logic (not using Rules-as-a-Service) | Review Section 9 | ☐ Pass |
| **AP-002**: Synchronous calls for >16s operations | Review Section 6.2 | ☐ Pass |
| **AP-003**: Assuming REST/JSON without protocol verification | Review Section 6.3 | ☐ Pass |
| **AP-004**: Hardcoded endpoint URLs (not from config/Vault) | Review Section 7 | ☐ Pass |
| **AP-005**: Missing 11-function Flow Engine breakdown | Review Section 7.2 | ☐ Pass |
| **AP-006**: Try-catch error handling (should use go-style) | Review Section 8 | ☐ Pass |
| **AP-007**: Insufficient Lambda resources (< 1024MB / < 30s) | Review Section 1.3 | ☐ Pass |
| **AP-008**: Missing operation-status table for async ops | Review Section 6.2.3 | ☐ Pass |
| **AP-009**: Generating relational database schemas | Review Section 6 | ☐ Pass |
| **AP-010**: Missing SOAP parsing for XML responses | Review Section 6.3 | ☐ Pass |

### 14.2 Validation Process

1. **Self-Review**: Designer agent checks against anti-patterns before generation
2. **Human Review**: Architect verifies anti-pattern compliance
3. **Automated Scan**: CI/CD pipeline checks for anti-pattern keywords

### 14.3 Anti-Pattern References

Refer to Master TDD Section X for complete anti-pattern catalog.
```

---

## Part 3: Agent Instruction Updates

### Update: `agents/services-lld-designer.md`

**Add Extended Thinking Instructions**:

```markdown
[Extended thinking: Before generating Service-TDD, I verify:
1. Protocol specification (SOAP vs REST) from service inventory - NO ASSUMPTIONS
2. Estimated operation duration to determine async pattern (>16s = async)
3. 11-function Flow Engine breakdown if multi-step workflow required
4. Rules-as-a-Service integration for validation (NO embedded rules)
5. Lambda config: 1024MB / 30s timeout
6. operation-status table if async operations present
7. Sequence diagrams include all 11 functions + protocol + async branching
8. Anti-pattern scan before finalizing
I never hallucinate endpoints, assume protocols, or embed validation logic.]
```

**Add to Guardrails**:

```markdown
OPERATIONAL_CONSTRAINTS[Type,Rules]:
  ALWAYS,"verify protocol from service inventory | check duration for async pattern | use 11-function breakdown | integrate Rules-as-a-Service | include operation-status table | set 1024MB/30s Lambda config"
  NEVER,"assume REST/JSON | embed validation rules | use 512MB/16s config | skip async for >16s operations"
  STOP_AND_ASK,"protocol unclear | no service inventory | validation rule ownership ambiguous"
```

### Update: `agents/hld-designer.md`

**Add to Quality Principles**:

```markdown
QualityPrinciples[Principle,Implementation]:
  ProtocolExplicit,"All external services specify SOAP or REST protocol"
  AsyncAware,"Services with >16s operations include async pattern"
  FlowEngineReady,"Multi-step workflows define 11-function breakdown"
  ValidationExternal,"No embedded validation - reference Rules-as-a-Service"
  ResourceCorrect,"Lambda: 1024MB / 30s timeout (not 512MB / 16s)"
```

---

## Part 4: Testing Updates

### Update All Test Files

**Pattern: Update Expected Keywords**

**Example: `__tests__/services_lld_generation.test`**

```markdown
--- EXPECTED KEYWORDS ---
# OLD:
Services-LLD, Lambda TDD, handler.ts, processor.ts, 512MB, 16 seconds

# NEW:
Service-TDD, Lambda TDD, handler.ts, processor.ts, 1024MB, 30 seconds, async pattern, SOAP, 11-function flow, Rules-as-a-Service, operation-status
```

**Add New Test: `__tests__/async_operations_pattern.test`**

```markdown
=== TEST: Async Operations Pattern ===
DESCRIPTION: Verify Service-TDD includes async pattern for >16s operations

--- ACCEPTANCE CRITERIA ---
- Service-TDD includes async endpoint (POST /resource/async)
- Service-TDD includes poll endpoint (GET /resource/status/{requestId})
- Service-TDD includes operation-status DynamoDB table schema
- Service-TDD includes Function 6: determineAsyncPattern
- Service-TDD includes async sequence diagram

--- PROMPT ---
Generate Service-TDD for MDM Integration Proxy that calls external SOAP API with estimated response time of 20 seconds.

--- EXPECTED KEYWORDS ---
POST /resource/async, 202 Accepted, requestId, operation-status, DynamoDB, determineAsyncPattern, IN_PROGRESS, COMPLETED, async sequence diagram

--- END TEST ---
```

**Add New Test: `__tests__/soap_protocol_specification.test`**

```markdown
=== TEST: SOAP Protocol Specification ===
DESCRIPTION: Verify Service-TDD specifies SOAP protocol for external services

--- ACCEPTANCE CRITERIA ---
- Service-TDD includes protocol inventory table
- SOAP services specify: SOAP 1.2, text/xml, endpoint URL
- Service-TDD includes Function 8: buildSOAPRequest
- Service-TDD includes Function 10: parseSOAPResponse
- Service-TDD uses fast-xml-parser for XML parsing

--- PROMPT ---
Generate Service-TDD for Producer Search service integrating with MDM SOAP API.

--- EXPECTED KEYWORDS ---
Protocol inventory, SOAP 1.2, text/xml, buildSOAPRequest, parseSOAPResponse, fast-xml-parser, XMLParser, soap:Envelope

--- END TEST ---
```

**Add New Test: `__tests__/11_function_flow_engine.test`**

```markdown
=== TEST: 11-Function Flow Engine Breakdown ===
DESCRIPTION: Verify Service-TDD includes complete 11-function Flow Engine breakdown

--- ACCEPTANCE CRITERIA ---
- Service-TDD lists all 11 functions in order
- Function 6: determineAsyncPattern defined
- Function 8: buildRequest (SOAP or REST) defined
- Function 10: parseAndTransformResponse defined
- service-function-flows DynamoDB table schema included

--- PROMPT ---
Generate Service-TDD for Integration Proxy using Flow Engine pattern.

--- EXPECTED KEYWORDS ---
extractBearerToken, validateToken, checkUserPermissions, validateRequest, loadConfiguration, determineAsyncPattern, retrieveCredentials, buildRequest, invokeExternalService, parseAndTransformResponse, formatSuccessResponse, service-function-flows

--- END TEST ---
```

---

## Part 5: Implementation Priority

### Phase 1: Critical Fixes (Implement First)
1. ✅ Lambda configuration update (1024MB/30s)
2. ✅ Async operations pattern (>16s)
3. ✅ SOAP vs REST protocol specification
4. ✅ 11-function Flow Engine breakdown
5. ✅ Rules-as-a-Service integration

### Phase 2: Quality Improvements
6. ✅ Enhanced sequence diagrams
7. ✅ operation-status table schema
8. ✅ Anti-pattern checks
9. ✅ Agent instruction updates

### Phase 3: Consistency Updates
10. ✅ Naming convention updates (all files)
11. ✅ Test file updates
12. ✅ Documentation updates

---

## Part 6: File Change Summary

### Files Requiring Major Changes (Critical Patterns)

1. **`reference/service-tdd-template.md`** - Add 5 new sections (~500 lines)
   - Section 6.2: Async Operations Pattern
   - Section 6.3: SOAP vs REST Protocol Specification
   - Section 7.2: 11-Function Flow Engine Breakdown
   - Section 9.3: Rules-as-a-Service Integration
   - Section 14: Anti-Pattern Validation

2. **`agents/services-lld-designer.md`** - Update instructions
   - Extended thinking with protocol/async checks
   - Guardrails for anti-patterns
   - Lambda config 1024MB/30s

3. **`agents/hld-designer.md`** - Update instructions
   - Quality principles for protocol/async
   - Lambda config 1024MB/30s

### Files Requiring Naming Updates (Terminology)

4. **`agents/design-agent.md`** - Terminology updates (~30 occurrences)
5. **`agents/hld-designer.md`** - Rename agent, update references
6. **`agents/ui-lld-designer.md`** - Rename agent, update references
7. **`agents/services-lld-designer.md`** - Rename agent, update references
8. **`commands/*.md`** (4 files) - Update terminology
9. **`__tests__/*.test`** (10 files) - Rename files, update keywords
10. **`.claude-plugin/plugin.json`** - Update agent names
11. **`README.md`** - Update documentation

### New Files to Create

12. **`__tests__/async_operations_pattern.test`**
13. **`__tests__/soap_protocol_specification.test`**
14. **`__tests__/11_function_flow_engine.test`**
15. **`__tests__/rules_as_a_service_integration.test`**

---

## Part 7: Validation Checklist

After implementation, verify:

### Critical Patterns
- [ ] Async pattern documented with 3 endpoints + operation-status table
- [ ] SOAP protocol specification with Function 8 & 10
- [ ] 11-function Flow Engine breakdown complete
- [ ] Rules-as-a-Service integration with mock endpoint spec
- [ ] Lambda config updated to 1024MB / 30s everywhere
- [ ] operation-status DynamoDB table schema defined
- [ ] Anti-pattern checklist added to templates
- [ ] Enhanced sequence diagrams (11 functions + protocol + async)

### Naming Consistency
- [ ] All "HLD" → "Feature-TDD"
- [ ] All "UI-LLD" → "UI-TDD"
- [ ] All "Services-LLD" → "Service-TDD"
- [ ] Agent names updated in plugin.json
- [ ] Test files renamed and updated

### Agent Instructions
- [ ] services-lld-designer has protocol verification guardrail
- [ ] services-lld-designer has async duration check
- [ ] services-lld-designer has 11-function requirement
- [ ] services-lld-designer references Rules-as-a-Service
- [ ] hld-designer has protocol/async principles

### Testing
- [ ] All existing tests pass with new terminology
- [ ] 4 new tests added for critical patterns
- [ ] Expected keywords updated in all tests

---

## Part 8: Risk Mitigation

### Risks Identified from Assessment Report

| Risk | Mitigation in This Plan | Status |
|------|-------------------------|--------|
| **Endpoint Hallucination** (95% in assessment) | Protocol inventory table + explicit SOAP/REST specification | ✅ Addressed |
| **Async Pattern Missing** (90% risk) | Async pattern section + Function 6 + operation-status table | ✅ Addressed |
| **Function Flow Hallucination** (70% risk) | 11-function breakdown mandatory + service-function-flows table | ✅ Addressed |
| **Schema Ownership Conflict** | Clarified: Agent doesn't generate relational schemas (AP-009) | ✅ Addressed |
| **Embedded Validation** | Rules-as-a-Service integration + anti-pattern check | ✅ Addressed |

### Success Criteria

After implementation, assessment score should improve:

| Metric | Current (Assessment Report) | Target After Fix |
|--------|----------------------------|------------------|
| **Architecture & Diagrams** | 50/100 | 90/100 |
| **API & Integration Specs** | 60/100 | 95/100 |
| **Business Logic Design** | 66/100 | 95/100 |
| **Ambiguity (inverse risk)** | 40/100 (60% risk) | 90/100 (10% risk) |
| **Overall Score** | 71.3/100 (B) | 92/100 (A) |

---

## End of Implementation Plan

**Next Steps:**
1. Review this plan with team
2. Prioritize Phase 1 (Critical Fixes)
3. Implement changes file by file
4. Run test suite after each phase
5. Update assessment report with new scores

**Estimated Effort:** 2-3 days for complete implementation

**Point of Contact:** Design Agent Team
