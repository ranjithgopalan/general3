Design Agent review feedback outlined the action items, key decisions, and risks identified.

Action Items: 
#1 Update the naming conventions to Feature TDD
Feature HLD should Feature TDD
UI-LLD should be renamed to UI-TDD
API-LLD should be renamed to Service-TDD

#2 Remove from Design agent the Complete Validation TDD - this has to be externalized to a different API
#3 Obtain the API Specs/Mocks to call the external API / rules
#4 Need to have SOAP vs REST Endpoint Inventory
Provide list of external APIs that return SOAP vs JSON
#5 Update the Master TDD: add the async patterns, rules service calls, and correct diagrams into the master TDD
a) Link Manual TDDs
b) Add Dropdown Pattern: Document the reference-data dropdown call pattern and put it into the TDD
#6 Train the Agent: Tech the agent to follow the new rules: use the external validator, handle async jobs, and don't guess endpoints
#7 Async Operations - HTTP call should be handled Asynchrony when possible
#8 Eleven-function flow - should use the flow engine for multi-step workflows
#9 Design agent should create sequence diagrams
#10 Background tasks should be pulled for status updates
#11 Provide validation Rules-as-a-service API
Provide mock endpoint spec (URL pattern, request/response JSON, error format for the external validation service
#12 Get Scoring Rubric - obtain to see how the TDD is scored - so we can know what to improve - Ibrahim/Emanual

Key Decisions:
#1 Rules as a Service (OPA):
Validation logic will live in an external rules as a service endpoint using OPA (repo files)
The agent generate code must call this external validation API, not embed or implement rules internally.
The team owns the repo file generation and hands it to the rules-as-a-service team.

#2 Async vs sync behavior:
Lambda endpoints must return a response to the caller as soon as possible
Long-running work is handled asynchronously:
Job entry written to DynamoDB w/ job id and status.
Async processes the job and writes results
A polling API reads DynamoDB and returns the final results to the UI
Internal calls within the same "In-Score" / internal Lambda Env can stay synchronous.
External call must use the async pattern when response time is unpredictable

#3 SOAP vs REST:
Some external APIs are SOAP only
Agent design must not assume JSON/REST by default
Each interface must be tagged as SOAP or REST, and the agent must generate the correct protocol

#4 Flow Engine Usage:
Execution order is driven by a flow engine - config stored in DynamoDB.
Agent must generate function that follow this flow configuration and not hard code its own sequence

#5 Schema Ownership
Agent must not generate schemas for relational databases
Data Architecture owns relational schemas- Design Agent (AI) should expect an existing schema and integration with it.
DynamoDB team can define and evolve schemas themselves

#6 TDD Structure
One Single Master TDD as the top level "Source of Truth" (Patterns, anti-patterns, diagrams)
Agent must update the Master TDD where integrations or diagrams change and must not create new master files per feature

#7 Anit- Patterns checks
Master TDD contains defined anti-patterns
Agent output should be scanned against these anti-patterns and flag against any violations.

Risks:
#1 Endpoint Hallucination: Agent might still invent endpoints if it's not trained properly
#2 Schema Ownership - if the agent tries to generate relational database schemas on its own
#3 Async Pattern Consistency: Async handling might not be applied uniformly, especially for external calls - could lead to timeouts