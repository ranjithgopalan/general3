# Design Agent

Expert Design Agent specializing in creating implementation-ready technical design documents (TDD) for UI components and Lambda services.

## Overview

The AIDLC-design plugin bridges the gap between high-level business requirements and code implementation. It transforms Features (from product-owner) and User Stories (from scrum-master) into detailed technical design documents that serve as blueprints for code generation by axis-tools and nodejs-pair-programmer.

**Key terminology change**: HLD → Feature-TDD, UI-LLD → UI-TDD, Services-LLD → Service-TDD

## Plugin Structure

```
AIDLC-design/
├── .claude-plugin/
│   └── plugin.json                      # Plugin configuration
├── skills/                               # Executable skills
│   ├── generate/SKILL.md                # Generate Feature-TDD, UI-TDD, or Service-TDD
│   ├── validate/SKILL.md                # Validate coverage and critical patterns
│   ├── explore/SKILL.md                 # Explore existing design documents
│   └── help/SKILL.md                    # Plugin help documentation
├── agents/                               # Specialized agents
│   ├── design-agent.md                  # Router agent for design tasks
│   ├── feature-tdd-designer.md          # Feature-TDD generator (architecture)
│   ├── ui-tdd-designer.md               # UI-TDD generator (component specs)
│   ├── service-tdd-designer.md          # Service-TDD generator (Lambda specs)
│   └── design-guidelines.md             # Reference patterns and guidelines
├── reference/                            # Reference materials and templates
│   ├── service-tdd-template.md          # Service-TDD template (v2.1)
│   ├── ui-tdd-template.md               # UI-TDD template
│   ├── 1.Master TDD.zip                 # Architecture strategy reference
│   ├── 2. Common Library.zip            # Shared library specs
│   └── 3. DynamoDB.zip                  # DynamoDB patterns
├── __tests__/                            # Evaluation tests
│   ├── feature_tdd_generation.test      # Feature-TDD generation test
│   ├── ui_tdd_generation.test           # UI-TDD generation test
│   ├── service_tdd_generation.test      # Service-TDD generation test
│   ├── validate_coverage.test           # Coverage validation test
│   ├── ui_tdd_cross_field_validation.test      # HLR-1: Cross-field validation
│   ├── service_tdd_server_validation.test      # HLR-2: Server-side validation
│   ├── complete_data_flow.test                  # HLR-3: Data flow documentation
│   ├── pom_subsection_focus.test                # HLR-4: POM subsection focus
│   ├── fsd_driven_design.test                   # HLR-5: FSD-driven design
│   ├── reference_data_dropdown_pattern.test     # HLR-6: Dropdown pattern
│   ├── sequence_diagram_completeness.test       # HLR-7: Sequence diagrams
│   └── endpoint_verification.test               # HLR-8: Endpoint verification
├── acceptance-criteria.md                # Plugin acceptance criteria (8 HLRs)
└── README.md
```

## Role in SDLC Workflow

```
Business Analyst → Product Owner → Scrum Master → Design Agent → Pair Programmers
    (EPIC/BRD)      (Feature/PRD)   (User Stories)   (TDD Specs)   (Code Implementation)
```

**Input**: Feature Specification Documents (FSD), Master TDD, Common Library TDD
**Output**: Feature-TDD.md, UI-TDD.md, Service-TDD.md (consolidated - all Lambda services)

## When to Use

Use this plugin when you need to:
- Create Feature-TDD (high-level architecture combining UI and Services)
- Create UI-TDD (detailed component specifications for axis-tools)
- Create Service-TDD (consolidated specifications for all Lambda services for nodejs-pair-programmer)
- Transform high-level architecture into implementation-ready specs with critical patterns:
  - Protocol specification (SOAP vs REST) - NO assumptions, actual endpoint URLs verified
  - Async operations pattern for >16s operations with polling (operation-status table)
  - Lambda configuration: 1024MB / 30s timeout
  - 11-function Flow Engine breakdown for multi-step workflows
  - Rules-as-a-Service integration for business validation (external validator)
  - Reference-Data Dropdown Pattern for RDM integration with caching
  - Sequence diagrams for ALL services showing complete flow
- Define component specifications optimized for LLM code generation
- Map Policy Object Model (POM) fields to UI requirements (instruction-driven)

## User Guide

### Migration from Commands to Skills

**AIDLC-design has migrated from slash commands to Claude Code skills.** This migration provides better integration with Claude Code's skill invocation system and improved auto-invocation capabilities.

#### What Changed

**Before (Commands):**
```bash
# Old slash command syntax (NO LONGER SUPPORTED)
/AIDLC-design:generate Feature-TDD from customer-portal FSD
/AIDLC-design:validate Feature-TDD against FSD
/AIDLC-design:explore What services are in customer-portal?
```

**After (Skills):**
```bash
# New skill invocation syntax (CURRENT)
Skill: AIDLC-design:generate
Generate Feature-TDD from the customer-portal FSD

Skill: AIDLC-design:validate
Validate Feature-TDD against FSD

Skill: AIDLC-design:explore
What services are in customer-portal Feature-TDD?
```

#### Key Differences

| Aspect | Commands (Old) | Skills (New) |
|--------|----------------|--------------|
| **Invocation** | `/AIDLC-design:command args` | `Skill: AIDLC-design:skill` + request |
| **Syntax** | Slash command prefix | Skill tool invocation |
| **Arguments** | Inline with command | Natural language in request |
| **Auto-invoke** | Limited | Enhanced detection |
| **Structure** | `commands/*.md` | `skills/*/SKILL.md` |
| **Metadata** | YAML frontmatter | YAML frontmatter + extended thinking |

#### Migration Benefits

- **Natural Language Requests**: Skills accept conversational requests instead of rigid command syntax
- **Better Context Understanding**: Skills include extended thinking for improved routing
- **Auto-Invocation**: Claude Code can automatically invoke skills based on user intent
- **Standardized Structure**: Follows agentskills.io specification format
- **Improved Discovery**: Skills are easier to discover and document

### Quick Start

Invoke skills using natural language requests:

```bash
# Generate Feature-TDD
Skill: AIDLC-design:generate
Generate Feature-TDD from the customer-portal FSD located at ./requirements/customer-portal-fsd.md

# Generate UI-TDD
Skill: AIDLC-design:generate
Create UI-TDD for the customer-portal feature

# Generate Service-TDD
Skill: AIDLC-design:generate
Generate Service-TDD for the customer-search Lambda service

# Validate design documents
Skill: AIDLC-design:validate
Validate the customer-portal Feature-TDD against the FSD

# Explore existing designs
Skill: AIDLC-design:explore
What services are defined in the customer-portal Feature-TDD?
```

## Version

**Current Version**: 5.0.1 (2025-12-10)

See [CHANGELOG.md](./CHANGELOG.md) for version history and updates.

## Key Features

### Master TDD References (New in v5.0.1)
All generated TDD documents now include **Master TDD section references** following the standardized pattern:
- Document headers reference the relevant Master TDD section
- Major sections include reference callouts (e.g., `> **Master TDD Reference**: Section 20.4 - Architectural Layers`)
- Ensures traceability to architecture strategy and design patterns
- Format: `> **Master TDD Reference**: Section X.Y - Description`

**Example:**
```markdown
> **Master TDD Reference**: Section 20 - Lambda Code Generation Template
> **Service Type**: Consolidated Service Technical Design Document

## 2. Technical Architecture

> **Master TDD Reference**: Section 20.4 - Architectural Layers and Responsibilities
```

### Critical Pattern Enforcement (Enhanced in v2.1)
- **Endpoint Verification**: All external services must have actual endpoint URLs - NEVER guess or use placeholders
- **Protocol Specification**: All external services must specify SOAP or REST - no assumptions
- **Async Operations Pattern**: Operations >16s require 3-endpoint async pattern with operation-status DynamoDB table and polling
- **Lambda Configuration**: All Lambdas: 1024MB memory / 30s timeout (not 512MB/16s)
- **11-Function Flow Engine**: Multi-step workflows broken down into standardized functions
- **Rules-as-a-Service**: Business validation via external OPA service (no embedded rules) - external validator
- **Reference-Data Dropdown Pattern**: RDM integration with caching strategy (24h TTL)
- **Sequence Diagrams**: Required for ALL services showing 11 functions + protocol + async branching
- **Manual TDD Linking**: References to Master TDD and Common Library TDD
- **Anti-Pattern Validation**: 10-point checklist to prevent common design flaws

### Three Design Document Types
1. **Feature-TDD**: Combined UI + Services architecture (high-level)
2. **UI-TDD**: Angular component specifications with Axis framework (for axis-tools)
3. **Service-TDD**: Consolidated specifications for all Lambda services with critical patterns (for nodejs-pair-programmer)

### Comprehensive Specifications Include
- Component inputs, outputs, methods, lifecycle hooks
- State management patterns (Angular Signals) and data models
- Protocol specification (SOAP XML or REST JSON) for all external services
- Lambda trigger types (SQS, Kinesis, API Gateway) and event structures
- Async pattern (POST /async, GET /status, background processor) for >16s operations
- 11-function Flow Engine breakdown for multi-step workflows
- Data validation rules via Rules-as-a-Service (no embedded logic)
- Go-style error handling ([error, result] pattern)
- Enhanced sequence diagrams showing all functions + protocol + async branching
- Lambda configuration: 1024MB / 30s timeout
- operation-status DynamoDB table for async operations
- Testing requirements and acceptance criteria
- Accessibility and security considerations

### Optimized for Code Generation
- Detailed enough for LLM pair programmers to generate production code
- Follows Angular 18 and Node.js best practices
- Integrated with Axis framework conventions (axis-tools)
- Aligned with Lambda patterns (nodejs-pair-programmer)

## Templates Used

Reference templates in `reference/` folder:
- `service-tdd-template.md` - Service-TDD template with critical patterns (v2.1 - includes Dropdown Pattern & Manual TDD links)
- `ui-tdd-template.md` - UI-TDD template for component specifications

All design documents stored in `.claude_kb/workspaces/EPIC-XXX/technical/design/`

## Generated Documentation

**Output files:**
- `{feature-name}-Feature-TDD.md` - Combined UI + Services architecture
- `{feature-name}-UI-TDD.md` - UI component specifications (for axis-tools)
- `{feature-name}-Service-TDD.md` - Consolidated specifications for all Lambda services (for nodejs-pair-programmer)

## Available Skills

AIDLC-design provides four skills for design document generation, validation, exploration, and help:

### 1. `AIDLC-design:generate`

**Purpose:** Generate Feature-TDD, UI-TDD, or Service-TDD design documents from requirements.

**When to Use:**
- Creating Feature-TDD (architecture combining UI + Services)
- Creating UI-TDD (component specifications for axis-tools)
- Creating Service-TDD (Lambda specifications for nodejs-pair-programmer)
- Converting Feature Specification Documents to technical designs

**Basic Usage:**
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD from customer-portal FSD

Skill: AIDLC-design:generate
Create UI-TDD for customer-portal

Skill: AIDLC-design:generate
Generate Service-TDD for customer-search Lambda
```

**Advanced Usage with File Paths:**
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD from ./requirements/claims-processing-fsd.md
Use Master TDD at ./reference/master-tdd.md
Use Common Library TDD at ./reference/common-library-tdd.md

Skill: AIDLC-design:generate
Create UI-TDD for claims-submission feature
Source Feature-TDD: ./workspace/EPIC-12345/technical/design/claims-submission-Feature-TDD.md
Source FSD: ./requirements/claims-submission-fsd.md

Skill: AIDLC-design:generate
Generate consolidated Service-TDD for all Lambda services in claims-processing
Include: claims-validator, claims-processor, claims-enrichment services
```

**How It Works:**
1. **Analyzes user intent** - Identifies document type (Feature-TDD | UI-TDD | Service-TDD)
2. **ADLCs required context** - Locates FSD, Master TDD, Common Library TDD, Feature-TDD
3. **Uses selective reading** - Efficiently processes large documents (Master TDD ~41K tokens)
4. **Verifies critical patterns:**
   - Endpoint URLs verified (no guessing/hallucination)
   - Protocol specification (SOAP vs REST)
   - Async operations >16s with polling
   - Lambda config 1024MB/30s
   - 11-function Flow Engine for multi-step workflows
   - Rules-as-a-Service integration
   - Reference-data dropdown pattern
   - Sequence diagrams (Mermaid + PlantUML)
   - AUG (Axis UI Generator) JSON-based design
   - Minimal code output (HLR-14)
5. **Presents plan** - Shows what will be generated and waits for user confirmation
6. **Delegates to specialized agent:**
   - `feature-tdd-designer` → `{feature}-Feature-TDD.md`
   - `ui-tdd-designer` → `{feature}-UI-TDD.md`
   - `service-tdd-designer` → `{feature}-Service-TDD.md` (consolidated)

**Output Location:** `.claude_kb/workspaces/EPIC-XXX/technical/design/`

**Generated Files:**
- `{feature-name}-Feature-TDD.md` - Combined UI + Services architecture
- `{feature-name}-UI-TDD.md` - UI component specifications (for axis-tools)
- `{feature-name}-Service-TDD.md` - Consolidated Lambda specifications (for nodejs-pair-programmer)

---

### 2. `AIDLC-design:validate`

**Purpose:** Validate design document coverage against source requirements and critical patterns.

**When to Use:**
- Validating Feature-TDD coverage against FSD
- Validating UI-TDD coverage against Feature-TDD and FSD
- Validating Service-TDD coverage against Feature-TDD and FSD
- Checking compliance with critical patterns

**Basic Usage:**
```bash
Skill: AIDLC-design:validate
Validate Feature-TDD against FSD

Skill: AIDLC-design:validate
Check Service-TDD for customer-search
```

**Advanced Usage:**
```bash
Skill: AIDLC-design:validate
Validate claims-submission-Feature-TDD against the original FSD
Check for:
- Complete requirement coverage
- Critical pattern compliance
- Protocol specifications
- Lambda configuration accuracy

Skill: AIDLC-design:validate
Validate claims-submission-UI-TDD
Verify:
- All components from Feature-TDD are included
- AUG JSON schema compliance
- Cross-field validation rules
- Sequence diagrams present (Mermaid + PlantUML)
```

**What It Checks:**
- **Requirement Coverage** - All FSD requirements addressed in target document
- **Critical Pattern Compliance:**
  - Protocol specification (SOAP vs REST) for all external services
  - Async operations pattern for >16s operations
  - Lambda config (1024MB / 30s timeout)
  - 11-function Flow Engine breakdown
  - Rules-as-a-Service integration
  - Reference-data dropdown pattern
  - Sequence diagrams (both Mermaid and PlantUML)
  - AUG JSON-based design (UI-TDD)
  - Minimal code output (HLR-14)
- **Consistency** - Cross-document consistency checks
- **Anti-Pattern Violations** - 10-point checklist validation

**Output:**
- Coverage percentage
- List of gaps (missing requirements)
- Inconsistencies found
- Critical pattern violations
- Priority recommendations

---

### 3. `AIDLC-design:explore`

**Purpose:** Explore and understand existing design documents and patterns.

**When to Use:**
- Finding specific design documents or sections
- Explaining architecture decisions
- Comparing design versions
- Tracing requirements through Feature-TDD to TDD
- Verifying critical patterns in existing designs

**Basic Usage:**
```bash
Skill: AIDLC-design:explore
What services are in customer-portal Feature-TDD?

Skill: AIDLC-design:explore
Does customer-search Service-TDD specify SOAP or REST?
```

**Advanced Usage:**
```bash
Skill: AIDLC-design:explore
Show me the data flow for the claims submission process
Trace from FSD through Feature-TDD to UI-TDD and Service-TDD

Skill: AIDLC-design:explore
Compare the async operations pattern used in customer-search Service-TDD
with the pattern specified in the Master TDD

Skill: AIDLC-design:explore
List all external service integrations in the claims-processing Feature-TDD
Include protocol specifications and endpoint URLs

Skill: AIDLC-design:explore
Explain the 11-function Flow Engine breakdown for claims-enrichment service
Show which functions handle validation, processing, and persistence
```

**Query Types:**

| Query Type | Example | What It Does |
|------------|---------|--------------|
| **Find** | "Locate the claims-processing UI-TDD" | Searches workspace for specific documents |
| **Explain** | "Explain the async pattern in customer-search" | Analyzes architecture decisions |
| **Compare** | "Compare Feature-TDD v1 vs v2" | Shows differences between versions |
| **Trace** | "Trace requirement R-123 through designs" | Follows requirement from FSD → Feature-TDD → TDD |
| **Verify** | "Check protocol specs in all Service-TDDs" | Validates critical pattern compliance |

**Search Strategy:**
- GLOB for design documents in workspace
- GREP for specific terms or components
- READ relevant sections
- Cross-reference between Feature-TDD and TDDs

---

### 4. `AIDLC-design:help`

**Purpose:** Display comprehensive help documentation for AIDLC-design plugin.

**When to Use:**
- Need guidance on using design tools
- Understanding design document types
- Learning workflow sequences
- Reviewing quality checklists

**Usage:**
```bash
Skill: AIDLC-design:help
Show me how to use AIDLC-design

Skill: AIDLC-design:help
What are the three design document types?
```

**Help Topics Covered:**
- Plugin overview and SDLC role
- All four skills with usage examples
- Document flow and generation workflow
- Three design document types (Feature-TDD, UI-TDD, Service-TDD)
- Document storage locations
- Comprehensive specifications
- POM integration approach
- Confirmation workflow (Plan → Confirm → Generate)
- Quality checklist
- Plugin distinctions

## Workflow Integration

### End-to-End Design Workflow

This section provides complete examples for common design scenarios using the new skill-based approach.

#### Workflow 1: Complete Feature Design (All Three Documents)

**Scenario:** Generate complete design documentation for a new claims-submission feature.

```bash
# Step 1: Generate Feature-TDD (Architecture)
Skill: AIDLC-design:generate
Generate Feature-TDD for claims-submission feature
Source FSD: ./requirements/claims-submission-fsd.md
Master TDD: ./reference/master-tdd.md
Common Library: ./reference/common-library-tdd.md

# [Agent presents plan] → User reviews and confirms

# Output: .claude_kb/workspaces/EPIC-12345/technical/design/claims-submission-Feature-TDD.md

# Step 2: Generate UI-TDD (Component Specifications)
Skill: AIDLC-design:generate
Create UI-TDD for claims-submission feature
Use Feature-TDD at ./workspace/EPIC-12345/technical/design/claims-submission-Feature-TDD.md
Include AUG JSON schemas and sequence diagrams

# [Agent presents plan] → User reviews and confirms

# Output: .claude_kb/workspaces/EPIC-12345/technical/design/claims-submission-UI-TDD.md

# Step 3: Generate Service-TDD (Lambda Specifications)
Skill: AIDLC-design:generate
Generate consolidated Service-TDD for claims-submission
Include all Lambda services: validator, processor, enrichment
Use Feature-TDD at ./workspace/EPIC-12345/technical/design/claims-submission-Feature-TDD.md

# [Agent presents plan] → User reviews and confirms

# Output: .claude_kb/workspaces/EPIC-12345/technical/design/claims-submission-Service-TDD.md

# Step 4: Validate Complete Design
Skill: AIDLC-design:validate
Validate all three TDD documents for claims-submission
Check coverage, critical patterns, and consistency

# Step 5: Pass to Code Generation
# UI-TDD → AIDLC-axis plugin
# Service-TDD → AIDLC-lambda plugin
```

---

#### Workflow 2: Quick UI-Only Design

**Scenario:** Generate only UI component specifications for a simple form.

```bash
# Step 1: Generate Feature-TDD (Lightweight)
Skill: AIDLC-design:generate
Generate Feature-TDD for customer-profile-form
This is a simple form feature with no backend services
FSD: ./requirements/customer-profile-fsd.md

# Step 2: Generate UI-TDD
Skill: AIDLC-design:generate
Create UI-TDD for customer-profile-form
Include form validators, AUG JSON schemas, and component interactions

# Step 3: Validate UI-TDD
Skill: AIDLC-design:validate
Validate customer-profile-form UI-TDD against Feature-TDD
Check AUG compliance and sequence diagrams

# Step 4: Generate Angular Components
# Pass UI-TDD to AIDLC-axis plugin
```

---

#### Workflow 3: Service-Only Design (Backend Lambda)

**Scenario:** Generate Lambda service specifications for a new API service.

```bash
# Step 1: Generate Feature-TDD (Architecture)
Skill: AIDLC-design:generate
Generate Feature-TDD for claims-enrichment service
Focus on backend architecture - API Gateway + Lambda + DynamoDB
FSD: ./requirements/claims-enrichment-fsd.md

# Step 2: Generate Service-TDD
Skill: AIDLC-design:generate
Generate Service-TDD for claims-enrichment
Include all critical patterns:
- Protocol specification (REST)
- Async operations for long-running enrichment
- 11-function Flow Engine breakdown
- Rules-as-a-Service integration

# Step 3: Explore Generated Design
Skill: AIDLC-design:explore
Show me the 11-function breakdown for claims-enrichment
Explain the async operations pattern

# Step 4: Validate Service-TDD
Skill: AIDLC-design:validate
Validate claims-enrichment Service-TDD
Check Lambda config, protocol specs, and async pattern compliance

# Step 5: Generate Lambda Code
# Pass Service-TDD to AIDLC-lambda plugin
```

---

#### Workflow 4: Iterative Design Updates

**Scenario:** Update existing design documents after requirement changes.

```bash
# Step 1: Explore Current Design
Skill: AIDLC-design:explore
Show me the current claims-submission Feature-TDD
What services are currently defined?

# Step 2: Regenerate Feature-TDD with Updates
Skill: AIDLC-design:generate
Update Feature-TDD for claims-submission
New requirements: Add claims-notification service
Updated FSD: ./requirements/claims-submission-fsd-v2.md

# Step 3: Regenerate Service-TDD
Skill: AIDLC-design:generate
Update Service-TDD for claims-submission
Add claims-notification service specifications
Include SNS topic integration

# Step 4: Validate Updated Design
Skill: AIDLC-design:validate
Validate updated claims-submission Service-TDD
Ensure new notification service follows critical patterns

# Step 5: Compare Versions
Skill: AIDLC-design:explore
Compare claims-submission-Service-TDD v1 vs v2
Show differences in service architecture
```

---

#### Workflow 5: Design Review and Troubleshooting

**Scenario:** Review and fix issues in existing design documents.

```bash
# Step 1: Validate Existing Design
Skill: AIDLC-design:validate
Validate customer-portal Service-TDD
Check for critical pattern violations

# [Agent reports issues: missing protocol specs, wrong Lambda config]

# Step 2: Explore Specific Issues
Skill: AIDLC-design:explore
Show all external service integrations in customer-portal Service-TDD
Which ones are missing protocol specifications?

# Step 3: Explore Master TDD for Guidance
Skill: AIDLC-design:explore
Show the async operations pattern from Master TDD
Compare with customer-search service implementation

# Step 4: Regenerate with Fixes
Skill: AIDLC-design:generate
Regenerate customer-portal Service-TDD
Fix protocol specifications for all external services
Update Lambda config to 1024MB / 30s
Add async pattern for customer-search (>16s operation)

# Step 5: Re-validate
Skill: AIDLC-design:validate
Validate updated customer-portal Service-TDD
Confirm all critical patterns are now compliant
```

---

#### Workflow 6: Cross-Document Traceability

**Scenario:** Trace requirements from FSD through all design documents.

```bash
# Step 1: Explore FSD Requirements
Skill: AIDLC-design:explore
List all requirements in claims-processing FSD
Group by feature area (UI, Services, Integration)

# Step 2: Trace to Feature-TDD
Skill: AIDLC-design:explore
Trace requirement R-456 "Claims auto-validation"
Show how it's addressed in Feature-TDD

# Step 3: Trace to UI-TDD
Skill: AIDLC-design:explore
Show how requirement R-456 maps to UI-TDD components
Which validators and form fields implement this requirement?

# Step 4: Trace to Service-TDD
Skill: AIDLC-design:explore
Show how requirement R-456 maps to Service-TDD
Which Lambda services handle auto-validation?

# Step 5: Generate Traceability Report
Skill: AIDLC-design:validate
Validate requirement traceability for R-456
Confirm it's fully covered in all three TDD documents
```

---

### Typical Design Flow Summary

**Phase 1: Architecture (Feature-TDD)**
1. Provide FSD, Master TDD, Common Library TDD
2. Invoke: `AIDLC-design:generate` skill with Feature-TDD request
3. Agent verifies critical patterns (protocol, async, Lambda config)
4. Review Feature-TDD for approval

**Phase 2: Specifications (UI-TDD + Service-TDD)**
5. After Feature-TDD approval
6. Invoke: `AIDLC-design:generate` skill for UI-TDD
7. Invoke: `AIDLC-design:generate` skill for Service-TDD
8. Review UI-TDD and Service-TDD documents

**Phase 3: Validation**
9. Invoke: `AIDLC-design:validate` skill for each document
10. Check coverage and critical pattern compliance
11. Address any gaps identified

**Phase 4: Code Generation**
12. Pass UI-TDD to AIDLC-axis plugin
13. Pass Service-TDD to AIDLC-lambda plugin

## Skill Invocation Best Practices

### Natural Language Requests

Skills accept natural language requests. Be specific about what you need:

**Good Examples:**
```bash
✓ Generate Feature-TDD from ./requirements/claims-fsd.md with async patterns
✓ Create UI-TDD for customer-portal including AUG JSON schemas
✓ Validate claims-submission Service-TDD for critical pattern compliance
✓ Show me all Lambda services in the customer-portal Feature-TDD
```

**Avoid Vague Requests:**
```bash
✗ Generate design
✗ Make a TDD
✗ Check the document
✗ Show me stuff
```

### Providing File Paths

Always provide explicit file paths when available:

```bash
Skill: AIDLC-design:generate
Generate Feature-TDD for claims-processing
FSD: ./requirements/claims-processing-fsd.md
Master TDD: ./reference/master-tdd.md
Common Library: ./reference/common-library-tdd.md
Output to: ./.claude_kb/workspaces/EPIC-12345/technical/design/
```

### Specifying Requirements

Be explicit about specific patterns or requirements:

```bash
Skill: AIDLC-design:generate
Generate Service-TDD for customer-search
Requirements:
- Must include async operations pattern (search takes >16s)
- Protocol: REST with JSON
- Lambda config: 1024MB / 30s
- Include Rules-as-a-Service integration
- Add sequence diagrams (Mermaid + PlantUML)
```

### Confirming Plans

The `generate` skill always presents a plan before execution:

```
Agent: "I will generate Feature-TDD with the following approach:
1. Read FSD from ./requirements/claims-fsd.md
2. Extract Master TDD Section 20 (Lambda patterns)
3. Identify 5 UI components and 3 Lambda services
4. Verify protocol specifications for external services
5. Create claims-processing-Feature-TDD.md

Proceed? (yes/no)"

User: "Yes, proceed"
```

### Iterative Refinement

Use explore and validate skills to refine designs:

```bash
# Generate initial design
Skill: AIDLC-design:generate
Generate Service-TDD for claims-validator

# Explore what was generated
Skill: AIDLC-design:explore
Show me the validation rules in claims-validator Service-TDD

# Validate compliance
Skill: AIDLC-design:validate
Check claims-validator Service-TDD for protocol specifications

# Regenerate with fixes
Skill: AIDLC-design:generate
Regenerate claims-validator Service-TDD
Fix: Add REST protocol specification for external validation service
```

### Policy Object Model (POM) Integration

Design agent focuses on **relevant POM sections** for each feature:
- Instruction-driven: Only when user explicitly provides POM
- Not the entire POM (too large)
- Only fields needed for the specific workflow
- Mapped to UI components (in UI-TDD)

**Example:**
```bash
Skill: AIDLC-design:generate
Generate UI-TDD for claims-submission form
POM subsection: Claims.Submission (fields: claimNumber, claimDate, claimAmount)
Map to form components with validation rules
```

## Quality Checklist

Before completion, design specs verify:
- [ ] All FSD features addressed in Feature-TDD
- [ ] Component inputs/outputs clearly defined (UI-TDD)
- [ ] Protocol specification (SOAP or REST) for all external services
- [ ] Endpoint URLs verified (NEVER guess or use placeholders like example.com)
- [ ] Async pattern for operations >16s with operation-status table
- [ ] Lambda config: 1024MB / 30s timeout (not 512MB/16s)
- [ ] 11-function Flow Engine for multi-step workflows
- [ ] Rules-as-a-Service integration (no embedded validation logic)
- [ ] Reference-data dropdown pattern with RDM integration (when applicable)
- [ ] Enhanced sequence diagrams showing all functions + protocol + async branching
- [ ] Manual TDD references (Master TDD, Common Library TDD) included
- [ ] Anti-pattern validation passed (10-point checklist)
- [ ] Error handling with go-style pattern ([error, result])
- [ ] Accessibility requirements included
- [ ] Security considerations documented
- [ ] Testing requirements defined
- [ ] POM field mappings accurate (if provided)
- [ ] Ready for code generation by pair programmers

## Troubleshooting

### Common Issues After Migration

#### Issue 1: Old Slash Commands Not Working

**Problem:**
```bash
/AIDLC-design:generate Feature-TDD
# Error: Command not found
```

**Solution:**
The plugin has migrated to skills. Use the new skill syntax:
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD from ./requirements/feature-spec.md
```

---

#### Issue 2: Skill Not Auto-Invoked

**Problem:** Saying "generate a Feature-TDD" doesn't automatically invoke the skill.

**Solution:** Use explicit skill invocation:
```bash
Skill: AIDLC-design:generate
[Your request here]
```

Auto-invocation depends on Claude Code's context understanding. Be explicit when needed.

---

#### Issue 3: Plan Confirmation Required

**Problem:** Agent shows a plan but doesn't generate the document.

**Solution:** The `generate` skill requires explicit confirmation:
```
Agent: [Presents plan]
User: "Yes, proceed with the plan"
```

This is a feature, not a bug - it ensures you review the approach before generation.

---

#### Issue 4: Can't Find Input Documents

**Problem:**
```
Agent: "Could not locate FSD at ./requirements/feature-spec.md"
```

**Solution:** Provide absolute or correct relative paths:
```bash
Skill: AIDLC-design:generate
Generate Feature-TDD
FSD: C:/workspace/requirements/feature-spec.md
# Or use explore first
```

Or use explore to find documents:
```bash
Skill: AIDLC-design:explore
Find all FSD documents in the workspace
```

---

#### Issue 5: Wrong Document Type Generated

**Problem:** Asked for UI-TDD but got Service-TDD.

**Solution:** Be explicit about document type:
```bash
Skill: AIDLC-design:generate
Create UI-TDD (not Service-TDD) for customer-portal
Component specifications for axis-tools
```

---

### FAQ: Skills vs Commands

**Q: Why did AIDLC-design migrate from commands to skills?**

A: Skills provide better integration with Claude Code's natural language processing, improved auto-invocation, and follow the agentskills.io specification standard.

---

**Q: Are old slash commands still supported?**

A: No. Slash commands (`/AIDLC-design:command`) were fully replaced by skills (`Skill: AIDLC-design:skill`) in version 1.4.0+.

---

**Q: Can I still use command syntax?**

A: No. The `commands/` directory was removed. Use the skill syntax with natural language requests.

---

**Q: What's the difference between `Skill:` and `/command`?**

A:
- **Skills** accept natural language requests and use extended thinking for better routing
- **Commands** used rigid argument syntax (no longer supported)

---

**Q: How do I know which skill to use?**

A: Use this decision tree:

```
Need to create/update design documents?
  → Use AIDLC-design:generate

Need to check coverage/compliance?
  → Use AIDLC-design:validate

Need to find/understand existing designs?
  → Use AIDLC-design:explore

Need help using the plugin?
  → Use AIDLC-design:help
```

---

**Q: Can I chain multiple skill invocations?**

A: Yes, but invoke them sequentially:

```bash
# Step 1
Skill: AIDLC-design:generate
Generate Feature-TDD

# Wait for completion, then Step 2
Skill: AIDLC-design:validate
Validate Feature-TDD

# Wait for completion, then Step 3
Skill: AIDLC-design:explore
Show all services in Feature-TDD
```

---

**Q: Where can I find skill implementation details?**

A: Skills are located in `plugins/AIDLC-design/skills/*/SKILL.md`:
- `skills/generate/SKILL.md` - Generation logic
- `skills/validate/SKILL.md` - Validation logic
- `skills/explore/SKILL.md` - Exploration logic
- `skills/help/SKILL.md` - Help content

---

## Agent Locations

- **Router Agent**: `agents/design-agent.md` - Routes design requests to specialized agents
- **Feature-TDD Designer**: `agents/feature-tdd-designer.md` - Generates architecture documents
- **UI-TDD Designer**: `agents/ui-tdd-designer.md` - Generates component specifications
- **Service-TDD Designer**: `agents/service-tdd-designer.md` - Generates consolidated Lambda specifications
- **Design Guidelines**: `agents/design-guidelines.md` - Reference patterns and best practices
- **Skills Directory**: `skills/*/SKILL.md` - Skill implementations (generate, validate, explore, help)
- **Workspace**: `.claude_kb/workspaces/EPIC-XXX/technical/design/`

---

## Verifying Plugin Updates

### When Using Plugin from a Different Repository

If you've cloned or installed this plugin in a different repository/machine, here's how to verify you have the latest version with Master TDD references:

#### 1. Check Plugin Version

```bash
# Check the plugin version in the plugin.json file
cat plugins/AIDLC-design/.claude-plugin/plugin.json | grep version
# Should show: "version": "5.0.1" or higher
```

Or check the README version section (above).

#### 2. Verify Agent Files Contain Master TDD Traits

```bash
# Check if service-tdd-designer has Master TDD references trait
grep -n "MasterTDDReferences" plugins/AIDLC-design/agents/service-tdd-designer.md
# Should return: Line 48: MasterTDDReferences,"Add Master TDD section references..."

# Check if ui-tdd-designer has Master TDD references trait
grep -n "MasterTDDReferences" plugins/AIDLC-design/agents/ui-tdd-designer.md
# Should return: Line 37: MasterTDDReferences,"Add Master TDD section references..."

# Check if feature-tdd-designer has Master TDD references trait
grep -n "MasterTDDReferences" plugins/AIDLC-design/agents/feature-tdd-designer.md
# Should return: Line 43: MasterTDDReferences,"Add Master TDD section references..."
```

#### 3. Test Generation with a Simple Example

After installing/updating the plugin, generate a small test TDD:

```bash
# In Claude Code, run:
/AIDLC-design:generate Service-TDD - Create a simple validation service

**Feature Specification:**
# Test Feature: Input Validator
Simple validation service for testing

## Service: Input Validator
- POST /api/validate
- Validates JSON input
- Returns validation results
```

**Expected Output**: The generated Service-TDD should include:

```markdown
> **Master TDD Reference**: Section 20 - Lambda Code Generation Template

## 1. Introduction
> **Master TDD Reference**: Section 3.2 - Core Services and Shared Libraries

## 2. Service Architecture
> **Master TDD Reference**: Section 20.4 - Architectural Layers and Responsibilities
```

#### 4. Automated Verification Script

Create a verification script to check all required updates:

```bash
#!/bin/bash
# verify-plugin-updates.sh

echo "Verifying AIDLC-design plugin updates..."

# Check version
VERSION=$(grep -o '"version": "[^"]*"' plugins/AIDLC-design/.claude-plugin/plugin.json | cut -d'"' -f4)
echo "✓ Plugin Version: $VERSION"

# Check service-tdd-designer
if grep -q "MasterTDDReferences" plugins/AIDLC-design/agents/service-tdd-designer.md; then
    echo "✓ service-tdd-designer.md has Master TDD references trait"
else
    echo "✗ service-tdd-designer.md MISSING Master TDD references trait"
fi

# Check ui-tdd-designer
if grep -q "MasterTDDReferences" plugins/AIDLC-design/agents/ui-tdd-designer.md; then
    echo "✓ ui-tdd-designer.md has Master TDD references trait"
else
    echo "✗ ui-tdd-designer.md MISSING Master TDD references trait"
fi

# Check feature-tdd-designer
if grep -q "MasterTDDReferences" plugins/AIDLC-design/agents/feature-tdd-designer.md; then
    echo "✓ feature-tdd-designer.md has Master TDD references trait"
else
    echo "✗ feature-tdd-designer.md MISSING Master TDD references trait"
fi

# Check templates
if grep -q "Master TDD Reference" plugins/AIDLC-design/reference/service-tdd-template.md; then
    TEMPLATE_REFS=$(grep -c "Master TDD Reference" plugins/AIDLC-design/reference/service-tdd-template.md)
    echo "✓ service-tdd-template.md has $TEMPLATE_REFS Master TDD references"
else
    echo "✗ service-tdd-template.md MISSING Master TDD references"
fi

echo ""
echo "Verification complete. If all checks passed, you have the latest version."
```

#### 5. Force Plugin Reload

After verifying files are updated, reload the plugin:

**In VSCode:**
- Press `Ctrl+Shift+P` (Windows/Linux) or `Cmd+Shift+P` (Mac)
- Type: "Developer: Reload Window"
- Press Enter

**Or restart Claude Code CLI** if using command-line interface.

### Troubleshooting

If Master TDD references are not appearing in generated documents:

1. **Check Git Pull**: Ensure you've pulled the latest changes
   ```bash
   git pull origin main
   git log --oneline -5  # Verify you have commits from 2025-12-10
   ```

2. **Check File Modifications**: Verify the agent files were updated
   ```bash
   git diff HEAD~5 plugins/AIDLC-design/agents/service-tdd-designer.md
   ```

3. **Clear Plugin Cache**: Some systems cache plugin configurations
   ```bash
   # Remove any cached plugin data (if applicable)
   rm -rf ~/.claude-code/cache/plugins/AIDLC-design
   ```

4. **Reinstall Plugin**: Uninstall and reinstall the plugin
   ```bash
   claude-code marketplace uninstall <path-to-marketplace>
   claude-code marketplace install <path-to-marketplace>
   ```

## Quick Reference: Skill Commands

### Skill Syntax Cheat Sheet

| Task | Old Command (Deprecated) | New Skill Syntax |
|------|-------------------------|------------------|
| **Generate Feature-TDD** | `/AIDLC-design:generate Feature-TDD from FSD` | `Skill: AIDLC-design:generate`<br>Generate Feature-TDD from FSD |
| **Generate UI-TDD** | `/AIDLC-design:generate UI-TDD for feature` | `Skill: AIDLC-design:generate`<br>Create UI-TDD for feature |
| **Generate Service-TDD** | `/AIDLC-design:generate Service-TDD for service` | `Skill: AIDLC-design:generate`<br>Generate Service-TDD for service |
| **Validate Design** | `/AIDLC-design:validate Feature-TDD` | `Skill: AIDLC-design:validate`<br>Validate Feature-TDD against FSD |
| **Explore Designs** | `/AIDLC-design:explore services in Feature-TDD` | `Skill: AIDLC-design:explore`<br>What services are in Feature-TDD? |
| **Get Help** | `/AIDLC-design:help` | `Skill: AIDLC-design:help`<br>Show help documentation |

### Common Request Patterns

**Generate Requests:**
```bash
Skill: AIDLC-design:generate
[Generate|Create|Build] [Feature-TDD|UI-TDD|Service-TDD] [for|from] [feature-name]
[Optional: Include specific requirements]
[Optional: Source files with paths]
```

**Validate Requests:**
```bash
Skill: AIDLC-design:validate
[Validate|Check|Review] [document-name] [against|for] [source|compliance]
[Optional: Specific patterns to check]
```

**Explore Requests:**
```bash
Skill: AIDLC-design:explore
[What|Show|List|Find|Explain|Compare] [aspect] in [document-name]
[Optional: Specific query details]
```

### Critical Pattern Checklist

When generating design documents, ensure these patterns are included:

- [ ] **Protocol Specification** - SOAP or REST for ALL external services
- [ ] **Endpoint URLs** - Actual verified URLs (never guess or use placeholders)
- [ ] **Async Operations** - 3-endpoint pattern for operations >16s
- [ ] **Lambda Configuration** - 1024MB memory / 30s timeout
- [ ] **11-Function Flow Engine** - Breakdown for multi-step workflows
- [ ] **Rules-as-a-Service** - External OPA validation (no embedded rules)
- [ ] **Reference-Data Dropdown** - RDM integration with caching
- [ ] **Sequence Diagrams** - Both Mermaid and PlantUML formats
- [ ] **AUG Compliance** - JSON-based design (no raw HTML templates)
- [ ] **Minimal Code** - Specifications, not implementations (HLR-14)
- [ ] **Master TDD References** - Section references in all major sections

### Version History

- **1.5.0** (2026-02-25): Added sequence diagrams (HLR-13) and minimal code output (HLR-14)
- **1.4.1** (2026-02-06): Plugin manifest fixes, restored help and validate skills
- **1.4.0**: Migrated from slash commands to Claude Code skills
- **1.3.0** (2026-01-09): Token efficiency optimization (85-90% reduction)
- **1.2.0** (2025-12-18): Design Agent Review Feedback for V1.2 Release
- **1.1.1** (2025-12-11): Fixed Master TDD references in generated documents
- **1.1.0** (2025-12-10): Added Master TDD section references to all generated documents
- **1.0.0** (2025-12-08): Major refactoring with consolidated design capabilities

See [CHANGELOG.md](./CHANGELOG.md) for complete version history.

---

## Additional Resources

- **Acceptance Criteria**: `acceptance-criteria.md` - 14 High-Level Requirements (HLRs)
- **Templates**: `reference/` - Service-TDD and UI-TDD templates
- **Design Guidelines**: `agents/design-guidelines.md` - Patterns and best practices
- **Tests**: `__tests__/` - 14+ evaluation tests for plugin validation
- **Master TDD**: Reference architecture document (~41K tokens)
- **Common Library TDD**: Shared library specifications

## Support

For issues, questions, or feedback:
1. Check this README and the troubleshooting section
2. Review `CHANGELOG.md` for recent changes
3. Run `Skill: AIDLC-design:help` for interactive help
4. Examine `acceptance-criteria.md` for requirements and test cases
