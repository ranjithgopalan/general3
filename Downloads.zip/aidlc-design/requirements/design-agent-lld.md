# Low-Level Design: Design Agent Plugin

**Plugin:** design-agent (AIDLC-design)
**Version:** 3.0
**Document Type:** Low-Level Design (LLD)
**Status:** Draft
**Last Updated:** December 8, 2025

---

## Table of Contents

1. [Plugin Configuration](#1-plugin-configuration)
2. [Agent Implementations](#2-agent-implementations)
3. [Mandatory Pattern Implementations](#3-mandatory-pattern-implementations)
4. [Large Document Handling](#4-large-document-handling)
5. [Sub-Agent Delegation](#5-sub-agent-delegation)
6. [Anti-Pattern Validation](#6-anti-pattern-validation)
7. [Tool Usage Patterns](#7-tool-usage-patterns)
8. [Error Handling](#8-error-handling)
9. [Testing Implementation](#9-testing-implementation)

---

## 1. Plugin Configuration

### 1.1 plugin.json

```json
{
  "name": "design-agent",
  "version": "6.0.0",
  "description": "Generates Service-TDD (ONE consolidated doc for ALL backend services), Integration-TDD (SOAP systems), and UI-TDD from Master TDD + FSD with MANDATORY async patterns, SOAP specs, 11-function Flow Engine, Rules-as-a-Service, and anti-pattern validation.",
  "author": "AI COE Team & S3 Team",
  "keywords": ["design", "TDD", "Service-TDD", "Integration-TDD", "UI-TDD", "async", "SOAP", "11-function", "Rules-as-a-Service"]
}
```

### 1.2 Directory Structure

```
design-agent/
├── .claude-plugin/plugin.json
├── agents/
│   ├── design-agent.md              # Router/orchestrator with anti-pattern validation
│   ├── service-tdd-designer.md     # Service-TDD (ONE consolidated doc) + Integration-TDD
│   ├── ui-tdd-designer.md           # UI-TDD → axis-tools
│   └── design-guidelines.md         # Reference patterns
├── commands/
│   └── design.md                    # Unified command (prompt enricher)
├── __tests__/
│   └── [test files for 11 HLRs]
└── requirements/
    ├── hlr.md
    ├── design-agent-brd.md           # Version 5.0
    ├── design-agent-hld.md           # Version 6.0 (THIS DOCUMENT'S COMPANION)
    └── design-agent-lld.md           # This document
```

---

## 2. Agent Implementations

### 2.1 Router Agent: design-agent.md

```markdown
---
name: design-agent
description: Routes design requests to specialized agents. Reads Master TDD patterns, checks SOAP vs REST inventory, runs anti-pattern validation. Generates Service-TDD (ONE consolidated doc), Integration-TDD, or UI-TDD.
model: sonnet
color: magenta
tools:
  - Read
  - Write
  - Glob
  - Grep
  - Task
---

[Extended thinking: I am the design-agent router that orchestrates TDD generation with MANDATORY async patterns, SOAP protocol specifications, 11-function Flow Engine breakdown, Rules-as-a-Service integration, and anti-pattern validation. When I receive a request, I first (1) read Master TDD selectively for mandatory patterns (async, SOAP, 11-function, Rules-as-a-Service, anti-patterns, Lambda config); (2) read FSD completely to extract requirements and identify >16s operations; (3) check SOAP vs REST Endpoint Inventory if external APIs mentioned; (4) analyze design intent (Service-TDD vs Integration-TDD vs UI-TDD); (5) delegate to specialized designer agent with complete context; (6) after agent completes, run anti-pattern validation checks (8 critical checks); (7) if ANY check fails, request corrections before delivering output. I NEVER skip protocol checking, NEVER skip anti-pattern validation, NEVER deliver output with critical omissions. I do NOT generate Feature-TDD as Master TDD already covers feature-level architecture.]

# Design Agent Router

You orchestrate TDD generation by reading Master TDD patterns, checking protocols, and delegating to specialized designers.

## Your Role

1. Read Master TDD selectively for mandatory patterns
2. Read FSD completely for requirements
3. Check SOAP vs REST Endpoint Inventory (if integrations)
4. Analyze design intent and present plan
5. Delegate to specialized designer
6. Run anti-pattern validation (8 checks)
7. Deliver validated output

## Routing Logic

| User Intent | Trigger Keywords | Route To | Output |
|-------------|------------------|----------|--------|
| Service-TDD | "Service-TDD", "Lambda TDD", "backend" | service-tdd-designer | `{feature}-Service-TDD.md` |
| Integration-TDD | "Integration-TDD", "SOAP", "external system" | service-tdd-designer (Integration mode) | `{feature}-Integration-TDD.md` |
| UI-TDD | "UI-TDD", "component specs", "axis-tools" | ui-tdd-designer | `{feature}-UI-TDD.md` |
| Coverage | "validate", "coverage", "check" | Direct handling | Coverage report |

## Required Inputs

### For Service-TDD / Integration-TDD:
- **Master TDD** (Architecture Strategy) - Required - Selective reading for mandatory patterns
- **FSD** (Feature Specification) - Required - Complete reading
- **Common Library TDD** (Shared Library Specs) - Required - Selective reading
- **SOAP vs REST Endpoint Inventory** - Required if external APIs mentioned in FSD
- **Rules-as-a-Service API Spec** - Optional

### For UI-TDD:
- **Master TDD** - Required (patterns reference)
- **FSD** - Required
- **POM** - Optional (instruction-driven)

## Master TDD Selective Reading Implementation

**CRITICAL:** Master TDD (~41K tokens) exceeds Claude Code's 25K token limit.

### Step 1: Read Table of Contents
```typescript
const toc = await Read({
  file_path: "master-tdd-full.md",
  limit: 150
});
// Parse section headings and line numbers
```

### Step 2: Grep for MANDATORY Pattern Sections
```typescript
const patterns = [
  "Async Operations|Asynchronous",
  "11-Function|Flow Engine|Function Breakdown",
  "SOAP|Protocol Specification",
  "Rules-as-a-Service|OPA",
  "Anti-Pattern|ANTIPATTERN",
  "Lambda Configuration"
];

for (const pattern of patterns) {
  await Grep({
    pattern: pattern,
    path: "master-tdd-full.md",
    output_mode: "content",
    "-n": true
  });
}
```

### Step 3: Read Mandatory Pattern Sections
```typescript
// Read Async Operations Pattern
await Read({
  file_path: "master-tdd-full.md",
  offset: async_section_line,
  limit: 200
});

// Read 11-Function Flow Engine
await Read({
  file_path: "master-tdd-full.md",
  offset: flow_engine_line,
  limit: 150
});

// Read SOAP Protocol Specification
await Read({
  file_path: "master-tdd-full.md",
  offset: soap_line,
  limit: 150
});

// Read Rules-as-a-Service Integration
await Read({
  file_path: "master-tdd-full.md",
  offset: rules_line,
  limit: 100
});

// Read Anti-Patterns
await Read({
  file_path: "master-tdd-full.md",
  offset: antipattern_line,
  limit: 100
});

// Read Lambda Configuration
await Read({
  file_path: "master-tdd-full.md",
  offset: lambda_config_line,
  limit: 50
});
```

## SOAP vs REST Endpoint Inventory Check

**CRITICAL:** If FSD mentions external APIs, MUST check inventory. NEVER assume REST.

```typescript
// Step 1: Parse FSD for external API mentions
const externalAPIs = extractExternalAPIsFromFSD(fsd);

if (externalAPIs.length > 0) {
  // Step 2: Check for SOAP vs REST Endpoint Inventory
  const inventoryPath = findInventoryPath(); // Look for soap-rest-endpoint-inventory.yaml

  if (!inventoryPath) {
    // STOP and ASK user
    throw new Error(`
      ⚠️ **External APIs Detected - Protocol Inventory Required**

      The FSD mentions external APIs: ${externalAPIs.join(", ")}

      **Required:** SOAP vs REST Endpoint Inventory
      **Format:** YAML file with protocol specifications

      **Example:**
      external_apis:
        - name: MDM Producer Search
          protocol: SOAP
          endpoint: https://mdm-gateway.example.com
        - name: RDM Reference Data
          protocol: REST
          endpoint: https://rdm-api.example.com

      **Recovery:** Provide the inventory file path or content.
    `);
  }

  // Step 3: Read and parse inventory
  const inventory = await Read({ file_path: inventoryPath });
  const protocolMap = parseProtocolInventory(inventory);

  // Step 4: Pass protocol map to designer agent
  context.protocolMap = protocolMap;
}
```

## Anti-Pattern Validation (8 Critical Checks)

**CRITICAL:** After designer agent completes, run validation BEFORE delivering output.

```typescript
async function validateAntiPatterns(tddContent: string, context: Context): Promise<ValidationResult> {
  const checks = [];

  // Check 1: No Synchronous Calls for >16s Operations
  if (context.hasLongRunningOperations) {
    const hasAsyncPattern =
      tddContent.includes("POST /async") &&
      tddContent.includes("GET /status") &&
      tddContent.includes("operation-status");
    checks.push({
      name: "No Synchronous Calls for >16s Operations",
      passed: hasAsyncPattern,
      message: hasAsyncPattern
        ? "Async pattern specified"
        : "MISSING: Async endpoints for >16s operations"
    });
  }

  // Check 2: No Hardcoded Endpoints
  const hasHardcodedEndpoints = /https?:\/\/[^"'\s]+/.test(
    tddContent.replace(/Vault|configuration|environment variable/gi, "")
  );
  checks.push({
    name: "No Hardcoded Endpoints",
    passed: !hasHardcodedEndpoints,
    message: !hasHardcodedEndpoints
      ? "Endpoints retrieved from configuration/Vault"
      : "FOUND: Hardcoded endpoints (should use Vault/config)"
  });

  // Check 3: No Try-Catch Blocks
  const hasTryCatch = /try\s*\{|catch\s*\(/i.test(tddContent);
  checks.push({
    name: "No Try-Catch Blocks",
    passed: !hasTryCatch,
    message: !hasTryCatch
      ? "Go-style [error, result] pattern used"
      : "FOUND: try-catch blocks (use go-style pattern)"
  });

  // Check 4: No Embedded Validation Logic
  const hasRulesService = tddContent.includes("Rules-as-a-Service") ||
                          tddContent.includes("rulesServiceClient");
  const hasEmbeddedValidation = /function validate|const validate\s*=/i.test(
    tddContent.replace(/Rules-as-a-Service|rulesServiceClient/g, "")
  );
  checks.push({
    name: "No Embedded Validation Logic",
    passed: hasRulesService && !hasEmbeddedValidation,
    message: hasRulesService
      ? "Rules-as-a-Service integration specified"
      : "MISSING: Rules-as-a-Service (NO embedded validation)"
  });

  // Check 5: No Protocol Assumption
  if (context.hasExternalAPIs) {
    const hasExplicitProtocol =
      tddContent.includes("Protocol: SOAP") ||
      tddContent.includes("Protocol: REST");
    checks.push({
      name: "No Protocol Assumption",
      passed: hasExplicitProtocol,
      message: hasExplicitProtocol
        ? "Protocol explicitly specified from inventory"
        : "MISSING: Explicit protocol specification (SOAP or REST)"
    });
  }

  // Check 6: No Schema Generation for Relational DBs
  const hasPostgreSQLDDL = /CREATE TABLE|ALTER TABLE|DROP TABLE/i.test(tddContent);
  checks.push({
    name: "No Schema Generation for Relational DBs",
    passed: !hasPostgreSQLDDL,
    message: !hasPostgreSQLDDL
      ? "PostgreSQL usage documented only (no DDL)"
      : "FOUND: PostgreSQL DDL (Data Architecture owns schema)"
  });

  // Check 7: No Missing Flow Engine Functions
  if (tddContent.includes("Flow Engine")) {
    const has11Functions = /function.*\[1\-11\]|sequence.*1.*11|11 functions/i.test(tddContent);
    checks.push({
      name: "No Missing Flow Engine Functions",
      passed: has11Functions,
      message: has11Functions
        ? "All 11 functions specified"
        : "MISSING: Complete 11-function breakdown"
    });
  }

  // Check 8: No Insufficient Lambda Config
  const hasCorrectConfig =
    tddContent.includes("1024") &&
    tddContent.includes("30") &&
    !tddContent.includes("512MB") &&
    !tddContent.includes("16s");
  checks.push({
    name: "No Insufficient Lambda Config",
    passed: hasCorrectConfig,
    message: hasCorrectConfig
      ? "Lambda config: 1024MB/30s"
      : "INCORRECT: Lambda config must be 1024MB/30s (NOT 512MB/16s)"
  });

  const allPassed = checks.every(check => check.passed);

  return {
    passed: allPassed,
    checks: checks,
    summary: allPassed
      ? "✅ All 8 anti-pattern checks passed"
      : `❌ ${checks.filter(c => !c.passed).length} anti-pattern check(s) failed`
  };
}
```

## Sub-Agent Delegation with Context

```typescript
// Delegate to service-tdd-designer with complete context
await Task({
  subagent_type: "design-agent:service-tdd-designer",
  model: "sonnet",
  description: "Generate Service-TDD with mandatory patterns",
  prompt: `
Generate Service-TDD from the following inputs:

**Master TDD Patterns:**
${masterTDDPatterns}

**FSD:**
${fsdContent}

**SOAP vs REST Endpoint Inventory:**
${protocolInventory}

**Common Library TDD Modules:**
${commonLibraryModules}

**OUTPUT PATH:** ${outputPath}

**MANDATORY REQUIREMENTS:**
1. Async pattern for operations >16s: POST /async, GET /status, operation-status table
2. SOAP protocol specification: ${soapAPIs.join(", ")} (SOAP envelope, XML parsing)
3. Complete 11-function Flow Engine breakdown (Functions 6/8/10 detailed)
4. Rules-as-a-Service integration (NO embedded validation)
5. Detailed sequence diagrams (sync + async, SOAP/REST indicators)
6. Lambda config: 1024MB/30s
7. Service-TDD: ONE consolidated document for ALL services

User Request: ${userRequest}
  `
});
```
```

---

### 2.2 Service-TDD Designer Agent

**Implementation:** See `plugins/AIDLC-design/agents/service-tdd-designer.md`

**Key Implementation Details:**

**IMPORTANT:** This agent generates ONE consolidated Service-TDD document containing ALL backend services for the feature, NOT separate documents per service.

#### Async Operations Implementation

```typescript
// Function to identify >16s operations from FSD
function identifyLongRunningOperations(fsd: string): LongRunningOperation[] {
  const operations: LongRunningOperation[] = [];

  // Parse FSD for duration indicators
  const durationPatterns = [
    /may take.*(\d+).*seconds?/i,
    /could take.*(\d+).*seconds?/i,
    /timeout.*(\d+).*seconds?/i,
    /external.*API.*call/i, // External APIs may be >16s
    /MDM.*search/i,          // Known long operations
    /complex.*transformation/i
  ];

  for (const pattern of durationPatterns) {
    const matches = fsd.match(pattern);
    if (matches) {
      const duration = parseInt(matches[1]) || 20; // Default to 20s if not specified
      if (duration > 16) {
        operations.push({
          name: extractOperationName(matches[0]),
          estimatedDuration: duration,
          requiresAsync: true
        });
      }
    }
  }

  return operations;
}

// Generate async pattern specification
function generateAsyncPattern(operation: LongRunningOperation): AsyncPattern {
  return {
    asyncEndpoint: {
      method: "POST",
      path: `/api/${operation.serviceName}/async`,
      requestBody: operation.requestSchema,
      response: {
        statusCode: 202,
        body: {
          requestId: "UUID",
          status: "IN_PROGRESS",
          statusUrl: `/api/${operation.serviceName}/status/{requestId}`
        }
      }
    },
    pollEndpoint: {
      method: "GET",
      path: `/api/${operation.serviceName}/status/{requestId}`,
      response: {
        statusCode: 200,
        body: {
          requestId: "UUID",
          status: "IN_PROGRESS | COMPLETED | FAILED",
          progress: "number (0-100)",
          result: "JSON (when COMPLETED)",
          error: "JSON (when FAILED)"
        }
      }
    },
    operationStatusTable: {
      tableName: "operation-status",
      schema: {
        PK: "requestId (UUID)",
        attributes: {
          operationType: "string",
          status: "IN_PROGRESS | COMPLETED | FAILED",
          progress: "number (0-100)",
          result: "JSON",
          error: "JSON",
          ttl: "number (expires after 24h)"
        }
      }
    },
    backgroundLambda: {
      trigger: "Async invocation from POST /async",
      function: `${operation.serviceName}-async-processor`,
      config: {
        memory: "1024MB",
        timeout: "30s"
      }
    }
  };
}
```

#### SOAP Protocol Implementation

```typescript
// Generate SOAP envelope structure
function generateSOAPEnvelope(api: SOAPAPISpec): string {
  return `
### SOAP Envelope Structure

**Request Envelope:**
\`\`\`xml
<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:ns="${api.namespace}">
  <soap:Header>
    <ns:AuthToken>${'{from Vault}'}</ns:AuthToken>
  </soap:Header>
  <soap:Body>
    <ns:${api.operation}>
      ${api.requestFields.map(f => `<ns:${f.name}>${'{' + f.type + '}'}</ns:${f.name}>`).join('\n      ')}
    </ns:${api.operation}>
  </soap:Body>
</soap:Envelope>
\`\`\`

**Response Envelope:**
\`\`\`xml
<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:ns="${api.namespace}">
  <soap:Body>
    <ns:${api.operation}Response>
      ${api.responseFields.map(f => `<ns:${f.name}>${'{' + f.type + '}'}</ns:${f.name}>`).join('\n      ')}
    </ns:${api.operation}Response>
  </soap:Body>
</soap:Envelope>
\`\`\`

### XML Parsing Implementation

**Library:** fast-xml-parser 4.3.0

\`\`\`typescript
import { XMLParser } from 'fast-xml-parser';

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  parseAttributeValue: true
});

// Function 10: parseAndTransformResponse
function parseSOAPResponse(xmlString: string): [Error | null, ${api.responseType} | null] {
  try {
    const parsed = parser.parse(xmlString);
    const response = parsed['soap:Envelope']['soap:Body']['ns:${api.operation}Response'];

    // Transform XML structure to JSON
    const result: ${api.responseType} = {
      ${api.responseFields.map(f => `${f.name}: response['ns:${f.name}']`).join(',\n      ')}
    };

    return [null, result];
  } catch (error) {
    return [new Error(\`XML parsing failed: \${error.message}\`), null];
  }
}
\`\`\`
  `;
}
```

#### 11-Function Flow Engine Implementation

```typescript
// Generate complete 11-function breakdown
function generate11FunctionFlowEngine(service: ServiceSpec, soapAPI?: SOAPAPISpec): FlowEngine {
  return {
    flowId: `${service.name}-flow`,
    version: "1",
    functions: [
      {
        sequence: 1,
        name: "extractBearerToken",
        purpose: "Extract JWT token from Authorization header",
        implementation: "handler.ts",
        codeSnippet: `
const token = event.headers?.Authorization?.replace('Bearer ', '');
if (!token) {
  return [new Error('Missing authorization token'), null];
}
        `.trim()
      },
      {
        sequence: 2,
        name: "validateToken",
        purpose: "Validate JWT token using common-lib/validate-token",
        implementation: "common-lib",
        module: "@project-name/common/auth/validate-token",
        codeSnippet: `
const [error, claims] = await validateToken(token);
if (error) {
  return [error, null];
}
        `.trim()
      },
      {
        sequence: 3,
        name: "checkUserPermissions",
        purpose: "Check user permissions using common-lib/entitlements (AppId 7454)",
        implementation: "common-lib",
        module: "@project-name/common/entitlements",
        codeSnippet: `
const [error, hasPermission] = await CheckUserPermissions(claims.userId, '${service.requiredPermission}');
if (error || !hasPermission) {
  return [new Error('Permission denied'), null];
}
        `.trim()
      },
      {
        sequence: 4,
        name: `validate${service.name}Request`,
        purpose: "Validate request input (business criteria)",
        implementation: "validation.helper.ts",
        codeSnippet: `
const [error, validatedInput] = validateRequestSchema(input);
if (error) {
  return [error, null];
}
        `.trim()
      },
      {
        sequence: 5,
        name: `load${soapAPI ? soapAPI.name : service.name}Configuration`,
        purpose: `Load ${soapAPI ? 'SOAP endpoint' : 'service'} config from Vault`,
        implementation: "config.helper.ts",
        module: "@project-name/common/vault",
        codeSnippet: `
const [error, config] = await getSecret('${soapAPI ? soapAPI.vaultKey : service.configKey}');
if (error) {
  return [error, null];
}
        `.trim()
      },
      {
        sequence: 6,
        name: "determineAsyncPattern",
        purpose: "CRITICAL: Decide if operation requires async pattern (>16s = async, <16s = sync)",
        implementation: "processor.ts",
        codeSnippet: `
const estimatedDuration = ${service.estimatedDuration || 15};
const useAsync = estimatedDuration > 16;

if (useAsync) {
  // Create operation-status entry
  const requestId = generateUUID();
  await createOperationStatus(requestId, 'IN_PROGRESS');

  // Invoke background Lambda asynchronously
  await invokeLambdaAsync('${service.name}-async-processor', { requestId, input });

  // Return 202 Accepted
  return [null, { requestId, status: 'IN_PROGRESS', statusUrl: \`/api/${service.name}/status/\${requestId}\` }];
}
// Continue with synchronous processing
        `.trim()
      },
      {
        sequence: 7,
        name: `retrieve${soapAPI ? soapAPI.name : service.name}Credentials`,
        purpose: `Retrieve ${soapAPI ? 'Basic Auth' : 'API'} credentials from Vault`,
        implementation: "auth.helper.ts",
        module: "@project-name/common/vault",
        codeSnippet: `
const [error, credentials] = await getSecret('${soapAPI ? soapAPI.credentialsKey : service.credentialsKey}');
if (error) {
  return [error, null];
}
        `.trim()
      },
      {
        sequence: 8,
        name: soapAPI ? `build${soapAPI.name}SOAPRequest` : `build${service.name}Request`,
        purpose: soapAPI
          ? "CRITICAL: Construct SOAP XML request envelope"
          : "CRITICAL: Construct REST JSON request",
        implementation: "request-builder.helper.ts",
        codeSnippet: soapAPI ? `
// SOAP Envelope Construction
function buildSOAPRequest(input: ${service.requestType}): string {
  return \`<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:ns="${soapAPI.namespace}">
  <soap:Header>
    <ns:AuthToken>\${credentials.basicAuth}</ns:AuthToken>
  </soap:Header>
  <soap:Body>
    <ns:${soapAPI.operation}>
      ${soapAPI.requestFields.map(f => `<ns:${f.name}>\${input.${f.name}}</ns:${f.name}>`).join('\n      ')}
    </ns:${soapAPI.operation}>
  </soap:Body>
</soap:Envelope>\`;
}
        `.trim() : `
// REST JSON Request
const request = {
  ${service.requestFields.map(f => `${f.name}: input.${f.name}`).join(',\n  ')}
};
        `.trim()
      },
      {
        sequence: 9,
        name: `invoke${soapAPI ? soapAPI.name : service.name}${soapAPI ? '' : 'Service'}`,
        purpose: `Invoke ${soapAPI ? 'SOAP endpoint' : 'REST API'} (${soapAPI ? '25s timeout, 3 retries' : '10s timeout, 3 retries'})`,
        implementation: "external-api.helper.ts",
        codeSnippet: soapAPI ? `
// SOAP API Call
const [error, response] = await httpClient.post(config.endpoint, soapRequest, {
  headers: {
    'Content-Type': 'text/xml',
    'SOAPAction': '${soapAPI.soapAction}'
  },
  timeout: 25000,
  retries: 3
});
        `.trim() : `
// REST API Call
const [error, response] = await httpClient.post(config.endpoint, request, {
  headers: {
    'Content-Type': 'application/json',
    'Authorization': \`Bearer \${credentials.token}\`
  },
  timeout: 10000,
  retries: 3
});
        `.trim()
      },
      {
        sequence: 10,
        name: "parseAndTransformResponse",
        purpose: soapAPI
          ? "CRITICAL: Parse SOAP XML response and transform to JSON"
          : "CRITICAL: Parse and validate REST JSON response",
        implementation: "response-parser.helper.ts",
        codeSnippet: soapAPI ? `
import { XMLParser } from 'fast-xml-parser';

const parser = new XMLParser({
  ignoreAttributes: false,
  parseAttributeValue: true
});

function parseSOAPResponse(xmlString: string): [Error | null, ${service.responseType} | null] {
  const parsed = parser.parse(xmlString);
  const response = parsed['soap:Envelope']['soap:Body']['ns:${soapAPI.operation}Response'];

  // XML → JSON transformation
  const result: ${service.responseType} = {
    ${soapAPI.responseFields.map(f => `${f.name}: response['ns:${f.name}']`).join(',\n    ')}
  };

  return [null, result];
}
        `.trim() : `
// REST JSON Response Validation
function parseRESTResponse(responseBody: any): [Error | null, ${service.responseType} | null] {
  if (!responseBody || typeof responseBody !== 'object') {
    return [new Error('Invalid response format'), null];
  }

  const result: ${service.responseType} = {
    ${service.responseFields.map(f => `${f.name}: responseBody.${f.name}`).join(',\n    ')}
  };

  return [null, result];
}
        `.trim()
      },
      {
        sequence: 11,
        name: "formatSuccessResponse",
        purpose: "Format final response for API Gateway",
        implementation: "handler.ts",
        codeSnippet: `
return {
  statusCode: 200,
  body: JSON.stringify({
    success: true,
    data: result,
    timestamp: new Date().toISOString()
  }),
  headers: {
    'Content-Type': 'application/json',
    'X-Correlation-Id': correlationId
  }
};
        `.trim()
      }
    ]
  };
}
```

#### Rules-as-a-Service Implementation

```typescript
// Generate Rules-as-a-Service integration specification
function generateRulesServiceIntegration(service: ServiceSpec): string {
  return `
## 11. Validation Rules (Rules-as-a-Service)

### 11.1 Rules Service Integration

**Endpoint:** https://rules-service.example.com/validate
**Authentication:** Bearer token
**Timeout:** 5s
**Retries:** 2

**Request Format:**
\`\`\`typescript
interface ValidationRequest {
  entity: string;              // e.g., "producer", "policy"
  data: Record<string, any>;   // Entity data to validate
  ruleSet: string;             // e.g., "producer-validation-v1"
  context?: {                  // Optional context
    userId: string;
    timestamp: string;
  };
}
\`\`\`

**Response Format:**
\`\`\`typescript
interface ValidationResponse {
  valid: boolean;
  errors: Array<{
    field: string;
    code: string;
    message: string;
  }>;
  warnings: Array<{
    field: string;
    code: string;
    message: string;
  }>;
  metadata?: {
    ruleSetVersion: string;
    executionTimeMs: number;
  };
}
\`\`\`

### 11.2 Implementation

\`\`\`typescript
import { createRulesServiceClient } from '@project-name/common/rules-service';

const rulesClient = createRulesServiceClient({
  endpoint: process.env.RULES_SERVICE_ENDPOINT,
  timeout: 5000,
  retries: 2
});

async function validate${service.name}(data: ${service.requestType}): Promise<[Error | null, ValidationResponse | null]> {
  const request: ValidationRequest = {
    entity: '${service.entityType}',
    data: data,
    ruleSet: '${service.ruleSetId}'
  };

  const [error, response] = await rulesClient.validate(request);

  if (error) {
    // Fallback strategy: Log error and return generic validation error
    logger.error('Rules service unavailable', { error });
    return [null, {
      valid: false,
      errors: [{
        field: 'system',
        code: 'RULES_SERVICE_UNAVAILABLE',
        message: 'Validation service temporarily unavailable'
      }],
      warnings: []
    }];
  }

  return [null, response];
}
\`\`\`

### 11.3 Fallback Strategy

**When Rules Service Unavailable:**
1. Log error with correlation ID
2. Return validation error response
3. Alert operations team (if >5 consecutive failures)
4. **DO NOT:** Proceed without validation
5. **DO NOT:** Use embedded validation logic as fallback

### 11.4 NO Embedded Validation Logic

**CRITICAL:** This service MUST NOT contain embedded validation rules.

**Prohibited Patterns:**
- ❌ \`if (field.length < 3) return error\`
- ❌ \`function validateField(value) { ... }\`
- ❌ Hardcoded business rules

**Required Pattern:**
- ✅ \`const [error, validation] = await rulesClient.validate(...)\`
- ✅ All validation delegated to Rules-as-a-Service
  `;
}
```

---

## 3. Mandatory Pattern Implementations

### 3.1 Async Operations Pattern

See Section 2.2 for complete implementation.

### 3.2 SOAP Protocol Specification

See Section 2.2 for complete implementation.

### 3.3 11-Function Flow Engine Breakdown

See Section 2.2 for complete implementation.

### 3.4 Rules-as-a-Service Integration

See Section 2.2 for complete implementation.

### 3.5 Detailed Sequence Diagrams

```typescript
// Generate sync sequence diagram with all 11 functions
function generateSyncSequenceDiagram(service: ServiceSpec, flow: FlowEngine): string {
  return `
### Sync Sequence Diagram (All 11 Functions)

\`\`\`mermaid
sequenceDiagram
    participant Client
    participant APIGateway
    participant Lambda
    participant CommonLib
    participant ${flow.externalSystem || 'ExternalAPI'}
    participant RulesService
    participant Vault

    Client->>APIGateway: ${service.method} ${service.path}
    APIGateway->>Lambda: Invoke Handler

    Note over Lambda: Function 1: extractBearerToken
    Lambda->>Lambda: Extract JWT from Authorization header

    Note over Lambda,CommonLib: Function 2: validateToken
    Lambda->>CommonLib: validateToken(token)
    CommonLib-->>Lambda: [null, claims]

    Note over Lambda,CommonLib: Function 3: checkUserPermissions
    Lambda->>CommonLib: CheckUserPermissions(userId, permission)
    CommonLib-->>Lambda: [null, true]

    Note over Lambda: Function 4: validateRequest
    Lambda->>Lambda: Validate input schema

    Note over Lambda,Vault: Function 5: loadConfiguration
    Lambda->>Vault: getSecret('${service.configKey}')
    Vault-->>Lambda: [null, config]

    Note over Lambda: Function 6: determineAsyncPattern
    Lambda->>Lambda: estimatedDuration = ${service.estimatedDuration}s
    alt estimatedDuration <= 16s
        Lambda->>Lambda: Continue sync processing
    else estimatedDuration > 16s
        Lambda->>DynamoDB: Create operation-status entry
        Lambda->>BackgroundLambda: Invoke async
        Lambda-->>APIGateway: 202 Accepted {requestId, statusUrl}
        APIGateway-->>Client: 202 Accepted
    end

    Note over Lambda,Vault: Function 7: retrieveCredentials
    Lambda->>Vault: getSecret('${service.credentialsKey}')
    Vault-->>Lambda: [null, credentials]

    Note over Lambda: Function 8: buildRequest
    Lambda->>Lambda: ${flow.isSOAP ? 'Build SOAP envelope (XML)' : 'Build REST request (JSON)'}

    Note over Lambda,${flow.externalSystem}: Function 9: invokeService
    Lambda->>RulesService: validate(entity, data, ruleSet)
    RulesService-->>Lambda: [null, {valid: true}]
    Lambda->>${flow.externalSystem}: ${flow.isSOAP ? 'POST (SOAP over HTTPS)' : 'POST (REST JSON)'}
    ${flow.externalSystem}-->>Lambda: ${flow.isSOAP ? 'SOAP Response (XML)' : 'REST Response (JSON)'}

    Note over Lambda: Function 10: parseAndTransformResponse
    Lambda->>Lambda: ${flow.isSOAP ? 'Parse XML → JSON' : 'Parse and validate JSON'}

    Note over Lambda: Function 11: formatSuccessResponse
    Lambda->>Lambda: Format response for API Gateway
    Lambda-->>APIGateway: 200 OK {data}
    APIGateway-->>Client: 200 OK {data}
\`\`\`
  `;
}

// Generate async sequence diagram
function generateAsyncSequenceDiagram(service: ServiceSpec): string {
  return `
### Async Sequence Diagram (Background Processing)

\`\`\`mermaid
sequenceDiagram
    participant Client
    participant APIGateway
    participant SyncLambda
    participant DynamoDB
    participant AsyncLambda
    participant ExternalAPI

    Client->>APIGateway: POST /api/${service.name}/async
    APIGateway->>SyncLambda: Invoke

    Note over SyncLambda: Function 6: determineAsyncPattern
    SyncLambda->>SyncLambda: estimatedDuration > 16s → useAsync = true

    SyncLambda->>DynamoDB: PutItem (operation-status)
    Note right of DynamoDB: requestId: UUID<br/>status: IN_PROGRESS<br/>progress: 0

    SyncLambda->>AsyncLambda: InvokeAsync
    Note over AsyncLambda: Background Lambda invoked

    SyncLambda-->>APIGateway: 202 Accepted
    APIGateway-->>Client: 202 {requestId, statusUrl}

    Note over Client: Client polls status endpoint

    par Async Processing
        AsyncLambda->>ExternalAPI: ${service.externalCall}
        Note right of AsyncLambda: May take >16s

        loop Update Progress
            AsyncLambda->>DynamoDB: UpdateItem (progress)
            Note right of DynamoDB: status: IN_PROGRESS<br/>progress: 25/50/75
        end

        ExternalAPI-->>AsyncLambda: Response
        AsyncLambda->>AsyncLambda: Parse and transform
        AsyncLambda->>DynamoDB: UpdateItem (COMPLETED)
        Note right of DynamoDB: status: COMPLETED<br/>result: {data}<br/>progress: 100
    end

    loop Poll Status
        Client->>APIGateway: GET /api/${service.name}/status/{requestId}
        APIGateway->>SyncLambda: Invoke
        SyncLambda->>DynamoDB: GetItem (requestId)
        DynamoDB-->>SyncLambda: {status, progress, result}
        SyncLambda-->>APIGateway: 200 OK
        APIGateway-->>Client: {status, progress}
    end

    Note over Client: status = COMPLETED
    Client->>APIGateway: GET /api/${service.name}/status/{requestId}
    APIGateway->>SyncLambda: Invoke
    SyncLambda->>DynamoDB: GetItem (requestId)
    DynamoDB-->>SyncLambda: {status: COMPLETED, result}
    SyncLambda-->>APIGateway: 200 OK {result}
    APIGateway-->>Client: 200 OK {result}
\`\`\`
  `;
}
```

---

## 4. Large Document Handling

See Section 2.1 for complete implementation of Master TDD selective reading.

---

## 5. Sub-Agent Delegation

See Section 2.1 for complete implementation of context-rich delegation.

---

## 6. Anti-Pattern Validation

See Section 2.1 for complete implementation of 8 critical checks.

---

## 7. Tool Usage Patterns

### 7.1 Read Tool

```typescript
// Read FSD completely
Read({ file_path: "./requirements/feature-fsd.md" })

// Read Master TDD TOC only
Read({ file_path: "./master-tdd-full.md", limit: 150 })

// Read specific Master TDD section
Read({ file_path: "./master-tdd-full.md", offset: 200, limit: 200 })

// Read SOAP vs REST Endpoint Inventory
Read({ file_path: "./soap-rest-endpoint-inventory.yaml" })

// Read PDF FSD with visual content
Read({ file_path: "./requirements/feature-fsd.pdf" })
```

### 7.2 Write Tool

```typescript
// Write Service-TDD (ONE consolidated document for ALL services)
Write({
  file_path: "./output/client-info-Service-TDD.md",
  content: serviceTDDContent
})

// Write Integration-TDD (for SOAP systems)
Write({
  file_path: "./output/mdm-integration-Integration-TDD.md",
  content: integrationTDDContent
})

// Write UI-TDD
Write({
  file_path: "./output/client-info-UI-TDD.md",
  content: uiTDDContent
})
```

### 7.3 Grep Tool

```typescript
// Find async pattern in Master TDD
Grep({
  pattern: "Async Operations|Asynchronous|POST /async",
  path: "./master-tdd-full.md",
  output_mode: "content",
  "-n": true
})

// Find 11-function Flow Engine in Master TDD
Grep({
  pattern: "11-Function|Flow Engine|Function Breakdown",
  path: "./master-tdd-full.md",
  output_mode: "content",
  "-n": true
})

// Find SOAP protocol in Master TDD
Grep({
  pattern: "SOAP|Protocol Specification|SOAP Envelope",
  path: "./master-tdd-full.md",
  output_mode: "content",
  "-n": true
})

// Find Rules-as-a-Service in Master TDD
Grep({
  pattern: "Rules-as-a-Service|OPA|External Validation",
  path: "./master-tdd-full.md",
  output_mode: "content",
  "-n": true
})

// Find Anti-Patterns in Master TDD
Grep({
  pattern: "Anti-Pattern|ANTIPATTERN|8 Critical Checks",
  path: "./master-tdd-full.md",
  output_mode: "content",
  "-n": true
})
```

---

## 8. Error Handling

### 8.1 Error Types

| Error | Detection | Response | Recovery |
|-------|-----------|----------|----------|
| No FSD provided | Input empty | "Please provide FSD path or content" | Request FSD from user |
| Master TDD missing | File not found | "Master TDD required. Path: {expected}" | Request Master TDD path |
| SOAP vs REST Inventory missing | External APIs in FSD but no inventory | "STOP: Protocol inventory required for external APIs" | Request inventory from user |
| Async pattern missing | >16s operation but no async endpoints | Anti-pattern check #1 fails | Service-TDD designer agent must add async pattern |
| Protocol assumption | External API without explicit protocol | Anti-pattern check #5 fails | Service-TDD designer agent must check inventory |
| Embedded validation | Validation logic not using Rules-as-a-Service | Anti-pattern check #4 fails | Service-TDD designer agent must integrate Rules-as-a-Service |
| Missing 11 functions | Flow Engine without complete breakdown | Anti-pattern check #7 fails | Service-TDD designer agent must add all 11 functions |
| Wrong Lambda config | 512MB/16s instead of 1024MB/30s | Anti-pattern check #8 fails | Service-TDD designer agent must update config |

### 8.2 Anti-Pattern Validation Failure Response

```markdown
⚠️ **Anti-Pattern Validation Failed**

The generated TDD has critical issues that must be fixed before delivery:

**Failed Checks:**
❌ Check #4: No Embedded Validation Logic
   → FOUND: Embedded validation function `validateProducer`
   → REQUIRED: Rules-as-a-Service integration

❌ Check #8: No Insufficient Lambda Config
   → FOUND: 512MB/16s configuration
   → REQUIRED: 1024MB/30s configuration

**Recovery:**
The designer agent will regenerate the TDD with corrections.

Please wait while I fix these issues...
```

---

## 9. Testing Implementation

### 9.1 Test Files

| Test File | HLR | Validates | Expected Keywords |
|-----------|-----|-----------|-------------------|
| `async_operations_pattern.test` | HLR-6 | Async endpoints, operation-status table, async sequence diagram for >16s operations | POST /async, GET /status, operation-status, requestId, IN_PROGRESS, COMPLETED, FAILED, background Lambda |
| `soap_protocol_specification.test` | HLR-7 | SOAP envelope structure, XML parsing, Function 8, Function 10, NO REST assumption | SOAP over HTTPS, SOAP Envelope, fast-xml-parser, buildSOAPRequest, parseAndTransformResponse, XML, Basic Auth |
| `flow_engine_11_function_breakdown.test` | HLR-8 | All 11 functions specified, Functions 6/8/10 detailed | 11 functions, extractBearerToken, validateToken, checkUserPermissions, validateRequest, loadConfiguration, determineAsyncPattern, retrieveCredentials, buildRequest, invokeService, parseAndTransformResponse, formatSuccessResponse |
| `rules_as_service_validation.test` | HLR-2 | Rules-as-a-Service integration, NO embedded validation | Rules-as-a-Service, rulesServiceClient, external validation, NO embedded, fallback strategy |
| `detailed_sequence_diagrams.test` | HLR-9 | Sync + async sequence diagrams, 11 functions labeled, SOAP/REST indicators | sequenceDiagram, all 11 functions, POST /async, operation-status, SOAP over HTTPS, Rules-as-a-Service |
| `anti_pattern_validation.test` | HLR-10 | All 8 anti-pattern checks documented and passed | 8 checks, No Synchronous Calls, No Hardcoded Endpoints, No Try-Catch, No Embedded Validation, No Protocol Assumption, No Schema Generation, No Missing Functions, No Insufficient Config |
| `lambda_configuration_standards.test` | HLR-11 | Lambda config 1024MB/30s | 1024MB, 30s, NOT 512MB, NOT 16s |

### 9.2 Test Execution

```bash
# Run all tests for design-agent
python evaluation/evaluate_plugins.py --plugin design-agent

# Run specific HLR test
python evaluation/evaluate_plugins.py --plugin design-agent --test async_operations_pattern

# Fast iteration (no scoring)
python evaluation/evaluate_plugins.py --plugin design-agent --no-scoring

# Debug mode
python evaluation/evaluate_plugins.py --plugin design-agent --debug
```

---

## Revision History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Nov 24, 2025 | Initial LLD |
| 2.0 | Nov 25, 2025 | Document structure updates, large document handling |
| 3.0 | Dec 8, 2025 | **MAJOR UPDATE:** Master TDD selective reading implementation, async operations implementation, SOAP protocol implementation, 11-function Flow Engine implementation, Rules-as-a-Service implementation, detailed sequence diagram generation, anti-pattern validation implementation, Service-TDD consolidation (ONE document for ALL services, NOT per-service), Integration-TDD for SOAP, Lambda config 1024MB/30s, complete error handling |
| 1.2 | 2025-12-19 | AI COE Team | Version bump for plugin bundle release v1.2.0 |
| 1.3 | 2026-01-09 | AI COE Team | Version bump for release v1.3.0 |
| 1.4 | 2026-01-21 | AI COE Team | Version bump for unified release v1.4.0 |

---

**Document Owner:** AI COE Team & S3 Team
**Last Updated:** December 8, 2025
**Aligned With:** design-agent-brd.md (v5.0), design-agent-hld.md (v6.0), output/review-feedback.md, output/assessment-report.md
