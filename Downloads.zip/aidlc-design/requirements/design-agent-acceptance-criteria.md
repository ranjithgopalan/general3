# Acceptance Criteria: AIDLC-design (Design Agent)

- **Document Version:** 1.2
- **Date:** 2025-12-18
- **Author:** AI COE Team
- **Plugin:** AIDLC-design
- **Status:** Released

---

## 1. Overview

This document defines the acceptance criteria for the AIDLC-design plugin, which generates technical design documents (Service-TDD, UI-TDD) from Master TDD and Feature Specification Documents.

---

## 2. High-Level Requirements (HLR)

### HLR-1: Cross-Field Validation in UI-TDD
**Requirement:** For UI component designs, specifications must include client-side validation rules that account for cross-field dependencies and relationships with other UI inputs within the component or form.

**Test:** `ui_tdd_cross_field_validation.test`

---

### HLR-2: Server-Side Validation in Services-TDD (Rules-as-a-Service)
**Requirement:** When generating specifications for Lambda functions, the documents must specify integration with Rules-as-a-Service API for validation. NO embedded validation logic is permitted. Documents must include Rules-as-a-Service endpoint, request/response format, and fallback strategies.

**Test:** `services_tdd_rules_as_service_validation.test`

---

### HLR-3: Complete Data Flow Documentation
**Requirement:** Given feature requirements, when the plugin creates design specifications, then it must document the complete data flow: UI captures user data and loads the POM, external APIs are called to enrich the POM, the combined UI-captured data and enriched POM data is stored to DynamoDB, and after business criteria are met, the data from DynamoDB is persisted to PostgreSQL.

**Test:** `complete_data_flow.test`

---

### HLR-4: POM Subsection Focus
**Requirement:** Given a Feature Specification Document (FSD) as input, when the plugin creates design specifications for a feature or workflow, then it should understand the Policy Object Model (POM) data structure and identify which subsection of the POM is relevant to focus on, rather than including the entire POM.

**Test:** `pom_subsection_focus.test`

---

### HLR-5: Master TDD-Driven Design
**Requirement:** Given Master TDD (which covers feature-level architecture) and Feature Specification Document (FSD), when the plugin generates design specifications, then it must use Master TDD patterns as source of truth and generate the final TDD: (1) Service-TDD (ONE consolidated document for ALL backend services), (2) UI-TDD.

**Test:** `master_tdd_driven_design.test`

---

### HLR-6: Async Operations Pattern (Mandatory for >16s)
**Requirement:** When generating Services-TDD, agent must identify ALL operations that may take >16 seconds and specify complete async pattern including: (1) POST /api/{service}/async endpoint returning 202 with requestId, (2) GET /api/{service}/status/{requestId} polling endpoint, (3) operation-status DynamoDB table with complete schema, (4) async sequence diagram showing background processing.

**Test:** `async_operations_pattern.test`

---

### HLR-7: SOAP vs REST Protocol Specification (NO Assumptions)
**Requirement:** When generating Services-TDD for external API integrations, agent must check SOAP vs REST Endpoint Inventory and explicitly specify protocol. For SOAP: include SOAP envelope structure, XML parsing approach, Function 8 (buildSOAPRequest), Function 10 (parseAndTransformResponse). Agent must NEVER assume REST protocol.

**Test:** `soap_protocol_specification.test`

---

### HLR-8: Complete 11-Function Flow Engine Breakdown
**Requirement:** When generating Services-TDD for services using Flow Engine, agent must specify ALL 11 functions with complete breakdown including: Function 1 (extractBearerToken), Function 2 (validateToken), Function 3 (checkUserPermissions), Function 4 (validateRequest), Function 5 (loadConfiguration), Function 6 (determineAsyncPattern - CRITICAL), Function 7 (retrieveCredentials), Function 8 (buildRequest - CRITICAL), Function 9 (invokeService), Function 10 (parseAndTransformResponse - CRITICAL), Function 11 (formatSuccessResponse).

**Test:** `flow_engine_11_function_breakdown.test`

---

### HLR-9: Detailed Sequence Diagrams
**Requirement:** When generating Services-TDD, agent must create detailed sequence diagrams showing: (1) Sync sequence with all 11 Flow Engine functions labeled, (2) Async sequence with background Lambda invocation and polling pattern, (3) SOAP/REST protocol indicators, (4) Rules-as-a-Service API calls, (5) operation-status table interactions.

**Test:** `detailed_sequence_diagrams.test`

---

### HLR-10: Anti-Pattern Validation (8 Critical Checks)
**Requirement:** Before generating any Services-TDD output, agent must validate against 8 critical anti-patterns: (1) No synchronous calls for >16s operations, (2) No hardcoded endpoints, (3) No try-catch blocks (use go-style [error, result]), (4) No embedded validation logic (use Rules-as-a-Service), (5) No protocol assumption (explicit SOAP or REST), (6) No schema generation for relational DBs, (7) No missing Flow Engine functions, (8) No insufficient Lambda config (must be 1024MB/30s).

**Test:** `anti_pattern_validation.test`

---

### HLR-11: Lambda Configuration Standards
**Requirement:** When generating Services-TDD, agent must specify Lambda configuration as Memory: 1024MB, Timeout: 30s (NOT 512MB/16s) to support SOAP processing and async patterns.

**Test:** `lambda_configuration_standards.test`

---

## 3. Command-Specific Criteria

### Service-TDD Generation (`/design-agent:services-tdd`)
- Generates Service-TDD (ONE consolidated document for ALL backend services)
- Includes complete async patterns (POST /async, GET /status, operation-status table) for >16s operations
- Specifies SOAP or REST protocols explicitly (from Endpoint Inventory, NO assumptions)
- Includes complete 11-function Flow Engine breakdown with Functions 6/8/10 detailed
- Integrates Rules-as-a-Service for validation (NO embedded validation logic)
- Includes sync + async sequence diagrams with all 11 functions, SOAP/REST indicators
- Specifies Lambda config: 1024MB/30s
- Runs 8 anti-pattern validation checks before output
- Output is for nodejs-pair-programmer code generation

**Test:** `services_tdd_generation.test`

### UI-TDD Generation (`/design-agent:ui-tdd`)
- Generates UI-TDD with detailed component specifications for axis-tools
- Documents inputs/outputs with TypeScript types
- Includes form validators and cross-field validators (HLR-1)
- Maps to POM when provided (instruction-driven)
- Includes state management strategy (Signals/NgRx/Services)
- Documents component communication patterns
- Output is for axis-tools code generation

**Test:** `ui_tdd_generation.test`

### Validate Coverage (`/design-agent:validate-coverage`)
- Validates 100% feature coverage
- Checks all features from FSD against design documents
- Reports coverage percentage
- Lists missing coverage by feature

**Test:** `validate_coverage.test`

---

## 4. Test Coverage Summary

| Test File | HLR Coverage | Description |
|-----------|--------------|-------------|
| ui_tdd_cross_field_validation.test | HLR-1 | Cross-field validation in UI-TDD |
| services_tdd_rules_as_service_validation.test | HLR-2 | Rules-as-a-Service validation in Services-TDD |
| complete_data_flow.test | HLR-3 | Data flow documentation |
| pom_subsection_focus.test | HLR-4 | POM subsection identification |
| master_tdd_driven_design.test | HLR-5 | Master TDD as source of truth (NO Feature-TDD) |
| async_operations_pattern.test | HLR-6 | Async pattern for >16s operations |
| soap_protocol_specification.test | HLR-7 | SOAP vs REST explicit specification |
| flow_engine_11_function_breakdown.test | HLR-8 | Complete 11-function Flow Engine breakdown |
| detailed_sequence_diagrams.test | HLR-9 | Detailed sync + async sequence diagrams |
| anti_pattern_validation.test | HLR-10 | 8 critical anti-pattern checks |
| lambda_configuration_standards.test | HLR-11 | Lambda config 1024MB/30s |
| services_tdd_generation.test | Command | Service-TDD generation |
| ui_tdd_generation.test | Command | UI-TDD generation for axis-tools |
| validate_coverage.test | Command | Coverage validation |

---

## 5. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Nov 2025 | AI COE | Initial acceptance criteria |
| 1.2 | Dec 2025 | AI COE | Synchronizing version numbers to line up with plugin bundle |
| 1.3 | 2026-01-09 | AI COE Team | Version bump for release v1.3.0 |
| 1.4 | 2026-01-21 | AI COE Team | Version bump for unified release v1.4.0 |
