# High-Level Design: Design Agent Plugin

**Plugin:** design-agent (AIDLC-design)
**Version:** 6.0
**Document Type:** High-Level Design (HLD)
**Status:** Draft
**Last Updated:** December 8, 2025

---

## 1. Overview

The **design-agent** plugin generates Technical Design Documents (TDDs) from Feature Specification Documents (FSD) and Master TDD. It creates implementation-ready specifications for code generation agents with MANDATORY async patterns, SOAP protocol specifications, complete 11-function Flow Engine breakdown, and Rules-as-a-Service integration.

### 1.1 Design Philosophy

```
┌───────────────────────────────────────────────────────────────┐
│                      Input Documents                           │
│                                                                │
│  Required for TDD Generation:                                  │
│  • Master TDD (Architecture Strategy & Mandatory Patterns)     │
│  • FSD (Feature Specification) - Markdown or PDF               │
│  • Common Library TDD (Shared Library Specifications)          │
│  • SOAP vs REST Endpoint Inventory (for integrations)          │
│                                                                │
│  Optional (Instruction-Driven):                                │
│  • BRD (Business Requirements)                                 │
│  • POM (Policy Object Model)                                   │
│  • Rules-as-a-Service API Specification                        │
└───────────────────────────────┬───────────────────────────────┘
                                │
                                ↓
           ┌────────────────────────────────────┐
           │      design-agent (router)          │
           │  Reads Master TDD, FSD, Inventory   │
           └────────────┬───────────────────────┘
                        │
         ┌──────────────┼──────────────┐
         ↓              ↓              ↓
   ┌─────────┐   ┌──────────┐   ┌─────────────┐
   │ UI-TDD  │   │ Service  │   │ Integration │
   │ Designer│   │ Feature  │   │ TDD         │
   │         │   │ TDD      │   │ Designer    │
   │         │   │ Designer │   │ (SOAP)      │
   └────┬────┘   └────┬─────┘   └──────┬──────┘
        │             │                 │
        ↓             ↓                 ↓
   axis-tools   nodejs-pair-      nodejs-pair-
   (Angular)    programmer         programmer
                (Lambda)           (SOAP/async)
```

### 1.2 Key Principles

| Principle | Description |
|-----------|-------------|
| **Master TDD as Source of Truth** | Master TDD contains mandatory patterns (async, SOAP, 11-function, Rules-as-a-Service) - agent does NOT create Feature-TDD |
| **Service-TDD Consolidation** | ONE document for ALL backend services (not separate per service) |
| **Integration TDD for SOAP** | Separate document for complex SOAP integrations |
| **Async Pattern Mandatory** | ALL operations >16s MUST use async pattern (POST /async, GET /status, operation-status table) |
| **Protocol Specification Mandatory** | NEVER assume REST - explicitly specify SOAP or REST from Endpoint Inventory |
| **11-Function Flow Engine** | Complete breakdown for ALL services using Flow Engine |
| **Rules-as-a-Service** | NO embedded validation logic - external validation API only |
| **Anti-Pattern Validation** | 8 critical checks before output generation |
| **Lambda Config Standards** | 1024MB/30s (NOT 512MB/16s) for SOAP/async support |

---

## 2. Architecture

### 2.1 Three-Tier Agent Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          Agent Architecture Pattern                          │
├─────────────────────────────────────────────────────────────────────────────┤
│  TIER 1: COMMAND (Prompt Enricher)                                          │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  /design command (commands/design.md)                                  │ │
│  │  - Takes $ARGUMENTS from user                                          │ │
│  │  - Enriches with FSD, Master TDD, inventory references                 │ │
│  │  - Invokes design-agent router via Task tool                           │ │
│  │  - NO routing logic (delegated to router)                              │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                    │                                         │
│                                    ▼                                         │
│  TIER 2: ROUTER (Context Engineering + Orchestration)                       │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  design-agent.md (agents/design-agent.md)                              │ │
│  │  Context Engineering:                                                  │ │
│  │  - Read Master TDD selectively for mandatory patterns                  │ │
│  │  - Read FSD completely for requirements                                │ │
│  │  - Check SOAP vs REST Endpoint Inventory                               │ │
│  │  - Read Common Library TDD selectively                                 │ │
│  │  - Discover output path                                                │ │
│  │                                                                        │ │
│  │  Orchestration:                                                        │ │
│  │  - Analyze design intent (UI-TDD vs Service-TDD vs Integration-TDD)    │ │
│  │  - Present design plan for user confirmation                           │ │
│  │  - Delegate to specialized designer agents                             │ │
│  │  - Run anti-pattern validation checks                                  │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                    │                                         │
│           ┌────────────────────────┼────────────────────────┐               │
│           ▼                        ▼                        ▼               │
│  TIER 3: SPECIALIZED AGENTS (Extended Thinking + TOON + Guardrails)        │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐            │
│  │ ui-tdd-designer  │ │ service-tdd-     │ │ integration-tdd- │            │
│  │                  │ │ designer         │ │ designer         │            │
│  │ UI-TDD specs     │ │ Service-TDD      │ │ Integration-TDD  │            │
│  │ for axis-tools   │ │ (ONE doc)        │ │ (SOAP systems)   │            │
│  │                  │ │ with async,SOAP, │ │ async,SOAP,11-fn │            │
│  │                  │ │ 11-function, OPA │ │ complete specs   │            │
│  └──────────────────┘ └──────────────────┘ └──────────────────┘            │
│                                                                              │
│  All agents: Extended thinking + TOON + Guardrails + Anti-Pattern Checks   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Agent Specifications

| Agent | Model | Purpose | Output | Mandatory Patterns |
|-------|-------|---------|--------|--------------------|
| **design-agent** | Sonnet | Orchestration, routing, anti-pattern validation | - | Master TDD reading, protocol checking |
| **ui-tdd-designer** | Sonnet | UI component specifications | `{feature}-UI-TDD.md` | Cross-field validation |
| **service-tdd-designer** | Sonnet | Backend service specifications (ONE consolidated doc for ALL services) | `{feature}-Service-TDD.md` | Async, SOAP, 11-function, Rules-as-a-Service, anti-patterns |
| **integration-tdd-designer** | Sonnet | Complex SOAP integration specifications | `{feature}-Integration-TDD.md` | Async, SOAP envelope, 11-function, anti-patterns |

---

## 3. Mandatory Patterns from Master TDD

### 3.1 Async Operations Pattern (>16s Operations)

**Requirement:** ALL operations that MAY take >16 seconds MUST use async pattern.

**Components:**
1. **Async Endpoint:** `POST /api/{service}/async`
   - Returns 202 Accepted with requestId
   - Writes job entry to operation-status DynamoDB table
   - Invokes background Lambda asynchronously

2. **Poll Endpoint:** `GET /api/{service}/status/{requestId}`
   - Returns current status (IN_PROGRESS, COMPLETED, FAILED)
   - Returns results when COMPLETED

3. **operation-status DynamoDB Table:**
   ```
   PK: requestId (UUID)
   Attributes:
     - operationType: string
     - status: IN_PROGRESS | COMPLETED | FAILED
     - progress: number (0-100)
     - result: JSON (when COMPLETED)
     - error: JSON (when FAILED)
     - ttl: number (expires after 24h)
   ```

4. **Async Sequence Diagram:** Shows background processing, polling pattern

**Example Operations Requiring Async:**
- MDM searches (SOAP) - may take >16s
- Complex data transformations
- Multi-step external API calls
- Large data processing

### 3.2 SOAP vs REST Protocol Specification

**Requirement:** NEVER assume REST protocol. Explicitly specify protocol from Endpoint Inventory.

**SOAP Integration Pattern:**
- **SOAP Envelope Structure:** Complete XML request envelope
- **XML Parsing Approach:** fast-xml-parser 4.3.0, XML→JSON transformation
- **Function 8:** buildSOAPRequest (construct XML envelope)
- **Function 10:** parseAndTransformResponse (XML→JSON)
- **Authentication:** Basic Auth from Vault, TLS certificates

**REST Integration Pattern:**
- **JSON Schemas:** Complete request/response TypeScript interfaces
- **Content-Type:** application/json
- **Authentication:** Bearer token, OAuth 2.0

### 3.3 Complete 11-Function Flow Engine Breakdown

**Requirement:** ALL services using Flow Engine MUST specify ALL 11 functions.

**Standard 11-Function Template:**
```json
{
  "flowId": "{service-flow-id}",
  "version": "1",
  "functions": [
    { "sequence": 1, "name": "extractBearerToken", "purpose": "Extract JWT token" },
    { "sequence": 2, "name": "validateToken", "purpose": "Validate JWT token" },
    { "sequence": 3, "name": "checkUserPermissions", "purpose": "Check permissions" },
    { "sequence": 4, "name": "validateRequest", "purpose": "Validate request input" },
    { "sequence": 5, "name": "loadConfiguration", "purpose": "Load config from Vault" },
    { "sequence": 6, "name": "determineAsyncPattern", "purpose": "CRITICAL: Async vs sync decision" },
    { "sequence": 7, "name": "retrieveCredentials", "purpose": "Get credentials from Vault" },
    { "sequence": 8, "name": "buildRequest", "purpose": "CRITICAL: Construct SOAP/REST request" },
    { "sequence": 9, "name": "invokeService", "purpose": "Call external service" },
    { "sequence": 10, "name": "parseAndTransformResponse", "purpose": "CRITICAL: Parse XML/JSON response" },
    { "sequence": 11, "name": "formatSuccessResponse", "purpose": "Format final response" }
  ]
}
```

**CRITICAL Functions:**
- **Function 6:** determineAsyncPattern - Decision logic for >16s operations
- **Function 8:** buildRequest - SOAP envelope construction or REST JSON
- **Function 10:** parseAndTransformResponse - XML→JSON or JSON→JSON transformation

### 3.4 Rules-as-a-Service Integration

**Requirement:** Validation logic MUST call external Rules-as-a-Service API. NO embedded validation.

**Integration Pattern:**
```typescript
// NO embedded validation logic - call Rules API
async function validate(data: any): Promise<ValidationResult> {
  const rulesRequest = {
    entity: 'entity-type',
    data: data,
    ruleSet: 'validation-rules-v1'
  };

  const [error, result] = await rulesServiceClient.validate(rulesRequest);
  if (error) {
    // Handle Rules service unavailability
    return { valid: false, errors: ['Validation service unavailable'] };
  }
  return result;
}
```

**Documentation Format:**
- **Endpoint:** https://rules-service.example.com/validate
- **Authentication:** Bearer token
- **Request/Response Format:** Complete TypeScript interfaces
- **Fallback Strategy:** Error handling when service unavailable

### 3.5 Detailed Sequence Diagrams

**Requirement:** Create detailed sequence diagrams showing:
1. Sync sequence with all 11 Flow Engine functions labeled
2. Async sequence with background Lambda invocation and polling pattern
3. SOAP/REST protocol indicators
4. Rules-as-a-Service API calls
5. operation-status table interactions

### 3.6 Anti-Pattern Validation (8 Critical Checks)

**Requirement:** Before generating output, validate against 8 critical anti-patterns.

**8 Critical Checks:**
1. ✅ **No Synchronous Calls for >16s Operations** - Async pattern specified
2. ✅ **No Hardcoded Endpoints** - Retrieved from configuration/Vault
3. ✅ **No Try-Catch Blocks** - Go-style [error, result] pattern
4. ✅ **No Embedded Validation Logic** - Rules-as-a-Service integration
5. ✅ **No Protocol Assumption** - Explicit SOAP or REST from inventory
6. ✅ **No Schema Generation for Relational DBs** - PostgreSQL usage documented only
7. ✅ **No Missing Flow Engine Functions** - All 11 functions specified
8. ✅ **No Insufficient Lambda Config** - 1024MB/30s configuration

**If ANY check fails:** STOP and FIX before proceeding.

### 3.7 Lambda Configuration Standards

**Requirement:** Lambda config MUST be 1024MB/30s (NOT 512MB/16s).

**Rationale:**
- SOAP XML parsing requires more memory
- Async pattern needs adequate timeout
- Complex transformations need sufficient resources

---

## 4. Large Document Handling Strategy

### 4.1 Problem Statement

Enterprise input documents exceed Claude Code's token limits:
- `master-tdd-full.md`: ~41,000 tokens
- `common-library-tdd.md`: ~35,000 tokens
- Claude Code Read limit: ~25,000 tokens per operation

### 4.2 Solution: Selective Reading with Pattern Focus

```
┌─────────────────────────────────────────────────────────────┐
│            Master TDD Selective Reading Flow                 │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Step 1: Read Table of Contents (first 150 lines)           │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ Read(file_path="master-tdd-full.md", limit=150)        │ │
│  │ Parse section index for mandatory patterns              │ │
│  └────────────────────────────────────────────────────────┘ │
│                           │                                  │
│                           ↓                                  │
│  Step 2: Grep for MANDATORY Pattern Sections                │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ Grep("Async Operations|Asynchronous")                  │ │
│  │ Grep("11-Function|Flow Engine")                        │ │
│  │ Grep("SOAP|Protocol Specification")                    │ │
│  │ Grep("Rules-as-a-Service|OPA")                         │ │
│  │ Grep("Anti-Pattern|ANTIPATTERN")                       │ │
│  │ Grep("Lambda Configuration")                           │ │
│  └────────────────────────────────────────────────────────┘ │
│                           │                                  │
│                           ↓                                  │
│  Step 3: Read Mandatory Pattern Sections                    │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ Read(offset=async_line, limit=200)                     │ │
│  │ Read(offset=flow_engine_line, limit=150)               │ │
│  │ Read(offset=soap_line, limit=150)                      │ │
│  │ Read(offset=rules_line, limit=100)                     │ │
│  │ Read(offset=antipattern_line, limit=100)               │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### 4.3 Mandatory Sections to Read from Master TDD

| Section | Purpose | Typical Length |
|---------|---------|----------------|
| **Async Operations Pattern** | >16s operations, async endpoints, operation-status table | ~200 lines |
| **11-Function Flow Engine Breakdown** | Complete function list, Functions 6/8/10 details | ~150 lines |
| **SOAP vs REST Protocol Specifications** | SOAP envelope, XML parsing, REST JSON schemas | ~150 lines |
| **Rules-as-a-Service Integration** | External validation API, request/response format | ~100 lines |
| **Anti-Patterns** | 8 critical checks with examples | ~100 lines |
| **Lambda Configuration** | 1024MB/30s standards | ~50 lines |

---

## 5. Document Types and Structure

### 5.1 Service-TDD (Consolidated Backend Services)

**File:** `{feature-name}-Service-TDD.md`

**Purpose:** ONE consolidated document for ALL backend services in the feature

**Consumer:** nodejs-pair-programmer (Lambda code generation)

**Key Sections:**
1. Feature Overview (scope, services list)
2. **Async Operations** (POST /async, GET /status, operation-status table for >16s services)
3. **Protocol Specifications** (SOAP envelope structures, REST JSON schemas)
4. **11-Function Flow Engine Breakdown** (all services using Flow Engine)
5. **Rules-as-a-Service Integration** (validation API, NO embedded rules)
6. Service Architecture (ALL services: handler→processor→helpers for each)
7. API Specifications (endpoints, request/response)
8. Database Operations (DynamoDB, PostgreSQL usage documentation)
9. **Detailed Sequence Diagrams** (sync + async with all 11 functions, SOAP/REST indicators)
10. Error Handling (go-style [error, result] pattern)
11. Testing Strategy (>80% coverage)
12. Environment Variables
13. **Anti-Pattern Validation Checklist** (8 checks passed)
14. Lambda Configuration (1024MB/30s)

### 5.2 Integration TDD (Complex SOAP Systems)

**File:** `{feature-name}-Integration-TDD.md`

**Purpose:** Separate document for complex external SOAP integrations

**Consumer:** nodejs-pair-programmer (SOAP Lambda code generation)

**Key Sections:**
1. Integration Overview (SOAP system description)
2. **SOAP Protocol Specification** (endpoint, operation, WSDL reference)
3. **SOAP Envelope Structure** (complete XML request envelope)
4. **XML Parsing Approach** (fast-xml-parser, XML→JSON transformation)
5. **11-Function Flow Engine Breakdown** (Functions 8 and 10 detailed)
6. **Async Pattern** (if operations >16s)
7. Authentication (Basic Auth from Vault, TLS certificates)
8. **Detailed Sequence Diagrams** (SOAP request/response flow)
9. Error Handling (SOAP faults, go-style pattern)
10. Testing Strategy (SOAP mocking)
11. **Anti-Pattern Validation Checklist**
12. Lambda Configuration (1024MB/30s)

### 5.3 UI-TDD (Component Specifications)

**File:** `{feature-name}-UI-TDD.md`

**Purpose:** Component specifications for axis-tools Angular code generation

**Consumer:** axis-tools (Angular code generation)

**Key Sections:**
1. Component Specifications (inputs, outputs, methods)
2. State Management Details (signals, computed, effects)
3. Form Specifications (controls, validators, **cross-field validators**)
4. POM Mappings (if POM provided)
5. API Integration (service dependencies)
6. Template Specifications (layout, conditionals)
7. Accessibility Requirements
8. Error Handling

---

## 6. Command Structure

### 6.1 Unified Command

```
/design [natural language request]
```

**Command acts as Prompt Enricher:**
- Enriches user input with Master TDD, FSD, Endpoint Inventory references
- Invokes design-agent router via Task tool
- Contains NO routing logic (delegated to router)

### 6.2 Routing Logic (Handled by Router)

| User Intent | Trigger Keywords | Routed To | Output |
|-------------|------------------|-----------|--------|
| Service-TDD | "Service-TDD", "Lambda TDD", "backend services" | service-tdd-designer | `{feature}-Service-TDD.md` |
| Integration-TDD | "Integration-TDD", "SOAP integration", "external system" | integration-tdd-designer | `{feature}-Integration-TDD.md` |
| UI-TDD | "UI-TDD", "component specs", "axis-tools" | ui-tdd-designer | `{feature}-UI-TDD.md` |
| Coverage | "validate", "coverage", "check" | Direct handling | Coverage report |

---

## 7. Integration Points

### 7.1 Upstream (Inputs)

| Source | Document | Required | Key Content |
|--------|----------|----------|-------------|
| tech-architect | Master TDD | **YES** | Async patterns, SOAP specs, 11-function, Rules-as-a-Service, anti-patterns (Feature-level architecture - agent does NOT generate separate Feature-TDD) |
| product-owner | FSD | **YES** | Requirements, business logic, operations duration |
| tech-architect | Common Library TDD | **YES** | Flow Engine, Validate Token, integration patterns |
| tech-architect | SOAP vs REST Endpoint Inventory | **YES (for integrations)** | Protocol list per external API |
| architecture | POM | Optional | Field mappings (instruction-driven) |
| security | Rules-as-a-Service API Spec | Optional | Validation endpoint, request/response format |

### 7.2 Downstream (Consumers)

| Consumer | Document | Purpose |
|----------|----------|---------|
| nodejs-pair-programmer | Service-TDD | Lambda code generation with async, SOAP, 11-function, Rules-as-a-Service |
| nodejs-pair-programmer | Integration-TDD | SOAP integration Lambda code generation |
| axis-tools | UI-TDD | Angular component code generation |

---

## 8. HLR Mapping

| HLR | Requirement | Where Addressed |
|-----|-------------|-----------------|
| HLR-1 | Client-side validation (cross-field) | UI-TDD - Form Specifications |
| HLR-2 | Server-side validation (Rules-as-a-Service) | Service-TDD - Rules-as-a-Service Integration |
| HLR-3 | Complete data flow | Service-TDD - Data Flow section |
| HLR-4 | POM subsection focus | ui-tdd-designer / service-tdd-designer (instruction-driven) |
| HLR-5 | Master TDD-driven design | All TDD generation from Master TDD patterns (NO Feature-TDD generation) |
| HLR-6 | Async pattern (>16s mandatory) | Service-TDD - Async Operations |
| HLR-7 | SOAP vs REST explicit specification | Service-TDD / Integration-TDD - Protocol Specifications |
| HLR-8 | 11-function Flow Engine breakdown | Service-TDD / Integration-TDD - Flow Engine section |
| HLR-9 | Detailed sequence diagrams | Service-TDD / Integration-TDD - Sequence Diagrams |
| HLR-10 | Anti-pattern validation (8 checks) | Service-TDD / Integration-TDD - Anti-Pattern Checklist |
| HLR-11 | Lambda config 1024MB/30s | Service-TDD / Integration-TDD - Lambda Configuration |

---

## 9. Key Design Decisions

| Decision | Rationale | Review Feedback Reference |
|----------|-----------|---------------------------|
| **Master TDD as source of truth** | Agent does NOT create Feature-TDD; Master TDD contains architecture | Action Item #5, Key Decision #6 |
| **Service-TDD consolidation** | ONE document for ALL backend services (not per-service) | Key Decision #6 |
| **Integration TDD for SOAP** | Separate document for complex SOAP integrations | Key Decision #3 |
| **Async pattern mandatory** | >16s operations MUST use async (POST /async, GET /status, operation-status table) | Action Items #7, #10, Key Decision #2 |
| **Protocol specification mandatory** | NEVER assume REST - check SOAP vs REST Endpoint Inventory | Action Items #4, #5, Key Decision #3 |
| **11-function Flow Engine complete** | ALL 11 functions specified, Functions 6/8/10 detailed | Action Item #8, Key Decision #4 |
| **Rules-as-a-Service integration** | NO embedded validation logic - external validation API only | Action Item #11, Key Decision #1 |
| **Anti-pattern validation** | 8 critical checks before output generation | Key Decision #7, Risk #1-#3 |
| **Lambda config 1024MB/30s** | SOAP processing and async pattern support require adequate resources | Assessment Report Gap |
| **Selective reading for large docs** | Master TDD (41K) and Common Library TDD (35K) exceed token limits | Existing pattern |

---

## 10. Quality Metrics

| Metric | Target | Source |
|--------|--------|--------|
| **Master TDD Compliance** | 100% | All 6 mandatory patterns included |
| **Async Pattern Coverage** | 100% | All >16s operations use async pattern |
| **Protocol Specification Accuracy** | 100% | No REST assumptions, explicit from inventory |
| **11-Function Completeness** | 100% | All 11 functions specified if using Flow Engine |
| **Anti-Pattern Check Pass Rate** | 100% | All 8 checks passed before output |
| **Hallucination Risk** | <15% | Down from 60% through explicit protocol checking |
| **Lambda Code Generation Success** | >90% | nodejs-pair-programmer can generate without clarification |

---

## Revision History

| Version | Date | Changes |
|---------|------|---------|
| 4.0 | Nov 24, 2025 | Initial HLD for design-agent |
| 5.0 | Nov 25, 2025 | Document structure updates, large document handling |
| 6.0 | Dec 8, 2025 | **MAJOR UPDATE:** Master TDD as source of truth (NO Feature-TDD generation), Service-TDD consolidation (ONE document for ALL services), async patterns (>16s), SOAP vs REST explicit specification, 11-function Flow Engine complete breakdown, Rules-as-a-Service integration, anti-pattern validation (8 checks), Lambda config 1024MB/30s, detailed sequence diagrams, Integration-TDD for SOAP |
| 1.2 | 2025-12-19 | AI COE Team | Version bump for plugin bundle release v1.2.0 |
| 1.3 | 2026-01-09 | AI COE Team | Version bump for release v1.3.0 |
| 1.4 | 2026-01-21 | AI COE Team | Version bump for unified release v1.4.0 |

---

**Document Owner:** AI COE Team & S3 Team
**Last Updated:** December 8, 2025
**Aligned With:** output/review-feedback.md, output/assessment-report.md
