# Business Requirements Document: Design Agent Plugin

**Feature:** Claude Code Plugin for Technical Design Document Generation (Service-TDD with SOAP integrations, UI-TDD)

**User Story ID:** US-009

**Status:** Review Feedback Updated - Draft (Aligned with HLD v6.0 and LLD v3.0)

**Document Type:** Business Requirements Document (BRD)

**Version:** 1.2

---

## Executive Summary

This document defines the business requirements for the **design-agent** Claude Code plugin that creates specialized **TDD** (Technical Design Document) documents for code generation agents. The plugin uses a **three-tier agent architecture** (Command → Router → Specialized Designers) to orchestrate context engineering and generate implementation-ready specifications from Master TDD and Feature Specification Documents (FSD).

**Key Terminology Updates (Based on Review Feedback):**
- ~~Feature HLD~~ → **Feature-TDD** (High Level Technical Design Document) Don't generate if not required **As Master TDD (provided by tech-architect) covers feature-level architecture**
- ~~UI-LLD~~ → **UI-TDD** (UI Technical Design Document) - Component specifications for axis-tools
- ~~Services-LLD / API-LLD / per-service TDDs~~ → **Service-TDD** (Consolidated Technical Design Document for ALL backend services in ONE document, including SOAP integrations) - Lambda specifications for nodejs-pair-programmer

**Three-Tier Architecture:**
1. **Tier 1: Command** (`/design`) - Prompt enricher that ADLCs user context
2. **Tier 2: Router** (design-agent) - Context engineer that reads Master TDD selectively, checks protocols, runs anti-pattern validation, and orchestrates specialized designers
3. **Tier 3: Specialized Designers** (service-tdd-designer, ui-tdd-designer) - Generate TDD documents with mandatory patterns

---

### Key Changes Summary

| Change Area | Previous Approach | Updated Approach |
|-------------|-------------------|------------------|
| **Document Structure** | Service-TDD (includes SOAP integrations) + UI-TDD | Combined structure (no separate Integration-TDD) |
| **Master TDD Role** | Master TDD covers architecture; agent does NOT generate Feature-TDD | Eliminated redundancy, single source of truth |
| **Async Patterns** | Not specified (0% coverage) | Mandatory for >16s operations: async endpoint + poll endpoint + operation-status table (100% coverage) |
| **Protocol Specs** | Assumed REST (95% error rate) | Explicit SOAP vs REST from Endpoint Inventory (0% ambiguity) |
| **Flow Engine** | Generic mention | Complete 11-function breakdown with explicit specs for Functions 6, 8, 10 |
| **Sequence Diagrams** | Basic (4 diagrams, no detail) | Detailed sync+async with all 11 functions, SOAP/REST indicators (minimum 2 per Service-TDD) |
| **Lambda Config** | 512MB/16s (insufficient) | 1024MB/30s (correct for SOAP/async) |
| **Validation Logic** | Embedded in Lambda code | Rules-as-a-Service API integration |
| **PostgreSQL Schemas** | Agent generates DDL | Agent documents usage only (Data Architecture owns DDL) |
| **Anti-Pattern Checks** | None | 8 critical checks before output |
| **Overall Hallucination Risk** | 60% (HIGH) | Target <15% (LOW) |

### Key Decisions

| Decision | Rationale | Implementation |
|----------|-----------|----------------|
| **Rules as a Service (OPA)** | Validation logic lives externally; agent generates code that CALLS validation API | BR6: Rules-as-a-Service API Specification |
| **Async vs Sync Behavior** | Lambda endpoints return ASAP; long work handled asynchronously with job tracking | BR2: Async Operations Pattern (>16s) |
| **SOAP vs REST** | Never assume JSON/REST; each interface tagged and agent generates correct protocol | BR5: SOAP vs REST Endpoint Inventory |
| **Flow Engine Usage** | Execution driven by Flow Engine config in DynamoDB; agent generates 11-function breakdown | BR2: 11-Function Flow Engine Breakdown |
| **Schema Ownership** | Data Architecture owns relational schemas; agent documents usage only | BR15: Database Schema Specifications |
| **TDD Structure** | ONE Service-TDD (not separate per service); Master TDD covers architecture | BR1, BR8: Document Consolidation |
| **Anti-Patterns Check** | Agent scans output against anti-patterns before delivery | BR4: Anti-Pattern Validation |

### Design Document Hierarchy

```
┌───────────────────────────────────────────────────────────────┐
│                      Input Documents                           │
│                                                                │
│  Required for Feature TDD Generation:                          │
│  • FSD (Feature Specification) - Markdown or PDF               │
│  • Master TDD (Architecture Strategy & Standards)              │
│    - MUST include: Async patterns, 11-function flows,          │
│      SOAP/REST protocol specs, Rules-as-a-Service integration  │
│      Sequence diagrams with all functions, Anti-pattern checks │
│  • Common Library TDD (Shared Library Specifications)          │
│                                                                │
│  Optional (Instruction-Driven):                                │
│  • BRD (Business Requirements)                                 │
│  • POM (Policy Object Model)                                   │
└─────────────────────────────┬──────────────────────────────────┘
                              │
                              │
                   ┌──────────┴──────────┐
                   ↓                     ↓
        ┌────────────────┐      ┌────────────────────────┐
        │    UI-TDD      │      │      Services-TDD      │
        │                │      │   (combined service)   │
        │ Pattern:       │      │  Pattern:              │
        │ Component      │      │  Service TDD with:     │
        │ Specs with     │      │  • Async patterns      │
        │ validators     │      │  • SOAP envelope specs │
        │                │      │  • 11-function flow    │
        │                │      │  • Rules service calls │
        └────────┬───────┘      └──────────┬─────────────┘
                 ↓                         ↓
            axis-tools            nodejs-pair-programmer
             (Angular)                  (Lambda)
```

### Document Types

| Document | Purpose | Pattern | Audience |
|----------|---------|---------|----------|
| **Service-TDD** | ALL backend services in ONE document per feature | Consolidated service specs, System-level architecture covering ALL patterns (async, Flow Engine, protocols, anti-patterns) | nodejs-pair-programmer (Code Generation) |
| **UI-TDD** | Component specifications, form validators, state management, POM mappings | Component Specs | axis-tools (Code Generation) |

**IMPORTANT:** Master TDD already covers Feature-level architecture. Design agent does NOT generate separate Feature-TDD/HLD documents. It generates directly:
1. **Service-TDD** - ONE consolidated document for ALL backend services (includes SOAP integrations)
2. **UI-TDD** - Component specifications for frontend

---

## Business Objectives

### Primary Objective

**Enable technical teams** to generate comprehensive technical design documents (Service-TDD with SOAP integrations, UI-TDD) from Master TDD and Feature Specification Documents (FSD) using a three-tier orchestration architecture, reducing design documentation time by 70% while ensuring:
1. Complete Master TDD pattern compliance (100%) through selective reading (41K+ token documents)
2. Zero hallucination risk for coding agents through protocol verification, endpoint verification, and anti-pattern validation
3. Implementation readiness with all critical patterns (async >16s, SOAP envelope specs, complete 11-function Flow Engine, Rules-as-a-Service integration, Lambda config 1024MB/30s)
4. Efficient context engineering using Tier 1 (Command) → Tier 2 (Router) → Tier 3 (Designers) architecture

### Success Metrics

| Metric | Target | Measurement | Architecture Component |
|--------|--------|-------------|----------------------|
| **Service-TDD Generation Time** | <45 minutes | Time from Master TDD + FSD to complete Service-TDD (all backend services combined) | service-tdd-designer agent |
| **UI-TDD Generation Time** | <30 minutes | Time from Master TDD + FSD to complete UI-TDD | ui-tdd-designer agent |
| **Code Generation Success** | >90% | TDD specs successfully used by nodejs-pair-programmer and axis-tools with NO protocol errors, NO async omissions | Downstream consumers |
| **Master TDD Pattern Compliance** | 100% | All 6 mandatory patterns followed (async, SOAP, 11-function, Rules-as-a-Service, anti-patterns, Lambda config) | Router agent validation |
| **Hallucination Risk** | <15% | Protocol ambiguity, async pattern omission, flow engine mismatch, endpoint hallucination | Router agent protocol/endpoint verification |
| **Rework Rate** | <10% | TDDs requiring changes after implementation | Overall quality |
| **Async Pattern Coverage** | 100% | All operations >16s have complete async pattern (POST /async, GET /status, operation-status table, async sequence diagram) | service-tdd-designer pattern |
| **SOAP Protocol Accuracy** | 100% | Correct protocol specification (SOAP vs REST) with SOAP envelope structure, XML parsing for SOAP APIs | Router agent protocol verification |
| **11-Function Flow Completeness** | 100% | All Flow Engine integrations have complete 11-function breakdown with Functions 6/8/10 explicitly detailed | service-tdd-designer pattern |
| **Context Engineering Efficiency** | <5 seconds | Time to read Master TDD using selective reading (TOC + Grep + offset/limit) vs full read | Router agent selective reading |
| **Anti-Pattern Detection Rate** | 100% | All 8 critical anti-patterns detected before TDD output | Router agent validation |
| **Lambda Config Accuracy** | 100% | All Lambda specs use 1024MB/30s (NOT 512MB/16s) | service-tdd-designer pattern |

---

## Business Requirements

### BR1: Three-Tier Agent Architecture with Master TDD as Source of Truth

**Requirement:** The design agent implements a three-tier architecture to orchestrate TDD generation:

**Tier 1: Command Layer** (`/design` slash command)
- Acts as prompt enricher
- ADLCs user context and references to input documents
- Invokes Tier 2 (Router) via Task tool
- Contains NO routing logic (delegated to router)

**Tier 2: Router Layer** (design-agent.md)
- Context engineering responsibilities:
  - Read Master TDD selectively for mandatory patterns (async, SOAP, 11-function, Rules-as-a-Service, anti-patterns, Lambda config)
  - Read FSD completely for requirements and operation duration
  - Check SOAP vs REST Endpoint Inventory for protocol verification
  - Discover output path using three-tier discovery (document metadata → workspace structure → user prompt)
- Orchestration responsibilities:
  - Analyze design intent (Service-TDD vs UI-TDD)
  - Verify critical patterns (protocol specification, async operations >16s, Lambda config 1024MB/30s)
  - Present plan for user confirmation
  - Delegate to specialized designer agents with complete context
  - Run anti-pattern validation (8 checks) before delivery

**Tier 3: Specialized Designer Layer** (service-tdd-designer, ui-tdd-designer)
- service-tdd-designer: Generates Service-TDD (ONE consolidated document for ALL backend services including SOAP integrations) with mandatory patterns
- ui-tdd-designer: Generates UI-TDD with component specifications for axis-tools

**Master TDD Role:**
The Master TDD (provided by tech-architect) covers feature-level architecture. The design agent DOES NOT generate separate Feature-level TDD documents. Master TDD includes:
- Async patterns for long-running operations (>16s)
- 11-function Flow Engine breakdown patterns
- SOAP vs REST protocol specifications
- Rules-as-a-Service integration patterns
- Complete sequence diagrams with all functions
- Anti-pattern definitions and checks
- Lambda configuration standards (1024MB/30s)

**Business Value:**
- Efficient context engineering through selective reading (41K+ token documents)
- Zero hallucination risk through protocol/endpoint verification at router layer
- Consistent pattern enforcement through centralized anti-pattern validation
- Eliminates redundant Feature-level documentation, ensures single source of truth (Master TDD)

**Priority:** P0 (Critical)

**Key Decision:** Three-tier architecture enables separation of concerns: Command (ADLCing) → Router (context engineering + orchestration + validation) → Designers (generation)

---

### BR2: Master TDD Mandatory Patterns (Review Feedback Integration)

**Requirement:** When consuming Master TDD as input, the design agent MUST reference and implement ALL mandatory patterns:

1. **Async Operations Pattern** (>16s operations)
   - POST /api/service/async endpoints
   - GET /api/service/status/{requestId} polling endpoints
   - operation-status DynamoDB table with TTL
   - Async sequence diagrams with background processing

2. **11-Function Flow Engine Breakdown**
   - Function 1: extractBearerToken
   - Function 2: validateToken
   - Function 3: checkUserPermissions
   - Function 4: validate{Entity}Request
   - Function 5: load{System}Configuration
   - Function 6: determineAsyncPattern (>16s decision logic)
   - Function 7: retrieve{System}Credentials
   - Function 8: build{System}Request (SOAP/REST)
   - Function 9: invoke{System}Operation
   - Function 10: parseAndTransformResponse (XML/JSON)
   - Function 11: formatSuccessResponse

3. **Protocol Specifications (SOAP vs REST)**
   - Explicitly state protocol: "SOAP over HTTPS" or "REST API"
   - SOAP: Include XML envelope structure, parsing approach
   - REST: Include JSON request/response schemas
   - Never assume protocol - MUST be specified from SOAP vs REST Endpoint Inventory

4. **Rules-as-a-Service Integration**
   - Validation logic calls external Rules-as-a-Service API (OPA)
   - NO embedded validation rules in Lambda code
   - Specify Rules API endpoint, request/response format
   - Error handling for Rules service unavailability

5. **Lambda Configuration**
   - Memory: 1024MB (NOT 512MB) for SOAP processing
   - Timeout: 30s (NOT 16s) for async pattern support

**Router Implementation - Selective Reading Strategy:**

**Problem:** Master TDD (~41K tokens) and Common Library TDD (~35K tokens) exceed Claude Code's 25K token read limit.

**Solution:** Router agent uses three-phase selective reading:
1. **Phase 1 - TOC Discovery:** Read first 150 lines to get Table of Contents
2. **Phase 2 - Pattern Location:** Use Grep to find mandatory pattern sections (async, SOAP, 11-function, Rules-as-a-Service, anti-patterns, Lambda config)
3. **Phase 3 - Selective Reading:** Read specific sections using offset/limit (200-300 lines per pattern)

**Example Implementation:**
```typescript
// Phase 1: Read TOC
Read(file_path="master-tdd-full.md", limit=150)

// Phase 2: Grep for patterns
Grep(pattern="Async Operations|Asynchronous", path="master-tdd-full.md", "-n"=true)
Grep(pattern="11-Function|Flow Engine", path="master-tdd-full.md", "-n"=true)
Grep(pattern="SOAP|Protocol Specification", path="master-tdd-full.md", "-n"=true)

// Phase 3: Read specific sections
Read(file_path="master-tdd-full.md", offset=async_line, limit=200)
Read(file_path="master-tdd-full.md", offset=flow_engine_line, limit=150)
```

**Business Value:**
- Eliminates hallucination risk and ensures coding agents generate correct implementations (protocol, async, flow engine)
- Enables processing of enterprise-scale documentation without token limit failures
- Reduces context engineering time from minutes to <5 seconds

**Priority:** P0 (Critical)

**Required Inputs:**
- **Feature Specification Document (FSD)** - Required
  - Format: Markdown (.md) or PDF (.pdf)
  - Contains: Scope, Assumptions, Prerequisites, Business Requirements, Rules, Validation (functional & non-functional)
  - PDF may include: Screenshots, UI mockups, business process flow diagrams
- **Master TDD** - Required
  - Format: Markdown (.md)
  - Contains: Introduction, Architecture Overview, Service Library, Service Orchestration, Service Dependencies Matrix, Data Model, API Design, Backend Processing, Security Considerations
- **Common Library TDD** - Required
  - Format: Markdown (.md)
  - Contains: System Overview, Package Architecture, Technology Stack, Repository Structure, NPM Package Configuration, Module Specifications (Flow Engine, Validate Token, Entitlements, Vault Extension, etc.), Integration Patterns, Error Handling Strategy, Security Considerations, Performance Optimization, Monitoring and Logging, Testing Strategy, Deployment and Versioning

**Optional Inputs:**
- **BRD** (business context) - Optional
- **POM JSON/TypeScript structure** - Optional (instruction-driven)

**Outputs:**
- UI-TDD.md - UI component architecture
- Services-TDD.md - Backend services architecture

---

### BR3: Complete Sequence Diagrams (11-Function Detail)

**Requirement:** All Service-TDD documents MUST include detailed sequence diagrams showing:
1. All 11 functions in the Flow Engine execution order
2. SOAP or REST protocol interactions with XML/JSON indicators
3. Async decision branching (Function 6: determineAsyncPattern)
4. Background Lambda invocation for async operations
5. DynamoDB operation-status table interactions
6. Rules-as-a-Service API calls
7. Vault credential retrieval
8. MDM/RDM/external system interactions

**Diagram Requirements:**
- **Sync Sequence Diagram:** Shows all 11 functions in order, SOAP envelope building, XML parsing
- **Async Sequence Diagram:** Shows background processing, polling pattern, operation-status table
- **Service Integration Diagram:** Shows technology labels (SOAP, DynamoDB, Vault, PostgreSQL)

**Business Value:** Provides complete technical visibility, eliminates coding agent confusion about execution flow, reduces implementation errors by 50% (per assessment findings).

**Priority:** P0 (Critical)

**Validation:** Each Service-TDD must have minimum 2 sequence diagrams (sync + async) with all 11 functions labeled, including SOAP integration flows if applicable.

---

### BR4: Anti-Pattern Validation

**Requirement:** Design agent MUST validate generated TDD documents against Master TDD anti-patterns before output:

**Critical Anti-Patterns to Check:**
1. **No Synchronous Calls for >16s Operations** - Must use async pattern
2. **No Hardcoded Endpoints** - Must use configuration/Vault
3. **No Try-Catch Blocks** - Must use Go-style error handling `[error, result]`
4. **No Embedded Validation Logic** - Must call Rules-as-a-Service
5. **No Protocol Assumption** - Must explicitly specify SOAP or REST
6. **No Schema Generation for Relational DBs** - Data Architecture owns PostgreSQL schemas
7. **No Missing Flow Engine Functions** - Must have all 11 functions if using Flow Engine
8. **No Insufficient Lambda Config** - Must be 1024MB/30s for SOAP/async operations

**Process:**
1. After generating TDD, scan against anti-pattern list
2. Flag any violations with severity (CRITICAL, HIGH, MODERATE)
3. Auto-correct violations where possible
4. Warn user if manual correction needed

**Business Value:** Prevents common design errors, ensures enterprise pattern compliance, reduces rework by 30%.

**Priority:** P0 (Critical)

---

### BR5: SOAP vs REST Endpoint Inventory (External Input)

**Requirement:** When processing FSD for integration with external systems (MDM, RDM, etc.), design agent MUST:
1. Accept optional "SOAP vs REST Endpoint Inventory" document/list as input
2. Use inventory to explicitly specify protocol for each external API
3. If inventory not provided, WARN user and ask for protocol specification (DO NOT ASSUME REST)
4. Document protocol decision with rationale in TDD

**Endpoint Inventory Format:**
```yaml
external_apis:
  - name: MDM Producer Search
    protocol: SOAP
    endpoint: https://mdm-gateway-api-v1-uat.example.com
    operation: searchProducer

  - name: RDM Reference Data
    protocol: REST
    endpoint: https://rdm-api.example.com/v1
```

**Business Value:** Eliminates 95% protocol hallucination risk, ensures correct API integration patterns from design phase.

**Priority:** P0 (Critical)

---

### BR6: Rules-as-a-Service API Specification (External Input)

**Requirement:** Design agent MUST integrate external Rules-as-a-Service (OPA) instead of embedded validation logic:

**Required Specifications:**
1. Rules API endpoint URL pattern
2. Request format (JSON schema)
3. Response format (validation results)
4. Error handling for Rules service unavailability
5. Fallback validation strategy (if any)

**Integration Pattern in TDD:**
```typescript
// DO NOT generate embedded validation logic
// INSTEAD specify Rules-as-a-Service call:

async function validateProducer(producerData: Producer): Promise<ValidationResult> {
  const rulesRequest = {
    entity: 'producer',
    data: producerData,
    ruleSet: 'producer-validation-v1'
  };

  const [error, result] = await rulesServiceClient.validate(rulesRequest);
  if (error) {
    // Handle Rules service error
  }
  return result;
}
```

**Business Value:** Centralizes validation logic, enables non-technical updates to rules, separates policy from code, aligns with enterprise governance.

**Priority:** P1 (High)

---

### BR7: UI-TDD Component Architecture Focus

**Requirement:** UI-TDD documents focus on component specifications including component hierarchy, smart vs presentational components, state management strategy (signals, NgRx, services), data flow patterns, cross-cutting concerns (error handling, loading states), and POM field mappings.

**Business Value:** Provides implementation-ready Angular component specifications for axis-tools code generation.

**Priority:** P0 (Critical)

**Key Specifications:**
- Component Tree & Hierarchy with TypeScript interfaces
- State Management Strategy (Signals/NgRx)
- Data Flow Architecture
- Component Communication Patterns (Inputs/Outputs)
- Form Control Specifications with Validators
- Cross-Field Validation Rules
- POM Path Mappings (if POM provided)
- API Integration Points
- Accessibility Requirements (ARIA labels, keyboard navigation)

---

### BR8: Service-TDD Consolidation (Single Document for All Services)

**Requirement:** Design agent MUST generate ONE Service-TDD document that consolidates ALL backend services for a feature:

**Structure:**
```markdown
# {Feature-Name}-Service-TDD.md

## Section 1: Service Overview (all services)
## Section 2: Architecture & Service Integration Pattern
## Section 3: Sequence Diagrams (sync + async for ALL services)
## Section 4: API Specifications (ALL endpoints)
## Section 5: Async Operations Pattern (if >16s operations)
## Section 6: Integration Specifications (SOAP/REST, 11-functions)
## Section 7: Service Specifications
   ### 7.1 {Service-1-Name}
   ### 7.2 {Service-2-Name}
   ### 7.3 {Service-N-Name}
## Section 8: Data Model (DynamoDB + PostgreSQL)
## Section 9: Common Library Integration
## Section 10: Error Handling Strategy
## Section 11: Validation Rules (Rules-as-a-Service)
## Section 12: Traceability Matrix (FSD → Design)
```

**Business Value:** Prevents over-fragmentation, easier to maintain, better for parallel development teams.

**Priority:** P0 (Critical)

**Anti-Pattern:** DO NOT create separate TDD per service (e.g., service-1-TDD.md, service-2-TDD.md). Combine into ONE.

---

### BR9: SOAP Integration Specifications in Service-TDD (Consolidated)

**Requirement:** When FSD requires integration with complex external systems (SOAP, REST), all integration specifications are included within the Service-TDD document (NOT as separate Integration-TDD):

**Required When:**
- External API protocol is SOAP (not REST)
- Complex authentication (Vault, certificates)
- Multi-step integration workflows

**Content Requirements (within Service-TDD):**
- Complete protocol specifications (SOAP envelope structure, XML parsing for SOAP APIs)
- MDM/RDM endpoint URLs (actual, not placeholder)
- Credential retrieval specifications (Vault paths)
- 11-function Flow Engine breakdown for integration services
- Async patterns for >16s integration operations

**Business Value:** Consolidates all backend service specifications (including SOAP integrations) in ONE document, reduces hallucination risk, provides complete context for nodejs-pair-programmer.

**Priority:** P0 (Critical)

---

### BR10: UI-TDD Technical Specifications for Code Generation

**Requirement:** UI-TDD provides detailed component specifications enabling axis-tools to generate production-ready Angular code:

**Key Specifications:**
- Component TypeScript interfaces (inputs, outputs, state)
- Form control specifications with validators
- Cross-field validation rules (client-side)
- POM path mappings (if POM provided)
- Event handlers and outputs
- Template structure specifications
- Accessibility requirements (ARIA, keyboard navigation)
- API service integration specifications

**Business Value:** Enables axis-tools to generate production-ready Angular code without manual intervention.

**Priority:** P0 (Critical)

---

### BR11: Service-TDD Technical Specifications for Code Generation

**Requirement:** Service-TDD (Service-TDD) provides detailed Lambda specifications enabling nodejs-pair-programmer to generate production-ready code:

**Key Specifications:**
- API endpoint specifications with complete TypeScript schemas
- Lambda function specifications with three-layer architecture
- Server-side validation rules (Rules-as-a-Service integration)
- Database operation specifications (DynamoDB + PostgreSQL)
- Error handling with Go-style patterns `[error, result]`
- Async pattern specifications (if operations >16s)
- 11-function Flow Engine breakdown (if applicable)
- Protocol specifications (SOAP XML envelope, REST JSON)
- Common Library integration (Flow Engine, Validate Token, Entitlements, Vault)
- Complete sequence diagrams

**Business Value:** Enables nodejs-pair-programmer to generate production-ready Lambda code following enterprise patterns, eliminates protocol/async/flow engine hallucinations.

**Priority:** P0 (Critical)

---

### BR12: Complete Data Flow Documentation

**Requirement:** Both Service-TDD and UI-TDD include complete data flow documentation showing how data moves through the system: UI captures user data → API enrichment → POM integration → DynamoDB (working state) → PostgreSQL (final persistence).

**Business Value:** Provides end-to-end visibility, ensures data integrity across layers, supports troubleshooting.

**Priority:** P0 (Critical)

---

### BR13: POM Subsection Focus (Instruction-Driven)

**Requirement:** When user provides POM structure and explicitly requests field mappings, the plugin identifies which subsection of the Policy Object Model (POM) is relevant for each feature, rather than including the entire POM. UI-TDD clearly maps UI fields to POM paths.

**Business Value:** Reduces complexity, focuses on relevant data structures, improves specification clarity.

**Priority:** P1 (High) - Only when POM is provided

**Note:** This is an **instruction-driven capability**. The agent does not inherently process POM. When user provides POM and requests mappings, the UI-TDD includes field-to-POM-path mapping tables.

---

### BR14: Feature Coverage Validation

**Requirement:** Plugin validates that 100% of features from the FSD have corresponding TDD documents. Provides coverage report identifying:
- Which FSD requirements are covered by Service-TDD
- Which FSD requirements are covered by UI-TDD
- Which FSD requirements are covered by SOAP integration specifications within Service-TDD (if applicable)
- Any missing coverage gaps

**Validation Process:**
1. Extract all business requirements from FSD
2. Scan generated TDD documents for requirement references
3. Create traceability matrix: FSD Requirement ID → TDD Section
4. Flag any requirements with 0 references (missing coverage)
5. Generate coverage report with percentage

**Business Value:** Prevents missing functionality, ensures complete system design, provides audit trail for requirements.

**Priority:** P0 (Critical)

---

### BR15: Database Schema Specifications

**Requirement:** Service-TDD includes database schema specifications:

**DynamoDB Tables (Session & Working State):**
- operation-status (for async operations with TTL)
- ui-component-catalog (dynamic UI rendering)
- booking-reference-lookup (transient data)
- service-function-flows (Flow Engine configurations)

**PostgreSQL Tables (Policy Persistence):**
- Data Architecture team owns relational schemas
- Design agent documents existing schema usage
- **Agent MUST NOT generate PostgreSQL DDL** (anti-pattern check)
- Document table names, key fields, relationships only

**Business Value:** Provides infrastructure requirements, prevents schema generation anti-pattern, aligns with Data Architecture ownership.

**Priority:** P1 (High)

**Critical Note:** Agent documents PostgreSQL schema usage but does NOT generate CREATE TABLE statements (Data Architecture responsibility).

---

### BR16: Multi-Format Document Input Handling

**Requirement:** The plugin must handle input documents in multiple formats at runtime, automatically detecting and processing each format appropriately:

1. **Markdown Files (.md)**
   - Read directly as text
   - Parse headings, tables, code blocks
   - Extract structured content

2. **PDF Files (.pdf)**
   - Read using Claude Code's PDF reading capability
   - **Extract images/screenshots as visual content** (Claude Code reads PDFs page-by-page, extracting both text AND visual content)
   - Process business process flow diagrams visually
   - Extract text from structured sections

3. **Images in Documents**
   - Screenshots of UI mockups → Analyze visually for component identification
   - Business process flow diagrams → Understand workflow visually
   - Architecture diagrams → Extract system relationships

**Critical Implementation Note:**
- Claude Code **CAN read images embedded in PDFs** - it processes PDFs page by page, extracting both text and visual content for analysis
- When an FSD is provided as PDF with screenshots, the agent MUST read the PDF using the Read tool to see the visual content
- The agent should NOT attempt to extract only text from PDFs - it should read the full PDF to see images

**Business Value:** Supports real-world document formats where specifications often include visual elements (screenshots, diagrams) that are critical for accurate design generation.

**Priority:** P0 (Critical)

---

### BR17: Runtime Format Detection and Processing

**Requirement:** The plugin must dynamically detect input document formats at runtime and apply appropriate processing strategies without requiring explicit format specification from the user.

**Format Detection Logic:**
| File Extension | Detection | Processing Strategy |
|----------------|-----------|---------------------|
| `.md` | File extension | Read as markdown text |
| `.pdf` | File extension | Read with PDF reader (text + images) |
| No extension | Content analysis | Analyze first lines for format hints |
| Pasted content | Content structure | Parse as markdown/structured text |

**Business Value:** Reduces user friction, handles real-world document variety, enables seamless processing regardless of how specifications are provided.

**Priority:** P1 (High)

---

### BR18: Large Document Handling Strategy

**Requirement:** The plugin must handle large input documents (Master TDD, Common Library TDD) that exceed Claude Code's token limits (~25,000 tokens per read operation, ~40,000+ tokens for these documents).

**Problem Statement:**
- `master-tdd-full.md` is ~41,000 tokens
- `common-library-tdd.md` is ~35,000 tokens
- Claude Code's Read tool has a 25,000 token limit per operation
- Reading entire documents at once is not possible

**Strategy: Section-Based Selective Reading**

The agent must implement a **selective reading strategy** that extracts only the relevant sections needed for the current task:

**Phase 1: Document Structure Discovery**
```
1. Read first 100-200 lines to get Table of Contents
2. Parse section headings and line numbers
3. Build a section index map for navigation
```

**Phase 2: Task-Specific Section Selection**

| Task | Required Sections from Master TDD | Required Sections from Common Library TDD |
|------|-----------------------------------|-------------------------------------------|
| **Service-TDD** | Service Library (3.2) - ALL services, API Design (5) - ALL endpoints, Data Model (4), Async Patterns, 11-Function Flow Engine, SOAP/REST Specifications, Rules-as-a-Service, Anti-Patterns | Module Specifications (6) - relevant modules, Integration Patterns (7), Error Handling (8) |
| **UI-TDD** | API Design (5) - relevant endpoints, Data Model (4) - relevant tables | N/A (UI doesn't directly use Common Library) |

**Phase 3: Selective Reading Implementation**
```
1. Use Grep to find section start line numbers
2. Use Read with offset/limit to read specific sections
3. Extract only relevant content for the current feature
4. Cache extracted information for subsequent operations
```

**Example: Reading Service Library for "Booking Management Service"**
```
Step 1: Grep for "Booking-Management-Service" or "booking-management"
Step 2: Read surrounding context (offset: found_line - 10, limit: 50)
Step 3: Extract service specifications
```

**Implementation Guidelines:**
1. **Never attempt to read entire large document** - always use selective reading
2. **Use Grep first** to locate relevant sections before reading
3. **Read Table of Contents** (first 150 lines) to understand document structure
4. **Use offset/limit parameters** to read specific sections
5. **Extract and summarize** key information rather than copying entire sections
6. **Focus on feature-specific content** - only read sections relevant to the FSD being processed

**Business Value:** Enables processing of enterprise-scale documentation without token limit failures, ensures reliable HLD/LLD generation regardless of input document size.

**Priority:** P0 (Critical)

---

## Scope Definition

### In Scope

**TDD Generation (Based on Master TDD Patterns):**
1. **Service-TDD** - ONE consolidated document for ALL backend services in a feature (includes SOAP integrations)
   - Async operations pattern (>16s operations with POST /async, GET /status, operation-status table)
   - SOAP vs REST protocol specifications (explicit, from Endpoint Inventory)
   - SOAP envelope structure and XML parsing approach (for SOAP integrations)
   - Complete 11-function Flow Engine breakdown (Functions 1-11, especially 6/8/10)
   - Rules-as-a-Service integration (NO embedded validation logic)
   - Detailed sequence diagrams (sync + async with all functions labeled)
   - Lambda configuration (1024MB/30s for SOAP/async support)
   - Complex authentication patterns (Vault, certificates) for external systems
   - Anti-pattern validation (8 critical checks before output)

2. **UI-TDD** - Component specifications for axis-tools code generation
   - Component hierarchy and state management
   - Form validators and cross-field validators (HLR-1)
   - POM field mappings (instruction-driven when POM provided)
   - API integration points
   - Accessibility requirements

**Input Document Processing:**
4. Multi-format document input (Markdown, PDF with images)
5. Runtime format detection and appropriate processing
6. Visual content extraction from PDFs (screenshots, diagrams)
7. Direct document input (FSD, Master TDD, Common Library TDD, POM)
8. Large document handling (selective reading strategy for 40K+ token documents)

**Validation and Quality:**
9. SOAP vs REST Endpoint Inventory validation (NO protocol assumptions)
10. Anti-pattern validation (8 critical checks before output)
11. Feature coverage validation (100% FSD coverage)
12. Master TDD pattern compliance verification

**Supporting Capabilities:**
13. POM subsection analysis (instruction-driven)
14. Cross-field validation rules (client-side in UI-TDD)
15. Server-side validation rules (Rules-as-a-Service integration in Service-TDD)
16. Complete data flow documentation (UI → API → POM → DynamoDB → PostgreSQL)
17. Common Library integration patterns (Flow Engine, Validate Token, Entitlements, Vault)
18. Selective reading for large documents (Master TDD 41K tokens, Common Library TDD 35K tokens)

### Out of Scope

1. **Feature-TDD Generation** - Master TDD already covers feature-level architecture
2. **Separate Integration-TDD Documents** - SOAP integrations are included within Service-TDD (NOT as separate documents)
3. **Code Generation** - Handled by axis-tools (UI) and nodejs-pair-programmer (Lambda)
4. **Visual UI Design** - Mockups, wireframes (design team responsibility)
5. **Architecture Decision Making** - Handled by tech-architect (Master TDD creation)
6. **Business Requirements Creation** - Handled by business-analyst
7. **Master TDD Creation** - Handled by tech-architect
8. **Common Library TDD Creation** - Handled by tech-architect
9. **PostgreSQL Schema Generation (DDL)** - Data Architecture team owns relational schemas
10. **Embedded Validation Logic** - All validation uses Rules-as-a-Service API
11. **Protocol Assumption** - Agent NEVER assumes REST; MUST check Endpoint Inventory
12. **Test Execution** - Test specifications only, not execution
13. **Deployment Automation** - Infrastructure team responsibility

---

## Command Structure

### Unified Command Pattern

The plugin uses a **unified `/design` command** that implements the three-tier architecture:

| Tier | Component | Role | Implementation |
|------|-----------|------|----------------|
| **Tier 1** | `/design` command | Prompt enricher - ADLCs user context | commands/design.md |
| **Tier 2** | design-agent router | Context engineer + orchestrator - reads Master TDD, verifies protocols, delegates | agents/design-agent.md |
| **Tier 3** | Specialized designers | TDD generators - create output documents | agents/service-tdd-designer.md, agents/ui-tdd-designer.md |

### User-Facing Command

| Command | Description | Example Usage |
|---------|-------------|---------------|
| `/design [natural language request]` | Unified entry point - enriches prompt and invokes router | `/design create Service-TDD from FSD` |

### Available Slash Commands

| Command | Purpose | Consumer |
|---------|---------|----------|
| `/design-agent:services-tdd` | Generate Service-TDD for backend services (includes SOAP integrations) | nodejs-pair-programmer |
| `/design-agent:ui-tdd` | Generate UI-TDD for frontend components | axis-tools |
| `/design-agent:validate-coverage` | Validate 100% feature coverage across TDD documents | Quality validation |

### Usage Examples

**Service-TDD Generation (All Backend Services in ONE Document, includes SOAP integrations):**
```
/design-agent:services-tdd Generate Service-TDD from FSD and Master TDD
/design create Services-TDD for producer search feature with MDM SOAP integration
/design generate Lambda specifications from Master TDD and FSD
/design create backend service TDD with async patterns and SOAP specs
```

**UI-TDD Generation (Component Specifications):**
```
/design-agent:ui-tdd Generate UI-TDD from FSD
/design create UI component specifications for axis-tools
/design generate UI specs with form validators and cross-field validation
/design create Angular component specs with POM mappings
```

**Coverage Validation:**
```
/design-agent:validate-coverage Validate feature coverage
/design check if all FSD features are covered in TDD documents
/design validate 100% coverage across Service-TDD and UI-TDD
```

### Three-Tier Routing Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  TIER 1: COMMAND (Prompt Enricher)                                          │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  /design [natural language request]                                    │ │
│  │  - Takes user request with file paths/pasted content                   │ │
│  │  - Enriches with FSD, Master TDD, inventory references                 │ │
│  │  - Invokes design-agent router via Task tool                           │ │
│  │  - NO routing logic (delegated to router)                              │ │
│  └─────────────────────────────┬──────────────────────────────────────────┘ │
└─────────────────────────────────┼────────────────────────────────────────────┘
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  TIER 2: ROUTER (Context Engineering + Orchestration)                       │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  design-agent.md                                                       │ │
│  │                                                                        │ │
│  │  Context Engineering Phase:                                            │ │
│  │  1. Read Master TDD selectively (TOC + Grep + offset/limit)          │ │
│  │  2. Read FSD completely for requirements                               │ │
│  │  3. Check SOAP vs REST Endpoint Inventory for protocol verification   │ │
│  │  4. Discover output path (document metadata → workspace → user)       │ │
│  │                                                                        │ │
│  │  Orchestration Phase:                                                  │ │
│  │  5. Analyze design intent (Service-TDD vs UI-TDD)                     │ │
│  │  6. Verify critical patterns (protocol, async >16s, Lambda 1024MB/30s)│ │
│  │  7. Present plan for user confirmation                                 │ │
│  │  8. Delegate to specialized designer with complete context            │ │
│  │                                                                        │ │
│  │  Validation Phase:                                                     │ │
│  │  9. Run 8 anti-pattern checks on generated TDD                        │ │
│  │  10. Deliver validated output or request corrections                   │ │
│  └─────────────────────────────┬──────────────────────────────────────────┘ │
└─────────────────────────────────┼────────────────────────────────────────────┘
                                  ▼
                 ┌────────────────┼────────────────┐
                 ▼                ▼                ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  TIER 3: SPECIALIZED DESIGNERS (TDD Generation)                             │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐            │
│  │ service-tdd-     │ │ ui-tdd-          │ │ Direct handling  │            │
│  │ designer         │ │ designer         │ │ (coverage)       │            │
│  │                  │ │                  │ │                  │            │
│  │ Service-TDD      │ │ UI-TDD           │ │ Coverage         │            │
│  │ (ONE doc ALL     │ │ component specs  │ │ validation       │            │
│  │ services,        │ │ for axis-tools   │ │ report           │            │
│  │ includes SOAP    │ │                  │ │                  │            │
│  │ integrations)    │ │                  │ │                  │            │
│  │ for nodejs-pair- │ │                  │ │                  │            │
│  │ programmer       │ │                  │ │                  │            │
│  └──────────────────┘ └──────────────────┘ └──────────────────┘            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Intent Detection and Routing

**Router Agent (`design-agent.md`) analyzes user intent and routes to specialized designers:**

| User Intent | Trigger Keywords | Routed To | Required Inputs | Output |
|-------------|------------------|-----------|-----------------|--------|
| Service-TDD | "Service-TDD", "Lambda TDD", "backend", "API specs", "SOAP", "MDM", "RDM", "external system" | `service-tdd-designer` | Master TDD (selective), FSD (complete), Common Library TDD (selective), SOAP vs REST Endpoint Inventory | `{feature-name}-Service-TDD.md` (ONE document for ALL services including SOAP integrations) |
| UI-TDD | "UI-TDD", "component specs", "axis-tools", "Angular", "frontend" | `ui-tdd-designer` | Master TDD (API patterns), FSD | `{feature-name}-UI-TDD.md` |
| Coverage | "validate", "coverage", "check", "verify" | Router handles directly | FSD, Service-TDD, UI-TDD | Coverage report (console output) |

### Input Document Reference Strategy

**Master TDD (~41K tokens) - SELECTIVE READING REQUIRED:**
- **Phase 1:** Read Table of Contents (first 150 lines)
- **Phase 2:** Grep for MANDATORY patterns (async, 11-function, SOAP, Rules-as-a-Service, anti-patterns)
- **Phase 3:** Read specific pattern sections using offset/limit (200-300 lines per pattern)
- **Key Sections:** Async Operations Pattern, 11-Function Flow Engine, SOAP vs REST Specifications, Rules-as-a-Service Integration, Anti-Patterns, Lambda Configuration

**Common Library TDD (~35K tokens) - SELECTIVE READING REQUIRED:**
- **Phase 1:** Read Table of Contents (first 150 lines)
- **Phase 2:** Grep for relevant modules (Flow Engine, Validate Token, Entitlements, Vault)
- **Phase 3:** Read specific module specifications using offset/limit (150-200 lines per module)
- **Key Sections:** Flow Engine Module (Section 6.1), Validate Token Module (Section 6.2), Integration Patterns (Section 7), Error Handling Strategy (Section 8)

**FSD - COMPLETE READING:**
- **Phase 1:** Read entire FSD (typically <25K tokens)
- **Extract:** Business requirements, validation rules, operations >16s, external API integrations, error messages

**SOAP vs REST Endpoint Inventory - COMPLETE READING:**
- **Phase 1:** Read entire inventory (typically <5K tokens)
- **Extract:** Protocol for each external API (SOAP or REST), endpoint URLs, operations
- **CRITICAL:** If inventory missing and FSD mentions external APIs, STOP and ASK user for inventory

### Behavioral Guardrails

**ALWAYS (Mandatory Patterns):**
1. Read Master TDD selectively for mandatory patterns (async, SOAP, 11-functions, Rules-as-a-Service)
2. Read FSD completely to extract ALL business requirements and validation rules
3. Check SOAP vs REST Endpoint Inventory before protocol specification
4. Identify operations >16s and specify complete async pattern (POST /async, GET /status, operation-status table)
5. Specify complete 11-function Flow Engine breakdown (explicitly detail Functions 6/8/10)
6. Integrate Rules-as-a-Service for validation (NO embedded validation logic)
7. Create detailed sequence diagrams (sync + async with all 11 functions labeled)
8. Run 8 anti-pattern validation checks before output
9. Present plan for user confirmation before document generation
10. Specify Lambda configuration as 1024MB/30s (NOT 512MB/16s)

**NEVER (Anti-Patterns):**
1. Assume REST protocol (MUST check SOAP vs REST Endpoint Inventory)
2. Omit async patterns for >16s operations
3. Skip Functions 6, 8, or 10 in Flow Engine breakdown
4. Embed validation logic in Lambda code (use Rules-as-a-Service API)
5. Generate PostgreSQL DDL (Data Architecture owns schemas)
6. Skip user confirmation before document generation
7. Read entire Master TDD or Common Library TDD (use selective reading)
8. Use try-catch error handling patterns (use Go-style [error, result])
9. Specify 512MB/16s Lambda configuration (use 1024MB/30s)

**STOP and ASK (Ambiguity Handling):**
1. Protocol unclear or SOAP vs REST Endpoint Inventory missing
2. Async operation duration unknown (>16s or <16s?)
3. Flow Engine function breakdown ambiguous
4. Rules-as-a-Service API specification missing
5. Conflicting validation rules between FSD and Master TDD
6. PostgreSQL schema expectations (agent documents usage only, Data Architecture owns DDL)

---

## Inputs and Outputs

### Required Inputs for Service-TDD Generation

| Input | Format | Source | Required | Key Sections | Token Size | Reading Strategy |
|-------|--------|--------|----------|--------------|------------|------------------|
| **Master TDD** | Markdown (.md) | tech-architect | Yes | Async Operations Pattern, 11-Function Flow Engine, SOAP vs REST Specifications, Rules-as-a-Service Integration, Anti-Patterns, Lambda Configuration | ~41K tokens | **SELECTIVE** - Read TOC (150 lines) + Grep patterns + Read specific sections (offset/limit) |
| **Feature Specification Document (FSD)** | Markdown (.md) or PDF (.pdf) | product-owner | Yes | Scope, Business Requirements, Validation Rules, Operations >16s, External API Integrations, Error Messages. PDF may include screenshots, UI mockups, business process flows | <25K tokens | **COMPLETE** - Read entire document |
| **Common Library TDD** | Markdown (.md) | tech-architect | Yes | Flow Engine Module (6.1), Validate Token Module (6.2), Integration Patterns (7), Error Handling Strategy (8) | ~35K tokens | **SELECTIVE** - Read TOC (150 lines) + Grep modules + Read specific sections (offset/limit) |
| **SOAP vs REST Endpoint Inventory** | YAML (.yaml) or Markdown (.md) | tech-architect or integration team | Yes (if external APIs) | Protocol (SOAP/REST), Endpoint URLs, Operations, Authentication | <5K tokens | **COMPLETE** - Read entire inventory. If missing and FSD mentions external APIs, STOP and ASK |

### SOAP Integration Specifications (Included in Service-TDD)

**When Service-TDD includes SOAP integrations**, the following additional specifications are required within the Service-TDD document:

| Specification | Details | Source |
|---------------|---------|--------|
| **SOAP Envelope Structure** | Complete XML request/response envelope with namespaces | Master TDD (SOAP patterns section) |
| **XML Parsing Approach** | fast-xml-parser configuration, XML→JSON transformation | Master TDD |
| **11-Function Flow Engine** | Complete breakdown for integration services (Functions 1-11) | Master TDD + Common Library TDD |
| **Async Patterns** | If integration >16s: POST /async, GET /status, operation-status table | Master TDD (Async Operations Pattern) |
| **Authentication Patterns** | Vault credential retrieval, TLS certificates, Basic Auth | Master TDD |
| **SOAP vs REST Endpoint Inventory** | Protocol specification for external APIs | SOAP vs REST Endpoint Inventory (Required) |

### Required Inputs for UI-TDD Generation

| Input | Format | Source | Required | Key Sections | Reading Strategy |
|-------|--------|--------|----------|--------------|------------------|
| **FSD** | Markdown (.md) or PDF (.pdf) | product-owner | Yes | Business Requirements, UI Validation Rules, Cross-Field Dependencies, UI Screenshots/Mockups (if PDF) | **COMPLETE** |
| **Master TDD** | Markdown (.md) | tech-architect | Yes | API Design patterns (Section 5), Data Model (Section 4) | **SELECTIVE** - API and data model sections only |

### Optional Inputs (Instruction-Driven)

| Input | Format | Source | Used By | Purpose |
|-------|--------|--------|---------|---------|
| **BRD** | Markdown (.md) | business-analyst | All TDD types | Business context and justification |
| **POM Structure** | TypeScript/JSON | architecture | UI-TDD, Service-TDD | Field mappings (only when user explicitly requests POM mappings) |
| **Rules-as-a-Service API Specification** | Markdown (.md) or YAML (.yaml) | platform team | Service-TDD | Validation service endpoint, request/response format, fallback strategies |

**POM Note:** POM is **instruction-driven**. Agent does NOT inherently process POM. When user provides POM and explicitly requests field mappings, the UI-TDD or Service-TDD includes field-to-POM-path mapping tables. Without POM or explicit request, agent generates designs without field-level POM mappings.

### Document Format Handling

| Format | How to Read | Visual Content | Use Case |
|--------|-------------|----------------|----------|
| **Markdown (.md)** | Read tool - text mode | N/A | FSD, Master TDD, Common Library TDD, BRD |
| **PDF (.pdf)** | Read tool - processes page by page | **YES** - Claude Code extracts text AND images | FSD with screenshots, UI mockups, business process flow diagrams |
| **YAML (.yaml)** | Read tool - text mode | N/A | SOAP vs REST Endpoint Inventory, Rules-as-a-Service API Spec |
| **Images (.png, .jpg)** | Read tool - visual mode | **YES** - Analyzed visually | Standalone UI mockups or architecture diagrams |
| **Pasted Content** | Direct text parsing | N/A | Quick text inputs |

**Important:** When FSD is provided as PDF with screenshots or diagrams, the agent MUST use the Read tool on the PDF file to see the visual content. Claude Code processes PDFs as multimodal content (text + images).

### Outputs by Command

**Service-TDD Generation** (`/design-agent:services-tdd`)
```
output/
└── {feature-name}-Service-TDD.md    # ONE document for ALL backend services (includes SOAP integrations)
                                             # Contains: Service Overview (all services),
                                             # Async patterns (POST /async, GET /status),
                                             # SOAP/REST protocol specs with envelope structures,
                                             # SOAP integration specifications (if applicable):
                                             #   - SOAP envelope structure
                                             #   - XML parsing approach
                                             #   - Complex authentication (Vault, certificates)
                                             # Complete 11-function Flow Engine breakdown,
                                             # Rules-as-a-Service integration,
                                             # Detailed sync+async sequence diagrams,
                                             # Lambda config (1024MB/30s),
                                             # Anti-pattern validation results
```

**UI-TDD Generation** (`/design-agent:ui-tdd`)
```
output/
└── {feature-name}-UI-TDD.md                 # UI component specifications (for axis-tools)
                                             # Contains: Component hierarchy,
                                             # State management (Signals/NgRx),
                                             # Form validators and cross-field validators (HLR-1),
                                             # POM field mappings (if POM provided),
                                             # API integration points,
                                             # Template specifications,
                                             # Accessibility requirements (ARIA, keyboard nav)
```

**Coverage Validation** (`/design-agent:validate-coverage`)
```
output/
└── {feature-name}-Coverage-Report.md        # Coverage validation report
                                             # Contains: Coverage percentage,
                                             # FSD requirement ID → TDD section mappings,
                                             # Missing coverage gaps,
                                             # Recommendations
```

**Example Output for "Producer Search" Feature:**
```
output/
├── producer-search-Service-TDD.md   # ALL backend services (search, enrichment, persistence)
│                                            # Includes MDM SOAP integration specifications
├── producer-search-UI-TDD.md                # UI component specifications
└── producer-search-Coverage-Report.md       # Coverage validation (if requested)
```

### Output Consumers

| Output Document | Primary Consumer | Purpose |
|-----------------|------------------|---------|
| **Service-TDD** | nodejs-pair-programmer | Lambda code generation with async patterns, SOAP/REST protocols (includes SOAP integration specs), 11-function flows, Rules-as-a-Service |
| **UI-TDD** | axis-tools | Angular component code generation |
| **Coverage Report** | QA / Project Manager | Quality assurance, requirement traceability |

---

## Document Content Requirements

The design-agent generates documents that match the level of detail found in enterprise reference documents like `master-tdd-full.md` and `common-library-tdd.md`.

---

### Feature-TDD Content (NOT GENERATED - OUT OF SCOPE)

**IMPORTANT:** Design agent does NOT generate Feature-TDD documents. Master TDD already covers feature-level architecture including async patterns, SOAP/REST specifications, 11-function Flow Engine, Rules-as-a-Service, and anti-patterns.

**Agent Outputs:** Service-TDD (consolidated, includes SOAP integrations), UI-TDD

---

### Service-TDD Content (Consolidated Lambda/Service Specifications)

**Purpose:** ONE consolidated document for ALL backend services in the feature, following enterprise TDD standards with mandatory patterns (async, SOAP, 11-function, Rules-as-a-Service, anti-patterns).

**Output File:** `{feature-name}-Service-TDD.md` (e.g., `client-info-Service-TDD.md`)

**IMPORTANT:** This is a SINGLE document containing ALL backend services for the feature, NOT separate documents per service.

```markdown
# {Service Name} - Technical Design Document

## 1. Service Overview
### 1.1 Purpose
- What the service does
- Primary use cases

### 1.2 Key Features
- Feature list with descriptions

### 1.3 Runtime Specifications
| Property | Value |
|----------|-------|
| Runtime | Node.js 20.x.x |
| Memory | {size}MB |
| Timeout | {seconds}s |
| Invocation | Sync/Async |

## 2. Service Architecture
### 2.1 Architecture Diagram
```mermaid
graph TB
    // Service architecture diagram
```

### 2.2 Three-Layer Structure
- Handler layer
- Processor layer
- Helper layer

## 3. Technology Stack
| Component | Version | Purpose |
|-----------|---------|---------|

## 4. Module Specifications
### 4.1 Handler Module
#### TypeScript Interfaces
```typescript
interface ServiceRequest {
  // Request interface
}

interface ServiceResponse {
  // Response interface
}
```

#### Function Signatures
| Function | Parameters | Returns | Description |
|----------|------------|---------|-------------|

### 4.2 Processor Module
- Business logic specifications
- Function chain (if using Flow Engine)

### 4.3 Helper Modules
- Utility function specifications

## 5. API Specifications
### 5.1 Endpoint: {METHOD} {path}
#### Request
```typescript
interface RequestBody {
  // TypeScript interface
}
```
**Headers:**
| Header | Required | Description |
|--------|----------|-------------|

#### Response
```typescript
interface SuccessResponse {
  // TypeScript interface
}
```

**Status Codes:**
| Code | Description |
|------|-------------|

### 5.2 Additional Endpoints...

## 6. Database Operations
### 6.1 DynamoDB Operations
| Operation | Table | Key | Purpose |
|-----------|-------|-----|---------|

**Table Schema:**
```typescript
interface TableItem {
  // TypeScript interface for DynamoDB item
}
```

### 6.2 PostgreSQL Operations
- Table operations
- Query specifications

## 7. Common Library Integration
### 7.1 Flow Engine Configuration
```json
{
  "flowId": "{flowId}",
  "version": "1",
  "functions": [
    // Function chain configuration
  ]
}
```

### 7.2 Validate Token Integration
### 7.3 Entitlements Integration
### 7.4 Vault Integration (if applicable)

## 8. Error Handling
### 8.1 Error Codes
| Code | HTTP Status | Description |
|------|-------------|-------------|

### 8.2 Error Response Format
```typescript
interface ErrorResponse {
  // Error interface
}
```

## 9. Validation Rules (Server-Side)
| Field | Rule | Error Message |
|-------|------|---------------|

## 10. Sequence Diagrams
```mermaid
sequenceDiagram
    // Detailed sequence diagram
```

## 11. Testing Strategy
### 11.1 Unit Tests
### 11.2 Integration Tests
### 11.3 Test Coverage Requirements (>80%)

## 12. Environment Variables
| Variable | Description | Example |
|----------|-------------|---------|
```

---

### UI-TDD Content (Component Specifications)

**Purpose:** Detailed UI component specifications for axis-tools code generation.

**Output File:** `{feature-name}-UI-TDD.md`

```markdown
# {Feature Name} - UI Low-Level Design

**Consumer:** axis-tools (Angular code generation)

## 1. Component Specifications

### 1.1 {ComponentName}Component

**Selector:** `app-{component-name}`
**Type:** Smart | Presentational
**Module:** {ModuleName}Module

#### TypeScript Interface
\`\`\`typescript
interface {ComponentName}Props {
  // Input properties
}

interface {ComponentName}State {
  // Component state
}
\`\`\`

#### Inputs
| Name | Type | Required | Default | Description |
|------|------|----------|---------|-------------|

#### Outputs
| Name | Type | Description |
|------|------|-------------|

#### Methods
| Name | Parameters | Returns | Description |
|------|------------|---------|-------------|

#### Lifecycle Hooks
- ngOnInit: {responsibilities}
- ngOnDestroy: {cleanup}

### 1.2 Additional Components...

## 2. State Management Details

### 2.1 Signal Definitions
| Signal | Type | Initial Value | Description |
|--------|------|---------------|-------------|

### 2.2 Computed Properties
| Name | Derivation | Description |
|------|------------|-------------|

### 2.3 Effects
| Name | Trigger | Action |
|------|---------|--------|

## 3. Form Specifications

### 3.1 Form Controls
| Field | Type | Control Type | Default |
|-------|------|--------------|---------|

### 3.2 Field Validators
| Field | Validators | Error Messages |
|-------|------------|----------------|

### 3.3 Cross-Field Validators (HLR-1)
| Name | Fields | Rule | Error Message |
|------|--------|------|---------------|

## 4. POM Mappings (if POM provided)
| UI Field | POM Path | Data Type | Transform |
|----------|----------|-----------|-----------|

## 5. API Integration
### 5.1 Service Dependencies
| Service | Method | Endpoint | Purpose |
|---------|--------|----------|---------|

### 5.2 Data Loading
- Initial data fetch patterns
- Refresh patterns

## 6. Template Specifications
### 6.1 Layout Structure
- Component layout hierarchy
- Axis component usage

### 6.2 Conditional Rendering
| Condition | Elements | Behavior |
|-----------|----------|----------|

### 6.3 Event Bindings
| Element | Event | Handler | Action |
|---------|-------|---------|--------|

## 7. Accessibility Requirements
### 7.1 ARIA Labels
| Element | Label |
|---------|-------|

### 7.2 Keyboard Navigation
| Action | Behavior |
|--------|----------|

## 8. Error Handling
### 8.1 Error Display Patterns
### 8.2 User Feedback
```

---

## Success Criteria

### Acceptance Criteria

Plugin is considered successful when it achieves ALL of the following:

**Business Metrics:**
1. **Service-TDD Generation Time:** <45 minutes from FSD to complete Service-TDD (all backend services consolidated)
2. **UI-TDD Generation Time:** <30 minutes from FSD to complete UI-TDD
3. **Code Generation Success:** >90% of TDD specs successfully used by nodejs-pair-programmer and axis-tools with NO protocol errors, NO async pattern omissions, NO flow engine mismatches
4. **Rework Rate:** <10% of TDDs requiring changes after implementation

**Technical Compliance (High-Level Requirements):**
5. **HLR-1: Cross-Field Validation in UI-TDD** - UI-TDD documents include client-side validation rules accounting for cross-field dependencies and relationships
6. **HLR-2: Server-Side Validation (Rules-as-a-Service)** - Service-TDD specifies integration with Rules-as-a-Service API for validation (NO embedded validation logic permitted)
7. **HLR-3: Complete Data Flow Documentation** - All TDD documents show complete data flow: UI → External APIs → POM → DynamoDB → PostgreSQL
8. **HLR-4: POM Subsection Focus** - Agent identifies relevant POM subsections when POM provided (instruction-driven)
9. **HLR-5: Master TDD-Driven Design** - Agent does NOT generate separate Feature-TDD (Master TDD covers architecture); generates ONLY Service-TDD (consolidated with SOAP integrations), UI-TDD
10. **HLR-6: Async Operations Pattern** - 100% of operations >16s have complete async pattern (POST /async, GET /status, operation-status table, async sequence diagram)
11. **HLR-7: SOAP vs REST Protocol Specification** - 100% protocol accuracy; agent NEVER assumes REST; explicitly checks SOAP vs REST Endpoint Inventory; includes SOAP envelope structure and XML parsing for SOAP
12. **HLR-8: Complete 11-Function Flow Engine Breakdown** - All Flow Engine integrations have complete function breakdown with Functions 6/8/10 explicitly defined
13. **HLR-9: Detailed Sequence Diagrams** - All Service-TDD documents include sync + async sequence diagrams with all 11 functions labeled, SOAP/REST indicators, Rules-as-a-Service calls, SOAP integration flows
14. **HLR-10: Anti-Pattern Validation** - Agent runs 8 critical anti-pattern checks before output: (1) No sync calls >16s, (2) No hardcoded endpoints, (3) No try-catch blocks, (4) No embedded validation, (5) No protocol assumption, (6) No relational schema generation, (7) No missing Flow Engine functions, (8) No insufficient Lambda config
15. **HLR-11: Lambda Configuration Standards** - All Lambda specs use 1024MB/30s (NOT 512MB/16s)

**Quality Targets:**
16. **Master TDD Pattern Compliance:** 100% adherence to all mandatory patterns (async, 11-function flow, SOAP/REST, Rules-as-a-Service, anti-patterns, Lambda config)
17. **Hallucination Risk:** <15% (target: protocol ambiguity, async pattern omission, flow engine mismatch)
18. **Feature Coverage:** 100% of FSD features covered in generated TDD documents (validated via `/design-agent:validate-coverage`)
19. **Document Traceability:** 100% of TDD content traceable to source FSD requirements

### Definition of Done

**For Service-TDD:**
- [ ] ONE consolidated document generated for ALL backend services
- [ ] ALL operations >16s have complete async pattern specified (POST /async, GET /status, operation-status table)
- [ ] SOAP or REST protocol explicitly specified from Endpoint Inventory (NO protocol assumptions)
- [ ] Complete 11-function Flow Engine breakdown included (Functions 1-11, especially 6/8/10 detailed)
- [ ] Rules-as-a-Service integration specified (NO embedded validation logic)
- [ ] Detailed sync + async sequence diagrams with all 11 functions labeled
- [ ] Lambda configuration specified as 1024MB/30s
- [ ] 8 anti-pattern validation checks passed
- [ ] All sections completed (no TODOs or placeholders)
- [ ] Traceable to source FSD requirements
- [ ] Consumable by nodejs-pair-programmer for code generation

**For SOAP Integration Specifications (within Service-TDD):**
- [ ] SOAP envelope structure and XML parsing approach included
- [ ] Complete 11-function Flow Engine breakdown included for integration services
- [ ] Authentication patterns specified (Vault, certificates)
- [ ] Async pattern specifications included (if integration operations >16s)
- [ ] Detailed sequence diagrams included for SOAP flows
- [ ] SOAP specifications traceable to source FSD requirements
- [ ] All SOAP integration specs consumable by nodejs-pair-programmer

**For UI-TDD:**
- [ ] Component hierarchy and specifications completed
- [ ] State management strategy specified (Signals/NgRx/Services)
- [ ] Form validators and cross-field validators included (HLR-1)
- [ ] POM field mappings included (if POM provided and requested)
- [ ] API integration points specified
- [ ] Template specifications completed
- [ ] Accessibility requirements included (ARIA, keyboard navigation)
- [ ] All sections completed (no TODOs or placeholders)
- [ ] Traceable to source FSD requirements
- [ ] Consumable by axis-tools for code generation

**For Coverage Validation:**
- [ ] Coverage report generated with percentage
- [ ] FSD requirement ID → TDD section mappings completed
- [ ] Missing coverage gaps identified (if any)
- [ ] Recommendations provided (if gaps exist)

### Quality Assurance Checklist

Before delivering any TDD document, agent MUST verify:

**Anti-Pattern Checks (8 Critical):**
- [ ] ✅ No synchronous calls for >16s operations (async pattern specified)
- [ ] ✅ No hardcoded endpoints (configuration/Vault specified)
- [ ] ✅ No try-catch blocks (Go-style [error, result] specified)
- [ ] ✅ No embedded validation logic (Rules-as-a-Service integration specified)
- [ ] ✅ No protocol assumption (explicit SOAP or REST from Endpoint Inventory)
- [ ] ✅ No schema generation for relational DBs (PostgreSQL usage documented only)
- [ ] ✅ No missing Flow Engine functions (all 11 functions specified if using Flow Engine)
- [ ] ✅ No insufficient Lambda config (1024MB/30s specified)

**Master TDD Pattern Compliance:**
- [ ] ✅ Async operations pattern included for >16s operations
- [ ] ✅ SOAP vs REST protocol explicitly specified (not assumed)
- [ ] ✅ Complete 11-function Flow Engine breakdown included
- [ ] ✅ Rules-as-a-Service integration specified
- [ ] ✅ Detailed sequence diagrams included (sync + async)
- [ ] ✅ Lambda configuration 1024MB/30s specified

**Document Completeness:**
- [ ] ✅ All required sections completed (no TODOs or [placeholder] text)
- [ ] ✅ Mermaid diagrams included where required
- [ ] ✅ TypeScript interfaces included for all data structures
- [ ] ✅ Traceability matrix to FSD requirements included
- [ ] ✅ Document validated for consumability by code generation agents

---

## Dependencies

### Upstream Dependencies

| Dependency | Purpose | Document |
|------------|---------|----------|
| **tech-architect** | Provides Master TDD | `master-tdd-full.md` - System architecture, service library, data model |
| **tech-architect** | Provides Common Library TDD | `common-library-tdd.md` - Shared library specifications |
| **product-owner** | Provides FSD | Feature Specification Document (Markdown or PDF) |
| **Architecture repo** | Provides POM structure | Policy Object Model TypeScript/JSON |

### Downstream Consumers

| Consumer | Consumes | Purpose |
|----------|----------|---------|
| **axis-tools** | UI-TDD (component specs) | Angular code generation |
| **nodejs-pair-programmer** | Service-TDD (API/Lambda specs including SOAP integrations) | Lambda code generation |
| **Human reviewers** | TDD documents | Architecture review and approval |

---

## Constraints

### Business Constraints

1. **Master TDD Required:** Agent MUST have Master TDD as input (agent does NOT generate Feature-TDD; Master TDD already covers feature-level architecture)
2. **FSD Required:** Agent MUST have Feature Specification Document (FSD) to generate any TDD documents
3. **SOAP vs REST Endpoint Inventory Required:** When FSD mentions external API integrations, SOAP vs REST Endpoint Inventory MUST be provided (agent NEVER assumes REST protocol)
4. **No Code Generation:** Agent produces design documents only (code generation handled by nodejs-pair-programmer and axis-tools)
5. **User Confirmation Required:** Agent MUST present plan and wait for user confirmation before generating TDD documents
6. **Standalone Operation:** No workspace-agent dependency (documents provided directly)
7. **Data Architecture Ownership:** Agent MUST NOT generate PostgreSQL DDL (Data Architecture team owns relational schemas; agent documents usage only)
8. **Rules-as-a-Service Mandate:** Agent MUST NOT embed validation logic (all validation uses Rules-as-a-Service API integration)

### Technical Constraints

1. **Markdown Format:** All outputs in Markdown format (.md extension)
2. **Direct Input:** Documents provided directly via file paths or pasted content (not from workspace paths)
3. **Claude Code Compatible:** TDD specs optimized for consumption by code generation agents (axis-tools for UI, nodejs-pair-programmer for Lambda)
4. **Token Limits:** Large documents (Master TDD ~41K, Common Library TDD ~35K) exceed Claude Code's 25K token read limit; agent MUST use selective reading strategy (TOC + Grep + offset/limit)
5. **Protocol Determination:** Agent MUST check SOAP vs REST Endpoint Inventory before specifying protocol (NEVER assume REST)
6. **Async Pattern Mandatory:** Operations >16s MUST use async pattern (POST /async, GET /status, operation-status table); synchronous calls prohibited
7. **Lambda Configuration Fixed:** Agent MUST specify Lambda configuration as 1024MB/30s (NOT 512MB/16s) to support SOAP processing and async patterns
8. **11-Function Flow Engine:** When using Flow Engine, agent MUST specify all 11 functions (Functions 6/8/10 are CRITICAL and must be explicitly detailed)
9. **Anti-Pattern Validation Mandatory:** Agent MUST run 8 critical anti-pattern checks before generating output (any failure MUST be corrected)
10. **Go-Style Error Handling:** Agent MUST specify Go-style [error, result] error handling pattern (NOT try-catch blocks)

### Performance Constraints

1. **Service-TDD Generation Time:** Target <45 minutes from FSD input to complete Service-TDD (all backend services consolidated)
2. **UI-TDD Generation Time:** Target <30 minutes from FSD input to complete UI-TDD
3. **Large Document Processing:** Selective reading strategy required for documents >25K tokens (Master TDD, Common Library TDD)
4. **Mermaid Diagram Rendering:** All Mermaid diagrams must be syntactically valid and renderable in standard Markdown viewers

### Compliance Constraints

1. **Master TDD Pattern Compliance:** 100% adherence to Master TDD mandatory patterns (async, SOAP/REST, 11-function flow, Rules-as-a-Service, anti-patterns, Lambda config)
2. **High-Level Requirement (HLR) Compliance:** All 11 HLRs must be satisfied (HLR-1 through HLR-11)
3. **Anti-Pattern Prohibition:** All 8 anti-patterns must be avoided (checked before output):
   - No synchronous calls for >16s operations
   - No hardcoded endpoints
   - No try-catch blocks
   - No embedded validation logic
   - No protocol assumption
   - No schema generation for relational DBs
   - No missing Flow Engine functions
   - No insufficient Lambda config (512MB/16s)
4. **Feature Coverage:** 100% of FSD features must be covered in generated TDD documents (validated via `/design-agent:validate-coverage`)
5. **Document Traceability:** All TDD content must be traceable to source FSD requirements via traceability matrix

### Quality Constraints

1. **No Placeholders:** Generated TDD documents MUST NOT contain TODO markers or [placeholder] text
2. **Completeness:** All required sections must be completed before delivery
3. **TypeScript Interfaces:** All data structures must have complete TypeScript interface definitions
4. **Sequence Diagrams:** All Service-TDD documents must include minimum 2 sequence diagrams (sync + async) with all 11 functions labeled, including SOAP integration flows if applicable
5. **Hallucination Risk Target:** <15% hallucination risk (protocol ambiguity, async pattern omission, flow engine mismatch)

---

## Risk Assessment

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| **HLD too abstract** | Medium | High | Provide detailed templates and examples |
| **LLD too verbose** | Medium | Medium | Focus on code-generation-relevant details |
| **POM mapping errors** | Medium | High | Validate mappings, provide examples |
| **Feature coverage gaps** | Low | High | Mandatory validation command |

---

## Appendix

### Related Documents

**Design Agent Plugin Documents:**
- **BRD (This Document):** [plugins/AIDLC-design/requirements/design-agent-brd.md](plugins/AIDLC-design/requirements/design-agent-brd.md)
- **HLD (High-Level Design):** [plugins/AIDLC-design/requirements/design-agent-hld.md](plugins/AIDLC-design/requirements/design-agent-hld.md)
- **LLD (Low-Level Design):** [plugins/AIDLC-design/requirements/design-agent-lld.md](plugins/AIDLC-design/requirements/design-agent-lld.md)
- **Acceptance Criteria:** [plugins/AIDLC-design/acceptance-criteria.md](plugins/AIDLC-design/acceptance-criteria.md)
- **High-Level Requirements:** [plugins/AIDLC-design/requirements/hlr.md](plugins/AIDLC-design/requirements/hlr.md)

**Agent Implementation:**
- **Router Agent:** [plugins/AIDLC-design/agents/design-agent.md](plugins/AIDLC-design/agents/design-agent.md)
- **Service-TDD Designer:** [plugins/AIDLC-design/agents/service-tdd-designer.md](plugins/AIDLC-design/agents/service-tdd-designer.md) - Generates consolidated Service-TDD
- **UI-TDD Designer:** [plugins/AIDLC-design/agents/ui-tdd-designer.md](plugins/AIDLC-design/agents/ui-tdd-designer.md)
- **Design Guidelines:** [plugins/AIDLC-design/agents/design-guidelines.md](plugins/AIDLC-design/agents/design-guidelines.md)

**Downstream Consumers:**
- **Axis Tools (UI Code Generation):** [plugins/axis-tools/](plugins/axis-tools/)
- **Node.js Pair Programmer (Lambda Code Generation):** [plugins/nodejs-pair-programmer/](plugins/nodejs-pair-programmer/)

**Review Feedback:**
- **Review Feedback Document:** [output/review-feedback.md](output/review-feedback.md)
- **Assessment Report:** [output/assessment-report.md](output/assessment-report.md)

### Glossary

**Document Types:**
- **Service-TDD:** Technical Design Document for backend services - ONE consolidated document for ALL backend services in a feature, includes async patterns, SOAP/REST protocols (with complete SOAP integration specifications: envelope structure, XML parsing, complex authentication), 11-function Flow Engine, Rules-as-a-Service integration, sync+async sequence diagrams with SOAP flows
- **UI-TDD:** Technical Design Document for UI components - component specifications for axis-tools code generation, includes validators, POM mappings, state management
- **FSD:** Feature Specification Document - Business requirements, scope, validation rules (can be Markdown or PDF with screenshots)
- **Master TDD:** Master Technical Design Document - System architecture covering feature-level patterns (async, SOAP/REST, 11-function flows, Rules-as-a-Service, anti-patterns, Lambda config) - provided by tech-architect
- **Common Library TDD:** Common Library Technical Design Document - Shared library specifications (Flow Engine, Validate Token, Entitlements, Vault Extension) - provided by tech-architect
- **POM:** Policy Object Model - Data structure for policy information (instruction-driven: agent processes POM only when user provides it and requests field mappings)
- **BRD:** Business Requirements Document - Business objectives, requirements, success criteria (this document)
- **HLD:** High-Level Design - Architecture and mandatory patterns for Design Agent implementation
- **LLD:** Low-Level Design - Implementation details and code patterns for Design Agent implementation

**Architecture Terms:**
- **Async Operations Pattern:** Mandatory pattern for operations >16 seconds - includes POST /async endpoint (returns 202 + requestId), GET /status endpoint (polling), operation-status DynamoDB table
- **11-Function Flow Engine:** Complete function breakdown (Functions 1-11) with explicit detail for Functions 6 (determineAsyncPattern), 8 (buildSOAPRequest), 10 (parseAndTransformResponse)
- **SOAP vs REST Endpoint Inventory:** External input listing protocol (SOAP or REST) for each external API - MUST be checked before protocol specification (agent NEVER assumes REST)
- **Rules-as-a-Service:** External validation service (OPA) - ALL validation logic uses Rules API integration (NO embedded validation in Lambda code)
- **Anti-Patterns:** 8 critical checks before output - (1) No sync calls >16s, (2) No hardcoded endpoints, (3) No try-catch blocks, (4) No embedded validation, (5) No protocol assumption, (6) No relational schema generation, (7) No missing Flow Engine functions, (8) No insufficient Lambda config
- **Go-Style Error Handling:** [error, result] tuple pattern (NOT try-catch blocks)
- **Lambda Configuration:** 1024MB memory, 30s timeout (NOT 512MB/16s) - supports SOAP processing and async patterns
- **Selective Reading Strategy:** Technique for processing large documents (Master TDD ~41K, Common Library TDD ~35K) that exceed 25K token limit - Read TOC + Grep patterns + Read specific sections (offset/limit)

**Compliance Terms:**
- **HLR (High-Level Requirement):** Business requirement with acceptance criteria and test case - Design Agent has 11 HLRs (HLR-1 through HLR-11)
- **Master TDD Pattern Compliance:** 100% adherence to all mandatory patterns from Master TDD (async, SOAP/REST, 11-function flow, Rules-as-a-Service, anti-patterns, Lambda config)
- **Hallucination Risk:** Probability of generating incorrect or assumed information (protocol ambiguity, async pattern omission, flow engine mismatch) - Target <15%
- **Feature Coverage:** Percentage of FSD features covered in generated TDD documents - Target 100% (validated via `/design-agent:validate-coverage`)

### Acronyms

| Acronym | Full Name | Description |
|---------|-----------|-------------|
| **TDD** | Technical Design Document | Detailed specifications for code generation |
| **FSD** | Feature Specification Document | Business requirements and scope from product-owner |
| **BRD** | Business Requirements Document | Business objectives and requirements |
| **HLD** | High-Level Design | Architecture and patterns |
| **LLD** | Low-Level Design | Implementation details and code patterns |
| **POM** | Policy Object Model | Data structure for policy information |
| **UI** | User Interface | Frontend components |
| **API** | Application Programming Interface | Backend service endpoints |
| **REST** | Representational State Transfer | HTTP-based API protocol |
| **SOAP** | Simple Object Access Protocol | XML-based API protocol |
| **OPA** | Open Policy Agent | Rules-as-a-Service validation engine |
| **MDM** | Master Data Management | External system for master data |
| **RDM** | Reference Data Management | External system for reference data |
| **TTL** | Time To Live | Expiration time for DynamoDB items |
| **ARIA** | Accessible Rich Internet Applications | Accessibility standard |
| **HLR** | High-Level Requirement | Business requirement with acceptance criteria |

### SOAP vs REST Endpoint Inventory Example

```yaml
# soap-rest-endpoint-inventory.yaml
external_apis:
  - name: MDM Producer Search
    protocol: SOAP
    endpoint: https://mdm-gateway-api-v1-uat.example.com
    operation: searchProducer
    wsdl: https://mdm-gateway-api-v1-uat.example.com?wsdl
    authentication: Basic Auth (from Vault)
    timeout: 25s
    retry: 3 attempts

  - name: RDM Reference Data
    protocol: REST
    endpoint: https://rdm-api.example.com/v1
    authentication: Bearer Token
    timeout: 10s
    retry: 2 attempts

  - name: Vault Configuration Retrieval
    protocol: REST
    endpoint: https://vault.example.com/v1
    authentication: Token (from environment)
    timeout: 5s
    retry: 3 attempts
```

### Rules-as-a-Service API Specification Example

```yaml
# rules-service-api-spec.yaml
service_name: Rules-as-a-Service (OPA)
endpoint: https://rules-service.example.com/validate
authentication: Bearer Token
timeout: 5s
retry: 2 attempts

request_format:
  entity: string  # e.g., "producer", "policy", "claim"
  data: object    # Entity data to validate
  ruleSet: string # e.g., "producer-validation-v1"

response_format:
  valid: boolean
  errors: array   # Validation errors (if invalid)
  warnings: array # Warnings (if any)

fallback_strategy: |
  If Rules service unavailable:
  1. Return validation error to caller
  2. Log error with correlation ID
  3. Alert on-call team
  4. NO embedded validation fallback
```

### Anti-Pattern Examples

**Anti-Pattern 1: Synchronous Call for >16s Operation**
```typescript
// ❌ WRONG - Synchronous call for long-running operation
async function searchProducer(criteria: SearchCriteria) {
  const result = await mdmClient.search(criteria); // May take 25+ seconds
  return result;
}

// ✅ CORRECT - Async pattern with status polling
async function searchProducerAsync(criteria: SearchCriteria) {
  const requestId = generateUUID();
  await createOperationStatus(requestId, 'IN_PROGRESS');
  await invokeLambdaAsync('producer-search-processor', { requestId, criteria });
  return { requestId, status: 'IN_PROGRESS', statusUrl: `/api/producer/status/${requestId}` };
}
```

**Anti-Pattern 2: Hardcoded Endpoint**
```typescript
// ❌ WRONG - Hardcoded endpoint
const mdmEndpoint = 'https://mdm-gateway-api-v1-uat.example.com';

// ✅ CORRECT - Configuration from Vault
const mdmEndpoint = await vaultClient.getSecret('mdm/endpoint');
```

**Anti-Pattern 3: Try-Catch Error Handling**
```typescript
// ❌ WRONG - Try-catch blocks
try {
  const result = await mdmClient.search(criteria);
  return result;
} catch (error) {
  throw error;
}

// ✅ CORRECT - Go-style [error, result]
const [error, result] = await mdmClient.search(criteria);
if (error) {
  return [error, null];
}
return [null, result];
```

**Anti-Pattern 4: Embedded Validation Logic**
```typescript
// ❌ WRONG - Embedded validation logic
if (!producer.name || producer.name.length < 3) {
  throw new ValidationError('Producer name must be at least 3 characters');
}

// ✅ CORRECT - Rules-as-a-Service integration
const [error, validationResult] = await rulesServiceClient.validate({
  entity: 'producer',
  data: producer,
  ruleSet: 'producer-validation-v1'
});
if (error || !validationResult.valid) {
  return [new ValidationError(validationResult.errors), null];
}
```

### Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Nov 24, 2025 | AI COE | Initial BRD |
| 1.0.1 | Nov 24, 2025 | AI COE | Refocused on HLD + LLD generation, new command structure |
| 1.0.2 | Nov 25, 2025 | AI COE | Added Common Library TDD as required input; Added multi-format document handling (PDF with images); Added BR11 and BR12 for format handling; Updated input requirements with detailed section references |
| 1.0.3 | Nov 25, 2025 | AI COE | **Major restructure of outputs:** Document generation refactored; Updated Document Content Requirements with detailed templates matching enterprise TDD standards; Unified `/design` command pattern |
| 1.0.4 | Nov 25, 2025 | AI COE | Added BR13: Large Document Handling Strategy for processing Master TDD (~41K tokens) and Common Library TDD (~35K tokens) that exceed Claude Code's 25K token read limit; Section-based selective reading approach |
| 1.1 | Dec 9, 2025 | AI COE | **MAJOR UPDATE based on Design Agent Review Feedback, Assessment Report, and HLD v6.0/LLD v3.0 alignment:** <br/>**Terminology Changes:** Feature HLD→Feature-TDD (NOT generated, out of scope), UI-LLD→UI-TDD, Services-LLD/API-LLD/per-service TDDs→Service-TDD (ONE consolidated document for ALL services including SOAP integrations), NO separate Integration-TDD (SOAP integrations included in Service-TDD) <br/>**Three-Tier Architecture:** Tier 1 (Command /design as prompt enricher), Tier 2 (Router design-agent.md for context engineering + orchestration + validation), Tier 3 (Specialized designers service-tdd-designer, ui-tdd-designer) <br/>**BR1:** Restructured to detail three-tier architecture with Master TDD as source of truth <br/>**BR2:** Added router's selective reading strategy implementation (TOC + Grep + offset/limit) for 41K+ token documents with code examples; Added mandatory Master TDD patterns (async >16s, 11-function flow, SOAP/REST, Rules-as-a-Service, Lambda config 1024MB/30s) <br/>**BR3:** Complete sequence diagrams (sync+async with all 11 functions, SOAP/REST indicators) <br/>**BR4:** Anti-pattern validation (8 critical checks before output) <br/>**BR5:** SOAP vs REST Endpoint Inventory (external input, eliminate 95% protocol hallucination) <br/>**BR6:** Rules-as-a-Service API specification (external validation, NO embedded rules) <br/>**BR8:** Service-TDD consolidation (ONE document for ALL services per feature, NO separate TDDs per service) <br/>**BR9:** SOAP integration specifications WITHIN Service-TDD (consolidated, NOT separate Integration-TDD) <br/>**BR15:** Database schema specifications (DynamoDB full specs, PostgreSQL usage only - NO DDL generation) <br/>**Success Metrics:** Expanded with architecture component mapping and added Context Engineering Efficiency (<5s), Anti-Pattern Detection Rate (100%), Lambda Config Accuracy (100%), Master TDD compliance 100%, hallucination risk <15%, async pattern coverage 100%, SOAP protocol accuracy 100%, 11-function flow completeness 100% <br/>**Command Structure:** Restructured to show three-tier flow with user-facing `/design` command as Tier 1, removed `/design-agent:integration-tdd` command <br/>**Routing Logic:** Complete three-tier routing flow diagram showing context engineering, orchestration, and validation phases; Removed Integration-TDD as separate output <br/>**Document Hierarchy:** Updated to show Master TDD as single source for architecture, eliminated redundant Feature-TDD generation, consolidated SOAP integrations within Service-TDD <br/>**Overall Theme:** Emphasized implementation architecture, context engineering efficiency, protocol/endpoint verification at router layer, anti-pattern validation before delivery, and consolidation of all backend specifications (including SOAP) in Service-TDD |
| 1.2 | Dec 2025 | AI COE | Bump version for plugin bundle release v1.2 |
| 1.3 | 2026-01-09 | AI COE Team | Version bump for release v1.3.0 |
| 1.4 | 2026-01-21 | AI COE Team | Version bump for unified release v1.4.0 |

---

**Document Owner:** AI COE Team & S3 Team
**Status:** Review Feedback Updated
**Last Updated:** December 9, 2025
