# Axis Tools Plugin

A comprehensive Claude Code plugin for working with the Axis UI component library (v18.0.32). Features a TDD-first workflow with automatic section extraction, planning router that explores context, presents implementation plans, and coordinates specialized agents for UI generation, validation, and documentation.

**Version:** 1.5.0
**Framework:** Angular 18 with Axis UI v18.0.32
**Standard:** PLUGIN_DEVELOPMENT_GUIDE.md v2.0 Compliant
**Architecture:** Skills-Based (Natural Language Invocation)
**Key Feature:** Feature TDD-First Development with Automatic Section Extraction & Anti-Guess Safeguards

---

## Table of Contents

- [Features](#features)
- [Feature TDD-First Workflow](#feature-tdd-first-workflow)
- [Architecture](#architecture)
- [Plugin Structure](#plugin-structure)
- [Documentation](#documentation)
- [Agents](#agents)
- [Skills](#skills)
- [Agent Hierarchy](#agent-hierarchy)
- [TDD Context Storage & Reuse](#tdd-context-storage--reuse)
- [How to Use](#how-to-use)
- [Component Categories](#component-categories)
- [Agent Compliance](#agent-compliance)

---

## Features

- **Automatic TDD Section Extraction**: `tdd-extractor` skill automatically extracts 12+ major sections from monolithic TDD files into temporary category files for token-efficient loading (57-98% savings)
- **Feature TDD-First Workflow**: Always prompts for Feature TDD file path before code generation to ensure correct architecture, endpoints, and models
- **Intelligent Section Loading**: Agents analyze request keywords to load only needed TDD sections (e.g., "form validation" → loads overview, components, forms)
- **Anti-Guess Safeguards**: If TDD missing, pauses code generation and asks 3 specific clarifying questions (repository structure, API endpoints, component architecture) - NO guessing allowed
- **TDD Context Storage & Reuse**: Stores TDD context and passes to all downstream agents (axis-ui-generator, dynamic-ui-generator) for consistent architecture across all generated files
- **Planning Router**: `axis-router` explores context, presents plans, and coordinates agents
- **User Confirmation**: Plans are presented before execution for user approval
- **Multi-Agent Workflows**: Coordinate generate → validate → fix sequences
- **Static UI Generation**: Generate production-ready Angular UIs from descriptions, mockups, or LLD specs using TDD context
- **Dynamic UI Generation**: Generate DynamoDB-driven runtime UI from LLD specs with uiStructure patterns using TDD context
- **Code Validation**: Validate Angular code against Axis framework guidelines and source truth documents
- **Complete Documentation**: Access comprehensive documentation for all 78 Axis components via skill-based architecture

---

## Feature TDD-First Workflow

### Overview

This plugin enforces a **Feature TDD-first** approach to ensure correct architecture, endpoints, and model structure before generating any code.

### Workflow Steps

```
1. User Request with TDD Path (e.g., "Generate search form from .idea/client-info-ui-design.md")
   ↓
2. axis-implement skill auto-invokes
   ↓
3. Agent Detects TDD File Path in Request
   ↓
4. Agent Invokes tdd-extractor Skill
   ↓
5. tdd-extractor Extracts Sections:
   - Uses Grep to find section boundaries with line numbers
   - Extracts sections via targeted Read operations (93% memory reduction)
   - Writes sections to plugins/AIDLC-axis/.cache/tdd-extractions/{tdd-name}/
   - Returns section paths mapping
   ↓
6. Agent Determines Needed Sections:
   - Analyzes request keywords
   - Example: "form validation" → overview, components, forms
   - Token cost: ~5K (vs 42K full) = 88% savings
   ↓
7. Agent Reads Selected Sections in Parallel
   ↓
8. Plugin Extracts Context from Sections:
   - Architecture (component structure, state management, data flow)
   - Endpoints (API patterns, HTTP methods, URLs)
   - Models (TypeScript interfaces, POM mappings, validation rules)
   - Repository Structure (folder paths)
   - DynamoDB Tables (for dynamic UI)
   ↓
9. Plugin Stores TDD Context & Passes to Generators
   ↓
10. Generators Use EXACT TDD Specifications
    - NO guessing
    - NO assumptions
    - EXACT architecture, endpoints, and models from TDD
```

### Automatic TDD Section Extraction

**New in v2.1.0:** `tdd-extractor` skill automatically processes monolithic TDD files.

**Extracted Sections:**
- Overview (Section 1) - Business context, scope
- Architecture (Section 2) - C4 diagrams, system structure
- Components (Section 4) - Component specifications
- User Journey (Section 5) - User flows, interactions
- API Integration (Section 6) - Configuration, interceptors, endpoints, flows
- Forms (Section 7) - Field specs, validation, POM mapping
- Error Handling (Section 8) - Error scenarios, recovery
- Testing (Section 9) - Test strategy, requirements
- Security (Section 10) - Auth, compliance, validation
- Performance (Section 11) - Performance targets, optimization
- Dependencies (Section 12) - Dependencies, references

**Token Efficiency Examples:**
- Search form: 42K → 5K tokens (88% savings)
- Component only: 42K → 3.5K tokens (92% savings)
- Complete API context: 42K → 14K tokens (67% savings)

**Cache File Location:**
```
plugins/AIDLC-axis/.cache/tdd-extractions/{tdd-filename}/
├── overview.md
├── architecture.md
├── components.md
├── forms.md
└── ... (12-15 total sections)
```

**Manual Cleanup (optional):**
```bash
rm -rf plugins/AIDLC-axis/.cache/tdd-extractions/
```

### If TDD File Missing

**CRITICAL: Plugin PAUSES code generation and asks 3 clarifying questions:**

1. **Repository Structure (TDD Section 4.1)**
   - Project root and folder organization
   - Component, service, model, shared folder locations

2. **API Endpoints (TDD Section 5.1)**
   - Base URLs, HTTP methods, request/response structures
   - Authentication requirements

3. **Component Architecture (TDD Section 6.x)**
   - Component type and state management approach
   - Data flow pattern and validation strategy
   - UI pattern (static vs dynamic/DynamoDB-driven)

**After receiving answers:**
- Plugin constructs a virtual TDD context
- Proceeds with code generation using this context
- **NO code generated based on guesses**

### Benefits

✅ **Correct Architecture** - Component structure matches TDD specifications
✅ **Correct Endpoints** - API calls use exact URLs and methods from TDD
✅ **Correct Models** - TypeScript interfaces match TDD definitions
✅ **Consistent Implementation** - All agents share same TDD context
✅ **No Guessing** - Explicit clarification when TDD missing
✅ **Traceable Decisions** - All architecture decisions documented

---

## Architecture

**Centralized Routing Architecture (v2.1.0):** All UI generation requests flow through axis-router for TDD extraction, pattern detection, and agent coordination.

```
┌─────────────────────────────────────────────────────────────────┐
│               Natural Language User Request                      │
│   (e.g., "Generate form from .idea/client-info-ui-design.md")   │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│              axis-implement Skill Auto-Invokes                   │
│         Detects UI generation request and activates              │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│          ALWAYS Routes to axis-router (Single Entry Point)       │
│         Delegates all requests to router for orchestration       │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                       axis-router                                │
│   (Centralized TDD Handling + Pattern Detection + Routing)      │
├─────────────────────────────────────────────────────────────────┤
│  Step 1: Check for TDD Path                                      │
│          "Please provide Feature TDD path..." (if not provided)  │
│          ↓                                                       │
│  Step 1a: Extract TDD Sections (NEW - Centralized)              │
│           → Invoke tdd-extractor skill                           │
│           → Receive section paths mapping                        │
│           → Determine needed sections based on keywords          │
│           → Read selected sections in parallel                   │
│           Token Savings: 57-98% vs full TDD                      │
│          ↓                                                       │
│  Step 2: Load TDD Context from Extracted Sections               │
│          - Architecture (component structure, state mgmt)        │
│          - Endpoints (API patterns, HTTP methods, URLs)          │
│          - Models (TypeScript interfaces, POM mappings)          │
│          - Repository Structure (folder organization)            │
│          - DynamoDB Tables (for dynamic UI)                      │
│          ↓                                                       │
│  Step 3: Discover Shared Components                             │
│          Check TDD Section 6.4.2 + search _shared folder        │
│          ↓                                                       │
│  Step 4: Detect Pattern (Priority-Based - NEW)                  │
│          Priority 1: POM/Interface → dynamic-ui-generator        │
│          Priority 2: AUG Component → dynamic-ui-generator        │
│          Priority 3: Dynamic Patterns → dynamic-ui-generator     │
│          Priority 4: Static UI (default) → axis-ui-generator     │
│          ↓                                                       │
│  Step 5: Select Agent                                           │
│          Based on pattern detection                              │
│          ↓                                                       │
│  Step 6: Delegate with TDD Section Paths                        │
│          Pass "TDD Categories Available:" header                 │
│          Include extracted section file paths                    │
│          ↓                                                       │
│  Step 7: Summarize Results                                      │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          │ [Delegation with Section Paths]
                          │
          ┌───────────────┼───────────────┬───────────────┬──────────────┐
          ▼               ▼               ▼               ▼              ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────────┐ ┌────────────┐
│ axis-ui-     │ │ dynamic-ui-  │ │ axis-code-   │ │ axis-jasmine-    │ │ axis-      │
│ generator    │ │ generator    │ │ validator    │ │ test-generator   │ │documentation│
│ (Static UI)  │ │ (DynamoDB)   │ │ (Validation) │ │ (Jasmine Tests)  │ │(Reference) │
├──────────────┤ ├──────────────┤ └──────────────┘ └──────────────────┘ └────────────┘
│ Step 0:      │ │ Step 0:      │
│ Load TDD     │ │ Load TDD     │
│ Context from │ │ Context from │
│ Router       │ │ Router       │
└──────────────┘ └──────────────┘
       │                 │
       └─────────┬───────┘
                 ▼
   ┌────────────────────────────────────┐
   │ Generate Code Using EXACT TDD Specs│
   │ - Architecture from TDD            │
   │ - Endpoints from TDD               │
   │ - Models from TDD                  │
   │ - File paths from TDD              │
   └────────────────────────────────────┘
                 │
                 ▼
     ┌─────────────────────────┐
     │ axis-development-guide  │
     │ (Conventions Reference) │
     └─────────────────────────┘
                 │
                 ▼
     ┌─────────────────────────┐
     │   skills/axis-docs/     │
     │(Component Documentation)│
     └─────────────────────────┘
```

**Key Architecture Benefits:**
- ✅ **Single Source of Truth**: TDD extraction only in router (no duplication)
- ✅ **Consistent Flow**: ALL requests go through router (predictable behavior)
- ✅ **Easier Maintenance**: Update routing logic in one place only
- ✅ **Token Efficiency**: Same 57-98% savings as pre-split feature-specs
- ✅ **Better Separation**: Router handles orchestration, generators handle code generation

---

## Plugin Structure

```
axis-tools/
├── .claude-plugin/
│   └── plugin.json                    # Plugin configuration (v1.2.0)
│
├── commands/
│   └── axis.md                        # Routes to axis-router
│
├── agents/                            # 8 Specialized Agents (v2.0 Compliant)
│   ├── axis-router.md                 # Planning router (entry point)
│   ├── axis-ui-generator.md           # Static UI code generation
│   ├── dynamic-ui-generator.md        # DynamoDB-driven UI generation
│   ├── axis-code-validator.md         # Code validation + functional gap analysis
│   ├── axis-test-generator.md         # General unit test generation
│   ├── tdd-extractor.md               # TDD section extraction (token optimization)
│   ├── axis-documentation.md          # Component documentation (lightweight)
│   └── axis-development-guide.md      # Patterns & conventions reference
│
├── skills/                            # 9 Auto-Invoking Skills
│   ├── axis-docs/                     # Component documentation (9 categories)
│   ├── axis-types/                    # TypeScript type definitions (8 categories)
│   ├── generation-patterns/           # Implementation patterns and examples
│   ├── axis-implement/                # UI generation skill (auto-invokes)
│   ├── axis-explore/                  # Codebase exploration skill (auto-invokes)
│   ├── axis-validate/                 # Code validation skill (auto-invokes)
│   ├── axis-test/                     # General test generation skill (auto-invokes)
│   ├── axis-jasmine-test/             # Jasmine test generation skill (auto-invokes)
│   └── axis-help/                     # Plugin help and reference (auto-invokes)
│
├── __tests__/                         # Evaluation tests (18 total)
│   ├── ui_generation_from_descriptions.test
│   ├── ui_generation_from_mockups.test
│   ├── code_validation_against_axis_guidelines.test
│   ├── form_validation_patterns.test
│   ├── pom_field_mapping.test
│   ├── client_side_validation.test
│   ├── chart_data_visualization.test
│   ├── navigation_management.test
│   ├── accessibility_compliance.test
│   ├── conditional_attributes.test
│   ├── event_handler_pattern_with_business_logic.test
│   ├── dynamic_ui_event_handler_pattern.test
│   ├── jasmine_test_generation.test
│   ├── layout_decision_guide.test
│   ├── component_documentation_access.test
│   ├── prompt_in_hindi.test
│   ├── feature_tdd_prompt_workflow.test (NEW - v1.3.0)
│   └── missing_tdd_clarifying_questions.test (NEW - v1.3.0)
│
├── acceptance-criteria.md
└── README.md
```

---

## Documentation

### Core Reference
- **[AXIS-UI-GENERATOR-GUIDE.md](./docs/AXIS-UI-GENERATOR-GUIDE.md)** - Main API reference and decision guide (2,123 lines)
  - TypeScript Type System and type definitions
  - When to Use What: Decision Guide for method selection
  - AxisUiGeneratorComponent API reference
  - FormService API reference
  - Complete TypeScript Types Reference (680 lines)

### Supplementary Guides
- **[AXIS-UI-GENERATOR-EXAMPLES.md](./docs/AXIS-UI-GENERATOR-EXAMPLES.md)** - Complete working examples and patterns (~1,000 lines)
  - Basic Setup with imports and templates
  - Advanced Forms with Conditional Fields
  - 6 comprehensive uiEmitUpdate event handling patterns (cascade dropdowns, auto-save, validation, API lookup, DOM manipulation, complex business logic)
  - Dynamic Field Manipulation examples
  - FormService integration patterns
  - Multi-Step Wizard Forms
  - Translation examples

- **[AXIS-UI-GENERATOR-ADVANCED-PATTERNS.md](./docs/AXIS-UI-GENERATOR-ADVANCED-PATTERNS.md)** - Advanced techniques and best practices (~200 lines)
  - Pre-populating Form Data
  - Complex Validation patterns
  - Accessing Form Controls via FormService
  - Programmatic Form Refresh techniques
  - Monitoring Field Changes
  - Error Handling strategies
  - Best Practices (10 items)

- **[AXIS-UI-GENERATOR-TROUBLESHOOTING.md](./docs/AXIS-UI-GENERATOR-TROUBLESHOOTING.md)** - Common issues, mistakes, and anti-patterns (~250 lines)
  - Common Issues and Solutions (5 scenarios)
  - 8 Common Mistakes and Anti-Patterns with BAD vs GOOD examples
  - Decision Tree for choosing the right approach

**Benefits of Modular Documentation:**
- **37% size reduction**: Main guide reduced from 3,383 to 2,123 lines
- **Faster navigation**: Jump directly to examples, advanced patterns, or troubleshooting
- **Better learning path**: Beginners follow Main → Examples → Advanced → Troubleshooting
- **Easier maintenance**: Update sections independently

---

## Agents

### 1. axis-router (Planning Router)

**Purpose:** Orchestrates Axis development workflows by exploring context, planning implementation, and coordinating specialized agents. Entry point from `/axis` command. Enforces Feature TDD-first workflow.

| Property | Value |
|----------|-------|
| **Model** | inherit |
| **Tools** | Read, Glob, Grep, Task, AskUserQuestion, TodoWrite |
| **Permission Mode** | plan (read-only) |
| **Color** | automatic |

**Use When:**
- All `/axis` command invocations (automatic)
- Requests that need context exploration before routing
- Multi-step workflows (generate + validate)

**Key Behaviors:**
- **Always requests Feature TDD path first** - Ensures correct architecture, endpoints, models
- **Handles missing TDD** - If file not found, asks 3 clarifying questions (repository structure, API endpoints, component architecture)
- **Stores and passes TDD context** - Passes complete TDD to all downstream agents
- Detects static vs dynamic patterns from TDD
- Presents implementation plan for user confirmation
- Coordinates multi-agent workflows
- Never generates code directly (delegates to specialized agents)

---

### 2. axis-ui-generator (Static UI)

**Purpose:** Generates production-ready Angular TypeScript and HTML code using Axis components for static UI implementations. Uses Feature TDD context for exact architecture, endpoints, and models.

| Property | Value |
|----------|-------|
| **Model** | inherit |
| **Tools** | Read, Write, Edit, Grep, Glob, Task |
| **Permission Mode** | default |
| **Color** | automatic |

**Use When:**
- Creating Angular forms, dashboards, or UI mockups
- LLD files do NOT contain DynamoDB/JSON retrieval patterns
- Converting Figma/Sketch designs to Angular code

**Key Behaviors:**
- **Step 0: Extracts and stores Feature TDD context** - Architecture, endpoints, models, repository structure
- **Uses EXACT TDD specifications** - NO guessing, NO assumptions
- Queries axis-documentation for component specs before generating
- Never uses native HTML when Axis components exist
- Implements ALL validators from TDD/LLD specifications
- Generates files in TDD-specified repository paths

---

### 3. dynamic-ui-generator (DynamoDB-Driven UI)

**Purpose:** Generates Angular code that fetches and renders UI dynamically from JSON schemas stored in DynamoDB at runtime. Uses Feature TDD context for exact architecture, endpoints, models, and DynamoDB table details.

| Property | Value |
|----------|-------|
| **Model** | inherit |
| **Tools** | Read, Write, Edit, Glob, Grep, Task |
| **Permission Mode** | default |
| **Color** | automatic |

**Use When:**
- LLD/HLD files contain DynamoDB references
- ui-component-catalog table patterns detected
- uiStructure or JSON schema retrieval patterns present

**Key Behaviors:**
- **Step 0: Extracts and stores Feature TDD context** - Architecture, endpoints, models, DynamoDB tables, JSON schema structure
- **Uses EXACT TDD specifications** - NO guessing, NO assumptions
- Always reads LLD/HLD before generating to detect DynamoDB patterns
- Presents implementation plan for user confirmation
- Creates complete file sets (component, service, model, template, form-structure)
- Generates files in TDD-specified repository paths

---

### 3. axis-code-validator (Validation + Gap Analysis)

**Purpose:** Validates Angular code against Axis framework guidelines and identifies functional gaps by comparing implementations against source truth documents (FSD/HLD/LLD).

| Property | Value |
|----------|-------|
| **Model** | inherit |
| **Tools** | Read, Grep, Glob |
| **Permission Mode** | plan (read-only) |
| **Color** | red |

**Use When:**
- Reviewing Axis code for compliance
- After code generation (validation step)
- Before deployment
- Validating implementation against design specs

**Key Behaviors:**
- Reads source truth documents before validating functional completeness
- Categorizes findings by severity (CRITICAL/HIGH/MEDIUM/LOW)
- Never modifies code directly (read-only validator)
- Defers code fixes to generator agents

---

### 4. axis-test-generator (Unit Test Generator)

**Purpose:** Generates general unit tests for Angular components built with the Axis framework with flexible testing approach (Jest/Jasmine).

| Property | Value |
|----------|-------|
| **Model** | inherit |
| **Tools** | Read, Write, Edit, Glob, Grep |
| **Permission Mode** | default |
| **Color** | automatic |

**Use When:**
- Need general unit tests for Angular components
- After code generation (test creation step)
- Flexible testing framework requirements

**Key Behaviors:**
- Analyzes component structure including inputs, outputs, methods, services
- Generates test files with proper test configuration
- Creates mocks for Axis components and services
- Supports both Jest and Jasmine frameworks

---

### 5. tdd-extractor (TDD Section Extractor)

**Purpose:** Extracts major sections from monolithic TDD files (3,000+ lines, 40K+ tokens) into organized category files for token-efficient loading, enabling 57-98% token savings.

| Property | Value |
|----------|-------|
| **Model** | inherit |
| **Tools** | Read, Write, Bash, Grep |
| **Permission Mode** | default |
| **Color** | automatic |

**Use When:**
- Automatically invoked by axis-router when TDD file path detected
- Fallback invocation by generators when router bypassed
- Processing monolithic Technical Design Documents

**Key Behaviors:**
- Uses Grep to find section boundaries with line numbers (93% memory reduction vs full file read)
- Extracts 12-15 sections via targeted Read operations (offset/limit)
- Writes sections to `plugins/AIDLC-axis/.cache/tdd-extractions/{tdd-name}/`
- Returns section path mappings for selective loading
- Graceful fallback to legacy Read-based approach if Grep unavailable
- Enables 57-98% token savings for downstream agents

---

### 6. axis-documentation (Component Reference)

**Purpose:** Authoritative documentation source for the 78 Axis UI Angular components, providing comprehensive API reference including inputs, outputs, methods, and usage examples.

| Property | Value |
|----------|-------|
| **Model** | sonnet |
| **Tools** | Read, Grep, Glob |
| **Permission Mode** | plan (read-only) |

**Use When:**
- Looking up specific Axis component properties
- Need usage examples for dropdown, datagrid, charts, etc.
- Other agents query component specifications

**Key Behaviors:**
- Reads from skill files (skills/axis-docs/*.md) on demand
- Provides accurate API information with exact property names and types
- Never modifies code or generates files

---

### 7. axis-development-guide (Conventions Reference)

**Purpose:** Comprehensive AXIS framework knowledge base providing authoritative guidance on the 13 mandatory coding conventions, project structure, API Service patterns, and AxisSharedModule setup.

| Property | Value |
|----------|-------|
| **Model** | sonnet |
| **Tools** | Read, Grep, Glob |
| **Permission Mode** | plan (read-only) |

**Use When:**
- Questions about Axis setup or conventions
- Project structure guidance
- CSS class reference
- Other agents query convention information

**Key Behaviors:**
- Provides reference information without modifying code
- Cites specific convention numbers when referencing rules
- Recommends generator agents for code generation tasks

---

## Skills

The AIDLC-axis plugin includes 9 auto-invoking skills for natural language interaction:

### 1. axis-implement

**Purpose:** Generate, modify, or fix Angular UI code using Axis framework. Auto-invokes for UI generation requests with smart routing to static or dynamic generators.

**Auto-Invocation Triggers:**
- Keywords: generate, create, build, implement, modify, update, form, component, page, dashboard

**Key Behaviors:**
- Enforces Feature TDD-first workflow
- Routes to axis-router for orchestration
- Smart pattern detection (static vs dynamic UI)
- Stores and passes TDD context to generators

---

### 2. axis-explore

**Purpose:** Explore and understand existing Angular/Axis codebase. Auto-invokes for questions about code structure, components, patterns, and implementation details.

**Auto-Invocation Triggers:**
- Keywords: find, locate, explain, understand, how does, what is, compare, show

**Key Behaviors:**
- Locates components and files
- Explains existing patterns
- Compares implementations
- Documents codebase structure

---

### 3. axis-validate

**Purpose:** Validate Angular/Axis code against framework conventions and standards. Auto-invokes for code validation, compliance checks, and quality audits.

**Auto-Invocation Triggers:**
- Keywords: validate, check, review, verify, audit, compliance, quality, violations

**Key Behaviors:**
- Validates against Axis framework guidelines
- Checks accessibility compliance
- Identifies code quality issues
- Provides categorized findings (CRITICAL/HIGH/MEDIUM/LOW)

---

### 4. axis-test

**Purpose:** Generate unit tests for Angular/Axis components. Auto-invokes for test generation requests with flexible testing approach.

**Auto-Invocation Triggers:**
- Keywords: test, tests, testing, unit test, spec, coverage

**Key Behaviors:**
- Generates Jest/Jasmine tests
- Flexible testing framework support
- Analyzes component structure for comprehensive tests

---

### 5. axis-jasmine-test

**Purpose:** Generate comprehensive Jasmine unit tests for Angular/Axis components with >80% coverage. Auto-invokes for Jasmine-specific test generation requests.

**Auto-Invocation Triggers:**
- Keywords: jasmine test, comprehensive test, detailed test, >80% coverage, thorough test

**Key Behaviors:**
- Production-ready Jasmine test suites
- Guaranteed >80% code coverage
- Complete TestBed configuration
- Async operations testing with fakeAsync/tick

---

### 6. axis-help

**Purpose:** Comprehensive plugin help, skill reference, agent hierarchy, and component documentation index. Auto-invokes for help and documentation requests.

**Auto-Invocation Triggers:**
- Keywords: help, documentation, how to use, what skills, what commands, plugin info

**Key Behaviors:**
- Provides plugin overview
- Lists available skills and agents
- Shows component catalog
- Usage examples and guides

---

### 7. axis-docs

**Purpose:** Component documentation organized for progressive disclosure with 99.3% token reduction on activation.

**Structure:**

| File | Components | Lines |
|------|------------|-------|
| `SKILL.md` | Entry point with index | 58 |
| `form-controls.md` | button, checkbox, dropdown, input, datepicker, radio, slider, rating, timepicker, chip | 6,992 |
| `layout.md` | accordion, card, tab, modal, bottom-sheet, carousel | 3,593 |
| `advanced.md` | aug, file-upload, editor, search-address, search-account, duallist, captcha | 2,413 |
| `feedback.md` | alert, tooltip, loading, progress-bar, notifications, aqi, count, tour | 1,556 |
| `charts.md` | donut, bar, line, gauge, funnel, bubble, area, horizontal-bar, word-cloud | 540 |
| `data-display.md` | datagrid, list, tree, styled-list, calendar, datamaps | 442 |
| `navigation.md` | navbar, breadcrumb, paginator, portal-menu, progress-step, progress-tracker | 348 |
| `utilities.md` | cache-service, customValidators, helper-functions, logger, idle-timer | 321 |

**Total:** 16,263 lines across 9 files

**Benefits:**
- **99.3% token reduction** on agent activation (111 lines vs 16,357)
- **Progressive disclosure**: Only load needed category when queried
- **Maintainability**: Update one category without touching others

---

### 8. axis-types

**Purpose:** Complete TypeScript type definitions for all AXIS framework components. Multi-category skill with progressive disclosure covering 8 component categories.

**Type Categories:**
- Axis UI Generator Types
- Axis ABC Portal Menu Types
- Axis ABC Search Account Types
- Axis ABC Search Address Types
- Axis Charts Types
- Axis Components Types
- Axis DataGrid Types
- Axis Notification Types

**Benefits:**
- Comprehensive TypeScript type system
- Progressive disclosure by category
- Essential types loaded first, advanced types on demand

---

### 9. generation-patterns

**Purpose:** Component implementation patterns and examples for Axis UI generation. Load on-demand when generating specific component types.

**Key Patterns:**
- Form controls with validation
- Layout components
- Event handling examples
- Advanced component usage

**Benefits:**
- Quick reference for code generation
- Consistent implementation patterns
- Real-world usage examples

---

## Agent Hierarchy

### Relationships

```
┌─────────────────────────────────────────────────────────────┐
│                      ROUTER AGENT                            │
│              (permissionMode: default - orchestrates)        │
├─────────────────────────────────────────────────────────────┤
│                       axis-router                            │
│        (Exploration + Planning + Coordination)               │
└──────────────────────────┬──────────────────────────────────┘
                           │
       ┌───────────────────┼───────────────────┬───────────────┐
       ▼                   ▼                   ▼               ▼
┌─────────────────────────────────────────────────────────────┐
│                   GENERATOR AGENTS                           │
│              (permissionMode: default - can write)           │
├─────────────────────────────────────────────────────────────┤
│  axis-ui-generator    dynamic-ui-generator   axis-jasmine-  │
│  (Static Angular UI)  (DynamoDB-driven UI)   test-generator │
│                                              (Jasmine Tests) │
└──────────────┬─────────────────────────┬────────────────────┘
               │                         │
               └───────────┬─────────────┘
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                   VALIDATOR AGENT                            │
│              (permissionMode: plan - read-only)              │
├─────────────────────────────────────────────────────────────┤
│                    axis-code-validator                       │
│         (Code Quality + Functional Gap Analysis)             │
└─────────────────────────────────────────────────────────────┘
                           │
       ┌───────────────────┴───────────────────┐
       ▼                                       ▼
┌─────────────────────────────────────────────────────────────┐
│                    REFERENCE AGENTS                          │
│              (permissionMode: plan - read-only)              │
├─────────────────────────────────────────────────────────────┤
│  axis-documentation        axis-development-guide            │
│  (Component APIs)          (Conventions & Patterns)          │
└─────────────────────────────────────────────────────────────┘
```

### Key Distinctions

| Agent | Responsibility | Defers To |
|-------|---------------|-----------|
| **axis-router** | Explore, plan, coordinate workflows | All other agents (delegates) |
| **axis-ui-generator** | Generate static Angular code | axis-documentation (specs) |
| **dynamic-ui-generator** | Generate DynamoDB-driven UI code | axis-documentation (specs) |
| **axis-code-validator** | Validate code quality + find gaps | axis-ui-generator (fixes) |
| **axis-jasmine-test-generator** | Generate Jasmine unit tests | axis-documentation (specs) |
| **axis-documentation** | Provide component API reference | - |
| **axis-development-guide** | Provide convention guidance | - |

---

## TDD Context Storage & Reuse

### Overview

Once Feature TDD is ADLCed (either from file or user questions), the context is **stored and passed to all downstream agents** to ensure consistent implementation.

### Context Flow

```
┌──────────────────────────────────────────┐
│  implement.md OR axis-router             │
│  (Orchestrator)                          │
│                                          │
│  1. Request Feature TDD path             │
│  2. Read TDD file (or ask 3 questions)   │
│  3. STORE TDD context:                   │
│     - Architecture                       │
│     - Endpoints                          │
│     - Models                             │
│     - Repository Structure               │
└──────────────┬───────────────────────────┘
               │
               │ [Pass Complete TDD Context]
               │
               ▼
┌──────────────────────────────────────────┐
│  axis-ui-generator OR dynamic-ui-generator│
│  (Generator)                             │
│                                          │
│  Step 0: Extract and Store TDD Context  │
│  1. Receive TDD from orchestrator        │
│  2. Extract architecture patterns        │
│  3. Extract endpoint definitions         │
│  4. Extract model structures             │
│  5. Extract repository paths             │
│  6. STORE in memory throughout generation│
│  7. Reference TDD for ALL decisions      │
│  8. Generate code using EXACT TDD specs  │
└──────────────────────────────────────────┘
```

### Benefits

| Benefit | Description |
|---------|-------------|
| **Consistent Architecture** | All agents use same component structure, state management, and data flow |
| **Shared Understanding** | Virtual TDD (from user questions) or real TDD propagates to all generators |
| **Correct Endpoints** | All service files use exact API definitions, HTTP methods, and URL paths |
| **Accurate Models** | All TypeScript interfaces identical across component, service, and model files |
| **Proper Locations** | All files written to TDD-specified repository paths |

### Implementation

**Orchestrators** (implement.md, axis-router.md):
- Store TDD context after Step 1 (read file) or Step 1b (user questions)
- Pass complete TDD context in Task delegation prompts
- Include: architecture, endpoints, models, repository structure

**Generators** (axis-ui-generator.md, dynamic-ui-generator.md):
- Extract TDD context as Step 0 (before generating any code)
- Store TDD in memory throughout generation session
- Reference TDD for component structure, endpoints, models, file paths
- Use EXACT specifications from TDD (no guessing)

---

## How to Use

### Skills-Based Architecture (v2.0.0)

The AIDLC-axis plugin uses **auto-invoking skills** that respond to natural language. Simply describe what you want, and the appropriate skill will activate automatically.

### 1. UI Generation (axis-implement skill)

The axis-implement skill enforces Feature TDD-first workflow and auto-invokes for UI generation requests:

```bash
# UI Generation - Plugin will prompt for Feature TDD path
"Create a producer information form"
# axis-implement skill auto-invokes
# Plugin: "Please provide the Feature TDD file path (e.g., producer-information-ui-design.md)"
# User: "./docs/producer-info-tdd.md"
# Plugin reads TDD → Generates code with EXACT architecture/endpoints/models

# UI Generation with TDD path provided upfront
"Create registration form from ./docs/registration-tdd.md"

# If TDD file missing - Plugin asks 3 clarifying questions:
"Create claims dashboard"
# axis-implement skill auto-invokes
# Plugin: (file not found)
# Question 1: Repository structure (TDD Section 4.1)?
# Question 2: API endpoints (TDD Section 5.1)?
# Question 3: Component architecture (TDD Section 6.x)?
# Plugin constructs virtual TDD → Generates code

# Dynamic UI Generation (detected from TDD)
"Generate UI from ./output/client-information-UI-TDD.md"
# axis-implement detects DynamoDB patterns in TDD → Routes to dynamic-ui-generator

# Modify existing components
"Update the login form to add remember me checkbox"
```

### 2. Code Validation (axis-validate skill)

Validate Angular code against Axis framework guidelines:

```bash
# Validate specific file
"Validate my login component at src/app/login/login.component.ts"

# Validate directory
"Check code quality for src/app/forms/"

# Validate against source truth
"Validate my component against the UI-TDD spec"

# Accessibility audit
"Check accessibility compliance in src/app/dashboard/"
```

### 3. Test Generation (axis-test and axis-jasmine-test skills)

Generate comprehensive unit tests:

```bash
# General test generation
"Generate tests for src/app/user-profile/user-profile.component.ts"

# Comprehensive Jasmine tests with >80% coverage
"Generate comprehensive Jasmine tests for src/app/login/login.component.ts"
"Create detailed test suite with >80% coverage for my UserService"
```

### 4. Codebase Exploration (axis-explore skill)

Understand existing Angular/Axis code:

```bash
# Find components
"Find all components using axis-datagrid"

# Understand patterns
"How does authentication work in this codebase?"

# Compare implementations
"What's the difference between axis-dropdown and axis-dropdown-multiselect?"

# Documentation lookup
"Show me the API for axis-datepicker"
```

### 5. Component Documentation (axis-docs skill)

Access comprehensive API reference for 78 Axis components:

```bash
# Component properties
"What are the properties of axis-datagrid?"

# Usage examples
"How do I use axis-dropdown with search?"

# Event handlers
"What events does axis-button emit?"
```

### 6. Plugin Help (axis-help skill)

Get help with the plugin itself:

```bash
# General help
"Help me use the AIDLC-axis plugin"

# Available skills
"What skills are available in AIDLC-axis?"

# Component list
"Show me the Axis component list"
```

---

### Natural Language Benefits

✅ **No command syntax to remember** - Just describe what you want
✅ **Auto-invocation** - Skills activate based on context
✅ **More intuitive** - Conversational interaction
✅ **Better discoverability** - Skills explain themselves

---

### Migration from v1.x (Commands)

If you used the previous command-based version:

**Old Way (v1.x - Commands):**
```bash
/AIDLC-axis:implement Create a form
/AIDLC-axis:validate src/app/component.ts
/AIDLC-axis:test src/app/component.ts
```

**New Way (v2.x - Skills):**
```bash
Create a form with email and password fields
Validate the component at src/app/component.ts
Generate tests for src/app/component.ts
```

---

### Direct Agent Access (Advanced)

For advanced users, access specialized agents via Task tool with `subagent_type`:
- `AIDLC-axis:axis-ui-generator` - Static UI generation
- `AIDLC-axis:dynamic-ui-generator` - DynamoDB-driven UI
- `AIDLC-axis:axis-code-validator` - Code validation
- `AIDLC-axis:axis-test-generator` - Unit test generation
- `AIDLC-axis:axis-documentation` - Component docs
- `AIDLC-axis:axis-development-guide` - Conventions

---

## Component Categories

| Category | Count | Components |
|----------|-------|------------|
| **Form Controls** | 10 | button, checkbox, radio, input, dropdown, datepicker, timepicker, slider, rating, chip |
| **Layout** | 6 | accordion, card, tab, modal, bottom-sheet, carousel |
| **Navigation** | 6 | navbar, breadcrumb, paginator, portal-menu, progress-step, progress-tracker |
| **Charts** | 12 | donut, bar, line, gauge, funnel, bubble, area, horizontal-bar, horizontal-stacked, multi-bar-grouped, progress-chart, word-cloud |
| **Data Display** | 7 | datagrid, list, tree, styled-list, calendar, datamaps, date-range-picker |
| **Feedback** | 8 | alert, tooltip, loading, progress-bar, notifications, aqi, count, tour |
| **Advanced** | 13 | aug, file-upload, editor, search-address, search-account, duallist, captcha, bodymap, media, screen-capture, scroll-container, simple-feedback, truncate |
| **Utilities** | 11 | cache-service, can-deactivate, common-errors, customValidators, helper-functions, icon, idle-timer, json-translator, logger, okta-auth, timer |

**Total:** 78 Components

---

## Agent Compliance

All agents comply with **PLUGIN_DEVELOPMENT_GUIDE.md v2.0** with the following sections:

| Section | Description |
|---------|-------------|
| **Purpose** | 4-sentence role description |
| **Capabilities** | Categorized skill inventory |
| **Behavioral Traits** | 8-12 principle-based traits |
| **Guardrails** | Universal safety/security safeguards |
| **Quality Principles** | Operational standards (uncertainty, privacy, bias, consistency) |
| **Key Distinctions** | "vs [other-agent]" boundary definitions |

### Guardrails (Universal)

All agents block:
- Harmful content (violence, illegal, self-harm, discrimination)
- Rule circumvention (ignoring guidelines, overriding ethics)
- Inappropriate requests (sexual content, unethical behavior)
- Abusive language (profanity, insults, hate speech)
- Code-related security issues (injection, exploits, hardcoded secrets)
- System probing (internal prompts, operational details)

### Quality Principles (Per Agent)

All agents follow:
- **Admit Uncertainty**: "UNCERTAIN: Missing [X]. Required: [Y]."
- **Data Privacy**: Use placeholders `{USER_EMAIL}`, `{API_KEY}`, etc.
- **Bias Awareness**: Inclusive language, diverse examples
- **Output Consistency**: End with validation checklist
- **Deterministic Output**: Consistent results for same input
- **Fail-Safe Design**: Safe defaults, "TODO:" markers vs assumptions

---

## License

Internal use only.
