# AIDLC-axis Changelog

## **1.5.0**

### BREAKING CHANGES

- **Commands to Skills Migration**: Removed all slash commands, replaced with 6 auto-invoking skills (`axis-implement`, `axis-explore`, `axis-validate`, `axis-test`, `axis-jasmine-test`, `axis-help`) following agentskills.io specification. Users now interact using natural language instead of command syntax.

### Features

- **TDD Extractor Agent**: New `tdd-extractor` agent extracts TDD sections with semantic analysis, generating `generation-requirements.json` for reuse across agents. Reduces token usage by 93% (41,919 → <3,000 tokens) and eliminates 500+ lines of duplicate analysis.
- **Generator Token Optimization**: Refactored `axis-ui-generator` and `dynamic-ui-generator` to load pre-analyzed requirements instead of duplicating semantic analysis (-517 and -446 lines respectively). Total token reduction: 70-99% vs. loading full TDD files.
- **TypeScript Type Definitions**: Migrated `axis-types` skill from 61 .md files to 67 .types.ts files for better IDE integration.
- **Generation Patterns Enhancement**: Expanded `generation-patterns` skill from 286 to 1,233 lines with 9 new pattern sections (DynamoDB integration, async operations, dynamic forms, augRef helpers, workflows, state management, API integration, error handling, configuration).

### Performance

- 93% reduction in TDD extraction memory usage
- 57-98% token savings from section-based loading
- 30-50% additional savings from single-source semantic analysis
- Faster code generation with cached analysis

---

## **1.4.2** - 2026-01-29

### Agent Awareness Enhancement: Comprehensive Helper/Service Reference (US771359)

**CRITICAL UPDATE**: Enhanced axis-ui-generator and dynamic-ui-generator agents with comprehensive functionality awareness across all 8 axis-types categories to prevent code duplication and ensure proper helper/service reuse.

#### Key Improvements

1. **Available Functionality Reference Section** (NEW)
   - Comprehensive listing of 150+ helpers, services, and utilities across 8 categories
   - "When to use" and "When NOT to reimplement" guidance for each category
   - Prevents agents from reimplementing existing functionality (e.g., AUGHelper.setData(), AxisDatagridService.update())

2. **Rule 8: Pattern Enforcement** (NEW - axis-ui-generator) / **Rule 7** (NEW - dynamic-ui-generator)
   - 6 established pattern examples with ✅ correct vs. ❌ wrong usage
   - Patterns: Form manipulation, component props, observable state, cache-first, service config, lazy loading
   - Code examples showing proper vs. improper implementation

3. **Step 0: Check for Existing Functionality** (NEW)
   - Mandatory pre-implementation workflow step
   - Decision tree: use existing vs. implement new
   - Search guidance for specific helper files across all 8 type categories

4. **Enhanced Quality Checklist**
   - New "Helper/Service Usage Validation (ALL Categories)" section
   - 9 validation checkpoints across all type categories
   - Anti-pattern detection (e.g., formGroup.patchValue() → should use AUGHelper.setData())

5. **Enhanced Post-Generation Audit**
   - Step 2 now includes helper/service usage audit
   - Anti-pattern scanning for missing helper usage
   - Proper import verification from all 8 axis-types packages

#### Coverage Across 8 Type Categories

| Category | Helpers/Services Documented | Impact |
|----------|----------------------------|--------|
| **axis-ui-generator-types** | 25+ helper methods | Form manipulation, state management |
| **axis-components-types** | Base interfaces, 90+ constants | Component props, UI strings |
| **axis-charts-types** | 5 chart utilities | Tooltip positioning, accessibility |
| **axis-datagrid-types** | 20+ service operations | Grid state, virtual scrolling, export |
| **axis-abc-portal-menu-types** | State observables, menu ops | Navigation, notifications, permissions |
| **axis-abc-search-account-types** | API operations, HTTP utilities | Service config, retry/cache patterns |
| **axis-abc-search-address-types** | Google Maps service | Lazy loading, geocoding |
| **axis-notification-types** | Notification service, cache-first | Polling, background rehydration |

#### Benefits

- **Reduces code duplication** - Agents reuse existing helpers instead of reimplementing
- **Maintains internal consistency** - Using official services preserves internal state management
- **Improves code quality** - Following established patterns ensures consistency
- **Prevents bugs** - Reimplementing form manipulation or grid state management often breaks internal state
- **Faster development** - Agents find existing solutions instead of building new ones

#### Files Modified

- `plugins/AIDLC-axis/agents/axis-ui-generator.md` - 5 major sections added/updated
- `plugins/AIDLC-axis/agents/dynamic-ui-generator.md` - 5 major sections added/updated

---

## **1.4.1** - 2026-01-29

### axis-types Skill Documentation Migration

- **axis-types skill**: Migrated documentation from 61 markdown (.md) to 67 TypeScript (.ts) type definition files
- **SKILL.md**: Refactored all 8 category sections (54+ references) to use markdown links with descriptive text
- **Agent documentation**: Updated axis-ui-generator.md, dynamic-ui-generator.md, AXIS-UI-GENERATOR-GUIDE.md to reference .types.ts files
- **Documentation structure**: Improved progressive disclosure with Essential/Configuration/Advanced categorization
- **Plugin registration**: Registered axis-types skill in plugin.json for proper skill invocation
- **Link format**: Changed from Read() instructions to markdown links: `- **[Name](./path/to/file.types.ts)** - Description`

---

## **1.4.0** - 2026.PI1.Iteration1 (2026-01-22)

**Sprint Period**: January 8 - January 22, 2026

### AXIS UI Generator Improvements (F116883: Fix AXIS JSON-Driven Architecture Compliance)

- **US778836**: Incorporate AXIS library documentation and type definitions - TypeScript type definitions for all 78 AXIS components
  (Form Controls, Layout, Navigation, Charts, Advanced) and helper functions integrated into agent context
- **US782974**: Ask user how they want nested components structured - Interactive clarification workflow for component structure preferences,
  TDD Section 6.x pattern detection, default to single component with nested arrays
- **US782975**: Create TypeScript interfaces from JSON schemas - Schema-to-TypeScript conversion for generation guidance,
  accordion/nested array/action button patterns documented
- **US782976**: Document AXIS framework helper classes and services - Complete AUG._helper methods documentation with type definitions,
  usage examples for data transformation/validation/formatting
- **US782977**: Generate event-driven patterns - uiEmitChange and FormService integration patterns, validation to prevent direct Angular event handlers
- **US782979**: Prompt for Feature TDD and ask clarifying questions - Router prompts for Feature TDD path, asks clarifying questions about
  architecture/endpoints/patterns when TDD missing
- **US782981**: Discover and prioritize shared components - Codebase search for common-* and shared-* components, catalog with usage patterns,
  prioritize reuse over generation

### Bug Fixes (F116885: Plugin Development Automation)

- **US777816**: Fix agents claiming files written without Write tool - Added OPERATIONAL_CONSTRAINT to always use Write tool,
  guardrails against describing writes without tool invocation, validation across all generator agents

---

## 2025/2026IterationIP v1.3.0 (2026-01-09)

### Performance & Features

- **US774964**: Optimize AIDLC-axis Plugin for Token Efficiency and Speed - 41% token reduction (1.15M→679K), 18% faster execution (512s→419s), 37% cost reduction
- **US777742**: Enable Dynamic UI Generation with AUG Component and JSON Configuration - AXIS UI Generator, POM Mapping, JSON-Driven Forms, Minimal Components, Dynamic Rendering

---

## 2025.PI5.Iteration4

### AXIS Angular Agent

- **US767695**: Scrape the AUT Documentation site to extract JSON schemas for AI
- **US769372**: Agent should also generate the JSON representation of the component
- **US769375**: Agent should apply validation rules as needed
- **DE247743**: (Fixed) Generated code is missing config.json in ui-components-service causing runtime failure
- **DE247744**: (Fixed) Generated code creates Inconsistent logger implementation - function vs class-based approaches
- **DE247745**: (Fixed) Different error handling approaches across services

---

## **1.2.0** - Release version 1.2.0 (2025-12-18)

- Changed All Tests For Axis Plugin To Use new slash Commands
- Axis: Initial Tickets Feedback Changes
- Added Jasmine Unit Test Sub Agents For AIDLC-Axis Plugin
