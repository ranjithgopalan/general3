# Axis UI Generator Type Safety Reference

**Purpose**: Comprehensive type safety rules for generating Angular code with axis-ui-generator

**Mandatory Reading**: Read this document BEFORE generating any code that uses `<axis-ui-generator>`

---

## Critical Principle

**NEVER use `any` types when working with axis-ui-generator components.**

All types are available in the `axis-ui-generator-types` package. Import them, don't redefine them.

---

## Rule 1: Never Redefine Types from axis-ui-generator-types

**Problem**: Local type redefinitions lose discriminated unions and proper typing from the official package.

### ❌ PROHIBITED

```typescript
// DON'T redefine UIStructure locally in model.ts
export interface UIStructure {
  sections: { [key: string]: UISection };
}

// DON'T redefine UISection, UIField, UIControl, etc.
export interface UISection {
  fields?: UIField[];
}

export interface UIControl {
  name: string;
  type: string;
}
```

### ✅ REQUIRED

```typescript
// ALWAYS import from official package
import {
  UIStructure,
  UIControl,
  UISection,
  ContainerControl,
  TextControl,
  ButtonControl,
  DropdownControl,
  UIEmitEvent,
  UIEmitUpdateEvent,
  AUGHelper
} from 'axis-ui-generator-types';

// Use imported types directly - never redefine them
export class MyComponent {
  uiStructure: UIStructure | null = null;
  private augRef: { _helper: AUGHelper } | null = null;
}
```

**Rationale**: Local type redefinitions force you to use `any` when traversing sections and fields because you lose the official type system's discriminated unions.

---

## Rule 2: No 'any' Types for AUG Properties

**Problem**: Using `any` defeats type safety and prevents IntelliSense.

### ❌ PROHIBITED

```typescript
private augRef: any;
uiStructure: any;
uiData: any;

clientInfoEmitUpdate(event: any): void { }

handleFieldChange(fieldName: string, newValue: any): void { }

findField(name: string): any {
  // Returns any, no type safety
}
```

### ✅ REQUIRED

```typescript
import { AUGHelper, UIEmitUpdateEvent, UIStructure, UIControl } from 'axis-ui-generator-types';

// Properly typed augRef
private augRef: { _helper: AUGHelper } | null = null;

// Properly typed structure
uiStructure: UIStructure | null = null;

// Properly typed data
uiData: Record<string, unknown> = {};

// Properly typed event handler
clientInfoEmitUpdate(event: UIEmitUpdateEvent): void {
  const { fieldName, newValue, eventName } = event.eventInfo;
  // TypeScript knows the event structure
}

// Use 'unknown' for dynamic values, then type guard
handleFieldChange(fieldName: string, newValue: unknown): void {
  if (typeof newValue === 'string') {
    // Now TypeScript knows newValue is string
    this.processStringValue(newValue);
  }
}

// Return proper type
findField(name: string): UIControl | null {
  // Returns UIControl, enabling type-safe property access
}
```

**Rationale**: Proper typing enables IntelliSense, compile-time error detection, and prevents runtime type errors.

---

## Rule 3: Type Field Lookups Properly

**Problem**: Using `any` casts loses type information when traversing UI structure.

### ❌ PROHIBITED

```typescript
private findField(name: string): any {
  for (const section of Object.values(this.uiStructure.sections)) {
    const fields = (section as any).fields || (section as any).data?.fields;
    return fields.find((f: any) => f.name === name);
  }
}

// Later usage - no type safety
const field = this.findField('email');
field.value = 'test';  // No error if 'value' doesn't exist!
```

### ✅ REQUIRED

```typescript
import { UIControl, ContainerControl } from 'axis-ui-generator-types';

private findField(name: string): UIControl | null {
  if (!this.uiStructure?.sections) return null;

  for (const section of Object.values(this.uiStructure.sections)) {
    // Type as ContainerControl to access fields
    const container = section as ContainerControl;
    const fields: UIControl[] = container.data?.fields || container.fields || [];

    const field = fields.find(f => f.name === name);
    if (field) return field;
  }

  return null;
}

// Later usage - type safe!
const field = this.findField('email');
if (field && 'value' in field) {
  field.value = 'test';  // TypeScript validates 'value' exists
}
```

**Rationale**: Returns proper `UIControl` type instead of `any`, enabling type-safe access to control properties.

---

## Rule 4: Use 'unknown' Instead of 'any' for Dynamic Values

**Problem**: `any` allows any operation without checking, leading to runtime errors.

### ❌ PROHIBITED

```typescript
handleFieldDependencies(fieldName: string, newValue: any): void {
  // No type checking - runtime error if newValue is not a string
  if (fieldName === 'sic' && newValue) {
    this.service.getSubSicBySic(newValue).subscribe(...);
  }

  // No type checking - could pass wrong type
  this.updateRelatedField(newValue);
}
```

### ✅ REQUIRED

```typescript
handleFieldDependencies(fieldName: string, newValue: unknown): void {
  // Use type guards for type safety
  if (fieldName === 'sic' && typeof newValue === 'string' && newValue) {
    // Now TypeScript knows newValue is string
    this.service.getSubSicBySic(newValue).subscribe(...);
  }

  if (fieldName === 'quantity' && typeof newValue === 'number') {
    // TypeScript knows newValue is number
    this.calculateTotal(newValue);
  }

  if (fieldName === 'items' && Array.isArray(newValue)) {
    // TypeScript knows newValue is array
    this.processItems(newValue);
  }
}
```

**Common Type Guards**:
```typescript
// String check
if (typeof value === 'string') { }

// Number check
if (typeof value === 'number') { }

// Boolean check
if (typeof value === 'boolean') { }

// Array check
if (Array.isArray(value)) { }

// Object check (non-null)
if (typeof value === 'object' && value !== null) { }

// Date check
if (value instanceof Date) { }
```

**Rationale**: `unknown` forces you to use type guards, preventing accidental misuse of dynamic values.

---

## Rule 5: Type All Service Returns

**Problem**: Untyped observables lose type information, preventing compile-time checks.

### ❌ PROHIBITED

```typescript
saveData(data: any): Observable<any> {
  return this.http.post(url, data);
}

submitForm(payload: FormData): Observable<any> {
  return this.http.post(url, payload);
}

// Usage - no type safety
this.service.saveData(data).subscribe(response => {
  console.log(response.id);  // Could be undefined!
  console.log(response.sucess);  // Typo not caught!
});
```

### ✅ REQUIRED

```typescript
// Define response interfaces
export interface SaveResponse {
  success: boolean;
  id: string;
  timestamp: string;
  message?: string;
}

export interface SubmitResponse {
  success: boolean;
  clientId: string;
  clientNumber: string;
  message?: string;
}

// Type the observables
saveData(data: Record<string, unknown>): Observable<SaveResponse> {
  return this.http.post<SaveResponse>(url, data);
}

submitForm(payload: SubmitRequest): Observable<SubmitResponse> {
  return this.http.post<SubmitResponse>(url, payload);
}

// Usage - fully type safe!
this.service.saveData(data).subscribe(response => {
  console.log(response.id);  // TypeScript knows 'id' exists as string
  // response.sucess would be caught as error (property doesn't exist)
});
```

**Rationale**: Typed observables provide compile-time checking of response usage and enable IntelliSense for response properties.

---

## Rule 6: Invoke axis-types Skill FIRST (MANDATORY)

**Critical First Step**: Before generating ANY code that uses axis-ui-generator.

### Required Action

```typescript
// Option 1: Invoke the skill (RECOMMENDED)
Skill(skill: "AIDLC-axis:axis-types")

// Option 2: Read specific type files
Read(file_path: "plugins/AIDLC-axis/skills/axis-types/axis-ui-generator-types/ui-structure.types.ts")
Read(file_path: "plugins/AIDLC-axis/skills/axis-types/axis-ui-generator-types/helper.types.ts")
Read(file_path: "plugins/AIDLC-axis/skills/axis-types/axis-ui-generator-types/control.types.ts")
Read(file_path: "plugins/AIDLC-axis/skills/axis-types/axis-ui-generator-types/event.types.ts")
```

### Verification Steps

Before generating code, verify:

1. ✅ axis-types skill invoked OR type files read
2. ✅ Understand all types being used (UIStructure, AUGHelper, UIControl, etc.)
3. ✅ Know which types to import for the component being generated
4. ✅ Verify no local type redefinitions will be created

**Rationale**: The axis-types skill provides the complete, official type system. Using it prevents type redefinitions and ensures correct typing throughout.

---

## Rule 7: Follow Established Patterns

When using functionality from axis-types categories, follow established patterns.

### Pattern 1: Form Manipulation (axis-ui-generator-types)

```typescript
// ✅ CORRECT - Use AUGHelper
this.augRef._helper.setData('fieldName', newValue, 'myInstance');
this.augRef._helper.refreshElement({ elementName: 'fieldName', AUGinstance: 'myInstance' });

// ❌ WRONG - Direct form access
this.formGroup.patchValue({ fieldName: newValue });
this.formGroup.controls['fieldName'].setValue(newValue);
```

### Pattern 2: Component Props (axis-components-types)

```typescript
// ✅ CORRECT - Extend base interfaces
import { BaseComponentProps, ComponentConstants } from 'axis-components-types';

interface MyComponentProps extends BaseComponentProps {
  customProp: string;
}

const labels = ComponentConstants; // Use provided constants

// ❌ WRONG - Redefine props
interface MyComponentProps {
  ariaLabel?: string; // Already in BaseComponentProps!
  disabled?: boolean; // Already in BaseComponentProps!
}

const SAVE_LABEL = 'Save'; // Use ComponentConstants.save instead
```

### Pattern 3: Observable State (axis-datagrid-types)

```typescript
// ✅ CORRECT - Subscribe to observables
this.gridService.getRows('myGrid').subscribe(rows => {
  this.displayRows = rows; // Pre-filtered, sorted, paginated
});

// ❌ WRONG - Direct access
this.displayRows = this.allRows.filter(...).sort(...); // Use service!
```

---

## Common Import Patterns

### For Components Using axis-ui-generator

```typescript
import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AxisUiGeneratorAllModule, FormService } from 'axis-ui-generator';
import {
  UIStructure,
  UIControl,
  UIEmitEvent,
  UIEmitUpdateEvent,
  AUGHelper
} from 'axis-ui-generator-types';
```

### For Services

```typescript
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import {
  UIStructure,
  UIComponentCatalogResponse
} from 'axis-ui-generator-types';
```

### For Models

```typescript
import {
  UIStructure,
  UIControl,
  UIData,
  UIEmitUpdateEvent,
  UIEmitEvent
} from 'axis-ui-generator-types';

// Define domain-specific interfaces
export interface ClientSearchParams {
  partyName?: string;
  partyNumber?: string;
}

// Never redefine UIStructure, UIControl, etc.
```

---

## Validation Checklist

Before writing any files, verify:

- [ ] No local UIStructure/UIControl/UISection redefinitions
- [ ] No `any` types for augRef (must be `{ _helper: AUGHelper } | null`)
- [ ] No `any` types for uiStructure (must be `UIStructure | null`)
- [ ] No `any` types for events (must be `UIEmitUpdateEvent` or `UIEmitEvent`)
- [ ] Service returns are typed (Observable<ResponseInterface>)
- [ ] Dynamic values use `unknown` with type guards, not `any`
- [ ] All imports are from `axis-ui-generator-types` package
- [ ] axis-types skill was invoked before generation

---

## Quick Reference

### Correct Type Declarations

```typescript
// Component properties
private augRef: { _helper: AUGHelper } | null = null;
uiStructure: UIStructure | null = null;
uiData: Record<string, unknown> = {};

// Event handlers
onAugRef(ref: { _helper: AUGHelper }): void { }
clientInfoEmitUpdate(event: UIEmitUpdateEvent): void { }
onFormSubmit(event: UIEmitEvent): void { }

// Field lookup
findField(name: string): UIControl | null { }

// Service methods
getData(): Observable<MyResponse> { }
saveData(data: MyRequest): Observable<SaveResponse> { }
```

### Common Type Imports

```typescript
// Core types
import { UIStructure, UIControl, UISection, UIData } from 'axis-ui-generator-types';

// Helper types
import { AUGHelper, AddElementConfig, RefreshElementConfig } from 'axis-ui-generator-types';

// Event types
import { UIEmitEvent, UIEmitUpdateEvent, ContentRequest } from 'axis-ui-generator-types';

// Control types
import { ContainerControl, TextControl, ButtonControl, DropdownControl } from 'axis-ui-generator-types';
```

---

## Further Reading

- **axis-types skill**: Invoke for complete type system reference
- **AXIS-UI-GENERATOR-GUIDE.md**: Usage patterns and examples
- **axis-ui-generator-types source**: `plugins/AIDLC-axis/skills/axis-types/axis-ui-generator-types/`

---

**Last Updated**: 2026-02-02
**Version**: 1.0.0
