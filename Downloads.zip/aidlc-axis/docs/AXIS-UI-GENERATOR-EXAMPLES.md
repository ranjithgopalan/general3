# Axis UI Generator - Usage Examples

> Complete working examples for common AUG scenarios

**Main Guide:** [AXIS-UI-GENERATOR-GUIDE.md](./AXIS-UI-GENERATOR-GUIDE.md)

---

## Table of Contents

1. [Basic Setup](#basic-setup)
2. [Advanced Form with Conditional Fields](#advanced-form-with-conditional-fields)
3. [uiEmitUpdate Event Handling Patterns](#uiemitupdate-event-handling-patterns)
   - [Pattern 1: Cascade Dropdowns with setData()](#pattern-1-cascade-dropdowns-with-setdata)
   - [Pattern 2: Auto-Save Draft (Debounced)](#pattern-2-auto-save-draft-debounced)
   - [Pattern 3: Cross-Field Validation](#pattern-3-cross-field-validation)
   - [Pattern 4: Debounced API Lookup](#pattern-4-debounced-api-lookup)
   - [Pattern 5: DOM Manipulation - Scroll to Error](#pattern-5-dom-manipulation---scroll-to-error)
   - [Pattern 6: Complex Business Logic with Multiple Updates](#pattern-6-complex-business-logic-with-multiple-updates)
   - [Best Practices](#uiemitupdate-best-practices)
4. [Dynamic Field Manipulation](#dynamic-field-manipulation)
5. [Working with FormService Directly](#working-with-formservice-directly)
6. [Multi-Step Wizard Form](#multi-step-wizard-form)
7. [Using Translation](#using-translation)

---

## Usage Examples

### Basic Setup

#### 1. Import Required Modules

```typescript
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormService } from 'axis-ui-generator';

@Component({
  selector: 'app-my-form',
  templateUrl: './my-form.component.html',
  styleUrls: ['./my-form.component.scss']
})
export class MyFormComponent implements OnInit, OnDestroy {
  public uiData = {};
  public uiStructure: any;
  public refresh = {};
  private augRef: any;

  constructor(private formService: FormService) {}

  ngOnInit(): void {
    this.uiStructure = {
      id: 'myFormInstance',
      layout: {
        type: 'basic',
        slots: { main: ['mainSection'] }
      },
      sectionsOrder: ['mainSection'],
      sections: {
        mainSection: {
          type: 'container',
          name: 'main_container',
          fields: [
            {
              type: 'text',
              name: 'firstName',
              label: 'First Name',
              inputType: 'text',
              validators: { required: true }
            },
            {
              type: 'text',
              name: 'lastName',
              label: 'Last Name',
              inputType: 'text',
              validators: { required: true }
            },
            {
              type: 'text',
              name: 'email',
              label: 'Email',
              inputType: 'email',
              validators: {
                required: true,
                pattern: '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$'
              }
            }
          ]
        }
      }
    };
  }

  onAugRef(ref: any): void {
    this.augRef = ref;
  }

  onSubmit(event: any): void {
    if (event?.form?.model?.valid) {
      console.log('Form is valid', event.form.model.value);
      // Handle form submission
    } else {
      console.log('Form is invalid');
    }
  }

  onUpdate(event: any): void {
    console.log('Field updated:', event);
  }

  ngOnDestroy(): void {
    if (this.uiData) {
      this.uiData = {};
    }
  }
}
```

#### 2. Template

```html
<axis-ui-generator
  [uiStructure]="uiStructure"
  [uiData]="uiData"
  [refresh]="refresh"
  (uiEmit)="onSubmit($event)"
  (uiEmitUpdate)="onUpdate($event)"
  (augRef)="onAugRef($event)">
</axis-ui-generator>
```

### Advanced Form with Conditional Fields

```typescript
ngOnInit(): void {
  this.uiStructure = {
    id: 'conditionalFormInstance',
    layout: {
      type: 'basic',
      slots: { main: ['mainSection'] }
    },
    sectionsOrder: ['mainSection'],
    sections: {
      mainSection: {
        type: 'container',
        name: 'main_container',
        fields: [
          {
            type: 'radio',
            name: 'hasInsurance',
            label: 'Do you have insurance?',
            dataProvider: [
              { label: 'Yes', value: true },
              { label: 'No', value: false }
            ],
            validators: { required: true }
          },
          {
            type: 'text',
            name: 'insuranceProvider',
            label: 'Insurance Provider',
            inputType: 'text',
            displayIf: [
              {
                source: 'hasInsurance',
                comparison: 'equal',
                value: true
              }
            ],
            validators: { required: true }
          },
          {
            type: 'text',
            name: 'policyNumber',
            label: 'Policy Number',
            inputType: 'text',
            displayIf: [
              {
                source: 'hasInsurance',
                comparison: 'equal',
                value: true
              }
            ]
          }
        ]
      }
    }
  };
}
```

### uiEmitUpdate Event Handling Patterns

The `uiEmitUpdate` event fires on **EVERY field change**. Use it for real-time business logic, validation, dependent field updates, and complex workflows. This section provides production-ready patterns for common scenarios.

#### Pattern 1: Cascade Dropdowns with setData()

**Use Case:** When a parent dropdown changes (e.g., State), update child dropdown options (e.g., City) and clear the child's value.

```typescript
onUpdate(event: UIEmitUpdateEvent): void {
  const { fieldName, newValue } = event.eventInfo;

  // When state changes, update city options and clear city value
  if (fieldName === 'state' && this.augRef) {
    // Step 1: Clear dependent field value using setData()
    this.augRef._helper.setData('city', '', 'myFormInstance');

    // Step 2: Update city dropdown options
    const cityField = this.findFieldInStructure('city');
    if (cityField) {
      cityField.dataProvider = this.getCitiesByState(newValue as string);

      // Step 3: Refresh the dropdown to show new options
      this.augRef._helper.refreshElement({
        elementName: 'city',
        AUGinstance: 'myFormInstance'
      });
    }
  }

  // When SIC code changes, update Sub-SIC options
  if (fieldName === 'sic' && newValue && this.augRef) {
    this.augRef._helper.setData('subSic', '', 'myFormInstance');

    // Fetch Sub-SIC options from API
    this.service.getSubSicOptions(newValue as string).subscribe(options => {
      const subSicField = this.findFieldInStructure('subSic');
      if (subSicField && this.augRef) {
        subSicField.dataProvider = options;
        this.augRef._helper.refreshElement({
          elementName: 'subSic',
          AUGinstance: 'myFormInstance'
        });
      }
    });
  }
}

// Helper method to find field in structure
private findFieldInStructure(fieldName: string): any {
  if (!this.uiStructure?.sections) return null;

  for (const section of Object.values(this.uiStructure.sections)) {
    const fields = (section as any).fields || (section as any).data?.fields || [];
    const field = fields.find((f: any) => f.name === fieldName);
    if (field) return field;
  }
  return null;
}
```

**Key Points:**
- Use `setData()` to clear dependent field values
- Update `dataProvider` directly in uiStructure
- Call `refreshElement()` to trigger UI update
- Handle async data fetching from APIs

---

#### Pattern 2: Auto-Save Draft (Debounced)

**Use Case:** Automatically save form data as draft after user stops typing for 2 seconds.

```typescript
private autoSaveTimeout: any;
private readonly AUTO_SAVE_DELAY = 2000; // 2 seconds

onUpdate(event: UIEmitUpdateEvent): void {
  // Debounce auto-save to avoid excessive API calls
  if (this.autoSaveTimeout) {
    clearTimeout(this.autoSaveTimeout);
  }

  this.autoSaveTimeout = setTimeout(() => {
    this.performAutoSave(event);
  }, this.AUTO_SAVE_DELAY);
}

private performAutoSave(event: UIEmitUpdateEvent): void {
  // Only save if form is valid (or save with validation errors flagged)
  if (event.form?.model?.valid) {
    const draftData = {
      componentId: 'myFormInstance',
      formData: event.uiData,
      savedAt: new Date().toISOString(),
      isValid: true
    };

    this.service.saveDraft(draftData).subscribe({
      next: () => {
        console.log('Draft saved successfully');
        // Optional: Show subtle notification
        this.showAutoSaveIndicator();
      },
      error: (error) => {
        console.error('Auto-save failed:', error);
        // Silent failure for auto-save
      }
    });
  } else {
    // Save even if invalid, but flag it
    const draftData = {
      componentId: 'myFormInstance',
      formData: event.uiData,
      savedAt: new Date().toISOString(),
      isValid: false,
      validationErrors: this.getValidationErrors(event.form.model)
    };

    this.service.saveDraft(draftData).subscribe();
  }
}

private getValidationErrors(formModel: FormGroup): string[] {
  const errors: string[] = [];
  Object.keys(formModel.controls).forEach(key => {
    if (formModel.controls[key].invalid) {
      errors.push(`${key}: ${JSON.stringify(formModel.controls[key].errors)}`);
    }
  });
  return errors;
}

ngOnDestroy(): void {
  // Clear timeout on component destroy
  if (this.autoSaveTimeout) {
    clearTimeout(this.autoSaveTimeout);
  }

  // Clean up FormService
  this.formService.clearFormData('myFormInstance', null);
}
```

**Key Points:**
- Use `setTimeout()` with clearTimeout for debouncing
- Save both valid and invalid states (with flags)
- Handle errors silently for auto-save
- Clean up timeout in ngOnDestroy

---

#### Pattern 3: Cross-Field Validation

**Use Case:** Validate that Effective Date is before Expiration Date, or that End Date is after Start Date.

```typescript
onUpdate(event: UIEmitUpdateEvent): void {
  const { fieldName } = event.eventInfo;

  // Validate date range when either date changes
  if ((fieldName === 'effectiveDate' || fieldName === 'expirationDate') && this.augRef) {
    this.validateDateRange(event);
  }

  // Validate that coverage amount doesn't exceed policy limit
  if ((fieldName === 'coverageAmount' || fieldName === 'policyLimit') && this.augRef) {
    this.validateCoverageLimits(event);
  }
}

private validateDateRange(event: UIEmitUpdateEvent): void {
  const effectiveDate = event.form.data.effectiveDate;
  const expirationDate = event.form.data.expirationDate;

  if (effectiveDate && expirationDate) {
    const effective = new Date(effectiveDate);
    const expiration = new Date(expirationDate);

    if (effective >= expiration) {
      // Show error using FormService
      const control = this.formService.Form['myFormInstance']?.['mainForm']?.get('expirationDate');
      if (control) {
        control.setErrors({ dateRange: 'Expiration date must be after effective date' });
        control.markAsTouched();

        // Trigger change detection
        this.formService.detectChanges.next();
      }

      // Scroll to error field
      if (this.augRef) {
        this.augRef._helper.fnScrollToElem('expirationDate', 100);
      }
    } else {
      // Clear error if valid
      const control = this.formService.Form['myFormInstance']?.['mainForm']?.get('expirationDate');
      if (control?.hasError('dateRange')) {
        const errors = { ...control.errors };
        delete errors['dateRange'];
        control.setErrors(Object.keys(errors).length > 0 ? errors : null);
      }
    }
  }
}

private validateCoverageLimits(event: UIEmitUpdateEvent): void {
  const coverageAmount = parseFloat(event.form.data.coverageAmount) || 0;
  const policyLimit = parseFloat(event.form.data.policyLimit) || 0;

  if (coverageAmount > policyLimit) {
    const control = this.formService.Form['myFormInstance']?.['mainForm']?.get('coverageAmount');
    if (control) {
      control.setErrors({
        exceedsLimit: `Coverage amount cannot exceed policy limit of $${policyLimit.toLocaleString()}`
      });
      control.markAsTouched();
      this.formService.detectChanges.next();
    }
  }
}
```

**Key Points:**
- Check multiple related fields
- Set custom errors using FormControl.setErrors()
- Use `formService.detectChanges.next()` to update UI
- Scroll to error fields with `fnScrollToElem()`
- Clear errors when validation passes

---

#### Pattern 4: Debounced API Lookup

**Use Case:** Look up city and state from zip code, or company details from tax ID.

```typescript
private lookupTimeout: any;
private readonly LOOKUP_DELAY = 500; // 500ms delay

onUpdate(event: UIEmitUpdateEvent): void {
  const { fieldName, newValue } = event.eventInfo;

  // Debounced zip code lookup
  if (fieldName === 'zipCode' && this.augRef) {
    this.debouncedZipLookup(newValue as string);
  }

  // Debounced company lookup by tax ID
  if (fieldName === 'taxId' && (newValue as string).length >= 9 && this.augRef) {
    this.debouncedCompanyLookup(newValue as string);
  }
}

private debouncedZipLookup(zipCode: string): void {
  // Clear previous timeout
  if (this.lookupTimeout) {
    clearTimeout(this.lookupTimeout);
  }

  // Validate zip code format (5 digits)
  if (!/^\d{5}$/.test(zipCode)) {
    return;
  }

  // Show loading indicator
  this.isLookingUp = true;

  this.lookupTimeout = setTimeout(() => {
    this.service.lookupCityState(zipCode).subscribe({
      next: (result) => {
        if (this.augRef && result) {
          // Auto-populate city and state
          this.augRef._helper.setData('city', result.city, 'myFormInstance');
          this.augRef._helper.setData('state', result.state, 'myFormInstance');
          this.augRef._helper.setData('country', result.country || 'US', 'myFormInstance');

          // Trigger conditional logic if city/state affect other fields
          this.augRef._helper.updateFieldsConditionally({
            source: { name: 'state', AUGinstance: 'myFormInstance' },
            event: 'displayIf'
          });
        }
        this.isLookingUp = false;
      },
      error: (error) => {
        console.error('Zip lookup failed:', error);
        this.isLookingUp = false;
        // Don't show error for failed lookups - user can enter manually
      }
    });
  }, this.LOOKUP_DELAY);
}

private debouncedCompanyLookup(taxId: string): void {
  if (this.lookupTimeout) {
    clearTimeout(this.lookupTimeout);
  }

  this.isLookingUp = true;

  this.lookupTimeout = setTimeout(() => {
    this.service.lookupCompanyByTaxId(taxId).subscribe({
      next: (company) => {
        if (this.augRef && company) {
          // Auto-populate company details
          this.augRef._helper.setData('companyName', company.name, 'myFormInstance');
          this.augRef._helper.setData('companyAddress', company.address, 'myFormInstance');
          this.augRef._helper.setData('companyPhone', company.phone, 'myFormInstance');

          // Show confirmation to user
          this.showNotification(`Company found: ${company.name}`);
        }
        this.isLookingUp = false;
      },
      error: (error) => {
        console.error('Company lookup failed:', error);
        this.isLookingUp = false;
      }
    });
  }, this.LOOKUP_DELAY);
}

ngOnDestroy(): void {
  if (this.lookupTimeout) {
    clearTimeout(this.lookupTimeout);
  }
  this.formService.clearFormData('myFormInstance', null);
}
```

**Key Points:**
- Debounce API calls to reduce server load
- Validate input before making API call
- Show loading indicators during lookup
- Handle errors gracefully (silent or user-friendly)
- Use `setData()` for all auto-populated fields
- Trigger conditional logic with `updateFieldsConditionally()`

---

#### Pattern 5: DOM Manipulation - Scroll to Error

**Use Case:** After validation failure, scroll to the first error field and focus it.

```typescript
onUpdate(event: UIEmitUpdateEvent): void {
  const { fieldName } = event.eventInfo;

  // Real-time validation check
  if (fieldName && this.shouldValidateField(fieldName)) {
    this.validateFieldAndScroll(event, fieldName);
  }
}

private shouldValidateField(fieldName: string): boolean {
  // Only validate certain fields in real-time
  const realTimeValidationFields = ['email', 'phone', 'zipCode', 'taxId'];
  return realTimeValidationFields.includes(fieldName);
}

private validateFieldAndScroll(event: UIEmitUpdateEvent, fieldName: string): void {
  const control = event.form.model.controls[fieldName];

  if (control?.invalid && control.touched) {
    // Wait for DOM to update
    setTimeout(() => {
      // Find the error element
      const errorField = document.querySelector(`[name="${fieldName}"]`);
      const errorMessage = document.querySelector(`#${fieldName}-error`);

      if (errorField && this.augRef) {
        // Scroll to field with offset for fixed headers
        this.augRef._helper.fnScrollToElem(
          errorField as HTMLElement,
          100, // offset in pixels
          300, // duration in ms
          true, // smooth scroll
          'smooth' // scroll behavior
        );

        // Focus the field
        (errorField as HTMLElement).focus();

        // Highlight error message
        if (errorMessage) {
          errorMessage.classList.add('axis-error-highlight');
          setTimeout(() => {
            errorMessage.classList.remove('axis-error-highlight');
          }, 2000);
        }
      }
    }, 100);
  }
}

// On form submit, scroll to first error
onSubmit(event: UIEmitEvent): void {
  if (event.form?.model?.invalid) {
    // Mark all as touched
    Object.keys(event.form.model.controls).forEach(key => {
      event.form.model.controls[key].markAsTouched();
    });

    // Trigger change detection
    this.formService.detectChanges.next();

    // Find first invalid field
    const firstInvalidField = Object.keys(event.form.model.controls).find(
      key => event.form.model.controls[key].invalid
    );

    if (firstInvalidField && this.augRef) {
      setTimeout(() => {
        const fieldElement = document.querySelector(`[name="${firstInvalidField}"]`);
        if (fieldElement) {
          this.augRef._helper.fnScrollToElem(fieldElement as HTMLElement, 100);
          (fieldElement as HTMLElement).focus();
        }
      }, 150);
    }

    return;
  }

  // Submit form if valid
  this.submitForm(event.form.data);
}
```

**Key Points:**
- Use `fnScrollToElem()` with proper offset for fixed headers
- Focus the field after scrolling
- Highlight error messages temporarily
- Handle both real-time and submit validation
- Use setTimeout for DOM updates

---

#### Pattern 6: Complex Business Logic with Multiple Updates

**Use Case:** When policy type changes, recalculate premium, update coverage options, show/hide sections, and validate eligibility.

```typescript
onUpdate(event: UIEmitUpdateEvent): void {
  const { fieldName, newValue, oldValue } = event.eventInfo;

  // Complex workflow when policy type changes
  if (fieldName === 'policyType' && this.augRef) {
    this.handlePolicyTypeChange(event, newValue as string, oldValue);
  }

  // When coverage changes, update premium
  if (fieldName === 'coverage' && this.augRef) {
    this.recalculatePremium(event);
  }
}

private handlePolicyTypeChange(
  event: UIEmitUpdateEvent,
  newPolicyType: string,
  oldPolicyType: unknown
): void {
  if (!this.augRef) return;

  // Step 1: Show loading indicator
  this.isCalculating = true;

  // Step 2: Calculate new premium based on policy type
  const premium = this.calculatePremium(newPolicyType, event.form.data);
  this.augRef._helper.setData('premium', premium, 'myFormInstance');

  // Step 3: Update available coverage options
  const coverageField = this.findFieldInStructure('coverage');
  if (coverageField) {
    coverageField.dataProvider = this.getCoverageOptions(newPolicyType);

    // Clear current coverage selection (no longer valid)
    this.augRef._helper.setData('coverage', '', 'myFormInstance');

    // Refresh coverage dropdown
    this.augRef._helper.refreshElement({
      elementName: 'coverage',
      AUGinstance: 'myFormInstance'
    });
  }

  // Step 4: Show/hide additional sections based on policy type
  this.augRef._helper.updateFieldsConditionally({
    source: { name: 'policyType', AUGinstance: 'myFormInstance' },
    event: 'displayIf'
  });

  // Step 5: Update required fields based on policy type
  this.augRef._helper.updateFieldsConditionally({
    source: { name: 'policyType', AUGinstance: 'myFormInstance' },
    event: 'requireIf'
  });

  // Step 6: Fetch additional data from API if needed
  if (this.requiresAdditionalData(newPolicyType)) {
    this.service.getPolicyTypeData(newPolicyType).subscribe({
      next: (data) => {
        if (this.augRef) {
          // Populate additional fields
          Object.keys(data).forEach(key => {
            this.augRef!._helper.setData(key, data[key], 'myFormInstance');
          });
        }
        this.isCalculating = false;
      },
      error: (error) => {
        console.error('Failed to fetch policy type data:', error);
        this.isCalculating = false;
        this.showError('Failed to load policy type information');
      }
    });
  } else {
    this.isCalculating = false;
  }

  // Step 7: Validate eligibility for this policy type
  this.validatePolicyEligibility(newPolicyType, event.form.data);
}

private calculatePremium(policyType: string, formData: any): number {
  // Complex premium calculation logic
  const baseRate = this.getBaseRate(policyType);
  const coverageMultiplier = this.getCoverageMultiplier(formData.coverageAmount);
  const locationFactor = this.getLocationFactor(formData.state);
  const ageFactor = this.getAgeFactor(formData.age);

  return baseRate * coverageMultiplier * locationFactor * ageFactor;
}

private recalculatePremium(event: UIEmitUpdateEvent): void {
  if (!this.augRef) return;

  const policyType = event.form.data.policyType;
  const newPremium = this.calculatePremium(policyType, event.form.data);

  // Update premium field
  this.augRef._helper.setData('premium', newPremium, 'myFormInstance');

  // Show calculation breakdown to user
  this.showPremiumBreakdown(newPremium);
}

private validatePolicyEligibility(policyType: string, formData: any): void {
  // Check eligibility rules
  const eligibilityErrors: string[] = [];

  if (policyType === 'LIFE' && formData.age > 65) {
    eligibilityErrors.push('Life insurance not available for ages over 65');
  }

  if (policyType === 'AUTO' && !formData.driversLicense) {
    eligibilityErrors.push('Valid driver\'s license required for auto insurance');
  }

  if (eligibilityErrors.length > 0) {
    this.showError(`Eligibility issues: ${eligibilityErrors.join(', ')}`);

    // Optionally disable submit button
    const submitButton = this.findFieldInStructure('submit');
    if (submitButton) {
      submitButton.disabled = true;
      this.augRef!._helper.refreshElement({
        elementName: 'submit',
        AUGinstance: 'myFormInstance'
      });
    }
  }
}
```

**Key Points:**
- Handle complex multi-step workflows
- Use `setData()` for all programmatic updates
- Update multiple dropdowns with `refreshElement()`
- Trigger all conditional logic with `updateFieldsConditionally()`
- Fetch additional data from APIs as needed
- Validate business rules and show appropriate errors
- Show loading indicators during calculations
- Disable controls based on eligibility

---

### uiEmitUpdate Best Practices

1. **Always check `this.augRef`** before calling helper methods
2. **Debounce expensive operations** (API calls, calculations)
3. **Use `setData()` for programmatic updates** - never modify `uiData` directly
4. **Call `refreshElement()`** after updating field options
5. **Trigger conditional logic** with `updateFieldsConditionally()` after bulk updates
6. **Clean up timeouts** in `ngOnDestroy`
7. **Use `detectChanges.next()`** after FormControl manipulation
8. **Handle errors gracefully** - silent for auto-save, user-friendly for lookups
9. **Validate in real-time** for better UX (email, phone, etc.)
10. **Scroll to errors** for improved accessibility

---

### Dynamic Field Manipulation

```typescript
export class DynamicFormComponent implements OnInit {
  private augRef: any;

  onAugRef(ref: any): void {
    this.augRef = ref;
  }

  addPhoneField(): void {
    if (this.augRef) {
      this.augRef._helper.addElement({
        referenceElementName: 'email',
        sectionName: 'mainSection',
        AUGinstance: 'myFormInstance',
        addBefore: false,
        newElement: {
          type: 'text',
          name: 'phone',
          label: 'Phone Number',
          inputType: 'tel',
          validators: {
            required: true,
            pattern: '^[0-9]{10}$'
          }
        },
        emitNotification: true
      });
    }
  }

  removePhoneField(): void {
    if (this.augRef) {
      this.augRef._helper.deleteElement(
        this.augRef,
        'myFormInstance',
        'phone'
      );
    }
  }

  updateEmail(newEmail: string): void {
    if (this.augRef) {
      this.augRef._helper.setData('email', newEmail, 'myFormInstance');
    }
  }
}
```

### Working with FormService Directly

```typescript
export class FormManagementComponent implements OnInit {
  constructor(private formService: FormService) {}

  ngOnInit(): void {
    // Initialize form
    this.formService.startForm('myAugInstance', 'mainForm');
  }

  resetFormData(): void {
    // Reset form to initial state
    this.formService.resetForm('myAugInstance', 'mainForm');
  }

  clearAllData(): void {
    // Clear all form data
    this.formService.clearFormData('myAugInstance', null);
  }

  getFormMetadata(): void {
    const metadata = this.formService.getFormMetadata('myAugInstance');
    console.log('Form metadata:', metadata);
  }

  deleteSpecificField(): void {
    this.formService.deleteFormControl(
      'myAugInstance',
      'mainForm',
      'phoneNumber'
    );
  }
}
```

### Multi-Step Wizard Form

```typescript
ngOnInit(): void {
  this.uiStructure = {
    id: 'wizardFormInstance',
    layout: {
      type: 'wizard',
      slots: {
        step1: ['personalInfoSection'],
        step2: ['addressSection'],
        step3: ['reviewSection']
      }
    },
    wizard: {
      steps: [
        { name: 'step1', label: 'Personal Info' },
        { name: 'step2', label: 'Address' },
        { name: 'step3', label: 'Review' }
      ]
    },
    sectionsOrder: ['personalInfoSection', 'addressSection', 'reviewSection'],
    sections: {
      personalInfoSection: {
        type: 'container',
        name: 'personal_container',
        fields: [
          {
            type: 'text',
            name: 'firstName',
            label: 'First Name',
            validators: { required: true }
          }
        ]
      },
      addressSection: {
        type: 'container',
        name: 'address_container',
        fields: [
          {
            type: 'text',
            name: 'street',
            label: 'Street Address',
            validators: { required: true }
          }
        ]
      },
      reviewSection: {
        type: 'container',
        name: 'review_container',
        fields: []
      }
    }
  };
}
```

### Using Translation

```typescript
export class TranslatedFormComponent implements OnInit {
  public translation = {
    'firstName': 'Prénom',
    'lastName': 'Nom',
    'email': 'E-mail',
    'submit': 'Soumettre'
  };

  public uiStructure: any;
  public uiData = {};

  ngOnInit(): void {
    // uiStructure definition here
  }
}
```

```html
<axis-ui-generator
  [uiStructure]="uiStructure"
  [uiData]="uiData"
  [translation]="translation"
  (uiEmit)="onSubmit($event)"
  (uiEmitUpdate)="onUpdate($event)">
</axis-ui-generator>
```

---

## Pattern 7: Button Actions Through uiEmitUpdate

### Use Case
Handle action button clicks (Search, Save Draft, Reset, etc.) through the centralized uiEmitUpdate handler instead of direct Angular event bindings.

### Why This Pattern?
- ✅ Centralizes all user interactions through one event handler
- ✅ Maintains consistency with field change handling
- ✅ Prevents duplicate event listeners
- ✅ Ensures state synchronization through FormService
- ✅ Makes the component easier to test

### Aug.json Structure
```json
{
  "sections": {
    "clientInfo": {
      "type": "container",
      "name": "clientInfoContainer",
      "class": "form-section",
      "fields": [
        {
          "type": "text",
          "name": "clientName",
          "label": "Client Name",
          "required": true,
          "validators": ["required"]
        },
        {
          "type": "text",
          "name": "clientNumber",
          "label": "Client Number",
          "required": true,
          "validators": ["required"]
        }
      ]
    },
    "actions": {
      "type": "container",
      "name": "actionsContainer",
      "class": "form-actions d-flex gap-2 mt-3",
      "fields": [
        {
          "type": "button",
          "name": "searchButton",
          "label": "Search Client",
          "class": "kind-primary",
          "buttonType": "button",
          "eventName": "searchClient",
          "icon": "search",
          "iconPosition": "left"
        },
        {
          "type": "button",
          "name": "saveDraftButton",
          "label": "Save Draft",
          "class": "kind-secondary",
          "buttonType": "button",
          "eventName": "saveDraft"
        },
        {
          "type": "button",
          "name": "resetButton",
          "label": "Reset",
          "class": "kind-secondary",
          "buttonType": "button",
          "eventName": "resetForm"
        }
      ]
    }
  }
}
```

### Component Implementation
```typescript
import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { FormService } from 'axis-ui-generator';
import { UIEmitUpdateEvent } from 'axis-ui-generator-types';

@Component({
  selector: 'app-client-information',
  templateUrl: './client-information.component.html'
})
export class ClientInformationComponent implements OnInit, OnDestroy {
  private augFormService = inject(FormService);

  uiClientStructure: any = {};
  uiClientData: any = {};

  ngOnInit(): void {
    // Load UI structure from service or DynamoDB
    this.loadUIStructure();
  }

  ngOnDestroy(): void {
    // MANDATORY: Cleanup FormService
    this.augFormService.clearFormData('clientInformationInstance', null);
  }

  /**
   * Handle ALL interactions from axis-ui-generator
   * Both field changes AND button clicks flow through this handler
   */
  clientInfoEmitUpdate(event: UIEmitUpdateEvent): void {
    const { fieldName, newValue, eventName } = event.eventInfo;

    // Handle button events first
    if (eventName) {
      this.handleButtonAction(eventName);
      return;
    }

    // Handle field changes
    this.uiClientData = { ...this.uiClientData, ...event.uiData };
    this.handleFieldDependencies(fieldName, newValue);
  }

  /**
   * Centralized button action handler
   * Routes button clicks to appropriate methods
   */
  private handleButtonAction(eventName: string): void {
    switch (eventName) {
      case 'searchClient':
        this.onSearchClient();
        break;
      case 'saveDraft':
        this.saveDraft();
        break;
      case 'resetForm':
        this.resetForm();
        break;
      default:
        console.warn('Unhandled button action:', eventName);
    }
  }

  private onSearchClient(): void {
    console.log('Searching for client:', this.uiClientData.clientNumber);
    // Implement search logic
  }

  private saveDraft(): void {
    console.log('Saving draft:', this.uiClientData);
    // Implement draft save logic
  }

  private resetForm(): void {
    console.log('Resetting form');
    this.augFormService.resetForm('clientInformationInstance', null);
    this.uiClientData = {};
  }

  private handleFieldDependencies(fieldName: string, newValue: any): void {
    // Handle cascade dropdowns, validation, etc.
    if (fieldName === 'clientNumber') {
      console.log('Client number changed:', newValue);
    }
  }

  private loadUIStructure(): void {
    // Load from service or DynamoDB
  }
}
```

### Template
```html
<axis-ui-generator
  [uiStructure]="uiClientStructure"
  [uiData]="uiClientData"
  (uiEmitUpdate)="clientInfoEmitUpdate($event)"
  (uiEmit)="onFormSubmit($event)"
  (augRef)="onAugRef($event)">
</axis-ui-generator>
```

### Key Points

1. **NO Direct Event Handlers**: Template contains NO `(click)=` handlers on buttons
2. **Single Event Flow**: All button clicks and field changes flow through `uiEmitUpdate`
3. **Event Differentiation**: Use `event.eventInfo.eventName` to distinguish button clicks from field changes
4. **Centralized Routing**: `handleButtonAction()` method routes button events to specific handlers
5. **Consistent Pattern**: Same event handling pattern for both buttons and form fields

### Anti-Pattern to Avoid

❌ **WRONG:**
```html
<div class="form-actions">
  <button axis-button class="kind-primary" (click)="onSearchClient()">
    Search Client
  </button>
  <button axis-button class="kind-secondary" (click)="saveDraft()">
    Save Draft
  </button>
</div>

<axis-ui-generator
  [uiStructure]="uiClientStructure"
  [uiData]="uiClientData"
  (uiEmitUpdate)="clientInfoEmitUpdate($event)">
</axis-ui-generator>
```

**Why this is wrong:**
- Creates dual event handling patterns (buttons use `(click)=`, fields use `uiEmitUpdate`)
- Bypasses axis-ui-generator's centralized event management
- Makes testing more complex
- Harder to maintain consistency

✅ **CORRECT:**
Define all buttons in the aug.json structure with `eventName` properties and handle through `uiEmitUpdate`.

---

## Quick Reference Links

- [Main Guide](./AXIS-UI-GENERATOR-GUIDE.md) - Complete API reference and decision guidance
- [Advanced Patterns](./AXIS-UI-GENERATOR-ADVANCED-PATTERNS.md) - Advanced techniques and best practices
- [Troubleshooting](./AXIS-UI-GENERATOR-TROUBLESHOOTING.md) - Common issues and anti-patterns
