# Axis UI Generator - Troubleshooting Guide

> Common issues, mistakes, and anti-patterns for Axis UI Generator
> Main Guide: [AXIS-UI-GENERATOR-GUIDE.md](./AXIS-UI-GENERATOR-GUIDE.md)

## Table of Contents

1. [Common Issues and Solutions](#common-issues-and-solutions)
2. [Common Mistakes and Anti-Patterns](#common-mistakes-and-anti-patterns)
3. [Decision Tree: Choosing the Right Approach](#decision-tree-choosing-the-right-approach)

---

## Common Issues and Solutions

### Issue: Form not rendering

**Solution:** Ensure `uiStructure` is properly initialized before the component loads. Use `ngOnInit` or resolve data before navigation.

### Issue: Field values not updating

**Solution:** Use `augRef._helper.setData()` method or ensure two-way binding via `uiData` object.

### Issue: Conditional fields not showing/hiding

**Solution:** Verify `displayIf` conditions and ensure source field names match exactly. Call `updateFieldsConditionally()` if needed.

### Issue: Memory leaks

**Solution:** Always clear form data and complete subscriptions in `ngOnDestroy`:

```typescript
ngOnDestroy(): void {
  this.formService.clearFormData('myAugInstance', null);
}
```

### Issue: Form validation not triggering

**Solution:** Ensure validators are defined in uiStructure, not separately. Mark fields as touched to display errors.

---

## Common Mistakes and Anti-Patterns

### ❌ Don't: Manipulate uiStructure without updating the tree

```typescript
// BAD - Direct manipulation without refresh
this.uiStructure.sections.mainSection.fields.push(newField);
```

```typescript
// GOOD - Use proper methods
augRef._helper.addElement({
  referenceElementName: 'lastField',
  sectionName: 'mainSection',
  AUGinstance: 'myFormInstance',
  newElement: newField,
  emitNotification: true
});
```

### ❌ Don't: Use displayIf when you need to dynamically add fields

```typescript
// BAD - Field must exist in initial structure for displayIf
{
  type: 'text',
  name: 'dynamicField',
  displayIf: [{ source: 'trigger', comparison: 'equal', value: true }]
}
```

```typescript
// GOOD - Use addElement() for truly dynamic fields
onTriggerChange(value: boolean): void {
  if (value && !this.hasDynamicField) {
    augRef._helper.addElement({...});
  } else if (!value && this.hasDynamicField) {
    augRef._helper.deleteElement(augRef, 'myFormInstance', 'dynamicField');
  }
}
```

### ❌ Don't: Forget to clean up in ngOnDestroy

```typescript
// BAD - Memory leak risk
ngOnDestroy(): void {
  // No cleanup
}
```

```typescript
// GOOD - Proper cleanup
ngOnDestroy(): void {
  this.formService.clearFormData('myAugInstance', null);
  Object.values(this.subscriptions).forEach(sub => sub?.unsubscribe());
}
```

### ❌ Don't: Use Direct Button Event Handlers with axis-ui-generator

#### Anti-pattern: Direct Angular Event Handlers on Buttons

```html
<!-- BAD - Buttons outside axis-ui-generator with direct event handlers -->
<div class="form-actions">
  <button axis-button class="kind-primary" (click)="onSearch()">
    Search
  </button>
  <button axis-button class="kind-secondary" (click)="saveDraft()">
    Save Draft
  </button>
</div>

<axis-ui-generator
  [uiStructure]="uiStructure"
  [uiData]="uiData"
  (uiEmitUpdate)="onUpdate($event)">
</axis-ui-generator>
```

**Problem:**
- Buttons use direct Angular `(click)=` handlers outside the axis-ui-generator component
- Creates dual event handling patterns (buttons use `(click)=`, fields use `uiEmitUpdate`)
- Bypasses axis-ui-generator's centralized event management system
- Bypasses FormService state management and synchronization
- Makes the component harder to test and maintain
- Inconsistent with the framework's event-driven architecture

#### ✅ Correct Pattern: Buttons in aug.json with eventName

```json
// In aug.json structure
{
  "sections": {
    "actions": {
      "type": "container",
      "name": "actionsContainer",
      "class": "form-actions d-flex gap-2",
      "fields": [
        {
          "type": "button",
          "name": "searchButton",
          "label": "Search",
          "class": "kind-primary",
          "buttonType": "button",
          "eventName": "search"
        },
        {
          "type": "button",
          "name": "saveDraftButton",
          "label": "Save Draft",
          "class": "kind-secondary",
          "buttonType": "button",
          "eventName": "saveDraft"
        }
      ]
    }
  }
}
```

```typescript
// In component TypeScript
onUpdate(event: UIEmitUpdateEvent): void {
  const { fieldName, newValue, eventName } = event.eventInfo;

  // Handle button events first
  if (eventName === 'search') {
    this.onSearch();
    return;
  }

  if (eventName === 'saveDraft') {
    this.saveDraft();
    return;
  }

  // Handle field changes
  this.uiData = { ...this.uiData, ...event.uiData };
  this.handleFieldDependencies(fieldName, newValue);
}
```

```html
<!-- Template - NO separate button elements -->
<axis-ui-generator
  [uiStructure]="uiStructure"
  [uiData]="uiData"
  (uiEmitUpdate)="onUpdate($event)"
  (uiEmit)="onSubmit($event)">
</axis-ui-generator>
```

**Benefits:**
- ✅ Single event handling pattern for all user interactions
- ✅ All interactions flow through axis-ui-generator's centralized event management
- ✅ Maintains consistency with field change handling
- ✅ Ensures state synchronization through FormService
- ✅ Makes the component easier to test and maintain
- ✅ Button definitions in JSON can be changed without code redeployment (for dynamic UI)

### ❌ Don't: Use refreshClear when refreshElement is sufficient

```typescript
// BAD - Overkill for single field update
augRef._helper.refreshClear();
```

```typescript
// GOOD - Targeted refresh
augRef._helper.refreshElement({
  elementName: 'specificField',
  AUGinstance: 'myFormInstance'
});
```

### ❌ Don't: Access form controls directly without checking existence

```typescript
// BAD - Potential runtime error
const value = this.formService.Form['myInstance']['mainForm'].get('field').value;
```

```typescript
// GOOD - Safe access with checks
getFieldValue(fieldName: string): any {
  const form = this.formService.Form['myInstance']?. ['mainForm'];
  return form?.get(fieldName)?.value ?? null;
}
```

### ❌ Don't: Ignore augRef availability in template

```typescript
// BAD - Called before augRef emits
ngOnInit(): void {
  this.augRef._helper.setData('field', 'value'); // augRef is undefined
}
```

```typescript
// GOOD - Wait for augRef
onAugRef(ref: any): void {
  this.augRef = ref;
  this.augRef._helper.setData('field', 'value');
}
```

### ❌ Don't: Set values without triggering change detection

```typescript
// BAD - View won't update
this.uiData.firstName = 'John';
```

```typescript
// GOOD - Use setData for proper sync
augRef._helper.setData('firstName', 'John');
```

### ❌ Don't: Use multiple AUG instances with same ID

```typescript
// BAD - ID collision
this.uiStructure1 = { id: 'myForm', ... };
this.uiStructure2 = { id: 'myForm', ... };
```

```typescript
// GOOD - Unique IDs
this.uiStructure1 = { id: 'personalForm', ... };
this.uiStructure2 = { id: 'businessForm', ... };
```

## Decision Tree: Choosing the Right Approach

```
Need to update field value?
├─ Single field → augRef._helper.setData()
├─ Multiple fields → Loop setData() or bulk update uiData + updateAllFields()
└─ Initial load → Set uiData object before render

Need to show/hide field?
├─ Field exists in structure → Use displayIf in uiStructure
├─ Field doesn't exist → Use addElement() / deleteElement()
└─ Temporarily disable → Use disableIf or formControl.disable()

Field not updating?
├─ Try refreshElement() first
├─ Still broken? → Try recreateElement()
└─ Still broken? → Last resort: refreshClear()

Form validation needed?
├─ Built-in rules → Define validators in uiStructure
├─ Check validity → event.form.model.valid in uiEmit
├─ Show errors → Mark controls as touched
└─ Complex rules → Implement in uiEmitUpdate handler

Need cleanup?
├─ Component unmounting → clearFormData() in ngOnDestroy (REQUIRED)
├─ Form reset → resetForm()
└─ Field removal → deleteElement()

Performance issues?
├─ Too many renders → Use trackBy methods in ngFor
├─ Too many emitUpdate → Set timeToEmitUpdate
└─ Initial load slow → Set emitUpdateAfterLoad: false
```

---

## Quick Reference Links

- [Main Guide](./AXIS-UI-GENERATOR-GUIDE.md) - Complete API reference and decision guide
- [Usage Examples](./AXIS-UI-GENERATOR-EXAMPLES.md) - Working examples and patterns
- [Advanced Patterns](./AXIS-UI-GENERATOR-ADVANCED-PATTERNS.md) - Advanced techniques and best practices

---

## Need More Help?

If you're still stuck:
1. Check the [Main Guide](./AXIS-UI-GENERATOR-GUIDE.md) for complete API documentation
2. Review [Usage Examples](./AXIS-UI-GENERATOR-EXAMPLES.md) for working code patterns
3. Consult [Advanced Patterns](./AXIS-UI-GENERATOR-ADVANCED-PATTERNS.md) for complex scenarios
