# Axis UI Generator (AUG) Guide

Complete reference for using the Axis UI Generator component and Form Service in Angular applications with full TypeScript type safety.

## Table of Contents

1. [Overview](#overview)
2. [TypeScript Type System](#typescript-type-system)
3. [When to Use What: Decision Guide](#when-to-use-what-decision-guide)
4. [AxisUiGeneratorComponent](#axisuigeneratorcomponent)
5. [FormService](#formservice)
6. [TypeScript Types Reference](#typescript-types-reference)

## Additional Guides

- [Usage Examples](./AXIS-UI-GENERATOR-EXAMPLES.md) - Complete working examples and patterns
- [Advanced Patterns](./AXIS-UI-GENERATOR-ADVANCED-PATTERNS.md) - Advanced techniques and best practices
- [Troubleshooting](./AXIS-UI-GENERATOR-TROUBLESHOOTING.md) - Common issues, mistakes, and anti-patterns

---

## Overview

**Axis UI Generator (AUG)** is a dynamic Angular component that converts JSON configuration into fully functional UI at runtime. It provides a declarative approach to building forms and UI components using a JSON-based structure with full TypeScript type safety.

### Key Concepts

- **uiStructure**: JSON schema defining the layout, sections, and field configurations
- **uiData**: Object holding the form data/model values
- **AUG Instance**: Each instance of axis-ui-generator creates an isolated form context
- **FormService**: Service managing form state, validation, and field registration across AUG instances
- **Type System**: Comprehensive TypeScript types for all UI components and configurations

---

## TypeScript Type System

The Axis UI Generator includes a complete TypeScript type system via the `axis-ui-generator-types` package.

### Quick Start

```bash
npm install axis-ui-generator-types
```

**For complete type reference, see the axis-types skill:**
```
Read(file_path: "plugins/AIDLC-axis/skills/axis-types/SKILL.md")
```

### Essential Imports

```typescript
import {
  UIStructure, UIData, UIControl,
  AUGHelper, UIEmitEvent, UIEmitUpdateEvent
} from 'axis-ui-generator-types';
```

**Common types you'll need:**
- **UI Structure**: [skills/axis-types/axis-ui-generator-types/ui-structure.types.ts](../skills/axis-types/axis-ui-generator-types/ui-structure.types.ts) - Complete UI structure definition
- **UI Data**: [skills/axis-types/axis-ui-generator-types/ui-data.types.ts](../skills/axis-types/axis-ui-generator-types/ui-data.types.ts) - UIData and ComponentStatus
- **Control Types**: [skills/axis-types/axis-ui-generator-types/control.types.ts](../skills/axis-types/axis-ui-generator-types/control.types.ts) - All 78+ control types
- **Base Control**: [skills/axis-types/axis-ui-generator-types/base-control.types.ts](../skills/axis-types/axis-ui-generator-types/base-control.types.ts) - Common properties for all controls
- **Validation**: [skills/axis-types/axis-ui-generator-types/validation.types.ts](../skills/axis-types/axis-ui-generator-types/validation.types.ts) - UIValidators and UIErrorMessages
- **Events**: [skills/axis-types/axis-ui-generator-types/event.types.ts](../skills/axis-types/axis-ui-generator-types/event.types.ts) - UIEvent, UIEmitEvent, UIEmitUpdateEvent
- **Helpers**: [skills/axis-types/axis-ui-generator-types/helper.types.ts](../skills/axis-types/axis-ui-generator-types/helper.types.ts) - AUGHelper interface and config types

---

## When to Use What: Decision Guide

This section helps you choose the right method or approach for common scenarios.

### Scenario: Updating Field Values

| Situation | Use This | Why |
|-----------|----------|-----|
| Setting a single field value programmatically | `augRef._helper.setData()` | Automatically handles form control, uiData sync, and triggers change detection |
| Setting field value from FormService | `formService.Form[instance][form].get(name).setValue()` | Direct form control access when you need fine-grained control |
| Pre-populating form on load | Initialize `uiData` object before AUG renders | Cleanest approach for initial data |
| Bulk updating multiple fields | Loop through fields and use `setData()` for each | Ensures all validations and interactions fire correctly |

**Example Use Cases:**
- **Auto-populate from API**: Use `setData()` after fetching user profile data
- **Cascade dropdowns**: Use `setData()` in `uiEmitUpdate` handler when parent dropdown changes
- **Reset to defaults**: Set `uiData` object and call `refreshElement()`

### Scenario: Adding/Removing Fields Dynamically

| Situation | Use This | Why |
|-----------|----------|-----|
| Add field based on user action | `augRef._helper.addElement()` | Properly integrates field into form structure, tree, and validations |
| Remove field conditionally | `augRef._helper.deleteElement()` | Cleans up form controls, references, and uiStructure |
| Show/hide field based on condition | Use `displayIf` in uiStructure | Declarative, no code needed, field remains in DOM |
| Add multiple related fields | Loop `addElement()` with proper reference chaining | Each field references the previous one |
| Temporarily disable field | Use `disableIf` in uiStructure or `formControl.disable()` | Field remains visible but not editable |

**Example Use Cases:**
- **Add "Other" text field**: When user selects "Other" in dropdown, use `addElement()` to add text input
- **Dynamic address fields**: Add international address fields when country changes
- **Conditional insurance fields**: Use `displayIf` when "Has Insurance" is checked
- **Remove optional sections**: Use `deleteElement()` when user opts out of optional features

### Scenario: Refreshing/Re-rendering UI

| Situation | Use This | Why |
|-----------|----------|-----|
| Single field not reflecting changes | `augRef._helper.refreshElement({ elementName, AUGinstance })` | Triggers change detection for specific field only |
| Entire form needs re-render | `augRef._helper.refreshElement()` (no params) | Triggers change detection for all fields in all instances |
| Component broken after manipulation | `augRef._helper.recreateElement()` | Completely destroys and recreates the element with fresh state |
| Need to restart entire AUG | `augRef._helper.refreshClear()` | Nuclear option: destroys and recreates everything |
| Data changed but view not updating | Update `refresh` object: `this.refresh = { ...this.refresh }` | Triggers AUG's ngOnChanges hook |

**Example Use Cases:**
- **After external data update**: Use `refreshElement()` when data changes outside Angular's change detection
- **Dropdown not showing new options**: Use `recreateElement()` for the dropdown after updating dataProvider
- **Complex nested component stuck**: Use `recreateElement()` to reset component state
- **Switching between multiple uiStructures**: Use `refreshClear()` when loading completely different forms

### Scenario: Form Validation and Submission

| Situation | Use This | Why |
|-----------|----------|-----|
| Check if form is valid before submit | Check `event.form.model.valid` in `uiEmit` handler | Standard Angular form validation approach |
| Show all validation errors | Mark all controls as touched in `uiEmit` handler | Forces error messages to display |
| Validate specific field programmatically | `formService.Form[instance][form].get(name).valid` | Direct access to field validation state |
| Get all invalid fields | Filter form controls by `invalid` status | Useful for logging or custom error display |
| Custom validation beyond built-in | Use `checkAllInteractions()` after setting value | Rechecks all displayIf, disableIf, requireIf conditions |

**Example Use Cases:**
- **Multi-step form**: Validate current step before allowing next
- **Auto-save draft**: Check validity in `uiEmitUpdate` and save if valid
- **Show validation summary**: Collect all invalid fields and display at top of form
- **Custom business rules**: Use `checkAllInteractions()` after complex field updates

### Scenario: Conditional Logic and Interactions

| Situation | Use This | Why |
|-----------|----------|-----|
| Field shows based on another field | Define `displayIf` in uiStructure | Declarative, automatic, no code |
| Field disabled based on condition | Define `disableIf` in uiStructure | Declarative, automatic, field stays visible |
| Field required based on condition | Define `requireIf` in uiStructure | Dynamic validation without code |
| Manual trigger of conditionals | `augRef._helper.updateFieldsConditionally()` | Forces re-evaluation of conditions |
| Check all interactions after bulk update | `augRef._helper.checkAllInteractions()` | Ensures all displayIf/disableIf/requireIf are current |
| Complex multi-field logic | Implement in `uiEmitUpdate` handler | Full control for business logic too complex for declarative approach |

**Example Use Cases:**
- **Insurance fields**: Show when "Has Insurance" is true using `displayIf`
- **Dependent dropdowns**: Disable "City" until "State" is selected using `disableIf`
- **Conditional required**: Make "Spouse Name" required if "Marital Status" is "Married" using `requireIf`
- **After programmatic updates**: Call `updateFieldsConditionally()` after setting multiple fields
- **Complex workflows**: Use `uiEmitUpdate` when conditions depend on multiple fields with complex logic

### Scenario: Working with FormService Directly

| Situation | Use This | Why |
|-----------|----------|-----|
| Need to manipulate form state directly | Access `formService.Form[instance][form]` | Full Angular FormGroup access |
| Get reference to specific component | Access `formService.componentsRefs[instance][fieldName]` | Access to component instance and ViewRef |
| Initialize new form manually | `formService.startForm()` | Rarely needed (AUG does this), useful for custom scenarios |
| Reset form to initial state | `formService.resetForm()` | Resets all values to initial state |
| Clear all form data on cleanup | `formService.clearFormData()` | Memory cleanup in ngOnDestroy |
| Delete specific control from form | `formService.deleteFormControl()` | Lower-level than `deleteElement()`, use for form cleanup |
| Track wizard state | Check `formService.wizardStep` and `formService.wizardCount` | Access current wizard position |
| Register custom layout | `formService.registerLayout()` | Add your own layout component type |

**Example Use Cases:**
- **Custom validation display**: Access `componentsRefs` to show custom error UI
- **Form state debugging**: Log `formService.Form[instance]` to inspect current state
- **Wizard navigation**: Use `wizardStep` to determine current position
- **Memory management**: Call `clearFormData()` in ngOnDestroy of long-lived components
- **Integration with third-party**: Access form directly when integrating with non-AUG components

### Scenario: Navigation and Routing

| Situation | Use This | Why |
|-----------|----------|-----|
| Navigate to different route | `augRef._helper.navigate(route, params)` | AUG-aware navigation, handles cleanup |
| Configure routes for AUG content | Pass `augRoutes` input to axis-ui-generator | Enables route-based content loading |
| Preload route data | Configure `contentRequest` with `preload: true` in augRoutes | Caches data before route activation |

**Example Use Cases:**
- **Form submission success**: Navigate to success page after save
- **Wizard completion**: Navigate to summary/review page
- **Route-based forms**: Load different form configurations based on URL
- **Performance optimization**: Preload next form's data while user completes current step

### Scenario: Internationalization and Translation

| Situation | Use This | Why |
|-----------|----------|-----|
| Translate entire form | Pass `translation` object to axis-ui-generator | Automatic translation of all labels and text |
| Translate specific text programmatically | `augRef._helper.translate(key)` | On-demand translation for dynamic content |
| Translate array of keys | `augRef._helper.translateArray(keys)` | Efficient batch translation |

**Example Use Cases:**
- **Multi-language application**: Load translation based on user preference
- **Dynamic labels**: Translate error messages or dynamic field labels
- **Custom components**: Use translate() in custom field components

### Scenario: Data Structure Manipulation

| Situation | Use This | Why |
|-----------|----------|-----|
| Convert nested structure to flat | `augRef._helper.createFlatModels(uiStructure)` | Easier to work with flat data for APIs |
| Find element in structure | `augRef._helper.findElement(elementName, sectionName)` | Locate element's position and parent |
| Rebuild element tree | `augRef._helper.reDoTree()` | Refresh internal tree after manual structure changes |
| Remove entire AUG instance | `augRef._helper.deleteAugInstance(instanceName)` | Complete cleanup of instance |

**Example Use Cases:**
- **API submission**: Flatten nested form data before sending to backend
- **Dynamic layout changes**: Use `findElement()` to locate where to insert new fields
- **Manual structure manipulation**: Call `reDoTree()` after directly modifying uiStructure
- **Multi-instance cleanup**: Remove AUG instances no longer needed

### Scenario: Performance Optimization

| Situation | Use This | Why |
|-----------|----------|-----|
| Optimize ngFor loops | Use `formService.trackByName` or other track methods | Prevents unnecessary re-renders |
| Prevent excessive emitUpdate | Set `timeToEmitUpdate` in uiStructure | Debounces rapid field changes |
| Skip initial emitUpdate | Set `emitUpdateAfterLoad: false` in uiStructure | Prevents unnecessary event on form load |
| Bypass normal update flow | `augRef._helper.bypassEmitUpdate()` | Direct control of update emission |
| Manual change detection | `augRef._helper.markForCheck(instance, controlName)` | Trigger change detection for specific control |

**Example Use Cases:**
- **Large lists**: Use trackBy methods for fields, sections, or dynamic arrays
- **Autosave forms**: Set `timeToEmitUpdate: 500` to debounce while user types
- **Read-only forms**: Set `emitUpdateAfterLoad: false` when just displaying data
- **Custom update logic**: Use `bypassEmitUpdate()` for complex multi-field updates

### Scenario: Custom and Advanced Features

| Situation | Use This | Why |
|-----------|----------|-----|
| Scroll to specific field | `augRef._helper.fnScrollToElem(elementId)` | Smooth scroll with AUG context awareness |
| Custom interactions/events | `augRef._helper.emitInteraction(params)` | Trigger custom events between components |
| Reinitialize AUG | `augRef._helper.start()` | Restart initialization without destroying |
| Signal completion | `augRef._helper.emitComplete(routeEvent)` | Notify parent or router of completion |
| Access AUG utilities | `augRef._utils` | Internal utilities for advanced scenarios |
| Access AUG methods | `augRef._methods` | Internal methods for advanced scenarios |

**Example Use Cases:**
- **Validation errors**: Scroll to first invalid field on submit
- **Custom workflows**: Emit custom events between different AUG instances
- **Dynamic reconfiguration**: Call `start()` after major configuration change
- **Parent-child coordination**: Use `emitComplete()` to signal parent component

### Quick Reference: Method Selection Matrix

| I want to... | Use This Method |
|-------------|-----------------|
| Set a field's value | `augRef._helper.setData()` |
| Add a new field | `augRef._helper.addElement()` |
| Remove a field | `augRef._helper.deleteElement()` |
| Refresh a field's display | `augRef._helper.refreshElement()` |
| Reset a field completely | `augRef._helper.recreateElement()` |
| Check form validity | `event.form.model.valid` in uiEmit handler |
| Trigger conditional logic | `augRef._helper.updateFieldsConditionally()` |
| Navigate to another page | `augRef._helper.navigate()` |
| Translate text | `augRef._helper.translate()` |
| Clean up on destroy | `formService.clearFormData()` |
| Access form directly | `formService.Form[instance][form]` |
| Reset entire form | `formService.resetForm()` |
| Scroll to a field | `augRef._helper.fnScrollToElem()` |
| Restart AUG | `augRef._helper.refreshClear()` |

---

## AxisUiGeneratorComponent

The main component that renders dynamic UI from JSON configuration with full TypeScript support.

### Component Selector

```html
<axis-ui-generator></axis-ui-generator>
```

### Component Interface

```typescript
import { UIStructure, UIData, AUGInstance } from 'axis-ui-generator-types';

@Component({
  selector: 'axis-ui-generator',
  // ...
})
export class AxisUiGeneratorComponent {
  @Input() uiStructure: UIStructure | null = null;
  @Input() uiData: UIData = {};
  @Input() augRoutes: AUGRoutes | null = null;
  @Input() refresh: RefreshConfig | null = null;
  @Input() translation: TranslationDictionary | null = null;
  @Input() section: string | null = null;

  @Output() uiEmit: EventEmitter<UIEmitEvent> = new EventEmitter();
  @Output() uiEmitUpdate: EventEmitter<UIEmitUpdateEvent> = new EventEmitter();
  @Output() onDestroy: EventEmitter<void> = new EventEmitter();
  @Output() augRef: EventEmitter<AUGInstance> = new EventEmitter();
}
```

### Input Properties

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `uiStructure` | `UIStructure \| null` | Yes | JSON schema defining the UI layout, sections, and field configurations |
| `uiData` | `UIData` | Yes | Data model object containing field values (Record<string, unknown>) |
| `augRoutes` | `AUGRoutes \| null` | No | Route configuration for navigation within AUG |
| `refresh` | `RefreshConfig \| null` | No | Object used to trigger UI refresh operations |
| `translation` | `TranslationDictionary \| null` | No | Translation dictionary for internationalization (Record<string, string>) |
| `section` | `string \| null` | No | Specific section identifier to render |

**TypeScript Interfaces:**

```typescript
// Main inputs
type UIStructure = { /* see TypeScript Types Reference */ };
type UIData = Record<string, unknown>;
type TranslationDictionary = Record<string, string>;

// Route configuration
interface AUGRoutes {
  [routeName: string]: {
    contentRequest?: ContentRequest;
    component?: any;
    data?: unknown;
  };
}

// Refresh configuration
interface RefreshConfig {
  timestamp?: number;
  [key: string]: unknown;
}
```

### Output Events

| Event | Type | Description |
|-------|------|-------------|
| `uiEmit` | `EventEmitter<UIEmitEvent>` | Triggered when form is submitted via submit button |
| `uiEmitUpdate` | `EventEmitter<UIEmitUpdateEvent>` | Triggered when any form field value changes |
| `onDestroy` | `EventEmitter<void>` | Triggered when component is destroyed |
| `augRef` | `EventEmitter<AUGInstance>` | Emits reference to the AUG instance after initialization |

**Event Interfaces:**

```typescript
interface UIEmitEvent {
  form: {
    model: FormGroup;
    data: UIData;
  };
  eventInfo: {
    eventType: 'submit';
    eventSource: UIControl;
    AUGinstance: string;
  };
  uiStructure: UIStructure;
  uiData: UIData;
}

interface UIEmitUpdateEvent {
  form: {
    model: FormGroup;
    data: UIData;
  };
  eventInfo: {
    eventType: string;
    eventSource: UIControl;
    AUGinstance: string;
    fieldName: string;
    oldValue?: unknown;
    newValue: unknown;
  };
  uiStructure: UIStructure;
  uiData: UIData;
}

interface AUGInstance {
  _helper: AUGHelper;
  _methods: AUGMethods;
  _utils: AUGUtils;
  uiStructure: UIStructure;
  uiData: UIData;
  [key: string]: unknown;
}
```

### Helper Methods (via `_helper`)

The component exposes a `_helper` object providing utility methods for dynamic UI manipulation:

#### `setData(controlName, data, AUGinstance?, formName?, setValueOptions?)`

Set data to a specific form control.

**When to Use:**
- After fetching data from an API and need to populate a specific field
- In cascade/dependent field scenarios where one field's change affects another
- When implementing auto-complete or auto-fill functionality
- To programmatically set field values in response to user actions

**Parameters:**
- `controlName` (string): Name of the form control
- `data` (any): Value to set
- `AUGinstance` (string, optional): AUG instance identifier (defaults to current instance)
- `formName` (string, optional): Form name (auto-detected if not provided)
- `setValueOptions` (object, optional): Angular FormControl setValue options

**Example:**
```typescript
// Auto-populate based on zip code
onZipCodeChange(zipCode: string): void {
  const cityData = this.lookupCity(zipCode);
  augRef._helper.setData('city', cityData.city);
  augRef._helper.setData('state', cityData.state);
}
```

#### `addElement(config)`

Dynamically add a new field/element to the UI.

**When to Use:**
- When user selects "Other" option and needs to provide additional text input
- Building dynamic forms where fields are added based on previous selections
- Adding repeatable sections (e.g., "Add another phone number")
- Complex workflows where field visibility is determined at runtime
- When `displayIf` alone isn't sufficient because the field doesn't exist in initial structure

**Parameters:**
- `config.referenceElementName` (string): Name of element to add near
- `config.sectionName` (string): Section containing the reference element
- `config.AUGinstance` (string): AUG instance identifier
- `config.addBefore` (boolean): If true, adds before reference element; otherwise after
- `config.newElement` (object): UI structure for the new element
- `config.emitNotification` (boolean): Whether to emit update notification

**Example:**
```typescript
// Add "Other" text field when user selects "Other" from dropdown
onOccupationChange(value: string): void {
  if (value === 'other') {
    augRef._helper.addElement({
      referenceElementName: 'occupation',
      sectionName: 'personalInfo',
      AUGinstance: 'myFormInstance',
      addBefore: false,
      newElement: {
        type: 'text',
        name: 'occupationOther',
        label: 'Please specify your occupation',
        inputType: 'text',
        validators: { required: true }
      },
      emitNotification: true
    });
  }
}
```

#### `deleteElement(AUG, AUGinstanceName, controlName, deleteChildren?, clearUiStructure?)`

Remove a field/element from the UI.

**When to Use:**
- Removing dynamically added fields (counterpart to `addElement()`)
- Cleaning up optional sections user opted out of
- Removing repeatable items from a list (e.g., "Remove this phone number")
- Simplifying the form based on user's workflow path
- Performance optimization by removing unused sections from DOM

**Parameters:**
- `AUG` (any): Reference to AUG instance
- `AUGinstanceName` (string): AUG instance identifier
- `controlName` (string): Name of control to delete
- `deleteChildren` (boolean, default: true): Whether to delete child elements
- `clearUiStructure` (boolean, default: true): Whether to clear from uiStructure

**Example:**
```typescript
// Remove "Other" field when user changes dropdown back
onOccupationChange(value: string): void {
  if (value !== 'other' && this.hasOccupationOtherField) {
    augRef._helper.deleteElement(augRef, 'myFormInstance', 'occupationOther');
    this.hasOccupationOtherField = false;
  }
}
```

#### `refreshElement(config?)`

Trigger change detection for elements.

**When to Use:**
- After updating data outside Angular's change detection zone
- When a field's display isn't updating after programmatic changes
- After modifying uiStructure properties directly
- When dataProvider options are updated externally
- Performance optimization: refresh only changed elements instead of entire form

**Parameters:**
- `config` (object, optional): Configuration for refresh
  - `elementName` (string): Specific element to refresh
  - `AUGinstance` (string): AUG instance identifier

**Example:**
```typescript
// Refresh dropdown after updating its options
updateDropdownOptions(): void {
  this.fieldStructure.dataProvider = this.getNewOptions();
  augRef._helper.refreshElement({
    elementName: 'countryDropdown',
    AUGinstance: 'myFormInstance'
  });
}
```

#### `recreateElement(config)`

Completely recreate an element (useful for resetting complex components).

**When to Use:**
- Complex component is in broken/stuck state and simple refresh doesn't fix it
- Need to completely reset a field's internal state (like a multi-select or data-grid)
- After major structural changes to a field's configuration
- Component has accumulated state that needs clearing
- More reliable than `refreshElement()` for deeply nested components

**Parameters:**
- `config.elementName` (string): Name of element to recreate
- `config.sectionName` (string): Section containing the element
- `config.AUGinstance` (string): AUG instance identifier
- `config.AUG` (any): Reference to AUG instance
- `config.workOnCopy` (boolean, default: true): Whether to work on a copy of the structure

**Example:**
```typescript
// Reset complex data-grid to pristine state
resetDataGrid(): void {
  augRef._helper.recreateElement({
    elementName: 'productsGrid',
    sectionName: 'orderDetails',
    AUGinstance: 'myFormInstance',
    AUG: augRef
  });
}
```

#### `updateAllFields(config?)`

Update/refresh all fields in a form.

**When to Use:**
- After bulk data import or paste operation
- When multiple fields changed simultaneously from external source
- After resetting form to saved state
- When dataProvider options changed for multiple dropdowns
- Forcing all fields to re-validate and update display

**Parameters:**
- `config` (object, optional):
  - `AUGinstance` (string): AUG instance identifier
  - `parentForm` (string): Parent form name

**Example:**
```typescript
// After loading saved draft
loadDraft(draftData: any): void {
  Object.keys(draftData).forEach(key => {
    this.uiData[key] = draftData[key];
  });
  augRef._helper.updateAllFields({
    AUGinstance: 'myFormInstance',
    parentForm: 'mainForm'
  });
}
```

#### `updateFieldsConditionally(config)`

Check and update conditional interactions (displayIf, disableIf, requireIf).

**When to Use:**
- After programmatically setting a field value that affects other fields' conditions
- When conditional logic isn't automatically triggering
- After loading data and need to ensure all conditionals are evaluated
- When implementing complex multi-field dependencies
- Manual control over when conditional rules are re-evaluated

**Parameters:**
- `config.source` (object):
  - `name` (string): Source field name
  - `AUGinstance` (string): AUG instance identifier
- `config.event` (string): Event type ('displayIf' | 'disableIf' | 'requireIf')

**Example:**
```typescript
// After loading user profile, check insurance-related conditionals
loadUserProfile(profile: any): void {
  augRef._helper.setData('hasInsurance', profile.hasInsurance);
  augRef._helper.updateFieldsConditionally({
    source: { name: 'hasInsurance', AUGinstance: 'myFormInstance' },
    event: 'displayIf'
  });
}
```

#### `refreshClear(props?)`

Clear and completely recreate the entire AUG instance.

**When to Use:**
- Switching between completely different forms in the same component
- Nuclear reset when form is in irrecoverable state
- After major uiStructure changes that affect entire form
- Clearing all form state and starting fresh
- Last resort when other refresh methods don't work

**Example:**
```typescript
// Switch between form types
switchFormType(type: 'personal' | 'business'): void {
  this.uiStructure = type === 'personal'
    ? this.personalFormStructure
    : this.businessFormStructure;
  this.uiData = {};
  augRef._helper.refreshClear();
}
```

#### Additional Helper Methods

- `createFlatModels(uiStructure)`: Create flat model from nested structure
- `deleteAugInstance(instanceName)`: Delete an entire AUG instance
- `checkAllInteractions(AUG, controlName)`: Check all interaction conditions
- `emitInteraction(params)`: Manually emit interaction events
- `markForCheck(AUGinstance, controlName)`: Mark control for change detection
- `navigate(route, params)`: Navigate to a route
- `translate(key)`: Translate a key using translation dictionary
- `translateArray(keys)`: Translate array of keys
- `fnScrollToElem(elementId)`: Scroll to a specific element
- `bypassEmitUpdate(uiStructure, uiData, event, source, payload)`: Emit update without normal flow
- `start()`: Restart/reinitialize AUG
- `emitComplete(routeEvent?)`: Emit completion event
- `reDoTree()`: Rebuild the element tree
- `findElement(elementName, sectionName)`: Find element in structure

---

## FormService

Service managing form state, validation, and field registration across all AUG instances.

### Injectable

```typescript
import { FormService } from 'axis-ui-generator';

constructor(private formService: FormService) {}
```

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `Form` | `{}` | Object containing all form groups indexed by AUG instance name |
| `AUG_instances` | `{}` | Registry of all active AUG component instances |
| `componentsRefs` | `{}` | Component references indexed by AUG instance and field name |
| `mainUiData` | `{}` | Main data object across all instances |
| `mainUiStructure` | `{}` | Main structure object across all instances |
| `wizard` | `any` | Wizard configuration if using wizard layout |
| `isWizard` | `any` | Boolean indicating wizard mode |
| `wizardStep` | `number` | Current wizard step index |
| `wizardCount` | `number` | Total number of wizard steps |
| `LabelSeparator` | `string` | Character used to separate labels (default varies) |
| `fieldNames` | `{}` | Registry of field names by AUG instance |
| `isReplacing` | `boolean` | Flag indicating if replacement operation is in progress |
| `detectChanges` | `Subject<void>` | Subject for triggering change detection |

### Methods

#### `registerLayout(name, component)`

Register a custom layout component.

**When to Use:**
- Creating organization-specific form layouts (e.g., two-column, three-panel)
- Building reusable layout patterns across multiple forms
- Customizing form appearance beyond built-in layouts (basic, blank, sidebar-left, wizard)

**Parameters:**
- `name` (any): Layout name identifier
- `component` (any): Angular component class

**Example:**
```typescript
// Register custom two-column layout
formService.registerLayout('twoColumn', TwoColumnLayoutComponent);

// Use in uiStructure
this.uiStructure = {
  layout: { type: 'twoColumn', slots: { left: ['section1'], right: ['section2'] } }
};
```

#### `getFormMetadata(AUGinstance)`

Retrieve form metadata for a specific AUG instance.

**Parameters:**
- `AUGinstance` (any): AUG instance identifier

**Returns:** Form metadata object

**Example:**
```typescript
const metadata = formService.getFormMetadata('myAugInstance');
console.log(metadata);
```

#### `startForm(AUGinstanceName, formName)`

Initialize a new form for an AUG instance.

**Parameters:**
- `AUGinstanceName` (any): AUG instance identifier
- `formName` (any): Form name

**Example:**
```typescript
formService.startForm('myAugInstance', 'mainForm');
```

#### `resetForm(AUGinstanceName, formName)`

Reset a form to its initial state.

**When to Use:**
- "Clear Form" or "Reset" button functionality
- After successful submission to prepare for next entry
- Discarding draft changes and reverting to initial state
- Reverting to default values after validation errors

**Parameters:**
- `AUGinstanceName` (any): AUG instance identifier
- `formName` (any): Form name

**Example:**
```typescript
// Reset form after successful submission
onSubmitSuccess(): void {
  formService.resetForm('myAugInstance', 'mainForm');
  this.showSuccessMessage('Form submitted successfully');
}
```

#### `clearFormData(AUGinstanceName, formName)`

Clear all form data from the service.

**When to Use:**
- **Critical**: Always call in `ngOnDestroy()` to prevent memory leaks
- When navigating away from a form component
- Cleaning up temporary form instances
- Removing form data from memory after component unmounts

**Parameters:**
- `AUGinstanceName` (any): AUG instance identifier
- `formName` (string | null): Form name (null clears all forms in instance)

**Example:**
```typescript
// Essential memory cleanup pattern
ngOnDestroy(): void {
  formService.clearFormData('myAugInstance', null);

  // Clean up subscriptions
  for (const sub in this.subscriptions) {
    this.subscriptions[sub]?.unsubscribe();
  }
}
```

#### `deleteFormControl(AUGinstanceName, formName, controlName)`

Delete a specific control from a form.

**When to Use:**
- Lower-level cleanup after `deleteElement()` (usually not needed manually)
- Removing form control without removing from DOM (rare case)
- Programmatic form control management outside AUG's normal flow
- **Note**: Usually prefer `augRef._helper.deleteElement()` which handles both UI and form

**Parameters:**
- `AUGinstanceName` (any): AUG instance identifier
- `formName` (any): Form name
- `controlName` (any): Control name to delete

**Example:**
```typescript
// Rare case: Remove from form but keep in DOM for display
formService.deleteFormControl('myAugInstance', 'mainForm', 'displayOnlyField');
```

#### `addField(uiStructure, uiData)`

Add a new field to the form dynamically.

**Parameters:**
- `uiStructure` (any): Field UI structure configuration
- `uiData` (any): Field data/value

**Example:**
```typescript
formService.addField(
  { type: 'text', name: 'newField', label: 'New Field' },
  { newField: '' }
);
```

#### `setUiDataFromDataProvider(uiStructure, uiData)`

Set UI data with selected options from data provider.

**Parameters:**
- `uiStructure` (any): UI structure configuration
- `uiData` (any): UI data object to populate

**Example:**
```typescript
formService.setUiDataFromDataProvider(structure, data);
```

#### `checkName(uiStructure, property?)`

Check and retrieve name from UI structure.

**Parameters:**
- `uiStructure` (any): UI structure to check
- `property` (string, optional): Property to check (default: 'name')

**Returns:** Name value

**Example:**
```typescript
const fieldName = formService.checkName(fieldStructure);
```

#### Track Methods (for ngFor optimization)

- `trackByName(_index, structure)`: Track by name property
- `trackByLabel(_index, structure)`: Track by label property
- `trackByHeading(_index, structure)`: Track by heading property
- `trackByIcon(_index, icon)`: Track by icon property

**Example:**
```html
<div *ngFor="let field of fields; trackBy: formService.trackByName">
  {{ field.name }}
</div>
```

---

### FormService Complete API Reference

**Source:** `axis-ui-generator/lib/_common/form.service.d.ts`

This section provides a complete reference of all FormService methods and properties.

#### Available Methods

| Method | Parameters | Description | Required |
|--------|------------|-------------|----------|
| `clearFormData()` | `(AUGinstanceName, formName)` | Clears form data from service | **MANDATORY in ngOnDestroy** |
| `resetForm()` | `(AUGinstanceName, formName)` | Resets form to initial state | For reset functionality |
| `startForm()` | `(AUGinstanceName, formName)` | Initializes form in service | Called internally by AUG |
| `getFormMetadata()` | `(AUGinstance)` | Gets form metadata | For advanced usage |
| `deleteFormControl()` | `(AUGinstanceName, formName, controlName)` | Removes control from form | For dynamic fields |
| `registerLayout()` | `(name, component)` | Registers custom layout component | For custom layouts |
| `addField()` | `(uiStructure, uiData)` | Adds field to structure | For dynamic field addition |
| `setUiDataFromDataProvider()` | `(uiStructure, uiData)` | Sets data from provider | For data initialization |
| `checkName()` | `(uiStructure, property?)` | Validates field names | Internal validation |

#### FormService Properties Reference

| Property | Type | Description |
|----------|------|-------------|
| `Form` | `{}` | Access form controls: `formService.Form[instanceName][formName]` |
| `detectChanges` | `Subject<void>` | Trigger change detection: `formService.detectChanges.next()` |
| `componentsRefs` | `{}` | Access component references |
| `AUG_instances` | `{}` | Track AUG instances |
| `mainUiData` | `{}` | Global UI data storage |
| `mainUiStructure` | `{}` | Global UI structure storage |

#### Common Usage Patterns

```typescript
// MANDATORY: Cleanup in ngOnDestroy
ngOnDestroy(): void {
  this.formService.clearFormData('instanceName', null);
}

// Access form for validation
const form = this.formService.Form['instanceName'][null];
if (form?.valid) {
  // Submit form
}

// Trigger change detection after updates
this.formService.detectChanges.next();

// Reset form to initial state
resetForm(): void {
  this.formService.resetForm('instanceName', null);
  this.initializeFormData();
}
```

**IMPORTANT:** FormService does NOT have `saveFormData()` or `getFormData()` methods. For state persistence, use component-level `uiData` object or backend service calls.

---

### FormService Advanced Patterns

#### detectChanges: Triggering Manual Change Detection

The `detectChanges` property is a `Subject<void>` that forces Angular to run change detection for all AUG forms. Use this when you manipulate FormControls directly or need to ensure UI updates after programmatic changes.

**Property:**
```typescript
formService.detectChanges: Subject<void>
```

**When to Use:**
- After programmatically setting form control errors with `setErrors()`
- After marking controls as touched/untouched
- After updating FormControl states (disabled, enabled, validators)
- When UI doesn't reflect programmatic FormControl changes
- After bulk FormControl manipulations

**Pattern 1: Trigger After Setting Validation Errors**

```typescript
// Set custom validation error
const control = this.formService.Form['myFormInstance']?.['mainForm']?.get('email');
if (control) {
  control.setErrors({ customError: 'Email already exists in system' });
  control.markAsTouched();

  // CRITICAL: Trigger change detection to show error in UI
  this.formService.detectChanges.next();
}
```

**Pattern 2: Mark All Controls as Touched on Submit**

```typescript
onSubmit(event: UIEmitEvent): void {
  if (event.form?.model?.invalid) {
    // Mark all controls as touched
    Object.keys(event.form.model.controls).forEach(key => {
      event.form.model.controls[key].markAsTouched();
    });

    // REQUIRED: Trigger change detection to show all errors
    this.formService.detectChanges.next();

    return;
  }

  // Proceed with submission
  this.submitForm(event.form.data);
}
```

**Pattern 3: Bulk Control State Updates**

```typescript
// Disable multiple fields at once
disableFieldsForViewMode(): void {
  const fieldsToDisable = ['name', 'email', 'phone', 'address'];
  const formGroup = this.formService.Form['myFormInstance']?.['mainForm'];

  if (formGroup) {
    fieldsToDisable.forEach(fieldName => {
      const control = formGroup.get(fieldName);
      if (control) {
        control.disable();
      }
    });

    // Trigger change detection to update UI state
    this.formService.detectChanges.next();
  }
}

// Enable fields for edit mode
enableFieldsForEditMode(): void {
  const fieldsToEnable = ['name', 'email', 'phone', 'address'];
  const formGroup = this.formService.Form['myFormInstance']?.['mainForm'];

  if (formGroup) {
    fieldsToEnable.forEach(fieldName => {
      const control = formGroup.get(fieldName);
      if (control) {
        control.enable();
      }
    });

    // Trigger change detection to update UI state
    this.formService.detectChanges.next();
  }
}
```

**Pattern 4: Clear All Validation Errors**

```typescript
clearAllValidationErrors(): void {
  const formGroup = this.formService.Form['myFormInstance']?.['mainForm'];

  if (formGroup) {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.controls[key];
      control.setErrors(null);
      control.markAsUntouched();
      control.markAsPristine();
    });

    // Update UI to reflect clean state
    this.formService.detectChanges.next();
  }
}
```

**Pattern 5: Subscribe to detectChanges for Logging**

```typescript
ngOnInit(): void {
  // Subscribe to detectChanges for debugging
  this.formService.detectChanges.subscribe(() => {
    console.log('Change detection triggered');
    console.log('Form state:', this.formService.Form['myFormInstance']);
  });
}
```

**Key Points:**
- Call `detectChanges.next()` after **every** direct FormControl manipulation
- Always call after `setErrors()`, `markAsTouched()`, `disable()`, `enable()`
- Not needed when using `augRef._helper` methods (they handle it automatically)
- Use for debugging by subscribing to the Subject
- Essential for showing validation errors immediately

---

#### componentsRefs: Accessing Field Component References

The `componentsRefs` property provides direct access to Angular component instances for each field in your AUG forms. This is an advanced pattern for accessing component-specific methods or properties not exposed through standard APIs.

**Property Structure:**
```typescript
formService.componentsRefs: {
  [AUGinstanceName: string]: {
    [fieldName: string]: ComponentRef<any>
  }
}
```

**When to Use:**
- Accessing component-specific methods (e.g., datepicker.open())
- Triggering component animations or effects
- Getting component state not available through FormControl
- Integrating with third-party component libraries
- Advanced debugging of component lifecycle

**Pattern 1: Programmatically Open Datepicker**

```typescript
openDatepicker(fieldName: string): void {
  const componentRef = this.formService.componentsRefs['myFormInstance']?.[fieldName];

  if (componentRef) {
    const datepickerComponent = componentRef.instance as any;

    // Call component-specific method
    if (datepickerComponent.open) {
      datepickerComponent.open();
    }
  }
}

// Usage in template or code
onFieldClick(): void {
  this.openDatepicker('startDate');
}
```

**Pattern 2: Focus a Specific Field Component**

```typescript
focusField(fieldName: string): void {
  const componentRef = this.formService.componentsRefs['myFormInstance']?.[fieldName];

  if (componentRef) {
    const fieldComponent = componentRef.instance as any;

    // Focus using component-specific method
    if (fieldComponent.focus) {
      fieldComponent.focus();
    } else if (fieldComponent.inputElement) {
      // Fallback to native element
      fieldComponent.inputElement.nativeElement.focus();
    }
  }
}

// Focus first invalid field
focusFirstInvalidField(): void {
  const formGroup = this.formService.Form['myFormInstance']?.['mainForm'];

  if (formGroup) {
    const firstInvalid = Object.keys(formGroup.controls).find(
      key => formGroup.controls[key].invalid
    );

    if (firstInvalid) {
      this.focusField(firstInvalid);
    }
  }
}
```

**Pattern 3: Access Dropdown Component State**

```typescript
getDropdownState(fieldName: string): any {
  const componentRef = this.formService.componentsRefs['myFormInstance']?.[fieldName];

  if (componentRef) {
    const dropdownComponent = componentRef.instance as any;

    return {
      isOpen: dropdownComponent.isOpen,
      selectedIndex: dropdownComponent.selectedIndex,
      filteredOptions: dropdownComponent.filteredOptions,
      searchText: dropdownComponent.searchText
    };
  }

  return null;
}

// Usage
checkDropdownState(): void {
  const state = this.getDropdownState('country');
  console.log('Dropdown state:', state);

  if (state?.isOpen) {
    console.log('Dropdown is currently open');
  }
}
```

**Pattern 4: Trigger Component Refresh/Re-render**

```typescript
refreshFieldComponent(fieldName: string): void {
  const componentRef = this.formService.componentsRefs['myFormInstance']?.[fieldName];

  if (componentRef) {
    const component = componentRef.instance as any;

    // Trigger component-specific refresh if available
    if (component.refresh) {
      component.refresh();
    } else if (component.ngOnInit) {
      // Re-run initialization (use with caution)
      component.ngOnInit();
    }

    // Force change detection for this component
    componentRef.changeDetectorRef.detectChanges();
  }
}
```

**Pattern 5: Access Component for Debugging**

```typescript
debugComponent(fieldName: string): void {
  const componentRef = this.formService.componentsRefs['myFormInstance']?.[fieldName];

  if (componentRef) {
    const component = componentRef.instance;

    console.log('Component instance:', component);
    console.log('Component constructor:', component.constructor.name);
    console.log('Component properties:', Object.keys(component));

    // Access specific properties
    console.log('Component value:', (component as any).value);
    console.log('Component disabled:', (component as any).disabled);
  }
}

// Debug all components in form
debugAllComponents(): void {
  const componentRefs = this.formService.componentsRefs['myFormInstance'];

  if (componentRefs) {
    Object.keys(componentRefs).forEach(fieldName => {
      console.log(`Field: ${fieldName}`);
      this.debugComponent(fieldName);
    });
  }
}
```

**Pattern 6: Execute Component Method by Type**

```typescript
executeComponentMethod(fieldName: string, methodName: string, ...args: any[]): any {
  const componentRef = this.formService.componentsRefs['myFormInstance']?.[fieldName];

  if (componentRef) {
    const component = componentRef.instance as any;

    if (typeof component[methodName] === 'function') {
      return component[methodName](...args);
    } else {
      console.warn(`Method ${methodName} not found on component ${fieldName}`);
    }
  }

  return null;
}

// Usage examples
clearDropdownSearch(fieldName: string): void {
  this.executeComponentMethod(fieldName, 'clearSearch');
}

selectDropdownOption(fieldName: string, index: number): void {
  this.executeComponentMethod(fieldName, 'selectByIndex', index);
}

openDatepicker(fieldName: string): void {
  this.executeComponentMethod(fieldName, 'open');
}
```

**Pattern 7: Check Component Readiness**

```typescript
isComponentReady(fieldName: string): boolean {
  const componentRef = this.formService.componentsRefs['myFormInstance']?.[fieldName];

  if (!componentRef) {
    return false;
  }

  const component = componentRef.instance as any;

  // Check if component is initialized
  return component && !component.isDestroyed && component.initialized !== false;
}

// Wait for component to be ready
async waitForComponent(fieldName: string, timeout = 5000): Promise<boolean> {
  const startTime = Date.now();

  while (Date.now() - startTime < timeout) {
    if (this.isComponentReady(fieldName)) {
      return true;
    }

    await new Promise(resolve => setTimeout(resolve, 100));
  }

  return false;
}

// Usage
async setupDropdown(): Promise<void> {
  const isReady = await this.waitForComponent('country');

  if (isReady) {
    this.openDatepicker('country');
  } else {
    console.error('Component not ready within timeout');
  }
}
```

**Key Points:**
- **Advanced pattern** - use only when helper methods insufficient
- Cast to `any` when accessing undocumented component properties
- Always check if component and method exist before calling
- Prefer `augRef._helper` methods over direct component access
- Use for debugging component lifecycle issues
- Access `changeDetectorRef` for manual change detection
- Component availability depends on field visibility (displayIf)

**⚠️ Caution:**
- Direct component manipulation bypasses AUG's internal state management
- May cause synchronization issues between uiData and component state
- Component APIs may change between Axis versions
- Use sparingly and document why helper methods were insufficient
- Prefer observable patterns over direct component manipulation

---

## Usage Examples

For complete working examples and patterns, see:
- **[Usage Examples Guide](./AXIS-UI-GENERATOR-EXAMPLES.md)**

Includes:
- Basic Setup
- Advanced Forms with Conditional Fields
- uiEmitUpdate Event Handling (6 comprehensive patterns)
- Dynamic Field Manipulation
- FormService Integration
- Multi-Step Wizards
- Translation Examples

---

## Advanced Patterns & Best Practices

For advanced techniques, see:
- **[Advanced Patterns Guide](./AXIS-UI-GENERATOR-ADVANCED-PATTERNS.md)**

Includes:
- Pre-populating Form Data
- Complex Validation
- Accessing Form Controls via FormService
- Programmatic Form Refresh
- Monitoring Field Changes
- Error Handling
- Best Practices (10 items)

---

## Troubleshooting

For common issues and anti-patterns, see:
- **[Troubleshooting Guide](./AXIS-UI-GENERATOR-TROUBLESHOOTING.md)**

Includes:
- Common Issues and Solutions
- 8 Common Mistakes and Anti-Patterns
- Decision Tree for Choosing the Right Approach

---

## TypeScript Types Reference

**Complete type definitions have been moved to the axis-types skill for better organization and progressive disclosure.**

### Access Type Definitions

```
Read(file_path: "plugins/AIDLC-axis/skills/axis-types/SKILL.md")
```

### Type Categories

| Category | File | Contains |
|----------|------|----------|
| UI Structure | [axis-ui-generator-types/ui-structure.types.ts](../skills/axis-types/axis-ui-generator-types/ui-structure.types.ts) | Complete UI structure definition |
| UI Data | [axis-ui-generator-types/ui-data.types.ts](../skills/axis-types/axis-ui-generator-types/ui-data.types.ts) | UIData and ComponentStatus |
| Control Types | [axis-ui-generator-types/control.types.ts](../skills/axis-types/axis-ui-generator-types/control.types.ts) | All 78+ control types (ControlType) |
| Base Control | [axis-ui-generator-types/base-control.types.ts](../skills/axis-types/axis-ui-generator-types/base-control.types.ts) | Common properties for all controls |
| Validation | [axis-ui-generator-types/validation.types.ts](../skills/axis-types/axis-ui-generator-types/validation.types.ts) | UIValidators, UIErrorMessages |
| Events | [axis-ui-generator-types/event.types.ts](../skills/axis-types/axis-ui-generator-types/event.types.ts) | UIEvent, UIEmitEvent, UIEmitUpdateEvent, ContentRequest |
| Helper Types | [axis-ui-generator-types/helper.types.ts](../skills/axis-types/axis-ui-generator-types/helper.types.ts) | AUGHelper interface, config types |

### Most Common Types for AUG Code Generation

**Read these first:**
1. `axis-ui-generator-types/ui-structure.types.ts` - Complete UI structure definition
2. `axis-ui-generator-types/ui-data.types.ts` - UIData and ComponentStatus definitions
3. `axis-ui-generator-types/control.types.ts` - All 78+ control types
4. `axis-ui-generator-types/base-control.types.ts` - Common properties for all controls
5. `axis-ui-generator-types/validation.types.ts` - Validators and error messages
6. `axis-ui-generator-types/event.types.ts` - Event and emit types
7. `axis-ui-generator-types/helper.types.ts` - AUGHelper methods and configurations

**Additional type files:**
- `axis-ui-generator-types/conditional.types.ts` - ConditionalLogic interface
- `axis-ui-generator-types/layout.types.ts` - Layout configuration types
- `axis-ui-generator-types/menu.types.ts` - Menu configuration
- `axis-ui-generator-types/route.types.ts` - Navigation configuration

For the complete type system with all definitions, use the axis-types skill with progressive disclosure.

---

## Version Information

This guide is based on Axis UI Generator component definitions. For the latest updates and additional documentation, refer to the official repository or framework documentation.

**Type System Version**: 1.0.0
**Package**: `axis-ui-generator-types`

---

## Additional Resources

- [Axis Components Library Documentation](https://github.aig.net/commercial-it-uiux/axis-ui-generator-ui-5671)
- [Angular Reactive Forms Guide](https://angular.io/guide/reactive-forms)
- [Angular FormControl API](https://angular.io/api/forms/FormControl)
