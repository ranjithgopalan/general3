# Axis UI Generator - Advanced Patterns

> Advanced techniques and best practices for Axis UI Generator
> Main Guide: [AXIS-UI-GENERATOR-GUIDE.md](./AXIS-UI-GENERATOR-GUIDE.md)

## Table of Contents

1. [Pre-populating Form Data](#pre-populating-form-data)
2. [Handling Complex Validation](#handling-complex-validation)
3. [Accessing Form Controls via FormService](#accessing-form-controls-via-formservice)
4. [Programmatic Form Refresh](#programmatic-form-refresh)
5. [Monitoring Field Changes](#monitoring-field-changes)
6. [Error Handling](#error-handling)
7. [Best Practices](#best-practices)

---

## Advanced Patterns

### Pre-populating Form Data

```typescript
ngOnInit(): void {
  // Define structure first
  this.uiStructure = { /* ... */ };

  // Pre-populate data
  this.uiData = {
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@example.com'
  };
}
```

### Handling Complex Validation

```typescript
{
  type: 'text',
  name: 'password',
  label: 'Password',
  inputType: 'password',
  validators: {
    required: true,
    minlength: 8,
    pattern: '^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$'
  },
  errorMessages: {
    required: 'Password is required',
    minlength: 'Password must be at least 8 characters',
    pattern: 'Password must contain uppercase, lowercase, and numbers'
  }
}
```

### Accessing Form Controls via FormService

```typescript
export class FormAccessComponent implements OnInit {
  constructor(private formService: FormService) {}

  getFieldValue(fieldName: string): any {
    const augInstance = 'myAugInstance';
    const formName = 'mainForm';

    if (this.formService.Form[augInstance] &&
        this.formService.Form[augInstance][formName]) {
      const control = this.formService.Form[augInstance][formName].get(fieldName);
      return control?.value;
    }
    return null;
  }

  setFieldValue(fieldName: string, value: any): void {
    const augInstance = 'myAugInstance';
    const formName = 'mainForm';

    if (this.formService.Form[augInstance] &&
        this.formService.Form[augInstance][formName]) {
      const control = this.formService.Form[augInstance][formName].get(fieldName);
      control?.setValue(value);
    }
  }

  isFieldValid(fieldName: string): boolean {
    const augInstance = 'myAugInstance';
    const formName = 'mainForm';

    if (this.formService.Form[augInstance] &&
        this.formService.Form[augInstance][formName]) {
      const control = this.formService.Form[augInstance][formName].get(fieldName);
      return control?.valid || false;
    }
    return false;
  }
}
```

### Programmatic Form Refresh

```typescript
export class RefreshFormComponent {
  public refresh = {};

  triggerRefresh(): void {
    // Trigger refresh by reassigning reference
    this.refresh = { ...this.refresh, timestamp: Date.now() };
  }

  refreshSpecificElement(elementName: string): void {
    if (this.augRef) {
      this.augRef._helper.refreshElement({
        elementName: elementName,
        AUGinstance: 'myAugInstance'
      });
    }
  }

  recreateForm(): void {
    if (this.augRef) {
      this.augRef._helper.refreshClear();
    }
  }
}
```

### Monitoring Field Changes

```typescript
onUpdate(event: any): void {
  if (event?.eventInfo?.eventSource) {
    const source = event.eventInfo.eventSource;
    console.log('Field changed:', source.name);
    console.log('New value:', event.form.model.value[source.name]);

    // React to specific field changes
    if (source.name === 'country') {
      this.updateStateOptions(event.form.model.value.country);
    }
  }
}
```

### Error Handling

```typescript
onSubmit(event: any): void {
  if (event?.form?.model) {
    if (event.form.model.valid) {
      this.submitForm(event.form.model.value);
    } else {
      // Get all invalid fields
      const invalidFields = Object.keys(event.form.model.controls)
        .filter(key => event.form.model.controls[key].invalid);

      console.log('Invalid fields:', invalidFields);

      // Mark all fields as touched to show errors
      Object.keys(event.form.model.controls).forEach(key => {
        event.form.model.controls[key].markAsTouched();
      });
    }
  }
}
```

---

## Best Practices

1. **Always provide unique IDs** for AUG instances in `uiStructure.id`
2. **Clean up on destroy**: Reset form data and complete subscriptions in `ngOnDestroy`
3. **Use FormService for programmatic access**: Access form state through FormService rather than direct manipulation
4. **Leverage helper methods**: Use `augRef._helper` methods for dynamic operations
5. **Implement proper validation**: Define validators in uiStructure for consistency
6. **Handle both uiEmit and uiEmitUpdate**: Use uiEmit for submissions and uiEmitUpdate for real-time changes
7. **Store augRef reference**: Capture the augRef output event for programmatic control
8. **Use conditional interactions**: Leverage displayIf, disableIf, requireIf for dynamic behavior
9. **Optimize with trackBy**: Use FormService track methods in ngFor loops
10. **Test with different layouts**: Verify your forms work with different layout types

---

## Quick Reference Links

- [Main Guide](./AXIS-UI-GENERATOR-GUIDE.md) - Complete API reference and decision guide
- [Usage Examples](./AXIS-UI-GENERATOR-EXAMPLES.md) - Working examples and patterns
- [Troubleshooting](./AXIS-UI-GENERATOR-TROUBLESHOOTING.md) - Common issues and anti-patterns
