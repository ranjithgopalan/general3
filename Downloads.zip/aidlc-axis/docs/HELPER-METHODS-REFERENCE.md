# Documented Helper Methods Reference

**Purpose**: Complete list of documented axis-ui-generator helper methods with signatures and examples

**When to Use**: Before implementing field manipulation logic to verify method availability

---

## Critical Principle

**ONLY use methods documented in this list. Undocumented methods are not guaranteed to work and may cause runtime errors.**

---

## Documented Methods Whitelist

### 1. setData()

**Purpose**: Set value for a specific form field

**Signature**:
```typescript
augRef._helper.setData(
  controlName: string,
  data: any,
  AUGinstance?: string,
  formName?: string,
  setValueOptions?: { onlySelf?: boolean; emitEvent?: boolean }
): void
```

**Parameters**:
- `controlName`: Name of the field to update
- `data`: New value to set
- `AUGinstance` (optional): Instance name (use when multiple AUG instances)
- `formName` (optional): Form name (use when multiple forms in instance)
- `setValueOptions` (optional): Angular form control setValue options

**Example**:
```typescript
// Simple usage
this.augRef._helper.setData('email', 'user@example.com');

// With instance
this.augRef._helper.setData('email', 'user@example.com', 'clientInformationInstance');

// With form name
this.augRef._helper.setData('email', 'user@example.com', 'myInstance', 'contactForm');

// With options
this.augRef._helper.setData('email', 'user@example.com', 'myInstance', null, {
  emitEvent: false
});
```

**When to Use**:
- Setting field value programmatically
- Updating fields based on dependencies
- Pre-populating form from API data

---

### 2. addElement()

**Purpose**: Dynamically add a new field to the form

**Signature**:
```typescript
augRef._helper.addElement(config: AddElementConfig): void

interface AddElementConfig {
  AUG: any;
  AUGinstance: string;
  element: UIControl;
  parentElement?: string;
  position?: number;
}
```

**Parameters**:
- `AUG`: Reference to augRef
- `AUGinstance`: Instance name
- `element`: UIControl object to add
- `parentElement` (optional): Parent container name
- `position` (optional): Index position to insert

**Example**:
```typescript
// Add new field
this.augRef._helper.addElement({
  AUG: this.augRef,
  AUGinstance: 'clientInformationInstance',
  element: {
    type: 'text',
    name: 'newField',
    label: 'New Field',
    required: true
  }
});

// Add to specific parent at position
this.augRef._helper.addElement({
  AUG: this.augRef,
  AUGinstance: 'myInstance',
  element: newFieldControl,
  parentElement: 'addressSection',
  position: 2
});
```

**When to Use**:
- Adding fields dynamically based on conditions
- Building forms on-the-fly
- Implementing "Add Another" functionality

---

### 3. deleteElement()

**Purpose**: Remove a field from the form

**Signature**:
```typescript
augRef._helper.deleteElement(
  AUG: any,
  AUGinstanceName: string,
  controlName: string,
  deleteChildren?: boolean,
  clearUiStructure?: boolean
): void
```

**Parameters**:
- `AUG`: Reference to augRef
- `AUGinstanceName`: Instance name
- `controlName`: Name of field to delete
- `deleteChildren` (optional): Also delete child elements
- `clearUiStructure` (optional): Remove from UI structure

**Example**:
```typescript
// Simple deletion
this.augRef._helper.deleteElement(
  this.augRef,
  'clientInformationInstance',
  'temporaryField'
);

// Delete with children
this.augRef._helper.deleteElement(
  this.augRef,
  'myInstance',
  'addressSection',
  true  // Delete all child fields
);

// Delete and clear from structure
this.augRef._helper.deleteElement(
  this.augRef,
  'myInstance',
  'oldField',
  false,
  true  // Remove from uiStructure
);
```

**When to Use**:
- Removing fields based on conditions
- Implementing "Remove" functionality
- Cleaning up conditional fields

---

### 4. refreshElement()

**Purpose**: Trigger change detection for a specific element or entire form

**Signature**:
```typescript
augRef._helper.refreshElement(config?: RefreshElementConfig): void

interface RefreshElementConfig {
  elementName?: string;
  AUGinstance?: string;
  formName?: string;
}
```

**Parameters**:
- `elementName` (optional): Specific element to refresh (if omitted, refreshes all)
- `AUGinstance` (optional): Instance name
- `formName` (optional): Form name

**Example**:
```typescript
// Refresh specific element
this.augRef._helper.refreshElement({
  elementName: 'city',
  AUGinstance: 'clientInformationInstance'
});

// Refresh entire form
this.augRef._helper.refreshElement({
  AUGinstance: 'clientInformationInstance'
});

// Refresh specific form
this.augRef._helper.refreshElement({
  AUGinstance: 'myInstance',
  formName: 'addressForm'
});

// Refresh everything (no params)
this.augRef._helper.refreshElement();
```

**When to Use**:
- After updating uiStructure properties (options, validators, etc.)
- After manual DOM manipulation
- When conditional logic changes field visibility
- To force re-render

---

### 5. recreateElement()

**Purpose**: Completely recreate an element (destroy and rebuild)

**Signature**:
```typescript
augRef._helper.recreateElement(config: RecreateElementConfig): void

interface RecreateElementConfig {
  elementName: string;
  AUGinstance: string;
  formName?: string;
}
```

**Parameters**:
- `elementName`: Name of element to recreate
- `AUGinstance`: Instance name
- `formName` (optional): Form name

**Example**:
```typescript
// Recreate element
this.augRef._helper.recreateElement({
  elementName: 'dynamicField',
  AUGinstance: 'clientInformationInstance'
});

// Recreate in specific form
this.augRef._helper.recreateElement({
  elementName: 'addressField',
  AUGinstance: 'myInstance',
  formName: 'addressForm'
});
```

**When to Use**:
- When field type changes (text → dropdown)
- When field structure significantly changes
- After major configuration updates
- As alternative to refresh for complex changes

---

### 6. updateFieldsConditionally()

**Purpose**: Trigger evaluation of conditional logic (displayIf, requireIf, disableIf)

**Signature**:
```typescript
augRef._helper.updateFieldsConditionally(config: UpdateFieldsConfig): void

interface UpdateFieldsConfig {
  AUGinstance: string;
  formName?: string;
  fieldName?: string;
}
```

**Parameters**:
- `AUGinstance`: Instance name
- `formName` (optional): Specific form to update
- `fieldName` (optional): Specific field to evaluate

**Example**:
```typescript
// Update all conditionals
this.augRef._helper.updateFieldsConditionally({
  AUGinstance: 'clientInformationInstance'
});

// Update conditionals for specific form
this.augRef._helper.updateFieldsConditionally({
  AUGinstance: 'myInstance',
  formName: 'addressForm'
});

// Update conditionals for specific field
this.augRef._helper.updateFieldsConditionally({
  AUGinstance: 'myInstance',
  fieldName: 'dependentField'
});
```

**When to Use**:
- After changing field values that trigger conditions
- When conditional logic depends on external state
- To force re-evaluation of all conditionals

---

### 7. checkAllInteractions()

**Purpose**: Check all interaction conditions for a specific control

**Signature**:
```typescript
augRef._helper.checkAllInteractions(AUG: any, controlName: string): void
```

**Parameters**:
- `AUG`: Reference to augRef
- `controlName`: Name of control to check

**Example**:
```typescript
// Check interactions for field
this.augRef._helper.checkAllInteractions(this.augRef, 'emailField');

// After programmatic change
this.augRef._helper.setData('country', 'US', 'myInstance');
this.augRef._helper.checkAllInteractions(this.augRef, 'country');
```

**When to Use**:
- After programmatic field changes
- To trigger interaction-based conditionals
- When field relationships need re-evaluation

---

### 8. clearFormData() (FormService method)

**Purpose**: Clean up form data on component destroy

**Signature**:
```typescript
formService.clearFormData(AUGinstanceName: string, formName: string | null): void
```

**Parameters**:
- `AUGinstanceName`: Instance name to clear
- `formName`: Form name to clear (use `null` to clear all forms)

**Example**:
```typescript
// In ngOnDestroy
ngOnDestroy(): void {
  // Clear all forms in instance
  this.formService.clearFormData('clientInformationInstance', null);

  // Clear specific form
  this.formService.clearFormData('myInstance', 'contactForm');
}

// Clear multiple forms
ngOnDestroy(): void {
  this.formService.clearFormData('myInstance', 'form1');
  this.formService.clearFormData('myInstance', 'form2');
}
```

**When to Use**:
- **MANDATORY** in ngOnDestroy lifecycle hook
- To prevent memory leaks
- To clean up form state on component unmount

---

## PROHIBITED Methods (NOT Documented)

These methods are **NOT documented** and should **NEVER** be used:

### ❌ setFieldValue()
**Why prohibited**: Not in official documentation
**Use instead**: `setData()`
```typescript
// ❌ DON'T USE
augRef._helper.setFieldValue('email', 'test@example.com');

// ✅ USE THIS
augRef._helper.setData('email', 'test@example.com', 'myInstance');
```

---

### ❌ setFieldOptions()
**Why prohibited**: Not in official documentation
**Use instead**: Update `uiStructure` directly + call `refreshElement()`
```typescript
// ❌ DON'T USE
augRef._helper.setFieldOptions('dropdown', newOptions);

// ✅ USE THIS
const field = this.uiStructure.sections.main.fields.find(f => f.name === 'dropdown');
field.dataProvider = newOptions;
augRef._helper.refreshElement({ elementName: 'dropdown', AUGinstance: 'myInstance' });
```

---

### ❌ setFieldError()
**Why prohibited**: Not in official documentation
**Use instead**: Set validators in uiStructure + call `refreshElement()`

---

### ❌ clearFieldError()
**Why prohibited**: Not in official documentation
**Use instead**: Update validators in uiStructure

---

### ❌ updateFieldData()
**Why prohibited**: Not in official documentation
**Use instead**: `setData()`

---

### ❌ setFieldProperty()
**Why prohibited**: Not in official documentation
**Use instead**: Update uiStructure property + call `refreshElement()`

---

## Common Usage Patterns

### Pattern 1: Update Field Value

```typescript
// Simple update
this.augRef._helper.setData('email', newEmail, 'myInstance');
```

### Pattern 2: Update Dropdown Options

```typescript
// Find field in structure
const field = this.findFieldInStructure('stateDropdown');
if (field && 'dataProvider' in field) {
  field.dataProvider = newStateOptions;
}

// Refresh to show new options
this.augRef._helper.refreshElement({
  elementName: 'stateDropdown',
  AUGinstance: 'myInstance'
});
```

### Pattern 3: Conditional Field Display

```typescript
// When parent field changes
handleFieldChange(fieldName: string, newValue: unknown): void {
  if (fieldName === 'country' && typeof newValue === 'string') {
    // Update dependent field options
    this.loadStatesForCountry(newValue);

    // Trigger conditional evaluation
    this.augRef._helper.updateFieldsConditionally({
      AUGinstance: 'myInstance'
    });
  }
}
```

### Pattern 4: Add/Remove Dynamic Fields

```typescript
// Add additional field
addAdditionalInsured(): void {
  const newField: UIControl = {
    type: 'container',
    name: `additionalInsured${this.insuredCount}`,
    label: `Additional Insured ${this.insuredCount}`,
    fields: [
      { type: 'text', name: 'name', label: 'Name', required: true },
      { type: 'text', name: 'relationship', label: 'Relationship' }
    ]
  };

  this.augRef._helper.addElement({
    AUG: this.augRef,
    AUGinstance: 'myInstance',
    element: newField,
    parentElement: 'insuredSection'
  });

  this.insuredCount++;
}

// Remove field
removeAdditionalInsured(index: number): void {
  this.augRef._helper.deleteElement(
    this.augRef,
    'myInstance',
    `additionalInsured${index}`,
    true  // Delete children
  );
}
```

### Pattern 5: Cleanup on Destroy

```typescript
@Component({...})
export class MyComponent implements OnDestroy {
  private formService = inject(FormService);

  ngOnDestroy(): void {
    // MANDATORY: Clean up form data
    this.formService.clearFormData('myInstance', null);
  }
}
```

---

## Method Selection Guide

**Use this decision tree to choose the right method:**

```
Need to change field value?
└─> setData()

Need to update dropdown options?
└─> Update uiStructure.field.dataProvider + refreshElement()

Need to add/remove field?
├─> Add: addElement()
└─> Remove: deleteElement()

Field not updating visually?
└─> refreshElement()

Field structure changed significantly?
└─> recreateElement()

Conditional logic not working?
└─> updateFieldsConditionally()

Interaction conditions need checking?
└─> checkAllInteractions()

Component being destroyed?
└─> clearFormData() in ngOnDestroy
```

---

## Validation Before Use

Before using any helper method:

1. ✅ **Verify augRef is captured**:
   ```typescript
   if (!this.augRef) {
     console.error('augRef not captured');
     return;
   }
   ```

2. ✅ **Verify instance name is correct**:
   ```typescript
   const instanceName = 'myInstance';  // Must match [id] in template
   ```

3. ✅ **Verify field exists** (for field-specific operations):
   ```typescript
   const field = this.findFieldInStructure(fieldName);
   if (!field) {
     console.error(`Field ${fieldName} not found`);
     return;
   }
   ```

---

## Further Reading

- **AXIS-UI-GENERATOR-GUIDE.md**: Complete usage guide with advanced patterns
- **TYPE-SAFETY-REFERENCE.md**: TypeScript typing for helper methods
- **VALIDATION-CHECKLIST.md**: Validate helper method usage before writing files

---

**Last Updated**: 2026-02-02
**Version**: 1.0.0
