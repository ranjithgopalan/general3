# axis-tools Plugin: Detailed High-Priority Feedback

**Date:** 2025-11-25
**Component:** CoverageModificationComponent
**Input LLD:** test-data/ui-design/policy-renewal-ui-lld.md
**Generated Output:** generatedoutputs/axis-tools/ui-components/coverage-modification/

---

## HIGH PRIORITY ISSUE #1: Missing Axis UI Components

### Problem Statement

The generated template uses native HTML elements instead of the Axis UI component library. This defeats the purpose of the axis-tools plugin, which should generate Angular code using the Axis framework.

### Expected vs Generated Comparison

#### Template Structure

**EXPECTED (from LLD Section 5.1-5.3):**
```html
<!-- Using Axis components -->
<axis-card class="coverage-section">
  <axis-card-header>
    <h2>Coverage Modification</h2>
    <axis-badge *ngIf="hasChanges()" variant="warning">Unsaved Changes</axis-badge>
  </axis-card-header>

  <axis-card-content>
    <form [formGroup]="coverageForm">

      <!-- Coverage Type Selection -->
      <axis-dropdown
        formControlName="coverageType"
        label="Coverage Type"
        [required]="true"
        [options]="coverageTypeOptions"
        placeholder="Select coverage type"
        [attr.aria-label]="ARIA_LABELS.coverageType"
        [attr.aria-describedby]="'coverageType-hint'">
      </axis-dropdown>

      <!-- Coverage Limit Input -->
      <axis-input
        formControlName="coverageLimit"
        type="currency"
        label="Coverage Limit"
        [required]="true"
        [axisMask]="'currency'"
        placeholder="Enter coverage limit"
        [attr.aria-label]="ARIA_LABELS.coverageLimit"
        [attr.aria-describedby]="'coverageLimit-hint'">
        <axis-hint id="coverageLimit-hint">
          Min: $10,000 | Max: $5,000,000 | Increments of $5,000
        </axis-hint>
        <axis-error *ngIf="coverageForm.get('coverageLimit')?.errors?.['minCoverageLimit']">
          {{ COVERAGE_ERROR_MESSAGES['coverageLimit'].min }}
        </axis-error>
      </axis-input>

      <!-- Deductible Selection -->
      <axis-radio-group
        formControlName="deductible"
        label="Deductible"
        [required]="true"
        [options]="deductibleOptions"
        [attr.aria-label]="ARIA_LABELS.deductible">
      </axis-radio-group>

    </form>
  </axis-card-content>

  <axis-card-actions>
    <axis-button
      variant="secondary"
      (click)="onReset()"
      [disabled]="!hasChanges() || isSaving()"
      [attr.aria-label]="ARIA_LABELS.resetToDefault">
      Reset
    </axis-button>
    <axis-button
      variant="primary"
      (click)="onSave()"
      [disabled]="!hasChanges() || !isValid() || isSaving()"
      [loading]="isSaving()"
      [attr.aria-label]="ARIA_LABELS.saveChanges">
      Save Changes
    </axis-button>
  </axis-card-actions>
</axis-card>

<!-- Premium Impact Summary -->
<axis-card class="premium-summary" *ngIf="premiumImpact()">
  <axis-alert
    [variant]="premiumImpact()!.totalChange > 0 ? 'warning' : 'success'"
    [dismissible]="false">
    <axis-icon [name]="premiumImpact()!.totalChange > 0 ? 'trending-up' : 'trending-down'" slot="icon"></axis-icon>
    Premium {{ premiumImpact()!.totalChange > 0 ? 'increase' : 'decrease' }}:
    {{ formatCurrency(Math.abs(premiumImpact()!.totalChange)) }}
  </axis-alert>
</axis-card>

<!-- Cross-field validation error -->
<axis-alert
  *ngIf="coverageForm.errors?.['deductibleLimitRatio']"
  variant="danger"
  role="alert"
  aria-live="assertive">
  {{ coverageForm.errors?.['deductibleLimitRatio'].message }}
</axis-alert>
```

**GENERATED (coverage-modification.component.html):**
```html
<!-- Using native HTML elements -->
<div class="coverage-modification" role="main" aria-labelledby="coverage-title">

  <header class="coverage-header">
    <h2 id="coverage-title">Coverage Modification</h2>
    @if (hasChanges()) {
      <span class="unsaved-indicator" role="status" aria-live="polite">Unsaved Changes</span>
    }
  </header>

  <!-- Loading State -->
  @if (isLoading()) {
    <div class="loading-overlay" role="status" aria-busy="true">
      <span class="spinner"></span>
      <p>Loading coverage options...</p>
    </div>
  }

  <!-- Coverage Form -->
  <form [formGroup]="coverageForm" class="coverage-form" aria-label="Coverage modification form">

    <!-- Coverage Type - SHOULD BE axis-dropdown -->
    <div class="form-group">
      <label for="coverageType" class="form-label">
        Coverage Type <span class="required">*</span>
      </label>
      <select
        id="coverageType"
        formControlName="coverageType"
        class="form-control"
        aria-required="true">
        <option value="">Select coverage type</option>
        @for (coverage of coverages(); track coverage.id) {
          <option [value]="coverage.type">{{ coverage.name }}</option>
        }
      </select>
    </div>

    <!-- Coverage Limit - SHOULD BE axis-input with currency mask -->
    <div class="form-group">
      <label for="coverageLimit" class="form-label">
        Coverage Limit <span class="required">*</span>
      </label>
      <div class="input-group">
        <span class="input-prefix">$</span>
        <input
          type="number"
          id="coverageLimit"
          formControlName="coverageLimit"
          class="form-control"
          placeholder="Enter coverage limit"
          aria-required="true">
      </div>
      <small id="coverageLimit-hint" class="form-hint">
        Min: $10,000 | Max: $5,000,000 | Increments of $5,000
      </small>
    </div>

    <!-- Deductible - SHOULD BE axis-radio-group or axis-dropdown -->
    <div class="form-group">
      <label for="deductible" class="form-label">
        Deductible <span class="required">*</span>
      </label>
      <select
        id="deductible"
        formControlName="deductible"
        class="form-control"
        aria-required="true">
        <option [ngValue]="null">Select deductible</option>
        @for (option of selectedCoverage()?.deductibleOptions || []; track option.id) {
          <option [ngValue]="option">{{ option.label }}</option>
        }
      </select>
    </div>

  </form>

  <!-- Actions - SHOULD BE axis-button -->
  <footer class="coverage-actions">
    <button
      type="button"
      class="btn btn-secondary"
      (click)="onReset()"
      [disabled]="!hasChanges() || isSaving()">
      Reset
    </button>
    <button
      type="button"
      class="btn btn-primary"
      (click)="onSave()"
      [disabled]="!hasChanges() || !isValid() || isSaving()">
      @if (isSaving()) {
        <span class="spinner-small"></span> Saving...
      } @else {
        Save Changes
      }
    </button>
  </footer>
</div>
```

### Element-by-Element Mapping Required

| Native HTML Used | Should Be Axis Component | Properties to Include |
|------------------|--------------------------|----------------------|
| `<div class="coverage-modification">` | `<axis-card>` | variant, elevation |
| `<header>` | `<axis-card-header>` | - |
| `<span class="unsaved-indicator">` | `<axis-badge variant="warning">` | variant, size |
| `<div class="loading-overlay">` | `<axis-spinner>` | size, label |
| `<select formControlName="coverageType">` | `<axis-dropdown>` | options, placeholder, label, required |
| `<input type="number">` | `<axis-input type="currency">` | axisMask="currency", prefix="$" |
| `<select formControlName="deductible">` | `<axis-dropdown>` or `<axis-radio-group>` | options, label |
| `<small class="form-hint">` | `<axis-hint>` | - |
| `<div class="form-error">` | `<axis-error>` | - |
| `<button class="btn btn-secondary">` | `<axis-button variant="secondary">` | variant, disabled, loading |
| `<button class="btn btn-primary">` | `<axis-button variant="primary">` | variant, disabled, loading |
| `<span class="spinner">` | `<axis-spinner>` | size |
| Cross-field error div | `<axis-alert variant="danger">` | variant, dismissible |

### Impact Assessment

| Impact Area | Severity | Description |
|-------------|----------|-------------|
| UI Consistency | HIGH | Components won't match enterprise Axis design system |
| Accessibility | MEDIUM | Axis components have built-in ARIA; native HTML needs manual implementation |
| Theming | HIGH | Native HTML won't respond to Axis theme changes |
| Maintainability | MEDIUM | Developers expect Axis components in an Axis-based project |
| Code Review | HIGH | Will fail enterprise code review requiring Axis framework |

### Recommended Fix

The axis-tools agent should:

1. **Parse the Axis Component Mapping section** (LLD Section 5.1-5.3)
2. **Use the correct Axis component** for each form element type
3. **Include all Axis-specific attributes** (variant, loading, axisMask, etc.)
4. **Import Axis modules** in the component

```typescript
// Required imports in component
import {
  AxisCardModule,
  AxisButtonModule,
  AxisDropdownModule,
  AxisInputModule,
  AxisRadioGroupModule,
  AxisBadgeModule,
  AxisAlertModule,
  AxisSpinnerModule,
  AxisHintModule,
  AxisErrorModule
} from '@anthropic/axis-ui';

@Component({
  // ...
  imports: [
    CommonModule,
    ReactiveFormsModule,
    // Axis modules
    AxisCardModule,
    AxisButtonModule,
    AxisDropdownModule,
    AxisInputModule,
    AxisRadioGroupModule,
    AxisBadgeModule,
    AxisAlertModule,
    AxisSpinnerModule
  ],
})
```

---

## HIGH PRIORITY ISSUE #2: Incomplete HLR-1 Cross-Field Validators

### Problem Statement

The LLD specifies 8 cross-field validators for the CoverageModificationComponent, but only 4 generic validators were implemented. The missing validators are critical for business rule enforcement.

### Validators Comparison

#### EXPECTED (from LLD Section 2.5)

| Validator | Purpose | Implementation Status |
|-----------|---------|----------------------|
| `liabilityLimitsValidator` | Per-person ≤ per-accident | **MISSING** |
| `crossFieldCoverageValidator` | Lienholder requires full coverage | **MISSING** |
| `uninsuredMotoristValidator` | UM ≤ liability limits | **MISSING** |
| `stateMinimumValidator` | Meets state minimum requirements | **MISSING** |
| `deductibleLimitRatioValidator` | Deductible ≤ 10% of limit | Implemented |
| `coverageLimitStepValidator` | Limit in $5,000 increments | Implemented |
| `minCoverageLimitValidator` | Limit ≥ $10,000 | Implemented |
| `maxCoverageLimitValidator` | Limit ≤ $5,000,000 | Implemented |

### Missing Validator #1: liabilityLimitsValidator

**LLD Specification:**
```typescript
/**
 * HLR-1: Liability limits must follow per-person <= per-accident pattern
 * Business Rule: Per-person bodily injury cannot exceed per-accident limit
 */
export function liabilityLimitsValidator(group: FormGroup): ValidationErrors | null {
  const perPerson = group.get('bodilyInjuryPerPerson')?.value;
  const perAccident = group.get('bodilyInjuryPerAccident')?.value;

  if (perPerson > perAccident) {
    return {
      liabilityLimits: {
        message: 'Per-person liability cannot exceed per-accident liability',
        field: 'bodilyInjuryPerPerson',
        perPerson,
        perAccident
      }
    };
  }
  return null;
}
```

**Why it's critical:**
- Standard insurance industry rule
- Prevents invalid coverage configurations
- Required for policy issuance

**Test Cases Required:**
```typescript
describe('liabilityLimitsValidator', () => {
  it('should pass when perPerson <= perAccident', () => {
    const form = createForm({ perPerson: 100000, perAccident: 300000 });
    expect(liabilityLimitsValidator(form)).toBeNull();
  });

  it('should fail when perPerson > perAccident', () => {
    const form = createForm({ perPerson: 500000, perAccident: 300000 });
    expect(liabilityLimitsValidator(form)).toEqual({
      liabilityLimits: expect.objectContaining({
        message: 'Per-person liability cannot exceed per-accident liability'
      })
    });
  });

  it('should pass when values are equal', () => {
    const form = createForm({ perPerson: 100000, perAccident: 100000 });
    expect(liabilityLimitsValidator(form)).toBeNull();
  });
});
```

---

### Missing Validator #2: crossFieldCoverageValidator

**LLD Specification:**
```typescript
/**
 * HLR-1: Financed vehicles require both collision and comprehensive
 * Business Rule: If vehicle has lienholder, full coverage is mandatory
 */
export function crossFieldCoverageValidator(group: FormGroup): ValidationErrors | null {
  const collisionEnabled = group.get('collision.enabled')?.value;
  const comprehensiveEnabled = group.get('comprehensive.enabled')?.value;
  const hasLienholder = group.get('hasLienholder')?.value;

  if (hasLienholder && (!collisionEnabled || !comprehensiveEnabled)) {
    return {
      lienholderCoverage: {
        message: 'Collision and Comprehensive coverage required for financed vehicles',
        fields: ['collision.enabled', 'comprehensive.enabled'],
        hasLienholder: true
      }
    };
  }

  return null;
}
```

**Why it's critical:**
- Legal requirement for financed vehicles
- Protects lienholder interests
- Prevents policy rejection at underwriting

**Test Cases Required:**
```typescript
describe('crossFieldCoverageValidator', () => {
  it('should pass when no lienholder', () => {
    const form = createForm({ hasLienholder: false, collision: false, comprehensive: false });
    expect(crossFieldCoverageValidator(form)).toBeNull();
  });

  it('should pass when lienholder and full coverage', () => {
    const form = createForm({ hasLienholder: true, collision: true, comprehensive: true });
    expect(crossFieldCoverageValidator(form)).toBeNull();
  });

  it('should fail when lienholder but no collision', () => {
    const form = createForm({ hasLienholder: true, collision: false, comprehensive: true });
    expect(crossFieldCoverageValidator(form)).toEqual({
      lienholderCoverage: expect.objectContaining({
        message: 'Collision and Comprehensive coverage required for financed vehicles'
      })
    });
  });

  it('should fail when lienholder but no comprehensive', () => {
    const form = createForm({ hasLienholder: true, collision: true, comprehensive: false });
    expect(crossFieldCoverageValidator(form)).not.toBeNull();
  });
});
```

---

### Missing Validator #3: uninsuredMotoristValidator

**LLD Specification:**
```typescript
/**
 * HLR-1: UM/UIM limits cannot exceed liability limits
 * Business Rule: Uninsured motorist coverage capped by liability coverage
 */
export function uninsuredMotoristValidator(group: FormGroup): ValidationErrors | null {
  const liabilityBI = group.get('liability.bodilyInjuryPerPerson')?.value;
  const umBI = group.get('uninsuredMotorist.bodilyInjury')?.value;

  if (umBI > liabilityBI) {
    return {
      umLimits: {
        message: 'Uninsured motorist coverage cannot exceed liability coverage',
        field: 'uninsuredMotorist.bodilyInjury',
        umLimit: umBI,
        liabilityLimit: liabilityBI
      }
    };
  }
  return null;
}
```

**Why it's critical:**
- State insurance regulation in most states
- Actuarial pricing requirement
- Prevents over-insurance scenarios

---

### Missing Validator #4: stateMinimumValidator

**LLD Specification:**
```typescript
/**
 * HLR-1: Coverage must meet state minimum requirements
 * Business Rule: Policy cannot be issued below state minimums
 */
export interface StateMinimumCoverage {
  state: string;
  bodilyInjuryPerPerson: number;
  bodilyInjuryPerAccident: number;
  propertyDamage: number;
  uninsuredMotorist?: number;
}

export function stateMinimumValidator(minimums: StateMinimumCoverage): ValidatorFn {
  return (group: AbstractControl): ValidationErrors | null => {
    const form = group as FormGroup;
    const errors: string[] = [];

    const liabilityBI = form.get('liability.bodilyInjuryPerPerson')?.value;
    const liabilityPD = form.get('liability.propertyDamage')?.value;

    if (liabilityBI < minimums.bodilyInjuryPerPerson) {
      errors.push(`Bodily Injury must be at least $${minimums.bodilyInjuryPerPerson.toLocaleString()}`);
    }

    if (liabilityPD < minimums.propertyDamage) {
      errors.push(`Property Damage must be at least $${minimums.propertyDamage.toLocaleString()}`);
    }

    if (errors.length > 0) {
      return {
        stateMinimum: {
          message: errors.join('; '),
          state: minimums.state,
          errors
        }
      };
    }

    return null;
  };
}

// Example state minimums
const STATE_MINIMUMS: Record<string, StateMinimumCoverage> = {
  'CA': { state: 'CA', bodilyInjuryPerPerson: 15000, bodilyInjuryPerAccident: 30000, propertyDamage: 5000 },
  'TX': { state: 'TX', bodilyInjuryPerPerson: 30000, bodilyInjuryPerAccident: 60000, propertyDamage: 25000 },
  'FL': { state: 'FL', bodilyInjuryPerPerson: 10000, bodilyInjuryPerAccident: 20000, propertyDamage: 10000 },
  'NY': { state: 'NY', bodilyInjuryPerPerson: 25000, bodilyInjuryPerAccident: 50000, propertyDamage: 10000 },
  // ... other states
};
```

**Why it's critical:**
- Legal compliance requirement
- Policy cannot be issued below minimums
- State-specific business rule

---

### FormGroup Structure Mismatch

#### EXPECTED FormGroup (from LLD Section 2.4)

```typescript
export function createCoverageForm(fb: FormBuilder): FormGroup {
  return fb.group({
    // Liability Coverage - Detailed breakdown
    liability: fb.group({
      bodilyInjuryPerPerson: [100000, [Validators.required, Validators.min(25000)]],
      bodilyInjuryPerAccident: [300000, [Validators.required, Validators.min(50000)]],
      propertyDamage: [100000, [Validators.required, Validators.min(15000)]]
    }, { validators: [liabilityLimitsValidator] }),

    // Collision Coverage
    collision: fb.group({
      enabled: [true],
      deductible: [500, [Validators.required, Validators.min(100), Validators.max(2500)]]
    }),

    // Comprehensive Coverage
    comprehensive: fb.group({
      enabled: [true],
      deductible: [250, [Validators.required, Validators.min(100), Validators.max(2500)]]
    }),

    // Medical Payments
    medical: fb.group({
      limit: [5000, [Validators.required, Validators.min(1000), Validators.max(100000)]]
    }),

    // Uninsured Motorist
    uninsuredMotorist: fb.group({
      bodilyInjury: [100000, [Validators.required, Validators.min(25000)]],
      propertyDamage: [100000, [Validators.required, Validators.min(15000)]],
      stacked: [false]
    }),

    // Additional Coverages
    additionalCoverages: fb.group({
      rentalReimbursement: [true],
      roadsideAssistance: [true],
      glassDeductibleWaiver: [false],
      gapCoverage: [false],
      accidentForgiveness: [false]
    }),

    // Meta fields
    hasLienholder: [false],
    garageState: ['', Validators.required]
  }, {
    validators: [
      crossFieldCoverageValidator,
      uninsuredMotoristValidator
    ]
  });
}
```

#### GENERATED FormGroup (Simplified)

```typescript
private initializeForm(): void {
  this.coverageForm = this.fb.group({
    coverageType: ['', Validators.required],
    coverageLimit: [null, [
      Validators.required,
      minCoverageLimitValidator(10000),
      maxCoverageLimitValidator(5000000),
      coverageLimitStepValidator(5000)
    ]],
    deductible: [null, Validators.required],
    additionalCoverages: this.fb.array([])
  }, {
    validators: [deductibleLimitRatioValidator()]
  });
}
```

### Structure Comparison

| Expected | Generated | Gap |
|----------|-----------|-----|
| `liability.bodilyInjuryPerPerson` | Missing | Need nested group |
| `liability.bodilyInjuryPerAccident` | Missing | Need nested group |
| `liability.propertyDamage` | Missing | Need nested group |
| `collision.enabled` | Missing | Need nested group |
| `collision.deductible` | `deductible` (flat) | Need nested group |
| `comprehensive.enabled` | Missing | Need nested group |
| `comprehensive.deductible` | Missing | Need nested group |
| `medical.limit` | Missing | Need nested group |
| `uninsuredMotorist.bodilyInjury` | Missing | Need nested group |
| `uninsuredMotorist.propertyDamage` | Missing | Need nested group |
| `uninsuredMotorist.stacked` | Missing | Need nested group |
| `additionalCoverages.rentalReimbursement` | `additionalCoverages` (FormArray) | Should be FormGroup with booleans |
| `hasLienholder` | Missing | Need for validator |
| `garageState` | Missing | Need for state minimums |

---

## Summary of Required Changes

### Template Changes (coverage-modification.component.html)

1. Replace all `<div>` containers with `<axis-card>`
2. Replace `<select>` elements with `<axis-dropdown>`
3. Replace `<input>` elements with `<axis-input>`
4. Replace `<button>` elements with `<axis-button>`
5. Replace custom spinner with `<axis-spinner>`
6. Replace error divs with `<axis-alert>`
7. Add `<axis-badge>` for status indicators
8. Use `<axis-hint>` for form hints
9. Use `<axis-error>` for validation errors

### Validator Changes (coverage-modification.validators.ts)

1. Add `liabilityLimitsValidator`
2. Add `crossFieldCoverageValidator`
3. Add `uninsuredMotoristValidator`
4. Add `stateMinimumValidator`
5. Export `StateMinimumCoverage` interface
6. Export `STATE_MINIMUMS` configuration

### Component Changes (coverage-modification.component.ts)

1. Import Axis UI modules
2. Update FormGroup to match LLD structure
3. Add missing form controls for all coverage types
4. Wire up all validators to form groups
5. Add state minimums service integration

### Interface Changes (coverage-modification.interfaces.ts)

1. Add `LiabilityCoverage` interface
2. Add `CollisionCoverage` interface
3. Add `ComprehensiveCoverage` interface
4. Add `MedicalCoverage` interface
5. Add `UninsuredMotoristCoverage` interface
6. Add `AdditionalCoverageSelections` interface
7. Add `StateMinimumCoverage` interface

---

## Test Requirements for Validators

```typescript
// coverage-modification.validators.spec.ts

describe('Coverage Modification Validators', () => {

  describe('liabilityLimitsValidator', () => {
    // 5 test cases
  });

  describe('crossFieldCoverageValidator', () => {
    // 4 test cases
  });

  describe('uninsuredMotoristValidator', () => {
    // 4 test cases
  });

  describe('stateMinimumValidator', () => {
    // 6 test cases (multiple states)
  });

  describe('deductibleLimitRatioValidator', () => {
    // Already implemented - verify 4 test cases
  });

  describe('coverageLimitStepValidator', () => {
    // Already implemented - verify 4 test cases
  });

});
```

**Expected test coverage: >80%**

---

## Priority Action Items

| Priority | Action | Effort |
|----------|--------|--------|
| P0 | Replace native HTML with Axis components | 4 hours |
| P0 | Implement liabilityLimitsValidator | 1 hour |
| P0 | Implement crossFieldCoverageValidator | 1 hour |
| P1 | Implement uninsuredMotoristValidator | 1 hour |
| P1 | Implement stateMinimumValidator | 2 hours |
| P1 | Restructure FormGroup to match LLD | 2 hours |
| P2 | Add comprehensive unit tests | 3 hours |
| P2 | Add ARIA specifications | 1 hour |

**Total Estimated Effort: 15 hours**

---

*Detailed feedback generated for axis-tools plugin improvement*
