# Code Generation Validation Checklist

**Purpose**: Mandatory validation steps to execute BEFORE writing any generated code files

**When to Use**: Before every `Write()` operation in code generation agents

---

## Critical Principle

**NEVER write files with validation violations. Always auto-fix violations BEFORE writing.**

---

## Pre-Write Validation (MANDATORY)

Execute ALL checks below before writing files. If ANY violations found, auto-fix them before proceeding.

---

## Check 1: Template Angular Event Handlers (HIGHEST PRIORITY)

### What to Check

Scan ENTIRE template for prohibited Angular event bindings.

### Regex Pattern

```regex
\(click\)=|\(change\)=|\(ngModelChange\)=|\(blur\)=|\(focus\)=|\(input\)=|\(onClose\)=|\(submit\)=|\(onDismiss\)=
```

### Scope

**ALL elements in template** including:
- Buttons
- Form fields
- Alerts
- Modals
- Dialogs
- Cards
- Custom components

### ❌ PROHIBITED Examples

```html
<!-- Button with click handler -->
<button axis-button (click)="saveDraft()">Save</button>

<!-- Alert with close handler -->
<axis-alert (onClose)="errorMessage = null">Error</axis-alert>

<!-- Input with change handler -->
<input (change)="onFieldChange($event)">

<!-- Modal with dismiss handler -->
<axis-modal (onDismiss)="handleDismiss()">
```

### ✅ CORRECT Patterns

```html
<!-- Buttons: Define in aug.json with eventName -->
<!-- aug.json -->
{
  "type": "button",
  "name": "saveButton",
  "eventName": "save"
}

<!-- Template -->
<axis-ui-generator [uiStructure]="..." (uiEmitUpdate)="handleUpdate($event)">

<!-- Component -->
handleUpdate(event: UIEmitUpdateEvent) {
  if (event.eventInfo.eventName === 'save') {
    this.saveDraft();
  }
}

<!-- Alerts: Use property binding only -->
<axis-alert [dismissible]="false">Error</axis-alert>
<!-- OR control with ngIf -->
<axis-alert *ngIf="showError">Error</axis-alert>

<!-- Form fields: Handled by axis-ui-generator -->
<axis-ui-generator [uiStructure]="..." (uiEmitUpdate)="handleUpdate($event)">
```

### Auto-Fix Actions

**If violations found:**

1. **Buttons**: Move to aug.json with `eventName` property
2. **Alerts**: Remove handler, use `[dismissible]="false"` or `*ngIf`
3. **Form fields**: Remove handler (axis-ui-generator handles automatically)
4. **Modals**: Control visibility with component state, no event handlers

---

## Check 2: Undocumented Helper Methods

### What to Check

Search for ALL `augRef._helper.` method calls and verify against whitelist.

### Documented Methods Whitelist

**ONLY these methods are allowed:**

```typescript
// Field manipulation
augRef._helper.setData(controlName, data, AUGinstance?, formName?, setValueOptions?)

// Element management
augRef._helper.addElement(config: AddElementConfig)
augRef._helper.deleteElement(AUG, AUGinstanceName, controlName, deleteChildren?, clearUiStructure?)
augRef._helper.refreshElement(config?: RefreshElementConfig)
augRef._helper.recreateElement(config: RecreateElementConfig)

// Conditional logic
augRef._helper.updateFieldsConditionally(config)
augRef._helper.checkAllInteractions(AUG, controlName)

// Cleanup
formService.clearFormData(AUGinstanceName, formName)
```

### ❌ PROHIBITED Methods

```typescript
// These methods are NOT documented and will cause errors
augRef._helper.setFieldValue()        // Use setData() instead
augRef._helper.setFieldOptions()      // Update uiStructure + call refreshElement()
augRef._helper.setFieldError()        // Not documented
augRef._helper.clearFieldError()      // Not documented
augRef._helper.updateFieldData()      // Use setData() instead
augRef._helper.setFieldProperty()     // Update uiStructure + call refreshElement()
```

### Auto-Fix Mappings

```typescript
// setFieldValue → setData
❌ augRef._helper.setFieldValue('city', cityData.city);
✅ augRef._helper.setData('city', cityData.city, 'myInstance');

// setFieldOptions → Update structure + refresh
❌ augRef._helper.setFieldOptions('subSic', options);
✅ const field = this.uiStructure.sections.main.fields.find(f => f.name === 'subSic');
   field.options = options;
   augRef._helper.refreshElement({ elementName: 'subSic', AUGinstance: 'myInstance' });

// updateFieldData → setData
❌ augRef._helper.updateFieldData('email', newEmail);
✅ augRef._helper.setData('email', newEmail, 'myInstance');
```

---

## Check 3: Type Safety

### No 'any' Types for AUG Properties

```typescript
// ❌ PROHIBITED
private augRef: any;
uiStructure: any;
clientInfoEmitUpdate(event: any): void { }

// ✅ REQUIRED
import { AUGHelper, UIStructure, UIEmitUpdateEvent } from 'axis-ui-generator-types';

private augRef: { _helper: AUGHelper } | null = null;
uiStructure: UIStructure | null = null;
clientInfoEmitUpdate(event: UIEmitUpdateEvent): void { }
```

### No Local Type Redefinitions

```typescript
// ❌ PROHIBITED - Don't redefine UIStructure locally
export interface UIStructure {
  sections: { [key: string]: UISection };
}

// ✅ REQUIRED - Import from package
import { UIStructure } from 'axis-ui-generator-types';
```

### Verify All Imports

```typescript
// Check that imports are present
import {
  UIStructure,
  UIControl,
  UIEmitEvent,
  UIEmitUpdateEvent,
  AUGHelper
} from 'axis-ui-generator-types';
```

---

## Check 4: Cleanup Parameters

### What to Check

Verify `ngOnDestroy` exists and `clearFormData` has correct parameters.

### ❌ PROHIBITED

```typescript
ngOnDestroy(): void {
  // Missing cleanup
}

ngOnDestroy(): void {
  this.formService.clearFormData();  // Missing parameters
}

ngOnDestroy(): void {
  this.formService.clearFormData('myInstance');  // Missing second parameter
}
```

### ✅ REQUIRED

```typescript
ngOnDestroy(): void {
  // MANDATORY: 2 parameters (instanceName, formName)
  this.formService.clearFormData('clientInformationInstance', null);
}

// If multiple forms
ngOnDestroy(): void {
  this.formService.clearFormData('myInstance', 'form1');
  this.formService.clearFormData('myInstance', 'form2');
}
```

---

## Check 5: Direct Data Manipulation

### What to Check

Search for direct assignment to `ui{Feature}Data` arrays.

### Pattern to Find

```regex
this\.ui\w+Data\[
```

### ❌ PROHIBITED

```typescript
// Direct assignment
this.uiClientData[fieldName] = value;
this.uiClientData['email'] = 'test@example.com';

// Array manipulation
this.fields.push(newField);
this.fields.splice(index, 1);
delete this.fields[0];
```

### ✅ REQUIRED

```typescript
// Use helper methods
this.augRef._helper.setData(fieldName, value, 'myInstance');
this.augRef._helper.addElement({
  AUG: this.augRef,
  AUGinstance: 'myInstance',
  element: newField
});
this.augRef._helper.deleteElement(
  this.augRef,
  'myInstance',
  'fieldName'
);
```

---

## Check 6: augRef Capture Pattern

### What to Check

Verify augRef is properly captured with correct types.

### ✅ REQUIRED Pattern

```typescript
// Component property
import { AUGHelper } from 'axis-ui-generator-types';
private augRef: { _helper: AUGHelper } | null = null;

// Capture method
onAugRef(ref: { _helper: AUGHelper }): void {
  this.augRef = ref;
  console.log('augRef captured:', this.augRef);
}

// Template
<axis-ui-generator
  [uiStructure]="uiStructure"
  [uiData]="uiData"
  (augRef)="onAugRef($event)"
  (uiEmitUpdate)="handleUpdate($event)">
</axis-ui-generator>
```

---

## Check 7: Button Action Routing

### What to Check

Verify ALL buttons are defined in aug.json with `eventName` property.

### ✅ REQUIRED Pattern

**aug.json**:
```json
{
  "sections": {
    "actions": {
      "fields": [
        {
          "type": "button",
          "name": "saveButton",
          "label": "Save",
          "eventName": "save",
          "class": "kind-primary"
        },
        {
          "type": "button",
          "name": "cancelButton",
          "label": "Cancel",
          "eventName": "cancel",
          "class": "kind-secondary"
        }
      ]
    }
  }
}
```

**Component**:
```typescript
handleUpdate(event: UIEmitUpdateEvent): void {
  const { fieldName, newValue, eventName } = event.eventInfo;

  // Handle button clicks via eventName
  if (eventName) {
    this.handleButtonAction(eventName);
    return;
  }

  // Handle field changes
  // ...
}

private handleButtonAction(eventName: string): void {
  switch (eventName) {
    case 'save':
      this.saveDraft();
      break;
    case 'cancel':
      this.cancelForm();
      break;
    default:
      console.warn('Unhandled button action:', eventName);
  }
}
```

---

## Check 8: Accessibility Attributes — data-testid + aria-label Pairing

### What to Check

Every interactive element in every generated template must have **both** a `data-testid` attribute
and an accessibility attribute (`ariaLabel` / `aria-label` / `role` as appropriate).
These two must always appear together — one without the other is a violation.

### Interactive Elements Scope

**ALL of the following must carry data-testid AND aria-label/role:**
- `<axis-button>` and `<button>`
- `<axis-dropdown>`
- `<axis-input>`, `<axis-textbox>`
- `<axis-checkbox>`
- `<axis-radio>`, `<axis-radio-group>`
- `<axis-datepicker>`, `<axis-date-range-picker>`
- `<axis-search-address>`
- `<axis-tab>`, `<axis-tab-set>`
- `<axis-modal>` (role + aria-labelledby)
- `<axis-data-grid>` (aria-label + aria-rowcount)
- `<axis-slider>`
- `<axis-duallist>`
- `<form>` elements (role="form" + aria-label)

### Regex Pattern — Missing data-testid

```regex
<(axis-button|axis-dropdown|axis-input|axis-textbox|axis-checkbox|axis-radio|axis-datepicker|axis-date-range-picker|axis-search-address|axis-tab|axis-modal|axis-data-grid|axis-slider|axis-duallist|button)[^>]*>
```
For every match: confirm `data-testid=` is present in the same element's attributes.

### ❌ PROHIBITED Examples

```html
<!-- Button: missing data-testid and ariaLabel -->
<axis-button kind="primary" (click)="save()">Save</axis-button>

<!-- Dropdown: has data-testid but missing ariaLabel -->
<axis-dropdown data-testid="country-dropdown" [dataProvider]="countries">

<!-- Checkbox: has ariaLabel but missing data-testid -->
<axis-checkbox [ariaLabel]="'Accept terms'" [(ngModel)]="agreed">Accept</axis-checkbox>

<!-- Input: missing both -->
<axis-input [(ngModel)]="username" name="username"></axis-input>
```

### ✅ CORRECT Patterns

```html
<!-- axis-button: data-testid paired with ariaLabel -->
<axis-button
  kind="primary"
  data-testid="save-application-btn"
  [ariaLabel]="'Save application'">
  Save
</axis-button>

<!-- axis-dropdown: both attributes present -->
<axis-dropdown
  data-testid="country-select"
  [ariaLabel]="'Select country'"
  [dataProvider]="countries"
  [(ngModel)]="selectedCountry">
</axis-dropdown>

<!-- axis-checkbox: paired -->
<axis-checkbox
  data-testid="terms-checkbox"
  [ariaLabel]="'Accept terms and conditions'"
  [(ngModel)]="agreed"
  name="terms">
  Accept terms
</axis-checkbox>

<!-- axis-input: paired -->
<axis-input
  data-testid="username-input"
  aria-label="Enter your username"
  [(ngModel)]="username"
  name="username">
</axis-input>

<!-- form: role + aria-label on the container -->
<form
  data-testid="login-form"
  role="form"
  aria-label="User login form">
```

### Auto-Fix Actions

For every interactive element missing `data-testid`:
1. Derive a descriptive kebab-case value from the element's `name`, `label`, or surrounding context: `<feature>-<type>` (e.g. `country-select`, `save-btn`, `terms-checkbox`)
2. Insert `data-testid="<derived-value>"` as the second attribute (after `kind`/`class` if present)

For every interactive element missing `ariaLabel` / `aria-label`:
1. For Axis components: add `[ariaLabel]="'<human-readable label>'"` — derive from the field's visible label text
2. For native elements: add `aria-label="<human-readable label>"`
3. For `<form>` containers: add `role="form"` + `aria-label="<form purpose>"`
4. For `<axis-modal>`: add `aria-labelledby="<modal-title-id>"` and a matching `id` on the modal heading

---

## Validation Execution Flow

```typescript
function validateBeforeWrite(generatedCode: GeneratedFiles): ValidationResult {
  const violations: Violation[] = [];

  // 1. Check templates for event handlers
  for (const templateFile of generatedCode.templates) {
    const eventHandlers = scanForEventHandlers(templateFile);
    if (eventHandlers.length > 0) {
      violations.push({
        type: 'PROHIBITED_EVENT_HANDLER',
        file: templateFile.path,
        lines: eventHandlers,
        autoFix: () => moveButtonsToAugJson(eventHandlers)
      });
    }
  }

  // 2. Check TypeScript for undocumented methods
  for (const tsFile of generatedCode.typescript) {
    const undocumentedMethods = scanForUndocumentedMethods(tsFile);
    if (undocumentedMethods.length > 0) {
      violations.push({
        type: 'UNDOCUMENTED_METHOD',
        file: tsFile.path,
        methods: undocumentedMethods,
        autoFix: () => replaceWithDocumentedMethods(undocumentedMethods)
      });
    }
  }

  // 3. Check type safety
  for (const tsFile of generatedCode.typescript) {
    const anyTypes = scanForAnyTypes(tsFile);
    if (anyTypes.length > 0) {
      violations.push({
        type: 'ANY_TYPE',
        file: tsFile.path,
        locations: anyTypes,
        autoFix: () => replaceWithProperTypes(anyTypes)
      });
    }
  }

  // 4. Check cleanup
  for (const componentFile of generatedCode.components) {
    const cleanupIssues = checkCleanup(componentFile);
    if (cleanupIssues.length > 0) {
      violations.push({
        type: 'CLEANUP_ISSUE',
        file: componentFile.path,
        issues: cleanupIssues,
        autoFix: () => addProperCleanup(cleanupIssues)
      });
    }
  }

  // 5. Check direct data manipulation
  for (const tsFile of generatedCode.typescript) {
    const directManipulation = scanForDirectDataManipulation(tsFile);
    if (directManipulation.length > 0) {
      violations.push({
        type: 'DIRECT_DATA_MANIPULATION',
        file: tsFile.path,
        locations: directManipulation,
        autoFix: () => useHelperMethods(directManipulation)
      });
    }
  }

  return {
    passed: violations.length === 0,
    violations: violations
  };
}

// Main validation flow
function generateAndWrite(requirements: Requirements): void {
  // Generate code in memory
  const generatedCode = generateCode(requirements);

  // MANDATORY: Validate before writing
  let validationResult = validateBeforeWrite(generatedCode);

  // Auto-fix violations
  while (!validationResult.passed) {
    console.log(`Found ${validationResult.violations.length} violations. Auto-fixing...`);

    for (const violation of validationResult.violations) {
      violation.autoFix();
    }

    // Re-validate after fixes
    validationResult = validateBeforeWrite(generatedCode);
  }

  // ONLY write after all validations pass
  writeFiles(generatedCode);

  console.log('✅ All validations passed. Files written successfully.');
}
```

---

## Summary Checklist

Before writing files, verify:

- [ ] **Templates**: Zero Angular event handlers (click, change, etc.)
- [ ] **Helper Methods**: Only documented methods used (setData, addElement, etc.)
- [ ] **Type Safety**: No `any` types, all imports from axis-ui-generator-types
- [ ] **Cleanup**: ngOnDestroy with clearFormData(instance, form)
- [ ] **Data Manipulation**: No direct array/object assignments
- [ ] **augRef Capture**: Properly typed and captured
- [ ] **Button Actions**: All defined in aug.json with eventName
- [ ] **Accessibility**: Every interactive element has `data-testid` AND `ariaLabel`/`aria-label`/`role` — both must be present together

**If ANY violations found**: Auto-fix before writing files.

**Zero tolerance**: NEVER write files with violations.

---

## Auto-Fix Priority

1. **Event handlers** (CRITICAL - causes immediate bugs)
2. **Undocumented methods** (HIGH - causes runtime errors)
3. **Type safety** (HIGH - prevents IntelliSense and compile checks)
4. **Accessibility pairing** (HIGH - missing data-testid breaks E2E tests; missing aria-label fails WCAG 2.1 AA)
5. **Cleanup** (MEDIUM - causes memory leaks)
6. **Direct manipulation** (MEDIUM - breaks AUG state management)

---

## Further Reading

- **TYPE-SAFETY-REFERENCE.md**: Complete type safety rules
- **AXIS-UI-GENERATOR-GUIDE.md**: Usage patterns and examples
- **HELPER-METHODS-REFERENCE.md**: Complete documented methods list

---

**Last Updated**: 2026-02-02
**Version**: 1.0.0
