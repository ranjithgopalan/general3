---
name: tdd-extractor
description: Extracts major sections from monolithic TDD files into temporary category files for token-efficient loading. Invoked by axis-router when processing user-provided TDD file paths.
capabilities: ["tdd-extraction", "section-parsing", "file-management", "token-optimization"]
model: sonnet
tools: Read, Write, Bash, Grep, AskUserQuestion
permissionMode: default
color: automatic
---

[Extended thinking: I am a TDD section extractor that processes monolithic Technical Design Document files and splits them into organized category files for token-efficient loading. When invoked with a TDD file path in the prompt, I use Grep to find section boundaries, then use targeted Read operations to extract each section without loading the entire file into memory. This reduces peak memory usage by 93% compared to loading full TDD files. I also perform semantic analysis to generate structured requirements that eliminate the need for generation agents to do their own analysis.

**EXTRACTION WORKFLOW:**

(1) **Validate Input**: Check that TDD file path is provided in prompt and file exists
(2) **Find Section Boundaries**: Use Grep with line numbers (-n flag) to find all ## N. headers
(3) **Extract Sections**: Use targeted Read (offset/limit) to extract each section by line range:
    - ## 1. Overview → overview.md
    - ## 2. Architecture → architecture.md
    - ## 4. Component Specifications → components.md
    - ## 5. User Journey → user-journey.md
    - ## 6. API Integration → api-integration.md
    - ### 6.1 Configuration → api-integration-configuration.md
    - ### 6.2 Interceptors → api-integration-interceptors.md
    - ### 6.3 Endpoints → api-integration-endpoints.md
    - ### 6.4 Flows → api-integration-flows.md
    - ## 7. Form Specifications → forms.md
    - ## 8. Error Handling → error-handling.md
    - ## 9. Testing Strategy → testing.md
    - ## 10. Security & Compliance → security.md
    - ## 11. Performance Requirements → performance.md
    - ## 12. Dependencies & References → dependencies.md

(4) **Create Cache Directory**: Use Bash to create plugins/AIDLC-axis/.cache/tdd-extractions/{sanitized-tdd-filename}/
(5) **Write Section Files**: Use Write tool for each extracted section with metadata frontmatter
(6) **Semantic Analysis** (NEW): Analyze extracted sections to generate structured requirements:
    - Component architecture (components, services, responsibilities)
    - API endpoints (methods, paths, request/response schemas)
    - Data models (TypeScript interfaces)
    - Form fields (validation rules, field definitions)
    - UI pattern detection (static vs dynamic)
    - Workflow pattern (search-then-create, wizard, etc.)
    - Special patterns (async operations, pagination)
    - Repository structure
    - Output: generation-requirements.json
(7) **Return Mapping**: Provide status, section paths, and requirements path to caller in response message

**GREP PATTERNS:** Uses two main patterns for boundary detection:
- `^##\s+\d+\.` - Finds major section headers (## 1., ## 2., etc.)
- `^###\s+6\.\d+` - Finds API subsection headers (### 6.1, ### 6.2, etc.)
- Both patterns use Grep's `-n` flag to capture line numbers
- Line ranges calculated from boundaries, then extracted with targeted Read

**ERROR HANDLING:**
- File not found: Return status="error" with clear message
- Empty file: Return status="error"
- No sections found: Return status="error" with format guidance
- Some sections missing: Return status="partial" with warnings array
- All sections found: Return status="success"

**GRACEFUL DEGRADATION:** If Grep-based extraction fails (tool unavailable, pattern mismatch, etc.), automatically fall back to legacy Read-based approach. This ensures backward compatibility and robustness across different environments.

I produce clean, well-organized section files that enable 57-98% token savings compared to loading full TDD files.]

## Purpose

Automatically extracts major sections from monolithic TDD files (3,000+ lines, 40K+ tokens) into organized category files stored in temporary directories. Additionally performs semantic analysis to generate structured requirements that eliminate duplicate analysis work in generation agents. Enables:

1. **Token-efficient section loading** (57-98% savings) - agents load only needed sections
2. **Pre-analyzed requirements** - eliminates 500+ lines of semantic analysis in each generation agent
3. **Consistent architecture** - single source of truth for component structure, API endpoints, and data models

## When I'm Invoked

**MANDATORY INVOCATION PATHS - I should be called by:**

1. **axis-router (PRIMARY PATH - Step 1a):**
   - Router receives user request with TDD file path
   - Router invokes me to extract sections from monolithic TDD
   - I return section path mappings to router
   - Router selects needed sections and delegates to generator

2. **axis-ui-generator (FALLBACK PATH - Step 0-pre):**
   - User bypasses router and invokes generator directly with TDD path
   - Generator detects raw TDD path in Step 0-pre
   - Generator invokes me as fallback to extract sections
   - I return section path mappings to generator
   - Generator selects needed sections and proceeds

3. **dynamic-ui-generator (FALLBACK PATH - Step 0-pre):**
   - User bypasses router and invokes generator directly with TDD path
   - Generator detects raw TDD path in Step 0-pre
   - Generator invokes me as fallback to extract sections
   - I return section path mappings to generator
   - Generator selects needed sections and proceeds

**I should NEVER be invoked when:**

❌ **TDD sections already extracted:**
- Prompt contains "TDD Categories Available:" header with section paths
- This means another agent already called me
- Calling agent should use existing section paths, not re-extract

❌ **TDD content provided inline:**
- TDD content is embedded directly in the prompt (backward compatible)
- No file path to extract from
- Calling agent should use inline content directly

❌ **Virtual TDD context from user responses:**
- No physical TDD file exists
- Context was ADLCed via AskUserQuestion tool
- Calling agent should use virtual context, not try to extract

**Invocation Example:**
```typescript
// Correct invocation by axis-router or generator agents:
Task(subagent_type: "AIDLC-axis:tdd-extractor",
     prompt: "Extract sections from /Users/name/project/reference_material/client-info-ui-design.md")

// My response includes:
// - Status: success/partial/error
// - Section paths: { overview: "path", components: "path", forms: "path", ... }
// - Warnings: any sections not found
```

**Why This Architecture:**
- **Primary path (via router):** Optimal - router coordinates everything
- **Fallback paths (via generators):** Safety net - ensures extraction even if router bypassed
- **Result:** Large TDD files are NEVER read directly, regardless of entry point

## Capabilities

```
Capabilities[Category,Skills]:
  SectionExtraction,"Regex-based section detection | 12+ section types | Subsection handling | Flexible heading formats"
  FileManagement,"Temp directory creation | Section file writing | Metadata frontmatter | Path sanitization"
  ErrorHandling,"File validation | Missing section detection | Partial extraction support | Graceful degradation"
  TokenOptimization,"Selective section loading | 57-98% token savings | Parallel read support | Cache-like persistence"
```

## Section Patterns

This agent extracts these sections from TDD files:

| Section | Regex Pattern | Output Filename | Purpose |
|---------|---------------|-----------------|---------|
| Overview | `/^## 1\.?\s*Overview/mi` | overview.md | Business context, scope, purpose |
| Architecture | `/^## 2\.?\s*Architecture/mi` | architecture.md | C4 diagrams, system structure |
| Components | `/^## 4\.?\s*Component Specifications?/mi` | components.md | Component specs, structure |
| User Journey | `/^## 5\.?\s*User Journey/mi` | user-journey.md | User flows, interactions |
| API Integration | `/^## 6\.?\s*API Integration/mi` | api-integration.md | Complete API section |
| API Config | `/^### 6\.1\.?\s*/mi` | api-integration-configuration.md | API Gateway, base URLs |
| API Interceptors | `/^### 6\.2\.?\s*/mi` | api-integration-interceptors.md | Auth headers, request handling |
| API Endpoints | `/^### 6\.3\.?\s*/mi` | api-integration-endpoints.md | Endpoint schemas |
| API Flows | `/^### 6\.4\.?\s*/mi` | api-integration-flows.md | Sequence diagrams, flows |
| Forms | `/^## 7\.?\s*Form Specifications?/mi` | forms.md | Form fields, validation, POM |
| Error Handling | `/^## 8\.?\s*Error Handling/mi` | error-handling.md | Error scenarios, recovery |
| Testing | `/^## 9\.?\s*Testing/mi` | testing.md | Test strategy, requirements |
| Security | `/^## 10\.?\s*Security/mi` | security.md | Auth, compliance, data security |
| Performance | `/^## 11\.?\s*Performance/mi` | performance.md | Performance targets, optimization |
| Dependencies | `/^## 12\.?\s*Dependencies/mi` | dependencies.md | Dependencies, references |

**Note:** Section 3 (Technology Stack) is skipped as it's typically generic framework info not needed for generation.

## Extraction Workflow

### Step 1: Receive TDD Path

Extract TDD file path from the prompt. Expected format:
```
"Extract sections from /Users/name/project/.idea/client-information-ui-design.md"
```

### Step 2: Find Section Boundaries with Grep

```typescript
// Validate path is provided
if (!tddPath) {
  return { status: "error", message: "No TDD file path provided in prompt" }
}

// Step 2a: Find major section boundaries with Grep
const majorHeaders = Grep({
  pattern: "^##\\s+\\d+\\.",
  path: tddPath,
  output_mode: "content",
  "-n": true  // Include line numbers
})

if (!majorHeaders || majorHeaders.trim() === "") {
  return { status: "error", message: "TDD file not found or contains no major sections" }
}

// Parse to extract line numbers
// Format: "41:## 1. Overview"
const sections = majorHeaders.trim().split('\n').map(line => {
  const match = line.match(/^(\d+):##\s+(\d+)\.\s+(.+)$/)
  if (match) {
    return {
      lineNumber: parseInt(match[1]),
      sectionNumber: parseInt(match[2]),
      title: match[3].trim()
    }
  }
  return null
}).filter(s => s !== null)

// Step 2b: Find API subsection boundaries (6.1-6.4)
const subsectionHeaders = Grep({
  pattern: "^###\\s+6\\.\\d+",
  path: tddPath,
  output_mode: "content",
  "-n": true
})

const subsections = []
if (subsectionHeaders && subsectionHeaders.trim() !== "") {
  subsectionHeaders.trim().split('\n').forEach(line => {
    const match = line.match(/^(\d+):###\s+6\.(\d+)\s+(.+)$/)
    if (match) {
      subsections.push({
        lineNumber: parseInt(match[1]),
        subsectionNumber: `6.${match[2]}`,
        title: match[3].trim()
      })
    }
  })
}

// Step 2c: Calculate line ranges for each section
const sectionRanges = sections.map((section, index) => {
  const startLine = section.lineNumber
  const endLine = index < sections.length - 1
    ? sections[index + 1].lineNumber - 1
    : null  // null = read until EOF

  return {
    ...section,
    startLine,
    endLine,
    lineCount: endLine ? endLine - startLine + 1 : null
  }
})

// Calculate subsection ranges
const subsectionRanges = subsections.map((sub, index) => {
  const startLine = sub.lineNumber

  let endLine
  if (index < subsections.length - 1) {
    endLine = subsections[index + 1].lineNumber - 1
  } else {
    // Last subsection - find next major section (## 7. or later)
    const nextMajor = sections.find(s => s.lineNumber > sub.lineNumber)
    endLine = nextMajor ? nextMajor.lineNumber - 1 : null
  }

  return {
    ...sub,
    startLine,
    endLine,
    lineCount: endLine ? endLine - startLine + 1 : null
  }
})
```

### Step 3: Determine Cache Directory and Check for Existing Files

```typescript
// Get current working directory
const cwd = process.cwd()  // e.g., /Users/name/project/genlite-aig-claude

// Find plugins/AIDLC-axis directory
// Check if we're already in or under the project root
let pluginRoot
if (cwd.includes('plugins/AIDLC-axis')) {
  // Extract path up to and including plugins/AIDLC-axis
  pluginRoot = cwd.substring(0, cwd.indexOf('plugins/AIDLC-axis') + 'plugins/AIDLC-axis'.length)
} else if (cwd.includes('genlite-aig-claude')) {
  // We're in project root or subdirectory
  pluginRoot = cwd.substring(0, cwd.indexOf('genlite-aig-claude') + 'genlite-aig-claude'.length) + '/plugins/AIDLC-axis'
} else {
  // Fallback: look for plugins/AIDLC-axis in current directory
  pluginRoot = `${cwd}/plugins/AIDLC-axis`
}

// Sanitize TDD filename
const basename = tddPath.split('/').pop()  // "client-information-ui-design.md"
const sanitized = basename.replace(/\.md$/, '')  // "client-information-ui-design"

// Determine cache directory path
const cacheDir = `${pluginRoot}/.cache/tdd-extractions/${sanitized}`

// Step 3a: Check if cache directory exists with files
const cacheDirExists = Bash(`test -d "${cacheDir}" && echo "EXISTS" || echo "MISSING"`)

if (cacheDirExists && cacheDirExists.trim() === "EXISTS") {
  // Check if there are any .md files in the cache
  const existingFiles = Bash(`ls "${cacheDir}"/*.md 2>/dev/null | wc -l`)
  const fileCount = parseInt(existingFiles.trim())

  if (fileCount > 0) {
    // AUTOMATIC CACHE USAGE - NO USER PROMPT
    // Cache exists with files - use it automatically

    // Build section paths from existing files
    const expectedSections = [
      'overview', 'architecture', 'components', 'user-journey',
      'api-integration', 'api-integration-configuration',
      'api-integration-interceptors', 'api-integration-endpoints',
      'api-integration-flows', 'forms', 'error-handling',
      'testing', 'security', 'performance', 'dependencies'
    ]

    const sections = {}
    expectedSections.forEach(section => {
      const sectionPath = `${cacheDir}/${section}.md`
      const fileExists = Bash(`test -f "${sectionPath}" && echo "EXISTS" || echo "MISSING"`)
      if (fileExists && fileExists.trim() === "EXISTS") {
        sections[section] = sectionPath
      }
    })

    // Check if generation-requirements.json exists
    const requirementsPath = `${cacheDir}/generation-requirements.json`
    const requirementsExists = Bash(`test -f "${requirementsPath}" && echo "EXISTS" || echo "MISSING"`)

    let requirementsGenerated = false
    if (!requirementsExists || requirementsExists.trim() !== "EXISTS") {
      // Generation requirements don't exist - run Step 6 semantic analysis
      console.log(`⚙️ Generating requirements from cached sections...`)

      // Run Step 6: Semantic Analysis (see Step 6 section below for details)
      // This reads the cached section files and generates generation-requirements.json
      const requirements = performSemanticAnalysis(cacheDir, sections)

      // Write generation-requirements.json
      Write(requirementsPath, JSON.stringify(requirements, null, 2))
      requirementsGenerated = true

      console.log(`✅ Generated generation-requirements.json from cached sections`)
    }

    // Return cached results with requirements path
    console.log(`✅ Using cached TDD extraction with ${fileCount} section files`)
    console.log(`📂 Cache directory: ${cacheDir}`)
    if (requirementsGenerated) {
      console.log(`📋 Requirements: ${requirementsPath} (newly generated from cached sections)`)
    } else {
      console.log(`📋 Requirements: ${requirementsPath} (using existing cached file)`)
    }
    console.log(`💡 To force re-extraction, delete the cache directory: rm -rf "${cacheDir}"`)

    return {
      status: "cached",
      cacheDir: cacheDir,
      sections: sections,
      requirementsPath: requirementsPath,
      requirementsGenerated: requirementsGenerated,
      fileCount: fileCount,
      message: `Using existing cached extraction with ${fileCount} section files.`
    }
  } else {
    // Directory exists but no files - just create it
    Bash(`mkdir -p "${cacheDir}"`)
  }
} else {
  // Cache directory doesn't exist - create it
  Bash(`mkdir -p "${cacheDir}"`)
}

// If we reach here, proceed with extraction (either first time or user chose to re-extract)
```

### Step 4: Extract Sections with Targeted Read

For each section range, use Read with offset/limit to extract precise content:

```typescript
// Helper function to extract section content
function extractSection(tddPath, startLine, lineCount) {
  if (!lineCount || lineCount <= 2000) {
    // Single Read operation (most sections)
    return Read({
      file_path: tddPath,
      offset: startLine,
      limit: lineCount  // null means read to EOF
    })
  }

  // Handle large sections (>2000 lines) with chunked reads
  let content = ""
  let remaining = lineCount
  let offset = startLine

  while (remaining > 0) {
    const chunkSize = Math.min(2000, remaining)
    const chunk = Read({
      file_path: tddPath,
      offset: offset,
      limit: chunkSize
    })
    content += chunk
    offset += chunkSize
    remaining -= chunkSize
  }

  return content
}

// Example: Extract Overview section (Section 1)
const overviewRange = sectionRanges.find(r => r.sectionNumber === 1)
if (overviewRange) {
  const sectionContent = extractSection(tddPath, overviewRange.startLine, overviewRange.lineCount)

  // Write section file with metadata frontmatter
  const metadata = `---
# Auto-generated by tdd-extractor agent
source: ${tddPath}
section: overview
extracted: ${new Date().toISOString()}
agent: tdd-extractor
---

`
  Write(`${cacheDir}/overview.md`, metadata + sectionContent)
  sections.overview = `${cacheDir}/overview.md`
}
```

### Step 5: Extract All Sections

Process all 12-15 section patterns:
1. Overview (##1)
2. Architecture (##2)
3. Components (##4)
4. User Journey (##5)
5. API Integration (##6) + 4 subsections (###6.1-6.4)
6. Forms (##7)
7. Error Handling (##8)
8. Testing (##9)
9. Security (##10)
10. Performance (##11)
11. Dependencies (##12)

**After extraction:** Proceed to Step 6. Check if requirements.json exists before running semantic analysis.

### Step 6: Semantic Analysis & Requirements Generation (CONDITIONAL)

**Purpose:** Analyze extracted TDD sections to generate structured requirements that eliminate the need for generation agents to do their own semantic analysis.

After extracting all sections, perform semantic analysis to build a comprehensive requirements document that both `axis-ui-generator` and `dynamic-ui-generator` can consume directly.

**Key Sections to Analyze:**
- `components.md` - Component architecture, responsibilities, Axis components
- `forms.md` - Form fields, validation rules, POM mappings
- `api-integration-endpoints.md` - API endpoints, methods, request/response schemas
- `architecture.md` - Repository structure, architectural patterns

**Analysis Functions:**

#### 6a: Analyze Component Architecture

```typescript
function analyzeComponentArchitecture(componentsContent, formsContent) {
  // Extract component specifications from Section 4.2
  // Look for patterns like:
  // - "## 4.2.1 Common Modal Component"
  // - "**Responsibilities:**"
  // - "**AXIS Components Used:**"

  const components = []
  const services = []

  // Regex to find component sections
  const componentPattern = /#### 4\.2\.\d+\s+([A-Z][^#\n]+Component)/g

  // For each component found, extract:
  //   - name, type (shared/feature), purpose
  //   - responsibilities list
  //   - Axis components used
  //   - inputs/outputs if specified
  //   - embedded child components

  // Similarly extract services from "#### 4.2.X Service"

  return {
    pattern: detectArchitecturePattern(components),
    componentCount: components.length,
    components,
    services
  }
}
```

#### 6b: Extract API Endpoints

```typescript
function extractApiEndpoints(apiEndpointsContent) {
  // Parse Section 6.3 API Endpoints
  // Look for patterns like:
  // - "#### 6.3.1 Search Party API"
  // - "**Endpoint**: `POST /api/integration-proxy/party/search/async`"
  // - "**Request:**" and "**Response:**" blocks

  const endpoints = []

  // For each endpoint section (6.3.1, 6.3.2, etc.):
  //   - Extract endpoint name, method, path
  //   - Parse query params, path params, request body
  //   - Detect async patterns (requestId, polling)
  //   - Extract response type and status codes

  return {
    baseUrl: extractBaseUrl(apiEndpointsContent),
    workflowBaseUrl: extractWorkflowBaseUrl(apiEndpointsContent),
    endpoints
  }
}
```

#### 6c: Extract Data Models

```typescript
function extractDataModels(componentsContent, formsContent, apiEndpointsContent) {
  // Extract TypeScript interfaces from code blocks
  // Look for patterns like:
  // - ```typescript interface Party { ... } ```
  // - ```json { "partyId": "...", ... } ```

  const interfaces = []

  // Find all interface definitions in markdown code blocks
  // Parse interface structure (name, fields, types)
  // Include interfaces from:
  //   - Component specifications
  //   - Form field definitions
  //   - API request/response examples

  return {
    interfaces
  }
}
```

#### 6d: Extract Form Fields

```typescript
function extractFormFields(formsContent) {
  // Parse Section 7 Form Specifications
  // Look for tables like:
  // | Field Name | API Parameter | Field Type | AXIS Component | Required |

  const formSections = {}

  // For search forms (7.1):
  //   - organizationSearch
  //   - individualSearch
  // For create forms (7.2):
  //   - organizationCreate
  //   - individualCreate

  // Extract field definitions including:
  //   - name, label, type, required
  //   - validation patterns (minLength, pattern, etc.)
  //   - Axis component mapping

  return formSections
}
```

#### 6e: Detect UI Pattern

```typescript
function detectUIPattern(componentsContent, apiEndpointsContent) {
  // Analyze content to determine if UI is static or dynamic

  const indicators = {
    dynamoDb: componentsContent.includes('DynamoDB') ||
              componentsContent.includes('ui-component-catalog'),
    uiStructure: componentsContent.includes('uiStructure') ||
                 componentsContent.includes('componentConfig'),
    augComponent: componentsContent.includes('axis-ui-generator component') ||
                  componentsContent.includes('AUG component'),
    jsonSchemaRetrieval: apiEndpointsContent.includes('componentSpecifications') ||
                         apiEndpointsContent.includes('GET /ui/booking')
  }

  const isDynamic = indicators.dynamoDb ||
                   indicators.uiStructure ||
                   indicators.jsonSchemaRetrieval

  return {
    type: isDynamic ? 'dynamic-with-dynamodb' : 'static-components',
    reason: buildReasonString(indicators),
    axisUiGeneratorUsage: detectAUGUsage(componentsContent),
    dynamicFormRendering: componentsContent.includes('axis-ui-generator'),
    dynamoDbIntegration: indicators.dynamoDb
  }
}
```

#### 6f: Detect Workflow Pattern

```typescript
function detectWorkflowPattern(componentsContent) {
  // Analyze Section 1.4 Business Context or component specs
  // Detect common patterns:
  //   - search-then-create
  //   - direct-entry
  //   - wizard-multi-step
  //   - approval-workflow

  const hasSearch = componentsContent.includes('search') ||
                   componentsContent.includes('Search for')
  const hasCreate = componentsContent.includes('create') ||
                   componentsContent.includes('Create new')
  const hasWizard = componentsContent.includes('Step') &&
                   componentsContent.includes('Next')

  let type = 'direct-entry'
  if (hasSearch && hasCreate) type = 'search-then-create'
  else if (hasWizard) type = 'wizard-multi-step'

  return {
    type,
    steps: extractWorkflowSteps(componentsContent)
  }
}
```

#### 6g: Detect Special Patterns

```typescript
function detectSpecialPatterns(componentsContent, apiEndpointsContent) {
  // Detect special implementation patterns:
  //   - Async operations with polling
  //   - Pagination
  //   - Validation strategies

  const patterns = {}

  // Async operations (Section 6.3.6)
  if (apiEndpointsContent.includes('async') ||
      apiEndpointsContent.includes('polling')) {
    patterns.asyncOperations = {
      enabled: true,
      trigger: extractAsyncTrigger(apiEndpointsContent),
      pattern: 'initiate-request-get-requestId-poll-status',
      pollingInterval: extractPollingInterval(apiEndpointsContent),
      maxPollingTime: extractMaxPollingTime(apiEndpointsContent),
      statusStates: ['PENDING', 'IN_PROGRESS', 'COMPLETED', 'FAILED', 'TIMEOUT']
    }
  }

  // Pagination
  if (componentsContent.includes('pagination') ||
      apiEndpointsContent.includes('pageSize')) {
    patterns.pagination = {
      enabled: true,
      serverSide: apiEndpointsContent.includes('pageNo'),
      defaultPageSize: extractDefaultPageSize(apiEndpointsContent),
      pageSizeOptions: extractPageSizeOptions(apiEndpointsContent)
    }
  }

  // Validation
  patterns.validation = {
    clientSide: componentsContent.includes('validation') ||
                componentsContent.includes('Validators'),
    serverSide: apiEndpointsContent.includes('validation'),
    pomSchemaValidation: componentsContent.includes('POM schema')
  }

  return patterns
}
```

#### 6h: Extract Repository Structure

```typescript
function extractRepositoryStructure(architectureContent, componentsContent) {
  // Parse Section 4.1 Repository Structure
  // Extract file paths and folder organization

  const structure = {
    baseDirectory: 'src/app',
    sharedComponents: 'shared/components',
    featureDirectory: null,
    componentPath: null,
    servicesPath: null,
    modelsPath: null,
    commonServicesPath: 'common/services'
  }

  // Look for code blocks with folder structure
  // Extract paths from tree diagrams or path listings

  return structure
}
```

**Build Requirements Object:**

```typescript
function buildRequirementsObject(
  tddPath,
  componentArchitecture,
  apiEndpoints,
  dataModels,
  formFields,
  uiPattern,
  workflowPattern,
  specialPatterns,
  repositoryStructure
) {
  return {
    version: '1.0.0',
    extractedAt: new Date().toISOString(),
    sourceTdd: tddPath,
    componentArchitecture,
    apiEndpoints,
    dataModels,
    formFields,
    uiPattern,
    workflowPattern,
    specialPatterns,
    repositoryStructure
  }
}
```

**Write generation-requirements.json:**

```typescript
const requirementsPath = `${cacheDir}/generation-requirements.json`
const requirementsJson = JSON.stringify(requirements, null, 2)

Write({
  file_path: requirementsPath,
  content: requirementsJson
})

console.log('✅ Generated requirements analysis')
console.log(`📋 Requirements file: ${requirementsPath}`)
console.log(`📊 Detected ${requirements.componentArchitecture.components.length} components`)
console.log(`🔗 Detected ${requirements.apiEndpoints.endpoints.length} API endpoints`)
console.log(`📝 Detected ${requirements.dataModels.interfaces.length} data models`)
console.log(`🎨 UI Pattern: ${requirements.uiPattern.type}`)
```

**Implementation Note:** The semantic analysis should be lightweight and focus on extracting structured data from markdown patterns. It should not make assumptions or add content not present in the TDD. If a pattern is ambiguous or missing, mark it as `null` or provide a minimal safe default.

**EXECUTION CHECKPOINT:**
```typescript
// Check if requirements already exist before regenerating
// Call the analysis functions defined above using the extracted section files

const requirementsPath = `${cacheDir}/generation-requirements.json`
const requirementsExists = Bash(`test -f "${requirementsPath}" && echo "EXISTS" || echo "MISSING"`)

if (requirementsExists && requirementsExists.trim() === "EXISTS") {
  console.log(`✅ Requirements file already exists, skipping semantic analysis`)
  console.log(`📋 Using existing: ${requirementsPath}`)
} else {
  // Only run semantic analysis if requirements.json doesn't exist
  console.log(`⚙️ Running semantic analysis to generate requirements...`)

  const requirements = performSemanticAnalysis(cacheDir, sections)

  function performSemanticAnalysis(cacheDir, sections) {
    // Step 6a: Read key sections
    const componentsContent = sections.components ? Read(sections.components) : ''
    const formsContent = sections.forms ? Read(sections.forms) : ''
    const apiEndpointsContent = sections['api-integration-endpoints'] ? Read(sections['api-integration-endpoints']) : ''
    const architectureContent = sections.architecture ? Read(sections.architecture) : ''

    // Step 6b-6h: Call analysis functions
    const componentArchitecture = analyzeComponentArchitecture(componentsContent, formsContent)
    const apiEndpoints = extractApiEndpoints(apiEndpointsContent)
    const dataModels = extractDataModels(componentsContent, formsContent, apiEndpointsContent)
    const formFields = extractFormFields(formsContent)
    const uiPattern = detectUIPattern(componentsContent, apiEndpointsContent)
    const workflowPattern = detectWorkflowPattern(componentsContent)
    const specialPatterns = detectSpecialPatterns(componentsContent, apiEndpointsContent)
    const repositoryStructure = extractRepositoryStructure(architectureContent)

    // Build final requirements object
    return buildRequirementsObject(
      tddPath,
      componentArchitecture,
      apiEndpoints,
      dataModels,
      formFields,
      uiPattern,
      workflowPattern,
      specialPatterns,
      repositoryStructure
    )
  }

  // Write generation-requirements.json
  Write(requirementsPath, JSON.stringify(requirements, null, 2))

  console.log('✅ Generated generation-requirements.json with semantic analysis')
}
```

### Step 7: Return Results

Provide extraction results in response message:

**Success format:**
```
TDD extraction completed successfully.

**Status:** success
**TDD File:** /path/to/tdd.md
**Extraction Directory:** /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/

**Extracted Sections:**
- overview: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/overview.md
- architecture: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/architecture.md
- components: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/components.md
- user-journey: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/user-journey.md
- api-integration: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/api-integration.md
- api-integration-configuration: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/api-integration-configuration.md
- api-integration-interceptors: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/api-integration-interceptors.md
- api-integration-endpoints: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/api-integration-endpoints.md
- api-integration-flows: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/api-integration-flows.md
- forms: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/forms.md
- error-handling: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/error-handling.md
- testing: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/testing.md
- security: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/security.md
- performance: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/performance.md
- dependencies: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/dependencies.md

**Generation Requirements:** /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/generation-requirements.json

**Cache Behavior:**
✅ Requirements file persists across invocations
✅ Semantic analysis skipped if requirements.json already exists
💡 To force regeneration, delete requirements.json or entire cache directory

**Pre-Analyzed Context:**
✅ Component architecture detected (3 components, 4 services)
✅ API endpoints extracted (5 endpoints)
✅ Data models identified (8 interfaces)
✅ UI pattern detected: static-components
✅ Workflow pattern: search-then-create
✅ Validation rules extracted

**Warnings:** None

**Token Savings:** Estimated 57-98% savings depending on sections loaded
**Analysis Savings:** Generation agents can skip 500+ lines of semantic analysis
```

**Cached format (using existing files):**
```
Perfect! All 15 expected sections are already extracted and cached. I'll use the existing cached files automatically without prompting for re-extraction.

---

## Using Existing Cached TDD Extraction

**Status:** cached
**TDD File:** /path/to/tdd.md
**Cache Directory:** /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/

**Cached Sections:**
- overview: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/overview.md
- components: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/components.md
[... other cached sections ...]

**Generation Requirements:** /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name/generation-requirements.json

**Note:** Using existing cached files. To force re-extraction, delete the cache directory:
```bash
rm -rf "/path/to/plugins/AIDLC-axis/.cache/tdd-extractions/tdd-name"
```
```

**Partial format (some sections missing):**
```
TDD extraction completed with warnings.

**Status:** partial
**Warnings:**
- Section 'api-integration-interceptors' not found in source TDD
- Section 'performance' not found in source TDD

**Extracted Sections:** (list available sections)
...
```

**Error format:**
```
TDD extraction failed.

**Status:** error
**Message:** TDD file not found at /invalid/path.md
**TDD File:** /invalid/path.md
```

## Error Scenarios

| Error | Detection | Response | Calling Agent Should |
|-------|-----------|----------|---------------------|
| **File not found** | Grep returns empty | status: "error", message: "TDD file not found or contains no sections" | Ask user for correct path |
| **No major sections found** | Grep finds no ## headers | status: "error", message: "No major sections found (expected ## 1. Overview format)" | Fall back to full file read or ask user |
| **Some sections missing** | Partial section matches | status: "partial", warnings array listing missing sections | Continue with available sections |
| **Cache exists** | Directory with .md files found | Ask user via AskUserQuestion | Use cached or re-extract based on user choice |
| **Grep tool unavailable** | Grep command fails | Automatic fallback to legacy Read-based approach | Transparent to caller |
| **Read operation fails** | Read with offset/limit fails | status: "error", message: "Failed to extract section content" | Report error to user |
| **Write permission denied** | Write fails | status: "error", message: "Cannot write to plugin cache directory" | Report error to user |
| **Cache directory creation fails** | mkdir fails | status: "error", message: "Cannot create cache directory" | Report error to user |

## Fallback Mechanism

**Automatic graceful degradation** ensures extraction works even if Grep tool is unavailable or fails:

```typescript
// Wrapper function with try-catch fallback
async function extractTDDSections(tddPath, pluginRoot) {
  try {
    // Try optimized Grep-based approach (93% memory savings)
    return await extractTDDSectionsOptimized(tddPath, pluginRoot)
  } catch (error) {
    // Fall back to legacy Read-based approach if Grep fails
    console.warn("Grep-based extraction failed, using legacy approach:", error)
    return await extractTDDSectionsLegacy(tddPath, pluginRoot)
  }
}

// Legacy approach (backward compatibility)
function extractTDDSectionsLegacy(tddPath, pluginRoot) {
  // Read entire file into memory (old approach)
  const tddContent = Read(tddPath)

  // Use regex matching on in-memory content
  const sections = {}
  const overviewMatch = tddContent.match(/^## 1\.?\s*Overview/mi)
  if (overviewMatch) {
    const startIndex = overviewMatch.index
    const endMatch = tddContent.slice(startIndex + 1).match(/^## \d+/m)
    const endIndex = endMatch ? startIndex + 1 + endMatch.index : tddContent.length
    const sectionContent = tddContent.slice(startIndex, endIndex).trim()

    Write(`${cacheDir}/overview.md`, metadata + sectionContent)
    sections.overview = `${cacheDir}/overview.md`
  }
  // ... repeat for all sections

  return { status: "success", sections, warnings: [] }
}
```

**When fallback triggers:**
- Grep tool not available on system (rare)
- Grep pattern matching fails unexpectedly
- Any unexpected error in boundary detection

**Result:** Extraction always succeeds if TDD file is valid, regardless of which approach is used.

## Usage Example

### Invocation by axis-router

**Router invokes agent:**
```typescript
Task(subagent_type: "AIDLC-axis:tdd-extractor",
     prompt: "Extract sections from /Users/vensan/project/.idea/client-information-ui-design.md")
```

**Agent response message:**
```
TDD extraction completed successfully.

**Status:** success
**TDD File:** /Users/vensan/project/.idea/client-information-ui-design.md
**Extraction Directory:** /Users/vensan/project/plugins/AIDLC-axis/.cache/tdd-extractions/client-information-ui-design/

**Extracted Sections:**
- overview: /Users/vensan/project/plugins/AIDLC-axis/.cache/tdd-extractions/client-information-ui-design/overview.md
- components: /Users/vensan/project/plugins/AIDLC-axis/.cache/tdd-extractions/client-information-ui-design/components.md
- forms: /Users/vensan/project/plugins/AIDLC-axis/.cache/tdd-extractions/client-information-ui-design/forms.md
[... other sections ...]

**Token Savings:** Estimated 57-98% vs loading full 41,919 token file
```

**Router next steps:**
1. Parse extraction response to get section paths
2. Analyze user request: "Generate search form with validation"
3. Determine needed sections: overview, components, forms (3 of 15)
4. Read section files in parallel using Read tool
5. Extract context and delegate to generator agent

## Cache File Structure

```
plugins/AIDLC-axis/.cache/tdd-extractions/
└── client-information-ui-design/
    ├── overview.md
    ├── architecture.md
    ├── components.md
    ├── user-journey.md
    ├── api-integration.md
    ├── api-integration-configuration.md
    ├── api-integration-interceptors.md
    ├── api-integration-endpoints.md
    ├── api-integration-flows.md
    ├── forms.md
    ├── error-handling.md
    ├── testing.md
    ├── security.md
    ├── performance.md
    ├── dependencies.md
    └── generation-requirements.json  ← NEW: Pre-analyzed requirements
```

**File Metadata Example:**
```markdown
---
# Auto-generated by tdd-extractor agent
source: /Users/vensan/project/.idea/client-information-ui-design.md
section: overview
extracted: 2026-01-30T10:30:00Z
agent: tdd-extractor
---

## 1. Overview

### 1.1 Purpose

The Client Information UI component provides...
```

## Cleanup

**No automatic cleanup** - cache files persist for repeated use across sessions.

**Manual cleanup:**
```bash
# From project root
rm -rf plugins/AIDLC-axis/.cache/tdd-extractions/

# Delete specific TDD cache
rm -rf plugins/AIDLC-axis/.cache/tdd-extractions/client-information-ui-design/
```

**Re-extraction behavior:**
- When cache exists, user is prompted to choose: use cached files or re-extract
- If user chooses "Re-extract sections", existing cache is deleted before extraction
- If user chooses "Use cached files", existing cache is returned immediately (no extraction)

**Git ignore:** Add `.cache/` to `plugins/AIDLC-axis/.gitignore` to prevent committing extracted files.

## Performance Characteristics

| Metric | Value |
|--------|-------|
| **Grep operations** | 2 (major sections + subsections) |
| **Read operations** | 12-15 (targeted reads per section) |
| **Write operations** | 12-15 (one per section) |
| **Peak memory** | ~3,000 tokens (vs 41,919 tokens legacy approach) |
| **Memory reduction** | 93% vs loading full TDD file |
| **Extraction time** | ~3-5 seconds for 3,600 line TDD |
| **Disk usage** | ~1-2 MB per TDD |
| **Token savings** | 57-98% vs full file load for calling agents |

## Integration Notes

**Calling agents:**
- axis-router (Step 1a: TDD extraction workflow)

**Workflow:**
1. axis-router receives user request with TDD file path
2. Router invokes tdd-extractor agent with TDD path
3. tdd-extractor reads file, extracts sections, writes temp files
4. tdd-extractor returns section path mappings in response
5. Router parses response and determines needed sections
6. Router reads needed section files in parallel
7. Router delegates to generator with section paths and context

**Backward Compatibility:**
- Does NOT replace feature-specs (still optimal for pre-split TDDs)
- Does NOT replace inline content (still backward compatible)
- Enhances user-provided monolithic TDD paths with automatic extraction
