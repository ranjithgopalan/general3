#!/usr/bin/env python3
"""
Axis Documentation Agent Generator

This script generates a Claude Code agent that contains comprehensive documentation
for all Axis UI Angular components.

It reads from:
- src/assets/data/all-examples-search-data.json (component metadata and examples)
- src/assets/readme/readme.json (API documentation)
- src/app/components-guide/<component>/<component>.snippet.ts (TypeScript and HTML code examples)

Output:
- Generates plugins/axis-tools/agents/axis-documentation.md (Claude Code agent) with:
  - YAML frontmatter (name, description, tools, model)
  - System prompt explaining the agent's purpose
  - Complete documentation for all 77 Axis components
  - TypeScript and HTML code examples
  - API documentation with prop tables
"""

import json
import re
from pathlib import Path
from typing import Dict


class AxisDocsGenerator:
    """Generates markdown documentation for Axis components."""

    def __init__(self, base_path: str = ".", output_dir: str = None):
        self.base_path = Path(base_path)
        self.examples_data = None
        self.readme_data = None
        # Default output to agents directory
        if output_dir:
            self.output_dir = Path(output_dir)
        else:
            self.output_dir = Path(__file__).parent

    def load_json_data(self):
        """Load JSON data files."""
        print("Loading JSON data files...")

        # Load examples metadata
        examples_path = self.base_path / "src/assets/data/all-examples-search-data.json"
        with open(examples_path, 'r', encoding='utf-8') as f:
            self.examples_data = json.load(f)

        # Load API documentation
        readme_path = self.base_path / "src/assets/readme/readme.json"
        with open(readme_path, 'r', encoding='utf-8') as f:
            self.readme_data = json.load(f)

        print(f"Loaded {len(self.examples_data)} libraries")
        print(f"Loaded API docs for {len(self.readme_data)} components")

    def parse_snippet_file(self, snippet_path: Path) -> Dict:
        """Parse TypeScript snippet file and extract code examples."""
        if not snippet_path.exists():
            return {}

        with open(snippet_path, 'r', encoding='utf-8') as f:
            content = f.read()

        snippets = {}

        # Extract the exported object using regex
        # Pattern: export const <name>: CodeSnippetCollection = { ... }
        pattern = r'export\s+const\s+\w+:\s*CodeSnippetCollection\s*=\s*\{(.*)\};'
        match = re.search(pattern, content, re.DOTALL)

        if not match:
            return {}

        # Extract individual snippet sections
        # Pattern: snippet_name: [ ... ]
        snippet_pattern = r'(\w+):\s*\[(.*?)\](?=,\s*\w+:|,?\s*\})'

        for snippet_match in re.finditer(snippet_pattern, match.group(1), re.DOTALL):
            snippet_name = snippet_match.group(1)
            snippet_content = snippet_match.group(2)

            # Extract code blocks
            html_code = None
            ts_code = None

            # Find HTML code
            html_match = re.search(r'language:\s*["\']HTML["\']\s*,.*?code:\s*`(.*?)`',
                                  snippet_content, re.DOTALL)
            if html_match:
                html_code = html_match.group(1).strip()

            # Find TS code
            ts_match = re.search(r'language:\s*["\']TS["\']\s*,.*?code:\s*`(.*?)`',
                                snippet_content, re.DOTALL)
            if ts_match:
                ts_code = ts_match.group(1).strip()

            snippets[snippet_name] = {
                'html': html_code,
                'ts': ts_code
            }

        return snippets

    def clean_html(self, html_text: str) -> str:
        """Remove HTML tags and return plain text."""
        if not html_text:
            return ""
        # Remove HTML tags
        clean = re.sub(r'<[^>]+>', ' ', html_text)
        # Clean up whitespace
        clean = re.sub(r'\s+', ' ', clean).strip()
        return clean

    def generate_component_docs(self, component_data: Dict) -> str:
        """Generate markdown documentation for a single component."""
        component_name = component_data['componentName']
        label = component_data.get('label', component_name)
        url = component_data.get('url', '')

        # Start markdown content
        md = []
        md.append(f"# {label}\n")
        md.append(f"**Component:** `{component_name}`\n")
        md.append(f"**URL:** `{url}`\n")
        md.append("\n---\n")

        # Add examples section
        if 'examplesList' in component_data:
            md.append("## Examples\n")

            # Load snippet file
            snippet_path = self.base_path / f"src/app/components-guide/{component_name}/{component_name}.snippet.ts"
            snippets = self.parse_snippet_file(snippet_path)

            for example in component_data['examplesList']:
                example_id = example.get('id', '')
                example_label = example.get('label', '')

                md.append(f"### {example_label}\n")

                if example.get('updated'):
                    md.append("*[Updated]*\n")

                # Add search keywords
                if 'searchList' in example:
                    md.append(f"**Keywords:** {', '.join(example['searchList'])}\n")

                # Add code snippet if available
                if example_id in snippets:
                    snippet = snippets[example_id]

                    if snippet['ts']:
                        md.append("\n**TypeScript:**\n")
                        md.append("```typescript\n")
                        md.append(snippet['ts'])
                        md.append("\n```\n")

                    if snippet['html']:
                        md.append("\n**HTML:**\n")
                        md.append("```html\n")
                        md.append(snippet['html'])
                        md.append("\n```\n")

                md.append("\n")

        # Add API documentation section
        api_key = component_name
        if self.readme_data and api_key in self.readme_data:
            md.append("\n---\n")
            md.append("## API Documentation\n")

            api_data = self.readme_data[api_key]

            # Inputs
            if 'Inputs' in api_data:
                md.append("\n### Inputs\n")
                md.append("| Component | Property | Type | Default | Mandatory | Description |\n")
                md.append("|-----------|----------|------|---------|-----------|-------------|\n")

                for input_item in api_data['Inputs']:
                    comp_name = input_item.get('compName', '')
                    prop = input_item.get('property', '')
                    type_val = input_item.get('type', '')
                    default = input_item.get('defaultValue', '')
                    mandatory = input_item.get('mandatory', '')
                    desc = self.clean_html(input_item.get('description', ''))

                    # Handle rowspan for cleaner output
                    if input_item.get('rowspan', 0) != -1:
                        md.append(f"| `{comp_name}` | `{prop}` | `{type_val}` | `{default}` | {mandatory} | {desc} |\n")
                    else:
                        md.append(f"| | `{prop}` | `{type_val}` | `{default}` | {mandatory} | {desc} |\n")

                md.append("\n")

            # Outputs
            if 'Outputs' in api_data:
                md.append("### Outputs\n")
                md.append("| Component | Property | Description |\n")
                md.append("|-----------|----------|-------------|\n")

                for output_item in api_data['Outputs']:
                    comp_name = output_item.get('compName', '')
                    prop = output_item.get('property', '')
                    desc = self.clean_html(output_item.get('description', ''))

                    if output_item.get('rowspan', 0) != -1:
                        md.append(f"| `{comp_name}` | `{prop}` | {desc} |\n")
                    else:
                        md.append(f"| | `{prop}` | {desc} |\n")

                md.append("\n")

            # API Methods
            if 'ApiMethods' in api_data:
                md.append("### API Methods\n")
                md.append("| Component | Method | Input Params | Return Type | Description |\n")
                md.append("|-----------|--------|--------------|-------------|-------------|\n")

                for method_item in api_data['ApiMethods']:
                    comp_name = method_item.get('compName', '')
                    method = method_item.get('methodName', '')
                    params = method_item.get('inputsParameters', '')
                    return_type = method_item.get('returnType', '')
                    desc = self.clean_html(method_item.get('description', ''))

                    if method_item.get('rowspan', 0) != -1:
                        md.append(f"| `{comp_name}` | `{method}` | `{params}` | `{return_type}` | {desc} |\n")
                    else:
                        md.append(f"| | `{method}` | `{params}` | `{return_type}` | {desc} |\n")

                md.append("\n")

            # Selectors
            if 'Selectors' in api_data:
                md.append("### Selectors\n")
                md.append("| Component | Description |\n")
                md.append("|-----------|-------------|\n")

                for selector_item in api_data['Selectors']:
                    comp_name = selector_item.get('compName', '')
                    desc = self.clean_html(selector_item.get('description', ''))
                    md.append(f"| `{comp_name}` | {desc} |\n")

                md.append("\n")

            # JSON Config (if available)
            if 'JsonConfig' in api_data:
                md.append("### JSON Configuration\n")
                md.append("| Configuration | Key | Return Type | Description |\n")
                md.append("|---------------|-----|-------------|-------------|\n")

                for config_item in api_data['JsonConfig']:
                    config_name = config_item.get('configurationName', '')
                    key = config_item.get('inputKey', '')
                    return_type = config_item.get('returnType', '')
                    desc = self.clean_html(config_item.get('description', ''))

                    if config_item.get('rowspan', 0) != -1:
                        md.append(f"| {config_name} | `{key}` | `{return_type}` | {desc} |\n")
                    else:
                        md.append(f"| | `{key}` | `{return_type}` | {desc} |\n")

                md.append("\n")

        return ''.join(md)


    def generate_all_docs(self):
        """Generate Claude Code agent with Axis components documentation."""
        self.load_json_data()

        # Create output directory
        self.output_dir.mkdir(parents=True, exist_ok=True)

        print("\nGenerating Axis documentation agent...")

        # Collect all components from all libraries
        all_components = []
        for library in (self.examples_data or []):
            library_name = library.get('library', 'unknown')
            for component_data in library.get('data', []):
                all_components.append({
                    'library': library_name,
                    'data': component_data,
                    'name': component_data.get('componentName', 'unknown'),
                    'label': component_data.get('label', component_data.get('componentName', 'unknown'))
                })

        # Sort components by label
        all_components.sort(key=lambda x: x['label'])

        # Start building the agent file
        md = []

        # Add YAML frontmatter
        md.append("---\n")
        md.append("name: axis-documentation\n")
        md.append("description: Provides comprehensive documentation for all Axis UI Angular components including code examples, API documentation, and usage guidelines. Use this agent when you need to reference Axis component APIs, find component examples, or understand how to use specific Axis UI components.\n")
        md.append("tools: Read, Grep, Glob\n")
        md.append("model: sonnet\n")
        md.append("---\n\n")

        # Add system prompt
        md.append("# Axis UI Components Documentation Agent\n\n")
        md.append("You are a specialized agent with expert knowledge of the Axis UI Angular framework. ")
        md.append("Your role is to provide accurate, detailed information about Axis components, including:\n\n")
        md.append("- Component APIs (inputs, outputs, methods)\n")
        md.append("- TypeScript and HTML code examples\n")
        md.append("- Component usage patterns and best practices\n")
        md.append("- Component-specific configuration options\n\n")

        md.append("## How to Use This Documentation\n\n")
        md.append("When a user asks about an Axis component:\n\n")
        md.append("1. **Search the documentation** below for the relevant component\n")
        md.append("2. **Provide specific examples** from the TypeScript and HTML sections\n")
        md.append("3. **Reference the API tables** for input/output properties\n")
        md.append("4. **Explain the usage** in the context of the user's question\n\n")

        md.append("## Available Components\n\n")
        md.append(f"This documentation covers **{len(all_components)} Axis UI components** including:\n\n")

        # List component categories
        categories = {
            'Form Controls': ['button', 'checkbox', 'radio', 'input', 'dropdown', 'datepicker', 'timepicker', 'slider'],
            'Layout': ['accordion', 'card', 'tab', 'modal', 'bottomSheet', 'carousel'],
            'Navigation': ['navbar', 'breadcrumb', 'paginator', 'portal-menu'],
            'Charts': ['donut-chart', 'bar-plus-multi-line-chart', 'gauge-chart', 'funnel-chart', 'bubble-chart'],
            'Data Display': ['data-grid', 'list', 'tree', 'styled-list'],
            'Utilities': ['notifications', 'loading', 'tooltip', 'alert', 'progress-bar']
        }

        for category, components in categories.items():
            md.append(f"- **{category}**: {', '.join(components)}\n")

        md.append("\n---\n\n")

        md.append("# Complete Component Documentation\n\n")

        # Generate Table of Contents
        md.append("## Table of Contents\n\n")
        for comp in all_components:
            label = comp['label']
            anchor = comp['name'].lower().replace(' ', '-')
            md.append(f"- [{label}](#{anchor})\n")
        md.append("\n---\n\n")

        # Generate documentation for each component
        for comp in all_components:
            print(f"  - Generating docs for {comp['name']}...")
            try:
                comp_md = self.generate_component_docs(comp['data'])
                md.append(comp_md)
                md.append("\n---\n\n")
            except Exception as e:
                print(f"    [ERROR] Error generating docs for {comp['name']}: {e}")

        # Write to agent file
        output_file = self.output_dir / "axis-documentation.md"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(''.join(md))

        print(f"\n[SUCCESS] Axis documentation agent generated: {output_file}")
        print(f"[INFO] Agent contains documentation for {len(all_components)} components")





def main():
    """Main entry point."""
    import argparse

    parser = argparse.ArgumentParser(
        description='Generate Claude Code agent for Axis UI components documentation',
        epilog="""
Example:
  # Generate agent from current directory
  python generate_axis_docs.py

  # Generate agent from different source location
  python generate_axis_docs.py --base-path /path/to/axis-developer-guide

  # Custom output directory
  python generate_axis_docs.py --output-dir /path/to/output
        """,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument(
        '--base-path',
        default='.',
        help='Base path of the axis-developer-guide repository (default: current directory)'
    )
    parser.add_argument(
        '--output-dir',
        default=None,
        help='Output directory for generated agent file (default: plugins/axis-tools/agents/)'
    )

    args = parser.parse_args()
    base_path = Path(args.base_path)

    print("="*60)
    print("Axis Documentation Agent Generator")
    print("="*60)

    # Generate agent
    generator = AxisDocsGenerator(base_path=str(base_path), output_dir=args.output_dir)

    try:
        generator.generate_all_docs()
    except Exception as e:
        print(f"[ERROR] Failed to generate agent: {e}")
        import traceback
        traceback.print_exc()
        return 1

    print("\n" + "="*60)
    print("Agent generation complete!")
    print("="*60)
    return 0


if __name__ == '__main__':
    main()
