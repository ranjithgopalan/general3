# Low-Level Design: AXIS Angular Code Generation Plugin

**Feature:** Claude Code Plugin for AXIS Framework Development

**User Story ID:** US-011

**Status:** Implementing CR-001 (JSON Schema Generator)

**Document Type:** Low-Level Design (LLD)

**Consumer:** axis-tools plugin agents

---

## Table of Contents

1. [Document Overview](#1-document-overview)
2. [JSON Schema Generator Implementation (CR-001)](#2-json-schema-generator-implementation-cr-001)
3. [Agent Specifications](#3-agent-specifications)
4. [Skill Implementations](#4-skill-implementations)
5. [TypeScript Interfaces](#5-typescript-interfaces)
6. [Validation Rules](#6-validation-rules)
7. [Output Templates](#7-output-templates)
8. [Error Handling](#8-error-handling)
9. [Testing Specifications](#9-testing-specifications)

---

## 1. Document Overview

### 1.1 Purpose

This LLD provides implementation-level specifications for the axis-tools plugin, with primary focus on CR-001 (JSON Schema Generator). It serves as a detailed guide for implementing the visual-to-schema conversion capability.

### 1.2 Scope

| Capability | Coverage |
|------------|----------|
| JSON Schema Generator (CR-001/BR11) | Full implementation details |
| UI Generator updates | Schema generation routing |
| New skill: json-schema-generator | Complete specification |
| DynamoDB schema compliance | Field-level validation |

### 1.3 Related Documents

| Document | Location | Purpose |
|----------|----------|---------|
| BRD | `axis-tools-brd.md` | Business requirements |
| HLD | `axis-tools-hld.md` | Architecture overview |
| DynamoDB Spec | Enterprise DynamoDB Specification | Schema reference |
| AXIS Component APIs | `agents/axis-documentation.md` | **78 AXIS component APIs with exact property names** |

### 1.4 AXIS Documentation Reference

The `axis-documentation.md` file (560KB) contains comprehensive API documentation for all 78 AXIS components. **This is the authoritative source for:**
- Exact property names (inputs/outputs)
- Property types and defaults
- Validation directives
- Component-specific configurations

**Key components for JSON schema generation:**

| Component | Key Properties | Usage |
|-----------|----------------|-------|
| `axis-dropdown` | `dataProvider`, `placeholder`, `required`, `disabled`, `renderingLabel`, `isCombobox`, `isTypeahead` | Dropdown fields |
| `axisInputNumber` | `min`, `max`, `max_length`, `decimal`, `prefix`, `suffix`, `restrict` | Numeric inputs |
| `maskedInput` | `maskedInput`, `separator`, `secure` | SSN, phone, masked fields |
| `axis-ui-generator` | `[uiStructure]`, `[uiData]`, `(uiEmitUpdate)`, `(uiEmit)` | Dynamic form rendering (AUG) - contextual naming: `ui{Feature}Structure`, `ui{Feature}Data` |
| `axis-datepicker` | `minDate`, `maxDate`, `dateFormat`, `required` | Date fields |
| `axis-checkbox` | `checked`, `disabled`, `required` | Checkbox fields |
| `axis-button` | `kind-primary`, `kind-secondary`, `disabled` | Buttons |

---

## 2. JSON Schema Generator Implementation (CR-001)

### 2.1 Component Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    JSON Schema Generator Components                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      axis-ui-generator.md                            │   │
│  │  (Updated to support JSON schema generation routing)                 │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              │                                               │
│                              │ Routes "generate JSON schema" requests        │
│                              ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                   NEW: json-schema-generator skill                   │   │
│  │                                                                      │   │
│  │  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐        │   │
│  │  │ Visual Analyzer │  │ Schema Builder │  │ Output Generator│        │   │
│  │  └────────────────┘  └────────────────┘  └────────────────┘        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              │                                               │
│                              ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         Output Files                                 │   │
│  │  - {componentId}-schema.json (DynamoDB format)                      │   │
│  │  - {componentId}-schema.yaml (human-readable)                       │   │
│  │  - {componentId}-field-catalog.md (documentation)                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Workflow Implementation

#### Step 1: Request Detection

**Location:** `commands/axis.md` routing logic

**Detection Keywords:**
```
JSON schema, generate schema, DynamoDB schema, dynamic form schema,
schema from mockup, schema from image, schema from screenshot
```

**Routing Logic:**
```markdown
If request contains:
  - "JSON schema" OR "DynamoDB schema" OR "generate schema"
  - AND has attached image OR references mockup/screenshot
Then:
  - Route to axis-ui-generator with task_type: "json-schema-generation"
```

#### Step 2: Visual Analysis

**Performed by:** axis-ui-generator agent using Claude's vision capabilities

**Analysis Process:**

```typescript
interface VisualAnalysisResult {
  // Layout detection
  layout: {
    type: 'grid' | 'flex' | 'vertical';
    columns: number;
    gridTemplateColumns: string;  // e.g., "1fr 1fr 1fr"
  };

  // Section detection
  sections: {
    id: string;
    title: string;
    position: number;
    bounds: { top: number; left: number; width: number; height: number };
  }[];

  // Field detection
  fields: {
    id: string;
    label: string;
    detectedType: DetectedFieldType;
    position: { row: number; column: number };
    visualCues: string[];  // e.g., ["has dropdown arrow", "has asterisk"]
  }[];

  // Styling detection
  styling: {
    backgroundColor: string;
    borderColor: string;
    borderRadius: string;
    primaryColor: string;  // From buttons/accents
  };
}

type DetectedFieldType =
  | 'text-input'
  | 'dropdown'
  | 'date-picker'
  | 'checkbox'
  | 'radio-group'
  | 'button'
  | 'link'
  | 'textarea';
```

**Visual Detection Rules:**

| Visual Pattern | Detection | Confidence Factors |
|----------------|-----------|-------------------|
| Rectangular box with single line | `text-input` | Border visible, no arrow |
| Box with down arrow (▼) | `dropdown` | Arrow icon present |
| Box with calendar icon | `date-picker` | Calendar/date icon |
| Small square/circle + label | `checkbox` or `radio-group` | Shape indicates type |
| Rounded rectangle with text | `button` | Filled background, centered text |
| Underlined text | `link` | Underline or blue color |
| Multi-line box | `textarea` | Height > typical input |

#### Step 3: Plan Generation and Confirmation

**Plan Template:**

```markdown
## JSON Schema Generation Plan

Based on my analysis of your mockup, here's my proposed schema:

### Layout Detected
- **Type:** {layout.type} ({layout.columns} columns)
- **Grid Template:** `{layout.gridTemplateColumns}`

### Sections Identified ({sections.length})
| # | Section | Fields |
|---|---------|--------|
{for each section}
| {position} | {title} | {fieldCount} fields |
{end for}

### Fields Identified ({fields.length} total)
| Field | Detected Type | AXIS Component | Position |
|-------|---------------|----------------|----------|
{for each field}
| {label} | {detectedType} | {axisComponent} | Row {row}, Col {col} |
{end for}

### Output Files
- `{componentId}-schema.json` - DynamoDB-compatible JSON schema
- `{componentId}-schema.yaml` - Human-readable YAML version
- `{componentId}-field-catalog.md` - Field documentation

### Validation Rules (Inferred)
{for each field with inferred validation}
- **{fieldId}**: {validationDescription}
{end for}

### Assumptions
- POM paths are placeholders requiring developer input
- Dropdown options will use `refGroupCode` for runtime loading from DynamoDB
- Styling values are extracted from visual analysis (may need adjustment)

### Questions (if any)
{list any ambiguous elements that need clarification}

**Please confirm this plan or provide modifications before I generate the schema.**
```

#### Step 4: Schema Generation

**After user confirmation, generate the following outputs:**

### 2.3 Output Generation Specifications

#### Output 1: DynamoDB JSON Schema

**File:** `{componentId}-schema.json`

**Structure:**

```json
{
  "transactionType": "{transactionType}",
  "componentId": "{componentId}",
  "componentName": "{componentName}",
  "version": "1.0",
  "createdAt": "{ISO timestamp}",
  "updatedAt": "{ISO timestamp}",
  "componentSpecifications": {
    "type": "form",
    "layout": "{grid|flex|vertical}",
    "backgroundColor": "{extracted color}",
    "sections": [
      {
        "sectionId": "{kebab-case-id}",
        "title": "{Section Title}",
        "position": 1,
        "collapsed": false,
        "fields": [
          {
            "fieldId": "{camelCaseId}",
            "label": "{Field Label}",
            "type": "{text|email|tel|dropdown|date|checkbox|button|link}",
            "required": true,
            "position": 1,
            "gridColumn": "1 / 2",
            "pomPath": "{suggested.pom.path}",
            "placeholder": "{Placeholder text}",
            "validation": {
              "pattern": "{regex if applicable}",
              "minLength": null,
              "maxLength": null,
              "min": null,
              "max": null
            },
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          }
        ]
      }
    ],
    "styling": {
      "padding": "20px",
      "border": "1px solid #CCCCCC",
      "borderRadius": "8px",
      "backgroundColor": "#FFFFFF",
      "display": "grid",
      "gridTemplateColumns": "{extracted grid}",
      "gap": "16px"
    }
  }
}
```

#### Output 2: YAML Version

**File:** `{componentId}-schema.yaml`

```yaml
# AXIS UI Component Schema
# Generated from visual mockup analysis
# Consumer: DynamoDB ui-component-catalog table

transactionType: "{transactionType}"
componentId: "{componentId}"
componentName: "{componentName}"
version: "1.0"

componentSpecifications:
  type: form
  layout: grid
  backgroundColor: "#FFFFFF"

  sections:
    - sectionId: "{section-id}"
      title: "{Section Title}"
      position: 1
      collapsed: false
      fields:
        - fieldId: "{fieldId}"
          label: "{Field Label}"
          type: text
          required: true
          position: 1
          gridColumn: "1 / 2"
          pomPath: "{suggested.pom.path}"  # TODO: Verify POM path
          placeholder: "{Placeholder}"
          validation:
            pattern: null
            minLength: null
            maxLength: null
          styling:
            width: "100%"
            padding: "8px"
            border: "1px solid #CCCCCC"
            borderRadius: "4px"

  styling:
    padding: "20px"
    border: "1px solid #CCCCCC"
    borderRadius: "8px"
    backgroundColor: "#FFFFFF"
    display: grid
    gridTemplateColumns: "1fr 1fr 1fr"
    gap: "16px"
```

#### Output 3: Field Catalog Report

**File:** `{componentId}-field-catalog.md`

```markdown
# Field Catalog: {componentName}

**Component ID:** {componentId}
**Transaction Type:** {transactionType}
**Generated:** {timestamp}

## Summary

| Metric | Value |
|--------|-------|
| Total Sections | {count} |
| Total Fields | {count} |
| Required Fields | {count} |
| Dropdown Fields | {count} |

## Field Details

### Section: {Section Title}

| Field ID | Label | Type | AXIS Component | Required | POM Path |
|----------|-------|------|----------------|----------|----------|
| {fieldId} | {label} | {type} | {axis-component} | {Yes/No} | {pomPath} |

### Dropdown Reference Codes

| Field | refGroupCode | Description |
|-------|--------------|-------------|
| {fieldId} | {CODE} | {description of what options to load} |

### Validation Rules

| Field | Rule | Value | Error Message |
|-------|------|-------|---------------|
| {fieldId} | required | true | "{label} is required" |
| {fieldId} | pattern | {regex} | "Invalid {label} format" |

## POM Path Mapping (Requires Developer Review)

The following POM paths are suggestions based on field labels. Please verify against your actual POM structure:

| Field | Suggested POM Path | Status |
|-------|-------------------|--------|
| {fieldId} | {suggested.path} | ⚠️ Needs verification |

## Next Steps

1. Review and update POM paths to match your Policy Object Model
2. Configure dropdown reference data in `booking-reference-lookup` table
3. Add custom validation rules as needed
4. Upload to DynamoDB `ui-component-catalog` table
```

---

## 3. Agent Specifications

### 3.1 dynamic-ui-generator Agent (NEW)

**File:** `agents/dynamic-ui-generator.md`

**Purpose:** Generates Angular code that renders dynamic UI using the `axis-ui-generator` component with DynamoDB integration.

**Input:** LLD or HLD document containing JSON schema definitions

**Output Files:**
| File | Purpose |
|------|---------|
| `{component-name}.component.ts` | Component with DynamoDB fetch and event handling |
| `{component-name}.component.html` | Template using `<axis-ui-generator>` |
| `{component-name}.service.ts` | DynamoDB service to fetch UI schema |
| `{component-name}.model.ts` | TypeScript interfaces |

**Key Difference from axis-ui-generator:**

| axis-ui-generator | dynamic-ui-generator |
|-------------------|----------------------|
| Generates static Angular code (.ts, .html) | Generates code that uses `<axis-ui-generator>` component |
| Direct AXIS component usage | Fetches JSON schema from DynamoDB |
| UI defined in code | UI defined in DynamoDB (ui-component-catalog) |
| No backend service needed | Requires DynamoDB service |

**Generated Component Pattern:**

```typescript
// Component uses axis-ui-generator for dynamic rendering
// IMPORTANT: Use contextual naming pattern: ui{Feature}Structure, ui{Feature}Data
@Component({
  selector: 'app-{feature-name}',  // e.g., app-client-info, app-producer-info
  standalone: true,
  imports: [UiGeneratorModule],
  template: `
    <!-- ONLY these attributes are recognized by axis-ui-generator -->
    <axis-ui-generator
      *ngIf="ui{Feature}Structure"
      [uiStructure]="ui{Feature}Structure"
      [uiData]="ui{Feature}Data"
      (uiEmitUpdate)="{feature}InfoEmitUpdate($event)"
      (uiEmit)="onFormSubmit($event)">
    </axis-ui-generator>
  `
})
export class {Feature}Component {
  // Contextual naming: use feature name, not generic
  ui{Feature}Structure: UIStructure | null = null;  // e.g., uiClientStructure, uiProducerStructure
  ui{Feature}Data: Record<string, any> = {};        // e.g., uiClientData, uiProducerData

  ngOnInit() {
    // Fetch from DynamoDB ui-component-catalog table or backend service
    this.service.getUIStructure(transactionType, componentId)
      .subscribe(response => {
        this.ui{Feature}Structure = response.componentSpecifications;
      });
  }

  // Event handler with contextual naming
  {feature}InfoEmitUpdate(event: any): void {
    this.ui{Feature}Data = { ...this.ui{Feature}Data, ...event };
    this.handleFieldDependencies(event);
  }

  onFormSubmit(event: any): void {
    // Handle form submission
  }
}
```

**DynamoDB Integration:**

| Table | Purpose | Keys |
|-------|---------|------|
| `ui-component-catalog` | Stores UI schemas | PK: transactionType, SK: componentId |
| `booking-reference-lookup` | Dropdown options | PK: groupCode, SK: code |

---

### 3.2 axis-ui-generator.md Updates

**Add to routing logic section:**

```markdown
### JSON Schema Generation (CR-001)

When the request indicates JSON schema generation:

**Detection:**
- Keywords: "JSON schema", "DynamoDB schema", "generate schema", "dynamic form schema"
- Context: Attached image/mockup + schema generation intent

**Process:**

1. **Analyze Visual Mockup**
   - Use vision capabilities to identify UI elements
   - Detect layout structure (grid columns, sections)
   - Identify field types from visual cues
   - Extract styling information

2. **Present Plan for Confirmation**
   - Show detected layout and sections
   - List all identified fields with types
   - Show inferred validation rules
   - List output files that will be generated
   - **WAIT for user confirmation before proceeding**

3. **Generate Outputs (After Confirmation)**
   - Generate DynamoDB-compatible JSON schema
   - Generate YAML version for human review
   - Generate field catalog documentation

4. **Provide Upload Instructions**
   - Explain how to upload to DynamoDB
   - Note fields requiring developer attention (POM paths, dropdowns)
```

### 3.2 axis.md Command Updates

**Add routing condition:**

```markdown
### Routing for JSON Schema Generation

**Triggers:**
- "generate JSON schema from this mockup"
- "create DynamoDB schema from image"
- "convert mockup to schema"
- "generate dynamic form schema"

**Route to:** axis-ui-generator with context:
```
{
  "task_type": "json-schema-generation",
  "input_type": "visual-mockup",
  "output_format": ["json", "yaml", "markdown"],
  "target_table": "ui-component-catalog"
}
```
```

---

## 4. Skill Implementations

### 4.1 NEW: json-schema-generator Skill

**Location:** `skills/json-schema-generator/SKILL.md`

```markdown
---
name: json-schema-generator
description: Converts visual UI mockups to AXIS-compliant DynamoDB JSON schemas. Analyzes images to detect form fields, layout structure, and styling, then generates schemas compatible with the ui-component-catalog table.
---

# JSON Schema Generator Skill

You are a visual UI analysis and schema generation expert. Convert UI mockups into AXIS-compliant JSON schemas.

## Input Analysis

When given a UI mockup/screenshot:

### 1. Layout Detection

Identify the form layout:
- **Grid Layout**: Multiple columns of fields
- **Flex Layout**: Flexible arrangement
- **Vertical Layout**: Single column stack

Count columns by analyzing field alignment patterns.

### 2. Section Detection

Look for:
- Section headers (larger/bold text above field groups)
- Visual separators (lines, spacing)
- Grouped fields with common context

### 3. Field Detection

For each UI element, identify:

| Visual Pattern | Field Type | AXIS Component |
|----------------|------------|----------------|
| Text box (single line) | text | axis-textbox |
| Text box + "@" hint | email | axis-textbox |
| Text box + phone format | tel | axis-textbox |
| Box with ▼ arrow | dropdown | axis-dropdown |
| Box with calendar icon | date | axis-datepicker |
| Square checkbox | checkbox | axis-checkbox |
| Rounded button | button | axis-button |
| Underlined/blue text | link | anchor |

### 4. Validation Inference

Infer validation from context:

| Context Clue | Inferred Validation |
|--------------|---------------------|
| "*" or "required" near label | required: true |
| "Email" in label | pattern: email regex |
| "Phone" in label | pattern: phone regex |
| "Date" in label | type: date |
| "ZIP" or "Postal" in label | pattern: postal code |
| "SSN" in label | pattern: SSN format |

### 5. POM Path Suggestion

Suggest POM paths based on field labels:

| Label Pattern | Suggested POM Path |
|---------------|-------------------|
| First Name | applicant.personalInfo.firstName |
| Last Name | applicant.personalInfo.lastName |
| Email | applicant.contactInfo.email |
| Phone | applicant.contactInfo.phone |
| Address/Street | applicant.contactInfo.address.street |
| City | applicant.contactInfo.address.city |
| State | applicant.contactInfo.address.state |
| ZIP/Postal | applicant.contactInfo.address.zipCode |
| Country | applicant.contactInfo.address.country |
| Date of Birth | applicant.personalInfo.dateOfBirth |
| SSN | applicant.personalInfo.ssn |
| Policy Number | policy.policyNumber |
| Effective Date | policy.effectiveDate |

## Output Format

Generate schema following this structure:

```json
{
  "transactionType": "NB",
  "componentId": "{derived-from-title}",
  "componentName": "{Form Title}",
  "componentSpecifications": {
    "type": "form",
    "layout": "{detected-layout}",
    "sections": [...],
    "styling": {...}
  }
}
```

## Quality Checklist

Before outputting:
- [ ] All visible fields are captured
- [ ] Field types match visual cues
- [ ] Layout columns correctly identified
- [ ] Sections properly grouped
- [ ] Required fields marked (if visible)
- [ ] POM paths suggested for all fields
- [ ] Dropdown fields have refGroupCode placeholders
- [ ] Styling extracted from visual analysis
```

---

## 5. TypeScript Interfaces

### 5.1 Schema Interfaces

```typescript
// Main schema structure (matches DynamoDB ui-component-catalog)
interface UIComponentSchema {
  transactionType: string;
  componentId: string;
  componentName: string;
  version: string;
  createdAt: string;
  updatedAt: string;
  componentSpecifications: ComponentSpecifications;
}

interface ComponentSpecifications {
  type: 'form' | 'wizard' | 'dashboard' | 'list';
  layout: 'grid' | 'flex' | 'vertical';
  backgroundColor?: string;
  sections: Section[];
  styling: ComponentStyling;
}

interface Section {
  sectionId: string;
  title: string;
  position: number;
  collapsed?: boolean;
  fields: Field[];
}

interface Field {
  fieldId: string;
  label: string;
  type: FieldType;
  required: boolean;
  position: number;
  gridColumn?: string;
  pomPath?: string;
  placeholder?: string;
  refGroupCode?: string;
  validation?: FieldValidation;
  styling?: FieldStyling;
}

type FieldType =
  | 'text'
  | 'email'
  | 'tel'
  | 'dropdown'
  | 'date'
  | 'checkbox'
  | 'radio'
  | 'textarea'
  | 'button'
  | 'link';

interface FieldValidation {
  pattern?: string;
  minLength?: number;
  maxLength?: number;
  min?: number;
  max?: number;
  customValidator?: string;
  errorMessage?: string;
}

interface FieldStyling {
  width?: string;
  padding?: string;
  border?: string;
  borderRadius?: string;
  backgroundColor?: string;
}

interface ComponentStyling {
  padding?: string;
  border?: string;
  borderRadius?: string;
  backgroundColor?: string;
  display?: string;
  gridTemplateColumns?: string;
  gap?: string;
}
```

### 5.2 Visual Analysis Interfaces

```typescript
interface VisualAnalysisInput {
  imageData: ImageData;
  additionalContext?: string;
  pomStructure?: object;
  transactionType?: string;
}

interface VisualAnalysisOutput {
  layout: LayoutAnalysis;
  sections: SectionAnalysis[];
  fields: FieldAnalysis[];
  styling: StylingAnalysis;
  confidence: AnalysisConfidence;
}

interface LayoutAnalysis {
  type: 'grid' | 'flex' | 'vertical';
  columns: number;
  rows: number;
  gridTemplateColumns: string;
}

interface SectionAnalysis {
  id: string;
  title: string;
  position: number;
  fieldIds: string[];
  bounds: BoundingBox;
}

interface FieldAnalysis {
  id: string;
  label: string;
  detectedType: FieldType;
  position: GridPosition;
  visualCues: string[];
  confidence: number;
  suggestedPomPath?: string;
}

interface StylingAnalysis {
  backgroundColor: string;
  borderColor: string;
  borderRadius: string;
  primaryColor: string;
  textColor: string;
}

interface AnalysisConfidence {
  overall: number;
  layout: number;
  fields: number;
  styling: number;
}

interface BoundingBox {
  top: number;
  left: number;
  width: number;
  height: number;
}

interface GridPosition {
  row: number;
  column: number;
  rowSpan?: number;
  colSpan?: number;
}
```

---

## 6. Validation Rules

### 6.1 Field Type Inference Rules

```typescript
const fieldTypeInferenceRules: InferenceRule[] = [
  {
    labelPatterns: [/email/i, /e-mail/i],
    visualCues: ['@ symbol hint'],
    inferredType: 'email',
    validation: {
      pattern: '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$',
      errorMessage: 'Please enter a valid email address'
    }
  },
  {
    labelPatterns: [/phone/i, /mobile/i, /tel/i, /contact number/i],
    visualCues: ['phone format hint', 'numeric keyboard'],
    inferredType: 'tel',
    validation: {
      pattern: '^[\\d\\s\\-\\+\\(\\)]+$',
      errorMessage: 'Please enter a valid phone number'
    }
  },
  {
    labelPatterns: [/date/i, /dob/i, /birth/i, /effective/i, /expir/i],
    visualCues: ['calendar icon', 'date format hint'],
    inferredType: 'date',
    validation: {
      errorMessage: 'Please select a valid date'
    }
  },
  {
    labelPatterns: [/country/i, /state/i, /province/i, /type/i, /status/i],
    visualCues: ['dropdown arrow', 'select hint'],
    inferredType: 'dropdown',
    refGroupCode: {
      country: 'COUNTRY',
      state: 'STATE',
      province: 'STATE',
      type: 'TYPE',
      status: 'STATUS'
    }
  },
  {
    labelPatterns: [/zip/i, /postal/i],
    visualCues: ['short input'],
    inferredType: 'text',
    validation: {
      pattern: '^[0-9]{5}(-[0-9]{4})?$',
      maxLength: 10,
      errorMessage: 'Please enter a valid ZIP code'
    }
  },
  {
    labelPatterns: [/ssn/i, /social security/i],
    visualCues: ['masked input'],
    inferredType: 'text',
    validation: {
      pattern: '^[0-9]{3}-[0-9]{2}-[0-9]{4}$',
      errorMessage: 'Please enter a valid SSN (XXX-XX-XXXX)'
    }
  }
];
```

### 6.2 POM Path Mapping Rules

```typescript
const pomPathMappingRules: PomMappingRule[] = [
  // Personal Information
  { labelPattern: /first\s*name/i, pomPath: 'applicant.personalInfo.firstName' },
  { labelPattern: /last\s*name/i, pomPath: 'applicant.personalInfo.lastName' },
  { labelPattern: /middle\s*name/i, pomPath: 'applicant.personalInfo.middleName' },
  { labelPattern: /full\s*name/i, pomPath: 'applicant.personalInfo.fullName' },
  { labelPattern: /date\s*of\s*birth|dob/i, pomPath: 'applicant.personalInfo.dateOfBirth' },
  { labelPattern: /ssn|social\s*security/i, pomPath: 'applicant.personalInfo.ssn' },
  { labelPattern: /gender/i, pomPath: 'applicant.personalInfo.gender' },

  // Contact Information
  { labelPattern: /email/i, pomPath: 'applicant.contactInfo.email' },
  { labelPattern: /phone|mobile|tel/i, pomPath: 'applicant.contactInfo.phone' },
  { labelPattern: /address|street/i, pomPath: 'applicant.contactInfo.address.street' },
  { labelPattern: /city/i, pomPath: 'applicant.contactInfo.address.city' },
  { labelPattern: /state|province/i, pomPath: 'applicant.contactInfo.address.state' },
  { labelPattern: /zip|postal/i, pomPath: 'applicant.contactInfo.address.zipCode' },
  { labelPattern: /country/i, pomPath: 'applicant.contactInfo.address.country' },

  // Policy Information
  { labelPattern: /policy\s*number/i, pomPath: 'policy.policyNumber' },
  { labelPattern: /effective\s*date/i, pomPath: 'policy.effectiveDate' },
  { labelPattern: /expir.*date/i, pomPath: 'policy.expirationDate' },
  { labelPattern: /coverage/i, pomPath: 'policy.coverageType' },
  { labelPattern: /premium/i, pomPath: 'policy.premium' },

  // Vehicle Information (Auto Insurance)
  { labelPattern: /make/i, pomPath: 'vehicle.make' },
  { labelPattern: /model/i, pomPath: 'vehicle.model' },
  { labelPattern: /year/i, pomPath: 'vehicle.year' },
  { labelPattern: /vin/i, pomPath: 'vehicle.vin' }
];
```

### 6.3 Reference Group Code Mapping

```typescript
const refGroupCodeMapping: Record<string, string> = {
  // Geographic
  'country': 'COUNTRY',
  'state': 'STATE',
  'province': 'STATE',
  'city': 'CITY',

  // Insurance
  'product': 'PRODUCT',
  'coverage': 'COVERAGE',
  'coverage type': 'COVERAGE',
  'policy type': 'POLICY_TYPE',

  // Client
  'client type': 'CLIENT_TYPE',
  'customer type': 'CLIENT_TYPE',
  'gender': 'GENDER',
  'marital status': 'MARITAL_STATUS',

  // General
  'status': 'STATUS',
  'type': 'TYPE',
  'category': 'CATEGORY'
};
```

### 6.4 AXIS Component Property Mapping

**Source:** `agents/axis-documentation.md` (78 components, 560KB)

Maps generated schema field types to exact AXIS component properties:

```typescript
// Field Type → AXIS Component Properties
const axisPropertyMapping: Record<string, AXISComponentConfig> = {

  // Text Input (axis-textbox, axisInputNumber)
  'text': {
    component: 'axis-textbox',
    properties: {
      placeholder: 'placeholder',
      required: 'required',
      disabled: 'disabled',
      maxLength: 'max_length',
      pattern: 'axis-validate'  // Uses axis-validate directive
    }
  },

  // Numeric Input (axisInputNumber directive)
  'number': {
    component: 'axis-textbox',
    directive: 'axisInputNumber',
    properties: {
      min: 'min',
      max: 'max',
      maxLength: 'max_length',
      decimal: 'decimal',
      prefix: 'prefix',        // Currency symbol
      suffix: 'suffix',        // %, k, M, B
      thousandsSeparator: 'thousands_separator',
      restrict: 'restrict'     // Prevents values beyond max
    }
  },

  // Masked Input (SSN, Phone)
  'masked': {
    component: 'axis-textbox',
    directive: 'maskedInput',
    properties: {
      mask: 'maskedInput',     // e.g., "999-99-9999" for SSN
      separator: 'separator',
      secure: 'secure'         // Shows last 4 digits only
    }
  },

  // Dropdown (axis-dropdown)
  'dropdown': {
    component: 'axis-dropdown',
    properties: {
      options: 'dataProvider',
      placeholder: 'placeholder',
      required: 'required',
      disabled: 'disabled',
      labelField: 'renderingLabel',
      searchable: 'isCombobox',
      typeahead: 'isTypeahead',
      multiSelect: 'isMultiSearchSelect',
      refGroupCode: 'refGroupCode'  // Custom property for DynamoDB lookup
    }
  },

  // Date Picker (axis-datepicker)
  'date': {
    component: 'axis-datepicker',
    properties: {
      minDate: 'minDate',
      maxDate: 'maxDate',
      format: 'dateFormat',
      required: 'required',
      disabled: 'disabled'
    }
  },

  // Checkbox (axis-checkbox)
  'checkbox': {
    component: 'axis-checkbox',
    properties: {
      checked: 'checked',
      required: 'required',
      disabled: 'disabled'
    }
  },

  // Button (axis-button)
  'button': {
    component: 'axis-button',
    properties: {
      kind: 'class',           // kind-primary, kind-secondary, etc.
      disabled: 'disabled'
    }
  },

  // Email (axis-textbox with email validation)
  'email': {
    component: 'axis-textbox',
    directive: 'axis-validate',
    properties: {
      placeholder: 'placeholder',
      required: 'required',
      pattern: 'pattern'       // Email regex
    },
    defaultValidation: {
      pattern: '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$'
    }
  },

  // Phone (axis-textbox with maskedInput)
  'tel': {
    component: 'axis-textbox',
    directive: 'maskedInput',
    properties: {
      mask: 'maskedInput',     // "(999) 999-9999"
      required: 'required'
    },
    defaultMask: '(999) 999-9999'
  }
};

interface AXISComponentConfig {
  component: string;
  directive?: string;
  properties: Record<string, string>;
  defaultValidation?: object;
  defaultMask?: string;
}
```

### 6.5 AUG (AXIS UI Generator) Integration

When generating schemas for dynamic forms using `axis-ui-generator`:

```typescript
// AUG expects this structure (from axis-documentation.md)
interface AUGStructure {
  uiStructure: object;  // JSON form structure
  uiData: object;       // Data object for field values
  refresh?: object;     // Optional refresh configuration
}

// Generated schema should be consumable by AUG
const augCompatibleSchema = {
  // Matches componentSpecifications in ui-component-catalog
  uiStructure: {
    type: 'form',
    layout: 'grid',
    sections: [
      {
        sectionId: 'clientDetails',
        title: 'Client Information',
        fields: [
          {
            fieldId: 'clientName',
            label: 'Client Name',
            type: 'text',
            component: 'axis-textbox',  // AXIS component
            required: true,
            // ... other properties
          }
        ]
      }
    ]
  },
  uiData: {
    clientName: ''  // Initial values
  }
};
```

---

## 7. Output Templates

### 7.1 JSON Schema Template

```json
{
  "transactionType": "{{transactionType}}",
  "componentId": "{{componentId}}",
  "componentName": "{{componentName}}",
  "version": "1.0",
  "createdAt": "{{createdAt}}",
  "updatedAt": "{{updatedAt}}",
  "componentSpecifications": {
    "type": "form",
    "layout": "{{layout.type}}",
    "backgroundColor": "{{styling.backgroundColor}}",
    "sections": [
      {{#each sections}}
      {
        "sectionId": "{{sectionId}}",
        "title": "{{title}}",
        "position": {{position}},
        "collapsed": false,
        "fields": [
          {{#each fields}}
          {
            "fieldId": "{{fieldId}}",
            "label": "{{label}}",
            "type": "{{type}}",
            "required": {{required}},
            "position": {{position}},
            "gridColumn": "{{gridColumn}}",
            "pomPath": "{{pomPath}}",
            {{#if placeholder}}"placeholder": "{{placeholder}}",{{/if}}
            {{#if refGroupCode}}"refGroupCode": "{{refGroupCode}}",{{/if}}
            "validation": {
              {{#if validation.pattern}}"pattern": "{{validation.pattern}}",{{/if}}
              {{#if validation.minLength}}"minLength": {{validation.minLength}},{{/if}}
              {{#if validation.maxLength}}"maxLength": {{validation.maxLength}},{{/if}}
              {{#if validation.errorMessage}}"errorMessage": "{{validation.errorMessage}}"{{/if}}
            },
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          }{{#unless @last}},{{/unless}}
          {{/each}}
        ]
      }{{#unless @last}},{{/unless}}
      {{/each}}
    ],
    "styling": {
      "padding": "20px",
      "border": "1px solid #CCCCCC",
      "borderRadius": "8px",
      "backgroundColor": "{{styling.backgroundColor}}",
      "display": "grid",
      "gridTemplateColumns": "{{layout.gridTemplateColumns}}",
      "gap": "16px"
    }
  }
}
```

---

## 8. Error Handling

### 8.1 Error Scenarios

| Scenario | Detection | Response |
|----------|-----------|----------|
| No image attached | Request mentions mockup but no image | "Please attach the UI mockup image to generate the JSON schema." |
| Image too small/unclear | Low confidence in analysis | "The image quality is low. Please provide a clearer mockup for accurate schema generation." |
| No fields detected | Empty fields array | "I couldn't detect any form fields in the mockup. Please ensure the image shows a form with visible input fields." |
| Ambiguous field types | Multiple possible types | Include in plan confirmation: "I detected {field} but couldn't determine if it's a {type1} or {type2}. Please clarify." |
| Missing section headers | Fields without clear grouping | "Fields detected but no clear sections. Shall I group all fields into a single section?" |

### 8.2 Fallback Behaviors

```typescript
const fallbackBehaviors = {
  unknownFieldType: 'text',  // Default to text input
  unknownLayout: 'grid',     // Default to grid layout
  unknownColumns: 2,         // Default to 2 columns
  unknownRequired: false,    // Default to optional
  unknownStyling: {
    backgroundColor: '#FFFFFF',
    borderColor: '#CCCCCC',
    borderRadius: '4px'
  }
};
```

---

## 9. Testing Specifications

### 9.1 Test Cases

| Test ID | Description | Input | Expected Output |
|---------|-------------|-------|-----------------|
| JSG-001 | Simple form with text fields | 3-field form mockup | Schema with 3 text fields |
| JSG-002 | Form with dropdown | Form with dropdown | Schema with refGroupCode |
| JSG-003 | Multi-section form | Form with 2 sections | Schema with 2 sections |
| JSG-004 | Grid layout detection | 3-column form | gridTemplateColumns: "1fr 1fr 1fr" |
| JSG-005 | Required field detection | Form with asterisks | required: true for marked fields |
| JSG-006 | Email field inference | Field labeled "Email" | type: "email" with pattern |
| JSG-007 | POM path suggestion | Field labeled "First Name" | pomPath: "applicant.personalInfo.firstName" |

### 9.2 Acceptance Criteria Validation

```markdown
=== TEST: JSON Schema Generation from Mockup ===
DESCRIPTION: Validates CR-001 JSON schema generation capability

--- ACCEPTANCE CRITERIA ---
AC12: Visual to JSON Schema Generation
- Analyzes visual elements and identifies form fields
- Maps elements to AXIS component types
- Generates DynamoDB-compatible JSON schema
- Includes pomPath placeholders
- Outputs YAML version for review

--- PROMPT ---
Generate JSON schema from this mockup [attach client-info-mockup.png]

The form should be for "Client Information" with transaction type "NB".

--- EXPECTED KEYWORDS ---
componentSpecifications, sections, fields, fieldId, type, pomPath,
refGroupCode, validation, styling, gridTemplateColumns, ui-component-catalog

--- END TEST ---
```

---

## Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Nov 25, 2025 | Jagan Mohan | Initial LLD for axis-tools CR-001 (JSON Schema Generator). Includes: component overview, workflow implementation, visual analysis specifications, output templates, TypeScript interfaces, validation rules, POM path mapping, error handling, testing specifications. |
| 1.1 | Nov 25, 2025 | Jagan Mohan | Added Section 3.1: dynamic-ui-generator agent specification. Generates Angular code using axis-ui-generator component with DynamoDB integration. CR-001 JSON Schema from images ON HOLD pending AUG JSON structure documentation. |
| 1.2 | Nov 27, 2025 | AI COE Team | Updated axis-ui-generator component attributes: (1) Corrected recognized attributes to `[uiStructure]`, `[uiData]`, `(uiEmitUpdate)`, `(uiEmit)` (removed incorrect `refresh` attribute). (2) Added contextual naming pattern requirement: `ui{Feature}Structure`, `ui{Feature}Data`, `{feature}InfoEmitUpdate`. (3) Updated code template with proper patterns and comments. |
| 1.3 | 2026-01-09 | AI COE Team | Version bump for release v1.3.0 |
| 1.4 | 2026-01-21 | AI COE Team | Version bump for unified release v1.4.0 |

---

**Document Owner:** AI COE Team & S3 Team

**Document Type:** Low-Level Design (LLD)

**Consumer:** axis-tools plugin implementation

**Status:** Draft

**Last Updated:** November 25, 2025
