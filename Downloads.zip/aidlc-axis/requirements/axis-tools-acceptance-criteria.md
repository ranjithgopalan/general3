# Acceptance Criteria: AIDLC-axis (Axis Tools)

- **Document Version:** 1.4
- **Date:** 2026-01-19
- **Author:** AI COE Team
- **Plugin:** AIDLC-axis
- **Status:** Released

---

## 1. Overview

This document defines the acceptance criteria for the AIDLC-axis plugin, which generates Angular UI components using the Axis framework (v18.0.32).

---

## 2. Core Acceptance Criteria

### AC-01: UI Generation from Descriptions
**As a** developer,
**I want** to provide a natural language description of a UI component,
**So that** I can generate production-ready Angular code using Axis components.

**Acceptance:**
- [ ] Given a natural language description via `/axis-ui-generator`, when the plugin executes, then it must generate production-ready Angular code using appropriate Axis components with complete TypeScript, HTML, and proper imports.

---

### AC-02: UI Generation from Mockups
**As a** developer,
**I want** to provide an image of a UI mockup or screenshot,
**So that** I can generate matching Angular code.

**Acceptance:**
- [ ] Given an image of a UI mockup or screenshot, when I use `/axis-ui-generator` with the image, then the plugin must analyze the visual design and generate matching Angular code using Axis components that replicate the layout and functionality.

---

### AC-03: Code Validation Against Axis Guidelines
**As a** developer,
**I want** to validate my existing Angular code against Axis framework guidelines,
**So that** I can identify and fix violations.

**Acceptance:**
- [ ] Given existing Angular code using Axis components, when I run `/axis-code-validator`, then the plugin must scan the code and identify violations of Axis framework guidelines including incorrect imports, invalid properties, and missing accessibility attributes.

---

### AC-04: Component Documentation Access
**As a** developer,
**I want** to get accurate information about Axis components,
**So that** I can use them correctly.

**Acceptance:**
- [ ] Given a request about a specific Axis component, when the plugin searches documentation, then it must retrieve accurate information about properties, events, methods, and usage examples from the bundled Axis component library (v18.0.32).

---

### AC-05: Accessibility Compliance
**As a** developer,
**I want** generated UI code to include proper accessibility attributes,
**So that** the application is accessible to all users.

**Acceptance:**
- [ ] Given generated UI code, when the plugin creates Axis components, then it should include proper ARIA attributes, keyboard navigation support, and accessibility best practices by default.

---

### AC-06: Form Validation Patterns
**As a** developer,
**I want** generated forms to include proper validation patterns,
**So that** user input is validated correctly.

**Acceptance:**
- [ ] Given a UI that includes form inputs, when the plugin generates code, then it should implement proper validation patterns using Axis form controls with error messages and validation feedback.

---

### AC-07: Chart and Data Visualization
**As a** developer,
**I want** to generate appropriate data visualizations,
**So that** data is displayed effectively.

**Acceptance:**
- [ ] Given requirements for data visualization, when the plugin generates code, then it should recommend and implement appropriate Axis chart types (from the 18 available chart components) with proper data binding and configuration.

---

### AC-08: Navigation Management
**As a** developer,
**I want** navigation to be updated when new features are added,
**So that** users can access new functionality.

**Acceptance:**
- [ ] Given a new feature or workflow, when UI components are generated, then the plugin should identify and generate necessary navigation updates for left or top navigation menus to ensure the new feature is accessible.

---

### AC-09: DynamoDB-Driven UI Generation
**As a** developer,
**I want** UI components to be driven by JSON configurations,
**So that** UI can be dynamically rendered.

**Acceptance:**
- [ ] Given UI generation requirements, when the plugin creates components, then it should generate UI configurations driven by JSON structures stored in DynamoDB, enabling dynamic UI rendering based on database configuration.

---

### AC-10: POM Field Mapping
**As a** developer,
**I want** form fields to map correctly to POM data structures,
**So that** data binding works correctly.

**Acceptance:**
- [ ] Given form fields or data displays, when the plugin generates UI components, then it should ensure all fields map correctly to the corresponding fields in the Policy Object Model (POM) data structure for proper data binding and integration.

---

### AC-11: Client-Side Validation
**As a** developer,
**I want** comprehensive client-side validations,
**So that** data integrity is ensured before submission.

**Acceptance:**
- [ ] Given any form or input components, when the plugin generates code, then it should implement comprehensive client-side field validations and cross-field validations to ensure data integrity before submission.

---

### AC-12: AXIS UI Generator Attribute Compliance
**As a** developer,
**I want** generated code to use only recognized AUG attributes,
**So that** the axis-ui-generator component works correctly.

**Acceptance:**
- [ ] Given code using the axis-ui-generator component, when the plugin generates or validates Angular code, then it must use ONLY the recognized attributes: `[uiStructure]` (input), `[uiData]` (input), `(uiEmitUpdate)` (output), and `(uiEmit)` (output), with proper contextual naming like `ui{Feature}Structure`, `ui{Feature}Data`, and `{feature}InfoEmitUpdate()` event handlers.

---

### AC-13: Nested/Repeated Component Structure Handling
**As a** developer,
**I want** the plugin to correctly handle nested or repeated component structures,
**So that** components with arrays, accordions, or repeated sections are generated following the Master TDD pattern.

**Acceptance:**
- [ ] Given a UI requirement with nested or repeated structures (e.g., Additional Insureds, Risk Locations, arrays of objects), when the plugin detects such patterns, then it must FIRST check Feature TDD Section 6.x for component structure guidance.
- [ ] Given Feature TDD Section 6.x contains patterns indicating nested JSON (e.g., "array of objects", "componentConfig", "accordion with Add/Copy/Delete/Save", "action buttons in JSON"), when generating code, then the plugin must generate a single axis-ui-generator component with deeply nested componentConfig JSON containing arrays of objects.
- [ ] Given Feature TDD Section 6.x is unclear or not provided, when nested structures are detected, then the plugin must ask the user: "How should nested/repeated components be structured?" with options for (1) Single axis-ui-generator with nested JSON (Recommended), or (2) Separate Angular components for each section.
- [ ] Given single axis-ui-generator approach is selected, when generating code, then action buttons (Add, Copy, Delete, Save, Reset) must be part of the componentConfig JSON structure, NOT separate Angular components.
- [ ] Given single axis-ui-generator approach is selected, when generating code, then the plugin must NOT generate additional axis components (axis-icon, axis-button) outside of the axis-ui-generator component for nested structures.
- [ ] Given the requirement mentions global action buttons (Save, Next), when generating code, then the plugin must document that these are handled by Global Footer and should NOT be generated as part of the component.
- [ ] Given no explicit preference and no TDD guidance, when generating code with nested structures, then the plugin must default to single axis-ui-generator with nested arrays (Master TDD pattern).

---

### AC-14: Shared Component Discovery and Reuse
**As a** developer,
**I want** the plugin to discover and prioritize existing shared components before generating new code,
**So that** I maintain consistency across the application and reduce code duplication.

**Acceptance:**
- [ ] Given a UI generation request, when the plugin analyzes requirements, then it must FIRST check Feature TDD Section 6.4.2 for shared component specifications (e.g., common-modal, common-grid references).
- [ ] Given Feature TDD Section 6.4.2 specifies shared components with import statements or service references, when generating code, then the plugin must use the specified shared components exactly as documented in the TDD.
- [ ] Given Feature TDD Section 6.4.2 is unclear or not provided, when generating code, then the plugin must search the codebase for existing shared components using patterns: `_shared/components/*`, `common-*`, `shared-*`.
- [ ] Given shared components are discovered in the codebase, when functionality matches >80% of requirements, then the plugin must ask the user: "I found existing shared components. Which should I use for this functionality?" with options for (1) Use shared components (Recommended), (2) Generate new components, or (3) Let me specify custom components.
- [ ] Given the user selects to use shared components, when generating code, then the plugin must import from `@app/_shared/` path and configure the shared components without generating duplicate implementations.
- [ ] Given common-modal and common-grid are specified for search functionality (e.g., "openClientSearchModal"), when generating code, then the plugin must use CommonModalService and CommonGridComponent from _shared folder, NOT generate new modal or grid components.
- [ ] Given no suitable shared component exists (< 80% functionality match) or user explicitly requests new components, when generating code, then the plugin must generate new feature-specific components.
- [ ] Given code generation is complete, when reporting results, then the plugin must document which shared components were reused (list) and which new components were generated (list).

---

## 3. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Nov 2025 | AI COE | Initial acceptance criteria |
| 1.2 | Dec 2025 | AI COE | Synchronizing version numbers to line up with plugin bundle |
| 1.3 | Jan 2026 | AI COE | Added AC-13: Nested/Repeated Component Structure Handling |
| 1.4 | Jan 2026 | AI COE | Added AC-14: Shared Component Discovery and Reuse |
