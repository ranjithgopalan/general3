# Business Requirements Document: AXIS Angular Code Generation Plugin

**Feature:** Claude Code Marketplace Plugin for AXIS Framework Development

**User Story ID:** US-011

**Status:** Implemented as **axis-tools** plugin

**Document Type:** Business Requirements Document (BRD)

**Version:** 1.2

---

## Executive Summary

This document defines the business requirements for a Claude Code marketplace plugin that specializes in Angular code generation and compliance validation for the AXIS UI framework. The plugin enables frontend developers to generate production-ready, AXIS-compliant Angular components 10x faster through AI-assisted **specification-driven code generation** from written specifications or visual mockups.

### Specification-Driven Development Approach

The plugin follows **Specification-Driven Development (SDD)** principles:
- **Specifications as Source of Truth:** Code is generated from specifications (requirements, UI-TDD, design documents, mockups), not casual conversation
- **Implements, Doesn't Assume:** Agent implements what specifications explicitly state, doesn't make assumptions
- **Traceability:** Generated code is traceable back to source specifications

**Input Types (All are Specifications):**
- **Written Specifications:** Requirements documents, UI-TDD, feature descriptions (structured requirements, even if in natural language)
- **Visual Specifications:** UI mockups, screenshots, Figma designs (visual contracts for layout and structure)
- **Data Specifications:** POM structures, TypeScript interfaces (data contracts)
- **Configuration Specifications:** DynamoDB JSON schemas (dynamic UI contracts)

**Note:** This is NOT "vibe-coding" or free-form AI conversation. All inputs represent structured specifications that the agent implements.

---

## Business Objectives

### Primary Objective

**Enable frontend developers to generate production-ready, AXIS-compliant Angular components from natural language descriptions or UI mockups, reducing development time by 80% while ensuring consistent quality and framework compliance.**

### Success Metrics

| Metric | Measurement |
|--------|-------------|
| **Component Development Time** | Time to create production-ready component |
| **AXIS Compliance Rate** | Code review findings |
| **Accessibility Coverage** | ARIA attributes, keyboard nav implemented |
| **Onboarding Time** | Time to productive AXIS development |
| **Code Rework Rate** | Percentage of components requiring refactoring |

---

## Business Requirements

### BR1: Specification-Driven Code Generation

**Requirement:** Developer provides specifications for a UI component (written requirements, UI-TDD, design documents, or structured descriptions), and the plugin generates complete Angular code (TypeScript, HTML, SCSS) that implements the specification using appropriate AXIS components.

**Business Value:** Reduces development time by 80%, eliminates boilerplate coding, ensures code matches specifications.

---

### BR2: Visual Specification (Mockup) to Code Generation

**Requirement:** Developer uploads a UI mockup/screenshot (visual specification), and the plugin analyzes the visual design and generates matching Angular code using AXIS components that implements the visual specification.

**Business Value:** Bridges design-to-development gap, accelerates implementation of design specs.

---

### BR3: AXIS Framework Compliance

**Requirement:** All generated code must use only AXIS components (77 components across 8 categories) and follow AXIS framework standards (13 mandatory conventions).

**Business Value:** Ensures consistency, reduces technical debt, passes code reviews.

---

### BR4: Code Validation and Compliance Checking

**Requirement:** Plugin scans existing Angular code and identifies violations of AXIS framework guidelines (incorrect imports, invalid properties, missing accessibility attributes).

**Business Value:** Reduces manual code review time, catches compliance issues early.

---

### BR5: Accessibility by Default

**Requirement:** All generated UI code includes proper ARIA attributes, keyboard navigation support, and accessibility best practices without developer needing to specify them.

**Business Value:** Ensures WCAG 2.1 AA compliance, reduces accessibility defects.

---

### BR6: Form Validation Patterns

**Requirement:** When generating forms, plugin implements comprehensive client-side validation (field-level and cross-field) with proper error messaging.

**Business Value:** Reduces backend validation errors, improves user experience.

---

### BR7: Policy Object Model (POM) Integration

**Requirement:** For insurance domain forms, plugin maps form fields to POM data structure paths automatically when POM structure is provided.

**Business Value:** Ensures data binding consistency with backend APIs, reduces integration defects.

---

### BR8: Dynamic UI Generation (DynamoDB-Driven)

**Requirement:** When explicitly specified in requirements, plugin generates Angular code that loads form configurations from DynamoDB JSON, enabling dynamic form rendering based on database configuration.

**Business Value:** Enables A/B testing, personalization, form changes without code deployment.

---

### BR9: Component Documentation Access

**Requirement:** Developers can query the plugin for documentation on any of the 77 AXIS components (inputs, outputs, methods, events, usage examples).

**Business Value:** Reduces time searching documentation, accelerates learning curve.

---

### BR10: Chart and Data Visualization

**Requirement:** Plugin recommends and implements appropriate chart types from 18 available AXIS chart components based on data visualization requirements.

**Business Value:** Simplifies dashboard development, ensures consistent visualization patterns.

---

## Scope Definition

### In Scope

**Business Capabilities:**
1. Specification-driven Angular code generation (from written specifications)
2. Visual specification to code generation (from UI mockups/screenshots)
3. AXIS framework compliance enforcement
4. Code validation and compliance checking
5. Accessibility standards enforcement
6. Form validation pattern generation
7. POM field mapping (when POM provided)
8. Dynamic UI generation (when JSON schema provided)
9. Component documentation access

**Technical Scope:**
- Angular 18 with AXIS framework
- Component-level code generation (TypeScript, HTML, SCSS)
- AXIS component library (77 components)
- Client-side validation patterns
- Accessibility compliance (WCAG 2.1 AA)

---

### Out of Scope

**Business Capabilities NOT Included:**
1. Document parsing (BRD/PRD/TechArch/UI-TDD files)
2. Full application generation (architecture, folder structure)
3. API service generation from OpenAPI/Swagger specs
4. Unit test generation
5. E2E test generation
6. State management scaffolding (NgRx/Signals)
7. Routing and route guards generation (unless explicitly requested)
8. JSON schema generation (Requirements to DynamoDB JSON)
9. Traceability matrix generation
10. Deployment configuration (Docker, K8s, CI/CD)
11. Build and compilation execution
12. Custom AXIS component creation

**Why Out of Scope:**
- Focus on UI component generation (core value)
- Separate concerns require separate tools
- Maintains plugin simplicity and focused purpose

---

### Future Scope

**Potential Future Enhancements:**
1. Document parsing integration (BRD/PRD/TechArch/UI-TDD)
2. Service layer generation from API specifications
3. Routing and navigation generation
4. Unit test generation with 80%+ coverage
5. State management scaffolding
6. Traceability matrix generation
7. JSON schema generation (separate tool proposed)
8. Proactive navigation updates

---

## Inputs and Outputs

### Key Inputs Required

| Input Type | Format | Required | Description |
|------------|--------|----------|-------------|
| **Written Specifications** | Natural language, Markdown | Yes | Component requirements, feature descriptions, UI-TDD specifications |
| **Visual Specifications** | PNG, JPG, SVG, Figma exports | Optional | UI mockups, screenshots, design files |
| **Existing Code** | TypeScript, HTML, SCSS | Optional | Angular code for validation and compliance checking |
| **POM Structure** | TypeScript interface, JSON | Optional | Policy Object Model for field mapping |
| **DynamoDB JSON Schema** | JSON | Optional | Form configuration for dynamic UI generation |
| **Component Queries** | Natural language | Optional | Questions about AXIS component documentation |
| **Validation Rules** | Natural language, structured text | Optional | Field validation requirements, business rules |

**Invocation Method:** `/axis-tools:axis [request description]`

---

### Key Outputs Produced

| Output | Format | Description |
|--------|--------|-------------|
| **Angular Components** | `.ts`, `.html`, `.scss` | Complete standalone components with TypeScript logic, HTML templates, and styles |
| **Form Components** | `.ts`, `.html` | Reactive forms or dynamic forms (AUG-based) with validation |
| **Validation Reports** | Markdown, inline feedback | Code compliance analysis with violation details and fix recommendations |
| **Component Documentation** | Markdown, inline responses | Usage examples, inputs/outputs, methods, events for AXIS components |
| **Dynamic Form Services** | `.ts` | DynamoDB service with caching for JSON configuration retrieval |
| **Field Mappers** | TypeScript classes | JSON-to-AXIS component mapping utilities |
| **Import Statements** | TypeScript | Proper AXIS component and module imports |
| **Accessibility Attributes** | HTML attributes | ARIA labels, roles, keyboard navigation support |

**Output Location:** Generated code is provided inline for developer review and integration

---

## Dependencies

### Technical Dependencies

| Dependency | Version | Purpose |
|------------|---------|---------|
| **Angular CLI** | v18+ | Angular development |
| **AXIS Framework** | v18.0.32 | UI component library |
| **AXIS CLI** | v18+ | AXIS-specific commands |
| **Node.js** | v20+ | Runtime environment |
| **Claude API** | Latest | AI code generation |

### Knowledge Dependencies

| Knowledge Area | Source | Purpose |
|---------------|--------|---------|
| **AXIS Components** | 77 components documented | Component selection and usage |
| **AXIS Conventions** | 13 mandatory standards | Code compliance |
| **Angular 18 Patterns** | Best practices | Modern Angular development |
| **Insurance Domain** | POM structure | Domain-specific field mapping |

---

## Constraints

### Business Constraints

1. **AXIS Framework Only:** Cannot use other UI frameworks (Material, Bootstrap)
2. **Manual Review Required:** Generated code requires developer review before production
3. **Internet Connection:** Requires Claude API access (cloud-based)
4. **AXIS License:** Users must have valid AXIS framework license

### Technical Constraints

1. **Input Driven:** Agent follows specifications, doesn't assume features
2. **Component Scope:** Generates individual components, not full applications
3. **No Execution:** Generates code but doesn't compile or test it
4. **JSON Schema Required:** Dynamic UI generation requires pre-existing JSON schema

---

## Success Criteria

### Acceptance Criteria

Plugin is considered successful when:

1. Developer can generate production-ready AXIS component in <1 hour
2. Generated code passes AXIS compliance checks 95%+
3. All generated code includes accessibility attributes 90%+
4. Code validation identifies framework violations accurately (precision >90%)
5. New developers productive with AXIS in 1 week
6. Code rework rate <10%

### Definition of Done

For each business requirement (BR1-BR10):
- [ ] Capability implemented and tested
- [ ] Documentation completed
- [ ] Acceptance criteria validated
- [ ] User feedback positive (>80% satisfaction)

---

## Change Requests

### CR-001: Visual Specification to AXIS-Compliant JSON Schema Generation

**Change Request ID:** CR-001

**Priority:** High

**Status:** Proposed

**Requested By:** AI COE Team & S3 Team

**Date:** November 24, 2025

---

#### Business Need

Currently, the plugin can generate Angular code from UI mockups/screenshots (BR2) through direct interpretation. However, for dynamic UI generation (BR8), developers must manually create DynamoDB JSON schemas that map visual elements to AXIS components. This manual process is error-prone and time-consuming.

**Gap:** Missing capability to automatically generate AXIS-compliant JSON schemas from visual specifications (mockups/screenshots/images) that can be stored in DynamoDB for dynamic UI rendering.

---

#### Proposed Change

Add a new business requirement (BR11) to generate AXIS-compliant JSON schemas from visual specifications.

**BR11: Visual Specification to JSON Schema Generation**

**Requirement:** Developer provides a UI mockup/screenshot/image, and the plugin analyzes the visual design and generates an AXIS-compliant JSON schema that:
- Maps visual elements to appropriate AXIS component types (from 77 available components)
- Defines form structure (sections, field ordering, layout)
- Specifies field properties (fieldId, fieldType, label, placeholder, required)
- Includes validation rules inferred from visual cues and common patterns
- Provides POM path placeholders for data binding
- Generates dropdown configurations for select elements
- Ensures JSON schema is ready for DynamoDB storage

**Priority:** P1 (High)

---

#### Workflow Integration

**Current Workflow (BR2):**
```
UI Mockup/Screenshot → axis-tools → Angular Code (static components)
```

**Enhanced Workflow (BR11):**
```
UI Mockup/Screenshot → axis-tools → JSON Schema → DynamoDB
                              ↓
                         Angular Code (dynamic rendering via BR8)
```

**Combined Capability:**
- **Option 1 (Static):** Generate Angular code directly from mockup (BR2 - existing)
- **Option 2 (Dynamic):** Generate JSON schema from mockup (BR11 - new) → Store in DynamoDB → Generate dynamic form renderer (BR8 - existing)

---

#### Inputs and Outputs (CR-001)

**Key Inputs Required:**

| Input Type | Format | Required | Description |
|------------|--------|----------|-------------|
| **UI Mockup/Screenshot** | PNG, JPG, SVG, PDF | Yes | Visual representation of form/UI with visible fields and layout |
| **Design Specifications** | Figma exports, Sketch files | Optional | High-fidelity design files with annotations |
| **POM Structure** | TypeScript interface, JSON | Optional | Policy Object Model for automatic field path mapping |
| **Validation Context** | Text annotations, requirements | Optional | Business rules and validation requirements for fields |
| **Form Metadata** | Text description | Optional | Form name, purpose, target sections/steps |

**Invocation Method:** `/axis-tools:axis Generate JSON schema from this mockup [attach image]`

**Key Outputs Produced:**

| Output | Format | Description |
|--------|--------|-------------|
| **DynamoDB JSON Schema** | `.json` | Complete AXIS-compliant form configuration ready for DynamoDB storage |
| **YAML Version** | `.yaml` | Human-readable version of JSON schema for review and editing |
| **Field Catalog** | Markdown table | Summary of all identified fields with types and properties |
| **Component Mapping Report** | Markdown | Visual element to AXIS component mapping decisions |
| **POM Path Suggestions** | Inline comments in JSON | Placeholder pomPath values requiring developer input |
| **Validation Rule Summary** | Markdown | List of inferred validation rules and business logic |

**DynamoDB Schema Reference:**

The generated JSON schema MUST be compatible with the `ui-component-catalog` DynamoDB table structure as defined in the enterprise DynamoDB specification document.

**Target Table:** `ui-component-catalog`

| Attribute | Type | Description |
|-----------|------|-------------|
| `transactionType` | String | Partition Key - Transaction type (e.g., "NB", "ENDORSEMENT", or empty for common components) |
| `componentId` | String | Sort Key - Unique component identifier (e.g., "clientInformation") |
| `componentName` | String | Human-readable component name |
| `componentSpecifications` | Map | Complete component configuration in JSON format |

**Generated JSON Schema Structure (matching DynamoDB `componentSpecifications`):**

```json
{
  "transactionType": "NB",
  "componentId": "clientInformation",
  "componentName": "Client Information",
  "componentSpecifications": {
    "type": "form",
    "layout": "grid",
    "backgroundColor": "#FFFFFF",
    "sections": [
      {
        "sectionId": "clientDetails",
        "title": "Client Information",
        "position": 1,
        "fields": [
          {
            "fieldId": "clientName",
            "label": "Client Name",
            "type": "text",
            "required": true,
            "position": 1,
            "gridColumn": "1 / 2",
            "pomPath": "applicant.personalInfo.clientName",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "country",
            "label": "Country",
            "type": "dropdown",
            "required": false,
            "position": 4,
            "gridColumn": "1 / 2",
            "pomPath": "applicant.contactInfo.address.country",
            "refGroupCode": "COUNTRY",
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          },
          {
            "fieldId": "email",
            "label": "Email",
            "type": "email",
            "required": false,
            "position": 8,
            "gridColumn": "2 / 3",
            "pomPath": "applicant.contactInfo.email",
            "validation": {
              "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
            },
            "styling": {
              "width": "100%",
              "padding": "8px",
              "border": "1px solid #CCCCCC",
              "borderRadius": "4px"
            }
          }
        ]
      }
    ],
    "styling": {
      "padding": "20px",
      "border": "1px solid #CCCCCC",
      "borderRadius": "8px",
      "backgroundColor": "#FFFFFF",
      "display": "grid",
      "gridTemplateColumns": "1fr 1fr 1fr",
      "gap": "16px"
    }
  }
}
```

**Field Type to AXIS Component Mapping:**

| Visual Element | Field Type | AXIS Component |
|---------------|------------|----------------|
| Text input | `text` | `axis-textbox` |
| Email input | `email` | `axis-textbox` with email validation |
| Phone input | `tel` | `axis-textbox` with phone mask |
| Dropdown | `dropdown` | `axis-dropdown` |
| Date picker | `date` | `axis-datepicker` |
| Checkbox | `checkbox` | `axis-checkbox` |
| Button | `button` | `axis-button` |
| Link | `link` | HTML anchor with AXIS styling |

**Reference Data Integration:**

For dropdown fields, the schema includes `refGroupCode` to link to the `booking-reference-lookup` table:
- `refGroupCode: "COUNTRY"` → Loads country list from reference table
- `refGroupCode: "PRODUCT"` → Loads product types from reference table
- `refGroupCode: "CLIENT_TYPE"` → Loads client types from reference table

---

#### Acceptance Criteria

**AC12: Visual to JSON Schema Generation**

**Given** a UI mockup/screenshot/image showing form fields and layout

**When** developer invokes `/axis-tools:axis Generate JSON schema from this mockup [attach image]`

**Then** the plugin must:
1. Analyze visual elements and identify form fields, buttons, dropdowns, checkboxes, etc.
2. Map each visual element to appropriate AXIS component type (axis-textbox, axis-dropdown, axis-button, etc.)
3. Generate complete JSON schema with:
   - formId, formTitle, version
   - sections array with field definitions
   - fieldId, fieldType, label, placeholder, required for each field
   - validation rules (minLength, maxLength, pattern) inferred from visual cues
   - pomPath placeholders (e.g., "applicant.personalInfo.firstName")
   - dropdown options configuration
4. Output valid JSON schema compatible with DynamoDB structure
5. Output YAML version for human review
6. Ensure schema can be consumed by BR8 (Dynamic UI Generation)

**And** the JSON schema must be AXIS-compliant:
- All fieldType values map to valid AXIS components
- Field properties align with AXIS component inputs
- Layout structure matches AXIS grid system
- Accessibility attributes are included by default

---

#### Dependencies

**Prerequisites:**
- BR2 (Visual Specification to Code Generation) - existing capability to analyze mockups
- BR8 (Dynamic UI Generation) - existing capability to render from JSON schema
- AXIS component library knowledge (77 components)

**New Capabilities Required:**
- Visual element to AXIS component type mapping engine
- JSON schema template generation
- AXIS-compliant field property inference
- Validation rule extraction from visual context

---

#### Impact Assessment

**Affected Components:**
- axis-tools plugin (new capability added)
- axis-development-guide (documentation update)
- acceptance-criteria.md (new AC12 added)

**Benefits:**
- Completes the dynamic UI generation workflow
- Bridges gap between design and implementation
- Reduces manual JSON creation effort
- Improves accuracy of AXIS component mapping

**Risks:**
- Visual analysis may not capture all validation rules (mitigation: provide defaults, allow manual refinement)
- POM paths cannot be inferred from visuals alone (mitigation: generate placeholders, require developer input)
- Complex layouts may be challenging to map (mitigation: support iterative refinement)

---

### Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Nov 2025 | AI COE | Initial release |
| 1.1 | Nov 2025 | AI COE | Added CR-001 Visual to JSON Schema Generation, inputs/outputs sections, DynamoDB schema reference |
| 1.2 | Dec 2025 | AI COE | Bump version for plugin bundle release v1.2 |
| 1.3 | 2026-01-09 | AI COE Team | Version bump for release v1.3.0 |
| 1.4 | 2026-01-21 | AI COE Team | Version bump for unified release v1.4.0 |

---

**Document Owner:** AI COE Team
**Document Type:** Business Requirements Document
**Status:** Released
**Last Updated:** December 2025