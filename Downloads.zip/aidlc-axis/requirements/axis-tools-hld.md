﻿# High-Level Design: AXIS Angular Code Generation Plugin

**Feature:** Claude Code Plugin for AXIS Framework Development

**User Story ID:** US-011

**Status:** Implemented as **axis-tools** plugin

**Document Type:** High-Level Design (HLD)

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Component Design](#component-design)
3. [Plugin Structure](#plugin-structure)
4. [Agent Design](#agent-design)
5. [Skills Design](#skills-design)
6. [Commands Design](#commands-design)
7. [Data Flow](#data-flow)
8. [Integration Points](#integration-points)
9. [Error Handling Strategy](#error-handling-strategy)
10. [Security & Compliance](#security--compliance)
11. [Performance & Optimization](#performance--optimization)
12. [Testing Strategy](#testing-strategy)
13. [Deployment & Configuration](#deployment--configuration)
14. [DynamoDB Data Model for Dynamic UI](#dynamodb-data-model-for-dynamic-ui)
15. [JSON Schema Generator Architecture (CR-001)](#json-schema-generator-architecture-cr-001)
16. [Appendix](#appendix)

---

## Architecture Overview

### System Context

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Business Layer                                     │
│  ┌──────────────┐  ┌───────────────┐  ┌──────────────┐  ┌────────────────┐ │
│  │ Product Owner│  │ Scrum Master  │  │Tech Architect│  │ Design Agent   │ │
│  │  (Features)  │  │(User Stories) │  │(ADRs, Stack) │  │   (UI-TDD)     │ │
│  └──────┬───────┘  └───────┬───────┘  └──────┬───────┘  └────────┬───────┘ │
│         │                  │                  │                    │         │
│         └──────────────────┴──────────────────┴────────────────────┘         │
└─────────────────────────────────────────────────┬───────────────────────────┘
                                                  │
                                                  │ UI-TDD.md, Mockups, Requirements
                                                  │ POM Structure, JSON Schemas
                                                  │ Component Queries
                                                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        Axis Tools Plugin                                     │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                    Unified /axis Command                               │  │
│  │           (Intelligent Router for All Capabilities)                    │  │
│  └───────────────────────────┬───────────────────────────────────────────┘  │
│                               │                                              │
│         ┌────────────────┬────┴──────┬──────────────┬─────────────┐         │
│         │                │           │              │             │         │
│         ▼                ▼           ▼              ▼             ▼         │
│  ┌─────────────┐  ┌─────────────┐  ┌──────────┐  ┌──────────┐  ┌────────┐ │
│  │    UI       │  │    Code     │  │Component │  │  Dev     │  │ Skills │ │
│  │ Generator   │  │ Validator   │  │   Docs   │  │  Guide   │  │        │ │
│  │  (Sonnet)   │  │  (Haiku)    │  │  (Haiku) │  │(Reference)│  │(Domain)│ │
│  └─────────────┘  └─────────────┘  └──────────┘  └──────────┘  └────────┘ │
│                                                                              │
│  Features:                                                                   │
│  - Specification-driven code generation (written specs, UI-TDD)             │
│  - Visual specification to code (mockups, screenshots)                      │
│  - AXIS framework compliance enforcement (77 components, 13 conventions)    │
│  - Code validation and compliance checking                                  │
│  - Accessibility standards enforcement (WCAG 2.1 AA)                        │
│  - Component documentation access (16K+ lines)                              │
│  - POM field mapping (insurance domain)                                     │
│  - Dynamic UI generation (DynamoDB-driven)                                  │
└─────────────────────────────────────────────────┬───────────────────────────┘
                                                  │
                                                  │ Angular Components (TS, HTML, SCSS)
                                                  │ Validation Reports
                                                  │ Component Documentation
                                                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      Implementation Layer                                    │
│  ┌──────────────┐  ┌────────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │Code Validator│  │Security Reviewer│  │Test Specialist│  │   DevOps     │ │
│  │(Quality Check)│  │(Security Audit) │  │(Integration)  │  │(Deployment)  │ │
│  └──────────────┘  └────────────────┘  └──────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

### High-Level Architecture

The axis-tools plugin follows a **unified command routing architecture** with specialized agents for focused capabilities:

```
┌─────────────────────────────────────────────────────────────────────┐
│                      axis-tools Plugin                               │
│                                                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                   Unified /axis Command                       │  │
│  │  - Natural language request analysis                          │  │
│  │  - Task type classification (UI, validation, docs)            │  │
│  │  - Intelligent routing to specialized agents                  │  │
│  └────────────┬─────────────────────────────────────────────────┘  │
│               │                                                      │
│    ┌──────────┼──────────┬─────────────┬─────────────┐             │
│    │          │          │             │             │             │
│    ▼          ▼          ▼             ▼             ▼             │
│  ┌────┐  ┌────┐     ┌────┐        ┌────┐        ┌────────┐        │
│  │ UI │  │Code│     │Docs│        │Dev │        │ Skills │        │
│  │Gen │  │Val │     │    │        │Guide│        │        │        │
│  └────┘  └────┘     └────┘        └────┘        └────────┘        │
│                                                                      │
│  Legend:                                                             │
│  UI Gen = axis-ui-generator (Sonnet) - Code generation             │
│  Code Val = axis-code-validator (Haiku) - Compliance checking      │
│  Docs = axis-documentation (Haiku) - 77 components, 16K+ lines     │
│  Dev Guide = axis-development-guide (Auto-referenced) - Patterns   │
│  Skills = Domain knowledge (component selection, validation)        │
│                                                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                      Slash Commands                           │  │
│  │  /axis [request] - Unified command for all capabilities       │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

### Architectural Principles

1. **Unified Command Interface**: Single /axis command for all capabilities
2. **Intelligent Routing**: Automatic agent selection based on request type
3. **Specification-Driven Development**: Code from specifications, not assumptions
4. **AXIS Framework First**: All 77 components, 13 mandatory conventions enforced
5. **Accessibility by Default**: WCAG 2.1 AA compliance built-in
6. **Model Optimization**: Haiku for validation/docs, Sonnet for generation

---

## Component Design

The plugin is organized into five architectural layers:

### 1. Request Analysis & Routing Layer

**Purpose:** Analyze user requests and route to appropriate specialists

**Components:**

#### Unified /axis Command
**File:** `commands/axis.md`

**Responsibilities:**
- Parse natural language requests
- Classify task type: UI generation, code validation, documentation query, or best practices
- Route to appropriate specialized agent
- Handle both inline requests and file attachments (mockups)
- Support multi-modal inputs (text + images)

**Routing Decision Matrix:**

| Request Contains | Route To | For |
|-----------------|----------|-----|
| "create", "generate", "build" + UI/form/component | axis-ui-generator | Code generation |
| "validate", "check", "review" + code/component | axis-code-validator | Compliance checking |
| "how to", "show me", component name + usage/properties | axis-documentation | Component documentation |
| "pattern", "convention", "best practice", "setup" | axis-development-guide | Development patterns |

**Input Types:**
- Natural language descriptions
- UI mockups/screenshots (PNG, JPG, SVG)
- UI-TDD specifications from design-agent
- Existing Angular code for validation
- POM structures (TypeScript interfaces, JSON)
- DynamoDB JSON schemas

**Key Logic:**
```typescript
interface RequestAnalysis {
  taskType: 'ui-generation' | 'code-validation' | 'documentation' | 'best-practices';
  inputType: 'written-spec' | 'visual-spec' | 'existing-code' | 'query';
  targetAgent: 'axis-ui-generator' | 'axis-code-validator' |
                'axis-documentation' | 'axis-development-guide';
  context: {
    specification?: string;
    mockup?: Image;
    code?: string;
    query?: string;
    pomStructure?: POMDefinition;
    jsonSchema?: DynamoDBSchema;
  };
}
```

---

### 2. Code Generation Layer

**Purpose:** Generate production-ready Angular components from specifications

**Components:**

#### AXIS UI Generator
**File:** `agents/axis-ui-generator.md`
**Model:** Sonnet
**Tools:** Read, Write, Edit, Glob, Grep

**Responsibilities:**
- Generate Angular components from written specifications (requirements, UI-TDD)
- Generate Angular components from visual specifications (mockups, screenshots)
- Implement appropriate AXIS components from 77-component library
- Enforce 13 mandatory AXIS coding conventions
- Generate forms with client-side validation (field-level and cross-field)
- Map form fields to POM paths (when POM structure provided)
- Generate dynamic UI components (DynamoDB-driven, when JSON schema provided)
- Include accessibility attributes by default (ARIA, keyboard navigation)
- Generate component documentation

**AXIS Component Library (77 Components):**

| Category | Count | Components |
|----------|-------|------------|
| Form Controls | 15 | button, checkbox, radio, input, dropdown, datepicker, date-range, timepicker, slider, rating, file-upload, editor, captcha, chip-list, duallist |
| Layout | 9 | accordion, card, tab, modal, bottom-sheet, carousel, list, styled-list, scroll-container |
| Navigation | 8 | navbar, bread-crumb, paginator, portal-menu, progress-step, progress-tracker, scroll2tb, tour |
| Feedback | 10 | alert, tooltip, loading, progress-bar, progress-chart, aqi, timer, count, feedback, media |
| Data Display | 6 | tree, calendar, truncate, icon, logger, pdf-viewer |
| Charts | 18 | pie, bar, line, gauge, funnel, scatter, bubble, area, radar, polar, candlestick, heatmap, treemap, sunburst, sankey, parallel, boxplot, graph |
| Advanced | 7 | aug (UI Generator), data-grid, notifications, search-address, search-account, json-translator, common-login |
| Utilities | 4 | cache-service, can-deactivate, customValidators, screen-capture |

**Key Features:**
- Component selection based on requirements
- Proper AXIS imports (AxisSharedModule)
- AXIS CSS classes (NOT Bootstrap or Material)
- Reactive forms or AUG-based dynamic forms
- API service calls using prototype mode
- Accessibility attributes (ARIA labels, roles, keyboard nav)

**Output Structure:**
```typescript
// Component TypeScript
@Component({
  selector: 'app-registration-form',
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.scss']
})
export class RegistrationFormComponent implements OnInit {
  registrationForm: FormGroup;

  ngOnInit() {
    this.initializeForm();
  }

  private initializeForm() {
    this.registrationForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      // Cross-field validation
    }, { validators: this.crossFieldValidator });
  }
}
```

```html
<!-- Component HTML -->
<form [formGroup]="registrationForm" (ngSubmit)="onSubmit()">
  <axis-textbox
    [label]="'First Name'"
    [formControlName]="'firstName'"
    [isRequired]="true"
    [errorMessage]="getErrorMessage('firstName')"
    aria-label="First Name Input"
    role="textbox">
  </axis-textbox>

  <axis-dropdown
    [label]="'Country'"
    [options]="countries"
    [formControlName]="'country'"
    [isSearchable]="true"
    aria-label="Country Selection">
  </axis-dropdown>

  <axis-button
    [label]="'Submit'"
    [isDisabled]="!registrationForm.valid"
    (onClick)="onSubmit()">
  </axis-button>
</form>
```

---

### 3. Code Validation Layer

**Purpose:** Validate existing code against AXIS framework standards

**Components:**

#### AXIS Code Validator
**File:** `agents/axis-code-validator.md`
**Model:** Haiku (fast and cost-effective)
**Tools:** Read, Grep, Glob

**Responsibilities:**
- Scan Angular code for AXIS compliance violations
- Validate imports (AxisSharedModule, component imports)
- Validate component properties and bindings
- Check for invalid AXIS CSS classes
- Verify accessibility attributes (ARIA, keyboard nav)
- Detect Bootstrap/Material usage (anti-pattern)
- Verify API service pattern (prototype mode)
- Check for proper error handling
- Generate compliance report with recommendations

**13 Mandatory AXIS Coding Conventions:**

1. **axis serve, NOT npm start** - Use AXIS CLI instead of Angular CLI
2. **Shared Code in _shared Folder** - All reusable code in `_shared/`
3. **AXIS CSS Classes Only** - Never Bootstrap or Material classes
4. **API Calls Use Prototype Mode** - Pattern: `this.http.post(...).pipe()`
5. **AUG for Dynamic Forms** - Use AXIS UI Generator for DynamoDB-driven forms
6. **Import AxisSharedModule** - All components must import AxisSharedModule
7. **Proper Component Bindings** - Use AXIS-specific property names
8. **Accessibility Attributes** - ARIA labels, roles, keyboard navigation
9. **Form Validation Pattern** - Reactive forms with custom validators
10. **Navigation Management** - Update left/top navigation when adding features
11. **POM Field Mapping** - Map form fields to Policy Object Model paths
12. **Error Handling** - Proper error messaging and user feedback
13. **No Direct DOM Manipulation** - Use Angular directives and AXIS components

**Validation Checklist:**
```typescript
interface ValidationResult {
  overallCompliance: number; // 0-100
  violations: Violation[];
  recommendations: string[];
  categories: {
    imports: ValidationCategory;
    components: ValidationCategory;
    accessibility: ValidationCategory;
    css: ValidationCategory;
    api: ValidationCategory;
  };
}

interface Violation {
  rule: string; // Which of 13 conventions violated
  severity: 'critical' | 'high' | 'medium' | 'low';
  location: string; // File:line
  description: string;
  fix: string; // How to fix
}
```

---

### 4. Documentation & Knowledge Layer

**Purpose:** Provide comprehensive component documentation and development patterns

**Components:**

#### AXIS Component Documentation
**File:** `agents/axis-documentation.md`
**Model:** Haiku (fast lookups)
**Size:** 16,280 lines

**Content:**
- Complete API reference for all 77 components
- Component properties with types, defaults, and descriptions
- Methods and events for each component
- Usage examples and code snippets
- Integration patterns
- Accessibility guidelines per component

**Structure:**
```markdown
## axis-textbox

### Properties
| Property | Type | Default | Description |
|----------|------|---------|-------------|
| label | string | '' | Label text displayed above input |
| placeholder | string | '' | Placeholder text when empty |
| isRequired | boolean | false | Marks field as required |
| errorMessage | string | '' | Error message displayed on validation failure |
| formControlName | string | '' | Angular form control name |

### Methods
| Method | Parameters | Returns | Description |
|--------|------------|---------|-------------|
| focus() | none | void | Programmatically focus the input |
| clear() | none | void | Clear the input value |

### Events
| Event | Parameters | Description |
|-------|------------|-------------|
| onChange | value: string | Emitted when input value changes |
| onBlur | event: FocusEvent | Emitted when input loses focus |

### Usage Example
```typescript
<axis-textbox
  [label]="'Email Address'"
  [placeholder]="'Enter your email'"
  [isRequired]="true"
  [formControlName]="'email'"
  (onChange)="handleEmailChange($event)">
</axis-textbox>
```

### Accessibility
- Includes aria-label automatically
- Supports keyboard navigation
- Error announcements for screen readers
```

**Responsibilities:**
- Answer component property queries
- Provide usage examples
- Explain integration patterns
- Recommend appropriate components for use cases

---

#### AXIS Development Guide
**File:** `agents/axis-development-guide.md`
**Auto-referenced by all agents**

**Content:**
- 13 Mandatory Coding Conventions (detailed explanations)
- Installation & Setup (axis serve, project structure)
- API Service Pattern (prototype mode, error handling)
- AXIS UI Generator (AUG) - Dynamic form generation
- AXIS CSS Classes (complete reference)
- AxisSharedModule Configuration
- Common Patterns (services, forms, dropdowns, navigation)
- Business Logic Integration (POM mapping, DynamoDB-driven UI)
- Troubleshooting (common issues and solutions)
- Quality Checklist (validation, accessibility, testing)

**Purpose:**
- Auto-referenced by UI generator during code generation
- Auto-referenced by code validator during compliance checking
- Ensures all generated code follows AXIS patterns
- Single source of truth for AXIS best practices

---

### 5. Domain Knowledge & Validation Layer (Skills)

**Purpose:** Provide specialized domain knowledge for component selection and validation

The plugin uses **Agent Skills** (model-invoked capabilities) for domain-specific tasks:

#### Skill 1: axis-component-selector

**Description:** "Analyzes UI requirements and selects the most appropriate AXIS components from the 77-component library based on functionality, layout, and accessibility needs"

**Trigger:** Model auto-invokes when generating UI from specifications

**SKILL.md Content:**
```markdown
You are an AXIS component selection expert. Given UI requirements, select appropriate components:

**Component Selection Matrix:**

| Requirement | AXIS Component | Category |
|------------|----------------|----------|
| Text input field | axis-textbox | Form Controls |
| Dropdown selection | axis-dropdown | Form Controls |
| Date selection | axis-datepicker | Form Controls |
| Multiple selections | axis-checkbox, axis-chip-list | Form Controls |
| File upload | axis-file-upload | Form Controls |
| Navigation menu | axis-navbar, axis-portal-menu | Navigation |
| Data table with sorting | axis-data-grid | Advanced |
| Chart visualization | axis-pie-chart, axis-bar-chart, etc. | Charts |
| Form section grouping | axis-accordion, axis-card | Layout |
| Modal dialog | axis-modal | Layout |
| Progress indicator | axis-progress-bar, axis-loading | Feedback |

**Selection Criteria:**

1. **Functionality**: Does component support required features?
2. **Accessibility**: Does component include ARIA support?
3. **Validation**: Does component support form validation?
4. **Customization**: Can component be styled/configured as needed?
5. **Performance**: Is component optimized for use case?

**Output Format:**
```json
{
  "selectedComponents": [
    {
      "requirement": "Name input field",
      "component": "axis-textbox",
      "reason": "Text input with built-in validation and accessibility",
      "properties": {
        "label": "First Name",
        "isRequired": true,
        "formControlName": "firstName"
      }
    }
  ],
  "imports": [
    "AxisTextboxComponent",
    "AxisSharedModule"
  ]
}
```
```

**Location:** `skills/axis-component-selector/SKILL.md`

---

#### Skill 2: axis-compliance-validator

**Description:** "Validates generated or existing code against all 13 mandatory AXIS coding conventions, identifying violations and suggesting fixes"

**Trigger:** Model auto-invokes after code generation or during validation

**SKILL.md Content:**
```markdown
You are an AXIS compliance validation expert. Validate code against 13 mandatory conventions:

**Validation Rules:**

1. **axis serve, NOT npm start**
   - Check: package.json scripts
   - Violation: `"start": "ng serve"`
   - Fix: `"start": "axis serve"`

2. **Shared Code in _shared Folder**
   - Check: Reusable services, components, utilities location
   - Violation: Services in `/src/app/services/`
   - Fix: Move to `/src/app/_shared/services/`

3. **AXIS CSS Classes Only**
   - Check: HTML for Bootstrap/Material classes
   - Violation: `class="btn btn-primary"`
   - Fix: `class="axis-btn axis-btn-primary"`

4. **API Calls Use Prototype Mode**
   - Check: HTTP service calls
   - Violation: `this.http.post(url, data).subscribe(...)`
   - Fix: `this.apiService.post(url, data, 'prototype').pipe(...)`

5. **Import AxisSharedModule**
   - Check: Component module imports
   - Violation: Missing AxisSharedModule
   - Fix: Add `imports: [AxisSharedModule]` to @NgModule

[... all 13 rules ...]

**Output Format:**
```json
{
  "overallCompliance": 85,
  "violations": [
    {
      "rule": "AXIS CSS Classes Only",
      "severity": "high",
      "location": "registration-form.component.html:15",
      "description": "Bootstrap class 'btn btn-primary' used instead of AXIS class",
      "fix": "Replace with 'axis-btn axis-btn-primary'"
    }
  ],
  "recommendations": [
    "Replace all Bootstrap classes with AXIS equivalents",
    "Add AxisSharedModule to component imports"
  ]
}
```
```

**Location:** `skills/axis-compliance-validator/SKILL.md`

---

#### Skill 3: axis-accessibility-enforcer

**Description:** "Ensures all generated UI components include proper ARIA attributes, keyboard navigation support, and WCAG 2.1 AA compliance without developer needing to specify"

**Trigger:** Model auto-invokes during code generation

**SKILL.md Content:**
```markdown
You are an accessibility expert for AXIS components. Enforce WCAG 2.1 AA compliance:

**Accessibility Requirements:**

1. **ARIA Labels**: All interactive elements must have aria-label
2. **ARIA Roles**: Components must have appropriate roles (button, textbox, listbox, etc.)
3. **Keyboard Navigation**: Tab order, Enter/Space activation, Arrow key navigation
4. **Error Announcements**: Form errors must be announced to screen readers
5. **Focus Management**: Visible focus indicators, logical tab order
6. **Color Contrast**: Text meets 4.5:1 contrast ratio
7. **Alternative Text**: Images and icons have alt text
8. **Landmark Regions**: Proper use of header, main, nav, footer

**Component-Specific Accessibility:**

| Component | ARIA Attributes | Keyboard Support |
|-----------|----------------|------------------|
| axis-textbox | aria-label, aria-required, aria-invalid | Tab to focus, type to input |
| axis-dropdown | aria-label, aria-expanded, aria-haspopup | Tab to focus, Arrow keys to navigate, Enter to select |
| axis-button | aria-label, aria-pressed (toggle buttons) | Tab to focus, Enter/Space to activate |
| axis-modal | aria-modal, aria-labelledby, aria-describedby | Escape to close, Tab traps focus |
| axis-data-grid | aria-label, aria-rowcount, aria-colcount | Arrow keys for navigation, Enter to select |

**Auto-Generated Accessibility:**

```html
<!-- Textbox with accessibility -->
<axis-textbox
  [label]="'Email Address'"
  [formControlName]="'email'"
  [isRequired]="true"
  aria-label="Email Address Input"
  aria-required="true"
  aria-invalid="{{emailControl.invalid}}"
  role="textbox">
</axis-textbox>

<!-- Dropdown with accessibility -->
<axis-dropdown
  [label]="'Country'"
  [options]="countries"
  [formControlName]="'country'"
  aria-label="Country Selection"
  aria-haspopup="listbox"
  aria-expanded="{{isDropdownOpen}}"
  role="combobox">
</axis-dropdown>

<!-- Button with accessibility -->
<axis-button
  [label]="'Submit'"
  [isDisabled]="!form.valid"
  (onClick)="onSubmit()"
  aria-label="Submit Registration Form"
  role="button"
  [attr.aria-disabled]="!form.valid">
</axis-button>
```

**Validation Checklist:**
- [ ] All interactive elements have aria-label
- [ ] Proper ARIA roles assigned
- [ ] Keyboard navigation implemented
- [ ] Error messages announced
- [ ] Focus indicators visible
- [ ] Color contrast meets requirements
- [ ] Alt text for images
```

**Location:** `skills/axis-accessibility-enforcer/SKILL.md`

---

#### Skill 4: pom-field-mapper

**Description:** "Maps form fields to Policy Object Model (POM) data structure paths for insurance domain integration, ensuring consistent data binding with backend APIs"

**Trigger:** Model auto-invokes when POM structure is provided during UI generation

**SKILL.md Content:**
```markdown
You are a POM field mapping expert. Map form fields to POM paths:

**POM Structure Example:**
```typescript
interface PolicyObjectModel {
  applicant: {
    personalInfo: {
      firstName: string;
      lastName: string;
      dateOfBirth: string;
      ssn: string;
    };
    contactInfo: {
      email: string;
      phone: string;
      address: {
        street: string;
        city: string;
        state: string;
        zipCode: string;
      };
    };
  };
  policy: {
    policyNumber: string;
    effectiveDate: string;
    expirationDate: string;
    coverageType: string;
  };
  vehicle: {
    make: string;
    model: string;
    year: number;
    vin: string;
  };
}
```

**Mapping Strategy:**

1. **Analyze Form Fields**: Identify all form controls
2. **Match to POM Paths**: Find corresponding POM property paths
3. **Generate Mapping Code**: Create data binding logic
4. **Handle Transformations**: Convert UI values to POM format (e.g., date formatting)

**Mapping Code Pattern:**

```typescript
// Component TypeScript
export class InsuranceFormComponent {
  pom: PolicyObjectModel = this.initializePOM();

  // Form to POM mapping
  mapFormToPOM(): void {
    this.pom.applicant.personalInfo.firstName = this.form.get('firstName').value;
    this.pom.applicant.personalInfo.lastName = this.form.get('lastName').value;
    this.pom.applicant.personalInfo.dateOfBirth = this.formatDate(
      this.form.get('dateOfBirth').value
    );
    this.pom.applicant.contactInfo.email = this.form.get('email').value;
    this.pom.applicant.contactInfo.phone = this.formatPhone(
      this.form.get('phone').value
    );
  }

  // POM to Form mapping (for edit scenarios)
  mapPOMToForm(): void {
    this.form.patchValue({
      firstName: this.pom.applicant.personalInfo.firstName,
      lastName: this.pom.applicant.personalInfo.lastName,
      dateOfBirth: new Date(this.pom.applicant.personalInfo.dateOfBirth),
      email: this.pom.applicant.contactInfo.email,
      phone: this.pom.applicant.contactInfo.phone
    });
  }
}
```

**Output Format:**
```json
{
  "fieldMappings": [
    {
      "formField": "firstName",
      "pomPath": "applicant.personalInfo.firstName",
      "transformation": "none"
    },
    {
      "formField": "dateOfBirth",
      "pomPath": "applicant.personalInfo.dateOfBirth",
      "transformation": "formatDate"
    }
  ],
  "generatedCode": "mapFormToPOM() and mapPOMToForm() methods"
}
```
```

**Location:** `skills/pom-field-mapper/SKILL.md`

---

## Plugin Structure

The plugin follows Claude Code best practices for unified command architecture:

```
axis-tools/
├── .claude-plugin/
│   └── plugin.json                     # Plugin configuration
│
├── commands/                            # Unified slash command
│   └── axis.md                         # Single entry point for all capabilities
│
├── agents/                              # Specialized agents
│   ├── axis-ui-generator.md            # UI code generation (model: sonnet)
│   ├── axis-code-validator.md          # Code validation (model: haiku)
│   ├── axis-documentation.md           # Component docs (model: haiku, 16K+ lines)
│   ├── axis-development-guide.md       # Patterns & conventions (auto-referenced)
│   └── generate_axis_docs.py          # Documentation generation script
│
├── skills/                              # Agent Skills (model-invoked)
│   ├── axis-component-selector/
│   │   └── SKILL.md                    # Component selection logic
│   ├── axis-compliance-validator/
│   │   └── SKILL.md                    # 13 conventions validation
│   ├── axis-accessibility-enforcer/
│   │   └── SKILL.md                    # WCAG 2.1 AA enforcement
│   └── pom-field-mapper/
│       └── SKILL.md                    # POM mapping logic
│
├── requirements/                        # Requirements documentation
│   ├── hlr.md                          # High-Level Requirements (client)
│   ├── axis-tools-brd.md               # Business Requirements Document
│   └── axis-tools-hld.md               # This file (High-Level Design)
│
├── __tests__/                           # Evaluation tests
│   ├── ui_generation_from_descriptions.test
│   ├── ui_generation_from_mockups.test
│   └── code_validation_against_axis_guidelines.test
│
├── acceptance-criteria.md               # Plugin requirements
└── README.md                            # User-facing documentation
```

### Plugin Configuration

**File:** `.claude-plugin/plugin.json`

```json
{
  "name": "axis-tools",
  "version": "1.0.0",
  "description": "AXIS Angular code generation and compliance validation for enterprise UI development",
  "author": "AI COE Team",
  "main_command": "commands/axis.md",
  "commands": [
    "commands/axis.md"
  ],
  "agents": [
    "agents/axis-ui-generator.md",
    "agents/axis-code-validator.md",
    "agents/axis-documentation.md",
    "agents/axis-development-guide.md"
  ],
  "skills": [
    "skills/axis-component-selector",
    "skills/axis-compliance-validator",
    "skills/axis-accessibility-enforcer",
    "skills/pom-field-mapper"
  ],
  "dependencies": {
    "workspace-agent": "^1.0.0",
    "design-agent": "^1.0.0"
  },
  "keywords": [
    "axis",
    "angular",
    "ui-generation",
    "code-validation",
    "accessibility",
    "insurance",
    "pom",
    "dynamic-forms"
  ]
}
```

---

## Agent Design

### Agent Architecture Pattern

The axis-tools plugin follows a **three-tier agent architecture** pattern:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          Agent Architecture Pattern                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  TIER 1: COMMAND (Prompt Enricher)                                          │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  /axis command (commands/axis.md)                                      │ │
│  │  - Takes $ARGUMENTS from user                                          │ │
│  │  - Enriches with context instructions                                  │ │
│  │  - Invokes router via Task tool                                        │ │
│  │  - NO routing logic (delegated to router)                              │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                    │                                         │
│                                    ▼                                         │
│  TIER 2: ROUTER (Context Engineering + Orchestration)                       │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  axis-router (agents/axis-router.md)                                   │ │
│  │                                                                        │ │
│  │  Context Engineering:                                                  │ │
│  │  - FrameworkDetection: Read package.json, angular.json                 │ │
│  │  - PatternDiscovery: Detect static vs dynamic indicators               │ │
│  │  - ContextAssembly: ADLC LLD/HLD/UI-TDD documents                    │ │
│  │  - OutputPathDiscovery: Discover where to write generated code         │ │
│  │                                                                        │ │
│  │  Orchestration:                                                        │ │
│  │  - IntentAnalysis: Classify task (generate, validate, docs)            │ │
│  │  - PlanPresentation: Present plan with agent selection                 │ │
│  │  - UserConfirmation: WAIT for explicit approval                        │ │
│  │  - AgentDelegation: Invoke specialized agent with context              │ │
│  │  - ResultAggregation: Summarize what was accomplished                  │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                    │                                         │
│         ┌──────────────────────────┼──────────────────────────┐             │
│         ▼                          ▼                          ▼             │
│  TIER 3: SPECIALIZED AGENTS (Extended Thinking + TOON)                      │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐                │
│  │axis-ui-generator│  │dynamic-ui-gen  │  │axis-code-      │  + others     │
│  │                │  │                │  │validator       │                │
│  │[Extended       │  │[Extended       │  │[Extended       │                │
│  │ thinking:...]  │  │ thinking:...]  │  │ thinking:...]  │                │
│  │                │  │                │  │                │                │
│  │Capabilities    │  │Capabilities    │  │Capabilities    │                │
│  │BehavioralTraits│  │BehavioralTraits│  │BehavioralTraits│                │
│  │Guardrails      │  │Guardrails      │  │Guardrails      │                │
│  │QualityPrincip. │  │QualityPrincip. │  │QualityPrincip. │                │
│  └────────────────┘  └────────────────┘  └────────────────┘                │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Tier 1: Command as Prompt Enricher

**Pattern:** Commands are simple prompt enrichers that:
1. Accept `$ARGUMENTS` from user
2. Enrich with context instructions for the router
3. Invoke router via `Task tool with subagent_type`
4. Do NOT contain routing logic (delegated to router)

**Template:**
```markdown
---
argument-hint: [your request in natural language]
description: Unified command description
model: inherit
---

[Extended thinking: This command is the unified entry point...]

## Agent Invocation

Use Task tool with `subagent_type="axis-router"` with the following enriched prompt:

**Prompt Template:**
\`\`\`
## User Request
$ARGUMENTS

## Context Instructions for Router
1. **Analyze User Intent**...
2. **ADLC Required Context**...
3. **Present Plan for Confirmation**...
4. **Delegate to Specialized Agent**...
\`\`\`
```

#### Tier 2: Router with Context Engineering + Orchestration

**Pattern:** Routers have two distinct responsibilities expressed in TOON format:

```
ContextEngineering[Responsibility,Description]:
  FrameworkDetection,"Read package.json, angular.json to detect Angular/AXIS version"
  PatternDiscovery,"Detect static vs dynamic UI indicators in LLD/HLD"
  ContextAssembly,"ADLC all relevant documents and project patterns"
  OutputPathDiscovery,"Three-tier discovery: LLD metadata → project structure → user prompt"

Orchestration[Responsibility,Description]:
  IntentAnalysis,"Classify task: UI generation | validation | documentation | best practices"
  PlanPresentation,"Present plan with agent selection and estimated output"
  UserConfirmation,"WAIT for explicit user approval before proceeding"
  AgentDelegation,"Invoke specialized agent with full context via Task tool"
  ResultAggregation,"Summarize results and report back to user"
```

**Handoff with Extended Thinking Templates:**
```
ExtendedThinkingTemplates[Agent,ThinkingInstructions]:
  axis-ui-generator,"Before generating: (1) read skill axis-development-guide; (2) glob for existing components; (3) detect naming conventions..."
  dynamic-ui-generator,"Before generating: (1) read LLD Form Specifications; (2) extract JSON schema structure; (3) identify POM mappings..."
  axis-code-validator,"Before validating: (1) read skill axis-rules.md; (2) glob for files in scope; (3) check each rule systematically..."
```

#### Tier 3: Specialized Agents with Extended Thinking + TOON

**Pattern:** Specialized agents have structured prompts with:

1. **[Extended thinking: ...]** - Instructions for how to think before acting (numbered steps)
2. **TOON format** for structured metadata:
   - `Capabilities[Category,Skills]` - What the agent can do
   - `BehavioralTraits[Trait,Description]` - How the agent behaves
   - `Guardrails` - INPUT_BLOCKING_CONDITIONS, OPERATIONAL_CONSTRAINTS
   - `QualityPrinciples[Principle,Implementation]` - Quality standards

**Template:**
```markdown
---
name: agent-name
description: Agent description
model: inherit
tools: [tools]
---

[Extended thinking: I am a {role} that {purpose}. When I receive a request,
I first (1) {step1}; (2) {step2}; (3) {step3}; ... I never {constraint}.]

## Capabilities

\`\`\`
Capabilities[Category,Skills]:
  Category1,"Skill1 | Skill2 | Skill3"
  Category2,"Skill4 | Skill5"
\`\`\`

## Behavioral Traits

\`\`\`
BehavioralTraits[Trait,Description]:
  Trait1,"Description of trait"
  Trait2,"Description of trait"
\`\`\`

## Guardrails

\`\`\`
INPUT_BLOCKING_CONDITIONS[Category,Triggers]:
  SCOPE_VIOLATION,"triggers that block input"

OPERATIONAL_CONSTRAINTS[Type,Rules]:
  ALWAYS,"rules that always apply"
  NEVER,"rules that never apply"
\`\`\`

## Key Distinctions

- **vs other-agent**: I do X; it does Y
```

---

### /axis Command (Prompt Enricher)

**File:** `agents/axis-router.md`

**Frontmatter:**
```yaml
---
name: axis-router
description: Orchestrates Axis development workflows by exploring context, planning implementation, and coordinating specialized agents. Use PROACTIVELY when users invoke /axis command or request Angular UI generation, validation, or documentation lookup.
model: sonnet
color: purple
tools:
  - Read
  - Glob
  - Grep
  - Task
permissionMode: default
---
```

**Purpose:**
The axis-router is the intelligent orchestrator for all Axis development workflows, serving as the entry point from the `/axis` command. It explores the codebase and provided documents (LLD/HLD/FSD/UI-TDD) before making routing decisions, ensuring the correct specialized agent is selected.

**Responsibilities:**
- Analyze natural language requests to detect intent (generate, validate, document, guide)
- **Read LLD/HLD/UI-TDD documents to detect static vs dynamic patterns**
- **Detect Enterprise UI-TDD indicators** (see Routing Logic above)
- Present implementation plan for user confirmation BEFORE delegating
- Coordinate multi-agent workflows (generate → validate → fix)
- Discover output paths through project exploration
- Pass full context to sub-agents including TDD constraints

**Workflow:**
```
Step 1: Analyze Request → Identify primary intent
Step 2: Explore Context → Read LLD/HLD/UI-TDD, glob project structure
Step 3: Detect Patterns → Static vs Dynamic indicators
Step 4: Generate Plan → Present approach, components, output path
Step 5: Await Confirmation → User must approve before proceeding
Step 6: Delegate → Invoke specialized agent with full context
Step 7: Summarize Results → Report what was accomplished
```

**Context Passing Specification:**
When delegating to sub-agents, axis-router passes:
```yaml
# Context passed to sub-agents
contextPassing:
  userRequest: "Original user request"
  outputPath: "Discovered or LLD-specified path"
  outputPathSource: "LLD | PROJECT | USER"
  tddConstraints:
    dynamicIndicators: ["Dynamic Form", "componentConfig", ...]
    formSpecifications: { ... }
    pomMapping: { ... }
  existingPatterns:
    componentNaming: "Discovered naming convention"
    servicePatterns: "Discovered service patterns"
```

**Key Behaviors:**
- **NEVER** generates code directly (always delegates)
- **ALWAYS** presents plan for user confirmation before delegating
- Detects dynamic vs static by READING documents, not guessing
- Explains routing decisions with clear reasoning
- Asks clarifying questions when intent is ambiguous

**Quality Checklist:**
- [ ] LLD/HLD/UI-TDD read if provided
- [ ] Dynamic indicators checked
- [ ] Implementation plan presented
- [ ] User confirmation received
- [ ] Full context passed to sub-agent
- [ ] Results summarized

---

### AXIS UI Generator Agent

**File:** `agents/axis-ui-generator.md`

**Frontmatter:**
```yaml
---
name: AXIS UI Generator
description: Generates production-ready Angular components from written specifications, UI mockups, or UI-TDD using the AXIS framework. Enforces 13 mandatory coding conventions, includes accessibility by default, and supports POM field mapping and dynamic UI generation.
model: sonnet
color: blue
tools:
  - Read
  - Write
  - Edit
  - Glob
  - Grep
---
```

**Responsibilities:**
- Generate Angular components (TypeScript, HTML, SCSS)
- Select appropriate AXIS components from 77-component library
- Enforce 13 mandatory AXIS coding conventions
- Include accessibility attributes by default (ARIA, keyboard nav)
- Generate forms with client-side validation (field-level and cross-field)
- Map form fields to POM paths (when POM provided)
- Generate dynamic UI code (DynamoDB-driven, when JSON schema provided)
- Auto-reference axis-development-guide for patterns

**Quality Checklist:**
- [ ] Proper AXIS component selection
- [ ] AxisSharedModule imported
- [ ] AXIS CSS classes used (not Bootstrap/Material)
- [ ] Accessibility attributes included
- [ ] Form validation implemented
- [ ] POM field mapping (if applicable)
- [ ] API service calls use prototype mode
- [ ] Error handling included
- [ ] Code follows 13 conventions

---

### Dynamic UI Generator Agent

**File:** `agents/dynamic-ui-generator.md`

**Frontmatter:**
```yaml
---
name: dynamic-ui-generator
description: Generates Angular code that renders dynamic UI using the axis-ui-generator component. Takes LLD/HLD with JSON schema definitions as input and creates components that fetch UI structure from DynamoDB and render forms dynamically.
model: sonnet
color: cyan
tools:
  - Read
  - Write
  - Edit
  - Glob
  - Grep
  - Task
---
```

**Responsibilities:**
- Read LLD/HLD/UI-TDD documents containing JSON schema definitions or Form Specifications
- Generate Angular components that use `<axis-ui-generator>` component
- **Generate JSON Structure file (form-structure.ts) from UI-TDD Form Specifications**
- Create services to fetch `uiStructure` from backend/DynamoDB
- Handle loading and error states for dynamic UI rendering
- Implement event handlers for `(uiEmitUpdate)` and `(uiEmit)` events
- Generate TypeScript interfaces matching JSON schema structure
- **Use contextual naming pattern**: `ui{Feature}Structure`, `ui{Feature}Data`
- **Use axis-datagrid for ALL search results tables**
- Follow Plan → Confirm → Generate workflow

**axis-ui-generator Component Attributes (CRITICAL):**
```html
<!-- ONLY these attributes are recognized -->
<axis-ui-generator
  [uiStructure]="ui{Feature}Structure"    <!-- JSON structure (required) -->
  [uiData]="ui{Feature}Data"              <!-- Data object (required) -->
  (uiEmitUpdate)="{feature}InfoEmitUpdate($event)"  <!-- Field change event -->
  (uiEmit)="onFormSubmit($event)">        <!-- Form submit event -->
</axis-ui-generator>
```

**Contextual Naming Pattern:**
```typescript
// Use feature-specific naming
ui{Feature}Structure: UIStructure | null = null;  // e.g., uiClientStructure, uiProducerStructure
ui{Feature}Data: Record<string, any> = {};        // e.g., uiClientData, uiProducerData

{feature}InfoEmitUpdate(event: any): void {       // e.g., clientInfoEmitUpdate, producerInfoEmitUpdate
  this.ui{Feature}Data = { ...this.ui{Feature}Data, ...event };
}
```

**Output Files:**
| File | Purpose |
|------|---------|
| `{component-name}.component.ts` | Component with service fetch and event handling |
| `{component-name}.component.html` | Template using `<axis-ui-generator>` with contextual naming |
| `{component-name}.service.ts` | Service to fetch UI schema |
| `{component-name}.model.ts` | TypeScript interfaces |
| `{feature}-form-structure.ts` | **JSON structure generated from UI-TDD Form Specifications** |

**JSON Structure Generation (from UI-TDD):**
When UI-TDD contains Form Specifications, generate `{feature}-form-structure.ts`:
```typescript
export const {FEATURE}_FORM_STRUCTURE: UIStructure = {
  layout: { type: 'basic', slots: { main: ['mainSection'] } },
  sectionsOrder: ['mainSection'],
  sections: {
    mainSection: {
      type: 'container',
      fields: [
        { type: 'text', name: 'fieldName', label: 'Field Label', ... }
      ]
    }
  }
};
```

**Key Difference from axis-ui-generator:**
| axis-ui-generator | dynamic-ui-generator |
|-------------------|----------------------|
| Generates static Angular code (.ts, .html) | Generates code that uses `<axis-ui-generator>` component |
| Direct AXIS component usage | Fetches JSON schema from service/DynamoDB |
| UI defined in code | UI defined in JSON structure (runtime) |
| Build-time UI structure | Runtime UI structure |

**Search Results with axis-datagrid:**
When implementing search functionality, MUST use axis-datagrid:
```html
<axis-datagrid
  [columns]="searchResultColumns"
  [data]="searchResults"
  [pagination]="true"
  [pageSize]="10"
  (rowSelect)="onResultSelect($event)">
</axis-datagrid>
```

**Quality Checklist:**
- [ ] Component fetches uiStructure from service
- [ ] Uses axis-ui-generator with ONLY recognized attributes: `[uiStructure]`, `[uiData]`, `(uiEmitUpdate)`, `(uiEmit)`
- [ ] **Uses contextual naming**: `ui{Feature}Structure`, `ui{Feature}Data`, `{feature}InfoEmitUpdate`
- [ ] Handles loading and error states
- [ ] Event handlers for uiEmitUpdate and uiEmit with correct signatures
- [ ] Service has proper API calls
- [ ] TypeScript interfaces match schema
- [ ] **JSON structure file generated from Form Specifications (if in UI-TDD)**
- [ ] **axis-datagrid used for ALL search results**
- [ ] Standalone component with proper imports
- [ ] No hardcoded values (uses environment config)

---

### AXIS Code Validator Agent

**File:** `agents/axis-code-validator.md`

**Frontmatter:**
```yaml
---
name: AXIS Code Validator
description: Validates existing Angular code against AXIS framework guidelines, identifies violations of 13 mandatory coding conventions, checks accessibility compliance, and provides actionable fix recommendations.
model: haiku
color: yellow
tools:
  - Read
  - Grep
  - Glob
---
```

**Responsibilities:**
- Scan Angular code for AXIS compliance violations
- Validate against 13 mandatory conventions
- Check imports, component properties, CSS classes
- Verify accessibility attributes (ARIA, keyboard nav)
- Detect anti-patterns (Bootstrap/Material usage, incorrect API calls)
- Generate compliance report with recommendations
- Auto-reference axis-development-guide for validation rules

**Validation Output:**
```markdown
## Compliance Report

**Overall Compliance:** 75%

### Violations

#### Critical (2)
1. **Missing AxisSharedModule Import**
   - Location: registration-form.component.ts:10
   - Fix: Add `AxisSharedModule` to imports array

2. **Bootstrap CSS Classes Used**
   - Location: registration-form.component.html:25
   - Fix: Replace `class="btn btn-primary"` with `class="axis-btn axis-btn-primary"`

#### High (3)
[...]

### Recommendations
1. Import AxisSharedModule in all components
2. Replace all Bootstrap classes with AXIS equivalents
3. Add ARIA labels to all form controls
```

---

### AXIS Documentation Agent

**File:** `agents/axis-documentation.md`
**Model:** Haiku (fast lookups)
**Size:** 16,280 lines

**Frontmatter:**
```yaml
---
name: AXIS Component Documentation
description: Provides comprehensive API documentation for all 77 AXIS components including properties, methods, events, usage examples, and accessibility guidelines. Single source of truth for AXIS component reference.
model: haiku
color: green
tools:
  - Read
---
```

**Responsibilities:**
- Answer component property queries
- Provide usage examples with code snippets
- Explain component methods and events
- Recommend appropriate components for use cases
- Provide integration patterns
- Explain accessibility features

**Content Organization:**
- **77 Components** organized by category
- Each component includes:
  - Properties table (property, type, default, description)
  - Methods table (method, parameters, returns, description)
  - Events table (event, parameters, description)
  - Usage example (TypeScript + HTML)
  - Accessibility guidelines
  - Integration patterns

---

### AXIS Development Guide (Auto-Referenced)

**File:** `agents/axis-development-guide.md`

**Purpose:** Auto-referenced by all agents for patterns and conventions

**Content Sections:**

1. **13 Mandatory Coding Conventions** (detailed explanations)
2. **Installation & Setup** (axis serve, project structure)
3. **Project Structure** (_shared folder, module organization)
4. **API Service Pattern** (prototype mode, error handling)
5. **AXIS UI Generator (AUG)** (dynamic form generation from JSON)
6. **AXIS CSS Classes** (complete reference, NOT Bootstrap/Material)
7. **AxisSharedModule Configuration** (imports, declarations)
8. **Common Patterns**:
   - Services (API calls, caching, error handling)
   - Forms (reactive forms, validation, error messages)
   - Dropdowns (options, search, dynamic loading)
   - Navigation (left nav, top nav, breadcrumbs)
9. **Business Logic Integration**:
   - POM field mapping
   - DynamoDB-driven UI
   - Validation patterns
10. **Troubleshooting** (common issues and solutions)
11. **Quality Checklist** (validation, accessibility, testing)

---

## Skills Design

### Skill 1: axis-component-selector

**Location:** `skills/axis-component-selector/`

**Purpose:** Select appropriate AXIS components from 77-component library based on requirements

**When Invoked:** Model auto-invokes during UI generation from specifications

**Output:** Component selection with properties and reasoning

---

### Skill 2: axis-compliance-validator

**Location:** `skills/axis-compliance-validator/`

**Purpose:** Validate code against 13 mandatory AXIS coding conventions

**When Invoked:** Model auto-invokes after code generation or during validation

**Output:** Compliance report with violations and fixes

---

### Skill 3: axis-accessibility-enforcer

**Location:** `skills/axis-accessibility-enforcer/`

**Purpose:** Ensure WCAG 2.1 AA compliance with ARIA attributes and keyboard navigation

**When Invoked:** Model auto-invokes during code generation

**Output:** Accessibility-enhanced code with ARIA attributes

---

### Skill 4: pom-field-mapper

**Location:** `skills/pom-field-mapper/`

**Purpose:** Map form fields to Policy Object Model data structure paths

**When Invoked:** Model auto-invokes when POM structure is provided

**Output:** Field mappings and data binding code

---

## Commands Design

### Unified /axis Command (Prompt Enricher Pattern)

**File:** `commands/axis.md`

**Purpose:** Single entry point that enriches user input and invokes the axis-router

**Pattern:** The command is a **prompt enricher**, not a router. It:
1. Takes `$ARGUMENTS` from user
2. Enriches with context instructions for the router
3. Invokes `axis-router` via Task tool
4. Does NOT contain routing logic (delegated to router)

**Usage:**
```bash
/axis [your request in natural language]
```

**Examples:**

**UI Generation from Description:**
```bash
/axis Create a registration form with name, email, country dropdown, and submit button
/axis Build a dashboard with user stats card, line chart, and data grid
/axis Generate a multi-step wizard with progress tracker and navigation
```

**UI Generation from Mockup:**
```bash
/axis Generate this dashboard screen [attach dashboard-mockup.png]
/axis Create component from this design [attach form-design.jpg]
```

**Code Validation:**
```bash
/axis Validate my user-profile component - check imports and accessibility
/axis Review this form component for AXIS compliance
```

**Documentation Queries:**
```bash
/axis How do I use the data-grid component with sorting?
/axis Show me examples of axis-dropdown with search functionality
```

**Best Practices:**
```bash
/axis What's the correct API service pattern in AXIS?
/axis How do I set up AxisSharedModule?
```

**Implementation (Prompt Enricher Pattern):**

```markdown
---
argument-hint: [your request in natural language]
description: Unified command for AXIS development - intelligently routes to UI generation, code validation, documentation, and best practices
model: inherit
---

[Extended thinking: This command is the unified entry point for all AXIS development tasks.
When invoked, I enrich the user's request with context instructions and invoke the axis-router
agent. The router will then analyze the request, ADLC context (LLD/HLD/UI-TDD), detect
static vs dynamic patterns, present a plan for user approval, and delegate to the appropriate
specialized agent (axis-ui-generator, dynamic-ui-generator, axis-code-validator,
axis-documentation, or axis-development-guide).]

## Agent Invocation

Use Task tool with `subagent_type="axis-router"` with the following enriched prompt:

**Prompt Template:**
\`\`\`
## User Request
$ARGUMENTS

## Context Instructions for Router
1. **Analyze User Intent**: Determine task type from keywords:
   - create/generate/build + UI → UI generation
   - validate/check/review → Code validation
   - how to/show me → Documentation query
   - pattern/convention/setup → Best practices

2. **ADLC Required Context**:
   - Read LLD/HLD/UI-TDD if referenced
   - Detect static vs dynamic indicators
   - Discover output path (LLD → project → user)

3. **Present Plan for Confirmation**:
   - Show detected task type
   - Show selected agent
   - Show estimated output
   - WAIT for user approval

4. **Delegate to Specialized Agent**:
   - axis-ui-generator: Static Angular components
   - dynamic-ui-generator: DynamoDB-driven dynamic UI
   - axis-code-validator: AXIS compliance checking
   - axis-documentation: Component API lookup
   - axis-development-guide: Patterns and conventions
\`\`\`

**Request to process:** $ARGUMENTS
```

**Key Design Decision:** Routing logic is in the router agent, not the command. This allows the router to make context-aware decisions after exploring the codebase and reading documents.

---

## Data Flow

### 1. UI Generation from Written Specification Flow

```
User Request: "Create a registration form with name, email, country dropdown"
│
├─> Unified /axis Command
│   ├─> Analyze: UI generation request
│   ├─> Input type: Written specification
│   └─> Route to axis-ui-generator
│
├─> AXIS UI Generator
│   ├─> Invoke axis-component-selector skill
│   │   └─> Returns: axis-textbox (name, email), axis-dropdown (country), axis-button (submit)
│   │
│   ├─> Auto-reference axis-development-guide
│   │   └─> Reads: AXIS conventions, patterns, AxisSharedModule setup
│   │
│   ├─> Generate Component TypeScript
│   │   ├─> Import AxisSharedModule
│   │   ├─> Create FormGroup with validators
│   │   ├─> Implement onSubmit handler
│   │   └─> Add cross-field validation
│   │
│   ├─> Generate Component HTML
│   │   ├─> Add <axis-textbox> for name and email
│   │   ├─> Add <axis-dropdown> for country
│   │   ├─> Add <axis-button> for submit
│   │   └─> Invoke axis-accessibility-enforcer skill
│   │       └─> Returns: ARIA labels, roles, keyboard nav attributes
│   │
│   ├─> Generate Component SCSS
│   │   └─> Use AXIS CSS classes (not Bootstrap/Material)
│   │
│   └─> Invoke axis-compliance-validator skill
│       └─> Returns: Compliance report (100% pass)
│
└─> Return to User
    ├─> registration-form.component.ts
    ├─> registration-form.component.html
    ├─> registration-form.component.scss
    └─> Usage instructions
```

---

### 2. UI Generation from Visual Specification Flow

```
User Request: "Generate this dashboard screen [attach dashboard-mockup.png]"
│
├─> Unified /axis Command
│   ├─> Analyze: UI generation request with image
│   ├─> Input type: Visual specification (mockup)
│   └─> Route to axis-ui-generator with image
│
├─> AXIS UI Generator
│   ├─> Analyze Mockup Image
│   │   ├─> Identify visual elements: cards, charts, data grid
│   │   ├─> Identify layout: 3-column grid
│   │   └─> Identify data: user stats, sales chart, recent orders
│   │
│   ├─> Invoke axis-component-selector skill
│   │   └─> Returns:
│   │       ├─> axis-card (for stat cards)
│   │       ├─> axis-line-chart (for sales chart)
│   │       ├─> axis-data-grid (for orders table)
│   │
│   ├─> Generate Dashboard Component
│   │   ├─> TypeScript: Data models, API calls, chart config
│   │   ├─> HTML: Layout with AXIS components matching mockup
│   │   ├─> SCSS: Grid layout, spacing, colors matching mockup
│   │   └─> Accessibility: ARIA labels, keyboard navigation
│   │
│   └─> Validate Compliance
│       └─> Invoke axis-compliance-validator skill
│           └─> Returns: Compliance report (100% pass)
│
└─> Return to User
    ├─> dashboard.component.ts
    ├─> dashboard.component.html
    ├─> dashboard.component.scss
    └─> Component matches visual specification
```

---

### 3. Code Validation Flow

```
User Request: "Validate my dropdown component implementation"
│
├─> Unified /axis Command
│   ├─> Analyze: Code validation request
│   └─> Route to axis-code-validator
│
├─> AXIS Code Validator
│   ├─> Read Existing Code
│   │   ├─> dropdown.component.ts
│   │   ├─> dropdown.component.html
│   │   └─> dropdown.component.scss
│   │
│   ├─> Auto-reference axis-development-guide
│   │   └─> Reads: 13 mandatory conventions for validation
│   │
│   ├─> Invoke axis-compliance-validator skill
│   │   └─> Returns: Violations detected
│   │       ├─> VIOLATION 1: Missing AxisSharedModule import
│   │       ├─> VIOLATION 2: Bootstrap class used (class="btn")
│   │       ├─> VIOLATION 3: Missing ARIA labels
│   │
│   ├─> Validate Components
│   │   ├─> Check: axis-dropdown used correctly
│   │   ├─> Check: Properties match AXIS API (cross-reference axis-documentation)
│   │   └─> Check: Event bindings correct
│   │
│   ├─> Validate Accessibility
│   │   ├─> Check: ARIA labels present
│   │   ├─> Check: Keyboard navigation supported
│   │   └─> Check: Error announcements configured
│   │
│   └─> Generate Compliance Report
│       ├─> Overall Compliance: 60%
│       ├─> Violations: 3 (1 critical, 2 high)
│       ├─> Recommendations: Import AxisSharedModule, replace Bootstrap classes, add ARIA labels
│       └─> Fix code snippets
│
└─> Return to User
    └─> Detailed compliance report with actionable fixes
```

---

### 4. Documentation Query Flow

```
User Request: "How do I use the data-grid component with sorting?"
│
├─> Unified /axis Command
│   ├─> Analyze: Documentation query
│   └─> Route to axis-documentation
│
├─> AXIS Documentation Agent
│   ├─> Search 16K+ lines for "axis-data-grid"
│   │   └─> Locate: Component section with full API reference
│   │
│   ├─> Extract Relevant Information
│   │   ├─> Properties: [data], [columns], [sortable], [sortColumn]
│   │   ├─> Events: (onSort), (onRowClick)
│   │   ├─> Methods: sort(), refresh()
│   │   └─> Usage example with sorting
│   │
│   └─> Format Response
│       ├─> Property table with types and descriptions
│       ├─> Sorting configuration example
│       ├─> Complete code snippet (TypeScript + HTML)
│       └─> Accessibility notes
│
└─> Return to User
    └─> Complete documentation with usage example
```

---

## Integration Points

### Upstream Integrations

#### 1. Design Agent (UI-TDD)

**File:** `.claude_kb/workspaces/EPIC-XXX/technical/design/frontend/UI-TDD.md`

**Integration Pattern:**

design-agent generates UI-TDD → axis-tools consumes UI-TDD → generates Angular components

**UI-TDD Structure:**
```yaml
component_id: "user-profile-form"
component_name: "UserProfileFormComponent"
description: "User profile management form with personal info and preferences"

inputs:
  - name: "userId"
    type: "string"
    required: true
    description: "User identifier for loading profile data"

outputs:
  - name: "profileSaved"
    type: "EventEmitter<UserProfile>"
    description: "Emits when profile is successfully saved"

methods:
  - name: "loadUserProfile"
    params:
      - name: "userId"
        type: "string"
    returns: "Promise<UserProfile>"
    description: "Fetches user profile from backend API"

state_management:
  pattern: "reactive-forms"
  form_group: "profileForm"

validation_rules:
  - field: "email"
    validators: ["required", "email"]
    error_messages:
      required: "Email is required"
      email: "Invalid email format"

  - field: "dateOfBirth"
    validators: ["required", "minAge(18)"]
    cross_field_validation:
      - rule: "age >= 18"
        message: "User must be at least 18 years old"

pom_mappings:
  - ui_field: "firstName"
    pom_path: "applicant.personalInfo.firstName"
  - ui_field: "email"
    pom_path: "applicant.contactInfo.email"

axis_components:
  - component: "axis-textbox"
    bindings:
      label: "First Name"
      formControlName: "firstName"
      isRequired: true
```

**Consumption Pattern:**

/axis command with UI-TDD file → axis-ui-generator reads UI-TDD → Generates Angular component matching specification

---

#### 2. Product Owner (Features & PRDs)

**Integration:** Natural language feature descriptions used as input

**Example:**
"Feature: User Registration
- Form fields: First Name, Last Name, Email, Password, Country
- Validation: Email format, password strength, age verification
- Submit: Create account via POST /api/users"

---

#### 3. Tech Architect (Architecture Decisions & Technology Stack)

**Integration:** ADRs inform:
- Angular 18 framework usage
- AXIS framework v18.0.32
- Reactive forms vs template-driven forms
- State management approach

---

### Downstream Integrations

#### 1. Code Validator

**Integration:** Generated code sent for quality validation

**Validation Checks:**
- Code style (Angular best practices)
- Complexity metrics
- Duplication detection
- Test coverage

---

#### 2. Security Reviewer

**Integration:** Generated code sent for security audit

**Security Checks:**
- Input sanitization
- XSS prevention
- CSRF protection
- Authentication/authorization patterns

---

#### 3. Test Specialist

**Integration:** Integration tests for generated components

**Test Execution:**
- Component unit tests
- E2E tests
- Accessibility tests (aXe, WAVE)

---

### Lateral Integrations

#### 1. Workspace Agent

**Integration:** Use workspace templates and folder structure

**Usage:**
- Read YAML templates from `.claude_kb/templates/`
- Write Angular code to `.claude_kb/workspaces/EPIC-XXX/technical/implementation/ui/`

---

#### 2. Node.js Pair Programmer (Backend)

**Integration:** Generated UI components call Lambda APIs

**Data Flow:**
UI (axis-tools) → API Gateway → Lambda (nodejs-pair-programmer) → DynamoDB → Response → UI

---

## Error Handling Strategy

### 1. Command Router Error Handling

**Scenario:** Unable to classify request

**Handling:**
```typescript
const [classificationError, taskType] = classifyRequest(userRequest);

if (classificationError) {
  // Ask clarifying questions
  return `I'm not sure what you'd like me to do. Are you trying to:
  1. Generate a new UI component?
  2. Validate existing code?
  3. Look up component documentation?
  4. Learn about AXIS best practices?

  Please clarify your request.`;
}
```

---

### 2. UI Generator Error Handling

**Scenario:** Component selection fails (no appropriate AXIS component)

**Handling:**
```typescript
const [selectionError, components] = await invokeSkill('axis-component-selector', {
  requirements: userRequirements
});

if (selectionError) {
  logger.warn({ step: 'component-selection', error: selectionError });

  // Fall back to closest match
  const fallbackComponents = selectFallbackComponents(userRequirements);

  return `I couldn't find an exact match for your requirements. Here are the closest AXIS components:
  - ${fallbackComponents.map(c => c.name).join('\n- ')}

  Would you like me to use these components?`;
}
```

---

### 3. Code Validator Error Handling

**Scenario:** Code parsing fails

**Handling:**
```typescript
const [parseError, ast] = parseAngularCode(codeContent);

if (parseError) {
  logger.error({ step: 'parse-code', error: parseError });

  return `I encountered an error parsing your code:
  ${parseError.message}

  Please ensure the code is valid TypeScript/Angular syntax.`;
}
```

---

### 4. Documentation Agent Error Handling

**Scenario:** Component not found in documentation

**Handling:**
```typescript
const [searchError, componentDoc] = searchDocumentation(componentName);

if (searchError || !componentDoc) {
  logger.warn({ step: 'search-docs', componentName, error: searchError });

  // Suggest similar components
  const similarComponents = findSimilarComponents(componentName);

  return `I couldn't find documentation for "${componentName}". Did you mean one of these?
  - ${similarComponents.map(c => c.name).join('\n- ')}`;
}
```

---

## Security & Compliance

### 1. Input Sanitization

**Requirement:** All form inputs must be sanitized to prevent XSS attacks

**Pattern:**
```typescript
import { DomSanitizer } from '@angular/platform-browser';

export class RegistrationFormComponent {
  constructor(private sanitizer: DomSanitizer) {}

  sanitizeInput(value: string): string {
    return this.sanitizer.sanitize(SecurityContext.HTML, value);
  }

  onSubmit() {
    const sanitizedData = {
      firstName: this.sanitizeInput(this.form.get('firstName').value),
      email: this.sanitizeInput(this.form.get('email').value)
    };

    this.apiService.post('/api/users', sanitizedData);
  }
}
```

---

### 2. Accessibility Compliance (WCAG 2.1 AA)

**Requirements:**

| Guideline | Requirement | Implementation |
|-----------|------------|----------------|
| **1.1 Text Alternatives** | All images have alt text | `<img [src]="logo" alt="Company Logo">` |
| **1.3 Adaptable** | Proper heading hierarchy | `<h1>`, `<h2>`, `<h3>` in order |
| **1.4 Distinguishable** | 4.5:1 color contrast | AXIS CSS classes meet contrast requirements |
| **2.1 Keyboard Accessible** | All interactive elements keyboard accessible | Tab order, Enter/Space activation |
| **2.4 Navigable** | Skip links, focus indicators | `<a href="#main-content">Skip to content</a>` |
| **3.1 Readable** | Language specified | `<html lang="en">` |
| **3.2 Predictable** | Consistent navigation | Standard AXIS navbar pattern |
| **4.1 Compatible** | Valid HTML, ARIA | Proper ARIA roles, labels, states |

**Auto-Generated Accessibility:**
```html
<!-- Form with complete accessibility -->
<form [formGroup]="registrationForm"
      (ngSubmit)="onSubmit()"
      role="form"
      aria-label="User Registration Form">

  <!-- Text input with accessibility -->
  <axis-textbox
    [label]="'First Name'"
    [formControlName]="'firstName'"
    [isRequired]="true"
    [errorMessage]="getErrorMessage('firstName')"
    aria-label="First Name Input"
    aria-required="true"
    aria-invalid="{{firstNameControl.invalid}}"
    role="textbox">
  </axis-textbox>

  <!-- Error message announced to screen readers -->
  <div *ngIf="firstNameControl.invalid && firstNameControl.touched"
       role="alert"
       aria-live="polite">
    {{ getErrorMessage('firstName') }}
  </div>

  <!-- Submit button with accessibility -->
  <axis-button
    [label]="'Submit Registration'"
    [isDisabled]="!registrationForm.valid"
    (onClick)="onSubmit()"
    aria-label="Submit Registration Form"
    [attr.aria-disabled]="!registrationForm.valid"
    role="button">
  </axis-button>
</form>
```

---

### 3. Form Validation Security

**Requirement:** Client-side validation for UX, server-side validation for security

**Pattern:**
```typescript
// Client-side validation (UX)
registrationForm = this.formBuilder.group({
  email: ['', [Validators.required, Validators.email]],
  password: ['', [
    Validators.required,
    Validators.minLength(8),
    this.customValidators.passwordStrength
  ]],
  confirmPassword: ['', Validators.required]
}, {
  validators: this.customValidators.matchPasswords('password', 'confirmPassword')
});

// Server-side validation (security) - API call
onSubmit() {
  if (this.registrationForm.valid) {
    const userData = this.registrationForm.value;

    this.apiService.post('/api/users', userData).subscribe({
      next: (response) => {
        // Server validates again, returns success
      },
      error: (error) => {
        // Server validation failed, show errors
        this.handleServerErrors(error);
      }
    });
  }
}
```

**Note:** Never trust client-side validation alone. Server MUST validate all inputs.

---

### 4. POM Data Protection

**Requirement:** Sensitive POM data (SSN, financial info) must be handled securely

**Pattern:**
```typescript
// Sensitive fields marked and masked
export class InsuranceFormComponent {
  pom: PolicyObjectModel;

  // Mask sensitive data in UI
  maskSSN(ssn: string): string {
    return ssn.replace(/\d(?=\d{4})/g, '*');
  }

  // Encrypt sensitive data before API call
  async submitApplication() {
    const encryptedPOM = {
      ...this.pom,
      applicant: {
        ...this.pom.applicant,
        personalInfo: {
          ...this.pom.applicant.personalInfo,
          ssn: await this.encrypt(this.pom.applicant.personalInfo.ssn)
        }
      }
    };

    this.apiService.post('/api/applications', encryptedPOM);
  }
}
```

---

## Performance & Optimization

### 1. Model Selection Strategy

| Agent | Model | Rationale |
|-------|-------|-----------|
| Unified /axis Command | inherit | Simple routing logic |
| AXIS UI Generator | sonnet | Complex code generation requires advanced reasoning |
| AXIS Code Validator | haiku | Pattern matching and rule checking, cost optimization |
| AXIS Documentation | haiku | Fast lookups, retrieval task |
| AXIS Development Guide | N/A | Auto-referenced document, not an agent |

**Cost Savings:**

Using Haiku for validation and documentation reduces cost by ~80% compared to Sonnet for these tasks.

---

### 2. Lazy Loading & Code Splitting

**Pattern:**
```typescript
// app-routing.module.ts
const routes: Routes = [
  {
    path: 'registration',
    loadChildren: () => import('./registration/registration.module')
      .then(m => m.RegistrationModule)
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./dashboard/dashboard.module')
      .then(m => m.DashboardModule)
  }
];
```

**Benefits:**
- Reduces initial bundle size
- Faster initial page load
- Loads modules on-demand

---

### 3. Change Detection Strategy

**Pattern:**
```typescript
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush // Optimized change detection
})
export class UserProfileComponent {
  @Input() user: User; // Immutable input

  // Component only re-renders when input reference changes
}
```

**Benefits:**
- Reduces unnecessary re-renders
- Improves performance for large component trees

---

### 4. Virtual Scrolling for Large Lists

**Pattern:**
```html
<!-- Use AXIS data-grid with virtual scrolling -->
<axis-data-grid
  [data]="largeDataset"
  [virtualScroll]="true"
  [rowHeight]="50"
  [pageSize]="50">
</axis-data-grid>
```

**Benefits:**
- Only renders visible rows
- Handles datasets with 10K+ rows efficiently

---

### 5. Bundle Size Optimization

**Techniques:**

1. **Tree Shaking**: Remove unused code
```json
// angular.json
{
  "optimization": true,
  "buildOptimizer": true
}
```

2. **Compression**: Enable gzip/brotli
```json
// angular.json
{
  "outputHashing": "all",
  "optimization": true
}
```

3. **Image Optimization**: Use responsive images
```html
<img [src]="imagePath"
     srcset="image-320w.jpg 320w, image-640w.jpg 640w"
     sizes="(max-width: 600px) 320px, 640px"
     alt="Description">
```

---

## Testing Strategy

### 1. Component Unit Testing

**Scope:** Individual component logic

**Tools:** Jasmine, Karma

**Example Test:**
```typescript
// registration-form.component.spec.ts
describe('RegistrationFormComponent', () => {
  let component: RegistrationFormComponent;
  let fixture: ComponentFixture<RegistrationFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RegistrationFormComponent],
      imports: [ReactiveFormsModule, AxisSharedModule]
    }).compileComponents();

    fixture = TestBed.createComponent(RegistrationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create form with required fields', () => {
    expect(component.registrationForm.get('firstName')).toBeDefined();
    expect(component.registrationForm.get('email')).toBeDefined();
  });

  it('should validate email format', () => {
    const emailControl = component.registrationForm.get('email');
    emailControl.setValue('invalid-email');
    expect(emailControl.invalid).toBeTruthy();

    emailControl.setValue('valid@email.com');
    expect(emailControl.valid).toBeTruthy();
  });

  it('should validate cross-field password match', () => {
    component.registrationForm.patchValue({
      password: 'password123',
      confirmPassword: 'different'
    });

    expect(component.registrationForm.hasError('passwordMismatch')).toBeTruthy();
  });
});
```

---

### 2. Accessibility Testing

**Tools:** aXe, WAVE, Lighthouse

**Automated Checks:**
```typescript
// Install: npm install --save-dev @axe-core/playwright

import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test('should not have accessibility violations', async ({ page }) => {
  await page.goto('http://localhost:4200/registration');

  const accessibilityScanResults = await new AxeBuilder({ page }).analyze();

  expect(accessibilityScanResults.violations).toEqual([]);
});
```

**Manual Checks:**
- Keyboard navigation (Tab, Enter, Escape, Arrow keys)
- Screen reader testing (NVDA, JAWS, VoiceOver)
- Color contrast (contrast ratio >= 4.5:1)
- Focus indicators visible

---

### 3. Code Validation Testing

**Scope:** AXIS compliance validation

**Test Cases:**

| Test ID | Description | Expected Result |
|---------|-------------|-----------------|
| CV-001 | Valid AXIS component with all conventions | 100% compliance |
| CV-002 | Missing AxisSharedModule import | Critical violation detected |
| CV-003 | Bootstrap CSS classes used | High violation detected |
| CV-004 | Missing ARIA labels | High violation detected |
| CV-005 | Incorrect API service pattern | Medium violation detected |

---

### 4. Evaluation Testing

**Framework:** `evaluation/evaluate_plugins.py`

**Test Files:** `plugins/axis-tools/__tests__/*.test`

**Execution:**
```bash
# Run all tests
python evaluation/evaluate_plugins.py --plugin axis-tools

# Run specific test
python evaluation/evaluate_plugins.py --plugin axis-tools --test ui_generation_from_descriptions

# Fast iteration without scoring
python evaluation/evaluate_plugins.py --plugin axis-tools --no-scoring

# Debug mode
python evaluation/evaluate_plugins.py --plugin axis-tools --debug
```

**Example Test File:**
```
=== TEST: UI Generation from Description ===
DESCRIPTION: Validates that the plugin generates AXIS-compliant Angular components from natural language descriptions

--- ACCEPTANCE CRITERIA ---
BR1: Specification-Driven Code Generation
BR3: AXIS Framework Compliance
BR5: Accessibility by Default

--- PROMPT ---
Create a registration form with the following fields:
- First Name (required, min 2 characters)
- Last Name (required, min 2 characters)
- Email (required, valid email format)
- Country (dropdown with search, required)
- Date of Birth (datepicker, must be 18+)
- Terms checkbox (required)
- Submit button (disabled until form valid)

--- EXPECTED KEYWORDS ---
axis-textbox, axis-dropdown, axis-datepicker, axis-checkbox, axis-button, AxisSharedModule, FormGroup, Validators, aria-label, aria-required

--- END TEST ---
```

---

## Deployment & Configuration

### 1. Plugin Installation

**Method 1: Local Repository**

```bash
# Clone repository
git clone <repository-url>
cd genlite-aig-claude

# Install as Claude Code marketplace
# Add repository path to Claude Code settings
```

**Method 2: Claude Code Marketplace**

```bash
# Install from marketplace (future)
claude install axis-tools
```

---

### 2. AXIS Framework Setup

**Installation:**

```bash
# Install AXIS CLI
npm install -g @axis/cli@18.0.32

# Create new Angular project with AXIS
axis new my-app
cd my-app

# Install AXIS dependencies
npm install
```

**Configuration:**

```typescript
// angular.json
{
  "projects": {
    "my-app": {
      "architect": {
        "serve": {
          "builder": "@axis/cli:dev-server", // Use AXIS CLI
          "options": {
            "browserTarget": "my-app:build"
          }
        }
      }
    }
  }
}
```

---

### 3. AxisSharedModule Setup

**File:** `src/app/_shared/axis-shared.module.ts`

```typescript
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

// Import all AXIS components
import { AxisTextboxComponent } from '@axis/components';
import { AxisDropdownComponent } from '@axis/components';
import { AxisButtonComponent } from '@axis/components';
import { AxisDatepickerComponent } from '@axis/components';
// ... import all other AXIS components

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  exports: [
    // Export all AXIS components
    AxisTextboxComponent,
    AxisDropdownComponent,
    AxisButtonComponent,
    AxisDatepickerComponent,
    // ... export all other AXIS components
  ]
})
export class AxisSharedModule { }
```

---

### 4. Generated Component Integration

**Steps:**

1. **Generate Component:**
```bash
/axis Create a user profile form with name, email, phone
```

2. **Receive Generated Code:**
- `user-profile.component.ts`
- `user-profile.component.html`
- `user-profile.component.scss`

3. **Integrate into Project:**
```bash
# Create component directory
mkdir -p src/app/components/user-profile

# Copy generated files
cp user-profile.component.* src/app/components/user-profile/

# Import AxisSharedModule in component module
```

4. **Test Component:**
```bash
axis serve
# Navigate to http://localhost:4200
```

---

### 5. POM Integration (Insurance Domain)

**Configuration:**

```typescript
// src/app/_shared/models/pom.model.ts
export interface PolicyObjectModel {
  applicant: {
    personalInfo: {
      firstName: string;
      lastName: string;
      dateOfBirth: string;
      ssn: string;
    };
    contactInfo: {
      email: string;
      phone: string;
      address: {
        street: string;
        city: string;
        state: string;
        zipCode: string;
      };
    };
  };
  policy: {
    policyNumber: string;
    effectiveDate: string;
    expirationDate: string;
    coverageType: string;
  };
}
```

**Usage in Generated Components:**

```typescript
// Component TypeScript
import { PolicyObjectModel } from '@app/_shared/models/pom.model';

export class InsuranceFormComponent {
  pom: PolicyObjectModel;

  mapFormToPOM(): void {
    this.pom.applicant.personalInfo.firstName = this.form.get('firstName').value;
    this.pom.applicant.personalInfo.lastName = this.form.get('lastName').value;
    // ... map all fields
  }
}
```

---

## DynamoDB Data Model for Dynamic UI

This section defines the DynamoDB schema structures used for dynamic UI generation. The axis-tools plugin generates JSON schemas that are stored in these tables and consumed by Angular components at runtime.

### 14.1 Table Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DynamoDB Tables for Dynamic UI                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     ui-component-catalog                             │   │
│  │  PK: transactionType  SK: componentId                               │   │
│  │  Stores: Form layouts, field definitions, validation rules           │   │
│  │  Used by: axis-ui-generator (BR11), Angular AUG component            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              │                                               │
│                              │ References                                    │
│                              ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                   booking-reference-lookup                           │   │
│  │  PK: groupCode  SK: code                                            │   │
│  │  Stores: Dropdown options, reference data                            │   │
│  │  Used by: axis-dropdown for dynamic options                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                  booking-component-status                            │   │
│  │  PK: bookingId  SK: componentId                                     │   │
│  │  Stores: Component state, user progress                              │   │
│  │  Used by: Workflow tracking, form state persistence                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                  service-function-flows                              │   │
│  │  PK: flowId  SK: version                                            │   │
│  │  Stores: Configurable function flow definitions                      │   │
│  │  Used by: Lambda orchestration                                       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 14.2 ui-component-catalog Table

**Purpose:** Stores UI component configurations for dynamic Angular UI generation.

**Primary Key:**
- Partition Key: `transactionType` (String) - e.g., "NB", "ENDORSEMENT", or empty for common
- Sort Key: `componentId` (String) - Unique component identifier

**Attributes:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `transactionType` | S | Transaction type (NB, ENDORSEMENT, common) |
| `componentId` | S | Unique component identifier (e.g., "clientInformation") |
| `componentName` | S | Human-readable component name |
| `componentSpecifications` | M | Complete component configuration in JSON |
| `version` | S | Schema version for backward compatibility |
| `createdAt` | S | ISO timestamp of creation |
| `updatedAt` | S | ISO timestamp of last update |

**componentSpecifications Structure:**

```typescript
interface ComponentSpecifications {
  type: 'form' | 'wizard' | 'dashboard' | 'list';
  layout: 'grid' | 'flex' | 'vertical';
  backgroundColor?: string;
  sections: Section[];
  styling: ComponentStyling;
}

interface Section {
  sectionId: string;
  title: string;
  position: number;
  collapsed?: boolean;
  fields: Field[];
}

interface Field {
  fieldId: string;
  label: string;
  type: 'text' | 'email' | 'tel' | 'dropdown' | 'date' | 'checkbox' | 'button' | 'link';
  required: boolean;
  position: number;
  gridColumn?: string;
  pomPath?: string;
  refGroupCode?: string;  // For dropdown reference data
  validation?: FieldValidation;
  styling?: FieldStyling;
}

interface FieldValidation {
  pattern?: string;
  minLength?: number;
  maxLength?: number;
  min?: number;
  max?: number;
  customValidator?: string;
}

interface FieldStyling {
  width?: string;
  padding?: string;
  border?: string;
  borderRadius?: string;
  backgroundColor?: string;
}
```

**Access Patterns:**

| Pattern | PK | SK | Operation |
|---------|----|----|-----------|
| Get specific component | `{transactionType}` | `{componentId}` | GetItem |
| Get all components for transaction | `{transactionType}` | begins_with("") | Query |
| Get common components | "" (empty) | begins_with("") | Query |

### 14.3 booking-reference-lookup Table

**Purpose:** Stores reference data for dropdown options and lookups.

**Primary Key:**
- Partition Key: `groupCode` (String) - Reference group (e.g., "COUNTRY", "PRODUCT")
- Sort Key: `code` (String) - Option code

**Attributes:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `groupCode` | S | Reference group identifier |
| `code` | S | Option value/code |
| `description` | S | Display text for the option |
| `isActive` | BOOL | Whether option is active |
| `sortOrder` | N | Display order within group |
| `parentCode` | S | For hierarchical data (optional) |

**Common Reference Groups:**

| groupCode | Description | Example Values |
|-----------|-------------|----------------|
| COUNTRY | Country list | US, CA, UK, AU |
| STATE | State/Province | CA, NY, TX |
| PRODUCT | Insurance products | AUTO, HOME, LIFE |
| CLIENT_TYPE | Client types | INDIVIDUAL, CORPORATE |
| COVERAGE | Coverage types | LIABILITY, COLLISION, COMPREHENSIVE |

### 14.4 Data Flow: JSON Schema to Dynamic UI

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    JSON Schema to Dynamic UI Flow                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Phase 1: Schema Generation (BR11 - CR-001)                                 │
│  ─────────────────────────────────────────                                  │
│                                                                              │
│  UI Mockup/Screenshot                                                        │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────────┐                                                        │
│  │  axis-tools     │  Analyzes visual elements                              │
│  │  JSON Schema    │  Maps to AXIS component types                          │
│  │  Generator      │  Generates DynamoDB-compatible JSON                    │
│  └────────┬────────┘                                                        │
│           │                                                                  │
│           ▼                                                                  │
│  ┌─────────────────┐                                                        │
│  │  Generated JSON │  componentSpecifications                               │
│  │  Schema         │  with sections, fields, validation                     │
│  └────────┬────────┘                                                        │
│           │                                                                  │
│           ▼                                                                  │
│  ┌─────────────────┐                                                        │
│  │  DynamoDB       │  ui-component-catalog table                            │
│  │  Storage        │  booking-reference-lookup (dropdown data)              │
│  └────────┬────────┘                                                        │
│           │                                                                  │
│  Phase 2: Dynamic UI Rendering (BR8 - Existing)                             │
│  ─────────────────────────────────────────────                              │
│           │                                                                  │
│           ▼                                                                  │
│  ┌─────────────────┐                                                        │
│  │  Angular App    │  Fetches componentSpecifications                       │
│  │  (AUG Component)│  Renders AXIS components dynamically                   │
│  └────────┬────────┘                                                        │
│           │                                                                  │
│           ▼                                                                  │
│  ┌─────────────────┐                                                        │
│  │  Dynamic Form   │  User interacts with rendered form                     │
│  │  Rendered       │  Validation rules applied at runtime                   │
│  └─────────────────┘                                                        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## JSON Schema Generator Architecture (CR-001)

This section defines the architecture for BR11: Visual Specification to JSON Schema Generation.

### 15.1 JSON Schema Generator Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    JSON Schema Generator Architecture                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Input: UI Mockup/Screenshot (PNG, JPG, SVG, PDF)                           │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                   Visual Analysis Pipeline                            │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │   │
│  │  │  Element    │  │   Layout    │  │  Component  │  │   Field    │ │   │
│  │  │ Detection   │→ │  Analysis   │→ │   Mapping   │→ │ Generation │ │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                    Schema Generation Engine                           │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                  │   │
│  │  │  Structure  │  │  Validation │  │   Styling   │                  │   │
│  │  │  Generator  │  │  Inferrer   │  │  Extractor  │                  │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│         │                                                                    │
│         ▼                                                                    │
│  Output: DynamoDB-Compatible JSON Schema + YAML + Reports                   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 15.2 Visual Analysis Pipeline

#### Stage 1: Element Detection

**Responsibilities:**
- Analyze mockup image to identify UI elements
- Detect: text inputs, dropdowns, buttons, checkboxes, labels, sections
- Determine element boundaries and positions

**Visual Cues for Element Types:**

| Visual Pattern | Detected Element |
|----------------|------------------|
| Rectangular box with text inside | Text input |
| Box with dropdown arrow (▼) | Dropdown |
| Box with calendar icon | Date picker |
| Square/circle with checkmark | Checkbox |
| Rounded rectangle with text | Button |
| Text above input box | Label |
| Grouped inputs with header | Section |

#### Stage 2: Layout Analysis

**Responsibilities:**
- Determine grid/flex layout structure
- Calculate column counts and grid positions
- Identify section groupings
- Extract visual hierarchy

**Layout Detection:**

```typescript
interface LayoutAnalysis {
  type: 'grid' | 'flex' | 'vertical';
  columns: number;
  rows: number;
  sections: {
    title: string;
    bounds: { x: number; y: number; width: number; height: number };
    fieldCount: number;
  }[];
}
```

#### Stage 3: Component Mapping

**Responsibilities:**
- Map detected elements to AXIS component types
- Match field types based on visual characteristics
- Determine appropriate AXIS properties

**Mapping Rules:**

| Detection | Field Type | AXIS Component | Properties |
|-----------|------------|----------------|------------|
| Input + "Name" label | text | axis-textbox | label, required |
| Input + "Email" label | email | axis-textbox | pattern, validation |
| Input + "Phone" label | tel | axis-textbox | mask, pattern |
| Dropdown with arrow | dropdown | axis-dropdown | options, refGroupCode |
| Calendar icon | date | axis-datepicker | format, minDate, maxDate |
| Square checkbox | checkbox | axis-checkbox | label, checked |
| Rounded button | button | axis-button | label, onClick |

#### Stage 4: Field Generation

**Responsibilities:**
- Generate field definitions with all properties
- Assign position and grid placement
- Generate POM path placeholders
- Infer validation rules from labels/context

### 15.3 Schema Generation Engine

#### Structure Generator

Generates the overall schema structure:

```typescript
function generateSchema(
  analysis: LayoutAnalysis,
  fields: DetectedField[]
): ComponentSpecifications {
  return {
    type: 'form',
    layout: analysis.type,
    sections: generateSections(analysis.sections, fields),
    styling: generateComponentStyling(analysis)
  };
}
```

#### Validation Inferrer

Infers validation rules from field context:

| Context | Inferred Validation |
|---------|---------------------|
| Label contains "required" or "*" | `required: true` |
| Label contains "email" | `pattern: email regex` |
| Label contains "phone" | `pattern: phone regex` |
| Label contains "date" | Date format validation |
| Label contains "SSN" | `pattern: SSN format`, masking |
| Label contains "ZIP" | `pattern: postal code` |

#### Styling Extractor

Extracts visual styling from mockup:

```typescript
interface ExtractedStyling {
  primaryColor: string;      // Detected from buttons/accents
  backgroundColor: string;   // Form background
  borderColor: string;       // Input borders
  borderRadius: string;      // Corner rounding
  padding: string;           // Spacing
  fontFamily: string;        // If detectable
}
```

### 15.4 Output Generation

#### Primary Output: DynamoDB JSON Schema

```json
{
  "transactionType": "NB",
  "componentId": "auto-generated-{timestamp}",
  "componentName": "Generated Form",
  "componentSpecifications": {
    // Full schema as defined in Section 14.2
  }
}
```

#### Secondary Output: YAML Version

```yaml
transactionType: NB
componentId: clientInformation
componentName: Client Information
componentSpecifications:
  type: form
  layout: grid
  sections:
    - sectionId: clientDetails
      title: Client Information
      position: 1
      fields:
        - fieldId: clientName
          label: Client Name
          type: text
          required: true
          position: 1
          pomPath: applicant.personalInfo.clientName  # Placeholder
```

#### Tertiary Output: Field Catalog Report

```markdown
## Generated Field Catalog

| Field | Type | AXIS Component | Required | POM Path (placeholder) |
|-------|------|----------------|----------|------------------------|
| clientName | text | axis-textbox | Yes | applicant.personalInfo.clientName |
| email | email | axis-textbox | No | applicant.contactInfo.email |
| country | dropdown | axis-dropdown | No | applicant.address.country |
```

### 15.5 Plan → Confirm → Generate Workflow

The JSON Schema Generator follows the same confirmation workflow as other design agents:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                 JSON Schema Generator Workflow                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Step 1: Analyze Mockup                                                     │
│  ─────────────────────                                                      │
│  - Read mockup image                                                         │
│  - Run visual analysis pipeline                                              │
│  - Detect all elements, layout, sections                                     │
│                                                                              │
│  Step 2: Present Plan for Confirmation (REQUIRED)                           │
│  ────────────────────────────────────────────────                           │
│  ```markdown                                                                 │
│  ## JSON Schema Generation Plan                                              │
│                                                                              │
│  Based on analysis of your mockup, here's my proposed schema:               │
│                                                                              │
│  ### Layout Detected                                                         │
│  - Type: Grid (3 columns)                                                   │
│  - Sections: 2 (Client Info, Contact Details)                               │
│                                                                              │
│  ### Fields Identified                                                       │
│  | Field | Type | AXIS Component | Required |                               │
│  |-------|------|----------------|----------|                               │
│  | Client Name | text | axis-textbox | Yes |                                │
│  | Country | dropdown | axis-dropdown | No |                                 │
│  | Email | email | axis-textbox | No |                                       │
│                                                                              │
│  ### Output Files                                                            │
│  - `clientInformation-schema.json` (DynamoDB format)                        │
│  - `clientInformation-schema.yaml` (human-readable)                         │
│  - `field-catalog.md` (field summary)                                       │
│                                                                              │
│  ### Assumptions                                                             │
│  - POM paths are placeholders (need developer input)                        │
│  - Dropdown options will use refGroupCode for runtime loading               │
│                                                                              │
│  **Please confirm this plan or suggest modifications.**                     │
│  ```                                                                         │
│                                                                              │
│  Step 3: Generate Schema (After Confirmation)                               │
│  ────────────────────────────────────────────                               │
│  - Generate DynamoDB-compatible JSON                                         │
│  - Generate YAML version                                                     │
│  - Generate field catalog report                                             │
│  - Output all files                                                          │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 15.6 Integration with Existing Capabilities

```
┌─────────────────────────────────────────────────────────────────────────────┐
│              CR-001 Integration with Existing BR                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Option 1: Static Code Generation (BR2 - Existing)                          │
│  ──────────────────────────────────────────────────                         │
│                                                                              │
│  UI Mockup → axis-ui-generator → Angular Components (TS, HTML, SCSS)        │
│                                                                              │
│  Use when: UI is static, doesn't change frequently                          │
│                                                                              │
│  ─────────────────────────────────────────────────────────────────────────  │
│                                                                              │
│  Option 2: Dynamic Schema Generation (BR11 - NEW)                           │
│  ─────────────────────────────────────────────────                          │
│                                                                              │
│  UI Mockup → JSON Schema Generator → DynamoDB Schema                        │
│                    │                       │                                 │
│                    │                       ▼                                 │
│                    │              ┌─────────────────┐                       │
│                    │              │   DynamoDB      │                       │
│                    │              │   Storage       │                       │
│                    │              └────────┬────────┘                       │
│                    │                       │                                 │
│                    │                       ▼                                 │
│                    └────────────> Angular AUG Component (BR8)               │
│                                   (Dynamic Form Rendering)                   │
│                                                                              │
│  Use when: UI changes frequently, A/B testing needed, personalization       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Appendix

### A. AXIS Component Quick Reference

#### Form Controls (15 Components)

| Component | Use Case | Key Properties |
|-----------|----------|----------------|
| axis-textbox | Text input | label, placeholder, isRequired, formControlName |
| axis-dropdown | Selection from list | options, isSearchable, isMultiple |
| axis-datepicker | Date selection | minDate, maxDate, format |
| axis-checkbox | Boolean selection | isChecked, label |
| axis-button | Action trigger | label, isDisabled, onClick |

#### Layout (9 Components)

| Component | Use Case | Key Properties |
|-----------|----------|----------------|
| axis-card | Content grouping | title, headerActions |
| axis-accordion | Collapsible sections | panels, isMultiple |
| axis-modal | Dialog/popup | isVisible, title, size |
| axis-tab | Tabbed interface | tabs, activeIndex |

#### Charts (18 Components)

| Component | Use Case | Key Properties |
|-----------|----------|----------------|
| axis-pie-chart | Proportional data | data, labels, colors |
| axis-bar-chart | Categorical comparison | data, xAxis, yAxis |
| axis-line-chart | Trends over time | data, xAxis, yAxis, series |
| axis-gauge | Single metric | value, min, max, thresholds |

#### Advanced (7 Components)

| Component | Use Case | Key Properties |
|-----------|----------|----------------|
| axis-aug | Dynamic form generation | jsonConfig, onSubmit |
| axis-data-grid | Data tables | data, columns, sortable, filterable |
| axis-notifications | User alerts | message, type, duration |

---

### B. 13 Mandatory AXIS Coding Conventions Checklist

Before completion, validate ALL conventions:

- [ ] 1. **axis serve, NOT npm start** - package.json uses AXIS CLI
- [ ] 2. **Shared Code in _shared Folder** - Reusable code in `_shared/`
- [ ] 3. **AXIS CSS Classes Only** - No Bootstrap or Material classes
- [ ] 4. **API Calls Use Prototype Mode** - All HTTP calls use prototype pattern
- [ ] 5. **AUG for Dynamic Forms** - DynamoDB-driven forms use AXIS UI Generator
- [ ] 6. **Import AxisSharedModule** - All components import AxisSharedModule
- [ ] 7. **Proper Component Bindings** - AXIS-specific property names used
- [ ] 8. **Accessibility Attributes** - ARIA labels, roles, keyboard navigation
- [ ] 9. **Form Validation Pattern** - Reactive forms with custom validators
- [ ] 10. **Navigation Management** - Left/top navigation updated when adding features
- [ ] 11. **POM Field Mapping** - Form fields mapped to POM paths (if applicable)
- [ ] 12. **Error Handling** - Proper error messaging and user feedback
- [ ] 13. **No Direct DOM Manipulation** - Use Angular directives and AXIS components

---

### C. Accessibility Checklist (WCAG 2.1 AA)

- [ ] All images have alt text
- [ ] Heading hierarchy is logical (h1 → h2 → h3)
- [ ] Color contrast meets 4.5:1 ratio
- [ ] All interactive elements are keyboard accessible
- [ ] Skip links provided for main content
- [ ] Language specified in HTML tag
- [ ] Navigation is consistent across pages
- [ ] Valid HTML and ARIA attributes
- [ ] Form labels associated with inputs
- [ ] Error messages announced to screen readers
- [ ] Focus indicators visible
- [ ] No time limits on user actions (or user can extend)

---

### D. Common UI Patterns

#### Pattern 1: Registration Form
```typescript
// Generated by /axis Create a registration form
export class RegistrationFormComponent {
  registrationForm = this.formBuilder.group({
    firstName: ['', [Validators.required, Validators.minLength(2)]],
    lastName: ['', [Validators.required, Validators.minLength(2)]],
    email: ['', [Validators.required, Validators.email]],
    country: ['', Validators.required],
    dateOfBirth: ['', [Validators.required, this.minAge(18)]],
    terms: [false, Validators.requiredTrue]
  });
}
```

#### Pattern 2: Data Dashboard
```typescript
// Generated by /axis Create a sales dashboard
export class DashboardComponent {
  salesData: ChartData;
  ordersData: GridData;

  ngOnInit() {
    this.loadSalesData();
    this.loadOrdersData();
  }
}
```

#### Pattern 3: Dynamic Form (DynamoDB-driven)
```typescript
// Generated by /axis Create a dynamic insurance application form
export class InsuranceApplicationComponent {
  formConfig: DynamoDBFormConfig;

  ngOnInit() {
    this.loadFormConfig();
  }

  loadFormConfig() {
    this.dynamoService.getFormConfig('auto-insurance-v1').subscribe({
      next: (config) => {
        this.formConfig = config;
        this.renderForm();
      }
    });
  }
}
```

---

### E. Related Documents

- **Business Requirements:** `plugins/axis-tools/requirements/axis-tools-brd.md`
- **High-Level Requirements:** `plugins/axis-tools/requirements/hlr.md`
- **Development Guide:** `plugins/axis-tools/agents/axis-development-guide.md`
- **Component Documentation:** `plugins/axis-tools/agents/axis-documentation.md`
- **User Guide:** `plugins/axis-tools/README.md`
- **Acceptance Criteria:** `plugins/axis-tools/acceptance-criteria.md`

---

### F. Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Nov 24, 2025 | Jagan Mohan | Initial HLD - Complete technical architecture for axis-tools plugin. Unified /axis command routing, 4 specialized agents (UI generator, code validator, documentation, development guide), 4 Skills (component selector, compliance validator, accessibility enforcer, POM mapper), all 10 business requirements, 77 AXIS components, 13 mandatory conventions, integration points, error handling, security, accessibility (WCAG 2.1 AA), performance, testing strategy, deployment. |
| 1.1 | Nov 25, 2025 | Jagan Mohan | Added Section 14 (DynamoDB Data Model for Dynamic UI) and Section 15 (JSON Schema Generator Architecture for CR-001). Includes: ui-component-catalog table schema, booking-reference-lookup table, componentSpecifications TypeScript interfaces, visual analysis pipeline, schema generation engine, Plan→Confirm→Generate workflow, integration with existing BR2/BR8 capabilities. |
| 1.2 | Nov 25, 2025 | Jagan Mohan | Added Dynamic UI Generator Agent to Section 4 (Agent Design). Updated routing logic in /axis command to include dynamic-ui-generator for DynamoDB-driven UI generation. Added comparison table between axis-ui-generator (static) and dynamic-ui-generator (runtime). |
| 1.3 | Nov 27, 2025 | AI COE Team | **Major Update**: (1) Added axis-router agent section with Planning Router pattern, context passing specification, and 7-step workflow. (2) Updated routing logic with Enterprise UI-TDD indicators (Dynamic Form, componentConfig, POM schema, Form Specifications). (3) Updated dynamic-ui-generator with correct axis-ui-generator attributes (`[uiStructure]`, `[uiData]`, `(uiEmitUpdate)`, `(uiEmit)`), contextual naming pattern (`ui{Feature}Structure`), JSON Structure Generation from Form Specifications, and axis-datagrid for search results. |

---

## Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | Nov 24, 2025 | AI COE Team | Initial HLD |
| 1.2 | 2025-12-19 | AI COE Team | Version bump for plugin bundle release v1.2.0 |
| 1.3 | 2026-01-09 | AI COE Team | Version bump for release v1.3.0 |
| 1.4 | 2026-01-21 | AI COE Team | Version bump for unified release v1.4.0 |

---

**Document Owner:** AI COE Team & S3 Team

**Document Type:** High-Level Design (HLD)

**Status:** Pending Review

**Last Updated:** November 24, 2025
