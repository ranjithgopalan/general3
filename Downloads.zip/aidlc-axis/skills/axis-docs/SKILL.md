---
name: axis-docs
description: Axis UI component documentation with APIs and examples. Use when looking up specific Axis component properties, inputs, outputs, or usage examples.
---

# Axis UI Components Documentation

Comprehensive documentation for **78 Axis UI Angular components** (v18.0.32).

## Component Lookup

Each component file contains everything you need:
- **API Reference**: Inputs, Outputs, Methods
- **AUG JSON Structure**: For dynamic form generation
- **Examples**: TypeScript and HTML code samples

### Single Component Lookup (Recommended)

```
Read(file_path: "plugins/AIDLC-axis/skills/axis-docs/components/dropdown.md")
```

### Component Index

See [components/index.md](./components/index.md) for the full component list.

## File Structure

```
axis-docs/
├── SKILL.md              # This file
└── components/           # Individual component files (74)
    ├── index.md         # Component lookup table
    ├── dropdown.md      # API + AUG JSON + Examples
    ├── datepicker.md
    ├── datagrid.md
    └── ...
```

## Component File Structure

Each component file follows this standardized structure:

```markdown
# ComponentName

## Overview
Brief description and selector

## API Reference
### Inputs
| Property | Type | Default | Required | Description |

### Outputs
| Event | Payload | Description |

### Methods
| Method | Parameters | Returns | Description |

## AUG JSON Structure
```json
{ "type": "component", ... }
```

## Examples
### Basic Usage
```typescript / ```html

### Advanced Usage
...
```

## Common Patterns

### Importing Components
```typescript
import { AxisSharedModule } from 'axis-shared';

@Component({
  standalone: true,
  imports: [AxisSharedModule]
})
```

### Form Control Pattern
```html
<axis-dropdown [(ngModel)]="value" [dataProvider]="options" placeholder="Select..."></axis-dropdown>
```

### Event Handling Pattern
```html
<axis-button (onClick)="handleClick($event)">Submit</axis-button>
```

## Component Categories

| Category | Components |
|----------|------------|
| Form Controls | button, checkbox, radio, input, dropdown, datepicker, timepicker, slider, file-upload, editor, rating, captcha, duallist, chip |
| Layout | accordion, card, tab, modal, bottom-sheet, carousel, scroll-container |
| Navigation | navbar, breadcrumb, paginator, portal-menu, progress-step, progress-tracker |
| Charts | donut-chart, gauge-chart, funnel-chart, bubble-chart, horizontal-bar-chart, multi-bar-grouped-chart, area-plus-line-chart, bar-plus-multi-line-chart, d3-charts, word-cloud-chart |
| Data Display | datagrid, list, styled-list, tree, calendar, datamaps |
| Feedback | alert, loading, notifications, tooltip, tour, simple-feedback |
| Advanced | aug, search-account, search-address, screen-capture, bodymap |
| Utilities | customvalidators, helper-functions, cache-service, logger, json-translator, truncate |
