# Search Address

## Overview

**Component:** `search-address`
**URL:** `business-components/search-address`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-address` | `contentType` | `string` | `NA` | No | Display data in input based on type. Available options are postal_code: Displays postal code in input field. country: Displays country name in input field. |
| `axis-address` | `ariaLabel` | `string` | `NA` | No | Accessibility: Custom aria-label. |
| `axis-address` | `ariaLabelledby` | `string` | `NA` | No | Accessibility: aria-labelledby. |
| `axis-address` | `config` | `Object` | `NA` | Yes | This is the configuration object. The properties in this configuration are: 'apiKey': string - This is google api key. 'countryCode': string - This is the country code. |
| `axis-address` | `errorMessage` | `string` | `Address not recognized by Google.` | No | Defines the error message incase if the mentioned address is not recognized by Google. |
| `axis-address` | `filterStreet` | `boolean` | `false` | No | If true, it shows only street_number and route for the location instead of address. |
| `axis-address` | `layout` | `string` | `NA` | Yes | Option to display map layout view for address. NO-MAP: Map is not displayed. FULL-MAP: Display full size map. RIGHT-MAP: Display map on right side with latitude and longitude at left side. |
| `axis-address` | `required` | `boolean` | `false` | No | Defines whether it is required to search and select the address or not. true: Mandatory to search/select the address. false: Not mandatory to search/select the address. Note: Default value is set to false . |
| `axis-address` | `restrictedCountries` | `Array` | `[]` | No | A grouping of places to which you would like to restrict your results. Currently, you can use components to filter by up to 5 countries. Countries must be passed as a two character, ISO 3166-1 Alpha-2 compatible country code. Eg: ['jp','sg'] ISO 3166-1 Alpha-2 country code |
| `axis-address` | `manualAddress` | `Boolean` | `false` | No | Using [manualAddress]='true' will allow you to fill any address. Note: Default value is set to false . |
| `axis-address` | `showFormattedAddress` | `Boolean` | `false` | No | Using [showFormattedAddress]='true' will allow you to bind formatted address in input box. if false it will bind autoCompleteAddres. Note: Default value is set to false . |
| `axis-address` | `regex` | `String` | `` | No | Set regular expression on input field. Note: Default value is set to empty . |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-abc-search-address` | `addressChange` | Emits the whole data object for map when address changes. |
| `axis-abc-search-address` | `invalidAddress` | Emits an object with error and value. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "addressLookup",
  "name": "%name%",
  "componentHostClasses": "",
  "label": "Search location",
  "config": {
    "apiKey": "YOUR_GOOGLE_MAPS_API_KEY",
    "countryCode": "US"
  },
  "layout": "FULL-MAP"
}
```

---

## Examples

### Search address with restricted countries, without map, required validation and aria (template driven approach)
**Keywords:** Search address, restricted countries, no map, required validation, aria, template driven, address search, country restriction

### Search address with full map, prefilled address, aria and validation(reactive from approach)
**Keywords:** Search address, full map, prefilled address, aria, validation, reactive form, address search, map

### Search address with right side map, prefilled address, aria and validation(template driven approach)
**Keywords:** Search address, right side map, prefilled address, aria, validation, template driven, address search, map position

### Search address with unrestricted input( containing property [manualAddress]="true")
**Keywords:** Search address, unrestricted input, manual address, manual input, address search, address input, business components, address

### Search address with placeholder input( containing property [placeholder]="Enter your location")
**Keywords:** Search address, placeholder, input, enter your location, address input, address search, location placeholder



*(4 additional examples omitted for brevity. See full documentation for more patterns.)*

---
