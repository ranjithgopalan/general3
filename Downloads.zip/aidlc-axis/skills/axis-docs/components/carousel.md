# Carousel

## Overview

**Component:** `carousel`
**URL:** `components/carousel`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-carousel` | `loop` | `boolean` | `true` | No | loop='false' This property will disable the leftmost arrow when first item is visible and rightmost arrow when last item is visible |
| `axis-carousel` | `multiItemScroll` | `boolean` | `false` | No | multiItemScroll='true' This property is dependent on input loop='false' and it will replace N number of visible items with another N number of items on next click and vice versa |
| `axis-carousel` | `showIndicator` | `boolean` | `false` | No | showIndicator='false' This property hides the indicators when it is false |
| `axis-carousel` | `timing` | `string` | `750ms 50ms ease-in-out` | No | timing='750ms 50ms ease-in-out': This is default value. Carousel will transition for 750ms delaying for 50ms after click and will ease into and out of transition. |
| `axis-carousel` | `showControls` | `boolean` | `true` | No | showControls='true': This is default value. Animation buttons will be visible for user to click triggering transitions at any time. |
| `axis-carousel` | `autoScroll` | `number` | `null` | No | autoScroll='4000': If present, value must be set. Use to have the carousel automatically animate. Input value is the wait time before transition. |
| `axis-carousel` | `itemsCount` | `number` | `1` | No | [itemsCount]='2': Gives number of items to be shown at a time in carousel. By default only one item will be shown per slide. |
| `axis-carousel` | `customClass` | `string` | `NA` | No | Applies custom class to axis-carousel-item. |

### Selectors
| Component | Description |
|-----------|-------------|
| `axis-carousel` | Consists of an array of images or text based slides. |


---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "carousel",
  "name": "%name%",
  "componentHostClasses": "",
  "carouselType": {
    "id": "image",
    "name": "Image"
  },
  "options": [
    {
      "title": "./assets/images/carousel/carousel-1.jpg",
      "altText": "carousel 1",
      "heading": "This is Image 1",
      "content": "This is Image content 1"
    },
    {
      "title": "./assets/images/carousel/carousel-2.jpg",
      "altText": "carousel 2",
      "heading": "This is Image 2",
      "content": "This is Image content 2"
    },
    {
      "title": "./assets/images/carousel/carousel-3.jpg",
      "altText": "carousel 3"
    },
    {
      "title": "./assets/images/carousel/carousel-4.jpg",
      "altText": "carousel 4"
    }
  ],
  "rowsCount": 1,
  "direction": {
    "id": "horizontal",
    "name": "Horizontal"
  }
}
```

---

## Examples

### Basic usage of carousel with multiple items
**Keywords:** Carousel, basic, multiple items, slider, slides, carousel example

### Basic usage with indicators inside
**Keywords:** Carousel, indicators, inside, slider, dots, navigation

### Slides with pictures and indicators inside
**Keywords:** Carousel, pictures, images, indicators, inside, slider, slides

**TypeScript:**
```typescript
<axis-carousel class="control-light">
@for ( item of testItems; track item) {
<ng-container>
  <ng-container *carouselItem>
    <div class="axis-carousel-item-bg">
        <img  [src]="item.title">
    </div>
  </ng-container>
</ng-container>
}
</axis-carousel>
```

### Slides with pictures and content
**Keywords:** Carousel, pictures, images, content, slider, slides

**TypeScript:**
```typescript
<axis-carousel class="control-light">
@for (item of testItems; track item) {
      <ng-container>
        <ng-container *carouselItem>
          <div class="axis-carousel-item-bg">
            <img [src]="item.title">
          </div>
          <div class="axis-carousel-item-bg-content axis-carousel-item-content _text-center">
              <h3>This is headline</h3>
              <p>Lorem Ipsum</p>
          </div>
        </ng-container>
      </ng-container>
}
</axis-carousel>
```

### Slides with pictures and indicators left
**Keywords:** Carousel, pictures, images, indicators, left, slider, slides

**TypeScript:**
```typescript
<axis-carousel class="arrow-left control-light">
@for (item of testItems; track item) {
<ng-container>
  <ng-container *carouselItem>
    <div class="axis-carousel-item-bg">
      <img [src]="item.title">
    </div>
    <div class="axis-carousel-item-bg-content axis-carousel-item-content _text-center">
        <h3>This is headline</h3>
        <p>Lorem Ipsum</p>
    </div>
  </ng-container>
</ng-container>
}
</axis-carousel>
```



*(5 additional examples omitted for brevity. See full documentation for more patterns.)*

---
