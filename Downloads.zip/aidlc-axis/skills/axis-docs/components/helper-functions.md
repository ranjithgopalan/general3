# Helper Functions

## Overview

**Component:** `Helper_Functions`
**URL:** `aug-documentation/helperFunctions`

---

---

## API Reference

### Inputs

| Property | Type | Default | Required | Description |
|----------|------|---------|----------|-------------|
| *See examples below* | | | | |

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## Examples

### addElement
**Keywords:** addElement, add, element, helper function, aug, add element

### bypassEmitUpdate
**Keywords:** bypassEmitUpdate, bypass, emit update, helper function, aug, update

### checkAllInteractions
**Keywords:** checkAllInteractions, check, interactions, helper function, aug, all interactions

### createFlatModels
**Keywords:** createFlatModels, create, flat models, helper function, aug, models

### deleteAugInstance
**Keywords:** deleteAugInstance, delete, aug instance, helper function, aug, instance



*(17 additional examples omitted for brevity. See full documentation for more patterns.)*

---
