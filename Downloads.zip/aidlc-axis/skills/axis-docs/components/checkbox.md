# Checkbox

## Overview

**Component:** `checkbox`
**URL:** `components/checkbox`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-checkbox` | `ariaLabel` | `string` | `` | No | Accessibility: Custom ariaLabel. |
| `axis-checkbox` | `tabIndex` | `any` | `` | No | tabIndex is used to set tabbing order of checkbox |
| `axis-checkbox` | `checked` | `boolean` | `NA` | No | Preselects the element when the page loads. true: Preselects the element. false: Does not preselect the element. |
| `axis-checkbox` | `data-inline` | `string` | `NA` | No | Display checkbox and label order. true: Display checkbox and label in same line. |
| `axis-checkbox` | `disabled` | `boolean` | `NA` | No | Disables the element. true: Defines that the element has to be disabled. false: Keeps the elements in enabled state. Note: Default Value is set to false . |
| `axis-checkbox` | `heading` | `string` | `NA` | Yes | Represents the checkbox label. |
| `axis-checkbox` | `name` | `string` | `NA` | Yes | Defines a name for an individual checkbox element and a group of check box elements. |
| `axis-checkbox` | `required` | `boolean` | `false` | No | Defines whether it is mandatory to select the checkbox. true: Mandatory to select the check box. false: Not mandatory to select the check box. Note: Default Value is set to false . |
| `axis-checkbox` | `value` | `string` | `NA` | Yes | Defines the initial value of an element. |
| `axis-checkbox` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |
| `axis-checkbox-wrapper` | `isAllChecked` | `boolean` | `false` | No | Selects all the checkboxes. true: Selects all the check boxes. false: Does not allow to select all the check boxes. Note: Default Value is set to false . |
| `axis-checkbox-wrapper` | `isAllDisabled` | `boolean` | `false` | No | Disables all the check box elements present in a group. true: Disables the check box elements. false: Check box elements are in default state. Note: Default Value is set to false . |
| `axis-checkbox-wrapper` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-checkbox` | `changeDetect` | Notifies with the value of checkbox whenever its state changes. |
| `axis-checkbox` | `emitBlurEvent` | Notifies whenever it looses focus. |
| `axis-checkbox` | `onChangeEvent` | Notifies with the event of checkbox whenever its changes. |
| `axis-checkbox-wrapper` | `onSelect` | Notifies the attributes of the selected checkbox element/ elements from the group. Note: [{name:cbw1, value:garage, index:0}, {name:cbw1, value:kitchen, index:1}] |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-checkbox-wrapper` | `activate()` | ` NA` | `void` | Activates the checkbox. |
| `axis-checkbox-wrapper` | `disable()` | ` NA` | `void` | Disables the checkbox. |
| `axis-checkbox-wrapper` | `unCheck()` | ` NA` | `void` | Unchecks the checkbox. |
| `axis-checkbox` | `check()` | ` NA` | `void` | Checks the checkbox. |
| `axis-checkbox` | `deSelectAll()` | `NA` | `void` | Deselects all the checkboxes. |
| `axis-checkbox` | `reset()` | `NA` | `void` | Resets all the checkboxes to its default states. |
| `axis-checkbox` | `selectAll()` | `NA` | `void` | Selects all the checkboxes. |
| `axis-checkbox` | `toggleDisable()` | `NA` | `void` | Toggles disable and enable options for the checkboxes. |
| `axis-checkbox` | `toggleCheck()` | ` NA` | `void` | Toggles the state of the checkbox elements. |
| `axis-checkbox` | `toggleAllCheck()` | ` NA` | `void` | Toggles the state of all the checkbox elements present in a group. |

### Selectors
| Component | Description |
|-----------|-------------|
| `axis-checkbox-wrapper` | Container that is required to create a group of checkbox element. |
| `axis-checkbox` | Creates checkbox element. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "checkbox",
  "name": "%name%",
  "label": "Checkbox Label",
  "heading": "<span class='axis-badge _bg-success'>Apr &#8217;20</span>",
  "checkedValue": "yes"
}
```

---

## Examples

### Basic checkboxes without wrapper
**Keywords:** Checkbox, basic, no wrapper, default, checkboxes

**TypeScript:**
```typescript
<axis-checkbox [tabIndex]="1" heading="Male" name="gender" value="male"></axis-checkbox>
  <axis-checkbox [tabIndex]="3" heading="Female" name="gender" value="female"></axis-checkbox>
  <axis-checkbox [tabIndex]="2" heading="Other" name="gender" value="other"></axis-checkbox>
```

**HTML:**
```html
<axis-checkbox [tabIndex]="1" heading="Male" name="gender" value="male"></axis-checkbox>
  <axis-checkbox [tabIndex]="3" heading="Female" name="gender" value="female"></axis-checkbox>
  <axis-checkbox [tabIndex]="2" heading="Other" name="gender" value="other"></axis-checkbox>
```

### Basic checkboxes with wrapper
**Keywords:** Checkbox, basic, wrapper, default, checkboxes

**TypeScript:**
```typescript
<axis-checkbox-wrapper>
    <axis-checkbox heading="Male" name="gender" value="male" [checked]="true"></axis-checkbox>
    <axis-checkbox heading="Female" name="gender" value="female"></axis-checkbox>
    <axis-checkbox heading="Other" name="gender" value="other"></axis-checkbox>
</axis-checkbox-wrapper>
```

**HTML:**
```html
<axis-checkbox-wrapper>
    <axis-checkbox heading="Male" name="gender" value="male" [checked]="true"></axis-checkbox>
    <axis-checkbox heading="Female" name="gender" value="female"></axis-checkbox>
    <axis-checkbox heading="Other" name="gender" value="other"></axis-checkbox>
</axis-checkbox-wrapper>
```

### Checkboxes with wrapper and @for loop
**Keywords:** Checkbox, wrapper, ngFor, loop, checkboxes

**TypeScript:**
```typescript
@Component({
    ...
})
export class DefaultCheckboxComponent {
public myOptions = [0, 2 ];
public cblist:Array<any> = [
     {'name': 'gender', 'value': 'male','heading': 'male','checked': true},
     {'name': 'gender', 'value': 'female','heading': 'female','checked': false},
     {'name': 'gender', 'value': 'other','heading': 'other','checked': false}
   ];

onSelect(data){
    console.log(data);
  }

}
```

**HTML:**
```html
<form>
  <div class="axis-form-group">
    <axis-checkbox-wrapper (onSelect)="onSelect($event)">
    @for (obj of cblist; track obj) {
      <axis-checkbox [heading]="obj.heading"
        [name]="obj.name" [value]="obj.value" [checked]="obj.checked"></axis-checkbox>
    }
    </axis-checkbox-wrapper>
</div>
<div class="axis-form-group">
    <axis-checkbox-wrapper (onSelect)="onSelect($event)" name="wrapper" [ngModel]="myOptions">
    @for (obj of cblist; track obj) {
      <axis-checkbox [heading]="obj.heading"
        [name]="obj.name" [value]="obj.value"></axis-checkbox>
    }
    </axis-checkbox-wrapper>
  </div>
</form>
```

### Checkboxes without wrapper and with @for loop
**Keywords:** Checkbox, no wrapper, ngFor, loop, checkboxes

**TypeScript:**
```typescript
@Component({
    ...
})
export class DefaultCheckboxComponent {
public myOptions = [0, 2 ];
public cblist:Array<any> = [
     {'name': 'gender', 'value': 'male','heading': 'male','checked': true},
     {'name': 'gender', 'value': 'female','heading': 'female','checked': false},
     {'name': 'gender', 'value': 'other','heading': 'other','checked': false}
   ];

onSelect(data){
    console.log(data);
  }

}
```

**HTML:**
```html
@for (obj of cblist; track obj) {
  <axis-checkbox [heading]="obj.heading"
[name]="obj.name" [value]="obj.value" [checked]="obj.checked"></axis-checkbox>
  }
```

### Checked checkbox with wrapper
**Keywords:** Checkbox, checked, wrapper, selected, checkboxes

**TypeScript:**
```typescript
@Component({
    ...
})
export class DefaultCheckboxComponent {
public myOptions = [0, 2 ];
public cblist:Array<any> = [
     {'name': 'gender', 'value': 'male','heading': 'male','checked': true},
     {'name': 'gender', 'value': 'female','heading': 'female','checked': false},
     {'name': 'gender', 'value': 'other','heading': 'other','checked': false}
   ];

onSelect(data){
    console.log(data);
  }

}
```

**HTML:**
```html
<axis-checkbox-wrapper (onSelect)="onSelect($event)" [isAllChecked] = "true">
@for (obj of cblist; track obj) {
  <axis-checkbox [heading]="obj.heading"
          [name]="obj.name" [value]="obj.value"></axis-checkbox>
}
</axis-checkbox-wrapper>
```



*(26 additional examples omitted for brevity. See full documentation for more patterns.)*

---
