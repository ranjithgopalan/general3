# Input

## Overview

**Component:** `input`
**URL:** `components/input`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axisInputNumber` | `ceil` | `` | `` | No | Rounds off the decimal number, by incrementing the post decimal digit or the number itself to the assigned level. Note: Number = 55.544 ceil: -2, displays 55.55 as output. |
| `axisInputNumber` | `decimal` | `number` | `null` | No | Validates the number of digits allowed after a decimal. |
| `axisInputNumber` | `decimal_separator` | `string` | `.` | No | Defines the decimal separator. |
| `axisInputNumber` | `fraction_size ` | `string` | `null` | No | Defines number of digits to be displayed after decimal separator. |
| `axisInputNumber` | `floor` | `` | `` | No | Removes all digits occuring after the given limit in the post decimal number. Note: number = 55.546 floor: -2, displays 55.54 as output. |
| `axisInputNumber` | `max` | `number` | `null` | No | Does not allow to enter value greater than max. |
| `axisInputNumber` | `max_length` | `number` | `` | No | Specifies the maximum number of characters allowed. |
| `axisInputNumber` | `maxValue` | `number` | `null` | No | Validates the maximum value that can be entered. Note: If max = 100, and if input value = 101, then the entered value is validated only if axis-validate directive is used. |
| `axisInputNumber` | `min` | `number` | `null` | No | Validates the minimum value that can be entered. Note: If min=100, and if input value = 99, then the entered value is validated only if axis-validate directive is used. |
| `axisInputNumber` | `prefix` | `string` | `Null` | No | Defines the prefix to the input value. Note: It is used for displaying currency symbols. |
| `axisInputNumber` | `range` | `number` | `` | No | Defines the scope of values that are allowed to enter. This property works only with axis-validate directive. |
| `axisInputNumber` | `rangelength` | `number` | `` | No | Defines the scope of number of digits that are allowed to enter. This property works only with axis-validate directive. |
| `axisInputNumber` | `restrict` | `boolean` | `false` | No | Restricts the max value. true: Does not allow to enter any value beyond the max value. false: Allows any value to be entered. This property works only with axis-validate directive. |
| `axisInputNumber` | `round` | `` | `` | No | Rounds off the decimal number by the given logic. >= 0.5: rounds off the number to the next integer up to the assigned level. rounds off the number to previous integer up to the assigned level. Note: If the number = 55.568 round: -2, displays 55.57 as output. round: -1, displays 55.6 as output. If the number = 55.534, round: -2, displays 55.53 as output. round: -1, displays 55.5 as output. |
| `axisInputNumber` | `suffix` | `string` | `Null` | No | Defines the suffix to the input value. Note: List of values accepted are: k/K for Thousand, m/M for Million, b/B for Billion, t/T for Trillion, % for percentage, etc. |
| `axisInputNumber` | `thousands_separator ` | `string` | `null` | No | Defines the character displayed to separate thousands. Note: The values are separated by a ',' after every 3 digits. |
| `axisInputNumber` | `view_roundoff` | `boolean` | `false` | No | To apply round off to input value without impacting the user specified model value. Note: If view_roundoff value is true model contains user entered value and input contains rounded value. If view_roundoff value is false both model and input contains rounded value. |
| `axisInputNumber` | `noTrailingZeros` | `boolean` | `false` | No | false: To remove trailing zeros from fractional part of given number. |
| `axisInputNumber` | `isSeparaterChanged` | `boolean` | `false` | No | @deprecated false: Need to pass as true if decimal or thousand separator is other than default US. |
| `axisInputNumber` | `isSeparatorChanged` | `boolean` | `false` | No | false: Need to pass as true if decimal or thousand separator is other than default US. |
| `axis-validate` | `` | `` | `` |  | Notifies with validation of entered values. Few axisInputNumber properties can be used with this for validation. |
| `maskedInput` | `maskedInput` | `string` | `` | No | Used for providing masking feature. 1. X - Used for Alphabate only input. 2. 9 - Used for Numeric only input. 3. 0 - Used for Alphanumeric input. 4. ? - Used for optional input. 5. separator - Used for custom optional input.- eg- ?, - Note: Whatever will come after ? will be optional masking. |
| `maskedInput` | `separator` | `string` | `?` | No | separator - Used for custom optional input.- eg- ?, - Note: Whatever will come after separator(i.e. ?) will be optional masking. |
| `maskedInput` | `preserveValue` | `boolean` | `false` | No | If true, mask input field will not be cleared and mark it as invalid. Default is false. |
| `maskedInput` | `secure` | `boolean` | `false` | No | If true, only last 4 alphabet's/numbers will be displayed, rest will be replaced with 'X'. |
| `axisPolicyNumber` | `minLength` | `number` | `` | No | Specifies the minimum number of characters allowed. |
| `axisPolicyNumber` | `maxLength` | `number` | `` | No | Specifies the maximum number of characters allowed. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-input-clear` | `onClear` | Notifies with the input value when clearInputValue() is invoked. |
| `axisInputNumber` | `onModelValue` | Notifies with the input value at load/focus/blur is invoked. |
| `axisInputNumber` | `onMaxLengthExceeds` | Notifies when the input value exceeds specified max_length. Note: max_length property should be specified to emit this output event. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-input-clear` | `clearInputValue()` | `NA` | `NA` | Clears the input values and hides the clear icon. |
| `axis-input-clear` | `enableClear()` | `NA` | `NA` | Displays the clear icon when any value is entered in the input field. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "text",
  "name": "%name%",
  "label": "My Textbox",
  "placeholder": "Type Something!!!"
}
```

---

## Examples

### Default text input with prevent copy paste
**Keywords:** Input, text, textbox, prevent copy, prevent paste, copy paste, default

### Input with placeholder
**Keywords:** Input, placeholder, text, textbox, input placeholder

### Number
**Keywords:** Input, number, numeric, textbox, input number

### Password
**Keywords:** Input, password, textbox, input password, secure, hide text

### Focus state
**Keywords:** Input, focus, focus state, active, textbox, input focus



*(39 additional examples omitted for brevity. See full documentation for more patterns.)*

---
