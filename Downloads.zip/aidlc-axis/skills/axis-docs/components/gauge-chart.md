# Gauge chart

## Overview

**Component:** `gauge-chart`
**URL:** `charts/gauge-chart`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-gauge-chart` | `options` | `Object` | `` | Yes | Its an object consist of different settings for gauge chart. pointer: option to show pointer, by default it is false. gaugeLabel: option to show labels on gauge chart, by default it is true. gaugeTickMark: option to show ticks on gauge chart, by default it is true. tooltip: option to show tooltip, by default it is true. currentCaption: option to show current caption for gauge chart, it is a string. potentialCaption: option to show potential caption for gauge chart, it is a string. caption: option to show caption for gauge chart, it is a string. subCaption: option to show subcaption for gauge chart, it is a string. lowerLimit: option to provide lower limit for chart, it is a number. upperLimit: option to provide upper limit for chart, it is a number. lowerLimitDisplay: option to show lower limit of chart as label, by default it is true. upperLimitDisplay: option to show upper limit of chart as label, by default it is true. width: option to set width of the chart, it is a number. height: option to set height of the chart, it is a number. range: option to provide gradient colors for chart, it is an array. enableLazyRender: option to load charts lazily when it comes inside viewport area, it accepts boolean value and default value is false. |
| `axis-gauge-chart` | `data` | `Object` | `` | Yes | Provides the data to the gauge chart. completed: data for gauge chart, it is a number. |

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---

## Examples

### Gauge chart with scale 0-100 (without labels and tick marks)
**Keywords:** Gauge chart, scale 0-100, no labels, no tick marks, chart

### Gauge chart with scale 0-1000 (with labels and tick marks)
**Keywords:** Gauge chart, scale 0-1000, labels, tick marks, chart

### Gauge chart with scale 0-10 (with lower limit and upper limit display only)
**Keywords:** Gauge chart, scale 0-10, lower limit, upper limit, chart

### Gauge chart with scale 0-20
**Keywords:** Gauge chart, scale 0-20, chart

### Gauge chart with scale 0-100 with current and potential (with labels)
**Keywords:** Gauge chart, scale 0-100, current, potential, labels, chart



*(2 additional examples omitted for brevity. See full documentation for more patterns.)*

---
