# Progress chart

## Overview

**Component:** `progress-chart`
**URL:** `components/progress-chart`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-progress-chart` | `diameter` | `number` | `0` | No | It displays the size of the chart |
| `axis-progress-chart` | `radial` | `number` | `0` | No | It displays the radial bar width of the chart |
| `axis-progress-chart` | `showLabel` | `boolean` | `false` | No | It displays the label in center of the chart |
| `axis-progress-chart` | `percentage` | `number` | `0` | No | It displays the percentage of the chart |
| `axis-progress-chart` | `completed` | `number` | `0` | No | It displays the completed status of the chart |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|


---

---

## Examples

### Progress chart with size
**Keywords:** Progress chart, size, progress, chart, progress chart size

### Progress chart with radial
**Keywords:** Progress chart, radial, progress, chart, radial progress chart

### Progress chart with percentage
**Keywords:** Progress chart, percentage, progress, chart, percentage progress chart

### Alternative Progress Radial
**Keywords:** Progress chart, alternative, radial, alt radial, progress, chart, alternative progress chart


---

---
