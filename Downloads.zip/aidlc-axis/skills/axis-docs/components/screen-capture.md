# Screen capture

## Overview

**Component:** `screen-capture`
**URL:** `components/screen-capture`

---

---

## API Reference

### Inputs

| Property | Type | Default | Required | Description |
|----------|------|---------|----------|-------------|
| *See examples below* | | | | |

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `ScreenCaptureService` | `grabImage()` | `canvasScale, captureViewPort` | `void` | grabImage() needs to be called for capturing the screen. canvasScale: Number. Default value is 3, Optional field. This decides the canvas scale and file size depends on this. captureViewPort: Boolean. Default value is false, Optional field. |
| `ScreenCaptureService` | `getBase64Content()` | `canvasScale, captureViewPort` | `promise` | getBase64Content() needs to be called for getting Base64 encoded data of captured screen. canvasScale: Number. Default value is 3, Optional field. This decides the canvas scale and file size depends on this. captureViewPort: Boolean. Default value is false, Optional field. |


---

---

## Examples

### Grab screenshot - Window
**Keywords:** Screen capture, screenshot, window, grab screenshot, capture window, screen shot

### Grab screenshot - View port
**Keywords:** Screen capture, screenshot, viewport, view port, grab screenshot, capture viewport, screen shot

### Grab screenshot without button
**Keywords:** Screen capture, screenshot, no button, without button, grab screenshot, screen shot

### Grab screenshot base64 encoded data
**Keywords:** Screen capture, screenshot, base64, encoded data, grab screenshot, screen shot, base64 screenshot


---

---
