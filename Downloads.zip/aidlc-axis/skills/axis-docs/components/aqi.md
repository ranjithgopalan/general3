# AQI

## Overview

**Component:** `aqi`
**URL:** `components/aqi`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-aqi` | `label` | `string` | `NA` | No | Provides additional information about AQI. |
| `axis-aqi` | `attr.data-size` | `string` | `NA` | No | Changes the width and height of an AQI.Its an HTML attribute. Note: The value of size can be either default , small or large . Note: If the size is set to large , label of the corresponding AQI tier is displayed below it. |
| `axis-aqi` | `attr.data-tier` | `string` | `NA` | Yes | Defines the content to be displayed in the AQI. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `NA` | `NA` | NA |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA ` | `NA` | NA |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "aqi",
  "name": "%name%",
  "tier": "A",
  "aqiLabel": "AQI",
  "componentHostClasses": "size-large"
}
```

---

## Examples

### Simple AQI
**Keywords:** Simple AQI, aqi, basic

**TypeScript:**
```typescript
<axis-aqi [attr.data-tier]="'A'"></axis-aqi>
<axis-aqi [attr.data-tier]="'B'"></axis-aqi>
<axis-aqi [attr.data-tier]="'C'"></axis-aqi>
<axis-aqi [attr.data-tier]="'D'"></axis-aqi>
```

**HTML:**
```html
<axis-aqi [attr.data-tier]="'A'"></axis-aqi>
<axis-aqi [attr.data-tier]="'B'"></axis-aqi>
<axis-aqi [attr.data-tier]="'C'"></axis-aqi>
<axis-aqi [attr.data-tier]="'D'"></axis-aqi>
```

### Large
**Keywords:** Large, aqi, big, large size

**TypeScript:**
```typescript
<axis-aqi class="size-large" label="AQI" [attr.data-tier]="'A'"></axis-aqi>
<axis-aqi class="size-large" label="AQI" [attr.data-tier]="'B'"></axis-aqi>
<axis-aqi class="size-large" label="AQI" [attr.data-tier]="'C'"></axis-aqi>
<axis-aqi class="size-large" label="AQI" [attr.data-tier]="'D'"></axis-aqi>
```

**HTML:**
```html
<axis-aqi class="size-large" label="AQI" [attr.data-tier]="'A'"></axis-aqi>
<axis-aqi class="size-large" label="AQI" [attr.data-tier]="'B'"></axis-aqi>
<axis-aqi class="size-large" label="AQI" [attr.data-tier]="'C'"></axis-aqi>
<axis-aqi class="size-large" label="AQI" [attr.data-tier]="'D'"></axis-aqi>
```

### Small
**Keywords:** Small, aqi, small size


---

---
