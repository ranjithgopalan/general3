# Tooltip

## Overview

**Component:** `tooltip`
**URL:** `components/tooltip`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-tooltip` | `axisIncludeComponent` | `component` | `none` | No | Allows adding tooltip content from dynamic component. Note: If axisIncludeComponent is used, the property content is not required. |
| `axis-tooltip` | `nested` | `boolean` | `false` | No | To remove role attribute from tooltip. true: Remove the role from tooltip to fix ADA issue, When tooltip is used with other components like axis-button-toggle,dualList etc. false: Default control is shown. Note: Value is set to 'false' by default. |
| `axis-tooltip` | `axisIncludeTooltipComponent` | `component` | `none` | No | Allows adding tooltip content from dynamic component. Note: If axisIncludeTooltipComponent is used, the property content is not required and it is used only with dropdowns. |
| `axis-tooltip` | `color` | `string` | `default` | No | Defines the color of the tooltip: danger, info, primary (default), success, and warning. |
| `axis-tooltip` | `content` | `string` | ` none` | Yes | Defines content of the tooltip. |
| `axis-tooltip` | `data-kind` | `string` | `none` | No | Its an attribute and possible value is 'text' which applies css to the tooltip link. |
| `axis-tooltip` | `componentRef` | `any` | `none` | No | Accesses host component data from data in dynamic component (with axisIncludeComponent). Note: It can be referred as componentRef.data.attribute. Refer data and componentRef input attributes. |
| `axis-tooltip` | `closeOnOutsideClick` | `boolean` | `none` | No | Removes tooltip content from dynamic component when user clicks outside of tooltip's contents. |
| `axis-tooltip` | `data` | `any` | `none` | No | Defines the objects required to establish communication between dynamic component(with axisIncludeComponent) and host component. Note: The object encapsulates data and methods that are need to be accessed in dynamic component. |
| `axis-tooltip` | `context` | `any` | `none` | No | Defines the context that can be passed to dynamic component(with axisIncludeComponent) from parent component. |
| `axis-tooltip` | `isOpen` | `boolean` | `false` | No | Enables or disables the tooltip. true: Enables the tooltip. false: Disables the tooltip. Note: Value is set to false by default. |
| `axis-tooltip` | `isToggleOnClick` | `string` | `none` | No | Defines whether to enable or disable the tooltip on mouseover or mouse click. true: Enables the tooltip on click and disables mouseover. false: Disables the tooltip on click and enables mouse over. |
| `axis-tooltip` | `minwidth` | `string` | `none` | Yes | Defines the minimum width of the tooltip. Note: Width should be defined in pixels (for example: width="450 px"). |
| `axis-tooltip` | `placement` | `string` | `right` | No | Positions the tooltip. Note: It can have the following values: top, bottom, left, right, auto. Value is set to right by default. If placement is set to auto, the position of tooltip can be dynamically reoriented. |
| `axis-tooltip` | `tooltipTrigger` | `string` | `none` | No | Disables the mouseover and click events. The tooltip is displayed based on the openFlag status. None: Mouse over and click events are disabled. Note: Default value is undefined. This is used for action tooltips. |
| `axis-tooltip` | `width` | `string` | `none` | No | Defines the maximum width of the tooltip's contents. |
| `axis-tooltip` | `changeDetectorRef` | `changeDetectorRef` | `none` | No | Trigger change detection when the tooltip is used in ChangeDetectionStrategy.OnPush component |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `onClose` | `Void` | Notifies on removal of the tooltip. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-tooltip` | `close()` | `NA` | `void` | Closed tooltip. |
| `axis-tooltip` | `removeTooltipOnBlur()` | `NA` | `void` | Hide tooltip on blur effect. |
| `axis-tooltip` | `toggleTooltip()` | `event` | `void` | This will hide and show tooltip. |
| `axis-tooltip` | `removeTooltipOnKeydown()` | `NA` | `void` | Hide tooltip on keydown event. |
| `axis-tooltip` | `removeTooltipOnMouseout()` | `NA` | `void` | Hide tooltip on mouse leave event. |
| `axis-tooltip` | `appendTooltipOnMouseover()` | `event` | `void` | Add tooltip on mouse over event. |
| `axis-tooltip` | `checkTooltipWithTruncate()` | `NA` | `void` | This will check if axis-truncate directive is applied and need to show tooltip or not. |
| `axis-tooltip` | `addDocumentListener()` | `NA` | `void` | Add accessibility changes for tolltip. |
| `axis-tooltip` | `createTooltipInstance()` | `event` | `void` | Create new instance of tooltip. |
| `axis-tooltip` | `addAdaChanges()` | `NA` | `void` | This will return native element of tooltip. |
| `axis-tooltip` | `deleteTooltipInstance()` | `NA` | `void` | Delete tooltip instance which is avaialble in DOM. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "tooltip",
  "name": "%name%",
  "content": "<ul><li><em>This is my simple <strong>HTML</strong> tooltip.</em></li><li>You can provide any html or any custom component name in axisIncludeComponent property of your tooltip json.</li></ul>",
  "tooltipType": {
    "id": "icon",
    "name": "Icon"
  },
  "iconName": "info",
  "icon": {
    "componentHostClasses": "Dynamic classes- kind-icon size-small _bg-success"
  },
  "button": {
    "componentHostClasses": "Dynamic classes- kind-icon size-small _bg-success"
  },
  "placement": {
    "id": "right",
    "name": "Right"
  }
}
```

---

## Examples

### Basic tooltip
**Keywords:** Tooltip, basic, hover, info, popup, hint

**TypeScript:**
```typescript
import {Component} from "@angular/core";
@Component({
    templateUrl:"./demo.html"
})
export class ToggleTooltipDemo{
    constructor() { }
}
```

**HTML:**
```html
<span axis-tooltip id="tooltip" content="This is a tooltip.">
    <axis-icon icon="help"></axis-icon>
</span>
```

### Basic tooltip with focus
**Keywords:** Tooltip, focus, hover, info, popup, hint

**TypeScript:**
```typescript
import {Component} from "@angular/core";
@Component({
    templateUrl:"./demo.html"
})
export class ToggleTooltipDemo{
    constructor() { }
}
```

**HTML:**
```html
<span tabindex="0" axis-tooltip id="tooltip" content="This is a tooltip.">
    <axis-icon icon="help"></axis-icon>
</span>
```

### ChangeDetectionStrategy.OnPush component with tooltip
**Keywords:** Tooltip, change detection, OnPush, component, performance

**TypeScript:**
```typescript
import {Component, ChangeDetectionStrategy, ChangeDetectorRef} from "@angular/core";
@Component({
    templateUrl:"./demo.html",
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ToggleTooltipDemo{
    constructor(public changeDetectorRef: ChangeDetectorRef) { }
}
```

**HTML:**
```html
<span tabindex="0" axis-tooltip [changeDetectorRef]="changeDetectorRef" id="tooltip" content="This is a tooltip.">
    <axis-icon icon="help"></axis-icon>
</span>
```

### Action tooltip
**Keywords:** Tooltip, action, button, popup, hint, interactive

**TypeScript:**
```typescript
import { Component } from '@angular/core';
import { ActionDemoTemplateComponent } from './action-demo-template';
@Component({
    ...
})

export class yourComponentName {
  public openFlag:boolean = false;
  public name = 'AIG';
  public componentData = {
        toolTipName: "",
        initialData: this.name,
        openTooltip: () => {
            this.openFlag = true;
            this.componentData.toolTipName = this.name;
        },
        inputComponent: ActionDemoTemplateComponent,
        closeTooltip: () => {
            this.openFlag = false;
        },
        restoreTooltip: () => {
            this.componentData.toolTipName = this.componentData.initialData;
        },
        saveTooltip:(tooltipInputName)=>{
            //handle other functionality
            this.name = tooltipInputName.value;
            this.openFlag = false;
        }
    }
}
```

**HTML:**
```html
<ul class="axis-list-inline">
  <li>
      <button (onClose)="componentData.closeTooltip()" [data]="componentData" [isOpen]="openFlag" axis-tooltip
        [axisIncludeComponent]="componentData.inputComponent" id="tooltip" tooltipTrigger="none" width="300px" axis-button
        class="kind-link" (click)="componentData.openTooltip()">{{name}}</button>
  </li>
  <li>
      <button [data]="tooltipImportData" [isOpen]="openFlag5" axis-tooltip
        [axisIncludeComponent]="tooltipImportData.inputComponent" id="tooltip" placement="bottom" tooltipTrigger="none"
        width="300px" axis-button class="kind-icon" title="Import from eStart" (click)="tooltipImportData.openTooltip()">
        <axis-icon icon="import_export"></axis-icon>
      </button>
  </li>
</ul>
```

### Action tooltip with dropdown
**Keywords:** Tooltip, action, dropdown, popup, hint, interactive



*(34 additional examples omitted for brevity. See full documentation for more patterns.)*

---
