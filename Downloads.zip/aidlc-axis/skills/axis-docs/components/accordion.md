# Accordion

## Overview

**Component:** `accordion`
**URL:** `components/accordion`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-accordion-wrapper` | `ucid` | `string` | `NA` | No | Required to generate a unique component id for ARIA features. |
| `axis-accordion-wrapper` | `active` | `boolean` | `NA` | No | Opens or Closes an item. true: Opens the corresponding item. false: Closes the corresponding item. Note: Value is set to true by default. |
| `axis-accordion-wrapper` | `data-nested` | `boolean` | `NA` | No | For nested accordions. true: Shows nested accordions with proper styling |
| `axis-accordion-wrapper` | `data-control` | `string` | `left` | No | Defines location of the open/close icon of each accordion item. Note: Position can be on left or right of the item. |
| `axis-accordion-wrapper` | `disabled` | `boolean` | `NA` | No | Disables or enables the Accordion headers. true: Disables the Accordion header. false: Keeps the Accordion header in its enabled state. |
| `axis-accordion-wrapper` | `<span class='axis-badge badge-color-orange'>@deprecated<br></span></br><strike>heading</strike>` | `string` | `NA` | Yes | Defines the accordion heading text. |
| `axis-accordion-group-wrapper` | `closeOthers` | `boolean` | `false` | No | Closes other accordion items by clicking on a single item. true: Closes the other accordion items. false: Does not effect the state of other accordion items. Note: Value is set to false by default. |
| `axis-accordion-group-wrapper` | `font` | `string` | `custom` | No | Defined to load icon styles from material library or custom library. Note: The value need to be configured as font='material' for material icons. |
| `axis-accordion-group-wrapper` | `customIcon` | `Object` | `null` | No | Used to load custom icon for exmpand and collapse. customIcon = { collapsed:'add_circle_outline', expanded:'do_not_enter' }; |
| `axis-expand-collapse-right` | `collapseText` | `string` | `Collapse All` | No | Displays link to hide an accordion group when all accordion items are open. Note: Default value is set to 'Collapse All' . |
| `axis-expand-collapse-right` | `expandText` | `string` | `Expand All` | No | Displays link to open accordion group when at least one accordion is closed. Note: Default value is set to 'Expand All' . |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-accordion-group-wrapper` | `<p>onGroupAccordionChange</p>` | Notifies with the change of state in an accordion item. Note: Values passed through this event are true or false . |
| `axis-accordion-wrapper` | `<p>onAccordionChange</p>` | Emits index on expand/collapse of accordion. |
| ` axis-expand-collapse-right` | `<p>onGroupAccordionChange</p>` | Notifies with the change of state in an accordion item. Note: Values passed through this event are true or false . |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-accordion-group-wrapper` | `toggleAll()` | `NA` | `void` | Toggles state each item of an accordion group to expand or collapse, based on its present state. |
| `axis-expand-collapse-right` | `<p>expandCollapse($event)</p>` | `event` | `void` | Toggles the accordion items. |

### Selectors
| Component | Description |
|-----------|-------------|
| `axis-accordion-group-wrapper` | Consists of a set of accordion items. Note: This selector is a wrapper class for all axis-accordion-wrapper items. |
| `axis-accordion-wrapper` | Represents an accordion item. Note: This selector is a wrapper class for axis-accordion-heading, axis-accordion-body, axis-expand-collapse-right, axis-accordion-heading-right . |
| `axis-accordion-heading-right` | Displays additional icons on the right part of the heading. |
| `axis-expand-collapse-right` | Provides 'Expand All' and 'Collapse All' option to the accordion group. |
| `axis-accordion-body` | Displays the accordion content. |
| `axis-accordion-heading` | Displays the accordion heading. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "accordion",
  "name": "%name%",
  "label": "My Accordion:",
  "heading": {
    "id": "left",
    "name": "Left"
  },
  "groups": [
    {
      "heading": "1. Accordion with Plain text",
      "content": "Accordion with plain text content... you can drop any component inside any accordion",
      "active": true,
      "ucid": "accr-1"
    },
    {
      "heading": "2. Accordion with components",
      "active": false,
      "ucid": "accr-2",
      "nested": true,
      "content": [
        {
          "type": "card",
          "vcard": "card-group",
          "name": "userInfoCard",
          "size": "a",
          "fields": [
            {
              "type": "content",
              "vcard": "content",
              "value": "User Information",
              "kind": "h5",
              "size": "a",
              "name": "userInfoContent"
            },
            {
              "type": "text",
              "vcard": "text",
              "size": "b",
              "label": "First Name",
              "name": "userFirstName",
              "placeholder": "Enter first name",
              "required": "true",
              "inputClear": "true",
              "inputType": "text",
              "minLength": 3,
              "autocomplete": "off",
              "errorMessages": {
                "required": "first name is required."
              }
            },
            {
              "type": "text",
              "vcard": "text",
              "size": "b",
              "label": "Last Name",
              "name": "userLastName",
              "placeholder": "Enter last name",
              "required": "true",
              "inputClear": "true",
              "inputType": "text",
              "autocomplete": "off",
              "errorMessages": {
                "required": "last name is required."
              }
            },
            {
              "type": "text",
              "vcard": "text",
              "size": "e",
              "label": "User Age",
              "name": "userAge",
              "placeholder": "Enter age",
              "axisSettings": {
                "max": 100,
                "round": "-2",
                "restrict": true,
                "suffix": "",
                "decimal_separator": ".",
                "thousands_separator": ",",
                "fraction_size": null,
                "min": "",
                "prefix": "",
                "reg_exp": "",
                "decimal": "",
                "max_length": "",
                "view_roundoff": false
              },
              "required": "true",
              "inputClear": "true",
              "inputType": "text",
              "autocomplete": "off",
              "errorMessages": {
                "required": "age is required."
              }
            },
            {
              "type": "text",
              "vcard": "text",
              "size": "b",
              "inputType": "email",
              "label": "User email",
              "placeholder": "Enter email",
              "name": "userEmail",
              "inputClear": "true",
              "autocomplete": "off"
            },
            {
              "type": "text",
              "vcard": "text",
              "size": "c",
              "label": "User Phone",
              "name": "userPhone",
              "placeholder": "Enter phone number",
              "axisSettings": {
                "reg_exp": "^\\d{1,10}$",
                "decimal_separator": ".",
                "fraction_size": null,
                "max": "",
                "min": "",
                "prefix": "",
                "suffix": "",
                "thousands_separator": "",
                "decimal": "",
                "restrict": false,
                "max_length": "",
                "view_roundoff": false
              },
              "inputClear": "true",
              "inputType": "text",
              "autocomplete": "off"
            }
          ],
          "sectionName": "form1"
        }
      ],
      "badge": {
        "cssClass": "axis-badge",
        "type": "untouched,error",
        "isPositionLeft": true,
        "showCount": true,
        "icon": true,
        "iconError": "error",
        "iconUntouced": "info",
        "iconSuccess": "check",
        "hideOnZero": false,
        "content": "",
        "isVisible": true
      }
    },
    {
      "heading": "3. Accordion with components/charts",
      "active": false,
      "ucid": "accr-3",
      "content": [
        {
          "type": "datepicker",
          "name": "iterationStartDate",
          "label": "Iteration Start Date:",
          "vcard": "datepicker",
          "size": "c",
          "isReadOnly": "true",
          "datepickerMode": "day"
        },
        {
          "type": "datepicker",
          "name": "iterationEndDate",
          "label": "Iteration End Date:",
          "vcard": "datepicker",
          "size": "c",
          "isReadOnly": "true",
          "datepickerMode": "day"
        },
        {
          "type": "datepicker",
          "name": "analysisMonth",
          "label": "Analysis Month:",
          "vcard": "datepicker",
          "size": "c",
          "isReadOnly": "true",
          "datepickerMode": "month"
        },
        {
          "type": "content",
          "name": "analysisTitle",
          "value": "Iteration Data Analysis:",
          "kind": "h5",
          "size": "a",
          "vcard": "content"
        },
        {
          "type": "horizontalBarChart",
          "name": "analysisHorizontalBarChart",
          "chartData": [
            {
              "label": "7",
              "labels": [
                "80",
                "8"
              ],
              "tooltips": [
                "80",
                "8"
              ],
              "values": [
                80,
                8
              ]
            },
            {
              "label": "7",
              "values": []
            },
            {
              "label": "6",
              "labels": [
                "20",
                "10"
              ],
              "tooltips": [
                "20",
                "10"
              ],
              "values": [
                20,
                10
              ]
            },
            {
              "label": "6",
              "values": []
            },
            {
              "label": "5",
              "labels": [
                "30",
                "5"
              ],
              "tooltips": [
                "30",
                "5"
              ],
              "values": [
                30,
                5
              ]
            },
            {
              "label": "5",
              "values": []
            },
            {
              "label": "4",
              "labels": [
                "40",
                "0"
              ],
              "tooltips": [
                "40",
                "0"
              ],
              "values": [
                40,
                0
              ]
            },
            {
              "label": "4",
              "values": []
            },
            {
              "label": "3",
              "labels": [
                "50",
                "4"
              ],
              "tooltips": [
                "50",
                "4"
              ],
              "values": [
                50,
                4
              ]
            },
            {
              "label": "3",
              "values": []
            },
            {
              "label": "2",
              "labels": [
                "60",
                "3"
              ],
              "tooltips": [
                "60",
                "3"
              ],
              "values": [
                60,
                3
              ]
            },
            {
              "label": "2",
              "values": []
            },
            {
              "label": "1",
              "labels": [
                "70",
                "2"
              ],
              "tooltips": [
                "70",
                "2"
              ],
              "values": [
                70,
                2
              ]
            },
            {
              "label": "1",
              "values": []
            }
          ],
          "options": {
            "bars": {
              "labelLeft1": "Planned Stories",
              "labelRight1": "Completed Stories"
            },
            "narrow": true,
            "xAxis": {
              "axisLabel": "User Story Points"
            },
            "yAxis": {
              "axisLabel": "Iterations"
            },
            "yWidth": 14,
            "showLegend": false,
            "clickableBars": true
          },
          "vcard": "horizontal-bar-chart",
          "size": "a"
        }
      ],
      "badge": {
        "cssClass": "axis-badge",
        "type": "untouched,error",
        "isPositionLeft": true,
        "showCount": true,
        "icon": true,
        "iconError": "error",
        "iconUntouced": "info",
        "iconSuccess": "check",
        "hideOnZero": false,
        "content": "",
        "isVisible": true
      }
    },
    {
      "heading": "4. Disabled Accordion",
      "content": "disabled accordion...",
      "disabled": true,
      "ucid": "accr-4"
    }
  ]
}
```

---

## Examples

### Static content
**Keywords:** Accordion, static, content, panel, expand, collapse, section

### Static content with single accordion open at once
**Keywords:** Accordion, single open, one at a time, static, panel, expand, collapse

### Disabling closure of other accordion items
**Keywords:** Accordion, disable close, keep open, multiple open, collapse, expand

### Opening an accordion item with external button
**Keywords:** Accordion, external button, open, expand, trigger, control

### Closing an accordion item with external button
**Keywords:** Accordion, external button, close, collapse, trigger, control



*(14 additional examples omitted for brevity. See full documentation for more patterns.)*

---
