# Multi bar grouped chart

## Overview

**Component:** `multi-bar-grouped-chart`
**URL:** `charts/multi-bar-grouped-chart`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-chart-bar-multi-grouped` | `options` | `Object` | `` | Yes | Its an object consist of different settings for bar plus multi line grouped chart. xAxisLabel: option to provide x axis label, it is a string. yAxisLabel: option to provide left side y axis label, it is a string. clickableBars: option to make bar clickable, by default it is false. selectableBars: option to make bar selectable, by default it is false. gradient: option to provide gradient color in bar, it is an array. barsLabels: option to provide legend name for bars, it is an array of string. numTicks: option to provide number of ticks needed on y axis, by default it is 5. yTickValues: option to provide custom values for positioning ticks on y axis, it is an array of numbers. customTooltip: option to provide custom data for tootlip colors: option to show colors for every value in the chart, it is a Array. gradients: option to provide gradient color in the bars , it is an array. showLegend: option to show legend, by default it is 'bottom'. To hide, pass false. showTooltips: option to show tooltip on bars of chart, by default it is true. animation: option to provide animation for chart, it is a boolean. gridLines: gridLines: option to show grid lines, by default it is true. showValuesOnBar: to show values on bar, by default it is true. hideBadgeColor: to hide badge color in tooltip, by default it is true. hideYaxisLabels: to hide y-axis labels text, by default it is true. valueFormat: to format the value on bar. |
| `axis-chart-bar-multi-grouped` | `data` | `Array` | `` | Yes | Provides display data to the charts. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-chart-bar-multi-grouped` | `showSelection` | It displays chartdata. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---

## Examples

### Bar chart with multi grouped
**Keywords:** Bar chart, multi grouped, grouped, bar chart


---

---
