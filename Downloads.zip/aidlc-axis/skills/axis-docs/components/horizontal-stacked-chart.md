# Horizontal stacked chart

## Overview

**Component:** `horizontal-stacked-chart`
**URL:** `charts/horizontal-stacked-chart`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-horizontal-stacked-chart` | `data` | `Array` | `` | Yes | Provides display data to the chart. color color can be passed in data object to show colors that needs to be shown. |
| `axis-horizontal-stacked-chart` | `options` | `Object` | `` | No | Its an object consist of different settings for funnel chart. enableLazyRender: option to load charts lazily when it comes inside viewport area, it accepts boolean value and default value is false. height: to set height of chart width: to set width of chart customTooltip: User can change the tooltip format. bufferSpace: number - Option to set the adjust the chart properly within space, by default it is 40. margin: object - Option to change position of chart. valueFormat: function - Option to change value formathe chart. ticksFormat: function - Option to change the ticks of x-axis . animation: object - Option to change animation of the chart, by default it is enabled as true it had options like duration,easing etc. labelPosition: number - Option to adjust labels properly, by default it is 0.32em. truncate: Object - Option to show truncate to labels, by default it is true. barHeight: number - Option to increase/decrease height of bar, by default it is 0. fontSize: string - Option to change font size of text, by default it is 12px. |


---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## Examples

### Horizontal stacked chart
**Keywords:** Horizontal stacked chart, stacked chart, horizontal, chart

### Horizontal stacked chart with enableLazyRender
**Keywords:** Horizontal stacked chart, lazy render, stacked chart, horizontal, chart


---

---
