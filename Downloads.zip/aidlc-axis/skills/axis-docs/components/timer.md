# Timer

## Overview

**Component:** `timer`
**URL:** `components/timer`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-timer` | `daysToCount` | `string` | `` | No | Number of days of timer. |
| `axis-timer` | `dateToEnd` | `Date` | `` | No | Timer end date. |
| `axis-timer` | `type` | `string` | `days` | No | Used to show hide days, hours, minutes and seconds section. days: Disaplays days, hours, minutes and seconds. hours: Disaplays hours, minutes and seconds. minutes: Disaplays minutes and seconds. seconds: Disaplays seconds only. |
| `axis-timer` | `customMessage` | `string` | `Please provide future date.` | No | Added customMessage input to show the error message in case of previous date provided. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-timer` | `start()` | `NA` | `void` | Starts/restarts timer. |
| `axis-timer` | `stop()` | `NA` | `void` | Stops timer. |


---

---

## Examples

### Days timer
**Keywords:** Timer, days timer, countdown, days, timer example

**TypeScript:**
```typescript
<button
    axis-button
    "kind-primary"
    (click)="timer.start()"
>Start</button>
<button
    axis-button
    class="kind-primary"
    (click)="timer.stop()"
>Stop/Reset</button>
<axis-timer #timer [daysToCount]="daysToCount"></axis-timer>
```

### Date timer
**Keywords:** Timer, date timer, countdown, date, timer example


---

---
