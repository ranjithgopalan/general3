# Can Deactivate

## Overview

**Component:** `can-deactivate`
**URL:** `components/can-deactivate`

---

---

---

## API Reference

### Inputs

| Property | Type | Default | Required | Description |
|----------|------|---------|----------|-------------|
| *See examples below* | | | | |

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `CanDeactivateService` | `canDeactivate` | `` | `Boolean` | Get the component status whether its dirty or not based on which navigation change can be handled. |
| `CanDeactivateService` | `canDeactivate(true/false)` | `Boolean` | `void` | Set the component status to true if there is any change in the user inputs(form dirty) |
| `CanDeactivateService` | `containerElementViewRef` | `ViewContainerRef` | `void` | Set the container(parent/app) component reference to attach the modal |
| `CanDeactivateService` | `config` | `{headerMessage: string; bodyMessage: string;}` | `void` | Set the modal header and body texts |


---

---

## Examples

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `CanDeactivateService` | `canDeactivate` | `` | `Boolean` | Get the component status whether its dirty or not based on which navigation change can be handled. |
| `CanDeactivateService` | `canDeactivate(true/false)` | `Boolean` | `void` | Set the component status to true if there is any change in the user inputs(form dirty) |
| `CanDeactivateService` | `containerElementViewRef` | `ViewContainerRef` | `void` | Set the container(parent/app) component reference to attach the modal |
| `CanDeactivateService` | `config` | `{headerMessage: string; bodyMessage: string;}` | `void` | Set the modal header and body texts |


---

---
