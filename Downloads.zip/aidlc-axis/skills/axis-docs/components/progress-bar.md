# Progress bar

## Overview

**Component:** `progress-bar`
**URL:** `components/progress-bar`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-progressbar,[axis-progressbar]` | `counter` | `string` | `false` | No | Displays the value of the progress bar counter in different formats. true: Progress bar counter is displayed as a fraction of counter value and maximum value. false: Progress bar counter is not displayed. percent: Progress bar counter is displayed as a percentage of counter value and percentage value. Note: Default value is set to false . |
| `axis-progressbar,[axis-progressbar]` | `kind` | `String` | `NA` | No | Stops the current progress action by invoking enableCancelfeature method and restarts the progress bar. Note: To stop the progress bar, this value is passed: data-kind= 'cancel' . |
| `axis-progressbar,[axis-progressbar]` | `data-chart-bg` | `String` | `NA` | Yes | Assigns color to the progress bar based on the code fetched from the CSS format. Note: Here are the color codes: data-chart-bg="color-1" : blue data-chart-bg="color-2" : amber data-chart-bg="color-3": green data-chart-bg="color-4" : dark blue data-chart-bg="color-5" : black data-chart-bg="color-6" : grey data-chart-bg="color-7" : light blue data-chart-bg="color-8" : light yellow data-chart-bg="color-9" : light green |
| `axis-progressbar,[axis-progressbar]` | `class='_bg-colorName'` | `String` | `NA` | No | Assigns color to the progress bar based on the css format. Note: These are the color codes: class="_bg-success": dark green class="_bg-danger": red class="_bg-info":_bg-blue class="warning": amber |
| `axis-progressbar,[axis-progressbar]` | `max` | `number` | `NA` | Yes | Defines the maximum value of the progress bar counter. |
| `axis-progressbar,[axis-progressbar]` | `value` | `number` | `0` | Yes | Defines the progress bar value. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `NA` | `NA` | NA |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-progressbar` | `cancelProgressBar()` | `NA` | `void` | Stops the dynamic progess bar. |
| `axis-progressbar` | `enableCancelFeature()` | `NA` | `void` | Enables the cancelProgressBar() method. |


---

---

## Examples

### Static progress bar
**Keywords:** Progress bar, static, progress, bar, default, basic

**TypeScript:**
```typescript
<axis-progressbar [value]="75"></axis-progressbar>
```

**HTML:**
```html
<axis-progressbar [value]="75"></axis-progressbar>
```

### In percentage
**Keywords:** Progress bar, percentage, progress, bar, percent, static

**TypeScript:**
```typescript
<axis-progressbar [value]="35" counter="percent"></axis-progressbar>
```

**HTML:**
```html
<axis-progressbar [value]="35" counter="percent"></axis-progressbar>
```

### Max value
**Keywords:** Progress bar, max value, maximum, progress, bar, static

**TypeScript:**
```typescript
<axis-progressbar [value]="22" counter="true" [max]="75"></axis-progressbar>
```

**HTML:**
```html
<axis-progressbar [value]="22" counter="true" [max]="75"></axis-progressbar>
```

### Color 1
**Keywords:** Progress bar, color, color 1, chart color, progress color, bar color, color example

### Color 2
**Keywords:** Progress bar, color, color 2, chart color, progress color, bar color, color example



*(18 additional examples omitted for brevity. See full documentation for more patterns.)*

---
