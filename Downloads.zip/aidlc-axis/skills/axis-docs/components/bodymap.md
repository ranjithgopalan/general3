# Bodymap

## Overview

**Component:** `bodymap`
**URL:** `charts/bodymap`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-bodymap-chart` | `data` | `Array` | `` | Yes | Provides display data to the chart. color: changes the color of the badge in which it is applied. |
| `axis-bodymap-chart` | `options` | `Object` | `` | No | Its an object consist of different settings for body map chart. legend: option to update different properties of legend like color, lineColor. It is an object. |
| `axis-bodymap-chart` | `randomString` | `String` | `` | No | chart will be re-drawn if the value of random sting changes. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|


---

---

## Examples

### Default body map chart
**Keywords:** Bodymap, body map chart, default, chart, map

### Body map chart with custom legend
**Keywords:** Bodymap, body map chart, custom legend, chart, map, legend


---

---
