# Scroll container

## Overview

**Component:** `scroll-container`
**URL:** `components/scroll-container`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-scroll-container` | `data-border` | `boolean` | `false` | No | Defines the border for container |
| `axis-scroll-container` | `data-size` | `string` | `` | No | Defines the size of the scroll for container Options : small, large . |


---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## Examples

### Scroll container - Basic
**Keywords:** Scroll container, basic, scroll, container, default, simple

### Scroll container with border
**Keywords:** Scroll container, border, scroll, container, with border, outline

### Scroll container - Size (small)
**Keywords:** Scroll container, small, size, scroll, container, compact

### Scroll container - Size (large)
**Keywords:** Scroll container, large, size, scroll, container, big


---

---
