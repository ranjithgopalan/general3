# D3 charts

## Overview

**Component:** `d3-charts`
**URL:** `charts/d3-charts`

---

---

## API Reference

---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## Examples

### Discrete bar chart (using d3 chart)
**Keywords:** D3 charts, discrete bar chart, bar chart, d3, chart, discrete

### Stacked bar chart (using d3 chart)
**Keywords:** D3 charts, stacked bar chart, bar chart, d3, chart, stacked

### Multi bar horizontal chart (using d3 chart)
**Keywords:** D3 charts, multi bar horizontal chart, bar chart, d3, chart, horizontal

### Bar chart horizontal (using d3 chart)
**Keywords:** D3 charts, bar chart horizontal, bar chart, d3, chart, horizontal

### Box plot chart (using d3 chart)
**Keywords:** D3 charts, box plot chart, box plot, d3, chart, box



*(9 additional examples omitted for brevity. See full documentation for more patterns.)*

---
