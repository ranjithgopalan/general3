# Json translator

## Overview

**Component:** `json-translator`
**URL:** `business-components/json-translator`

---

---

---

## API Reference

### JSON Configuration
| Configuration | Key | Return Type | Description |
|---------------|-----|-------------|-------------|
| Json translator Config | `progressStep` | `Boolean` | Default value is false. If passed true it will display progress bar on top of page. |
| Json translator Config | `enablePrepostHooks` | `Boolean` | Default is false. If true, then it will emit a pre and post event for customization purpose |
| Json translator Config | `overrideFileName` | `Array[string]` | File should be present inside assets folder. It is used for overriding rules on client side |
| Json translator Config | `baseURL` | `String` | Base URL of duckcreek which we want to load on startup |
| Json translator Config | `type` | `String` | Type of duckcreekAPI |
| Json translator Config | `name` | `String` | Name of translator |
| Json translator Config | `saveAndContinueCaption` | `String` | Pass custom name for saveAndContinueCaption |
| Json translator Config | `backCaption` | `String` | Pass custom name for backCaption |
| Json translator Config | `saveAndExitCaption` | `String` | Pass custom name for saveAndExitCaption |
| Override json translator config | `Account` | `Object/Array of Objects` | Name of the page which is available in duck creek json structure. |
| Override json translator config | `fields` | `Array[Object]` | Field items which are used to override properties of duck creek json. 1. name: 'string' Unique name of field which is available in duck creek json structure. 2. tl_AUGDirectOverrides: 'object' label: 'string' Override label required: true Add required to make field mandatory |


---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## Examples

### JSON Configuration
| Configuration | Key | Return Type | Description |
|---------------|-----|-------------|-------------|
| Json translator Config | `progressStep` | `Boolean` | Default value is false. If passed true it will display progress bar on top of page. |
| Json translator Config | `enablePrepostHooks` | `Boolean` | Default is false. If true, then it will emit a pre and post event for customization purpose |
| Json translator Config | `overrideFileName` | `Array[string]` | File should be present inside assets folder. It is used for overriding rules on client side |
| Json translator Config | `baseURL` | `String` | Base URL of duckcreek which we want to load on startup |
| Json translator Config | `type` | `String` | Type of duckcreekAPI |
| Json translator Config | `name` | `String` | Name of translator |
| Json translator Config | `saveAndContinueCaption` | `String` | Pass custom name for saveAndContinueCaption |
| Json translator Config | `backCaption` | `String` | Pass custom name for backCaption |
| Json translator Config | `saveAndExitCaption` | `String` | Pass custom name for saveAndExitCaption |
| Override json translator config | `Account` | `Object/Array of Objects` | Name of the page which is available in duck creek json structure. |
| Override json translator config | `fields` | `Array[Object]` | Field items which are used to override properties of duck creek json. 1. name: 'string' Unique name of field which is available in duck creek json structure. 2. tl_AUGDirectOverrides: 'object' label: 'string' Override label required: true Add required to make field mandatory |


---

---
