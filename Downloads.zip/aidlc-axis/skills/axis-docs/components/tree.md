# Tree

## Overview

**Component:** `tree`
**URL:** `components/tree`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-tree` | `dataSource` | `Array[Object]` | `NA` | Yes | This property is used to load nested tree data. |
| `axis-tree` | `iconColor` | `string` | `` | Yes | This property is used to change color of toggle icon. options are - danger, success, warning, info |
| `axis-tree` | `iconSize` | `string` | `` | Yes | This property is used to change size of toggle icon. options are - xsmall, small, large, xlarge, xxlarge, xxxlarge, xxxxlarge |
| `axis-tree` | `iconFont` | `string` | `` | Yes | This property is used to change font of toggle icon. options are - custom, material |
| `axis-tree` | `customIcon` | `Object` | `NA` | Yes | This property is used to add custom icon for expand and collapse. customIcon = { collapsed:'add_circle_outline', expanded:'do_not_enter'} |


---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "list",
  "name": "%name%",
  "label": "My List:",
  "list": [
    {
      "id": 1,
      "value": "Heading"
    },
    {
      "id": 2,
      "value": "List item 1"
    },
    {
      "id": 3,
      "value": "List item 2"
    },
    {
      "id": 4,
      "value": "List item 3"
    }
  ],
  "axisIncludeComponent": "ListTemplateComponent"
}
```

---

## Examples

### Basic tree
**Keywords:** Tree, basic tree, tree view, hierarchy, structure, nodes

### Filter tree
**Keywords:** Tree, filter tree, search tree, tree filter, filter, search, nodes

### Checkbox tree with custom icon
**Keywords:** Tree, checkbox tree, custom icon, tree with checkbox, icon, select, nodes

### All tree feature
**Keywords:** Tree, all features, tree features, full tree, advanced tree, nodes, checkbox, filter, icon


---

---
