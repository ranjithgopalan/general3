# Truncate

## Overview

**Component:** `truncate`
**URL:** `components/truncate`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA | NA |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `NA` | `NA` | NA |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `TruncateWordsPipe` | `truncateWords` | `NA` | `void` | Hides/truncates the statement after displaying a few words. Note: The number of words displayed are decided by the value passed to the pipe. |
| `TruncateCharactersPipe` | `truncateCharacters` | ` NA` | `void` | Hides/truncates the statement after displaying a few characters. Note: The number of characters displayed are decided by the value passed to pipe. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "truncate",
  "name": "%name%",
  "componentHostClasses": "",
  "content": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
  "truncateType": {
    "id": "characters",
    "name": "Characters"
  },
  "truncateNumber": 10
}
```

---

## Examples

### Truncate 10 characters with show more
**Keywords:** Truncate, truncate 10 characters, show more, character limit, text truncate, expand, collapse

**TypeScript:**
```typescript
<span tabindex="0" axis-tooltip id="tooltip" [content]="text" placement="left">{{ text | truncateCharacters:10:false:isShowMore }}</span>
  <a class="viewmore" tabindex="0" (keydown.enter)="showMore()" (click)="showMore()">
  @if(!isShowMore){    
  <span >Show more</span>
  }
  @if(isShowMore){  
      <span>Show less</span>
  }
  </a>
```

### Truncate 20 characters
**Keywords:** Truncate, truncate 20 characters, character limit, text truncate, shorten, collapse

**TypeScript:**
```typescript
<span axis-tooltip tabindex="0" id="tooltip" [content]="text" placement="left">{{ text | truncateCharacters:20 }}</span>
```

### Truncate 20 characters precisely
**Keywords:** Truncate, truncate 20 characters, precise truncate, character limit, exact truncate, text truncate

**TypeScript:**
```typescript
<span tabindex="0" axis-tooltip id="tooltip" [content]="text" placement="left">{{ text | truncateCharacters:20:true }}</span>
```

### Truncate button label
**Keywords:** Truncate, button label, truncate label, truncate button, text truncate, label

**TypeScript:**
```typescript
<span  axis-tooltip id="tooltip" [content]="text" placement="left">
     <button class="axis-btn" axis-button class="kind-primary">
       {{ text | truncateCharacters:5 }}
     </button>
  </span>
```

### Truncate 1 word
**Keywords:** Truncate, truncate 1 word, word limit, text truncate, shorten, collapse

**TypeScript:**
```typescript
<span axis-tooltip tabindex="0" id="tooltip" [content]="text" placement="left">
  {{ text | truncateWords:1:isViewMore }}
</span>
<a tabindex="0" class="viewmore" (keydown.enter)="viewMore()" (click)="viewMore()">
@if(!isViewMore){
<span >View more</span>
}
@if(isViewMore){
  <span >View less</span>
}
</a>
```



*(3 additional examples omitted for brevity. See full documentation for more patterns.)*

---
