# CustomValidators

## Overview

**Component:** `customValidators`
**URL:** `components/customValidators`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axisAlphabets` | `` | `string` | `none` |  | Validates the input and returns True if it is in given Range. Note:Valid range [A-Za-z] |
| `axisAlphaNumerics` | `` | `string` | `none` |  | Validates the input and returns True if it is only Alphabet,number or combination of both. Note:These are the Valid range [A-Za-z0-9] |
| `axisCurrency` | `` | `string` | `none` |  | Validates the input and returns True if it is in valid Currency format. |
| `axisDecimal` | `` | `string` | `none` |  | Validates the input and returns True if it is valid number or a valid Decimal number. |
| `axisEmail` | `` | `string` | `none` |  | Validates the input and returns True if it is valid Email format. |
| `axisNumerics` | `` | `string` | `none` |  | Validates the input and returns True if it is valid Numeric format. |
| `axisRange` | `` | `string` | `none` |  | Validates the input and returns True if it is with in valid Range. Note:Valid range [10-1000] |


---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## Examples

### Alphabets validation
**Keywords:** Alphabets, letters, alpha, validation, only alphabets, custom validator

### Numerics validation
**Keywords:** Numerics, numbers, digits, numeric, validation, only numbers, custom validator

### Currency validation
**Keywords:** Currency, money, amount, validation, currency format, custom validator

### Email validation
**Keywords:** Email, email address, validation, custom validator, mail

### Alphanumerics validation
**Keywords:** Alphanumerics, letters and numbers, alphanumeric, validation, custom validator



*(2 additional examples omitted for brevity. See full documentation for more patterns.)*

---
