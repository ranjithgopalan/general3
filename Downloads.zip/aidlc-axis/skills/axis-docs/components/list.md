# List

## Overview

**Component:** `list`
**URL:** `components/list`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-list` | `axisIncludeComponent` | `component` | ` none` | No | Allows adding a custom template from dynamic component. Note: If axisIncludeComponent is used, the property content is not required. |
| `axis-list` | `isOwnRepeater` | `boolean` | `false` | No | Loads the list items from dynamic component. true: loads the list from dynamic component. false: loads the list from a default template. Note: Default Value is set to false. |
| `axis-list` | `list` | `Array<any>` | ` none` | Yes | Contains array of list items. |
| `axis-list` | `draggable` | `boolean` | `false` | No | Enables list to be draggable to change the order. true: List will become draggable. false: List won't be draggable. Note: Default Value is set to false. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-list` | `deleteEmitter` | Notifies with the value of the deleted items when onDelete event takes place. |
| `axis-list` | `rowIndexonClickEmitter` | Notifies with the updated data when an item from the list is selected. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-list` | `itemClick()` | `event,data` | `void` | Displays the data when clicked. |
| `axis-list` | `onDelete()` | `data: any` | `void` | Deletes the data. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "list",
  "name": "%name%",
  "label": "My List:",
  "list": [
    {
      "id": 1,
      "value": "Heading"
    },
    {
      "id": 2,
      "value": "List item 1"
    },
    {
      "id": 3,
      "value": "List item 2"
    },
    {
      "id": 4,
      "value": "List item 3"
    }
  ],
  "axisIncludeComponent": "ListTemplateComponent"
}
```

---

## Examples

### List group (External list item template)
**Keywords:** List, list group, external template, list item, template, custom template

**TypeScript:**
```typescript
<axis-list [axisIncludeComponent]=\"inputcomponent\" [list]=\"list\"></axis-list>
```

**HTML:**
```html
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'list-default-demo-template',
    template: \
```

### List group (External parent template)
**Keywords:** List, list group, external parent template, parent template, template, custom template


---

---
