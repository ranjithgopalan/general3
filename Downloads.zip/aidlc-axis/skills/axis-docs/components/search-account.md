# Search Account

## Overview

**Component:** `search-account`
**URL:** `business-components/search-account`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-abc-search-account` | `config` | `Object` | `NA` | Yes | This is the configuration object. The properties in this configuration are: 'nameProject': string - This is name of your project. 'restHostUrl': string - This is the url of your rest service. 'accessToken': string - This is the JWT token for authentication. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-abc-search-account` | `onAccountSelect` | Notifies with the value of the selected account. |
| `axis-abc-search-account` | `resetOnSearch` | Notifies when reset required for already selected account. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "accountLookup",
  "name": "%name%",
  "label": "My Account Lookup:",
  "config": {
    "nameProject": "Your project name",
    "restHostUrl": "",
    "accessToken": ""
  }
}
```

---

## Examples

### Search account
**Keywords:** Search account, account search, find account, lookup account, business components, account

### Search account with reset output event emitter
**Keywords:** Search account, reset event, output event emitter, account search, reset account, business components, account


---

---
