# Chip

## Overview

**Component:** `chips`
**URL:** `components/chip-list`

---

---

## API Reference

### Inputs

| Property | Type | Default | Required | Description |
|----------|------|---------|----------|-------------|
| *See examples below* | | | | |

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "chipList",
  "name": "%name%",
  "label": "My Chip List:",
  "options": [
    {
      "heading": "Apple",
      "value": "apple",
      "selected": false,
      "removable": false,
      "content": "This is Apple!",
      "clickable": true,
      "size": "small",
      "avatar": "<img class=\"axis-img-circle\" src=\"assets/images/flag-india.png\" />"
    },
    {
      "heading": "Orange",
      "value": "orange",
      "selected": false,
      "removable": false,
      "content": "This is Orange!",
      "clickable": true,
      "icon": "add",
      "selectedIcon": "alert"
    },
    {
      "heading": "<span class='axis-badge' data-bg='success'>Guava</span>",
      "value": "guava",
      "selected": false,
      "removable": false,
      "content": "This is Guava!",
      "clickable": true,
      "icon": "success",
      "iconColor": "success",
      "iconFont": "custom",
      "selectedIcon": "clear",
      "selectedIconColor": "danger",
      "selectedIconFont": "custom"
    },
    {
      "heading": "<span class='axis-badge' data-bg='danger'>Watermelon</span>",
      "value": "watermelon",
      "selected": false,
      "removable": false,
      "content": "This is Watermelon!",
      "clickable": true,
      "icon": "add",
      "selectedIcon": "alert"
    },
    {
      "heading": "Mosambi",
      "value": "mosambi",
      "selected": false,
      "removable": false,
      "content": "This is Mosambi!",
      "clickable": true,
      "icon": "add",
      "selectedIcon": "alert",
      "iconColor": "warning",
      "iconFont": "custom",
      "selectedIconColor": "danger",
      "selectedIconFont": "custom"
    }
  ]
}
```

---

## Examples

### Native chip having small size chip and removable
**Keywords:** Chip, small, removable, native, delete, remove, size

### Native chip with custom heading
**Keywords:** Chip, custom heading, native, title, label

### Chip with dataProvider and custom aria-label and tooltip
**Keywords:** Chip, dataProvider, aria-label, tooltip, custom, accessibility

### Generating chips from an input with accessibility
**Keywords:** Chip, input, generate, accessibility, add, dynamic, keyboard

### Generating chips dynamically from a dropdown with removable
**Keywords:** Chip, dropdown, generate, removable, dynamic, add, delete



*(1 additional examples omitted for brevity. See full documentation for more patterns.)*

---
