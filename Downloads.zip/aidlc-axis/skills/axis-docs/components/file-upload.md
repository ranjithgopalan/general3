# File upload

## Overview

**Component:** `file-upload`
**URL:** `components/file-upload`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-upload` | `documentFlag` | `boolean` | `false` | No | Enables or disables the drag and drop feature. true: Enables drag and drop feature. false: Disables the drag and drop feature. Note: Default Value is set to false. |
| `axis-upload` | `invalidFileMsg` | `string` | `File type is not supported` | No | Custom error message option for invalid file type selection |
| `axis-upload` | `font` | `string` | `custom` | No | Defined to load icon styles from material library or custom library. Note: The value need to be configured as font='material' for material icons. |
| `axis-upload` | `imagePreview` | `boolean` | `false` | No | Updates the srcattribute of the axisfile object. true: Updates the src attribute. false: Does not Update the src attribute. Note: Default Value is set to false. Note: The src is used to display the image of the selected file. |
| `axis-upload` | `isAppendable` | `boolean` | `false` | No | Allows uploading of multiple files without removing the existing files. true: Keeps the existing files. false: Removes the existing files. Note: Value is set to false by default. It is used when the property isMulti is set to true. |
| `axis-upload` | `isMulti` | `boolean` | `true` | No | Enables uploading of multiple files. true: Uploads multiple files. false: Allows only single file upload. Note: Default Value is set to true. |
| `axis-upload` | `kind` | `string` | `secondary` | No | Assigns styles to the button. Note: If kind ='primary', the button color changes to blue. |
| `axis-upload` | `maxFileSize` | `number` | `NA` | No | Restricts the maximum size of file that user can upload. Note: Size is in bytes. |
| `axis-upload` | `restrictFiles` | `string` | `NA` | No | Restricts the types of files that user can upload. Note: restrictFiles= '.pdf, .doc, .docx' |
| `axis-upload` | `title` | `string` | `NA` | No | Sets title/label to the file upload button. Note: If no label is set, Select File (for single file) or Select Files (for multiple files) is displayed. |
| `axis-upload` | `type` | `string` | `NA` | No | Specifies the kind of file upload method that needs to be used. Note: By default, normal file upload is used. Note: If data-type = 'dragndrop', the dragndrop is enabled. |
| `axis-upload` | `titleText` | `string` | `NA` | No | Allows to add custom title for file upload. |
| `axis-upload` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |
| `axis-upload` | `allowUniqueFileName` | `boolean` | `true` | No | it will allow multiple files with same name if not passed or passed true (default value is true). false: It will not allow multiple file with same name, instead will discard it and if showGrowlAlert is true then show an growl error alert notification along with that it emits discardedFilesListEmitter event. |
| `axis-upload` | `base64Required` | `boolean` | `false` | No | Enables or disables base64 feature to encode and decode strings . Note: Default Value is set to false. |
| `axis-drag-highlight` | `documentFlag` | `boolean` | `false` | No | Enables or disables the drag and drop feature. true: Enables drag and drop feature. false: Disables the drag and drop feature. Note: Default Value is set to false. |
| `axis-drag-highlight` | `imagePreview` | `boolean` | `false` | No | Updates the srcattribute of the axisfile object. true: Updates the src attribute. false: Does not Update the src attribute. Note: Default Value is set to false. Note: The src is used to display the image of the selected file. |
| `axis-drag-highlight` | `isAppendable` | `boolean` | `false` | No | Allows uploading of multiple files without removing the existing files. true: Keeps the existing files. false: Removes the existing files. Note: Value is set to false by default. It is used when the property isMulti is set to true. |
| `axis-drag-highlight` | `isMulti` | `boolean` | `true` | No | Enables uploading of multiple files. true: Uploads multiple files. false: Allows only single file upload. Note: Default Value is set to true. |
| `axis-drag-highlight` | `maxFileSize` | `number` | `NA` | No | Restricts the maximum size of file that user can upload. |
| `axis-drag-highlight` | `invalidFileMsg` | `string` | `File type is not supported` | No | Custom error message option for invalid file type selection |
| `axis-drag-highlight` | `restrictFiles` | `string` | `NA` | No | Restricts the types of files that user can upload. Note: restrictFiles= '.pdf, .doc, .docx' |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-upload` | `discardedFilesListEmitter` | Notifies with the array of discarded files which are other than file types mentioned in restrictFiles. |
| `axis-upload` | `largerFilesEmitter` | Notifies with the array of discarded files which are higher than the size of specified maximum allowed size. |
| `axis-upload` | `listChange` | Notifies with the array of selected files. |
| `axis-drag-highlight` | `discardedFilesListEmitter` | Notifies with the array of discarded files which are other than file types mentioned in restrictFiles. |
| `axis-drag-highlight` | `largerFilesEmitter` | Notifies with the array of discarded files which are higher than the size of specified maximum allowed size. |
| `axis-drag-highlight` | `listChange` | Notifies with the array of selected files. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-upload, axis-drag-highlight` | `delete` | `NA` | `NA` | Deletes a file from the list. |


---

---

## Examples

### Regular file upload with multiple file selection and file restriction using custom buttons
**Keywords:** File upload, multiple files, file restriction, custom buttons, upload, select files, file input

**TypeScript:**
```typescript
import { Component, SecurityContext } from '@angular/core';
import { BrowseItemDpTemplateComponent } from '../browselistitem.template';
import { DomSanitizer } from '@angular/platform-browser';

import { showAlerts } from 'axis-components';
import { FileuploadAlertComponent } from './fileupload-alert';
@Component({
  ...
})

export class yourComponentName {

  @ViewChild('listBase') listBase: any;
  @ViewChild('listBase2') listBase: any;
  @ViewChild('listBase3') listBase: any;
  @ViewChild('fileUpload') fileUpload: any;
  @ViewChild('fileUpload2') fileUpload: any;
  @ViewChild('fileUpload3') fileUpload: any;
  public inputComponent = BrowseItemDpTemplateComponent;
  public demolist: Array<any> = new Array<any>();
  public demolist2: Array<any> = new Array<any>();
  public demolist3: Array<any> = new Array<any>();

  constructor(private sanitizer: DomSanitizer) { }

  updateList(list: any) {
    this.demolist = Array.apply(this, list);
  }

  updateList2(list: any) {
    this.demolist2 = Array.apply(this, list);
  }

  updateList3(list: any) {
    this.demolist3 = Array.apply(this, list);
  }
  onUploadLargeFile(data: any) {
    showAlerts(this.viewRef, FileuploadAlertComponent, 'files discarded. Please upload files less than 10KB')
  }

  delete(data) {
    this.fileUpload.delete(data);
  }

  delete2(data) {
    this.fileUpload2.delete(data);
  }

  delete3(data) {
    this.fileUpload3.delete(data);
  }

  download(obj) {
    const reader = new FileReader();
    const that = this;
    reader.onload = function (e) {
      const link = document.createElement('a');
      link.download = obj.file.name;
      const docURL = that.sanitizer.sanitize(SecurityContext.URL, reader.result.toString());
      link.href = docURL;
      link.target = '_blank';
      link.click();
    };
    reader.readAsDataURL(obj.file);
  }
}
```

**HTML:**
```html
<div class="axis-form-group">
<axis-upload #fileUpload (largerFilesEmitter)="onUploadLargeFiles($event)"
      [maxFileSize]="10000"  (listChange)="updateList($event)" class="kind-primary" [imagePreview]="true"
        restrictFiles=".pdf,.doc,.docx">
        <button axis-button title="Multi select" class="kind-secondary"> Multi select</button>
   </axis-upload>
</div>

<axis-list #listBase [axisIncludeComponent]="inputComponent" [imagePreview]="true"
    [list]="demolist" (rowIndexonClickEmitter)="download($event)" (deleteEmitter)="delete($event)">
</axis-list>
<div class="axis-form-group">
    <span>Various forms of fileupload button</span>

  <axis-upload #fileUpload2 (listChange)="updateList2($event)" [imagePreview]="true"></axis-upload>
  <axis-list #listBase2 [axisIncludeComponent]="inputComponent" [imagePreview]="true"
  [list]="demolist2" (rowIndexonClickEmitter)="download($event)" (deleteEmitter)="delete2($event)">

  <axis-upload #fileUpload3 (listChange)="updateList3($event)" [kind]="'icon'" [imagePreview]="true"></axis-upload>
  <axis-list #listBase3 [axisIncludeComponent]="inputComponent" [imagePreview]="true"
  [list]="demolist3" (rowIndexonClickEmitter)="download($event)" (deleteEmitter)="delete3($event)">
</div>
```

### Regular file upload with single file selection and file restriction with alert notification
**Keywords:** File upload, single file, file restriction, alert, notification, upload, file input

**TypeScript:**
```typescript
import { Component, SecurityContext } from '@angular/core';
import { BrowseItemDpTemplateComponent } from '../browselistitem.template';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  ...
})

export class yourComponentName {
  @ViewChild('fileUpload') fileUpload: any;
  @ViewChild('multilistBase') multilistBase: any;
  @ViewChild('multifileUpload') multifileUpload: any;
  public inputComponent = BrowseItemDpTemplateComponent;
  public multidemolist: Array<any> = new Array<any>();

  constructor(private sanitizer: DomSanitizer) {}

  multiUpdateList(list:any){
      this.multidemolist =  Array.apply(this,list);
  }

  delete(data){
      this.fileUpload.delete(data);
  }
  multiFileUploaddelete(data){
      this.multifileUpload.delete(data);
  }
  download(obj){
    const reader = new FileReader();
    const that = this;
    reader.onload = function (e) {
      const link = document.createElement('a');
      link.download = obj.file.name;
      const docURL = that.sanitizer.sanitize(SecurityContext.URL, reader.result.toString());
      link.href = docURL;
      link.target = '_blank';
      link.click();
    };
    reader.readAsDataURL(obj.file);
  }
}
```

**HTML:**
```html
<div class="axis-form-group">
  <axis-upload #multifileUpload (listChange)="multiUpdateList($event)" [kind]="'primary'"
    [imagePreview]="true" [isMulti]="false" restrictFiles=".pdf,.doc,.docx">
  </axis-upload>
</div>

<axis-list #multilistBase [axisIncludeComponent]="inputComponent" [imagePreview]="true"
  [list]="multidemolist" (rowIndexonClickEmitter)="download($event)" (deleteEmitter)="multiFileUploaddelete($event)">
</axis-list>
```

### Multi file upload with ability to add new items to the list and file restriction with error message, clear all files on a button click
**Keywords:** File upload, multiple files, add files, file restriction, error message, clear all, upload, file input

**TypeScript:**
```typescript
import { Component } from '@angular/core';
import { BrowseItemDpTemplateComponent } from '../browselistitem.template';
@Component({
  ...
})

export class yourComponentName {

  @ViewChild('multifileUpload2') multifileUpload2: any;
  public inputComponent = BrowseItemDpTemplateComponent;
  public multidemolist2: Array<any> = new Array<any>();
  public fileDiscarded = false;

  ...
  ...
  ...

  multiUpdateList2(list: any) {
    this.multidemolist2 = Array.apply(this, list);
     if (this.multifileUpload2.invalidFilesList.length > 0) {
      this.fileDiscarded =  true; // if wrong file is selected
     } else  {
      this.fileDiscarded =  false;
     }
  }

  multiFileUploaddelete2(data){
      this.multifileUpload2.delete(data);
  }
}
```

**HTML:**
```html
<div class="axis-form-group" [ngClass]="{'has-axis-error': fileDiscarded}">
 <axis-upload #multifileUpload2 [invalidFileMsg] ="'Please select a valid file'" (listChange)="multiUpdateList2($event)"
   restrictFiles=".pdf,.doc,.docx" [kind]="'primary'" [imagePreview]="true" [isAppendable]="true">
</axis-upload>
  <br>
  @if(fileDiscarded){
    <span  class="axis-error-block"> Please select a valid file. </span>
</div>
}

<axis-list #multilistBase2 [axisIncludeComponent]="inputComponent" [imagePreview]="true"
  [list]="multidemolist2" (rowIndexonClickEmitter)="download($event)" (deleteEmitter)="multiFileUploaddelete2($event)">
</axis-list>
```

### File upload with custom title
**Keywords:** File upload, custom title, upload, file input, title

**TypeScript:**
```typescript
import { Component } from '@angular/core';
import { BrowseItemDpTemplateComponent } from '../browselistitem.template';
@Component({
  ...
})

export class yourComponentName {

    @ViewChild('multifileUpload3') multifileUpload3: any;
    public inputComponent = BrowseItemDpTemplateComponent;
    public multidemolist3: Array<any> = new Array<any>();

    ...
    ...
    ...
    singleDemoListChange(event) {
      console.log(this.multidemolist3);
    }
    multiUpdateList3(list:any){
        this.multidemolist3 =  Array.apply(this,list);
    }

    multiFileUploaddelete3(data){
        this.multifileUpload3.delete(data);
    }
}
```

**HTML:**
```html
<div class="axis-form-group">
  <axis-upload #multifileUpload3 (listChange)="multiUpdateList3($event)" [kind]="'primary'"
    [imagePreview]="true" [isMulti]="false" title="Upload Files" [isAppendable]="true">
  </axis-upload>
</div>
<axis-list #multilistBase3 [axisIncludeComponent]="inputComponent" (changeValue)="singleDemoListChange($event)"
  [imagePreview]="true" [list]="multidemolist3" (deleteEmitter)="  multiFileUploaddelete3$event) ">
</axis-list>
```

### Action menu with file upload as a dropdown list item
**Keywords:** File upload, action menu, dropdown, list item, upload, file input

**TypeScript:**
```typescript
import {Component, ViewChild, ElementRef} from '@angular/core';

@Component({
  ...
})

export class yourComponentName {

  public inputComponent = BrowseItemDpTemplateComponent;
  @ViewChild('multifileUpload1') multifileUpload1: any;
  public multidemolist1: Array<any> = new Array<any>();

  ....
  ....
  ....

  multiDemoListChange(event) {
    console.log(this.multidemolist1);
  }
  multiUpdateList1(list:any){
      this.multidemolist1 =  Array.apply(this,list);
  }
  multiFileUploaddelete4(data){
      this.multifileUpload1.delete(data);
  }
}
```

**HTML:**
```html
<axis-dropdown [isActionMenu]="true" (actionEvent)="handleActionEvent()"#actdd>
  <axis-dropdown-list>
    <axis-upload #multifileUpload1 (listChange)="multiUpdateList1($event);"
      [kind]="'link'" [imagePreview]="true" >
    </axis-upload>
  </axis-dropdown-list>
</axis-dropdown>
<span [hidden]="actionCount===0">Action button clicked: {{actionCount}}</span>
<axis-list #multilistBase4 [axisIncludeComponent]="inputComponent" (changeValue)="multiDemoListChange($event)"
[imagePreview]="true" [list]="multidemolist1" (deleteEmitter)="multiFileUploaddelete4($event)">
</axis-list>
```



*(15 additional examples omitted for brevity. See full documentation for more patterns.)*

---
