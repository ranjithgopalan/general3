# Scroll2b

## Overview

**Component:** `scroll2tb`
**URL:** `components/scroll2tb`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-scroll2tb` | `offsetTop` | `Number` | `100` | No | Defines the number of pixels to scroll down from the top after which scroll buttons will display. |
| `axis-scroll2tb` | `scrollBottom` | `boolean` | ` true` | No | Displays or hides the scroll down button. true: Displays the scroll button. false: Hides the scroll button. Note: Default value is set to ' true '. |
| `axis-scroll2tb` | `scrollToElem` | `string` | `NA` | No | Scrolls to element with the specified ID selector. |
| `axis-scroll2tb` | `offset` | `string` | `0` | No | scrollToElem adjustment above or below the id. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-scroll2tb` | `scrollEvent` | Notifies with the value of the scroll type either 'bottom' or 'top'. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-scroll2tb` | `navigate()` | `event` | `void` | Scrolls to element based on Input configuration of scrollToElem property. |
| `axis-scroll2tb` | `scrollToBottom()` | `none ` | `void` | Scrolls to bottom of the page. |
| `axis-scroll2tb` | `scrollToTop()` | `none` | `void` | Scrolls to top of the page. |


---

---

## Examples

### Scroll to page top or bottom
**Keywords:** Scroll2tb, scroll, page top, page bottom, scroll to top, scroll to bottom, scroll button

**TypeScript:**
```typescript
<axis-scroll2tb></axis-scroll2tb>
```

### Offset to scrolling target
**Keywords:** Scroll2tb, scroll, offset, scrolling target, scroll offset, scroll to element, scroll button

**TypeScript:**
```typescript
<axis-scroll2tb [offsetTop]="70"></axis-scroll2tb>
```

### Hide scroll to bottom button
**Keywords:** Scroll2tb, scroll, hide, scroll to bottom, hide button, scroll button

**TypeScript:**
```typescript
<axis-scroll2tb [scrollBottom]="false"></axis-scroll2tb>
```

### Scroll to an element on the page
**Keywords:** Scroll2tb, scroll, element, scroll to element, page element, scroll button

**TypeScript:**
```typescript
<axis-card>
  <div style="padding: 5px;">
    <h4 id="hdrCard">Card header</h4>
    <p><a href="#" axis-scroll2tb scrollToElem="elemTabContent" [offset]="54">Go to tab content</a></p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
  </div>
</axis-card>
<axis-tab-wrapper>
  <axis-tab-set>
    <axis-tab heading="Tab 1">
      <p id="elemTabContent">Tab1 content</p>
      <p><a href="#" target="_self" axis-scroll2tb scrollToElem="hdrCard" [offset]="54">Go to Card Header</a></p>
    </axis-tab>
    <axis-tab heading="Tab 2">
      Tab 2 content
    </axis-tab>
    <axis-tab heading="Tab 3" [disabled]="true">
      Tab 3 content
    </axis-tab>
  </axis-tab-set>
</axis-tab-wrapper>
```

### Scroll to parent page top or bottom
**Keywords:** Scroll2tb, scroll, parent, page top, page bottom, scroll to parent, scroll button


---

---
