# Calendar

## Overview

**Component:** `calendar`
**URL:** `components/calendar`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-calendar` | `datepickerMode` | `string` | `day` | No | Defines whether the calendar in day mode or month mode or year mode. datepickerMode ='day' Displays the calendar in day mode. datepickerMode ='month' Displays the calendar in month mode. datepickerMode ='year' Displays the calendar in year mode. |
| `axis-calendar` | `browserLocale` | `boolean` | `false` | No | Will set browser language to calendar |
| `axis-calendar` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |
| `axis-calendar` | `useLocale` | `string` | `NA` | No | Defines the calendar in useLocale input language rather than browser language. Eg: 'ja','en','fr','es','nb' currently only these languages supported etc. |
| `axis-calendar` | `startDate` | `Date` | `NA` | No | Defines the start date from which date calendar starts. |
| `axis-calendar` | `endDate` | `Date` | `NA` | No | Defines the end date from which date calendar ends. |
| `axis-calendar` | `multiSelect` | `Array` | `NA` | No | Defines the multi date selection |
| `axis-calendar` | `content` | `Any` | `NA` | No | Defines the tooltip content of the selected date |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-calendar` | `onSelect` | Displays the value of the selected date. |
| `axis-calendar` | `onHoverSelect` | Displays the value of the date on hover of the selected date only. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "calendar",
  "name": "%name%",
  "label": "Pick your date"
}
```

---

## Examples

### Calendar with day
**Keywords:** Calendar, day, calendar day, date, single day

### Calendar with month
**Keywords:** Calendar, month, calendar month, monthly, date

### Calendar with year
**Keywords:** Calendar, year, calendar year, yearly, date

### Calendar with browserLocale
**Keywords:** Calendar, browserLocale, locale, browser language, calendar locale

### Calendar Preselect Value
**Keywords:** Calendar, preselect, preselect value, default value, calendar preselect



*(2 additional examples omitted for brevity. See full documentation for more patterns.)*

---
