# Dropdown

## Overview

**Component:** `dropdown`
**URL:** `components/dropdown`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-dropdown` | `aria-label` | `string` | `Please select` | No | accessibility - aria label for dropdown. |
| `axis-dropdown` | `insertBefore` | `boolean` | `false` | No | true: Add dropdown-menu in body as first element. Default is false: and adds the menu as last element of body which sometimes causes page scroll. |
| `axis-dropdown` | `isImage` | `boolean` | `false` | No | true: Add image to dropdown by taking src property(This will work only for (default,link,multiSelect dropdown). Default is false: Wont show any image to dropdown |
| `axis-dropdown` | `showLoader` | `boolean` | `false` | No | Show the loader in dropdown on open in menu instead of options and will close loader on call of setModelonDataproviderChange API call. true: Show loader on open. false: Does not show loader on open. Note: Value is set to true by default. |
| `axis-dropdown` | `arrowIcon` | `boolean` | `true` | No | This property show/hide the arrow icon button in action menu dropdown. This property works only with action menu. Note : Default value is set to true. |
| `axis-dropdown` | `tooltip` | `boolean` | `false` | No | This property display tooltip on hover,focus only when model is present and remove the tooltip on blur(this is avaliable only with defaultDropdown,combobox,typeahead) |
| `axis-dropdown` | `isIconOnly` | `boolean` | `false` | No | default (false) Show icon with label true : Show icon only. |
| `axis-dropdown` | `dataShared` | `boolean` | `false` | No | In MultiSearchSelect dropdown when dataShared is true then dataProvider can be shared with the other dropdowns |
| `axis-dropdown` | `aria-label-action` | `string` | `Action` | No | accessibility - aria label for action menu dropdown. |
| `axis-dropdown` | `aria-labelledby` | `string` | `` | No | accessibility - aria labelledby(HTML element id's whose text needs to be read by screen reader on dropdown focus.) for dropdown. |
| `axis-dropdown` | `data-kind` | `string` | `button` | No | Specify the dropdown type to button, link or icon Note: Default value is set to button . |
| `axis-dropdown` | `buttonKind` | `string` | `NA` | No | Specify the dropdown button type to success, danger, primary, secondary or tertiary. Note: This will only work if [isActionMenu]=true and data-kind='button'. |
| `axis-dropdown` | `icon` | `string` | `` | No | 1.Specify the icon for dropdown when data-kind='icon' 2.Specifies the icon when data-kind='button' for dropdown with action menu |
| `axis-dropdown` | `tabIndex` | `any` | `` | No | tabIndex is used to set tabbing order of axis-dropdown |
| `axis-dropdown` | `data-align` | `string` | `left` | No | Its an attribute which aligns text with in the dropdown through css. Note: Available values are left, right, center . |
| `axis-dropdown` | `retrieveFieldName` | `string` | `` | No | Emits only provided field property value to OnSelect output method. Note: Default value is set to empty string . |
| `axis-dropdown` | `actionLabel` | `string` | `Action` | No | Displays the dropdown label for action menu dropdown. Note: This option holds for action dropdown. It is applicable only when isActionMenu is set to true . |
| `axis-dropdown` | `axisIncludeComponent` | `component` | `none` | No | Allows adding dropdown content from dynamic component. Note: If axisIncludeComponent is used, the property content is not required. |
| `axis-dropdown` | `clearOnFocusOut` | `boolean` | `true` | No | Clears the user entered value in combobox and typeahead if the user don't select from list items. true: Clears the user entered value. false: Does not clear the user entered value. Note: Value is set to true by default. |
| `axis-dropdown` | `clientSideValidation` | `boolean` | `true` | No | Stops client side validation. true: Client side validation is applied on the list. false: Stops clients side validation. |
| `axis-dropdown` | `moreResultsMessage` | `string` | `Too many results...` | No | Changes the message of combobox and typeahead dropdown in case of more results are available. Note: This is for combobox dropdown and typeahead dropdown. Default value is Too many results... |
| `axis-dropdown` | `closeOnOutsideClick` | `boolean` | `true` | No | Closes the dropdown on clicking outside the dropdown list. true: Closes the dropdown. false: Does not close the dropdown. Note: Value is set to true by default. |
| `axis-dropdown` | `columnCount` | `number` | `1` | No | Defines number of columns displayed when the dropdown is opened. Note: Default value is set to 1. Note: This is for filter content dropdown and to make it filter content dropdown isPageContentSearch should be set to true . |
| `axis-dropdown` | `compref` | `any` | `none` | No | Accesses host component data from data in dynamic component (with axisincludeComponent ). Note: It can be referred as compref.data.attribute . Refer data and compref input attributes. |
| `axis-dropdown` | `dataProvider` | `Array` | `NA` | Yes | Stores the objects for dropdown list elements as an array. Each object of array is mapped with dropdown list items, so that they can be used as the source for data binding. Note: This is not mandatory if axis-dropdown list is included. Note: On change of data provider value model will reset. |
| `axis-dropdown` | `disabled` | `boolean` | `false` | No | Disables the dropdown button. true: Disables the dropdown button. false: Keeps the dropdown button enabled. Note Default value is false . |
| `axis-dropdown` | `data` | `any` | `none` | No | Defines the objects required to establish communication between dynamic component and host component. Note: The object encapsulates data and methods that are need to be accessed in dynamic component. |
| `axis-dropdown` | `font` | `string` | `material` | No | Defined to load icon styles from material library or custom library. Note: The default font is 'material', for custom icons, pass 'custom'. |
| `axis-dropdown` | `isActionMenu` | `boolean` | `false` | No | Allows the user to select the options in the action dropdown menu and triggers an event when heading is clicked. true: Allows selection. false: Does not allow selection. Note: Value is set to false by default. |
| `axis-dropdown` | `isCombobox` | `boolean` | `false` | No | Displays the input to search the menu items. On focussing the input the combobox menu is displayed. true: Enables the dropdown as a combobox. false: Continues to be in the default dropdown state. Note: Value is set to false by default. |
| `axis-dropdown` | `isLabelVisible` | `boolean` | `false` | No | Allows the user to show or hide label in the image dropdown. true: Shows label along with image. false: Hides label. Note: Value is set to false by default. |
| `axis-dropdown` | `placeholderIcon` | `object` | `` | No | Allows the user to show default icon in dropdown. icon: Shows icon type. font: Show font type. Note: Value is set to empty by default. |
| `axis-dropdown` | `isMultiSearchSelect` | `boolean` | `false` | No | Allows the user to filter and select multiple options in dropdown menu. true: Enables multi search select for dropdown. |
| `axis-dropdown` | `maxSelectionCount` | `number` | `` | No | Allows the user to restict max Selection in multiSearchSelect dropdown. Default it will allow un limited selection. |
| `axis-dropdown` | `isNestedMultiselect` | `boolean` | `false` | No | Allows the user to select multiple options within a nested dropdown menu. This property enables nested option only up to 2 levels. true: Allows selection in nested menu. false: Does not allow selection in nested menu. Note: Value is set to false by default. |
| `axis-dropdown` | `isPageContentSearch` | `boolean` | `false` | No | Displays a textbox for the user to type the required data. Thereafter, the probable data is filtered and displayed. true: Mandatory to type data false: Not mandatory to type data Note: Value is set to false by default. |
| `axis-dropdown` | `isSelectAll` | `boolean` | `false` | No | Inserts a Select All option checkbox above the available dropdown options when the list options are more than one. This checkbox helps to select or deselect all corresponding child options. true: Displays 'select all'checkbox. false: Does not display the 'Select All' checkbox. Note: Value is set to false by default. Note: The Select All option can be used only when 'type = multiselect' and when isNestedMultiSelect is set to true. |
| `axis-dropdown` | `isTypeahead` | `boolean` | `false` | No | Displays a textbox for the user to type in to search among the available list of options. Atleast 3 characters must be entered to display the filtered list. true: Displays the dropdown in the form of typeahead. false: Continues to be in the dropdown state. Note: Value is set to false by default. |
| `axis-dropdown` | `maxItemsLength` | `number` | `3` | No | Displays the list items with their labels up to the maximum length defined. On exceeding the limit, only the number of items selected is displayed. Note: This option can be used only when 'type = multiselect'. |
| `axis-dropdown` | `maxVisibleRows` | `number` | `3` | No | To limit the max number of rows visible in the view for multi search select dropdown. On exceeding limit user has to scroll to view other items. |
| `axis-dropdown` | `menuMaxHeight` | `number` | `NA` | No | Defines the maximum height of the dropdown menu. |
| `axis-dropdown` | `menuMinWidth` | `number` | `NA` | No | Defines the minimum height of the dropdown menu. |
| `axis-dropdown` | `messageNoResults` | `string` | `No results found` | No | Displays error message when there are no search results in dropdown, combobox or typeahead. Note: Default message is No results found . |
| `axis-dropdown` | `noOfSearchResults` | `number` | `10` | No | Controls the number of search results displayed at a time. Note: Default value is set to 10 . Note: This property works only when is isTypeahead is set to true . |
| `axis-dropdown` | `noOfSearchResultsList` | `number` | `undefined` | No | Controls the number of search results displayed at a time. Note: This property works only when is isCombobox is set to true, type is set to multiSelect . |
| `axis-dropdown` | `placeholder` | `string` | `Please select...` | No | Defines the placeholder text displayed in a textbox. Note: This property is provided only for combo boxes,Typeahead,multiSelect options,default,link. |
| `axis-dropdown` | `heading` | `string` | `Please select...` | No | Defines the placeholder text for dropdown. |
| `axis-dropdown` | `regExp` | `string` | `` | No | Defines the format of the user entries which are not present in dataprovider of dropdown. Note: This property is provided only for multi search select. |
| `axis-dropdown` | `renderingLabel` | `string` | `name` | No | Refers to a particular attribute of a given object based on the renderingLabel. |
| `axis-dropdown` | `required` | `boolean` | `false` | No | Makes it mandatory to select the drop down menu options before submitting the form. true: Mandatory to select. false: Not mandatory to select. Note: Value is set to false by default. |
| `axis-dropdown` | `searchProperties` | `any` | `name` | No | Refers to properties of a given object based on which filtering of options will be done in combobox and typeahead. |
| `axis-dropdown` | `selectedIndex` | `number` | `-1` | No | Stores the index of the selected array element index. |
| `axis-dropdown` | `showSelected` | `boolean` | `true` | No | Displays the selected element of the dropdown menu as a dropdown label. true: Displays the selected element. false: Does not display the selected element. Note: Value is set to false by default.This works explicitly for Menu dropdowns. |
| `axis-dropdown` | `size` | `string` | `medium` | No | Sets the font size. Note: Available font size are : large, medium, and small. |
| `axis-dropdown` | `templateClasses` | `string` | `NA` | No | To specify any custom class for dropdown list. Note: The value will apply on ul tag of dropdown list. |
| `axis-dropdown` | `triggerLength` | `number` | `3` | No | Displays the possible search results after entering the initial words. This option is used to fetch selected data from the dropdown menu, when isTypeahead is set to true. Note: Default value is set to 3. |
| `axis-dropdown` | `width` | `string` | `NA` | No | Sets the width of the dropdown menu. |
| `axis-dropdown` | `apiCall` | `string | Function` | `` | No | Accepts a url or a callback function to search data on typeahead. Note: This will be only for typeahead, used when isTypeahead is set to true. |
| `axis-dropdown` | `wrap` | `boolean` | `false` | No | Content in dropdown menu items can be long and break layouts (extend outside of the viewport). The wrap attribute ensures that the items wrap and fit within the dropdown’s parent element. |
| `axis-dropdown` | `enableMultiSelectFilter` | `boolean` | `false` | No | In multiselect dropdown, adds an input box where user can type something for filtering the dropdown options. |
| `axis-dropdown` | `attr.data-type` | `string` | `''` | No | In multiselect dropdown with filter feature, if data-type='filter' then it prevents the scrolling of input text box. |
| `axis-dropdown` | `backendFieldName` | `string` | `name` | No | It accepts property name based on which it will preselect the model, Defalut value is 'name'. |
| `axis-dropdown` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-dropdown` | `actionEvent` | Notifies whenever user clicks on action label of the action menu. |
| `axis-dropdown` | `onDataproviderChange` | Notifies on change of dataprovider. |
| `axis-dropdown` | `onSelect` | Notifies with the value of the selected option on outside click of dropdown. |
| `axis-dropdown` | `onMultiSelect` | Notifies with the value of the selected option in multiSelect dropdown . Note: This will be only for multiSelect, emits when type is set to multiSelect. |
| `axis-dropdown` | `openClose` | Notifies with the value of isOpen depending on whether the dropdown list is opened or closed. |
| `axis-dropdown` | `onDataproviderSubscription` | Notifies on change of dataprovider on subscription. Note: This will be only for typeahead, emits when isTypeahead is set to true and when apiCall property is used. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-dropdown` | `disableDropdown()` | `NA` | `void` | Disables the selection in dropdown list. |
| `axis-dropdown` | `reset()` | `NA` | `void` | Resets the selected items and model from the array. |
| `axis-dropdown` | `emptySelectedItems()` | `NA` | `void` | Empties the selected items from the array. |
| `axis-dropdown` | `enableDropdown()` | `NA` | `void` | Enables the selection in dropdown list. |
| `axis-dropdown` | `getSelectedItems()` | `NA` | `void` | Returns the selected items to the array. |
| `axis-dropdown` | `setModelonDataproviderChange()` | `dataprovider: array, model: any` | `void` | Update the dropdown dataprovider with new data and update the dropdown model with new value. This method accepts 2 parameters: first is new dataprovider data which is an array, second is the new model selected value. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "dropdown",
  "name": "%name%",
  "label": "My dropdown",
  "options": [
    {
      "id": "1",
      "name": "Option 1"
    },
    {
      "id": "2",
      "name": "Option 2"
    },
    {
      "id": "3",
      "name": "Option 3"
    }
  ]
}
```

---

## Examples

### Default axis dropdown with object, preselected value and aria-labelledby
**Keywords:** Default axis dropdown, dropdown, preselected, aria-labelledby, object, default, axis

**TypeScript:**
```typescript
import {Component,ViewChild} from '@angular/core';

@Component({
...
})

export class yourComponentName {

public showFlag:boolean = true;
 public jsonData2 = [
    {
      addOn: {
        classes: 'axis-flag flag-BJ',
        content: ''
      },
      name: 'Argentina'
    },
    {
      addOn: {
        classes: 'axis-flag flag-AO'
      },
      name: 'Germany'
    }
  ];
  @ViewChild('dd') defaultDropdown2: any;
  resetDefaultDropdown2() {
      this.defaultDropdown2.reset();
    }
}
```

**HTML:**
```html
<div class="col-12 demo-body">
<form #form="ngForm">
  <ng-template [ngIf]="showFlag">
      <div class="axis-col-md-4">
          <div class="axis-form-group">
              <label class="axis-control-label" id="dropdown4Label">Please select option from dropdown</label>
              <  <axis-dropdown name="axisdropdown" [ngModel]="jsonData2[0]" [aria-labelledby]="'dropdown4Label'" aria-describedby="dropdown4ValidId"
                    [dataProvider]="jsonData2"  #dd></axis-dropdown>
                  <div class="axis-help-block" id="dropdown4ValidId" aria-live="assertive">
                    @if (dd.model) {
                    <span>Selected Item name: {{dd.model | json}}</span>
                    }
                  </div>
              </div>
              <button axis-button class="kind-primary" (click)="resetDefaultDropdown2()">Reset</button>
          </div>
      </div>
  </ng-template>
</form>
</div>
```

### Dropdown with empty list having custom error message and aria-labelledby
**Keywords:** Dropdown, empty list, custom error, aria-labelledby, error message

**TypeScript:**
```typescript
import {Component, ViewChild, ElementRef} from '@angular/core';

@Component({
...
})

export class yourComponentName {

public emptyOptions = [0];
public messageNoResults = 'Custom error message for no results.';
}
```

**HTML:**
```html
<div class="axis-col-md-5">
  <div class="axis-form-group">
    <label class="axis-control-label" id="dropdown5Label">Please click to open dropdown and see custom error message.</label>
    <axis-dropdown name="axisdropdown" [aria-labelledby]="'dropdown5Label'" [dataProvider]="emptyOptions"
      [messageNoResults]="messageNoResults" #dd2>
    </axis-dropdown>
  </div>
</div>
```

### Dropdown selection with string as ngModel value
**Keywords:** Dropdown, selection, string, ngModel, value

**TypeScript:**
```typescript
import {Component} from '@angular/core';

@Component({
...
})

export class yourComponentName {
public showFlag:boolean = true;
public myOptions = [
      { id: 'test 1', name: 'Option 1' },
      { id: 'test 2', name: 'Option 2' }
  ];
}
```

**HTML:**
```html
<form #form="ngForm">
<ng-template [ngIf]="showFlag">
  <div class="axis-grid col-12 demo-body">
    <div class="axis-col-md-4">
      <div class="axis-form-group">
          <axis-dropdown name="axisdropdown" ngModel="Option 1" [dataProvider]="myOptions" #dd6></axis-dropdown>
          <div class="axis-help-block">
              <span>Selected Item name: {{dd6.model|json}}</span>
          </div>
      </div>
    </div>
  </div>
</ng-template>
</form>
```

### Dropdown selection with index as ngModel value
**Keywords:** Dropdown, selection, index, ngModel, value

**TypeScript:**
```typescript
import {Component} from '@angular/core';

@Component({
...
})

export class yourComponentName {
public myOptions = [
      { id: 'test 1', name: 'Option 1' },
      { id: 'test 2', name: 'Option 2' }
  ];
}
```

**HTML:**
```html
<form #form="ngForm">
<div class="axis-grid col-12 demo-body">
  <div class="axis-col-md-4">
    <div class="axis-form-group">
      <axis-dropdown name="axisdropdown" [ngModel]="1" [dataProvider]="myOptions" #dd6></axis-dropdown>
      <div class="axis-help-block">
          <span>Selected Item name: {{dd6.model|json}}</span>
      </div>
    </div>
  <div>
</div>
</form>
```

### Dropdown options with only image(dropdown kind = "link")
**Keywords:** Dropdown, image only, link, dropdown kind, image

**TypeScript:**
```typescript
import {Component} from '@angular/core';

@Component({
...
})

export class yourComponentName {
  public jsonData = [{
      src: 'assets/images/flag-argentina.png', label: 'Argentina'
      },{
      src: 'assets/images/flag-australia.png', label: 'Australia'
      },{
      src: 'assets/images/flag-bulgaria.png', label: 'Bulgaria'
      },{
      src: 'assets/images/flag-india.png', label: 'India'
      },{
      src: 'assets/images/flag-new-zealand.png', label: 'Newzealand'
      },{
      src: 'assets/images/flag-usa.png', label: 'USA'
      }
  ];
}
```

**HTML:**
```html
<div class="axis-col-md-4">
  <div class="axis-form-group">
      <axis-dropdown
          kind="link"
          [dataProvider]="jsonData"
          [isImage]="true"
          [ngModel]="jsonData[0]"
          #dd7>
      </axis-dropdown>
      <div class="axis-help-block">
          @if(dd7.model){
          <span >Selected value: {{dd7.model | json}}</span>
          }
      </div>
  </div>
</div>
```



*(93 additional examples omitted for brevity. See full documentation for more patterns.)*

---
