# Slider

## Overview

**Component:** `slider`
**URL:** `components/slider`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-slider` | `start` | `Array` | `none` | Yes | The start option sets the number of handles and corresponding start positions. |
| `axis-slider` | `connect` | `Array[boolean]` | `[true , false]` | No | The connect option can be used to control the bar between the handles or the edges of the slider. Pass an array with a boolean for every connecting element, including the edges of the slider. The length of this array must match the handle count + 1. Setting true sets the bars between the handles, but not between the handles and the sliders edges. |
| `axis-slider` | `margin` | `number` | `none` | No | When using two handles, the minimum distance between the handles can be set using the margin option. The margin value is relative to the value set in 'range'. This option is only available on linear sliders. |
| `axis-slider` | `limit` | `number` | `none` | No | The limit option is the oposite of the margin option, limiting the maximum distance between two handles. As with the margin option, the limit option can only be used on linear sliders. |
| `axis-slider` | `padding` | `number` | `none` | No | Padding limits how close to the slider edges handles can be. |
| `axis-slider` | `pageSteps` | `number` | `25` | No | By default, the slider slides fluently. In order to make the handles jump between intervals, you can use the step option. |
| `axis-slider` | `orientation` | `string` | `horizontal` | No | The orientation setting can be used to set the slider to vertical or horizontal position. Set dimensions! Vertical sliders don't assume a default height, so you'll need to set one. You can use any unit you want, including % or px. |
| `axis-slider` | `direction` | `string` | `ltr` | No | The direction setting can be used to set the slider direction as left to right or right to left. Possible values : ltr and rtl Default value : ltr |
| `axis-slider` | `tooltip` | `boolean` | `none` | No | Displays tooltip. |
| `axis-slider` | `hideMarkDivider` | `boolean` | `false` | No | Removes the divider |
| `axis-slider` | `hideToolTipLabel` | `boolean` | `false` | No | Hides tool tip label |
| `axis-slider` | `hideMarkDividerValues` | `boolean` | `false` | No | Removes the divider sub values |
| `axis-slider` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-slider` | `start` | This event fires when a tootltip is clicked. |
| `axis-slider` | `slide` | This event is useful when you specifically want to listen to a tooltip being dragged, but want to ignore other updates to the slider value. This event also fires on a change by a 'tap'. |
| `axis-slider` | `update` | It fires every time the slider values are changed. |
| `axis-slider` | `change` | This event is similar to the 'change' events on regular 'input' elements. It fires when a user stops sliding. |
| `axis-slider` | `end` | This event is the opposite of the 'start' event. If fires when a tooltip is released. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-slider` | `disableSlider(disabled: boolean)` | `disabled` | `void` | true: will disable the slider. false or null: will enable the slider. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "slider",
  "name": "%name%",
  "label": "My Slider",
  "componentHostClasses": "",
  "config": {
    "step": 10,
    "start": [
      10
    ],
    "range": {
      "min": [
        0
      ],
      "max": [
        100
      ]
    },
    "pips": {
      "mode": "steps",
      "stepped": true,
      "density": 2,
      "values": 100
    }
  }
}
```

---

## Examples

### Vertical single slider
**Keywords:** Slider, vertical, single, vertical slider, slider example

### Horizontal single slider (with right to left direction)
**Keywords:** Slider, horizontal, single, right to left, horizontal slider, slider example

### Vertical dual slider
**Keywords:** Slider, vertical, dual, vertical dual slider, slider example

### Horizontal dual slider
**Keywords:** Slider, horizontal, dual, horizontal dual slider, slider example

### Horizontal single slider with template driven form
**Keywords:** Slider, horizontal, single, template driven, form, horizontal slider, slider example



*(9 additional examples omitted for brevity. See full documentation for more patterns.)*

---
