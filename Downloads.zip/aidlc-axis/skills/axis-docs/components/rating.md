# Rating

## Overview

**Component:** `rating`
**URL:** `components/rating`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-rating` | `max` | `number` | `10` | No | Maximum rating that can be given. |
| `axis-rating` | `rate` | `number` | `NA` | No | Current rating value. Note: It can be decimal value also, eg, 3.75. |
| `axis-rating` | `readonly` | `boolean` | `false` | No | If true, rating cannot be changed. |
| `axis-rating` | `resettable` | `boolean` | `false` | No | If `true`, the rating can be reset to `0` by mouse clicking currently set rating. |
| `axis-rating` | `starTemplate` | `TemplateRef` | `NA` | No | The template to override the way each star is displayed. Alternatively put an as the only child of your element |
| `axis-rating` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-rating` | `onHover` | Event emitted when user hovers over rating component. |
| `axis-rating` | `onLeave` | Event emitted when user leave rating component. |
| `axis-rating` | `rateChange` | Event emitted when rating value is changed. |


---

---

## Examples

### Simple rating
**Keywords:** Rating, simple, star, basic, rate, stars

### Custom star template
**Keywords:** Rating, custom star, template, star template, custom, rate, stars

### Custom template rating (Read only)
**Keywords:** Rating, custom template, read only, readonly, template, rate, stars


---

---
