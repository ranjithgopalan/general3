# Simple Feedback

## Overview

**Component:** `feedback`
**URL:** `components/feedback`

---

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-feedback` | `blob` | `bolb` | `` | Yes | Accepts blob data. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-feedback` | `` | returns image blob. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|


---

---

## Examples

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-feedback` | `blob` | `bolb` | `` | Yes | Accepts blob data. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-feedback` | `` | returns image blob. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|


---

---
