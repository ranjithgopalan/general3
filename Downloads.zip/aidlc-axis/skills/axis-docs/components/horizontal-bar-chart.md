# Horizontal bar chart

## Overview

**Component:** `horizontal-bar-chart`
**URL:** `charts/horizontal-bar-chart`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-horizontal-bar-chart` | `data` | `Array` | `NA` | Yes | Its an array consist of data to be send. customTooltipLabel: option to provide custom tooltip, it is optional. |
| `axis-horizontal-bar-chart` | `options` | `object` | `NA` | No | Its an object consist of different settings for horizontal bar chart. animation: to show animation, by default it is true. bars: it is an object consist of bar names. clickableBars: option to make bar clickable, by default it is false. dual: option to show dual bars, by default it is false. showLegend: option to show legend, by default it is 'top'. showTooltips: option to show tooltip on hover, by default it is true. showValuesOnBar: to show values on bar, by default it is true. xAxis: object to show xAxis labels. yAxis: object to show yAxis labels. sameLeftRightScale: option to show same scale on both the sides of axis, by default it is false. gradients: option to provide gradient color in the bars , it is an array. narrow: option to provide narrow bars, by default it is false. selectableBars: option to provide selectable bars, by default it is false. clickableBars: option to make bar clickable, by default it is false. gridLines: option to show grid lines, by default it is true. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-horizontal-bar-chart` | `ShowSelection` | Gives the selected data. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---

## Examples

### Horizontal bar chart with single bar
**Keywords:** Horizontal bar chart, single bar, bar chart, horizontal, chart

### Horizontal bar chart with dual bar
**Keywords:** Horizontal bar chart, dual bar, bar chart, horizontal, chart, two bars

### Horizontal bar chart with multiple dual bar
**Keywords:** Horizontal bar chart, multiple dual bar, bar chart, horizontal, chart, multiple bars

### Horizontal bar chart with custom tooltip
**Keywords:** Horizontal bar chart, custom tooltip, bar chart, horizontal, chart, tooltip

### Horizontal bar chart with same scale
**Keywords:** Horizontal bar chart, same scale, bar chart, horizontal, chart, scale



*(2 additional examples omitted for brevity. See full documentation for more patterns.)*

---
