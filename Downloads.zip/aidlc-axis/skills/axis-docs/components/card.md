# Card

## Overview

**Component:** `card`
**URL:** `components/card`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-card` | `inverse` | `string` | `NA` | No | Changes the text color. true: Font color changes to white as per the css style given. false: Font color does not change. |
| `axis-card` | `data-shadow` | `boolean` | `NA` | No | Defines shadow to the card. true: Adds shadow to the card |
| `axis-card` | `kind` | `string` | `NA` | No | Defines the card format. Note: It could be a button controlled tooltip, question/help, or information. |
| `` | `alignflexitems` | `string` | `NA` | No | Displays special effects when applied to the card element. |
| `axis-card-ribbon` | `backgroundColor` | `string` | `NA` | No | Changes the background color of the ribbon Options : primary, success, info, warning, danger |
| `axis-card-ribbon` | `icon` | `string` | `NA` | No | Icon to be displayed inside ribbon ex: icon=&quot;open_quote&quot;. |
| `axis-card-ribbon` | `font` | `string` | `NA` | No | Add font style for ribbon icon ex: font=&quot;custom&quot;. |
| `axis-card-ribbon` | `color` | `string` | `NA` | No | Add color style for ribbon icon |
| `` | `size` | `string` | `NA` | No | Add size style for ribbon text |

### Selectors
| Component | Description |
|-----------|-------------|
| `axis-card` | Wrapper that contains all the card components. |
| `axis-card-body` | Contains the body of the card. |
| `axis-card-content` | Contains the body and footer elements. |
| `axis-card-footer` | Contains footer content of the card. |
| `axis-card-heading` | Contains the header for the card. |
| `axis-card-heading-body` | Contains the body of the header. |
| `axis-card-heading-right` | Contains the right side content of the header. |
| `axis-card-img-container` | Contains the images of the card. |
| `axis-card-row` | Adds an additional row inside the card body. |
| `axis-card-spotlight-container` | Contains badges of the card. |


---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "card",
  "name": "%name%",
  "label": "card"
}
```

---

## Examples

### Basic
**Keywords:** Card, basic, simple, default

**TypeScript:**
```typescript
<axis-card class="shadow">
    <axis-card-img-container>
        <img class="axis-img-responsive" src="images/3.jpg" alt="Card cap">
    </axis-card-img-container>
    <axis-card-body>
        <h4>VWR International, LLC</h4>
        <address class="_text-muted">
            521 Colony Road Madison Heights, VA 24572
        </address>
        <div class="_text-small _text-muted">
            <label>LAT</label>37.415528<label> LGT</label>-79.119610
        </div>
    </axis-card-body>
</axis-card>
```

### Card with title in heading, multicolumn footer
**Keywords:** Card, title, heading, multicolumn, footer, multiple columns

**TypeScript:**
```typescript
@for (item of cardDetails; track item) {
<axis-card >
  <axis-card-heading>
    <axis-card-heading-body>
        <h4>Executive Office</h4>
        <span class="_text-small _text-muted">RFS-41487</span>
    </axis-card-heading-body>
    <axis-card-heading-right>
        <axis-icon icon="location_on"></axis-icon>
    </axis-card-heading-right>
  </axis-card-heading>
  <axis-card-img-container>
    <img class="axis-img-responsive" src="images/3.jpg" alt="Card cap">
  </axis-card-img-container>
  <axis-card-body>
    <h4>{{item.cardTitle}}</h4>
    <address class="_text-muted">
        {{item.cardAddress}}
    </address>
    <div class="_text-small _text-muted">
        <label>LAT</label>{{item.latitude}}<label> LGT</label>{{item.longitude}}
    </div>
  </axis-card-body>
  <axis-card-footer>
    <div class="axis-grid axis-grid-separator">
        <div class="axis-col-6">
        <div class="axis-summary">
            <div class="_text-small">Survey Due [Sep 28, 2016]</div>
            <h4> 3 Days</h4>
        </div>
        </div>
        <div class="axis-col-6">
        <div class="axis-summary">
            <div class="_text-small">Report Due [Sep 28, 2016]</div>
            <h4> 3 Days</h4>
        </div>
        </div>
    </div>
  </axis-card-footer>
</axis-card>
  }
```

### Card with image and text
**Keywords:** Card, image, text, picture, photo

**TypeScript:**
```typescript
<div class="axis-grid">
    <div class="axis-col-md-4 axis-col-sm-6">
        <axis-card>
        <axis-card-img-container>
            <img class="axis-img-responsive" src="images/3.jpg" alt="Card cap">
        </axis-card-img-container>
        <axis-card-spotlight-container>
            <div class="axis-card-spotlight">
                <span class="axis-badge size-large">JM</span>
            </div>
        </axis-card-spotlight-container>
        <axis-card-body>
            <h4>VWR International, LLC</h4>
            <address class="_text-muted">
                521 Colony Road <br> Madison Heights, VA 24572
            </address>
            <div class="_text-small _text-muted"><label>LAT</label> 37.415528, <label>LGT</label> -79.119610)</div>
        </axis-card-body>
        </axis-card>
    </div>
    <div class="axis-col-md-4 axis-col-sm-6">
        <axis-card>
        <axis-card-img-container>
            <img class="axis-img-responsive" src="images/3.jpg" alt="Card cap">
        </axis-card-img-container>
        <axis-card-spotlight-container class="align-left">
            <div class="axis-card-spotlight">
                <span class="axis-badge size-large">JM</span>
            </div>
        </axis-card-spotlight-container>
        <axis-card-body>
            <h4>VWR International, LLC</h4>
            <address class="_text-muted">
                521 Colony Road <br> Madison Heights, VA 24572
            </address>
            <div class="_text-small _text-muted"><label>LAT</label> 37.415528, <label>LGT</label> -79.119610)</div>
        </axis-card-body>
        </axis-card>
    </div>
    <div class="axis-col-md-4 axis-col-sm-6">
        <axis-card>
        <axis-card-img-container>
            <img class="axis-img-responsive" src="images/3.jpg" alt="Card cap">
        </axis-card-img-container>
        <axis-card-spotlight-container class="align-right">
            <div class="axis-card-spotlight">
                <span class="axis-badge size-large">JM</span>
            </div>
        </axis-card-spotlight-container>
        <axis-card-body>
            <h4>VWR International, LLC</h4>
            <address class="_text-muted">
                521 Colony Road <br> Madison Heights, VA 24572
            </address>
            <div class="_text-small _text-muted"><label>LAT</label> 37.415528, <label>LGT</label> -79.119610)</div>
        </axis-card-body>
        </axis-card>
    </div>
</div>
```

### Card with title and options in heading, multicolumn footer
**Keywords:** Card, title, options, heading, multicolumn, footer

**TypeScript:**
```typescript
<div class="axis-grid">
<div class="axis-col-md-4 axis-col-sm-6">@for (item of cardDetails; track item) {
    <axis-card>
    <axis-card-heading>
        <div class="axis-card-heading-left">
            <span class="axis-badge size-large">JM</span>
        </div>
        <axis-card-heading-body>
            <h4>Executive Office</h4>
            <span class="_text-small _text-muted">RFS-41487</span>
        </axis-card-heading-body>
        <axis-card-heading-right>
            <axis-icon icon="location_on"></axis-icon>
        </axis-card-heading-right>
    </axis-card-heading>
    <axis-card-body>
        <h4>{{item.cardTitle}}</h4>
        <address class="_text-muted">
            {{item.cardAddress}}
        </address>
        <div class="_text-small _text-muted">
            <label>LAT</label>{{item.latitude}}<label> LGT</label>{{item.longitude}}
        </div>
    </axis-card-body>
    <axis-card-footer>
        <div class="axis-grid axis-grid-separator">
            <div class="axis-col-6">
                <div class="axis-summary">
                <div class="_text-small">Survey Due [Sep 28, 2016]</div>
                <h4> 3 Days</h4>
                </div>
            </div>
            <div class="axis-col-6">
                <div class="axis-summary">
                <div class="_text-small">Report Due [Sep 28, 2016]</div>
                <h4> 3 Days</h4>
                </div>
            </div>
        </div>
    </axis-card-footer>
    </axis-card>
}
</div>
</div>
```

### Card with image and list
**Keywords:** Card, image, list, items, picture

**TypeScript:**
```typescript
<div class="axis-grid">
<div class="axis-col-md-4 axis-col-sm-6">
    <axis-card>
        <axis-card-img-container>
            <img class="axis-img-responsive" src="images/3.jpg" alt="Card cap">
        </axis-card-img-container>
        <ul class="axis-list-group">
            <li class="axis-list-group-item">Test item 1</li>
            <li class="axis-list-group-item">Test item 2</li>
            <li class="axis-list-group-item">Test item 3</li>
        </ul>
    </axis-card>
</div>
</div>
```



*(12 additional examples omitted for brevity. See full documentation for more patterns.)*

---
