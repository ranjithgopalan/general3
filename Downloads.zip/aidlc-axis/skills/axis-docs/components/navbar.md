# Navbar

## Overview

**Component:** `navbar`
**URL:** `components/navbar`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-navbar` | `ariaLabel` | `string` | `main menu` | NA | Defines the text label for modal. Note: Value is set to main menu by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `NA` | `` | NA |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA ` | `NA` | NA |

### Selectors
| Component | Description |
|-----------|-------------|
| `axis-navbar` | Creates checkbox navbar. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "navbar",
  "name": "%name%",
  "appTitle": "App Title",
  "subTitle": "Application Sub title",
  "logo": "<a href>\n<img alt='AIG logo' src='../../assets/images/logos/aig-logo-white.svg' />\n<span class=\"sr-only\">American International Group, Inc.</span>\n</a>",
  "subNavbar": "true",
  "fields": {
    "navbarLeftFields": [
      {
        "type": "tooltip",
        "name": "navbarInfoTooltip",
        "className": "_nm",
        "content": "Navbar left section. you can add more controls in any of 4 sections inside fields.",
        "icon": "info",
        "color": {
          "id": "info",
          "name": "Info"
        },
        "vcard": "tooltip",
        "size": "a",
        "placement": {
          "id": "right",
          "name": "Right",
          "isSelected": true
        },
        "tooltipType": {
          "id": "icon",
          "name": "Icon",
          "isSelected": true
        },
        "iconName": "info",
        "iconColor": {
          "id": "info",
          "name": "Info",
          "isSelected": true
        },
        "iconSize": {
          "id": "large",
          "name": "Large",
          "isSelected": true
        }
      }
    ],
    "navbarRightFields": [
      {
        "type": "text",
        "name": "navbarSearchBar",
        "className": "_nm",
        "placeholder": "search",
        "vcard": "text",
        "size": "g",
        "inputClear": "true",
        "inputType": "text",
        "autocomplete": "on",
        "addOn": {
          "clickable": {
            "kind": "icon",
            "icon": "search",
            "font": "custom"
          },
          "noSeparator": false
        }
      }
    ],
    "subNavbarLeftFields": [
      {
        "type": "button",
        "name": "navbarHomeLink",
        "label": "Home",
        "vcard": "button",
        "size": "g",
        "kind": {
          "id": "link",
          "name": "Link",
          "isSelected": true
        },
        "icon": "home",
        "className": "_nm"
      },
      {
        "type": "button",
        "name": "navbarNewLink",
        "label": "New",
        "vcard": "button",
        "size": "g",
        "kind": {
          "id": "link",
          "name": "Link",
          "isSelected": true
        },
        "icon": "create",
        "navigationProperties": {
          "jsonURL": "assets/json/new.json",
          "effect": "add:body"
        },
        "className": "_nm"
      }
    ],
    "subNavbarRightFields": [
      {
        "type": "dropdown",
        "name": "navbarSampleDropdown",
        "options": [
          {
            "id": "1",
            "name": "Preferences",
            "icon": "settings"
          },
          {
            "id": "2",
            "name": "Sign out",
            "icon": "exit_to_app"
          }
        ],
        "vcard": "dropdown",
        "size": "g",
        "renderingLabel": "name",
        "clientSideValidation": "true",
        "heading": "Please select...",
        "closeOnOutsideClick": "true",
        "showSelected": "true",
        "listType": {
          "id": "select",
          "name": "Select",
          "isSelected": true
        },
        "kind": {
          "id": "button",
          "name": "Button",
          "isSelected": true
        },
        "fontSize": {
          "id": "medium",
          "name": "Medium",
          "isSelected": true
        },
        "className": "_nm"
      }
    ]
  }
}
```

---

## Examples

### Main Navbar
**Keywords:** Navbar, main navbar, navigation bar, header, menu, main menu

### Sub Navbar
**Keywords:** Navbar, sub navbar, sub navigation, submenu, secondary menu

### Page Header
**Keywords:** Navbar, page header, header, navigation, page navbar


---

---
