# Logger

## Overview

**Component:** `logger`
**URL:** `components/logger`

---

---

---

## API Reference

### Inputs

| Property | Type | Default | Required | Description |
|----------|------|---------|----------|-------------|
| *See examples below* | | | | |

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `Logger` | `init()` | `isEnabled` | `void` | init() needs to be called for initializing the Logger. User needs to configure isEnabled and pass the same to init() method. true will enable logging false will disable logging. default value is false. |
| `Logger` | `debug()` | `NA` | `void` | debug() needs to be called to use debug method of console. |
| `Logger` | `error()` | `NA` | `void` | error() needs to be called to show errors on console. |
| `Logger` | `log()` | `NA` | `void` | log() needs to be called to show log on console. |
| `Logger` | `info()` | `NA` | `void` | info() needs to be called to show info on console. |
| `Logger` | `warn()` | `NA` | `void` | warn() needs to be called to show warning on console. |


---

---

## Examples

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `Logger` | `init()` | `isEnabled` | `void` | init() needs to be called for initializing the Logger. User needs to configure isEnabled and pass the same to init() method. true will enable logging false will disable logging. default value is false. |
| `Logger` | `debug()` | `NA` | `void` | debug() needs to be called to use debug method of console. |
| `Logger` | `error()` | `NA` | `void` | error() needs to be called to show errors on console. |
| `Logger` | `log()` | `NA` | `void` | log() needs to be called to show log on console. |
| `Logger` | `info()` | `NA` | `void` | info() needs to be called to show info on console. |
| `Logger` | `warn()` | `NA` | `void` | warn() needs to be called to show warning on console. |


---

---
