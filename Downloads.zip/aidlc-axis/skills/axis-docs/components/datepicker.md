# Datepicker

## Overview

**Component:** `datepicker`
**URL:** `components/datepicker`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-datepicker` | `closeOnOutsideClick` | `boolean` | `true` | No | Defines whether the datepicker must be visible or not. true: Enables the closure of datepicker on clicking outside. false: Disables the closure of datepicker on clicking outside. Note: Default value is set to true . |
| `axis-datepicker` | `multiSelect` | `boolean` | `false` | No | Defines the multi selection datepicker. true: User can select/unselect multiple dates. Note: This feature works on default datepicker with limited inputs . |
| `axis-datepicker` | `isReadOnly` | `boolean` | `true` | No | Defines the type of datepicker. true: Default datepicker false: Editable datepicker. Note: Default Value is set to true . |
| `axis-datepicker` | `useLocale` | `string` | `NA` | No | Defines the datepicker in useLocale input language rather than browser language. Eg: 'fr', 'es', 'ja', 'nb', 'fi', 'pt', 'sv', 'th', 'zh-cn', 'zh-hk', 'zh-mo', 'zh-tw' |
| `axis-datepicker` | `locale` | `string` | `NA` | No | Defines the default date format based on language. Eg: 'ja' or 'en-YSA' etc. |
| `axis-datepicker` | `customLocale` | `Objects` | `NA` | No | Defines the date format based on given language and format. Eg: {'un-UN': 'YYYY/M/D'} |
| `axis-datepicker` | `disabled` | `Date` | `NA` | No | Disables the datepicker. |
| `axis-datepicker` | `browserLocale` | `boolean` | `false` | No | Will set browser language date format to datepicker |
| `axis-datepicker` | `font` | `string` | `custom` | No | Defined to load icon styles from material library or custom library. Note: The value need to be configured as font='material' for material icons. |
| `axis-datepicker` | `minDate` | `Date` | `NA` | No | Sets a minimum range for the date. |
| `axis-datepicker` | `maxDate` | `Date` | `NA` | No | Sets a maximum range for the date. |
| `axis-datepicker` | `required` | `Date` | `NA` | No | Defines whether it is required to select the datepicker or not. true: Mandatory to select the datepicker. false: Not mandatory to select the datepicker. Note: Default value is set to false . |
| `axis-datepicker` | `isTodayVisible` | `boolean` | `true` | No | Option to display today button in datepicker. true: Display today button in datepicker. false: Removes today button from datepicker. |
| `axis-datepicker` | `ignoreTime` | `boolean` | `false` | No | Returns only date ignoring time and timezone. true: Returns only date ignoring time and timezone.. false: Returns full date format with time stamp. |
| `axis-datepicker` | `disableDays` | `number array` | `NA` | No | Disable the days provided in an array 0: Sunday 1: Monday 2: Tuesday 3: Wednesday 4: Thursday 5: Friday 6: Saturday |
| `axis-datepicker` | `disableDates` | `Array` | `NA` | No | Disable the dates provided in an array {d:12,m:12,y:2019}: This disables the date 12/12/2019 {d:25,m:12}: For every year, Dec, 25th will be disabled. Note: If 'y' attribute is missing then the given date will be disabled for every year. If its available, then only for the specific year, particular date is disabled. |
| `axis-datepicker` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |
| `axis-datepicker` | `customFormat` | `any` | `` | No | Defines format of date |
| `axis-dob` | `alignment` | `string` | `'mm-dd-yyyy'` | No | Defines the alignment of day, month and year. 'mm-dd-yyyy': Default alignment. Other options are 'dd-mm-yyyy' , 'yyyy-mm-dd' |
| `axis-dob` | `ignoreTime` | `boolean` | `false` | No | Returns only date ignoring time and timezone. true: Returns only date ignoring time and timezone.. false: Returns full date format with time stamp. |
| `axis-dob` | `placeholder` | `Object` | `{ day: 'DD', month: 'MM', year: 'YYYY' }` | No | Defines the placeholder for all 3 dropdown. You can override all or individual. |
| `axis-dob` | `ariaLabel` | `Object` | `{ day: 'Please select a day', month: 'Please select a month', year: 'Please select a year' }` | No | Defines the aria-label for all 3 dropdown. You can override all or individual. |
| `axis-dob` | `startYear` | `number` | `1900` | No | Defines the year from which year calendar starts. |
| `axis-dob` | `endYear` | `number` | `` | No | Defines the year where year calendar ends. |
| `axis-dob` | `monthFormat` | `string` | `'mmm-mm'` | No | Defines the format of the month. 'mm': Month Label will be like 06. 'MMM': Month Label will be like JUN. 'mmm': Month Label will be like Jun. 'mmm-mm': by default, Month Label will be like Jun - 06. |
| `axis-dob` | `yearsOrderDesc` | `boolean` | `false` | No | Display the years in descending order. |
| `axis-dob` | `required` | `boolean` | `False` | No | Defines whether it is required to select the DOB or not. |
| `axis-dob` | `dayLabel` | `string` | `NA` | No | Defines the label for date dropdown. |
| `axis-dob` | `monthLabel` | `string` | `NA` | No | Defines the label for month dropdown. |
| `axis-dob` | `yearLabel` | `string` | `NA` | No | Defines the label for year dropdown. |
| `axis-dob` | `monthProvider` | `Array` | `NA` | No | Defines the customized month names for month dropdown. |
| `axis-dob` | `customFormat` | `string` | `MMM DD, YYYY` | No | Defines format of date and it is only used when ignoreTime is true to display date without time . |
| `axis-dob` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-datepicker` | `onDatepickerClose()` | Returns the active date on clicking the required date or 'today' button. Note: Returns the value from modelvalue(Time) method. |
| `axis-datepicker` | `formattedDate` | Defines the output of ignoreTime using template reference variable . formatedDate it is changed to formattedDate |
| `axis-datepicker` | `onError()` | Returns the input value on getting invalid status or invalid date |
| `axis-datepicker` | `onMultiSelect()` | Returns the Array of dates selected on input value |
| `axis-dob` | `onSelect` | Notifies with the value of the selected option. |
| `axis-dob` | `formattedDate` | Defines the output of ignoreTime using template reference variable |
| `axis-dob` | `onDropDownClose` | Notifies when the dropdown closed, used for validation. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-datepicker` | `closeDatepicker()` | `NA` | `void` | Close the datepicker. |
| `axis-datepicker` | `disableDatepicker()` | `NA` | `void` | Disables the option to select the date. |
| `axis-datepicker` | `enableDatepicker()` | `NA` | `void` | Enables the option to select the date. |
| `axis-datepicker` | `toggleDatepicker()` | `NA` | `void` | Toggles between the date selection states (enable/ disable). |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "datepicker",
  "name": "%name%",
  "label": "Select your date of birth",
  "prefix": "1.",
  "required": true,
  "isReadOnly": true,
  "datepickerMode": "month",
  "isTodayVisible": true,
  "isClearVisible": true,
  "locale": "locale",
  "customFormat": "DD/MM/YYYY",
  "browserLocale": true,
  "multiSelect": false,
  "customLocale": {
    "un-UN": "YYYY/M/D"
  },
  "useLocale": "en",
  "viewonly": false,
  "closeOnOutsideClick": true,
  "ignoreTime": false,
  "disableDays": [
    0,
    1
  ],
  "disableDates": {
    "d": "12",
    "m": "12",
    "y": "2019"
  },
  "placeholder": "Select Date",
  "ngClass": "axis-datepicker-color"
}
```

---

## Examples

### Default datepicker
**Keywords:** Datepicker, default, calendar, date, picker

### Datepicker without close on outside click and aria-labelledby
**Keywords:** Datepicker, no close, outside click, aria-labelledby, calendar, date

### Datepicker with month and year value
**Keywords:** Datepicker, month, year, calendar, date, picker

### Datepicker without today button on day mode
**Keywords:** Datepicker, no today button, day mode, calendar, date

### Datepicker without today and clear button on day mode
**Keywords:** Datepicker, no today, no clear, day mode, calendar, date



*(64 additional examples omitted for brevity. See full documentation for more patterns.)*

---
