# Radio

## Overview

**Component:** `radio`
**URL:** `components/radio`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-radio-button-wrapper` | `required` | `boolean` | `false` | No | Defines whether it is mandatory to select the radio button. true: Mandatory to select the radio button. false: Not mandatory to select the radio button. Note: Value is set to false by default. |
| `axis-radio-button-wrapper` | `retrieveValue` | `boolean` | `false` | No | Binds only value property to ngModel. Note: Default value is set to false . |
| `axis-radio` | `checked` | `boolean` | `NA` | No | Preselects the radio button if passed true. |
| `axis-radio` | `disabled` | `boolean` | `NA` | No | Disables or enables the radio button true: Disables the radio button. false: Keeps the radio button in its default state. |
| `axis-radio` | `tabIndex` | `any` | `` | No | tabIndex is used to set tabbing order of axis-radio |
| `axis-radio` | `ariaLabel` | `string` | `` | No | Accessibility: Custom ariaLabel. |
| `axis-radio` | `heading` | `string` | `NA` | Yes | Represents the label of the radio button object. |
| `axis-radio` | `name` | `string` | `NA` | Yes | Defines name of the set of the radio button objects. |
| `axis-radio` | `value` | `string` | `NA` | Yes | Defines value of the radio button object. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-radio` | `changeDetect` | Notifies with the value of the selected radio button when onChange event takes place. |
| `axis-radio` | `emitBlurEvent` | Notifies with the event when a radio button loses focus. |
| `axis-radio-button-wrapper` | `getSelectedItem` | Notifies with the name, value and index when a method is invoked. |
| `axis-radio-button-wrapper` | `getSelectedValue` | Notifies the value of the selected radio button. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-progressbar` | `cancelProgressBar()` | `none` | `void` | Stops the dynamic progess bar. |
| `axis-progressbar` | `enableCancelFeature()` | `none` | `void` | Enables the cancelProgressBar() method. |

### Selectors
| Component | Description |
|-----------|-------------|
| `axis-radio-button-wrapper` | Wrapper that contains all the axis-radio tags. |
| `axis-radio` | Attribute that creates radio button objects. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "radio",
  "name": "%name%",
  "label": "My Radio Label:",
  "options": [
    {
      "value": "yes",
      "label": "Yes",
      "componentHostClasses": "Dynamic classes- kind-primary size-small",
      "checked": true,
      "inline": true
    },
    {
      "value": "no",
      "label": "No",
      "checked": false,
      "inline": true
    },
    {
      "value": "dontKnow",
      "label": "<span class='axis-badge' data-bg='warning'>I don't know</span>",
      "checked": false,
      "inline": true
    }
  ]
}
```

---

## Examples

### Axis radio buttons
**Keywords:** Radio, axis radio, radio button, default, radio group

### Axis radio buttons custom
**Keywords:** Radio, axis radio, custom, radio button, radio group

### Axis radio buttons with custom heading and ariaLabel
**Keywords:** Radio, axis radio, custom heading, ariaLabel, radio button, radio group

### Disabled radio button
**Keywords:** Radio, disabled, radio button, axis radio, inactive

### Inline radio button
**Keywords:** Radio, inline, radio button, axis radio, horizontal



*(9 additional examples omitted for brevity. See full documentation for more patterns.)*

---
