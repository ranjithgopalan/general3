# Progress tracker

## Overview

**Component:** `progress-tracker`
**URL:** `components/progress-tracker`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-progress-tracker` | `color` | `String` | `` | No | It displays color of the tracker |
| `axis-progress-tracker` | `items` | `Array` | `` | No | It provides number of items for tracking |
| `axis-progress-tracker` | `active` | `number` | `0` | No | It displays the tracking till the 'active' number |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|


---

---

## Examples

### Default progress tracker
**Keywords:** Progress tracker, progress-tracker, default, tracker, progress, step, wizard

**TypeScript:**
```typescript
<div class="col-12 demo-body">
  <div class="_ml-xlarge _mt-xlarge">
    <axis-progress-tracker [items]="progressItems" [active]="active" spacing="none"></axis-progress-tracker>
    <div>Default tracker</div>
    <axis-progress-tracker [items]="progressItems" [active]="active" color="primary"></axis-progress-tracker>
    <div>Primary color tracker</div>
  </div>
  <div class="axis-grid _align-items-middle _mt-xlarge">
    <div class="axis-col-md-2">
      <button axis-button (click)="active=active+1" class="kind-secondary" [disabled]="active>=progressItems.length">
        @if (active<1) { <ng-container>Start Tracking </ng-container>}
        @if (active>0){ <ng-container >Next Step</ng-container>}
      </button>
    </div>
    <div class="axis-col-md-2">
      Step active: {{active}}
    </div>
    <div class="axis-col-md-1">
      <button axis-button (click)="active=0" class="kind-link" [disabled]="active<1">Reset</button>
    </div>
  </div>
</div>
```

### Use of Component Class Array in Progress Tracker
**Keywords:** Progress tracker, progress-tracker, component class array, class array, tracker, progress, step, wizard


---

---
