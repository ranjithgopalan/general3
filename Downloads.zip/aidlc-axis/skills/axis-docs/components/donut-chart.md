# Donut chart

## Overview

**Component:** `donut-chart`
**URL:** `charts/donut-chart`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-chart-donut` | `data` | `Array` | `` | Yes | Provides display data to the chart. |
| `axis-chart-donut` | `options` | `Object` | `` | No | Its an object consist of different settings for donut chart. colors: Array of colors needs to be shown. height: number - Height of the donut chart, By default it is 160 highlighted: : boolean - Option to highlight the selected chart, by default it is false. truncate: boolean - Will truncate the text if it exceeds the space. By default it is true. donutRatio: string - Specify the donut ratio. By default it is 'medium'. Available options: xsmall, small, medium, large and xlarge gradients: option to provide gradient color in the bars , it is an array. showLegend: option to show legend, by default it is 'bottom'. To hide, pass false. showTooltips: option to show tooltip on bars of chart, by default it is true. |
| `axis-chart-donut` | `center` | `Object` | `` | No | Data to be shown inside the donut chart. label: string - will be displayed at the center of the donut. value: string - displayed and highlighted at the center of the donut. size: string -'small' is the only option which works with value. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-chart-donut` | `ShowSelection` | It displays selected data. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|


---

---

## Examples

### Donut chart With three inputs
**Keywords:** Donut chart, three inputs, donut, chart, inputs

### Donut chart With five inputs
**Keywords:** Donut chart, five inputs, donut, chart, inputs

### Donut chart With dynamic data
**Keywords:** Donut chart, dynamic data, donut, chart, data

### Donut chart With single data
**Keywords:** Donut chart, single data, donut, chart, data

### Donut chart With label outside and custom tooltip
**Keywords:** Donut chart, label outside, custom tooltip, donut, chart, tooltip


---

---
