# Loading

## Overview

**Component:** `loading`
**URL:** `components/loading`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-loading` | `data-size` | `string` | `` | No | Defines the size of the loader icon small: Enables small size of loader icon. |


---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## Examples

### Inline loading component
**Keywords:** Loading, inline, loader, component, spinner, progress

### Loading component
**Keywords:** Loading, loader, component, spinner, progress

### Load multiple loaders with custom messages
**Keywords:** Loading, multiple loaders, custom message, loader, spinner, progress


---

---
