# Paginator

## Overview

**Component:** `paginator`
**URL:** `components/paginator`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-paginator` | `ariaLabel` | `string` | `` | No | Accessibility: Custom ariaLabel. |
| `axis-paginator` | `showMultiplePageSize` | `boolean` | `false` | No | To display the pageSize in static text format. |
| `axis-paginator` | `disabled` | `boolean` | `false` | No | Used to disable the paginator. |
| `axis-paginator` | `hideInput` | `boolean` | `false` | No | Used to hide search input box. |
| `axis-paginator` | `hidePageSize` | `boolean` | `false` | No | Used to hide size dropdown. |
| `axis-paginator` | `length` | `number` | `0` | No | used to no of items to display. |
| `axis-paginator` | `pageSizeOptions` | `array[]` | `[]` | No | Page size dropdown options. |
| `axis-paginator` | `pageSize` | `number` | `` | Yes | Number of items to display on each page. |
| `axis-paginator` | `pageIndex` | `number` | `1` | No | Page index to load for first time. |
| `axis-paginator` | `showFirstLastButtons` | `boolean` | `true` | No | Used to toggle first and last buttons. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-paginator` | `showItems` | Notifies with the event when a page changes. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "paginator",
  "name": "%name%",
  "label": "My Paginator:",
  "pageSize": "5",
  "pageSizeOptions": [
    1,
    2,
    3,
    4
  ],
  "items": [
    {
      "name": "Item 1"
    },
    {
      "name": "Item 2"
    },
    {
      "name": "Item 3"
    },
    {
      "name": "Item 4"
    },
    {
      "name": "Item 5"
    },
    {
      "name": "Item 6"
    },
    {
      "name": "Item 7"
    },
    {
      "name": "Item 8"
    },
    {
      "name": "Item 9"
    },
    {
      "name": "Item 10"
    },
    {
      "name": "Item 11"
    },
    {
      "name": "Item 12"
    },
    {
      "name": "Item 13"
    },
    {
      "name": "Item 14"
    },
    {
      "name": "Item 15"
    },
    {
      "name": "Item 16"
    },
    {
      "name": "Item 17"
    },
    {
      "name": "Item 18"
    },
    {
      "name": "Item 19"
    },
    {
      "name": "Item 20"
    },
    {
      "name": "Item 21"
    },
    {
      "name": "Item 22"
    },
    {
      "name": "Item 23"
    },
    {
      "name": "Item 24"
    },
    {
      "name": "Item 25"
    },
    {
      "name": "Item 26"
    },
    {
      "name": "Item 27"
    },
    {
      "name": "Item 28"
    },
    {
      "name": "Item 29"
    },
    {
      "name": "Item 30"
    }
  ]
}
```

---

## Examples

### Paginator - Basic
**Keywords:** Paginator, pagination, page, next, previous, navigation, basic paginator


---

---
