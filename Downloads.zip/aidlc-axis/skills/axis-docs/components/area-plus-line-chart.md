# Area plus line chart

## Overview

**Component:** `area-plus-line-chart`
**URL:** `charts/area-plus-line-chart`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-area-plus-line-chart` | `data` | `Array` | `NA` | Yes | Its an array consist of data to be send. areaLabel: label for area. areaLabelTooltip: tooltip for the area label. line1: Line 1 data point. if you have more line, pass it as line2, line3. line1Tooltip: Line 1 data tooltip. if you have more line, pass it as line2Tooltip, line3Tooltip. |
| `axis-area-plus-line-chart` | `options` | `object` | `NA` | Yes | Its an object consist of different settings for area plus line chart. clickableArea: option to make area clickable, by default it is false. areaLabels: array of string consist of area names. By Default it is having 2 area names. gradients: option to provide gradient color, it is an array of array of strings. [['line1Color', 'area1Color'], ['line2Color', 'area2Color']]. If you are using lineOnly as true, pass line color like [['line1Color', '']]. showLegend: option to show legend, by default it is 'bottom'. To hide, pass false. xAxisLabel: option to show x axis label name. yAxisLabel: option to show y axis label name. animation: option to show animation, by default it is true. gridLines: option to show grid lines, by default it is true. lineDashed: option to show dashed line, by default it is true. lineOnly: option to show only line and not the area, by default it is false. showTooltips: option to show tooltip, by default it is true. showValues: Displays values at top of the point in the chart, by default it is false. curve: Displays the chart with different curves user can add like d3.curveLinear,d3.curveCardinal etc,by default it is d3.curveCardinal for further information check here: https://github.com/d3/d3-shape colors: option to show colors for every value in the chart, it is a Array. numTicks: option to provide number of ticks needed on y axis, by default it is 5 |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-area-plus-line-chart` | `ShowSelection` | Gives the selected data. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---

## Examples

### Area plus line chart - 1 line
**Keywords:** Area plus line chart, 1 line, area chart, line chart, chart

### Area plus line chart - 2 lines
**Keywords:** Area plus line chart, 2 lines, area chart, line chart, chart

### Area plus line chart - 3 lines
**Keywords:** Area plus line chart, 3 lines, area chart, line chart, chart

### Line chart - 1 line
**Keywords:** Line chart, 1 line, chart


---

---
