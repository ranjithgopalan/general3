# Timepicker

## Overview

**Component:** `timepicker`
**URL:** `components/timepicker`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-timepicker` | `arrowkeys` | `boolean` | `true` | No | Increases/decreases the value of hours and minutes on clicking/pressing the arrow keys. true: Allows incrementing the time value. false: Does not allow change in time. Note: Default value is set to ' true '. |
| `axis-timepicker` | `font` | `string` | `custom` | No | custom: Timepicker icon cusom theme applied. material: Timepicker icon material theme applied. |
| `axis-timepicker` | `closeOnOutsideClick` | `boolean` | `true` | No | Defines whether the timepicker is closed on outside click or not. true: Enables the closure of timepicker on clicking outside. false: Disables the closure of timepicker on clicking outside. Note: Default Value is true . |
| `axis-timepicker` | `disabled` | `Date` | `NA` | No | Disables the timepicker. |
| `axis-timepicker` | `hourStep` | `number` | `1` | No | Sets the change in hours on clicking the arrow keys Note: Default value is set to 1 . |
| `axis-timepicker` | `max` | `Date` | `NA` | No | Sets the maximum value for time. |
| `axis-timepicker` | `min` | `Date` | `NA` | No | Sets the minimum value for time. |
| `axis-timepicker` | `minuteStep` | `number` | `5` | No | Sets the change in minutes on clicking the arrow keys. Note: Default value is set to 5 . |
| `axis-timepicker` | `required` | `Date` | `false` | No | Defines whether it is required to select the timepicker or not. true: Mandatory to select the timepicker. false: Not mandatory to select the timepicker. Note: Default Value is false . |
| `axis-timepicker` | `secondsStep` | `number` | `10` | No | Sets the change in seconds on clicking the arrow keys Note: Default value is set to 10 . |
| `axis-timepicker` | `showMeridian` | `string` | `true` | No | Displays or hides the suffix 'AM' or 'PM' based on the time format selected. true: Displays the time in AM/PM format. false: Hides the time format. Note: Default value is set to ' true '. |
| `axis-timepicker` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |
| `axis-timepicker` | `readonly` | `boolean` | `true` | No | To show control in non editable. true: Control will be keyboard editable. false: Control will be non editable with kwyboard. Note: Value is set to 'true' by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-timepicker` | `onTimepickerClose()` | Emits modelvalue(Time) or active Time when timepicker is closed. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-timepicker` | `disabletimepicker()` | `NA` | `void` | Disables the option to select time. |
| `axis-timepicker` | `enabletimepicker()` | `NA` | `void` | Enables the option to select time. |
| `axis-timepicker` | `toggletimepicker()` | `NA` | `void` | Toggles time selection options between enable or disable. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "timepicker",
  "name": "%name%",
  "label": "My Timepicker:",
  "componentHostClasses": ""
}
```

---

## Examples

### Default timepicker with editable
**Keywords:** Timepicker, default, editable, time picker, basic

**TypeScript:**
```typescript
<div class="axis-form-group">
  <axis-timepicker #timepicker1  [readonly]="false"></axis-timepicker>
  <pre class="alert alert-info">Time is : {{timepicker1.modelValue|date:"shortTime"}}</pre>
</div>
```

**HTML:**
```html
<div class="axis-form-group">
  <axis-timepicker #timepicker1  [readonly]="false"></axis-timepicker>
  <pre class="alert alert-info">Time is : {{timepicker1.modelValue|date:"shortTime"}}</pre>
</div>
```

### Timepicker without close on outside click
**Keywords:** Timepicker, no close, outside click, time picker, default

**TypeScript:**
```typescript
<div class="axis-form-group">
  <label class="axis-control-label">Timepicker</label>
  <axis-timepicker #timepicker2 [closeOnOutsideClick]="false"></axis-timepicker>
  <pre class="alert alert-info">Time is : {{timepicker2.modelValue|date:"shortTime"}}</pre>
</div>
```

**HTML:**
```html
<div class="axis-form-group">
  <label class="axis-control-label">Timepicker</label>
  <axis-timepicker #timepicker2 [closeOnOutsideClick]="false"></axis-timepicker>
  <pre class="alert alert-info">Time is : {{timepicker2.modelValue|date:"shortTime"}}</pre>
</div>
```

### Timepicker with min-max
**Keywords:** Timepicker, min, max, min-max, time range, time picker

**TypeScript:**
```typescript
import { Component } from '@angular/core';

@Component({
  ...
})

export class yourComponentName {
  ....
  public mytime: Date = new Date();
  public min: Date = new Date();
  public max: Date = new Date();
  constructor() {
        this.mytime.setHours(10);
        this.min.setHours(8);
        this.min.setMinutes(0);
        this.max.setHours(19);
        this.max.setMinutes(0);
      }
}
```

**HTML:**
```html
<div class="col-12 demo-body">
  <div>{{min|date:"shortTime"}}-{{max|date:"shortTime"}}</div>
    <form>
      <div class="axis-form-group"  [class.has-axis-error]="timepicker3.invalid">
        <label class="axis-control-label">Timepicker</label>
        <axis-timepicker #timepicker3="ngModel" name="tmpkr56" [min]="min" [max]="max" [(ngModel)]="mytime"></axis-timepicker>
        <pre class="alert alert-info">Time is : {{mytime|date:"shortTime"}}</pre>
      </div>
    </form>
</div>
```

### Timepicker with show seconds
**Keywords:** Timepicker, seconds, show seconds, time picker

**TypeScript:**
```typescript
<div class="axis-form-group">
  <label class="axis-control-label">Timepicker</label>
  <axis-timepicker #timepicker4 [showSeconds]="true"></axis-timepicker>
  <pre class="alert alert-info">Time is : {{timepicker4.modelValue|date:"hh:mm:ss"}}</pre>
</div>
```

**HTML:**
```html
<div class="axis-form-group">
  <label class="axis-control-label">Timepicker</label>
  <axis-timepicker #timepicker4 [showSeconds]="true"></axis-timepicker>
  <pre class="alert alert-info">Time is : {{timepicker4.modelValue|date:"hh:mm:ss"}}</pre>
</div>
```

### Timepicker with 12/24hr Format
**Keywords:** Timepicker, 12hr, 24hr, format, 12/24 hour, time format, time picker

**TypeScript:**
```typescript
import { Component } from '@angular/core';

@Component({
  ...
})

export class yourComponentName {
  ....
  public timePickerFormat: string = 'shortTime';
  public ismeridian: boolean = true;
  public mytime4: any;
  toggleMeridian(): void {
    this.ismeridian = !this.ismeridian;
    if(this.ismeridian) {
      this.timePickerFormat = 'shortTime';
    }else {
      this.timePickerFormat = 'HH:mm';
    }
  }
}
```

**HTML:**
```html
<div class="axis-form-group">
  <label class="axis-control-label">Timepicker</label>
  <axis-timepicker #timepicker5 [showMeridian]="ismeridian"  [(ngModel)]="mytime4"></axis-timepicker>
  <pre class="alert alert-info">Time is : {{timepicker5.modelValue|date:timePickerFormat}}</pre>
  <button axis-button class="kind-primary" (click)="toggleMeridian()">12hr/24hr</button>
</div>
```



*(8 additional examples omitted for brevity. See full documentation for more patterns.)*

---
