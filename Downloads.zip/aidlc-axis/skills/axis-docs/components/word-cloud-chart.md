# Word cloud chart

## Overview

**Component:** `word-cloud`
**URL:** `charts/word-cloud`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-wordcloud-chart` | `data` | `Array` | `NA` | Yes | Its an array of words which forms the wordcloud color: Will update the color of the text in which it is applied |
| `axis-wordcloud-chart` | `spirals` | `string` | `NA` | No | Refering to the selected sprial Method |
| `axis-wordcloud-chart` | `options` | `object` | `NA` | No | Its an object consist of different settings for the chart animationDuration: set the animation duration, by default it is 0 showTooltips: option to showtooltip, by default it is true wordPadding: padding between the words, by default it is 5 cursor: cursor style to be shown when the word hovered, by default it is 'default' rotate: horizontally rotated word to be shown, by default it is false fontWeight: word font weight, by default it is 'bold' enableLazyRender: option to load charts lazily when it comes inside viewport area, it accepts boolean value and default value is false. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-wordcloud-chart` | `getSelectedData` | Gives the selected word data |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---

## Examples

### Word cloud without tooltip
**Keywords:** Word cloud chart, no tooltip, word cloud, chart, without tooltip

### Word cloud with tooltip
**Keywords:** Word cloud chart, tooltip, word cloud, chart

### Word cloud with tooltip with tab
**Keywords:** Word cloud chart, tooltip, tab, word cloud, chart

### Word cloud with tooltip with modal
**Keywords:** Word cloud chart, tooltip, modal, popup, word cloud, chart


---

---
