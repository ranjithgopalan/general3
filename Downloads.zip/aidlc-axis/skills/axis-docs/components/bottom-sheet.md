# Bottom-sheet

## Overview

**Component:** `bottomSheet`
**URL:** `components/bottom-sheet`

---

---

## API Reference

### Inputs

| Property | Type | Default | Required | Description |
|----------|------|---------|----------|-------------|
| *See examples below* | | | | |

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "bottomSheet",
  "name": "%name%",
  "id": "bottomsheet1",
  "size": "a",
  "componentHostClasses": "_bg-primary size-medium",
  "bottomSheetInterface": {
    "icon": "",
    "text": "Open Bottom Sheet"
  },
  "htmlContent": "<p><h1>This bottom sheet can contain any content</h1></p>",
  "config": {
    "closeOnOutsideClick": true,
    "closeOnEscape": true,
    "hasBackdrop": true
  }
}
```

---

## Examples

### Default Bottom Sheet
**Keywords:** Bottom Sheet, default, sheet, modal, bottom, popup

### Bottom Sheet without Backdrop
**Keywords:** Bottom Sheet, no backdrop, sheet, modal, bottom, popup, transparent

### Disable Backdrop click and ESC key
**Keywords:** Bottom Sheet, disable backdrop, disable esc, sheet, modal, bottom, popup, no close, prevent close

### Emit Output Events
**Keywords:** Bottom Sheet, output event, emit, event, sheet, modal, bottom, popup, callback


---

---
