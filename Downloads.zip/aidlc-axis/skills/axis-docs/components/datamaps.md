# Datamaps

## Overview

**Component:** `datamaps`
**URL:** `charts/datamaps`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-datamaps-chart` | `chartData` | `object` | `NA` | Yes | Its an object of states/country which we have to display in map fillKey : color need to be shown value - by default value to be shown on tooltip |
| `axis-datamaps-chart` | `chartOptions` | `object` | `NA` | No | Its an object consist of different settings for the map scope: set scope of the map, by default it is 'usa' showTooltip: option to show tooltip, by default it is true id: unique id for the map valueAttribute: chart data property name whose value to be shown in tootltip, by default it is 'value' chartFills: colors to be shown for different parts in map labels: to show state name in map, by default it is true labelsRegions: to show region label in map with region, by default it is false regions: to show map with different regions, by default it is false labelsBubbles: to show labels inside bubble, by default it is false projection: to set projection view of datamap (equirectangular or mercator), by default it is equirectangular height: to set height of data map |
| `axis-datamaps-chart` | `bubbles` | `Array` | `NA` | No | Its an array of object consist of different values with respective to the bubble |
| `axis-datamaps-chart` | `hideLabel` | `Boolean` | `NA` | No | To hide label text by passsing hideLabel:true in options. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-datamaps-chart` | `getSelectedItem` | Gives the selected data |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---

## Examples

### US map with location markers - by state
**Keywords:** Datamaps, US map, location markers, state, map, markers

### US map - by state with different fill color
**Keywords:** Datamaps, US map, state, fill color, map, chart

###  US map - by region
**Keywords:** Datamaps, US map, region, map, chart

###  World map
**Keywords:** Datamaps, world map, map, chart, global

### Regions with bubbles
**Keywords:** Datamaps, regions, bubbles, map, chart



*(3 additional examples omitted for brevity. See full documentation for more patterns.)*

---
