# Date range picker

## Overview

**Component:** `date-range`
**URL:** `components/date-range`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-date-range` | `customFormat` | `string` | `MMM DD, YYYY` | No | Defines which format of date . customFormat ='DD-MM-YYYY' Displays the input in 'DD-MM-YYYY' format. customFormat ='DD.MM.YYYY' Displays the input in 'DD.MM.YYYY' format. |
| `axis-date-range` | `closeOnOutsideClick` | `boolean` | `false` | No | Defines whether the calendar must be visible or not. true: Enables the closure of calendar on clicking outside. false: Disables the closure of calendar on clicking outside. Note: Default value is set to false . |
| `axis-date-range` | `disableDate` | `Object` | `` | No | Defines the selection of disable dates. from: From represents from which date you want to disable the date. to: To represents until which date you want to disable the date. |
| `axis-date-range` | `minDate` | `Date` | `NA` | No | Sets a minimum range for the date. |
| `axis-date-range` | `maxDate` | `Date` | `NA` | No | Sets a maximum range for the date. |
| `axis-date-range` | `useLocale` | `string` | `NA` | No | Defines the calendar in useLocale input language rather than browser language. Eg: 'ja','en','fr','es','nb' currently only these languages supported etc. |
| `axis-date-range` | `config` | `Object` | `{isInputVisible: true,label: '',isIconVisible: false}` | No | Defines the visibility of input,icon,label.You can override all or the individuals |
| `axis-date-range` | `customList` | `Array` | `` | No | Array of Objects that can be provided for customList public customList = [ { key: 'today', value: 'Today' },{ key: 'month', value: 'Month' }, { key: 'lastFiveYears', value: 'Last 5 Years' }, { key: 'lastSevenYears', value: 'Last 7 Years' }, { key: 'lastTenYears', value: 'Last 10 Years' }, { key: 'thisQuarter', value: 'This Quarter' }, { key: 'lastQuarter', value: 'Last Quarter' }, { key: 'nextQuarter', value: 'Next Quarter' }, { key: 'lastTwoYearsFromToday', value: 'Last Two Years from Today' }, { key: '-30', value: 'Last 30 Days from Today' }, { key: '-160', value: 'Last 160 Days from Today' }, { key: '-14', value: 'Last 14 Days from Today' { key: '14', value: 'Next 14 Days from Today' }, { key: '30', value: 'Next 30 Days from Today' }, { key: '60', value: 'Next 60 Days from Today' }, { key: 'custom', value: 'Custom' } ] or List of objects that can be provided for customList This object way is deprecated please use array of objects instead {'custom':'Custom', 'today':'Today', 'yesterday':'Yesterday', 'thisWeek':'This Week', 'lastWeek':'Last Week', 'thisMonth':'This Month', 'lastMonth':'Last Month', 'thisYear':'This Year', 'lastYear':'Last Year', 'lastFiveYears':'Last 5 Years', 'lastSevenYears':'Last 7 Years', 'lastTenYears':'Last 10 Years', 'thisQuarter':'This Quarter', 'lastQuarter':'Last Quarter', 'nextQuarter':'Next Quarter'} |
| `axis-date-range` | `placeholder` | `string` | `MMM DD, YYYY - MMM DD, YYYY` | No | Defines placeholder text in input . placeholder ='MMM DD, YYYY - MMM DD, YYYY' Displays the placeholder text. |
| `axis-date-range` | `datepickerMode` | `string` | `day` | No | Defines which picker to enable . datepickerMode ='month' Displays the monthPicker calendar. |
| `axis-date-range` | `ariaLabelledby` | `string` | `NA` | No | Accessibility: aria-labelledby. |
| `axis-date-range` | `monthsGap` | `string` | `1` | No | Defines gap between months in calendars ex:monthsGap=4 it displays from august-november. |
| `axis-date-range` | `ariaLabel` | `string` | `Please select date range` | No | Defines the aria-label for input. |
| `axis-date-range` | `required` | `boolean` | `NA` | No | Required for validation. |
| `axis-date-range` | `disabled` | `boolean` | `NA` | No | Disabled if true. |
| `axis-date-range` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-date-range` | `onSelectRange` | Displays the value of the selected range date. |
| `axis-date-range` | `onSelectDate` | Displays the value of the selected range date when user click on any date |


---

---

## Examples

### Default date range picker using ngModel with customList,minDate,maxDate
**Keywords:** Date range, date range picker, ngModel, customList, minDate, maxDate, default

### Default date range picker with reactive form
**Keywords:** Date range, date range picker, reactive form, form, default

### Date range picker with custom format (DD-MM-YYYY) and aria-label
**Keywords:** Date range, date range picker, custom format, DD-MM-YYYY, aria-label

### Date range picker with template driven and validation
**Keywords:** Date range, date range picker, template driven, validation, form

### Date range picker with reactive form and validation
**Keywords:** Date range, date range picker, reactive form, validation, form



*(4 additional examples omitted for brevity. See full documentation for more patterns.)*

---
