# Styled-list

## Overview

**Component:** `styled-list`
**URL:** `components/styled-list`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-styled-list` | `dataProvider` | `object` | `` | No | List items that needs to be displayed as list item. config: Configuration of list. start and type is only applicable for ordered list. listStyle: 'square' Ordered list will display with given style type. refer below for various input https://css-tricks.com/almanac/properties/l/list-style/ . class: 'axis-list' custom classes to change style of list. classItems: '' used to pass classes which will apply on each list item. class: '' used to pass classes on each item object which will apply on provided list item. size: 'large' list items will be displays in bigger size. col: 2/3/4/5 unordered list items will be displays in mentioned columns i.e. 2/3/4/5. separator: true unordered list items will be displays with separator. kind: 'icon' unordered list items will be displays with icon at begining. Icon color, name, font can be provided in list. kind: 'timeline' unordered list items will be displays as timeline. kind: 'timeline', dashed: true unordered list items will be displays as dashed timeline. start: 50 ordered list items numbering will start from given number. type: 1 ordered list items will be numbered with numbers. type: a ordered list items will be numbered with lowercase letters. type: A ordered list items will be numbered with uppercase letters. type: I ordered list items will be numbered with uppercase roman numbers. type: i ordered list items will be numbered with lowercase roman numbers. list: Accepts array of objects which will be displayed as list items. name is required property in the object. |
| `axis-styled-list` | `listStyle` | `string` | `` | No | Accepts styling of items. 1. inline: Display list items as inline. 2. inline-pills: Display list items as inline. 3. inline-dots: Display list items as inline with dots. |
| `axis-styled-list` | `orderedList` | `boolean` | `false` | No | Display list items as ordered/unordered. default will display unordered. true: Display ordered list. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|


---

---

## Examples

### Unordered list
**Keywords:** Styled list, unordered, bulleted, list, ul, bullet points

### Ordered list
**Keywords:** Styled list, ordered, numbered, list, ol, numbers

### Timeline list
**Keywords:** Styled list, timeline, list, timeline list, steps, progress

### Timeline dashed list
**Keywords:** Styled list, timeline, dashed, list, timeline dashed, steps, progress

### Cross icon list
**Keywords:** Styled list, cross icon, list, icon list, cross, x mark, error



*(7 additional examples omitted for brevity. See full documentation for more patterns.)*

---
