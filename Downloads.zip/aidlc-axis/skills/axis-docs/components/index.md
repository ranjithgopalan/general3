# Axis Components Index

Comprehensive documentation for all 78 Axis UI Angular components (v18.0.32).

Each component file includes:
- **API Reference**: Inputs, Outputs, Methods
- **AUG JSON Structure**: For dynamic form generation
- **Examples**: TypeScript and HTML code samples

## Quick Lookup

| Component | File |
|-----------|------|
| Accordion | [accordion.md](./accordion.md) |
| Alert | [alert.md](./alert.md) |
| Aqi | [aqi.md](./aqi.md) |
| Area Plus Line Chart | [area-plus-line-chart.md](./area-plus-line-chart.md) |
| Aug Documentation | [aug-documentation.md](./aug-documentation.md) |
| Aug | [aug.md](./aug.md) |
| Bar Plus Multi Line Chart | [bar-plus-multi-line-chart.md](./bar-plus-multi-line-chart.md) |
| Bodymap | [bodymap.md](./bodymap.md) |
| Bottom Sheet | [bottom-sheet.md](./bottom-sheet.md) |
| Breadcrumb | [breadcrumb.md](./breadcrumb.md) |
| Bubble Chart | [bubble-chart.md](./bubble-chart.md) |
| Button | [button.md](./button.md) |
| Cache Service | [cache-service.md](./cache-service.md) |
| Calendar | [calendar.md](./calendar.md) |
| Can Deactivate | [can-deactivate.md](./can-deactivate.md) |
| Captcha | [captcha.md](./captcha.md) |
| Card | [card.md](./card.md) |
| Carousel | [carousel.md](./carousel.md) |
| Checkbox | [checkbox.md](./checkbox.md) |
| Chip | [chip.md](./chip.md) |
| Count | [count.md](./count.md) |
| Customvalidators | [customvalidators.md](./customvalidators.md) |
| D3 Charts | [d3-charts.md](./d3-charts.md) |
| Datagrid | [datagrid.md](./datagrid.md) |
| Datamaps | [datamaps.md](./datamaps.md) |
| Date Range Picker | [date-range-picker.md](./date-range-picker.md) |
| Datepicker | [datepicker.md](./datepicker.md) |
| Donut Chart | [donut-chart.md](./donut-chart.md) |
| Dropdown | [dropdown.md](./dropdown.md) |
| Duallist | [duallist.md](./duallist.md) |
| Editor | [editor.md](./editor.md) |
| Examples | [examples.md](./examples.md) |
| File Upload | [file-upload.md](./file-upload.md) |
| Funnel Chart | [funnel-chart.md](./funnel-chart.md) |
| Gauge Chart | [gauge-chart.md](./gauge-chart.md) |
| Helper Functions | [helper-functions.md](./helper-functions.md) |
| Horizontal Bar Chart | [horizontal-bar-chart.md](./horizontal-bar-chart.md) |
| Horizontal Stacked Chart | [horizontal-stacked-chart.md](./horizontal-stacked-chart.md) |
| Horizontal Stacked Progress Chart | [horizontal-stacked-progress-chart.md](./horizontal-stacked-progress-chart.md) |
| Icon | [icon.md](./icon.md) |
| Input | [input.md](./input.md) |
| Json Translator | [json-translator.md](./json-translator.md) |
| List | [list.md](./list.md) |
| Loading | [loading.md](./loading.md) |
| Logger | [logger.md](./logger.md) |
| Media | [media.md](./media.md) |
| Modal | [modal.md](./modal.md) |
| Multi Bar Grouped Chart | [multi-bar-grouped-chart.md](./multi-bar-grouped-chart.md) |
| Navbar | [navbar.md](./navbar.md) |
| Notifications | [notifications.md](./notifications.md) |
| Paginator | [paginator.md](./paginator.md) |
| Portal Menu | [portal-menu.md](./portal-menu.md) |
| Progress Bar | [progress-bar.md](./progress-bar.md) |
| Progress Chart | [progress-chart.md](./progress-chart.md) |
| Progress Step | [progress-step.md](./progress-step.md) |
| Progress Tracker | [progress-tracker.md](./progress-tracker.md) |
| Radio | [radio.md](./radio.md) |
| Rating | [rating.md](./rating.md) |
| Screen Capture | [screen-capture.md](./screen-capture.md) |
| Scroll Container | [scroll-container.md](./scroll-container.md) |
| Scroll2B | [scroll2b.md](./scroll2b.md) |
| Search Account | [search-account.md](./search-account.md) |
| Search Address | [search-address.md](./search-address.md) |
| Simple Feedback | [simple-feedback.md](./simple-feedback.md) |
| Slider | [slider.md](./slider.md) |
| Styled List | [styled-list.md](./styled-list.md) |
| Tab | [tab.md](./tab.md) |
| Timepicker | [timepicker.md](./timepicker.md) |
| Timer | [timer.md](./timer.md) |
| Tooltip | [tooltip.md](./tooltip.md) |
| Tour | [tour.md](./tour.md) |
| Tree | [tree.md](./tree.md) |
| Truncate | [truncate.md](./truncate.md) |
| Word Cloud Chart | [word-cloud-chart.md](./word-cloud-chart.md) |

**Total Components:** 74
