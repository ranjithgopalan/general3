# Datagrid

## Overview

**Component:** `data-grid`
**URL:** `data-grid`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-datagrid` | `gridModel` | `Object` | `` | Yes | Defines the json form structure of the components. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-datagrid` | `uiEmitUpdate` | Notifies with data on change in grid. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "datagrid",
  "name": "%name%",
  "componentHostClasses": "",
  "size": "a",
  "gridModel": {
    "config": {
      "name": "MyTable1",
      "rowHeight": 30,
      "bufferRows": 15,
      "agpFixed": false,
      "useApiOnScroll": false,
      "ariaLabel": "Grid aria label info",
      "scrollType": "normal",
      "agpSort": {
        "load": true,
        "concurrentSorting": false,
        "columnNames": [
          "name",
          "surname",
          "age",
          "country"
        ]
      }
    },
    "header": {
      "config": {},
      "rows": [
        {
          "config": {},
          "rowIndex": 0,
          "cells": [
            {
              "content": " ",
              "type": "checkbox",
              "alias": "check",
              "columnsWidth": {
                "min": "50px",
                "max": "150px",
                "width": "150px",
                "fraction": 0.5
              }
            },
            {
              "content": "Name",
              "type": "text",
              "alias": "name",
              "columnsWidth": {
                "min": "50px",
                "max": "250px",
                "width": "250px",
                "fraction": 2
              }
            },
            {
              "content": "Surname",
              "type": "text",
              "alias": "surname",
              "columnsWidth": {
                "min": "50px",
                "max": "250px",
                "width": "250px",
                "fraction": 2
              }
            },
            {
              "content": "Age",
              "type": "number",
              "alias": "age",
              "columnsWidth": {
                "min": "50px",
                "max": "250px",
                "width": "250px",
                "fraction": 2
              }
            },
            {
              "content": "Country",
              "type": "text",
              "alias": "country",
              "columnsWidth": {
                "min": "50px",
                "max": "250px",
                "width": "250px",
                "fraction": 2
              }
            },
            {
              "content": "Id",
              "type": "text",
              "alias": "id",
              "hideColumn": true,
              "columnsWidth": {
                "fraction": 0.5,
                "min": "50px",
                "max": "200px",
                "width": "200px"
              }
            }
          ]
        }
      ]
    },
    "body": {
      "config": {
        "totalCount": 102
      },
      "rows": [
        {
          "config": {},
          "rowIndex": 0,
          "cells": [
            {
              "mapTo": "check",
              "data-heading": ""
            },
            {
              "mapTo": "name",
              "content": "Lorem"
            },
            {
              "mapTo": "surname",
              "content": "Ipsum"
            },
            {
              "mapTo": "age",
              "content": "78"
            },
            {
              "mapTo": "country",
              "content": "Japan"
            }
          ]
        },
        {
          "config": {},
          "rowIndex": 1,
          "cells": [
            {
              "mapTo": "check",
              "data-heading": ""
            },
            {
              "mapTo": "name",
              "content": "Lorem1"
            },
            {
              "mapTo": "surname",
              "content": "Ipsum1"
            },
            {
              "mapTo": "age",
              "content": "18"
            },
            {
              "mapTo": "country",
              "content": "Russia"
            }
          ]
        },
        {
          "config": {},
          "rowIndex": 2,
          "cells": [
            {
              "mapTo": "check",
              "data-heading": ""
            },
            {
              "mapTo": "name",
              "content": "Lorem2"
            },
            {
              "mapTo": "surname",
              "content": "Ipsum2"
            },
            {
              "mapTo": "age",
              "content": "33"
            },
            {
              "mapTo": "country",
              "content": "Spain"
            }
          ]
        },
        {
          "config": {},
          "rowIndex": 3,
          "cells": [
            {
              "mapTo": "check",
              "data-heading": ""
            },
            {
              "mapTo": "name",
              "content": "Lorem3"
            },
            {
              "mapTo": "surname",
              "content": "Ipsum3"
            },
            {
              "mapTo": "age",
              "content": "25"
            },
            {
              "mapTo": "country",
              "content": "Republic Dominican"
            }
          ]
        },
        {
          "config": {},
          "rowIndex": 4,
          "cells": [
            {
              "mapTo": "check",
              "data-heading": ""
            },
            {
              "mapTo": "name",
              "content": "Lorem4"
            },
            {
              "mapTo": "surname",
              "content": "Ipsum4"
            },
            {
              "mapTo": "age",
              "content": "61"
            },
            {
              "mapTo": "country",
              "content": "United Arab Emirates"
            }
          ]
        }
      ]
    }
  }
}
```

---

## Examples

### Axis datagrid integration steps
**Keywords:** Axis datagrid, datagrid integration, integration steps, datagrid overview, grid documentation, overview, data grid, table grid, docs

### Full feature (Hyperlink enabled and hidden select all checkbox)
**Keywords:** Full feature, hyperlink, select all checkbox, hidden checkbox, address search, features

### Basic Datagrid with disabled row selection and number formatting
**Keywords:** Datagrid, disabled row selection, number formatting, basic grid, table, row selection

### Incremental table grid
**Keywords:** Incremental grid, table grid, incremental, pagination, load more, table

### Sticky virtual scroll
**Keywords:** Sticky virtual scroll, virtual scroll, sticky header, table grid, scroll



*(23 additional examples omitted for brevity. See full documentation for more patterns.)*

---
