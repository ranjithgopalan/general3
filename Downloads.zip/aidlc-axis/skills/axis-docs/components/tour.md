# Tour

## Overview

**Component:** `tour`
**URL:** `components/tour`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|


---

---

## Examples

### Tour integration steps
**Keywords:** Tour, integration, steps, tour documentation, guide, walkthrough

### Tour example
**Keywords:** Tour, example, demo, tour example, walkthrough, guide


---

---
