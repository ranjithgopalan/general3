# Breadcrumb

## Overview

**Component:** `breadcrumb`
**URL:** `components/bread-crumb`

---

---

## API Reference

### Inputs

| Property | Type | Default | Required | Description |
|----------|------|---------|----------|-------------|
| *See examples below* | | | | |

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "breadcrumb",
  "name": "%name%",
  "dataProvider": [
    {
      "active": true,
      "ariaCurrent": "step",
      "link": "#",
      "icon": "home",
      "font": "custom",
      "name": "Home"
    },
    {
      "active": false,
      "link": "#",
      "icon": "view_module",
      "font": "custom",
      "name": "Components"
    },
    {
      "active": false,
      "name": "BreadCrumbs"
    }
  ]
}
```

---

## Examples

### Breadcrumb - basic
**Keywords:** Breadcrumb, basic, navigation, path, trail

**TypeScript:**
```typescript
import { Component } from '@angular/core';
@Component({
  ...
})
export class yourComponent {
    public dataProviderBasic = [
        { active: true, ariaCurrent: 'page', name: 'Top-level link' },
        { name: 'Middle-level link' },
        { name: 'Active link' }
    ];
}
```

**HTML:**
```html
<axis-breadcrumb [dataProvider]="dataProviderBasic" />
```

### Breadcrumb - icon with link and text
**Keywords:** Breadcrumb, icon, link, text, navigation, path, trail

**TypeScript:**
```typescript
import { Component } from '@angular/core';
@Component({
  ...
})
export class yourComponent {
    public dataProviderIcontext = [
      { active: true, ariaCurrent: 'page', link: '#', icon: 'home', font: 'custom', name: 'Home' },
      { active: false, link: '#', icon: 'view_module', font: 'custom', name: 'Components' },
      { active: false, name: 'BreadCrumbs' }
    ];
}
```

**HTML:**
```html
<axis-breadcrumb [dataProvider]="dataProviderIcontext" class="kind-slash" />
```

### Breadcrumb - icon
**Keywords:** Breadcrumb, icon, navigation, path, trail

**TypeScript:**
```typescript
import { Component } from '@angular/core';
@Component({
  ...
})
export class yourComponent {
    public dataProviderIcon = [
    {
      active: true,
      ariaCurrent: "page",
      font: "custom",
      icon: 'home',
      ariaLabel:'home',
      content: 'Home',
      placement: 'top'
    },
    {
      icon: "view_module",
      font: "custom",
      active: false,
      ariaLabel:'view_module',
      content: 'Components'
    },
    {
      icon: "direction",
      font: "custom",
      active: false,
      ariaLabel:'direction'
    },
  ];
}
```

**HTML:**
```html
<axis-breadcrumb [dataProvider]="dataProviderIcon" />
```

### Breadcrumb with custom template
**Keywords:** Breadcrumb, custom template, template, navigation, path, trail

**TypeScript:**
```typescript
import { Component } from '@angular/core';
@Component({
  ...
})
export class yourComponent {

}
```

**HTML:**
```html
<axis-breadcrumb>
    <ul class="axis-breadcrumb">
        <li class="axis-breadcrumb-item active">
                <a> <axis-icon  class="_mr" [icon]="'home'" ></axis-icon> Home  </a>
        </li>
        <li class="axis-breadcrumb-item">
                <a> <axis-icon  class="_mr" [icon]="'view_module'" ></axis-icon> View Module  </a>
        </li>
    </ul>
</axis-breadcrumb>
```

### Breadcrumb with click event
**Keywords:** Breadcrumb, click event, event, navigation, path, trail


---

---
