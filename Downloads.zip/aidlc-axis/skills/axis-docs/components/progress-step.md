# Progress step

## Overview

**Component:** `progress-step`
**URL:** `components/progress-step`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-progress-step` | `dataProvider` | `object` | `` | No | List items that needs to be displayed as list item. config: Configuration of list like static wizard etc. list: Accepts array of objects which will be displayed as list items. name is required property in the object. data-kind:secondary It Displays larger icons with single line data-kind:teritary It Displays larger icons with no line data-kind:top It Displays names on top of icon data-kind:inline It Displays names on inline to icons data-kind:dotted It Displays dots instead of line data-kind:solid It Displays solid line data-kind:inline It Displays names on inline to icons data-kind:reverse It Displays line in reverse data-kind:inline It Displays names on inline to icons data-counter:false It won't show numbers on icon data-direction:vertical It displays progress step in vertical order data-kind:wizard It Displays icons with labels link: On click it will redirect user to respective angular router link. iconColor:warning It displays warning color to icon class:icon danger User can add multiple class here it displays danger color to the line |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|


---

---

## Examples

### Progress-Step - Basic
**Keywords:** Progress step, progress-step, basic, stepper, progress, step, wizard

### Progress-Step - with variations
**Keywords:** Progress step, progress-step, variations, stepper, progress, step, wizard, different styles

### Progress-Step - with label options
**Keywords:** Progress step, progress-step, label options, labels, stepper, progress, step, wizard

### Vertical progress steps with data-direction=vertical
**Keywords:** Progress step, progress-step, vertical, vertical steps, stepper, progress, step, wizard

### Vertical progress steps with links data-direction=vertical
**Keywords:** Progress step, progress-step, vertical, links, vertical steps, stepper, progress, step, wizard



*(2 additional examples omitted for brevity. See full documentation for more patterns.)*

---
