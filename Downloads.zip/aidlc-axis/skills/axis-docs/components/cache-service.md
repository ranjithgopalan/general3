# Cache-service

## Overview

**Component:** `cache-service`
**URL:** `components/cache-service`

---

---

---

## API Reference

### Inputs

| Property | Type | Default | Required | Description |
|----------|------|---------|----------|-------------|
| *See examples below* | | | | |

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `AxisCacheService` | `get(url = '', options = {}, useCache = true, reHydrate = true, storageType = 'sessionStorage', customKey = null)` | `<div style='text-align: justify;' class='readme-style'><span class='b'>url:</span> String - The address that will be called.</br><span class='b'><a target=_blank href=https://angular.io/guide/http>options</a>:</span> Object - The normal object passed on Angular HTTP requests.</br> <span class='b'>useCache:</span> boolean - True for caching the response and False for not caching</br><span class='b'>reHydrate:</span> boolean - True for reHydrate.</br><span class='b'>storageType:</span>string - 'localStorage', 'sessionStorage'</br><span class='b'>customKey:</span> string - Key to be used on storage instead of the MD5.</div>` | `void` | NA |
| `AxisCacheService` | `post(url = '', body = {}, options = {}, useCache = false, reHydrate = false, storageType = 'sessionStorage', customKey = null)` | `<div style='text-align: justify;' class='readme-style'><span class='b'>url:</span> String - The address that will be called.</br><span class='b'>body:</span> Object - The normal body object passed on Angular HTTP requests.</br><span class='b'><a target=_blank href=https://angular.io/guide/http>options</a>:</span> Object - The normal object passed on Angular HTTP requests.</br> <span class='b'>useCache:</span> boolean - True for caching the response and False for not caching</br><span class='b'>reHydrate:</span> boolean - True for reHydrate.</br><span class='b'>storageType:</span>string - 'localStorage', 'sessionStorage'</br><span class='b'>customKey:</span> string - Key to be used on storage instead of the MD5.</div>` | `void` | NA |
| `AxisCacheService` | `request(method = 'get', url = '', options = {}, useCache = true, reHydrate = true, storageType = 'sessionStorage', customKey = null)` | `<div style='text-align: justify;' class='readme-style'><span class='b'>method:</span> string - HTTP method name like get, post etc</br><span class='b'>url:</span> String - The address that will be called.</br><span class='b'><a target=_blank href=https://angular.io/guide/http>options</a>:</span> Object - The normal object passed on Angular HTTP requests.</br> <span class='b'>useCache:</span> boolean - true for caching the response and False for not caching</br><span class='b'>reHydrate:</span> boolean - true for reHydrate.</br><span class='b'>storageType:</span>string - 'localStorage', 'sessionStorage'</br><span class='b'>customKey:</span> string - Key to be used on storage instead of the MD5.</div>` | `void` | NA |
| `AxisCacheService` | `storageKey(method: string, url: string, options: any, customKey: string)` | `<div style='text-align: justify;' class='readme-style'><span class='b'>method:</span> string - HTTP method name like get, post etc</br><span class='b'>url:</span> String - The address that will be called.</br><span class='b'><a target=_blank href=https://angular.io/guide/http>options</a>:</span> Object - The normal object passed on Angular HTTP requests.</br> <span class='b'>customKey:</span> string - Key to be used on storage instead of the MD5.</div>` | `string` | NA |
| `AxisCacheService` | `md5String(url: string, options: any)` | `<div style='text-align: justify;' class='readme-style'><span class='b'>url:</span> string - The address that will be called.</br><span class='b'><a target=_blank href=https://angular.io/guide/http>options</a>:</span> Object - The normal object passed on Angular HTTP requests.</div>` | `string` | returns a unique string based on md5 hashing using the url and options. |


---

---

## Examples

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `AxisCacheService` | `get(url = '', options = {}, useCache = true, reHydrate = true, storageType = 'sessionStorage', customKey = null)` | `<div style='text-align: justify;' class='readme-style'><span class='b'>url:</span> String - The address that will be called.</br><span class='b'><a target=_blank href=https://angular.io/guide/http>options</a>:</span> Object - The normal object passed on Angular HTTP requests.</br> <span class='b'>useCache:</span> boolean - True for caching the response and False for not caching</br><span class='b'>reHydrate:</span> boolean - True for reHydrate.</br><span class='b'>storageType:</span>string - 'localStorage', 'sessionStorage'</br><span class='b'>customKey:</span> string - Key to be used on storage instead of the MD5.</div>` | `void` | NA |
| `AxisCacheService` | `post(url = '', body = {}, options = {}, useCache = false, reHydrate = false, storageType = 'sessionStorage', customKey = null)` | `<div style='text-align: justify;' class='readme-style'><span class='b'>url:</span> String - The address that will be called.</br><span class='b'>body:</span> Object - The normal body object passed on Angular HTTP requests.</br><span class='b'><a target=_blank href=https://angular.io/guide/http>options</a>:</span> Object - The normal object passed on Angular HTTP requests.</br> <span class='b'>useCache:</span> boolean - True for caching the response and False for not caching</br><span class='b'>reHydrate:</span> boolean - True for reHydrate.</br><span class='b'>storageType:</span>string - 'localStorage', 'sessionStorage'</br><span class='b'>customKey:</span> string - Key to be used on storage instead of the MD5.</div>` | `void` | NA |
| `AxisCacheService` | `request(method = 'get', url = '', options = {}, useCache = true, reHydrate = true, storageType = 'sessionStorage', customKey = null)` | `<div style='text-align: justify;' class='readme-style'><span class='b'>method:</span> string - HTTP method name like get, post etc</br><span class='b'>url:</span> String - The address that will be called.</br><span class='b'><a target=_blank href=https://angular.io/guide/http>options</a>:</span> Object - The normal object passed on Angular HTTP requests.</br> <span class='b'>useCache:</span> boolean - true for caching the response and False for not caching</br><span class='b'>reHydrate:</span> boolean - true for reHydrate.</br><span class='b'>storageType:</span>string - 'localStorage', 'sessionStorage'</br><span class='b'>customKey:</span> string - Key to be used on storage instead of the MD5.</div>` | `void` | NA |
| `AxisCacheService` | `storageKey(method: string, url: string, options: any, customKey: string)` | `<div style='text-align: justify;' class='readme-style'><span class='b'>method:</span> string - HTTP method name like get, post etc</br><span class='b'>url:</span> String - The address that will be called.</br><span class='b'><a target=_blank href=https://angular.io/guide/http>options</a>:</span> Object - The normal object passed on Angular HTTP requests.</br> <span class='b'>customKey:</span> string - Key to be used on storage instead of the MD5.</div>` | `string` | NA |
| `AxisCacheService` | `md5String(url: string, options: any)` | `<div style='text-align: justify;' class='readme-style'><span class='b'>url:</span> string - The address that will be called.</br><span class='b'><a target=_blank href=https://angular.io/guide/http>options</a>:</span> Object - The normal object passed on Angular HTTP requests.</div>` | `string` | returns a unique string based on md5 hashing using the url and options. |


---

---
