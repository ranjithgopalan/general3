# Modal

## Overview

**Component:** `modal`
**URL:** `components/modal`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-modal` | `cancelButtonLabel` | `string` | `Close dialog` | No | Defines the close button icon aria label. |
| `axis-modal` | `closeButton` | `boolean` | `false` | No | Displays the close button. true: Close button is displayed. false: Close button is not displayed. Note: Default value is set to false . |
| `axis-modal` | `closeOnEscape` | `boolean` | `false` | No | Closes the modal on pressing the Escape key. true: The modal closes on pressing the Esc key. false: The modal remains open. Note: Default value is set to false . |
| `axis-modal` | `closeOnOutsideClick` | `boolean` | `false` | No | Defines whether the modal must be visible or not. true: Enables the closure of modal on clicking outside. false: Disables the closure of modal on clicking outside. |
| `axis-modal` | `heading` | `string` | `NA` | Yes | Defines title of the modal. |
| `axis-modal` | `height` | `string` | ` NA` | No | Defines height of the modal body. |
| `axis-modal` | `attr.data-size` | `string` | `NA` | No | Defines size of the modal. Note: Valid sizes are full (fills the viewport), medium (default), page (fills the viewport with margins), large, small, x-large, xx-large, and x-small . |
| `axis-modal` | `top` | `string` | `NA` | No | Reposition the modal. |
| `axis-modal` | `modalRole` | `string` | `dialog` | No | Defines the role of modal. Note: Value is set to dialog by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-modal` | `onClose` | Notifies when the modal is closed. |
| `axis-modal` | `onOpen` | Notifies when the modal is displayed. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-modal` | `close()` | `...args: any[]` | `void` | Closes the modal on clicking a button. |
| `axis-modal` | `open()` | `...args: any[](optional parameters)` | `void` | Opens the modal on click to pass optional parameters. |

### Selectors
| Component | Description |
|-----------|-------------|
| `axis-modal-content` | Contains content of the modal. |
| `axis-modal-footer` | Contains footer of the modal. |
| `axis-modal-header` | Contains header of the modal. |
| `axis-modal` | Contains all the modal components. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "modal",
  "name": "%name%",
  "modalInterface": {
    "icon": "",
    "text": "Open Modal",
    "componentHostClasses": "Dynamic classes- kind-primary size-small"
  },
  "header": "Modal Header",
  "htmlContent": "<p>This modal has its own header, content and footer.</p>",
  "footer": true,
  "footerCloseButton": {
    "kind": "primary",
    "size": "medium",
    "icon": "",
    "text": "Close Modal"
  }
}
```

---

## Examples

### Open modal with tooltip
**Keywords:** Modal, tooltip, open modal, open with tooltip, popup, dialog

**TypeScript:**
```typescript
import { Component} from '@angular/core';
import { ModalService } from 'axis-components';
import { TooltipPopupComponent} from './tooltipInsideModal.component';
@Component({
    ...
})

export class ApplicationModalOpenComponent{

  constructor( private modalService: ModalService) {
  }
  openTooltipPopup() {
      this.modalService.createModalComponent(TooltipPopupComponent);
  }
}
```

**HTML:**
```html
<button axis-button class="kind-primary" (click)="openTooltipPopup()">
  Open tooltip popup
</button>
```

### Open modal using link
**Keywords:** Modal, link, open modal, open with link, popup, dialog

**TypeScript:**
```typescript
None.
```

**HTML:**
```html
<button axis-button class="kind-link" (click)="firstModal1.open()">Open Modal</button>
<axis-modal #firstModal1>
  <axis-modal-header>
    <h1>I was opened on click of Link</h1>
  </axis-modal-header>
  <axis-modal-content>
    This modal has its own header, content and footer.
  </axis-modal-content>
  <axis-modal-footer>
    <div class="axis-btn-wrapper">
      <div class="axis-btn-wrapper-right">
        <button axis-button class="kind-primary" (click)="firstModal1.close()">okay!</button>
      </div>
    </div>
  </axis-modal-footer>
</axis-modal>
```

### Open modal on clicking on icon
**Keywords:** Modal, icon, open modal, open with icon, popup, dialog

**TypeScript:**
```typescript
None.
```

**HTML:**
```html
<button axis-button class="kind-icon" (click)="firstModal2.open()">
<span axis-icon icon="settings"></span>
<span class="axis-btn-icon-text">Open modal</span></button>
<axis-modal #firstModal2>
  <axis-modal-header>
    <h1>I was opened on of Link</h1>
  </axis-modal-header>
  <axis-modal-content>
    This modal has its own header, content and footer.
  </axis-modal-content>
  <axis-modal-footer>
    <div class="axis-btn-wrapper">
      <div class="axis-btn-wrapper-right">
        <button axis-button class="kind-primary" (click)="firstModal2.close()">okay!</button>
      </div>
    </div>
  </axis-modal-footer>
</axis-modal>
```

### Change of input attributes values with button event
**Keywords:** Modal, input attributes, change value, button event, dynamic modal, popup

**TypeScript:**
```typescript
import {Component} from "@angular/core";
@Component({
  ...
})
export class ModalOpenComponent{
    public isClose:boolean = false;
    public size:string = 'small';
    public height:string = '200px';
    toggleCloseButtonVal() {
        this.isClose = !this.isClose;
    }
    changeSize() {
        this.size = 'large';
    }
    changeHeight() {
        this.height = '1000px';
    }
}
```

**HTML:**
```html
<button axis-button class="kind-icon" (click)="firstModal22.open()">
<span axis-icon icon="settings"></span>
<span class="axis-btn-icon-text">Open modal</span></button>
<axis-modal #firstModal22 [closeButton]="isClose" class="size-{{size}}" [height]="height">
  <axis-modal-header>
    <h1>I was opened on of Link</h1>
  </axis-modal-header>
  <axis-modal-content>
    This modal has its own header, content and footer.
  </axis-modal-content>
  <axis-modal-footer>
    <div class="axis-btn-wrapper">
      <div class="axis-btn-wrapper-right">
        <button axis-button class="kind-primary" (click)="firstModal22.close()">okay!</button>
      </div>
    </div>
  </axis-modal-footer>
</axis-modal>
<button axis-button class="kind-secondary" (click)="toggleCloseButtonVal()">Toggle Close Button</button>
<button axis-button class="kind-secondary" (click)="changeSize()">Change Size</button>
<button axis-button class="kind-secondary" (click)="changeHeight()">Change Height</button>
```

### Large modal without footer
**Keywords:** Modal, large, no footer, popup, dialog, large modal

**TypeScript:**
```typescript
None.
```

**HTML:**
```html
<button axis-button class="kind-primary" (click)="largeModal.open()">Open Large</button>
<axis-modal #largeModal class="'size-large'" [closeButton]="true">
  <axis-modal-header>
    <h1>Large Modal</h1>
  </axis-modal-header>
  <axis-modal-content>
    Content...
  </axis-modal-content>
</axis-modal>
```



*(17 additional examples omitted for brevity. See full documentation for more patterns.)*

---
