# Duallist

## Overview

**Component:** `duallist`
**URL:** `components/duallist`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-dual-list` | `availableItems` | `Array` | `NA` | Yes | Defines the list of items loaded in the first column of the dual listbox. |
| `axis-dual-list` | `height` | `number` | `200` | No | Defines the height of the dual listbox. |
| `axis-dual-list` | `renderingLabel` | `string` | `NA` | No | Displays the text for each label in the dual listbox. |
| `axis-dual-list` | `selectedItems` | `Array` | `NA` | No | Defines the list of selected items of the dual listbox. |
| `axis-dual-list` | `showAddAllBtn` | `boolean` | `true` | No | Displays or hides the Add All button. true: Displays the Add All button. false: Hides the Add All button. Note: Default Value is set to true. |
| `axis-dual-list` | `showAddBtn` | `boolean` | `true` | No | Displays or hides the Add button. true: Displays the Add button. false: Hides the Add button. Note: Default Value is set to true |
| `axis-dual-list` | `showMoveDownBtn` | `boolean` | `true` | No | Displays or hides the Move Down button. true: Displays the Move Down button. false: Hides the Move Down button. Note: Default Value is set to true. |
| `axis-dual-list` | `showMoveUpBtn` | `boolean` | `true` | No | Displays or hides the Move Up button. true: Displays the Move Up button. false: Hides the Move Up button. Note: Default Value is set to true. |
| `axis-dual-list` | `showRemoveAllBtn` | `boolean` | `true` | No | Displays or hides the Remove All button. true: Displays the Remove All button. false: Hides the Remove All button. Note: Default Value is set to true. |
| `axis-dual-list` | `showRemoveBtn` | `boolean` | `true` | No | Displays or hides the Remove button. true: Displays the Remove button. false: Hides the Remove button. Note: Default Value is set to true. |
| `axis-dual-list` | `width` | `number` | `150` | No | Defines the width of the dual listbox. |
| `axis-dual-list` | `ariaLabelLeft` | `string` | `Source listbox` | No | Defines the aria label for the source listbox. |
| `axis-dual-list` | `ariaLabelRight` | `string` | `Destination listbox` | No | Defines the aria label for the destination listbox. |
| `axis-dual-list` | `draggable` | `boolean` | `false` | No | Enables list to be draggable to change the order. true: List will become draggable. false: List won't be draggable. Note: Default Value is set to false. |
| `axis-dual-list` | `showSearch` | `boolean` | `false` | No | Displays or hides the search option. true: Displays the search option. false: Hides the search option. Note: Default Value is set to false. |
| `axis-dual-list` | `showCheckBox` | `boolean` | `false` | No | Displays or hides the checkbox. true: Displays the checkbox. false: Hides the checkbox. Note: Default Value is set to false. |
| `axis-dual-list` | `axisIncludeComponent` | `component` | `none` | No | Allows adding a custom template from dynamic component. |
| `axis-dual-list` | `showControls` | `boolean` | `true` | No | Display or hide the accessibility buttons. true: Display the accessibility buttons. false: Hide the accessibility buttons. Note: Default Value is set to true. |
| `` | `rightHeader` | `string` | `none` | No | Add right header to Duallist when list is draggable. |
| `` | `leftHeader` | `string` | `none` | No | Add left header to Duallist when list is draggable. |
| `` | `data-justified` | `boolean` | `none` | No | To achieve 100% width pass data-justified='true' to dual list |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-dual-list` | `onSelectionDone` | Notifies with the value of selected labels. |
| `axis-dual-list` | `getFocused` | Notifies with the value of currently clicked/selected/focused element. Returned object example : {isLeftPanel: false, item: {}, isSelected: true } isLeftPanel : Whether the item clicked is in left panel or not item : The details of item selected/unselected isSelected : Whether the item is selected or unselected. |
| `axis-dual-list` | `getAllFocused` | Notifies with the value of all selected elements. Returned object example : {isLeftPanel: true, items: [{}, {}], isSelected: false } isLeftPanel : Whether the item clicked is in left panel or not items : The array of details of all items selected isSelected : Whether the item is selected or unselected. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "dualList",
  "name": "%name%",
  "label": "List of Countries:",
  "availableItems": [
    {
      "name": "India"
    },
    {
      "name": "USA"
    },
    {
      "name": "UK"
    },
    {
      "name": "UAE"
    },
    {
      "name": "USSR"
    },
    {
      "name": "Mexico"
    },
    {
      "name": "Brazil"
    },
    {
      "name": "France"
    },
    {
      "name": "Germany"
    },
    {
      "name": "Japan"
    },
    {
      "name": "Korea"
    },
    {
      "name": "Croatia"
    },
    {
      "name": "Israel"
    },
    {
      "name": "Australia"
    },
    {
      "name": "Cuba"
    },
    {
      "name": "Chile"
    }
  ]
}
```

---

## Examples

### Simple dual list
**Keywords:** Dual list, simple, list, transfer, move, basic

**TypeScript:**
```typescript
<axis-dual-list #adl [availableItems]="items" (onSelectionDone)="onSelection1($event)"></axis-dual-list>
      <p>{{selectedData | json}}</p>
```

### Dual list with output events and custom aria-label
**Keywords:** Dual list, output event, aria-label, event, custom, accessibility

**TypeScript:**
```typescript
<axis-dual-list #ad2 [availableItems]="items" [ariaLabelLeft]="'select eligible countries from the list'"
  [ariaLabelRight]="'remove non-eligible countries from the list'" (onSelectionDone)="selectedValues($event)" (getFocusedItem)="currentFocused($event)" (getAllFocusedItems)="currentAllFocused($event)">
</axis-dual-list>
<p>{{selectedItems | json}}</p>
<p>{{currentlyFocused | json}}</p>
<p>{{currentlyAllFocused | json}}</p>
```

### Dual list without add all and remove all options
**Keywords:** Dual list, no add all, no remove all, options, list, transfer

**TypeScript:**
```typescript
<axis-dual-list #ad3 [availableItems]="items" [showAddAllBtn]="false" (onSelectionDone)="onSelection2($event)" [showRemoveAllBtn]="false"></axis-dual-list>
<p>{{selectedData1 | json}}</p>
```

### Dual list with specified width and height
**Keywords:** Dual list, width, height, size, custom size, list

**TypeScript:**
```typescript
<div class="col-12 demo-body">
  <axis-dual-list #adl2 [width]="200" (onSelectionDone)="onSelection3($event)" [height]="300" [availableItems]="items"></axis-dual-list>
  <p>{{selectedData2 | json}}</p>
</div>
```

### Dual list with rendering label
**Keywords:** Dual list, label, rendering, custom label, list

**TypeScript:**
```typescript
<axis-dual-list #adl4 [availableItems]="items1" (onSelectionDone)="onSelection4($event)" renderingLabel="value"></axis-dual-list>
<p>{{selectedData3 | json}}</p>
```



*(5 additional examples omitted for brevity. See full documentation for more patterns.)*

---
