# AUG

## Overview

**Component:** `aug`
**URL:** `aug`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-ui-generator` | `uiStructure` | `Object` | `` | Yes | Defines the json form structure of the components. |
| `axis-ui-generator` | `uiData` | `Object` | `` | Yes | Defines the json Object containing data for each field. |
| `axis-ui-generator` | `refresh` | `Object` | `null` | No | Defines the json Object to refresh/recreate fields on changes of any fields or structure. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-ui-generator` | `uiEmitUpdate` | Notifies with AUG form object, when any field interacted, data changes or any event triggered for a component. |
| `axis-ui-generator` | `uiEmit` | Notifies with AUG form object, when form submit button clicked. |


---

---

## Examples

### AUG integration steps
**Keywords:** AUG, integration, steps, aug integration, aug steps, aug documentation, Axis UI Generator integration

### Combine dropdown and form label with dynamic callback function on app end
**Keywords:** AUG, combine, dropdown, form label, dynamic callback, app end, aug combine

### ABC search address with city, coutry and zip code updation
**Keywords:** AUG, ABC search address, city, country, zip code, address update, aug search address

### Cascade Dropdown
**Keywords:** AUG, cascade dropdown, dropdown, cascade, aug dropdown

### Simple AUG example
**Keywords:** AUG, simple example, aug simple, basic aug, aug demo



*(33 additional examples omitted for brevity. See full documentation for more patterns.)*

---
