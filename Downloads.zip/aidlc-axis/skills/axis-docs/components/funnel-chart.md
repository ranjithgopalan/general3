# Funnel chart

## Overview

**Component:** `funnel-chart`
**URL:** `charts/funnel-chart`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-funnel-chart` | `data` | `Array` | `` | Yes | Provides display data to the chart. color color can be passed in data object to show colors that needs to be shown. |
| `axis-funnel-chart` | `options` | `Object` | `` | No | Its an object consist of different settings for funnel chart. enableLazyRender: option to load charts lazily when it comes inside viewport area, it accepts boolean value and default value is false. height: to set height of chart width: to set width of chart gradient: Array of colors needs to be shown user can pass in 'gradients' option inside gradient. dynamicHeight: boolean - Option to change shape of chart, by default it is false. tooltip: object - Option to show tooltip of chart, by default it is enabled as false. margin: object - Option to change position of chart. value: boolean - Option to show value on chart, by default it is enabled as false. valueFormat: function - Option to change value formathe chart. labelFormat: function - Option to change label format of the chart. customTooltip: function - Option to change tooltip format of the chart. label: object - Option to format label of the chart, by default it is enabled as false it had options like fontsize,format etc. truncate: boolean - Will truncate the text if it exceeds the space. By default it is true. animation: object - Option to change animation of the chart, by default it is enabled as true it had options like duration,easing etc. inverted: boolean - Will invert the whole chart. By default it is false. |


---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## Examples

### Funnel chart
**Keywords:** Funnel chart, chart, funnel

### Funnel chart with enableLazyRender
**Keywords:** Funnel chart, lazy render, chart, funnel


---

---
