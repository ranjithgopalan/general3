# Horizontal stacked progress chart

## Overview

**Component:** `horizontal-stacked-progress-chart`
**URL:** `charts/horizontal-stacked-progress-chart`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-horizontal-stacked-progress-chart` | `options` | `Object` | `` | Yes | Its an object consist of different settings for horizontal stacked progress chart. label: option to show labels on bars of horizontal stacked chart, by default it is string (label: 'Current' | 'Potential') . showTooltips: option to show tooltip on bars of chart, by default it is false. scale: option to show scales on bars of chart , it is a Array . (scale: [0 | 10 | 20]) . showScale: option to show scales on chart , it is a boolean. colorIndicator: option to show indicator color on bars of chart, it is a string. (colorIndicator:'blue') , colors: option to show colors for every value in the chart, it is a Array. (colors:['mediumpurple' | 'lightsalmon' | 'mediumaquamarine']) xAxisLabels: option to show xlabels for the chart, it is a Array. (xAxisLabels: [0 | 10 | 35 | 69 | 84 |100]) animation: option to provide animation for chart, it is a boolean. showLegend: option to show legend, by default it is 'bottom'. To hide, pass false |
| `axis-horizontal-stacked-progress-chart` | `indicators` | `Object` | `` | Yes | Its an object consist of different settings for horizontal stacked progress chart. size: option to show size of chart. (size:small| medium | xsmall) label: option to show labels on bars, it is string. (label: 'Past' | 'Current') placement: option to show placement on horizontal stacked chart,it is string. ( placement: top | bottom | right | left) value: option to show value,it is number. |
| `axis-horizontal-stacked-progress-chart` | `data` | `Object` | `` | Yes | Provides the data to the horizontal stacked progress chart. text: option to show text when tooltip is given. value: option to show value. it is a number ariaLabel: option to show arial labels either 'text' or 'arialLabel' or 'label' is given. ( ariaLabel: 'Liability 17%') ArrowLeft : To navigate to previous list. ArrowRight : To navigate to next list. Home : To navigate to first list. End : To navigate to last list. it is a string |

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---

## Examples

### Default horizontal stacked progress chart
**Keywords:** Horizontal stacked progress chart, default, progress chart, horizontal, stacked, chart

### Horizontal stacked progress chart with tooltip
**Keywords:** Horizontal stacked progress chart, tooltip, progress chart, horizontal, stacked, chart

### Horizontal stacked progress chart with scale
**Keywords:** Horizontal stacked progress chart, scale, progress chart, horizontal, stacked, chart

### Horizontal stacked progress chart with indicators
**Keywords:** Horizontal stacked progress chart, indicators, progress chart, horizontal, stacked, chart

### Horizontal stacked progress chart with scale and indicators
**Keywords:** Horizontal stacked progress chart, scale, indicators, progress chart, horizontal, stacked, chart



*(4 additional examples omitted for brevity. See full documentation for more patterns.)*

---
