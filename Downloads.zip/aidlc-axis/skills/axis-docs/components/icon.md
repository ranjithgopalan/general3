# Icon

## Overview

**Component:** `icon`
**URL:** `components/icon`

---

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-icon` | `icon` | `string` | `none` | Yes | Defines the kind of icon (no default). |
| `axis-icon` | `attr.data-color` | `string` | `none` | No | Assigns color css to the icon. These colors are defined in an external format. Note: Possible values are: success, info, warning, danger. |
| `axis-icon` | `attr.data-size` | `string` | `none` | No | Defines the size of an icon. Note: Possible values are: x-small, small, large, xlarge, xxlarge, xxxlarge, xxxx-large. |
| `axis-icon` | `attr.data-rotate` | `string` | `NA` | No | This is an attribute which applies css to rotate the icon. right: Enables the rotation from right to left. left: Enables the rotation from left to right. |
| `axis-icon` | `font` | `string` | `material` | No | Defined to load icon styles from material library or custom library. Note: Default value is material and can be configured as font='custom' for custom icons. |
| `axis-icon` | `type` | `string` | `material-icons` | No | Defines a particular icon to be selected from a given list. Note: If icon=' material-icon ', all the possible icons are listed and recognized within the component. |
| `axis-icon` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `NA` | `NA` | NA |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---

## Examples

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-icon` | `icon` | `string` | `none` | Yes | Defines the kind of icon (no default). |
| `axis-icon` | `attr.data-color` | `string` | `none` | No | Assigns color css to the icon. These colors are defined in an external format. Note: Possible values are: success, info, warning, danger. |
| `axis-icon` | `attr.data-size` | `string` | `none` | No | Defines the size of an icon. Note: Possible values are: x-small, small, large, xlarge, xxlarge, xxxlarge, xxxx-large. |
| `axis-icon` | `attr.data-rotate` | `string` | `NA` | No | This is an attribute which applies css to rotate the icon. right: Enables the rotation from right to left. left: Enables the rotation from left to right. |
| `axis-icon` | `font` | `string` | `material` | No | Defined to load icon styles from material library or custom library. Note: Default value is material and can be configured as font='custom' for custom icons. |
| `axis-icon` | `type` | `string` | `material-icons` | No | Defines a particular icon to be selected from a given list. Note: If icon=' material-icon ', all the possible icons are listed and recognized within the component. |
| `axis-icon` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `NA` | `NA` | NA |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---
