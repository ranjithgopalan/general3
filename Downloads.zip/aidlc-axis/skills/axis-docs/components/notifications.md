# Notifications

## Overview

**Component:** `notifications`
**URL:** `business-components/notifications`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-notifications` | `config` | `object` | `NA` | Yes | It's an object that consists of app-name and configurations for base URL and relative URLs.There are multiple relative URLs for different operations. Please find below the properties of the config object. APP_NAME: Represents app name. NOTIFICATION_BASE_URL: Base URL to get notification. RELATIVE_URL_ALL_NOTIFICATION: Relative URL to get all the notifications. RELATIVE_URL_MARK_NOTIFICATION_READ: Relative URL to update the notifications as read. RELATIVE_URL_DELETE_NOTIFICATION: Relative URL to delete the notification. RELATIVE_URL_CHECK_NOTIFICATION: Relative URL to check the new notifications. NOTIFICATION_INTERVAL: Time interval(in Seconds) to check for new notifications. |
| `axis-notifications` | `refreshMode` | `boolean` | `true` | No | It's an input variable which will decide whether watch for new notification or not.It can be controlled by user.And by default it will be true. |
| `axis-notifications` | `icon` | `object` | `NA` | No | It's an object that consists of following attributes. name: Name of icon title: Sets the tooltip of icon ariaLabel: Sets the aria-label of icon |
| `axis-notifications` | `axisIncludeComponent` | `component` | `NA` | No | Allows adding a custom template from dynamic component. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-notifications` | `toggleNotification($event, scrolling?)` | It will be used to toggle the notification popup. |
| `AxisNotificationService` | `getMessageOnNotification` | Emits an array of notification objects on the application side initially for all notifications and later whenever there is a new notification |
| `AxisNotificationService` | `getMessageOnAction` | Emits the notification object when the user clicks on any action notification. |


---

---

## Examples

### Axis notification with okta authentication
**Keywords:** Notifications, okta, authentication, axis notification, auth, login, secure

### Axis notification with icon configuration
**Keywords:** Notifications, icon, configuration, axis notification, icon config, custom icon

### Axis notification with external template
**Keywords:** Notifications, external template, axis notification, custom template, template


---

---
