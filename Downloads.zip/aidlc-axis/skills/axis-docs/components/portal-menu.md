# Portal Menu

## Overview

**Component:** `portal-menu`
**URL:** `business-components/portal-menu`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-abc-portal-menu` | `currentAppName` | `string` | `''` | Yes | Defines the name of the application. |
| `axis-abc-portal-menu` | `menuObject` | `Object` | `null` | Yes | This is a json object for the menu bar links. |
| `axis-abc-portal-menu` | `menuType` | `string` | `bar` | No | This is a configuration for the menu. Provide any string other than bar to get the thumbnails for all the links. Note: Default value is bar |
| `axis-abc-portal-menu` | `notificationObject` | `Object` | `null` | No | This is a json object for the menu bar notifications. |


---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## Examples

### Portal menu nav bar with menu items
**Keywords:** Portal menu, nav bar, menu items, navigation, portal navigation, navbar, menu

### Portal menu nav bar with menu items and cards with thumbnails
**Keywords:** Portal menu, nav bar, menu items, cards, thumbnails, card thumbnails, portal navigation, navbar, menu, card

### Portal menu nav bar with menu items and notifications
**Keywords:** Portal menu, nav bar, menu items, notifications, portal notifications, navbar, menu, notification


---

---
