# Bubble chart

## Overview

**Component:** `bubble-chart`
**URL:** `charts/bubble-chart`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-bubble-chart` | `options` | `Object` | `` | Yes | Its an object consist of different settings for bubble chart. height: option to provide height to chart. width: option to provide width to chart. tooltip: option to show tooltip in chart, by default it is true. fill: option to fill image completely in the bubble, by default it is false. enableLazyRender: option to load charts lazily when it comes inside viewport area, it accepts boolean value and default value is false. |
| `axis-gauge-chart` | `data` | `Object` | `` | Yes | Provides the data to the bubble chart. data: text for every bubble in chart, it is a string. count: numerical value for every bubble in chart, it is a number. image: path of image to be displayed in the bubble. color: color to fill the bubble, it is a string. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-bubble-chart` | `ShowSelection` | It displays selected data. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---

## Examples

### Bubble chart basic
**Keywords:** Bubble chart, basic, bubble, chart

### Bubble chart with images
**Keywords:** Bubble chart, images, bubble, chart, icons

### Bubble chart with images as icons
**Keywords:** Bubble chart, images as icons, bubble, chart, icons

### Bubble chart with tab
**Keywords:** Bubble chart, tab, bubble, chart, tabbed

### Bubble chart with modal
**Keywords:** Bubble chart, modal, bubble, chart, popup


---

---
