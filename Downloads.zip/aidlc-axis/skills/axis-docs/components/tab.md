# Tab

## Overview

**Component:** `tab`
**URL:** `components/tab`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-tab` | `active` | `boolean` | `false` | No | Preselects a tab when a page is loaded. true: Selects the tab on page load. false: Does not select the tab on page load. Note: Default value is set to false . |
| `axis-tab` | `disabled` | `boolean` | `false` | No | Disables the tab. true: Disables the tab. false: Enables the tab. Note: Default value is set to false . |
| `axis-tab` | `heading` | `string` | `NA` | Yes | Displays the tab title. Refer to axis-tab-heading and *getTabHeading. |
| `axis-tab` | `ariaLabel` | `string` | `NA` | No | Accessibility: Custom aria-label. |
| `axis-tab-set` | `ariaLabel` | `string` | `NA` | No | Accessibility: Custom aria-label. |
| `axis-tab-set` | `responsive` | `boolean` | `true` | No | Displays the tab as dropdown in mobile device true: Displays the tab as dropdown in mobile device. false: Displays the tab as it is. |
| `axis-tab-set` | `isScroll` | `boolean` | `false` | No | Displays the tabs as scrollable in smaller screens like mobile etc. |
| `axis-tab-wrapper` | `data-kind` | `string` | `primary` | No | Sets the style for the tabs. Note: Styles are categorized as: primary, secondary, icon . |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-tab` | `onSelect` | Notifies with the selected tab index. |
| `axis-tab` | `onDeSelect` | Notifies with deselected tab index. |
| `axis-tab` | `onContentInit` | Notifies when the content within a tab is initialized. Note: This process occurs only once. |
| `axis-tab-set` | `tabChange` | Notifies with the tab index of the selected item. |
| `axis-tab-set` | `onTabSelection` | Notifies with the tab object of the selected item. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-tab-set` | `setActiveTabWithIndex()` | `index` | `void` | Notifies with the tab index of the selected item. |

### Selectors
| Component | Description |
|-----------|-------------|
| `axis-tab-heading` | A container used to display customized tab headings. Note: Possible options are icons, error message headings, etc. Refer Tabs, Example 11. |
| `axis-tab-content` | Displays content of the tab. |
| `axis-tab-options` | A container used to display custmized tab options on the right side of the tab bar. |
| `axis-tab-set` | A container that consists of the set of tabs along with tab options as defined with *getTabOptions. |
| `axis-tab-wrapper` | Wrapper that defines the type of tab sets. Note: The possible type of tabs are: primary/secondary/icons. |
| `*getTabHeading` | This directive is used to assign customized titles to the tab. |
| `*getTabOptions` | This directive alligns tab options in horizontal manner on the right side of the tab bar. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "tab",
  "name": "%name%",
  "label": "My Tab Buttons:",
  "groups": [
    {
      "heading": "1. Plain Text Tab",
      "content": "This tab contains plain text... you can drop any component inside any tab..."
    },
    {
      "heading": "2. Tab with components",
      "content": [
        {
          "type": "card",
          "vcard": "card-group",
          "name": "userInfoCard",
          "size": "a",
          "fields": [
            {
              "type": "content",
              "vcard": "content",
              "value": "User Information",
              "kind": "h5",
              "size": "a",
              "name": "userInfoContent"
            },
            {
              "type": "text",
              "vcard": "text",
              "size": "b",
              "label": "First Name",
              "name": "userFirstName",
              "placeholder": "Enter first name",
              "required": "true",
              "inputClear": "true",
              "inputType": "text",
              "minLength": 3,
              "autocomplete": "off",
              "errorMessages": {
                "required": "first name is required."
              }
            },
            {
              "type": "text",
              "vcard": "text",
              "size": "b",
              "label": "Last Name",
              "name": "userLastName",
              "placeholder": "Enter last name",
              "required": "true",
              "inputClear": "true",
              "inputType": "text",
              "autocomplete": "off",
              "errorMessages": {
                "required": "last name is required."
              }
            },
            {
              "type": "text",
              "vcard": "text",
              "size": "e",
              "label": "User Age",
              "name": "userAge",
              "placeholder": "Enter age",
              "axisSettings": {
                "max": 100,
                "round": "-2",
                "restrict": true,
                "suffix": "",
                "decimal_separator": ".",
                "thousands_separator": ",",
                "fraction_size": null,
                "min": "",
                "prefix": "",
                "reg_exp": "",
                "decimal": "",
                "max_length": "",
                "view_roundoff": false
              },
              "required": "true",
              "inputClear": "true",
              "inputType": "text",
              "autocomplete": "off",
              "errorMessages": {
                "required": "age is required."
              }
            },
            {
              "type": "text",
              "vcard": "text",
              "size": "b",
              "inputType": "email",
              "label": "User email",
              "placeholder": "Enter email",
              "name": "userEmail",
              "inputClear": "true",
              "autocomplete": "off"
            },
            {
              "type": "text",
              "vcard": "text",
              "size": "c",
              "label": "User Phone",
              "name": "userPhone",
              "placeholder": "Enter phone number",
              "axisSettings": {
                "reg_exp": "^\\d{1,10}$",
                "decimal_separator": ".",
                "fraction_size": null,
                "max": "",
                "min": "",
                "prefix": "",
                "suffix": "",
                "thousands_separator": "",
                "decimal": "",
                "restrict": false,
                "max_length": "",
                "view_roundoff": false
              },
              "inputClear": "true",
              "inputType": "text",
              "autocomplete": "off"
            }
          ],
          "sectionName": "form1"
        }
      ]
    },
    {
      "heading": "3. Tab with components/charts",
      "content": [
        {
          "type": "datepicker",
          "name": "iterationStartDate",
          "label": "Iteration Start Date:",
          "vcard": "datepicker",
          "size": "c",
          "isReadOnly": "true",
          "datepickerMode": "day"
        },
        {
          "type": "datepicker",
          "name": "iterationEndDate",
          "label": "Iteration End Date:",
          "vcard": "datepicker",
          "size": "c",
          "isReadOnly": "true",
          "datepickerMode": "day"
        },
        {
          "type": "datepicker",
          "name": "analysisMonth",
          "label": "Analysis Month:",
          "vcard": "datepicker",
          "size": "c",
          "isReadOnly": "true",
          "datepickerMode": "month"
        },
        {
          "type": "content",
          "name": "analysisplaceholder",
          "value": "Iteration Data Analysis:",
          "kind": "h5",
          "size": "a",
          "vcard": "content"
        },
        {
          "type": "horizontalBarChart",
          "name": "analysisHorizontalBarChart",
          "chartData": [
            {
              "label": "7",
              "labels": [
                "80",
                "8"
              ],
              "tooltips": [
                "80",
                "8"
              ],
              "values": [
                80,
                8
              ]
            },
            {
              "label": "7",
              "values": []
            },
            {
              "label": "6",
              "labels": [
                "20",
                "10"
              ],
              "tooltips": [
                "20",
                "10"
              ],
              "values": [
                20,
                10
              ]
            },
            {
              "label": "6",
              "values": []
            },
            {
              "label": "5",
              "labels": [
                "30",
                "5"
              ],
              "tooltips": [
                "30",
                "5"
              ],
              "values": [
                30,
                5
              ]
            },
            {
              "label": "5",
              "values": []
            },
            {
              "label": "4",
              "labels": [
                "40",
                "0"
              ],
              "tooltips": [
                "40",
                "0"
              ],
              "values": [
                40,
                0
              ]
            },
            {
              "label": "4",
              "values": []
            },
            {
              "label": "3",
              "labels": [
                "50",
                "4"
              ],
              "tooltips": [
                "50",
                "4"
              ],
              "values": [
                50,
                4
              ]
            },
            {
              "label": "3",
              "values": []
            },
            {
              "label": "2",
              "labels": [
                "60",
                "3"
              ],
              "tooltips": [
                "60",
                "3"
              ],
              "values": [
                60,
                3
              ]
            },
            {
              "label": "2",
              "values": []
            },
            {
              "label": "1",
              "labels": [
                "70",
                "2"
              ],
              "tooltips": [
                "70",
                "2"
              ],
              "values": [
                70,
                2
              ]
            },
            {
              "label": "1",
              "values": []
            }
          ],
          "options": {
            "bars": {
              "labelLeft1": "Planned Stories",
              "labelRight1": "Completed Stories"
            },
            "narrow": true,
            "xAxis": {
              "axisLabel": "User Story Points"
            },
            "yAxis": {
              "axisLabel": "Iterations"
            },
            "yWidth": 14,
            "showLegend": false,
            "clickableBars": true
          },
          "vcard": "horizontal-bar-chart",
          "size": "a"
        }
      ]
    },
    {
      "heading": "4. Error Tab",
      "content": "This is Error Tab with plain text... you can drop any component inside any tab...",
      "error": true
    },
    {
      "heading": "5. Disabled Tab",
      "content": "Disabled Tab...",
      "disabled": true
    }
  ],
  "options": [
    {
      "name": "Google",
      "link": "http://www.google.com"
    },
    {
      "name": "Email",
      "hashLink": "userEmail"
    }
  ]
}
```

---

## Examples

### Primary tabs with [responsive] = 'false'
**Keywords:** Tab, tabs, primary, responsive, no responsive, default, axis tab

**TypeScript:**
```typescript
import { Component , ViewChild } from '@angular/core';

@Component({
    ...
})
export class yourComponentName {
    public customAriaLabel = 'Custom aria-label for axis tab set';
    public isHidden = false;
    public selectedValue = "Tab 2 Show";
    @ViewChild('tab1') tab1: any;
    @ViewChild('tab2') tab2: any;
    onContentInit(){
        console.log("tab content initiated");
    }
    showTab(event:any) {
        this.isHidden = false;
      }
      hideTab(event:any) {
        this.isHidden = true;
        if (this.tab2.active) {
          this.tab1.active = true;
          this.tab1.isHidden = false;
        }
      }
}
```

**HTML:**
```html
<axis-radio-button-wrapper [(ngModel)]="selectedValue" name="radioBtn2" #rbtnRef2>
    <axis-radio heading="Tab 2 Show"
    name="inline"
    value="Tab 2 Show"
    (changeDetect) = showTab($event)
    class="inline">
</axis-radio>
<axis-radio heading="Tab 2 Hide"
    name="inline"
    value="Tab 2 Hide"
    (changeDetect) = hideTab($event)
    class="inline">
</axis-radio>
</axis-radio-button-wrapper>
<axis-tab-wrapper>
    <axis-tab-set [responsive]="false" [ariaLabel]='customAriaLabel'>
        <axis-tab heading="Tab 1" #tab1  (onContentInit)="onContentInit()">
            <axis-tab-content>
                This is content of the 'Tab 1'
            </axis-tab-content>
        </axis-tab>
        @if(!isHidden){
        <axis-tab heading="Tab 2"  #tab2 >
            <axis-tab-content>
                This is content of the 'Tab 2'
            </axis-tab-content>
        </axis-tab>
      }
        <axis-tab heading="Tab 3" >
            <axis-tab-content>
                Content of the 'Tab 3'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 4">
            <axis-tab-content>
                Content of the Tab 4
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 5">
            <axis-tab-content>
                Content of the Tab 5
            </axis-tab-content>
        </axis-tab>
    </axis-tab-set>
</axis-tab-wrapper>
```

### Secondary tabs
**Keywords:** Tab, tabs, secondary, axis tab, default

**TypeScript:**
```typescript
<axis-tab-wrapper class="kind-secondary">
    <axis-tab-set>
        <axis-tab heading="Tab 1" >
            <axis-tab-content>
                This is content of the 'Tab 1'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 2">
            <axis-tab-content>
                This is content of the 'Tab 2'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 3">
            <axis-tab-content>
                This is content of the 'Tab 3'
            </axis-tab-content>
        </axis-tab>
    </axis-tab-set>
</axis-tab-wrapper>
```

**HTML:**
```html
<axis-tab-wrapper class="kind-secondary">
    <axis-tab-set>
        <axis-tab heading="Tab 1" >
            <axis-tab-content>
                This is content of the 'Tab 1'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 2">
            <axis-tab-content>
                This is content of the 'Tab 2'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 3">
            <axis-tab-content>
                This is content of the 'Tab 3'
            </axis-tab-content>
        </axis-tab>
    </axis-tab-set>
</axis-tab-wrapper>
```

### Right-aligned tab options
**Keywords:** Tab, tabs, right aligned, right align, options, axis tab

**TypeScript:**
```typescript
<axis-tab-wrapper>
    <axis-tab-set>
        <axis-tab heading="Tab 1" >
            <axis-tab-content>
                This is content of the 'Tab 1'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 2">
            <axis-tab-content>
                This is content of the 'Tab 2'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 3">
            <axis-tab-content>
                This is content of the 'Tab 3'
            </axis-tab-content>
        </axis-tab>
        <axis-tab-options *getTabOptions>
            <ul class="axis-list-inline axis-list-pills">
                <li><a href="page1.html">Preferences</a></li>
                <li><a href="page2.html">Explore</a></li>
            </ul>
        </axis-tab-options>
    </axis-tab-set>
</axis-tab-wrapper>


<axis-tab-wrapper class="kind-secondary">
    <axis-tab-set>
        <axis-tab heading="Tab 1" >
            <axis-tab-content>
                This is content of the 'Tab 1'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 2">
            <axis-tab-content>
                This is content of the 'Tab 2'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 3">
            <axis-tab-content>
                This is content of the 'Tab 3'
            </axis-tab-content>
        </axis-tab>
        <axis-tab-options *getTabOptions>
            <ul class="axis-list-inline axis-list-pills">
                <li><a href="page1.html">Preferences</a></li>
                <li><a href="page2.html">Explore</a></li>
            </ul>
        </axis-tab-options>
    </axis-tab-set>
</axis-tab-wrapper>
```

**HTML:**
```html
<axis-tab-wrapper>
    <axis-tab-set>
        <axis-tab heading="Tab 1" >
            <axis-tab-content>
                This is content of the 'Tab 1'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 2">
            <axis-tab-content>
                This is content of the 'Tab 2'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 3">
            <axis-tab-content>
                This is content of the 'Tab 3'
            </axis-tab-content>
        </axis-tab>
        <axis-tab-options *getTabOptions>
            <ul class="axis-list-inline axis-list-pills">
                <li><a href="page1.html">Preferences</a></li>
                <li><a href="page2.html">Explore</a></li>
            </ul>
        </axis-tab-options>
    </axis-tab-set>
</axis-tab-wrapper>


<axis-tab-wrapper class="kind-secondary">
    <axis-tab-set>
        <axis-tab heading="Tab 1" >
            <axis-tab-content>
                This is content of the 'Tab 1'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 2">
            <axis-tab-content>
                This is content of the 'Tab 2'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 3">
            <axis-tab-content>
                This is content of the 'Tab 3'
            </axis-tab-content>
        </axis-tab>
        <axis-tab-options *getTabOptions>
            <ul class="axis-list-inline axis-list-pills">
                <li><a href="page1.html">Preferences</a></li>
                <li><a href="page2.html">Explore</a></li>
            </ul>
        </axis-tab-options>
    </axis-tab-set>
</axis-tab-wrapper>
```

### Default selection/preselecting tab
**Keywords:** Tab, tabs, default selection, preselect, preselected, axis tab

**TypeScript:**
```typescript
<axis-tab-wrapper class="kind-secondary">
    <axis-tab-set>
        <axis-tab heading="Tab 1" >
            <axis-tab-content>
                This is content of the 'Tab 1'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 2" [active]="true">
            <axis-tab-content>
                This is content of Default selected tab
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 3">
            <axis-tab-content>
                This is content of the 'Tab 3'
            </axis-tab-content>
        </axis-tab>
    </axis-tab-set>
</axis-tab-wrapper>
```

**HTML:**
```html
<axis-tab-wrapper class="kind-secondary">
    <axis-tab-set>
        <axis-tab heading="Tab 1" >
            <axis-tab-content>
                This is content of the 'Tab 1'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 2" [active]="true">
            <axis-tab-content>
                This is content of Default selected tab
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 3">
            <axis-tab-content>
                This is content of the 'Tab 3'
            </axis-tab-content>
        </axis-tab>
    </axis-tab-set>
</axis-tab-wrapper>
```

### Second tab configured with nested tables
**Keywords:** Tab, tabs, nested tables, second tab, axis tab, table in tab

**TypeScript:**
```typescript
<axis-tab-wrapper class="kind-secondary">
    <axis-tab-set>
        <axis-tab heading="Tab 1">
            <axis-tab-content>
                This is content of the 'Tab 1'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Nested tab">
            <axis-tab-content>
            <table class="axis-table axis-table-basic ng-scope">
                <thead>
                    <tr>
                        <th>Table Heading 1</th>
                        <th>Table Heading 2</th>
                        <th>Table Heading 3</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <td colspan="3">Table Footer</td>
                    </tr>
                </tfoot>
                <tbody>
                    <tr>
                        <td>Column 1 content.</td>
                        <td>Column 2 content.</td>
                        <td>Column 3 content.</td>
                    </tr>
                    <tr>
                        <td>Column 1 content.</td>
                        <td>Column 2 content.</td>
                        <td>Column 3 content.</td>
                    </tr>
                    <tr>
                        <td>Column 1 content.</td>
                        <td>Column 2 content.</td>
                        <td>Column 3 content.</td>
                    </tr>
                </tbody>
            </table>
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 3">
            <axis-tab-content>
                Content of the 'Tab 3'
            </axis-tab-content>
        </axis-tab>
        <axis-tab-options *getTabOptions>
            <ul class="axis-list-inline axis-list-pills">
                <li><a href="page1.html">Preferences</a></li>
                <li><a href="page2.html">Explore</a></li>
            </ul>
        </axis-tab-options>
    </axis-tab-set>
</axis-tab-wrapper>
```

**HTML:**
```html
<axis-tab-wrapper class="kind-secondary">
    <axis-tab-set>
        <axis-tab heading="Tab 1">
            <axis-tab-content>
                This is content of the 'Tab 1'
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Nested tab">
            <axis-tab-content>
            <table class="axis-table axis-table-basic ng-scope">
                <thead>
                    <tr>
                        <th>Table Heading 1</th>
                        <th>Table Heading 2</th>
                        <th>Table Heading 3</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <td colspan="3">Table Footer</td>
                    </tr>
                </tfoot>
                <tbody>
                    <tr>
                        <td>Column 1 content.</td>
                        <td>Column 2 content.</td>
                        <td>Column 3 content.</td>
                    </tr>
                    <tr>
                        <td>Column 1 content.</td>
                        <td>Column 2 content.</td>
                        <td>Column 3 content.</td>
                    </tr>
                    <tr>
                        <td>Column 1 content.</td>
                        <td>Column 2 content.</td>
                        <td>Column 3 content.</td>
                    </tr>
                </tbody>
            </table>
            </axis-tab-content>
        </axis-tab>
        <axis-tab heading="Tab 3">
            <axis-tab-content>
                Content of the 'Tab 3'
            </axis-tab-content>
        </axis-tab>
        <axis-tab-options *getTabOptions>
            <ul class="axis-list-inline axis-list-pills">
                <li><a href="page1.html">Preferences</a></li>
                <li><a href="page2.html">Explore</a></li>
            </ul>
        </axis-tab-options>
    </axis-tab-set>
</axis-tab-wrapper>
```



*(17 additional examples omitted for brevity. See full documentation for more patterns.)*

---
