# Alert

## Overview

**Component:** `alert`
**URL:** `components/alert`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-alert,[axis-alert]` | `dismissible` | `boolean` | `NA` | No | Displays a close icon that enables the user to close the alert message manually. Note: This will be always false if 'axis-alert-heading-right' is used in axis-alert accordion type. |
| `axis-alert,[axis-alert]` | `datafadeout` | `boolean` | `false` | No | Hides the alert message after a specified timeout. true: Hides the alert message. false: No change. Note: Default value of timeout is 3000 milliseconds. |
| `axis-alert,[axis-alert]` | `data-inline` | `string` | `NA` | No | Formats the alert message to display as inline. |
| `axis-alert,[axis-alert]` | `autoClose` | `boolean` | `true` | No | Closes notification automatically after given timeout. true: Closes notification automatically after given timeout. false: Do not Closes notification automatically after given timeout.. Note: The default value is set to true. |
| `axis-alert,[axis-alert]` | `data-kind` | `string` | `warning` | No | Sets the style for the alert message. Note: Alert notifications are categorized as: alert/error, information, success, warning, question/help. |
| `axis-alert,[axis-alert]` | `type` | `string` | `NA` | No | Defines the type of alert message. we have below 3 types of alert. '': When type is empty which is default, simple alert message is displayed. notification: Message is displayed as a notification. Note: Alert notifications are categorized as: alert/error, information, success, warning, question/help . accordion: Message is displayed with accordion having expand collapse feature. |
| `axis-alert,[axis-alert]` | `timeOut` | `number` | `3000` | No | Hides the alert message based on the value of datafadeout. Note: The default value of timeout is 3000 milliseconds. |
| `axis-alert,[axis-alert]` | `top` | `string` | `NA` | No | Reposition of the notification. |
| `axis-alert,[axis-alert]` | `font` | `string` | `custom` | No | Add font style for alert ex: font=&quot;custom&quot;. |
| `axis-alert,[axis-alert]` | `isNotificationVisible` | `boolean` | `false` | No | Add isNotificationVisible to make notification visible ex: font=&quot;false&quot;. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-alert,[axis-alert]` | `onClose` | Calls closeAlert() on clicking the close icon. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-alert,[axis-alert]` | `close()` | `NA ` | `void` | Closes the alert message on clicking the close icon. |
| `axis-alert,[axis-alert]` | `openAlert()` | `NA ` | `void` | Opens the alert message/notification. |

### Selectors
| Component | Description |
|-----------|-------------|
| `axis-notification` | Provides content to the alert message of notification type. |
| `axis-alert-heading` | Provides heading to the alert accordion type. |
| `axis-alert-body` | Provides body to the alert accordion type. |
| `axis-alert-heading-right` | Provides content to the right heading of alert accordion type. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "alert",
  "name": "%name%",
  "alertMessage": "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur ab libero, omnis modi unde illo.",
  "size": "a",
  "alertType": "accordion",
  "componentHostClasses": "kind-warning",
  "timeout": 3000,
  "datafadeout": "false",
  "alertEditTab": 1,
  "reservedSpace": true
}
```

---

## Examples

### Auto dismiss
**Keywords:** Auto dismiss, alert, auto close, notification, timeout

**TypeScript:**
```typescript
<axis-alert [datafadeout]="true" [timeOut]="5000">
  This alert will dismiss in 5s
</axis-alert>
```

### Success
**Keywords:** Success, alert, success message, notification, green

**TypeScript:**
```typescript
<axis-alert class="kind-success" [dismissible]="true">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur ab libero, omnis modi unde illo.
</axis-alert>
```

### Danger
**Keywords:** Danger, alert, error, notification, red

**TypeScript:**
```typescript
<axis-alert class="kind-danger" [dismissible]="true">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur ab libero, omnis modi unde illo.
</axis-alert>
```

### Information
**Keywords:** Information, alert, info, notification, blue

**TypeScript:**
```typescript
<axis-alert class="kind-info" [dismissible]="true">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur ab libero, omnis modi unde illo.
</axis-alert>
```

### Warning
**Keywords:** Warning, alert, notification, yellow, caution

**TypeScript:**
```typescript
<axis-alert class="kind-warning" [dismissible]="true">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tenetur ab libero, omnis modi unde illo.
</axis-alert>
```



*(13 additional examples omitted for brevity. See full documentation for more patterns.)*

---
