# Editor

## Overview

**Component:** `editor`
**URL:** `components/editor`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-editor` | `elementId` | `String` | `NA` | Yes | Defines a unique ID for the axis editor. |
| `axis-editor` | `height` | `number|string` | `200` | No | To set the height of the editable area. The custom height can be a number(300) or it can be a string with or without px ('300px')/('300'), or it can be in percentage(100%) with parent(400px) height in px. Note: Default height is 200. |
| `axis-editor` | `isReadOnly` | `boolean` | `false` | No | Enables or disables the editor text area and other features. true: Disables editor. false: Enables editor. |
| `axis-editor` | `config` | `Object` | `NA` | No | This will add or remove the properties like 'advlist_bullet_styles','advlist_number_styles'. Note:This is applicable only with combination of ('advlist','lists') plugins |
| `axis-editor` | `maxLength` | `number` | `NA` | No | Specifies the maximum number of characters allowed. |
| `axis-editor` | `placeHold` | `string` | `Please enter text.` | No | Defines the placeholder text displayed on editor. |
| `axis-editor` | `resize` | `string` | `false` | No | To enable or disable the resize functionality of editor. true: Enable only vertical resize false: To disable resize. 'both': To enable resize in both directions. |
| `axis-editor` | `skinURL` | `string` | `/assets/skins/ui/oxide` | No | Editor theme. Note: Include skins folder in 'src/assets' folder of the project from 'node_modules/axis-common-lib/lib-tinymce' |
| `axis-editor` | `plugins` | `Array` | `['placeholder', 'table', 'wordcount', 'spellchecker']` | No | Enables the given plugin in the editor.Its an array of strings. Available plugins are 'placeholder', 'table', 'wordcount', 'spellchecker', 'lists', 'fullscreen', 'link' @deprecated paste |
| `axis-editor` | `toolbar` | `string` | `insertfile undo redo | styleselect | bold italic underline | strikethrough subscript superscript | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table | link,` | No | Displays the editor buttons on toolbar to customize the text on editor. @deprecated paste |
| `axis-editor` | `toolbarFlag` | `boolean` | `false` | No | Toggles(displays)the toolbar when clicked on editor(textarea) and hides the toolbar on focus out. true: Toggle feature will be enabled on toolbar false: Toolbar is static. Note: 'placeHold' input parameter should be empty. |
| `axis-editor` | `menubar` | `string` | `false/null` | No | Editor Menubar, Displays the editor button on menubar to customize the text on editor. The menubar value is a string with space separated item, possible value could be 'table format view insert edit'. Note: Menubar must be declared(buttons must be passed). |
| `axis-editor` | `menubarFlag` | `boolean` | `false` | No | Toggles(displays)the menubar when clicked on editor(textarea) and hides the menubar on focus out. true: Toggle feature will be enabled on menubar false: Menubar is static. Note: Menubar must be declared(buttons must be passed) when the menubarFlag is true. 'placeHold' input parameter should be empty |
| `axis-editor` | `required` | `boolean` | `NA` | No | Makes entering data to the editor mandatory. true: Mandatory to enter data. false: Not mandatory to enter data. |
| `axis-editor` | `spellcheckerCallback` | `Function` | `NA` | No | This property accepts function for the custom spellchecker_callback. Pass your custom function to this property. It will add the spellchecker plugin to the toolbar, disables the browser spellchecker and activates the spellchecker as per your custom function definition. This function accepts below 4 parameters: method: string - It describes the method name 'spellcheck' or 'addToDictionary'. wordList: Array - It describes the array of user entered words. success: Function - It's a success callback function to return the suggestions. failure: Function - It's a failure callback function. |
| `axis-editor` | `viewonly` | `boolean` | `false` | No | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |
| `axis-editor` | `language` | `string` | `en_US` | No | Load Editor with custom language. Supported language codes can be found on Language Table. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-editor` | `onEditorKeyup` | Notifies with the content entered by user on the keyup. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA ` | `` | NA |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "editor",
  "name": "%name%",
  "label": "My Editor:",
  "elementId": "myEditorId"
}
```

---

## Examples

### Default editor
**Keywords:** Editor, default, rich text, text editor

**TypeScript:**
```typescript
import { Component } from '@angular/core';
@Component({
  ...
})
export class DefaultEditorDemoComponent {
  public skin_url = '/assets/skins/ui/oxide'; // see Note in Read Me section for skins.
  public defaultModelData = '<p>This is a default editor text.</p>';
}
```

**HTML:**
```html
<axis-editor elementId="my-editor-id" name="editor" [(ngModel)]="defaultModelData"
        [skinURL]="skin_url"></axis-editor>
      <div>
        <span class="axis-help-block">Model Data: {{defaultModelData}}</span>
      </div>
```

### Editor with configurable placeholder,custom height,advanced list and image upload
**Keywords:** Editor, placeholder, custom height, advanced list, image upload, configurable, options

**TypeScript:**
```typescript
import { Component } from '@angular/core';
@Component({
  ...
})
export class DefaultEditorDemoComponent {
  public skin_url = '/assets/skins/ui/oxide'; // see Note in Read Me section for skins.
  public placeholder = "Type something";
  public plugins1 = ['table','advlist','lists', 'placeholder image link'];// 'advslist' plugin need 'lists'plugin to work
  public config = {
    advlist_bullet_styles: 'square',
    advlist_number_styles: 'lower-alpha',
  }
  public toolbar = 'insertfile undo redo | styleselect | paste | strikethrough subscript superscript | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table | link image';
/**
Possible Values for advlist_bullet_styles:
* default: your browser’s default style
* lower-alpha: lowercase ASCII letters, e.g. a, b, c, … z
* lower-greek: lowercase classical Greek (alpha, beta, gamma), e.g. α, β, γ …
* lower-roman: lowercase roman numerals, e.g. i, ii, iii, iv, v …
* upper-alpha: uppercase ASCII letters, e.g. A, B, C, … Z
* upper-roman: uppercase roman numerals, e.g. I, II, III, IV, V …
*/

/**
Possible Values for advlist_number_styles:
* circle: a hollow circle
* disc: a filled circle
* square: a filled square
*/
}
```

**HTML:**
```html
<axis-editor [placeHold]="placeholder" [height]="300" [config]="config" [toolbar]="toolbar" [plugins]="plugins1"
        elementId="my-editor-id1" name="editor" [skinURL]="skin_url"></axis-editor>
```

### Editor with configurable toolbar menu and custom height in percentage with parent height
**Keywords:** Editor, toolbar, menu, custom height, percentage, parent height, configurable

**TypeScript:**
```typescript
import { Component } from '@angular/core';

@Component({
  ...
})
export class DefaultEditorDemoComponent {
  public skin_url = '/assets/skins/ui/oxide'; // see Note in Read Me section for skins.
  public toolbar = 'insertfile undo redo | styleselect | paste | strikethrough subscript superscript | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table';
  public heightInPercentage = '100%'; // custom height in percentage works only when parent height is given.
}
```

**HTML:**
```html
<div style="height:400px;">
      <axis-editor [toolbar]="toolbar" elementId="my-editor-id2" [height]="heightInPercentage"
        [skinURL]="skin_url"></axis-editor>
    </div>
```

### Editor with configurable menubar with custom height in px
**Keywords:** Editor, menubar, custom height, px, pixels, configurable

**TypeScript:**
```typescript
import { Component } from '@angular/core';

@Component({
  ...
})
export class DefaultEditorDemoComponent {
  public menubar ="table format view insert edit";
  public skin_url = '/assets/skins/ui/oxide'; // see Note in Read Me section for skins.
  public heightInPx = '300px'; // height in px.
}
```

**HTML:**
```html
<div>
      <axis-editor [menubar]="menubar" elementId="my-editor-id4" [height]="heightInPx" [skinURL]="skin_url"
        [spellcheckerCallback]="spellchecker"></axis-editor>
    </div>
```

### Editor with configurable plugins with custom height in number
**Keywords:** Editor, plugins, custom height, number, configurable

**TypeScript:**
```typescript
import { Component } from '@angular/core';

@Component({
  ...
})
export class DefaultEditorDemoComponent {
  public plugins = ['table'];
  public skin_url = '/assets/skins/ui/oxide'; // see Note in Read Me section for skins.
  public heightInNumber = 400; // height in number type
}
```

**HTML:**
```html
<div>
      <axis-editor [plugins]="plugins" elementId="my-editor-id5" [height]="heightInNumber"
        [skinURL]="skin_url"></axis-editor>
    </div>
```



*(10 additional examples omitted for brevity. See full documentation for more patterns.)*

---
