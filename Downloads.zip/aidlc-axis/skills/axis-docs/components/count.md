# Count

## Overview

**Component:** `count`
**URL:** `components/count`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `[axis-countDown],[axis-counter]` | `max` | `number` | `10` | No | Defines the maximum number of characters allowed in the input field. Note: Default value is 10. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `[axis-countDown],[axis-counter]` | `counterUpdated` | Notifies with the updated counter value of the entered text. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA ` | `NA` | NA |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "countdown",
  "name": "%name%",
  "label": "Count:",
  "max": "10",
  "inputType": {
    "id": "text",
    "name": "Text"
  }
}
```

---

## Examples

### Countdown - text input
**Keywords:** Countdown, text input, input, countdown input, character countdown, limit, text

### Countdown - text area
**Keywords:** Countdown, text area, textarea, countdown textarea, character countdown, limit, text

### Countdown - input countdown with ngModel
**Keywords:** Countdown, ngModel, input, countdown input, character countdown, model, limit

### Countdown - program text input count with ngModel
**Keywords:** Countdown, ngModel, programmatic, input, countdown input, character countdown, model, limit

### Countdown - text input count with reactive form
**Keywords:** Countdown, reactive form, input, countdown input, character countdown, form, limit



*(4 additional examples omitted for brevity. See full documentation for more patterns.)*

---
