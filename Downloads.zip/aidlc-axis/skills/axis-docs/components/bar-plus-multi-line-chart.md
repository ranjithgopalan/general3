# Bar plus multi line chart

## Overview

**Component:** `bar-plus-multi-line-chart`
**URL:** `charts/bar-plus-multi-line-chart`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-bar-plus-multi-line-chart` | `options` | `Object` | `` | Yes | Its an object consist of different settings for bar plus line chart. xAxisLabel: option to provide x axis label, it is a string. y1AxisLabel: option to provide left side y axis label, it is a string. y2AxisLabel: option to provide right side y axis label, it is a string. barsLabel: option to provide legend name for bars, it is a string. linesLabels: option to show legend names for lines, it is an array of string. clickableBars: option to make bar clickable, by default it is false. selectableBars: option to make bar selectable, by default it is false. gradient: option to provide gradient color in bar, it is an array. lines: option to provide lines color, it is an array. colors: option to show colors for every value in the chart, it is a Array. numTicks: option to provide number of ticks needed on y axis, by default it is 5 gradients: option to provide gradient color in the bars , it is an array. showLegend: option to show legend, by default it is 'bottom'. To hide, pass false. showTooltips: option to show tooltip on bars of chart, by default it is true. showValuesOnBar: to show values on bar, by default it is true. |
| `axis-bar-plus-multi-line-chart` | `data` | `Array` | `` | Yes | Provides display data to the charts. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-bar-plus-multi-line-chart` | `showSelection` | It displays chartdata. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `NA` | `NA` | `NA` | `NA` | NA |


---

---

## Examples

### Bar and line chart with two lines and tooltip
**Keywords:** Bar and line chart, two lines, tooltip, bar chart, line chart

### Bar and line chart with three lines and clickable bars
**Keywords:** Bar and line chart, three lines, clickable bars, bar chart, line chart

### Bar and line chart
**Keywords:** Bar and line chart, bar chart, line chart, chart


---

---
