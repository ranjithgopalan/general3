# Media

## Overview

**Component:** `media`
**URL:** `components/media`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-media` | `data-separator` | `boolean` | `false` | No | Adds separator to the media component. Default value is false . |
| `axis-media` | `data-align` | `string` | `` | No | Aligns the item inside the media component. top: Aligns item to top. bottom: Aligns item to bottom. Note: By default content will be centre aligned. |
| `axis-media` | `data-gutter` | `string` | `` | No | Add gutter space in media component. Available options: medium, large |

### Selectors
| Component | Description |
|-----------|-------------|
| `axis-media-left` | Contains content for the left media element. |
| `axis-media-body` | Contains content for the body of media element. |
| `axis-media-right` | Contains content for the right media element. |
| `axis-media` | Contains all the media components. |


---

### Outputs

| Event | Payload | Description |
|-------|---------|-------------|
| *See examples below* | | |

---

## Examples

### Basic
**Keywords:** Media, basic, default, media component

### Media with separator, gutter and alignment
**Keywords:** Media, separator, gutter, alignment, media component, layout


---

---
