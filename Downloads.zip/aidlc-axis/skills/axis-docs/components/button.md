# Button

## Overview

**Component:** `button`
**URL:** `components/button`

---

---

## API Reference

### Inputs
| Component | Property | Type | Default | Mandatory | Description |
|-----------|----------|------|---------|-----------|-------------|
| `axis-button` | `data-kind` | `string` | `null` | No | Note: This is not input property, Its applied by css, so pass as an attribute if want to bind dynamically. Either data-kind='primary' or [attr.data-kind]='kind', where kind is variable. Assigns styles to buttons based on the value. data-kind=primary: White text on blue background. data-kind=secondary: Blue text on white background. data-kind=default: Grey text on white background. Note: By default, the value is 'null' . |
| `axis-button` | `data-size` | `string` | `null` | No | Note: This is not input property, Its applied by css, so pass as an attribute if want to bind dynamically. Either data-size='large' or [attr.data-size]='size', where size is variable. data-size=large: Display large button. data-size=small: Display small button. data-size=xsmall: Display extra small button. Note: By default, the value is 'null' . |
| `axis-button` | `data-shape` | `string` | `null` | No | Note: This is not input property, Its applied by css, so pass as an attribute if want to bind dynamically. Either data-shape='round' or [attr.data-size]='shape', where shape is variable. Assigns styles to buttons based on the value. data-shape=square: Display square shaped button. data-shape=round: Display round shaped button. . |
| `axis-button` | `data-direction` | `string` | `null` | No | Note: This is not input property, Its applied by css, so pass as an attribute if want to bind dynamically. Either data-direction='vertical' or [attr.data-direction]='direction', where direction is variable. Assigns styles to buttons based on the value. data-direction=vertical: Display icon vertically aligned to button. . |
| `axis-button` | `title` | `string` | `null` | No | Defines text to be displayed on hovering mouse over the button. |
| `axis-button-group` | `data-kind` | `string` | `null` | No | Assigns styles to buttons based on the value. data-kind=vertical: Arranges multiple buttons vertically. . |
| `axis-button-toggle` | `disabled` | `boolean` | `false` | No | Disables or enables the button. true: Disables the button. false: Enables the button. Note: Value is set to 'false' by default. |
| `axis-button-toggle` | `data-kind` | `string` | `-` | No | Assigns styles to toggle button based on the value. justified: Defines justified alignment for toggle button |
| `axis-button-toggle` | `font` | `string` | `custom` | No | Defined to load icon styles from material library or custom library. Note: The value need to be configured as font='material' for material icons. |
| `axis-button-toggle` | `isReset` | `boolean` | ` false` | No | Displays or hides a reset icon which clears the button selection on clicking. true: Displays the reset icon. false: Hides the reset icon. Note: Value is set to 'false' by default. |
| `axis-button-toggle` | `required` | `boolean` | ` false` | No | Defines if it is mandatory to select the button. true: Mandatory to select the button. false: Not mandatory to select the button. Note: Value is set to 'false' by default. |
| `axis-button-toggle-label` | `active` | `boolean` | ` false` | No | Preselects the corresponding label in toggle button group. true: Selects the label. false: Deselects the label. Note: Value is set to 'false' by default. Note: When value of index on axis-button-toggle is set as ngModel, 'active' is not needed. |
| `axis-button-toggle-label` | `ariaLabel` | `string` | `` | No | Accessibility: Custom ariaLabel. |
| `axis-button-toggle-label` | `disabled` | `boolean` | ` false` | No | Disables or enables the toggle label on which it is defined. true: Disables the toggle label. false: Enables the toggle label. Note: Value is set to 'false' by default. |
| `axis-button-toggle-label` | `value` | `string | number | boolean` | `` | No | Provide value to the corresponding toggle button labels. You can pass the corresponsing value in ngModel to pre-select. Note: If you are passing index in ngModel, then don't use this property. |
| `axis-toggle-switch` | `disabled` | `boolean` | ` false` | No | Disables or enables the toggle switch. true: Disables the toggle switch. false: Enables the toggle switch. Note: Value is set to 'false' by default. |
| `axis-toggle-switch` | `checked` | `boolean` | ` false` | No | Makes the toggle switch as ON/OFF. true: Turn toggle switch as ON. false: Turn toggle switch as OFF. Note: Value is set to 'false' by default. |
| `axis-toggle-switch` | `required` | `boolean` | ` false` | No | Defines if it is mandatory to select the toggle button. true: Mandatory to select the toggle button. false: Not mandatory to select the toggle button. Note: Value is set to 'false' by default. |

### Outputs
| Component | Property | Description |
|-----------|----------|-------------|
| `axis-toggle-button` | `emitBlurEvent` | Notifies the event when a button loses focus. |
| `axis-button-toggle` | `getSelectedIndex` | Notifies with the index of item selected. Note: Index starts with 0. |
| `axis-button-toggle` | `getSelectedValue` | Notifies with the value of item selected. Note: This will return only if you are using value property. |
| `axis-button-toggle` | `resetEvent` | Notifies the event when the reset icon is clicked. |
| `axis-button-toggle` | `viewonly` | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |
| `axis-toggle-switch` | `onToggle` | Notifies with value of the toggle switch. |
| `axis-toggle-switch` | `viewonly` | To show control in viewonly. true: Control will display in viewonly. false: Default control is shown. Note: Value is set to 'false' by default. |

### API Methods
| Component | Method | Input Params | Return Type | Description |
|-----------|--------|--------------|-------------|-------------|
| `axis-button-toggle` | `clearToggle()` | `NA` | `void` | Clears the toggle button from its initial state. |
| `axis-button-toggle` | `disableToggleBtn()` | `NA` | `void` | Disables the toggle button. |
| `axis-button-toggle` | `disableEnableToggleBtn()` | `NA` | `void` | Disables the toggle buttons if it is in enabled state and vice versa. |
| `axis-button-toggle` | `enableToggleBtn()` | `NA` | `void` | Enables the toggle button. |
| `axis-button-toggle` | `resetToggle()` | `NA` | `void` | Resets the toggle button to its initial state. |

### Selectors
| Component | Description |
|-----------|-------------|
| `axis-button` | Applies basic properties like data-kind and custom title to the button. |
| `axis-button-group` | Component that contains the whole group of buttons. |
| `axis-button-toolbar` | Arranges multiple buttons in pagination form. |
| `axis-button-toggle` | Selects one button while deselecting other buttons. |
| `axis-button-toggle-label` | Defines buttons in toggle button groups. |
| `axis-toggle-bar` | Defines the toggle bar with nested components of a toggle switch. |
| `axis-toggle-container` | Defines buttons on the toggle bar using nested components of a toggle switch. |
| `axis-toggle-switch` | This selector defines a toggle switch that has true and false values. |
| `axis-toggle-label` | Defines toggle switch label. |
| `axis-button-wrapper` | Wrapper that aligns buttons in a row. |


---

---

## AUG JSON Structure

Use this structure when generating dynamic forms with `axis-ui-generator`:

```json
{
  "type": "button",
  "name": "%name%",
  "id": "buttonId1",
  "label": "Submit",
  "title": "submit form button",
  "size": "a",
  "componentHostClasses": "kind-primary size-medium",
  "iconData": {
    "componentHostClasses": "_text-success size-large"
  },
  "icon": "check",
  "iconFont": "material",
  "navigationProperties": {}
}
```

---

## Examples

### Default button
**Keywords:** Default button, button, default, basic

**TypeScript:**
```typescript
<button axis-button>Default Button</button>
```

**HTML:**
```html
<button axis-button>Default Button</button>
```

### Primary button
**Keywords:** Primary button, button, primary, main

**TypeScript:**
```typescript
<button axis-button class="kind-primary">Primary Button</button>
```

**HTML:**
```html
<button axis-button class="kind-primary">Primary Button</button>
```

### Secondary button
**Keywords:** Secondary button, button, secondary

**TypeScript:**
```typescript
<button  axis-button class="kind-secondary">Secondary Button</button>
```

**HTML:**
```html
<button  axis-button class="kind-secondary">Secondary Button</button>
```

### Disabled button
**Keywords:** Disabled button, button, disabled, inactive

**TypeScript:**
```typescript
import { Component } from '@angular/core';

@Component({
   ...
})

export class yourComponentName {
   public isDisabled:boolean = true;
   ...
   ...
}
```

**HTML:**
```html
<button  axis-button class="kind-primary" [disabled]="isDisabled">Disabled Button</button>
```

### Link button
**Keywords:** Link button, button, link, hyperlink

**TypeScript:**
```typescript
<button axis-button class="kind-link">Link Button</button>
```

**HTML:**
```html
<button axis-button class="kind-link">Link Button</button>
```



*(38 additional examples omitted for brevity. See full documentation for more patterns.)*

---
