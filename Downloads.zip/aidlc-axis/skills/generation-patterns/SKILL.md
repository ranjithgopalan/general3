---
name: generation-patterns
description: Component implementation patterns and examples for Axis UI generation. Load on-demand when generating specific component types.
---

# Axis UI Generation Patterns

Reference patterns for generating Angular code with Axis components. Load specific sections as needed.

## Form Controls with Validation

```typescript
// Checkbox
<axis-checkbox
  [(ngModel)]="isAgreed"
  name="agree"
  [required]="true"
  (changeDetect)="handleChange($event)">
  I agree to terms
</axis-checkbox>

// Dropdown with search
<axis-dropdown
  [dataProvider]="countries"
  [(ngModel)]="selectedCountry"
  [showSearch]="true"
  placeholder="Select country"
  [required]="true"
  (onSelect)="handleSelection($event)">
</axis-dropdown>

// Datepicker with range
<axis-datepicker
  [(ngModel)]="dateRange"
  [range]="true"
  format="MM/DD/YYYY"
  [minDate]="minDate"
  [maxDate]="maxDate"
  (rangeChange)="onRangeChange($event)">
</axis-datepicker>
```

## Layout Components

```html
<!-- Card with header, body, footer -->
<axis-card [data-shadow]="true">
  <axis-card-heading>
    <axis-card-heading-body>Card Title</axis-card-heading-body>
    <axis-card-heading-right>
      <button axis-button class="kind-primary">Action</button>
    </axis-card-heading-right>
  </axis-card-heading>
  <axis-card-body>
    <p>Card content goes here</p>
  </axis-card-body>
  <axis-card-footer>
    <button axis-button>Cancel</button>
    <button axis-button class="kind-primary">Save</button>
  </axis-card-footer>
</axis-card>

<!-- Accordion with closeOthers -->
<axis-accordion-group-wrapper [closeOthers]="true">
  <axis-accordion-wrapper [active]="true">
    <axis-accordion-heading>Section 1</axis-accordion-heading>
    <axis-accordion-body>Content 1</axis-accordion-body>
  </axis-accordion-wrapper>
  <axis-accordion-wrapper>
    <axis-accordion-heading>Section 2</axis-accordion-heading>
    <axis-accordion-body>Content 2</axis-accordion-body>
  </axis-accordion-wrapper>
</axis-accordion-group-wrapper>

<!-- Tabs -->
<axis-tab-wrapper>
  <axis-tab-set>
    <axis-tab heading="Tab 1" [active]="true">
      <axis-tab-content>Content 1</axis-tab-content>
    </axis-tab>
    <axis-tab heading="Tab 2">
      <axis-tab-content>Content 2</axis-tab-content>
    </axis-tab>
  </axis-tab-set>
</axis-tab-wrapper>

<!-- Modal -->
<button (click)="modal.open()">Open Modal</button>
<axis-modal #modal [backdrop]="true" [keyboard]="true" size="large">
  <axis-modal-header><h3>Modal Title</h3></axis-modal-header>
  <axis-modal-body>Modal content</axis-modal-body>
  <axis-modal-footer><button (click)="modal.close()">Close</button></axis-modal-footer>
</axis-modal>
```

## Button Variants

```html
<!-- Button variants -->
<button axis-button class="kind-primary">Primary</button>
<button axis-button class="kind-secondary">Secondary</button>
<button axis-button class="kind-default">Default</button>
<button axis-button class="kind-link">Link</button>

<!-- Button sizes -->
<button axis-button class="kind-primary" data-size="large">Large</button>
<button axis-button class="kind-primary" data-size="small">Small</button>

<!-- Button group -->
<axis-button-group>
  <button axis-button>Button 1</button>
  <button axis-button>Button 2</button>
</axis-button-group>

<!-- Toggle buttons -->
<axis-button-toggle
  [(ngModel)]="selectedValue"
  [isReset]="true"
  (getSelectedValue)="onToggleChange($event)">
  <axis-button-toggle-label value="yes">Yes</axis-button-toggle-label>
  <axis-button-toggle-label value="no">No</axis-button-toggle-label>
</axis-button-toggle>
```

## Alerts and Feedback

```html
<!-- Success alert -->
<axis-alert class="kind-success" [dismissible]="true">
  <strong>Success!</strong> Changes saved.
</axis-alert>

<!-- Error alert -->
<axis-alert class="kind-danger" [dismissible]="true">
  <strong>Error:</strong> Something went wrong.
</axis-alert>

<!-- Auto-dismiss alert -->
<axis-alert class="kind-info" [datafadeout]="true" [timeOut]="5000" [dismissible]="true">
  This will auto-close in 5 seconds.
</axis-alert>

<!-- Tooltip -->
<button axisTooltip="Click to save" placement="top">Save</button>
```

## Data Grid

```typescript
import { Component } from '@angular/core';
import { DatagridModule } from 'axis-datagrid';

@Component({
  selector: 'app-data-grid',
  standalone: true,
  imports: [DatagridModule],
  template: `
    <axis-datagrid [gridModel]="gridConfig" (uiEmitUpdate)="onGridChange($event)">
    </axis-datagrid>
  `
})
export class DataGridComponent {
  gridConfig = {
    columnDefs: [
      { field: 'name', sortable: true, filter: true },
      { field: 'email', sortable: true, filter: true },
      { field: 'role', sortable: true }
    ],
    rowData: [],
    pagination: true,
    paginationPageSize: 10
  };

  onGridChange(event: any) {
    console.log('Grid changed:', event);
  }
}
```

## UI Generator (AUG) Pattern

```typescript
import { Component, inject } from '@angular/core';
import { AxisUiGeneratorAllModule, FormService } from 'axis-ui-generator';

@Component({
  selector: 'app-dynamic-form',
  standalone: true,
  imports: [AxisUiGeneratorAllModule],
  template: `
    <axis-ui-generator
      *ngIf="uiStructure"
      [uiStructure]="uiStructure"
      [uiData]="uiData"
      (uiEmitUpdate)="onFieldUpdate($event)"
      (uiEmit)="onFormSubmit($event)">
    </axis-ui-generator>
  `
})
export class DynamicFormComponent {
  private formService = inject(FormService);

  uiStructure: any = null;
  uiData: Record<string, any> = {};

  onFieldUpdate(event: any): void {
    this.uiData = { ...this.uiData, ...event };
  }

  onFormSubmit(data: any): void {
    if (this.formService.Form['mainSection']?.invalid) {
      this.formService.Form['mainSection'].markAllAsTouched();
      return;
    }
    console.log('Form submitted:', data);
  }
}
```

## Import Path Reference

```typescript
// Core components
import { ButtonsModule, CardModule, DropdownModule, CheckboxModule,
         AlertModule, InputModule, RadioButtonModule } from 'axis-components';

// Specialized modules
import { AccordionModule } from 'axis-components/accordion';
import { DatepickerModule } from 'axis-components/datepicker';
import { TabsModule } from 'axis-components/tab';
import { CalendarModule } from 'axis-components/calendar';

// Advanced modules
import { AxisUiGeneratorAllModule } from 'axis-ui-generator';
import { DatagridModule } from 'axis-datagrid';
import { NotificationModule } from 'axis-notification';
```

## Standalone Component Template

```typescript
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CardModule, ButtonsModule, DropdownModule, AlertModule } from 'axis-components';

@Component({
  selector: 'app-my-component',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CardModule,
    ButtonsModule,
    DropdownModule,
    AlertModule
  ],
  templateUrl: './my-component.component.html',
  styleUrls: ['./my-component.component.scss']
})
export class MyComponent {
  // Properties alphabetically
  isLoading = false;
  showSuccess = false;

  // Methods alphabetically
  onSubmit(): void { }
  resetForm(): void { }
}
```

## Component Quick Reference

| Need | Use |
|------|-----|
| Form select | `<axis-dropdown>` |
| Date input | `<axis-datepicker>` |
| Checkbox | `<axis-checkbox>` |
| Radio | `<axis-radio-button-group>` |
| Button | `<button axis-button class="kind-*">` |
| Card | `<axis-card>` |
| Alert | `<axis-alert class="kind-*">` |
| Tabs | `<axis-tab-wrapper>` |
| Modal | `<axis-modal>` |
| Data table | `<axis-datagrid>` |
| Dynamic form | `<axis-ui-generator>` |
## DynamoDB Integration Patterns

### UI Configuration from DynamoDB
```typescript
// Service method for loading component configuration
async loadComponentConfig(bookingId: string, componentId: string): Promise<ComponentConfig> {
  const endpoint = `/ui/booking/${bookingId}/components?componentId=${componentId}`;
  const response = await this.http.get<APIResponse>(endpoint).toPromise();

  return {
    componentConfiguration: response.data.componentConfiguration,
    pomSchema: response.data.pomSchema,
    workflowMetadata: response.data.workflowMetadata
  };
}

// Component initialization with config
async ngOnInit() {
  this.loading = true;
  try {
    const config = await this.configService.loadComponentConfig(
      this.bookingId,
      'clientSearch'
    );

    this.uiStructure = config.componentConfiguration.searchFormStructure;
    this.pomSchema = config.pomSchema;
    this.metadata = config.workflowMetadata;
  } catch (error) {
    this.handleError(error);
  } finally {
    this.loading = false;
  }
}
```

### Lookup Data from DynamoDB
```typescript
// Lazy-load reference data with caching
private lookupCache = new Map<string, any[]>();

async loadLookupData(fieldCode: string): Promise<any[]> {
  // Check cache first
  if (this.lookupCache.has(fieldCode)) {
    return this.lookupCache.get(fieldCode)!;
  }

  // Fetch from DynamoDB reference table
  const response = await this.http.get<ReferenceResponse>(
    `/reference?elementName=${fieldCode}`
  ).toPromise();

  // Cache for future use
  this.lookupCache.set(fieldCode, response.options);

  return response.options;
}

// Usage in dropdown interaction
async onDropdownFocus(fieldCode: string) {
  this.dropdownData[fieldCode] = await this.loadLookupData(fieldCode);
}
```


## Async Operation Patterns

### Long-Running Operation with Polling
```typescript
// Initiate async operation
async initiateAsyncSearch(searchParams: any): Promise<string> {
  const response = await this.http.post<AsyncResponse>(
    '/api/integration-proxy/party/search/async',
    searchParams
  ).toPromise();

  return response.data.requestId; // Returns immediately with request ID
}

// Poll for completion
pollOperationStatus(requestId: string): Observable<OperationResult> {
  return interval(2000).pipe( // Poll every 2 seconds
    switchMap(() =>
      this.http.get<StatusResponse>(`/api/operations/${requestId}/status`)
    ),
    map(response => response.data),
    takeWhile(result => result.status === 'PENDING', true), // Continue until complete
    filter(result => result.status === 'COMPLETED' || result.status === 'FAILED')
  );
}

// Combined usage
async searchWithAsyncPolling(searchParams: any) {
  this.loading = true;
  try {
    const requestId = await this.initiateAsyncSearch(searchParams);

    this.pollOperationStatus(requestId).subscribe({
      next: (result) => {
        if (result.status === 'COMPLETED') {
          this.results = result.data;
        } else {
          this.error = result.error;
        }
      },
      complete: () => {
        this.loading = false;
      }
    });
  } catch (error) {
    this.loading = false;
    this.handleError(error);
  }
}
```

### Loading States with Estimated Time
```html
<div *ngIf="loading" class="loading-overlay">
  <axis-spinner></axis-spinner>
  <p>Searching external systems...</p>
  <p *ngIf="estimatedWaitTime">Estimated wait: {{estimatedWaitTime}} seconds</p>
  <axis-progress-bar [value]="progressPercentage"></axis-progress-bar>
</div>
```

## Dynamic Form Patterns

### Schema-Driven Form with Type Switching
```typescript
// Component with dynamic form structure
export class DynamicFormComponent implements OnInit {
  uiStructure: UIStructure | null = null;
  uiData: UIData | null = null;
  formType: 'organization' | 'individual' = 'organization';

  async ngOnInit() {
    await this.loadFormStructure();
  }

  async loadFormStructure() {
    const config = await this.configService.loadComponentConfig(
      this.bookingId,
      this.componentId
    );

    // Select structure based on form type
    this.uiStructure = this.formType === 'organization'
      ? config.componentConfiguration.organizationFormStructure
      : config.componentConfiguration.individualFormStructure;

    // Pre-populate with saved data
    this.uiData = config.metaData?.formData || {};
  }

  onTypeChange(type: 'organization' | 'individual') {
    this.formType = type;
    this.loadFormStructure(); // Reload structure for new type
  }
}
```

### POM-Based Field Mapping
```typescript
// Extract form data and map to API payload using POM schema
extractFormPayload(augRef: any, pomSchema: POMSchema): CreateClientRequest {
  const formData = augRef._helper.getData();

  // Map form fields to API request using POM schema
  const payload: CreateClientRequest = {
    partySubType: this.formType.toUpperCase(),
    partyData: {}
  };

  // Map each field according to POM schema
  Object.keys(pomSchema.fieldMappings).forEach(fieldKey => {
    const mapping = pomSchema.fieldMappings[fieldKey];
    const formValue = formData[fieldKey];

    if (formValue !== undefined && formValue !== null) {
      payload.partyData[mapping.apiField] = formValue;
    }
  });

  return payload;
}
```

### Additional Insured Management Pattern
```typescript
// Dynamic array of form sections
export class AdditionalInsuredComponent {
  additionalInsuredSections: number[] = [];

  canAddSection(): boolean {
    // Check if main form is valid
    if (!this.mainFormValid) return false;

    // Check if all existing sections are valid
    return this.additionalInsuredSections.every(idx =>
      this.augRefs[idx]?._helper.isFormValid()
    );
  }

  addAdditionalInsured() {
    if (!this.canAddSection()) {
      this.showError('Please complete all required fields before adding another section');
      return;
    }

    const newIndex = this.additionalInsuredSections.length + 1;
    this.additionalInsuredSections.push(newIndex);
  }

  removeAdditionalInsured(index: number) {
    this.additionalInsuredSections = this.additionalInsuredSections.filter(i => i !== index);
  }
}
```

```html
<!-- Template for additional insured sections -->
<div *ngFor="let sectionIdx of additionalInsuredSections; let i = index">
  <h4>Additional Insured {{sectionIdx}}</h4>

  <axis-ui-generator
    [uiStructure]="additionalInsuredStructure"
    [uiData]="additionalInsuredData[sectionIdx]"
    (uiEmitUpdate)="onAdditionalInsuredUpdate($event, sectionIdx)"
    (augRef)="captureAugRef($event, sectionIdx)">
  </axis-ui-generator>

  <button axis-button class="kind-secondary" (click)="removeAdditionalInsured(sectionIdx)">
    Remove Additional Insured {{sectionIdx}}
  </button>
</div>

<button
  axis-button
  class="kind-primary"
  [disabled]="!canAddSection()"
  (click)="addAdditionalInsured()">
  Add Additional Insured
</button>

<p *ngIf="!canAddSection()" class="error-message">
  Please complete all required fields in existing sections before adding another
</p>
```

## augRef Helper Method Patterns

### Capturing augRef Reference
```typescript
export class DynamicFormComponent {
  augRef: { _helper: AUGHelper } | null = null;

  // Capture augRef from axis-ui-generator
  captureAugRef(ref: any) {
    this.augRef = ref;
  }
}
```

```html
<axis-ui-generator
  [uiStructure]="uiStructure"
  [uiData]="uiData"
  (augRef)="captureAugRef($event)"
  (uiEmitUpdate)="onFormUpdate($event)">
</axis-ui-generator>
```

### Common augRef Operations
```typescript
// Get all form data
const allData = this.augRef?._helper.getData();

// Get specific field value
const clientName = this.augRef?._helper.getFieldValue('clientName');

// Set field value
this.augRef?._helper.setFieldValue('clientName', 'ABC Corporation');

// Update multiple fields
this.augRef?._helper.setData({
  clientName: 'ABC Corporation',
  fiscalCode: '12345678901'
});

// Validate form
const isValid = this.augRef?._helper.isFormValid();

// Get validation errors
const errors = this.augRef?._helper.getValidationErrors();

// Refresh specific field (re-render)
this.augRef?._helper.refreshElement('countryDropdown');

// Enable/disable field
this.augRef?._helper.disableField('dBNumber');
this.augRef?._helper.enableField('dBNumber');

// Show/hide field
this.augRef?._helper.hideField('optionalField');
this.augRef?._helper.showField('optionalField');

// Clear form
this.augRef?._helper.clearForm();
```

### Form Cleanup Pattern
```typescript
ngOnDestroy() {
  // Clear form data on component destroy
  if (this.augRef) {
    this.formService.clearFormData(this.componentId);
  }
}
```

## Workflow Patterns

### Search-Then-Create Pattern
```typescript
export class SearchCreateWorkflowComponent {
  searchResults: any[] = [];
  showCreateForm = false;

  async onSearch(searchParams: any) {
    this.loading = true;
    try {
      const results = await this.searchService.search(searchParams);

      if (results.length === 0) {
        // No results - offer to create
        this.showNoResultsMessage();
        this.showCreateForm = true;
      } else {
        // Display results in grid
        this.searchResults = results;
      }
    } finally {
      this.loading = false;
    }
  }

  onSelectResult(result: any) {
    // User selected from results - populate main form
    this.selectedClient = result;
    this.closeSearchModal();
    this.populateMainForm(result);
  }

  onCreateNew() {
    // User chose to create new - show creation form
    this.showCreateForm = true;
    this.searchResults = [];
  }
}
```

### Modal Popup with Embedded Components
```typescript
export class ModalWorkflowComponent implements OnInit {
  modalConfig: any = null;
  searchFormStructure: UIStructure | null = null;
  gridColumns: GridColumn[] = [];
  paginationConfig: any = null;

  async openSearchModal() {
    // Load all modal configurations in one API call
    const config = await this.configService.loadComponentConfig(
      this.bookingId,
      'clientSearchModal'
    );

    this.modalConfig = config.componentConfiguration.modalOptions;
    this.searchFormStructure = config.componentConfiguration.searchFormStructure;
    this.gridColumns = config.componentConfiguration.gridColumns;
    this.paginationConfig = config.componentConfiguration.paginationStructure;

    this.modal.open();
  }

  async onSearchInModal(searchParams: any) {
    const results = await this.searchService.search(searchParams);
    this.searchResults = results;
    // Grid component automatically updates with new data
  }

  onPageChange(pageNumber: number) {
    // Preserve search criteria, change page
    this.onSearchInModal({
      ...this.lastSearchParams,
      pageNo: pageNumber
    });
  }
}
```

### Navigation with Status Update
```typescript
export class ComponentNavigationService {
  async saveAndNavigate(
    bookingId: string,
    componentId: string,
    data: any,
    nextComponentId?: string
  ) {
    // Step 1: Save component data and mark status
    const statusResponse = await this.http.put<StatusUpdateResponse>(
      `/ui/booking/${bookingId}/components/status`,
      {
        componentId,
        status: 'COMPLETED',
        componentData: data,
        transactionType: this.transactionType
      }
    ).toPromise();

    // Step 2: Conditionally refresh header
    if (statusResponse.refreshHeader) {
      await this.loadHeaderComponent(bookingId);
    }

    // Step 3: Get next component
    const params = nextComponentId
      ? `nextComponentId=${nextComponentId}`
      : `transactionType=${this.transactionType}`;

    const nextConfig = await this.http.get<ComponentConfigResponse>(
      `/ui/booking/${bookingId}/nextComponent?${params}`
    ).toPromise();

    return nextConfig.data;
  }

  async saveProgress(bookingId: string, componentId: string, data: any) {
    // Save without navigating (IN_PROGRESS status)
    await this.http.put(
      `/ui/booking/${bookingId}/components/status`,
      {
        componentId,
        status: 'IN_PROGRESS',
        componentData: data
      }
    ).toPromise();
  }
}
```

### Resume Flow Pattern
```typescript
async resumeBooking(bookingId: string) {
  // Load all breadcrumb components (header, footer, sidebar)
  const [header, footer, sidebar] = await Promise.all([
    this.loadComponent(bookingId, 'breadCrumHeader'),
    this.loadComponent(bookingId, 'breadCrumFooter'),
    this.loadComponent(bookingId, 'breadCrumSidebar')
  ]);

  // Get current component (where user left off)
  const currentComponent = await this.http.get<ComponentConfigResponse>(
    `/ui/booking/${bookingId}/nextComponent?currentPosition=true`
  ).toPromise();

  // Pre-populate form with saved data from metaData
  this.uiData = currentComponent.data.metaData?.formData || {};
  this.uiStructure = currentComponent.data.componentConfiguration.formStructure;

  // Display any validation errors from previous session
  if (currentComponent.data.metaData?.validationErrors) {
    this.displayValidationErrors(currentComponent.data.metaData.validationErrors);
  }
}
```

## State Management Patterns

### Facade Service for Workflow Orchestration
```typescript
@Injectable({ providedIn: 'root' })
export class ClientFacadeService {
  private clientTypeSubject = new BehaviorSubject<'organization' | 'individual'>('organization');
  clientType$ = this.clientTypeSubject.asObservable();

  constructor(
    private http: HttpClient,
    private configService: ConfigService
  ) {}

  selectClientType(type: 'organization' | 'individual'): void {
    this.clientTypeSubject.next(type);
  }

  searchClient(searchParams: ClientSearchParams): Observable<ClientSearchResult[]> {
    return this.http.post<SearchResponse>(
      '/api/integration-proxy/party/search/async',
      searchParams
    ).pipe(
      map(response => response.data.parties)
    );
  }

  createClient(clientData: CreateClientRequest): Observable<ClientCreateResponse> {
    return this.http.post<ApiResponse>(
      '/api/integration-proxy/createParty?partyType=CLIENT',
      clientData
    ).pipe(
      map(response => response.data)
    );
  }

  async associateClientWithBooking(
    bookingId: string,
    clientId: string
  ): Promise<void> {
    await this.updateComponentStatus(bookingId, 'clientInformation', {
      selectedClientId: clientId,
      status: 'COMPLETED'
    });
  }

  async updateComponentStatus(
    bookingId: string,
    componentId: string,
    data: any
  ): Promise<StatusUpdateResponse> {
    return this.http.put<StatusUpdateResponse>(
      `/ui/booking/${bookingId}/components/status`,
      { componentId, ...data }
    ).toPromise();
  }

  async navigateToNextComponent(
    bookingId: string,
    nextComponentId?: string
  ): Promise<ComponentConfig> {
    const params = nextComponentId
      ? `nextComponentId=${nextComponentId}`
      : `transactionType=${this.transactionType}`;

    const response = await this.http.get<ComponentConfigResponse>(
      `/ui/booking/${bookingId}/nextComponent?${params}`
    ).toPromise();

    return response.data;
  }
}
```

### Input-Driven Component State
```typescript
// Parent component manages state
export class ParentComponent {
  gridData: any[] = [];
  gridLoading = false;
  gridColumns: GridColumn[] = [
    { field: 'partyId', header: 'Party ID', sortable: true },
    { field: 'partyName', header: 'Party Name', sortable: true }
  ];

  async loadData() {
    this.gridLoading = true;
    try {
      this.gridData = await this.dataService.getData();
    } finally {
      this.gridLoading = false;
    }
  }

  onRowSelected(row: any) {
    this.selectedRow = row;
    this.closeModal();
  }
}
```

```html
<!-- Child component receives state via inputs -->
<app-common-grid
  [data]="gridData"
  [columns]="gridColumns"
  [loading]="gridLoading"
  [selectable]="true"
  (rowSelected)="onRowSelected($event)">
</app-common-grid>
```

### Lookup Data Caching
```typescript
@Injectable({ providedIn: 'root' })
export class LookupCacheService {
  private cache = new Map<string, { data: any[], timestamp: number }>();
  private readonly CACHE_TTL = 5 * 60 * 1000; // 5 minutes

  async getLookupData(fieldCode: string): Promise<any[]> {
    const cached = this.cache.get(fieldCode);

    // Check cache validity
    if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) {
      return cached.data;
    }

    // Fetch fresh data
    const response = await this.http.get<ReferenceResponse>(
      `/reference?elementName=${fieldCode}`
    ).toPromise();

    // Update cache
    this.cache.set(fieldCode, {
      data: response.options,
      timestamp: Date.now()
    });

    return response.options;
  }

  clearCache(fieldCode?: string) {
    if (fieldCode) {
      this.cache.delete(fieldCode);
    } else {
      this.cache.clear();
    }
  }
}
```

## API Integration Patterns

### Paginated Search API
```typescript
export interface PaginationParams {
  pageNo: number;
  pageSize: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    currentPage: number;
    pageSize: number;
    totalRecords: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
  };
}

// Service method with pagination
searchWithPagination(
  searchParams: any,
  pagination: PaginationParams
): Observable<PaginatedResponse<any>> {
  return this.http.post<ApiResponse>('/api/search', {
    ...searchParams,
    ...pagination
  }).pipe(
    map(response => ({
      data: response.data.parties,
      pagination: response.data.pagination
    }))
  );
}

// Component usage
export class SearchComponent {
  currentPage = 1;
  pageSize = 10;

  async onSearch() {
    const result = await this.searchService.searchWithPagination(
      this.searchParams,
      { pageNo: this.currentPage, pageSize: this.pageSize }
    ).toPromise();

    this.results = result.data;
    this.paginationMetadata = result.pagination;
  }

  onPageChange(page: number) {
    this.currentPage = page;
    this.onSearch(); // Preserves search params
  }
}
```

### HTTP Interceptors
```typescript
// Authentication Interceptor
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(private authService: AuthService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = this.authService.getJwtToken();

    const authReq = req.clone({
      headers: req.headers.set('Authorization', `Bearer ${token}`)
    });

    return next.handle(authReq);
  }
}

// Correlation ID Interceptor
@Injectable()
export class CorrelationInterceptor implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const correlationId = uuidv4();

    console.log(`[${correlationId}] ${req.method} ${req.url}`);

    const correlationReq = req.clone({
      headers: req.headers.set('X-Correlation-ID', correlationId)
    });

    return next.handle(correlationReq);
  }
}
```

### Create API with Nested Objects
```typescript
export interface CreateClientRequest {
  partySubType: 'ORGANIZATION' | 'INDIVIDUAL';
  partyData: {
    organizationName?: string;
    firstName?: string;
    lastName?: string;
    fiscalCode: string;
    address: {
      street: string;
      city: string;
      state: string;
      zipCode: string;
      country: string;
    };
    contactInfo: {
      email: string;
      phone: string;
    };
  };
}

async createClient(data: CreateClientRequest): Promise<ClientCreateResponse> {
  try {
    const response = await this.http.post<ApiResponse>(
      '/api/integration-proxy/createParty?partyType=CLIENT',
      data,
      {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'X-Correlation-ID': uuidv4()
        })
      }
    ).toPromise();

    return response.data;
  } catch (error) {
    if (error.status === 409) {
      throw new Error('A client with this fiscal code already exists');
    }
    throw error;
  }
}
```

## Error Handling Patterns

### Categorized Error Handler
```typescript
@Injectable({ providedIn: 'root' })
export class GlobalErrorHandlerService {
  constructor(
    private router: Router,
    private notificationService: NotificationService
  ) {}

  handleError(error: any): void {
    const httpError = error as HttpErrorResponse;

    switch (httpError.status) {
      case 401:
        // Authentication error - redirect to login
        this.notificationService.showError('Session expired. Please log in again.');
        this.router.navigate(['/login']);
        break;

      case 403:
        // Authorization error
        this.notificationService.showError('You do not have permission to access this resource.');
        break;

      case 400:
        // Validation error - display field-level errors
        const validationErrors = httpError.error?.error?.details;
        this.displayValidationErrors(validationErrors);
        break;

      case 404:
        // Not found
        this.notificationService.showError('The requested resource was not found.');
        break;

      case 504:
        // Timeout
        this.notificationService.showError(
          'Request timeout. The operation took too long. Please try again.'
        );
        break;

      case 500:
      case 502:
      case 503:
        // Server error
        this.notificationService.showError(
          'An unexpected server error occurred. Please try again later.'
        );
        break;

      default:
        // Network error
        if (error instanceof Error && !httpError.status) {
          this.notificationService.showError(
            'Network error. Please check your internet connection.'
          );
        } else {
          this.notificationService.showError('An unexpected error occurred.');
        }
    }
  }

  private displayValidationErrors(errors: any) {
    Object.keys(errors || {}).forEach(field => {
      this.notificationService.showFieldError(field, errors[field]);
    });
  }
}
```

### Retry with Exponential Backoff
```typescript
// Retry failed requests with exponential backoff
retryWithBackoff<T>(
  operation: () => Observable<T>,
  maxRetries = 3,
  initialDelay = 1000
): Observable<T> {
  return operation().pipe(
    retryWhen(errors =>
      errors.pipe(
        scan((retryCount, error) => {
          if (retryCount >= maxRetries) {
            throw error;
          }
          return retryCount + 1;
        }, 0),
        delayWhen(retryCount => timer(initialDelay * Math.pow(2, retryCount)))
      )
    )
  );
}

// Usage
this.retryWithBackoff(() => this.http.get('/api/data'))
  .subscribe({
    next: data => this.handleSuccess(data),
    error: error => this.handleError(error)
  });
```

## Configuration Patterns

### Runtime Configuration from S3
```typescript
// config.json structure
export interface AppConfig {
  environment: string;
  apiGateway: {
    baseUrl: string;
    timeout: number;
  };
  okta: {
    clientId: string;
    issuer: string;
    redirectUri: string;
  };
  apiEndpoints: {
    searchParty: string;
    createParty: string;
    getParty: string;
    componentStatusUpdate: string;
    uiComponents: string;
  };
  componentMappings: {
    header: string;
    footer: string;
    sidebar: string;
    currentComponent: string;
  };
  featureToggles: {
    enableDynamicForms: boolean;
    enableCorrelationTracking: boolean;
  };
}

// ConfigService with APP_INITIALIZER
@Injectable({ providedIn: 'root' })
export class ConfigService {
  private config: AppConfig | null = null;

  constructor(private http: HttpClient) {}

  async loadConfig(): Promise<void> {
    this.config = await this.http.get<AppConfig>('/assets/config/config.json').toPromise();
  }

  getApiBaseUrl(): string {
    return this.config?.apiGateway.baseUrl || '';
  }

  getEndpoint(key: keyof AppConfig['apiEndpoints']): string {
    return this.config?.apiEndpoints[key] || '';
  }

  isFeatureEnabled(feature: keyof AppConfig['featureToggles']): boolean {
    return this.config?.featureToggles[feature] || false;
  }
}

// APP_INITIALIZER setup in app.config.ts
export function initializeApp(configService: ConfigService) {
  return () => configService.loadConfig();
}

export const appConfig: ApplicationConfig = {
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: initializeApp,
      deps: [ConfigService],
      multi: true
    }
  ]
};
```
