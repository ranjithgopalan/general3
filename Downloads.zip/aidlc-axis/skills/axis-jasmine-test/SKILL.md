---
name: axis-jasmine-test
description: Generate comprehensive Jasmine unit tests for Angular/Axis components with >80% coverage. Auto-invokes for Jasmine-specific test generation requests.
---

# Axis Jasmine Test Generation

Auto-invoked skill for generating comprehensive Jasmine unit tests for Angular/Axis components with guaranteed >80% code coverage.

## Auto-Invocation Triggers

This skill automatically activates when detecting comprehensive Jasmine test requests:

**Trigger keywords:**
- jasmine test, jasmine spec
- comprehensive test, detailed test, complete test
- full coverage, >80% coverage, high coverage
- thorough test, extensive test

**Example requests:**
- "Generate comprehensive Jasmine tests for src/app/login/login.component.ts"
- "Create detailed test suite with >80% coverage for my user profile component"
- "Write thorough Jasmine specs for the dashboard component"
- "Generate complete test coverage for src/app/forms/registration.component.ts"

---

## Comprehensive Testing Approach

This skill generates **production-ready Jasmine test suites** with exhaustive coverage of all component functionality.

### Coverage Guarantee
- **>80% code coverage** minimum
- All public methods tested
- All inputs and outputs tested
- All form validations tested
- All service interactions tested
- All template interactions tested
- All async operations tested
- All error handling tested
- All edge cases tested

### Jasmine-Specific Features
- `jasmine.createSpyObj` for service mocks
- `spyOn` for method spying
- Custom matchers and expectations
- Async testing with `fakeAsync` and `tick`
- Fixture-based component testing

---

## Test Generation Process

### Step 1: Analyze Component File
**Read and analyze**:
- Component TypeScript implementation (.component.ts)
- Component template (.component.html)
- Component styles (.component.scss)
- Related service files
- Model/interface definitions

### Step 2: Identify Test Requirements
**Catalog all testable elements**:
- Component creation and initialization
- All public methods and their logic
- All @Input() properties
- All @Output() events
- Form controls and validation rules
- Service method calls
- Template event handlers
- Async operations (Observables, Promises)
- Error handling and edge cases

### Step 3: Generate Comprehensive Test Suite

**Create .spec.ts file with**:
- Complete TestBed configuration
- All necessary imports
- Service mocks using `jasmine.createSpyObj`
- beforeEach setup with proper initialization
- Comprehensive test cases covering all scenarios

---

## Step 0 — Discover Component Files (AIDLC Launcher context)

> ⚡ **ECS headless shortcut**: If `aidlc.config.json` does **NOT** exist in the current working
> directory, this is a headless ECS server run — auto-proceed directly to **Agent Delegation**
> (skip component discovery below). The ECS server provides source artifacts via KB chunk IDs.
> Also skip the ECS Reporting section; the server manages run state itself.

When invoked from the AIDLC Launcher for the `ui-smoke` stage, read `aidlc.config.json`
to locate the generated Angular UI root, then glob all component source files before delegation:

```powershell
$cfg    = Get-Content "aidlc.config.json" | ConvertFrom-Json
$uiRoot = if ($cfg.ui_output_path) { $cfg.ui_output_path } else {
    # Fallback: search well-known generated-UI paths
    $candidates = @(
        "$env:USERPROFILE\Documents\API\genai-aig-core-aidlc-platform-agents-7419\generated\ui\epics"
    )
    ($candidates | Where-Object { Test-Path $_ } | Select-Object -First 1)
}
$components = Get-ChildItem -Path $uiRoot -Recurse -Filter "*.component.ts" -Exclude "*.spec.ts" |
    Select-Object -ExpandProperty FullName
Write-Host "Found $($components.Count) component(s) to test."
```

Pass the discovered `$components` list to the axis-test-generator agent in the delegation prompt.

---

## Agent Delegation

> ⚡ **AIDLC Launcher mode**: If `aidlc.config.json` **exists** in the current working directory,
> skip Component Discovery and Agent Delegation entirely and jump directly to **Reporting to the
> AIDLC Platform** at the bottom. The local session's only role is to create the ECS run and
> monitor the CLI subprocess — do **not** invoke agents or generate files locally.

Delegates directly to **axis-test-generator** agent:

```
Task(subagent_type="AIDLC-axis:axis-test-generator", prompt="""
Generate comprehensive Jasmine unit tests for the following Angular components.

## Component Files to Test
[List of component file paths discovered in Step 0, one per line]

Requirements for EACH component:
1. Analyze the .component.ts and corresponding .component.html
2. Generate a .spec.ts file alongside the component with >80% code coverage
3. Include tests for:
   - Component creation and initialization
   - All public methods
   - Input and Output properties
   - Form validations (if applicable)
   - Service interactions with proper mocks
   - Template interactions and event handlers
   - Async operations with fakeAsync/tick
   - Error handling and edge cases
4. Mock all Axis components and services properly using jasmine.createSpyObj
5. Use proper TestBed configuration with AxisSharedModule or NO_ERRORS_SCHEMA
6. Follow Angular 18 standalone component testing best practices
7. Also generate smoke/test_visual_smoke.py and smoke/conftest.py for playwright smoke tests
   using the routes defined in src/app/app.routes.ts
8. Report estimated coverage and test count per component
""")
```

---

## Reporting to the AIDLC Platform (ECS UI tracking)

> **SERVER CLI GUARD:** If `aidlc.config.json` does **not** exist in your current
> working directory, skip this entire ECS section and run only the main workflow
> above. These steps are for the **local Claude Code session only**.

The local session creates the ECS run and monitors progress. All generation
is performed by the ECS server CLI — do **not** generate or copy files locally.

This skill covers the following pipeline stage:

| Launcher invocation | `$STAGE` value | Approver |
|---------------------|---------------|----------|
| M11 — UI Smoke / Jasmine Tests | `ui-smoke` | Developer |

---

**Step 0 — Read config**
```powershell
$cfg   = Get-Content "aidlc.config.json" | ConvertFrom-Json
$BASE  = $cfg.central_base_url
$TOKEN = [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env)
$WS    = $cfg.workspace_id
$HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
$STAGE = "ui-smoke"
```

**Step 1 — Cancel stale runs and create new run**
```powershell
try {
    $stale = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS" -Headers $HDR).items
    $stale | Where-Object { $_.stage_key -eq $STAGE -and $_.state -eq "queued" -and (-not $_.worktree) } |
        ForEach-Object { Invoke-RestMethod "$BASE/pipeline-runs/$($_.run_id)/cancel" -Headers $HDR -Method Post | Out-Null }
} catch {}
$body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true; force=$true } | ConvertTo-Json
$run    = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body
$RUN_ID = $run.run_id
Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
```

**Step 2 — Monitor and display elapsed time**
```powershell
do {
    Start-Sleep -Seconds 15
    $run     = Invoke-RestMethod "$BASE/pipeline-runs/$RUN_ID" -Headers $HDR
    $elapsed = if ($run.started_at) {
        $s = [datetime]::Parse($run.started_at)
        $e = if ($run.finished_at) { [datetime]::Parse($run.finished_at) } else { Get-Date }
        "$([int]($e - $s).TotalSeconds)s"
    } else { "queued" }
    $files = if ($run.files_written) { $run.files_written.Count } else { 0 }
    Write-Host "  [$elapsed]  state=$($run.state)  files=$files"
} while ($run.state -notin @("waiting_for_approval","completed","failed","cancelled"))
```

**Step 3 — Final timing summary**
```powershell
$fmt = { param($t) if ($t) { [datetime]::Parse($t).ToString("HH:mm:ss") } else { "—" } }
$sec = if ($run.started_at -and $run.finished_at) {
    [int]([datetime]::Parse($run.finished_at) - [datetime]::Parse($run.started_at)).TotalSeconds
} else { 0 }
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
Write-Host "  Run     : $RUN_ID"
Write-Host "  Stage   : $STAGE"
Write-Host "  State   : $($run.state)"
Write-Host "  Queued  : $(& $fmt $run.queued_at)"
Write-Host "  Started : $(& $fmt $run.started_at)"
Write-Host "  Finished: $(& $fmt $run.finished_at)"
Write-Host "  Elapsed : ${sec}s"
Write-Host "  Files   : $($run.files_written.Count) written"
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
```

**Step 4 — Review in ECS UI**
```
https://poc-ecs-build-ui.npsdlchgapp.us-east-1.aws.aig.net/aidlc-platform-management/pipeline
```

Approval persona: **Developer**

---

## Test Suite Structure

### Complete Test File Example

```typescript
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { of, throwError } from 'rxjs';
import { LoginComponent } from './login.component';
import { AuthService } from '../services/auth.service';
import { AxisSharedModule } from 'axis-shared';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let authService: jasmine.SpyObj<AuthService>;
  let compiled: HTMLElement;

  beforeEach(async () => {
    // Create spy object for AuthService
    const authServiceSpy = jasmine.createSpyObj('AuthService', [
      'login',
      'logout',
      'validateToken'
    ]);

    await TestBed.configureTestingModule({
      imports: [LoginComponent, ReactiveFormsModule, AxisSharedModule],
      providers: [
        { provide: AuthService, useValue: authServiceSpy }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    authService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
    compiled = fixture.nativeElement;
    fixture.detectChanges();
  });

  describe('Component Initialization', () => {
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should initialize form with empty values', () => {
      expect(component.loginForm.get('username')?.value).toBe('');
      expect(component.loginForm.get('password')?.value).toBe('');
    });

    it('should set initial loading state to false', () => {
      expect(component.isLoading).toBe(false);
    });
  });

  describe('Input Properties', () => {
    it('should accept redirectUrl input', () => {
      component.redirectUrl = '/dashboard';
      expect(component.redirectUrl).toBe('/dashboard');
    });
  });

  describe('Output Events', () => {
    it('should emit loginSuccess on successful login', fakeAsync(() => {
      authService.login.and.returnValue(of({ token: 'abc123' }));
      spyOn(component.loginSuccess, 'emit');

      component.login();
      tick();

      expect(component.loginSuccess.emit).toHaveBeenCalledWith({ token: 'abc123' });
    }));
  });

  describe('Form Validation', () => {
    it('should invalidate form when username is empty', () => {
      component.loginForm.patchValue({ username: '', password: 'test' });
      expect(component.loginForm.valid).toBe(false);
    });

    it('should invalidate form when password is empty', () => {
      component.loginForm.patchValue({ username: 'test', password: '' });
      expect(component.loginForm.valid).toBe(false);
    });

    it('should validate form when all fields are filled', () => {
      component.loginForm.patchValue({ username: 'test', password: 'pass123' });
      expect(component.loginForm.valid).toBe(true);
    });
  });

  describe('login() method', () => {
    it('should call authService.login with form values', () => {
      authService.login.and.returnValue(of({ token: 'abc123' }));
      component.loginForm.patchValue({ username: 'testuser', password: 'pass123' });

      component.login();

      expect(authService.login).toHaveBeenCalledWith({
        username: 'testuser',
        password: 'pass123'
      });
    });

    it('should set isLoading to true during login', fakeAsync(() => {
      authService.login.and.returnValue(of({ token: 'abc123' }));

      component.login();
      expect(component.isLoading).toBe(true);

      tick();
      expect(component.isLoading).toBe(false);
    }));

    it('should handle login error', fakeAsync(() => {
      const error = { error: { message: 'Invalid credentials' } };
      authService.login.and.returnValue(throwError(() => error));

      component.login();
      tick();

      expect(component.errorMessage).toBe('Invalid credentials');
      expect(component.isLoading).toBe(false);
    }));
  });

  describe('Template Interactions', () => {
    it('should disable login button when form is invalid', () => {
      component.loginForm.patchValue({ username: '', password: '' });
      fixture.detectChanges();

      const button = compiled.querySelector('axis-button');
      expect(button?.getAttribute('disabled')).toBeTruthy();
    });

    it('should call login() when form is submitted', () => {
      spyOn(component, 'login');
      component.loginForm.patchValue({ username: 'test', password: 'pass' });
      fixture.detectChanges();

      const form = compiled.querySelector('form');
      form?.dispatchEvent(new Event('submit'));

      expect(component.login).toHaveBeenCalled();
    });
  });

  describe('Error Handling', () => {
    it('should display error message on failed login', fakeAsync(() => {
      authService.login.and.returnValue(throwError(() => ({ error: { message: 'Network error' } })));

      component.login();
      tick();
      fixture.detectChanges();

      const errorElement = compiled.querySelector('.error-message');
      expect(errorElement?.textContent).toContain('Network error');
    }));
  });

  describe('Edge Cases', () => {
    it('should handle null username', () => {
      component.loginForm.patchValue({ username: null, password: 'pass' });
      expect(component.loginForm.valid).toBe(false);
    });

    it('should trim whitespace from username', () => {
      component.loginForm.patchValue({ username: '  test  ', password: 'pass' });
      component.login();
      expect(component.loginForm.get('username')?.value).toBe('test');
    });
  });
});
```

---

## Test Coverage Categories

### 1. Component Creation & Initialization
- Component is created successfully
- Initial state is correct
- Form is initialized properly
- Dependencies are injected

### 2. Public Methods
- Each method is called with expected parameters
- Return values are correct
- Side effects occur as expected
- Error conditions are handled

### 3. Input & Output Properties
- @Input() properties accept values correctly
- Changes to inputs trigger expected behavior
- @Output() events emit with correct payloads
- Event timing is correct

### 4. Form Validations
- Required field validation
- Pattern validation (email, phone, etc.)
- Min/max length validation
- Custom validators
- Cross-field validation
- Form state (valid/invalid/pristine/dirty)

### 5. Service Interactions
- Services are called with correct parameters
- Service responses are handled properly
- Service errors are caught and handled
- Loading states are managed correctly

### 6. Template Interactions
- Button clicks trigger correct methods
- Form submissions work correctly
- Input changes update component state
- Conditional rendering works as expected

### 7. Async Operations
- Observables complete successfully
- Promises resolve correctly
- Async/await patterns work
- Error handling in async operations

### 8. Error Handling & Edge Cases
- Null/undefined values handled
- Empty arrays/objects handled
- Network errors caught
- Validation errors displayed
- Boundary conditions tested

---

## Mocking Strategies

### Service Mocks
```typescript
const mockService = jasmine.createSpyObj('DataService', ['getData', 'postData']);
mockService.getData.and.returnValue(of({ data: 'test' }));
```

### Axis Component Mocks
```typescript
// Option 1: Use NO_ERRORS_SCHEMA
schemas: [NO_ERRORS_SCHEMA]

// Option 2: Mock individual components
@Component({ selector: 'axis-input', template: '' })
class MockAxisInputComponent {}

// Option 3: Import AxisSharedModule
imports: [AxisSharedModule]
```

### HTTP Mocks
```typescript
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

// In beforeEach
imports: [HttpClientTestingModule]

// In test
const httpMock = TestBed.inject(HttpTestingController);
```

---

## Coverage Reporting

After generating tests, the skill reports:

### Test Statistics
- Total test cases: 25
- Coverage areas: 8 (creation, methods, inputs, outputs, forms, services, template, errors)
- Estimated coverage: 85%

### Coverage Breakdown
- **Statements**: 90%
- **Branches**: 85%
- **Functions**: 95%
- **Lines**: 88%

### Recommendations
- Areas needing additional tests
- Complex logic requiring more edge cases
- Async operations needing more scenarios

---

## Running Tests

```bash
# Run all tests
ng test

# Run with coverage report
ng test --code-coverage

# Run specific file
ng test --include='**/login.component.spec.ts'

# Run in headless mode (CI)
ng test --watch=false --browsers=ChromeHeadless
```

---

## Best Practices

### Comprehensive Coverage
- Test every public method
- Test all code paths (if/else, switch cases)
- Test boundary conditions
- Test error scenarios

### Clear Test Names
```typescript
// Good
it('should display error message when login fails with 401 status', () => {});

// Bad
it('should work', () => {});
```

### Proper Mocking
- Mock external dependencies
- Use spy objects for services
- Mock HTTP calls
- Isolate unit under test

### Async Testing
```typescript
// Use fakeAsync for synchronous-looking async tests
it('should complete async operation', fakeAsync(() => {
  component.loadData();
  tick(1000);
  expect(component.data).toBeDefined();
}));
```

---

## Related Skills & Agents

**Skills:**
- `axis-test` - General test generation (use for simpler tests)
- `axis-implement` - Generate component to be tested
- `axis-validate` - Validate test quality

**Agents:**
- `axis-test-generator` - Specialized comprehensive test generation
- `axis-development-guide` - Testing conventions and patterns

---

## When to Use This Skill

### Use axis-jasmine-test when:
- You need production-ready test suites
- You want guaranteed >80% coverage
- You need comprehensive test cases
- You're preparing for code review
- You need tests for complex components

### Use axis-test when:
- You need basic test scaffolding
- You want quick test generation
- You're prototyping
- You prefer to write tests manually
