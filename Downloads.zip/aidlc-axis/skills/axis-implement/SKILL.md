﻿---
name: axis-implement
description: Generate, modify, or fix Angular UI code using Axis framework. Auto-invokes for UI generation requests with smart routing to static or dynamic generators.
---

# Axis UI Implementation

Auto-invoked skill for generating, modifying, or fixing Angular UI code using the Axis framework (v18.0.32).

## Auto-Invocation Triggers

This skill automatically activates when detecting UI implementation requests:

**Trigger keywords:**
- generate, create, build, implement, new
- modify, update, change, fix, refactor
- form, component, page, dashboard, UI, interface

**Example requests:**
- "Create a login form with username and password"
- "Generate a dashboard from ./output/UI-LLD.md"
- "Build a user profile page with tabs"
- "Implement the form from @UI-TDD.md"
- "Fix the validation in my registration component"

---

## Unified Execution Model

**This skill complies with** [`AIDLC-PLUGIN-EXECUTION-CONTRACT.md`](../AIDLC-PLUGIN-EXECUTION-CONTRACT.md)

- **Config**: Always read `aidlc.config.json` directly (never renamed to `.bak`)
- **Mode Detection**: Check `$env:AIDLC_RUN_ID` to determine local vs ECS execution
- **Prerequisite Discovery**:
  - **Local mode** (`AIDLC_RUN_ID="local"`): Search temp directory `%TEMP%\aidlc-ws\{wsId}\lld\`
  - **ECS mode**: Query central API for completed design (M1) runs
- **Output**: ALWAYS write to temp directory: `%TEMP%\aidlc-ws\{wsId}\ui-code\` (never to project root)

---

## Workflow

> ⚡ **AIDLC Launcher mode**: If `aidlc.config.json` **exists** in the current working directory,
> the skill is running via AIDLC launcher or CLI worker. Follow the unified execution model above.
> - Read config directly (do not rename)
> - Detect mode via `AIDLC_RUN_ID` env var
> - Discover design prerequisites from temp directory (local) or API (ECS)
> - Write output to temp directory
> - Report to ECS if applicable

⚠️ **EXECUTION ORDER**: Phase 0 (Mode detection) → Phase 1 (Read config) → Phase 2 (Discover prerequisites) → Phase 3 (Figma PNG discovery) → Phase 4 (TDD check) → **Phase 4.5 (Prerequisite Gate — HARD STOP if either missing)** → Phase 5 (Generate) → Phase 6 (Output to temp) → Phase 7 (ECS reporting)

---

## Phase 0 — Mode Detection

Determine execution mode by checking environment variables:

```powershell
$runId = [System.Environment]::GetEnvironmentVariable("AIDLC_RUN_ID")
$isLocalMode = $runId -eq "local"

if ($isLocalMode) {
    Write-Host "[M2-LOCAL] Running locally — prerequisites from temp directory"
} else {
    Write-Host "[M2-ECS] Running in ECS — prerequisites from central API"
}
```

---

## Phase 1 — Read Config

Always read `aidlc.config.json` directly (never renamed):

```powershell
if (-not (Test-Path "aidlc.config.json")) {
    throw "aidlc.config.json not found — run /launch first."
}

$cfg = Get-Content "aidlc.config.json" -Raw -Encoding UTF8 | ConvertFrom-Json
$centralBaseUrl = $cfg.central_base_url.TrimEnd('/')
$workspaceId    = $cfg.workspace_id
$TOKEN = [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env)

Write-Host "Config: workspace=$workspaceId, central_url=$centralBaseUrl"
```

---

## Phase 2 — Discover Design Prerequisites (M1)

M2 (ui-code) requires the design documents (LLD) from M1.

**Local Mode** — Search temp directory:

```powershell
if ($isLocalMode) {
    $designTempDir = Join-Path (Join-Path (Join-Path $env:TEMP "aidlc-ws") $workspaceId) "lld"
    
    if (Test-Path $designTempDir) {
        $designDocs = Get-ChildItem $designTempDir -Filter "*.md" -Recurse
        Write-Host "Found $($designDocs.Count) design documents in temp directory"
        $designWorktree = $designTempDir
    } else {
        $designWorktree = $null
        Write-Host "⚠ Design documents not found in temp directory"
    }
}
```

**ECS Mode** — Query central API:

```powershell
if (-not $isLocalMode) {
    $HDR = @{ 
        Authorization = "Bearer $TOKEN"
        "Content-Type" = "application/json" 
    }
    
    $runsUrl = "$centralBaseUrl/pipeline-runs?workspace_id=$workspaceId&stage_key=lld"
    try {
        $runs = (Invoke-RestMethod $runsUrl -Headers $HDR).items
        $completedRun = $runs | Where-Object { $_.state -in @("completed", "waiting_for_approval") } |
                             Sort-Object queued_at -Descending |
                             Select-Object -First 1
        
        if ($completedRun) {
            Write-Host "Found completed design run: $($completedRun.run_id)"
            $designWorktree = $completedRun.worktree
        } else {
            $designWorktree = $null
            Write-Host "⚠ No completed design run found"
        }
    } catch {
        Write-Host "Error querying API for design runs: $_"
        $designWorktree = $null
    }
}
```

**Gate Check:**

```powershell
if (-not $designWorktree) {
    throw @(
        "⚠ GATE CHECK FAILED — Design prerequisites not found"
        ""
        "M2 (ui-code) requires completed M1 (lld) design documents."
        "Run M1 (design:generate) before running M2."
    ) -join "`n"
}

Write-Host "✓ Design prerequisites found: $designWorktree"
```

---

### Step 0: Auto-Discover Figma PNG Files (ALWAYS RUN FIRST)

Before anything else, scan the `figma_png` folder inside the plugin directory for visual design inputs.

**Discovery logic:**

1. Resolve the Figma PNG folder path — check in this priority order:

   **a. Worker-injected path (highest priority — workspace-specific):**
   Look for this exact marker in the current prompt:
   ```
   Figma export folder (pre-confirmed from aidlc.config.json — do NOT prompt the user via AskUserQuestion): <path>
   ```
   If the marker is present, extract `<path>` and use it as the Figma folder.
   This path was provided by the user via the AIDLC launcher for this specific workspace
   and takes precedence over all other candidates. Do NOT show any AskUserQuestion.

   **b. Hardcoded fallback candidates (used when skill is invoked directly, not via worker):**
   - `${CLAUDE_PLUGIN_ROOT}/figma_png/`
   - `./plugins/AIDLC-axis/figma_png/`
   - `./figma_png/`

   Use the first candidate path that contains at least one `.png` file.

2. Glob all PNG files in the resolved folder:
   ```
   Glob({ pattern: "<figma_png_path>/*.png" })
   ```

3. **If PNG files are found:**
   - Tell the user:
     ```
     Found [N] Figma design file(s) for [epicId] in figma_png/epic-N/:
       - [filename1.png]
       - [filename2.png]
       ...
     Reading all images as visual design input...
     ```
   - Where `[epicId]` is the last path segment of the resolved folder (e.g. `epic-1`, `epic-2`).
     Extract it as: `figmaEpicId = resolvedFigmaPath.split(/[\\/]/).filter(Boolean).pop()`
   - Read every PNG file using the `Read` tool:
     ```
     Read({ file_path: "<figma_png_path>/<filename>.png" })
     ```
   - Store all loaded images as `figmaImages` (array of file paths + visual content).
   - Set flag: `hasFigmaImages = true`
   - Set flag: `hasTDDContext = false` (images are the primary source; TDD check in Step 1 still runs but is non-blocking when images are present)

4. **If figma_png folder is empty or does not exist:**
   - Set flag: `hasFigmaImages = false`
   - Continue to Step 1 normally (TDD check remains mandatory blocking gate)

5. **Pass figmaImages to every agent delegation** in Step 4 using this block:

   ```
   ## Epic Context

   Epic ID : ${figmaEpicId}   (e.g. epic-1, epic-2 — used to scope guards, interceptors, and output paths)

   ## Figma Visual Design Input

   The following Figma design screenshots have been loaded from figma_png/${figmaEpicId}/:
   ${figmaImages.map(img => `- ${img.filename} (Read and analyzed visually)`).join('\n')}

   **Instructions for agent:**
   - These screens belong exclusively to ${figmaEpicId}. Do NOT generate components for screens that belong to a different epic.
   - Figma is the VISUAL TRUTH for layout. LLD defines behavior and data contracts; Figma defines visual structure. When they conflict on layout, Figma wins.
   - If Figma shows a card-grid of module tiles (icon + title + description arranged in a grid), generate that as card-grid HTML (`div.module-cards-grid > button.module-card`). NEVER substitute a nav-list.
   - The nav-list AUG type is for sidebar or top-nav links only. Card-grid tiles on a dashboard page are NOT nav-list items.
   - The post-login home/landing/menu page shown in Figma is ALWAYS in scope for the authentication or navigation workspace. Generate it as a card-grid dashboard, not a navigation wrapper.
   - If images show multiple screens/pages, generate a COMPLETE Angular component per screen — no 3-line placeholders. A stub (`axis-page-header` + single `<p>` tag) is a delivery failure.
   - When a Figma screen has a matching route in the workspace but no component spec in the TDD, generate the component from the Figma alone and document the assumption in SUMMARY.md.
   - Extract field names, input types, validation hints, groupings, section headings, table columns, button labels, and modal dialogs directly from the images — match them exactly.
   - Security infrastructure files (guards, interceptors) are generated ONCE per epic — prefix output folder with ${figmaEpicId} or place under src/app/${figmaEpicId}/ as directed by the TDD output path.
   ```

---

### Step 0.5: Figma Screen Inventory (MANDATORY when hasFigmaImages = true)

Before delegating to any agent, build a screen inventory from the loaded Figma images. This step prevents stubs, wrong layouts, and silently skipped screens.

**For each distinct screen, state, or modal visible across all PNG files:**

| Screen Name | Image File | Type | In-Scope? | Component | Notes |
|---|---|---|---|---|---|
| e.g. Home / Landing Page | Home.png | page | YES | main-menu | post-login landing rule |
| e.g. Account Name Maintenance | ...1.png | empty-state | YES | rm-user-maintenance | route found in workspace TDD |
| e.g. Company Maintenance | ...1.png | page | NO | — | belongs to RM Application workspace |

**Screen types:** `page` | `modal` | `empty-state` | `loaded-state` | `dropdown-state`

**Scope rules (apply in order):**
1. **IN-SCOPE** — the screen is the post-login home / landing / dashboard page (always belongs to auth/nav workspace)
2. **IN-SCOPE** — a matching route path exists in any input document (ui-tdd.md, feature-tdd.md, routes file) for this workspace
3. **OUT-OF-SCOPE** — the screen clearly belongs to a different business domain with no route reference in this workspace's input documents

**Rules after producing the inventory:**
- Every **in-scope** screen → complete Angular component, no placeholders
- If in-scope screen has **no TDD component spec** → generate entirely from the Figma image; note `source: Figma-only` in SUMMARY.md
- Every **out-of-scope** screen → listed in SUMMARY.md under `## Figma Screens Not Generated (Out of Scope)` with the reason and the target workspace name (do NOT reference EPIC numbers — use the workspace or module name only, e.g. "RM Application workspace")
- **NEVER produce a 3-line stub** (`<axis-page-header title="X" /><p>Content.</p>`) for any in-scope screen

---

### Step 1: Check for Feature TDD Path (MANDATORY - DO NOT SKIP)

⚠️ **CRITICAL**: You MUST check for TDD context BEFORE proceeding to pattern detection or agent delegation. This step is MANDATORY and cannot be skipped.

Look for Feature TDD path in the incoming request:

**TDD Path Detection Patterns:**
```javascript
const TDD_PATH_PATTERNS = [
  /reference this TDD:\s*([^\s]+\.md)/i,
  /TDD file:\s*([^\s]+\.md)/i,
  /TDD path:\s*([^\s]+\.md)/i,
  /from\s+([^\s]+\.(TDD|LLD|HLD)\.md)/i,
  /(reference_material|\.idea|docs)\/[^\s]+\.(md|TDD\.md|LLD\.md|HLD\.md)/i,
  /@([^\s]+\.(md|TDD\.md|LLD\.md|HLD\.md))/i
];
```

**If TDD path NOT provided (most common case):**

> ⚡ **Figma shortcut**: If `hasFigmaImages = true` (Step 0 loaded PNG files), automatically select **Option 3** — do NOT ask the user. Then:
> 1. Scan the workspace input directory for a `ui-tdd.md` file. Check these paths in order: `lld/ui-tdd.md`, `design/ui-tdd.md`, any `.md` file in `lld/` whose name contains "ui" or "tdd".
> 2. **If a `ui-tdd.md` is found** → set `hasTDDContext = true`, proceed to **Step 2** (invoke tdd-extractor on it). The Figma provides visual layout; the TDD provides component architecture and data models. Both are used together.
> 3. **If no `ui-tdd.md` is found** → set `hasTDDContext = false`, proceed to **Step 1.5** (Prerequisite Gate — this will issue a HARD STOP). Do NOT skip to Step 3.

> ⚡ **ECS server-mode shortcut**: If `aidlc.config.json` does **NOT** exist in the current working directory, this is a headless ECS run — automatically select **Option 3** (proceed without interactive TDD prompt) and skip directly to Step 3. The KB chunk IDs in the run context provide the source artifacts.

1. ⚠️ **STOP IMMEDIATELY** (only when `hasFigmaImages = false` AND `aidlc.config.json` exists in the current working directory) - Do not proceed to pattern detection
2. Use AskUserQuestion tool to present options to the user:

   **Question:** "How would you like to proceed with code generation?"

   **Options:**
   - **Option 1**: "I have a TDD file. Let me provide the path." (Recommended)
     - Description: "Provides complete architecture, endpoints, and models for accurate code generation"
     - If selected: Ask for file path, then proceed to Step 2 (TDD extraction)

   - **Option 2**: "I don't have a TDD, but I can answer questions about the architecture."
     - Description: "Generate virtual TDD context by answering 3 quick questions about your requirements"
     - If selected: ADLC virtual TDD context via AskUserQuestion (3 questions below), then proceed to Step 3 (skip Step 2)
     - Questions:
       1. **Repository Structure (TDD Section 4.1):** Project root, folder organization, component/service/model locations
       2. **API Endpoints (TDD Section 5.1):** Base URLs, HTTP methods, request/response structures, authentication
       3. **Component Architecture (TDD Section 6.x):** Component type, state management, data flow, validation strategy, UI pattern (static vs dynamic)

   - **Option 3**: "Proceed with generation. I will provide feedback as the code is generated."
     - Description: "Generate code using Axis framework best practices. TDD compliance validation will be skipped."
     - If selected: Set flag `hasTDDContext = false`, skip Step 2, proceed to Step 3 (pattern detection)

3. Wait for user selection and process accordingly

**If TDD path provided in request:**
- Set flag: `hasTDDContext = true`
- Proceed directly to Step 2

⚠️ **WARNING**: If you proceed to Step 3 without completing Step 1, you have violated the workflow and will generate incorrect code without proper architecture context.

---

### Step 1.5: Mandatory Prerequisite Gate (HARD STOP)

⛔ **This gate runs immediately after Step 0 (Figma discovery) and Step 1 (TDD check) have both completed and set their flags. It is NON-NEGOTIABLE — no override, no workaround, no user prompt to bypass.**

Evaluate the two flags `hasFigmaImages` and `hasTDDContext` together:

| `hasFigmaImages` | `hasTDDContext` | Decision |
|---|---|---|
| `true` | `true` | ✅ **PROCEED** — both prerequisites confirmed |
| `false` | `true` | ❌ **HARD STOP** — Figma screens missing |
| `true` | `false` | ❌ **HARD STOP** — UI-TDD missing |
| `false` | `false` | ❌ **HARD STOP** — Neither present |

---

**Case 1 — HARD STOP: Figma missing, TDD present** (`hasFigmaImages = false`, `hasTDDContext = true`):

Output this exact message and terminate immediately. Do not generate any code, do not proceed to Step 2 or beyond:

```
⛔ PREREQUISITE GATE FAILED — Figma screens missing.

Figma screens missing. Place PNG exports in figma_png/ folder and re-run UI-code stage.

Steps to resolve:
  1. Export all Figma screens as PNG files.
  2. Place the exported PNG files in the figma_png/ folder at the workspace root.
  3. Re-run the UI-code stage.

UI code generation has been stopped. No files have been generated.
```

---

**Case 2 — HARD STOP: UI-TDD missing, Figma present** (`hasFigmaImages = true`, `hasTDDContext = false`):

Output this exact message and terminate immediately. Do not generate any code, do not proceed to Step 2 or beyond:

```
⛔ PREREQUISITE GATE FAILED — UI-TDD missing.

UI-TDD missing. First re-run the "LLD and TDDs stage" for UI-TDD.md file and second re-run the UI-code stage.

Steps to resolve:
  1. Re-run the "LLD and TDDs stage" to generate the UI-TDD.md file.
  2. Confirm that ui-tdd.md is present in the workspace lld/ folder.
  3. Re-run the UI-code stage.

UI code generation has been stopped. No files have been generated.
```

---

**Case 3 — HARD STOP: Neither present** (`hasFigmaImages = false`, `hasTDDContext = false`):

Output this exact message and terminate immediately. Do not generate any code, do not proceed to Step 2 or beyond:

```
⛔ PREREQUISITE GATE FAILED — Both prerequisites missing.

Both Figma screens and UI-TDD are required. Neither was found.

Steps to resolve:
  1. Re-run the "LLD and TDDs stage" to generate the UI-TDD.md file.
  2. Export all Figma screens as PNG files and place them in the figma_png/ folder at the workspace root.
  3. Re-run the UI-code stage.

UI code generation has been stopped. No files have been generated.
```

---

**Case 4 — Gate passes** (`hasFigmaImages = true` AND `hasTDDContext = true`):

Output a confirmation and proceed to Step 2:

```
✅ PREREQUISITE GATE PASSED — Both Figma screens and UI-TDD confirmed.
   Epic ID      : [figmaEpicId]   (e.g. epic-1)
   Figma images : [N] PNG files loaded from figma_png/[figmaEpicId]/
   UI-TDD       : [resolved path to ui-tdd.md]
   Proceeding to Step 2 (TDD extraction)...
```

---

### Step 2: Extract TDD Sections

Once TDD file path is obtained, invoke tdd-extractor agent:

```typescript
Task(subagent_type: "AIDLC-axis:tdd-extractor",
     prompt: "Extract sections from [user-provided-tdd-path]")
```

**Parse extraction response:**
- Look for "Extracted Sections:" in response
- Store section paths (overview, components, forms, api-integration-endpoints, etc.)
- If status="error": Display error and return to Step 1
- If status="partial": Note warnings and proceed with available sections
- If status="success": Proceed to Step 3

**Example Response:**
```
TDD extraction completed successfully.

**Status:** success
**Extracted Sections:**
- overview: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/client-info/overview.md
- components: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/client-info/components.md
- forms: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/client-info/forms.md
- api-integration-endpoints: /path/to/plugins/AIDLC-axis/.cache/tdd-extractions/client-info/api-integration-endpoints.md
...
```

### Step 3: Detect UI Pattern

Analyze in this order:

**3a. If `generation-requirements.json` exists** (written by tdd-extractor in Step 2):
- Read it first — it contains the authoritative component list, UI patterns, and any TDD gaps.
- If it flags `uiPattern: "dynamic-aug"` for any component → route to **dynamic-ui-generator**.
- If it flags any component with `"tddGap": true` (route exists, no component spec) → pass those component names to the delegated agent explicitly as: "generate `<ComponentName>` from the Figma image — no TDD spec exists for this component".
- Otherwise continue to 3b for the remaining routing decision.

**3b. Analyze user request and TDD content (if available) to determine routing:**

**Priority 1: POM/Interface Detection (HIGHEST)**

Routes to **dynamic-ui-generator** when detecting:
- TypeScript interface definitions: `interface SomethingModel { ... }`
- Nested interfaces (2+ levels deep)
- Keywords: "POM", "Policy", "ObjectModel", "interface" with properties
- Phrases: "populate from POM", "map to POM", "POM fields", "POM structure"

**Priority 2: axis-ui-generator Component**

Routes to **dynamic-ui-generator** when detecting:
- "axis-ui-generator component" (refers to the Angular COMPONENT, not the agent)
- "using axis-ui-generator" or "with axis-ui-generator"
- "AUG component", "AXIS UI Generator component"
- "generate an axis-ui-generator component"

**Priority 3: Dynamic UI Patterns**

Routes to **dynamic-ui-generator** when detecting:
- DynamoDB, ui-component-catalog, uiStructure, componentConfig
- `*.aug.json` files
- "dynamic UI", "dynamic form", "runtime rendering"
- "JSON schema retrieval"

**Static UI (No Dynamic Indicators)**

Routes to **axis-ui-generator** when:
- Simple UI request: "create a form", "build a dashboard"
- NO POM structures or interface definitions
- NO axis-ui-generator COMPONENT mentions
- NO DynamoDB/dynamic indicators
- Modifying existing static components

**Ambiguous Requests**

Routes through **axis-router** when:
- Request is ambiguous (could be static or dynamic)
- Referenced documents need to be analyzed first
- Unclear whether POM/dynamic UI is involved

### Step 4: Delegate to Specialized Agent

Based on pattern detection, delegate with complete context.

---

## Agent Delegation

### Dynamic UI Generator

For clearly dynamic UI with POM/DynamoDB indicators:

```typescript
Task(subagent_type: "AIDLC-axis:dynamic-ui-generator", prompt: `
User Request: ${userRequest}

## Epic Context

Epic ID : ${figmaEpicId || 'unknown'}
All components, guards, interceptors, and output paths generated in this run belong to ${figmaEpicId || 'this epic'}.
Security infrastructure files (guards, interceptors) are generated ONCE for this epic — do not duplicate across components.

## TDD Context

${tddPath ? `
**TDD Available**: Yes
**TDD File Path:** ${tddPath}

**TDD Categories Available:**
${extractedSections.map(s => `- ${s.name}: ${s.path}`).join('\n')}

**Instructions:** Read relevant TDD sections above for architecture, endpoints, and models. Your Step 0-pre will detect these paths and use them for generation.
` : virtualTddContext ? `
**TDD Available**: Yes (Virtual)
**Virtual TDD Context (from user responses):**

**Repository Structure:**
${virtualTddContext.repositoryStructure}

**API Endpoints:**
${virtualTddContext.apiEndpoints}

**Component Architecture:**
${virtualTddContext.componentArchitecture}
` : `
**TDD Available**: No

**Instructions:** User chose to proceed without TDD. Generate code using Axis framework best practices and conventions as defined in your agent instructions. Skip TDD Compliance Validation steps.
`}

${pomStructures ? `
## POM Structure
${pomStructures}
` : ''}

${referencedDocs ? `
## Referenced Documents
${referencedDocs}
` : ''}

## Your Task

Generate Angular code that uses the axis-ui-generator COMPONENT to render dynamic UI.

MANDATORY FILES:

**Per-Component Files (one set per component):**
1. {component-name}.component.ts - Component with DynamoDB integration
2. {component-name}.component.html - Template using <axis-ui-generator>
3. {component-name}.service.ts - API service for DynamoDB calls
4. {component-name}.model.ts - TypeScript interfaces matching POM
5. {component-name}.aug.json - Pure JSON structure for UI configuration (REQUIRED)

**Security Infrastructure (once per epic, not per component):**
6. guards/auth.guard.ts - Route guard for authentication check
7. guards/rbac.guard.ts - Route guard for role-based access control
8. guards/data-def-rbac.guard.ts - Data definition RBAC guard (if TDD specifies data-level access control)
9. guards/portal-rbac.guard.ts - Portal-level RBAC guard (if multi-portal TDD)
10. interceptors/rbac-http.interceptor.ts - HTTP interceptor for attaching RBAC tokens to API requests
11. interceptors/global-error.interceptor.ts - HTTP interceptor for centralized error handling

**Routing & Documentation:**
12. app.routes.ts - Angular routing configuration with guard assignments
13. SUMMARY.md - Written to the stage output directory (e.g. workspaces/{workspace_id}/ui-code/SUMMARY.md).
    CRITICAL: This file is read by subsequent epics (Step 0A of axis-ui-generator) to prevent
    duplicate component/service/route generation. Use this EXACT structured format:

    ```markdown
    ---
    epic: {epic_id}
    workspace: {workspace_id}
    generated_at: {ISO-8601 timestamp}
    ---

    ## Components
    | Selector | Class | Module | Purpose |
    |---|---|---|---|
    | app-example | ExampleComponent | ExampleModule | One-line description |

    ## Services
    | Class | Scope | Key Methods |
    |---|---|---|
    | ExampleService | root | getExample(), createExample() |

    ## Routes
    | Path | Component | Guard |
    |---|---|---|
    | example | ExampleComponent | AuthGuard |

    ## Shared Utilities
    | Name | Type | Purpose |
    |---|---|---|
    | ExamplePipe | Pipe | Formats example values |

    ## Imported from Prior Epics
    | Name | Source Epic | Usage in This Epic |
    |---|---|---|
    | QuoteService | epic-1 | Injected into ReviewService |

    ## Files Generated
    | Layer | Count | Sample |
    |---|---|---|
    | Components (TS) | N | example.component.ts |
    | Templates (HTML) | N | example.component.html |
    | Services | N | example.service.ts |
    | Guards | N | auth.guard.ts |
    | Interceptors | N | rbac-http.interceptor.ts |
    | AUG Config (JSON) | N | example.aug.json |
    | Total | N | — |
    ```

REQUIREMENTS:
- Use augRef._helper methods for field manipulation
- Include cleanup with formService.clearFormData() in ngOnDestroy
- Follow all Axis framework conventions
- Ensure production-ready, complete implementation
- DO NOT generate any test files (*.spec.ts, TestBed, jasmine.createSpyObj).
  Test generation is exclusively owned by the ui-smoke stage (M7) via
  AIDLC-axis:axis-test — writing spec files here creates duplicates and
  conflicts when M7 runs.

OUTPUT PATH: ${outputPath || 'src/app/'}
`)
```

**Key Points:**
- TDD sections are passed with "TDD Categories Available:" header
- dynamic-ui-generator's Step 0-pre will detect and use these paths
- Agent will NOT re-extract TDD (avoids duplicate work)
- Agent receives extracted section paths for selective reading

### Static UI Generator

For clearly static UI without dynamic indicators:

```typescript
Task(subagent_type: "AIDLC-axis:axis-ui-generator", prompt: `
User Request: ${userRequest}

## Epic Context

Epic ID : ${figmaEpicId || 'unknown'}
All components, guards, interceptors, and output paths generated in this run belong to ${figmaEpicId || 'this epic'}.
Security infrastructure files (guards, interceptors) are generated ONCE for this epic — do not duplicate across components.

## TDD Context

${tddPath ? `
**TDD Available**: Yes
**TDD File Path:** ${tddPath}

**TDD Categories Available:**
${extractedSections.map(s => `- ${s.name}: ${s.path}`).join('\n')}

**Instructions:** Read relevant TDD sections above for architecture, endpoints, and models. Your Step 0-pre will detect these paths and use them for generation.
` : virtualTddContext ? `
**TDD Available**: Yes (Virtual)
**Virtual TDD Context (from user responses):**

**Repository Structure:**
${virtualTddContext.repositoryStructure}

**API Endpoints:**
${virtualTddContext.apiEndpoints}

**Component Architecture:**
${virtualTddContext.componentArchitecture}
` : `
**TDD Available**: No

**Instructions:** User chose to proceed without TDD. Generate code using Axis framework best practices and conventions as defined in your agent instructions. Skip TDD Compliance Validation steps.
`}

${referencedDocs ? `
## Referenced Documents
${referencedDocs}
` : ''}

## Your Task

Generate STATIC Angular UI code using Axis components.

MANDATORY FILES:

**Per-Component Files:**
1. For CRUD features, generate SEPARATE component files (decomposition pattern):
   - {feature}-list.component.ts/html - List/grid view
   - {feature}-create.component.ts/html - Create/add new form
   - {feature}-detail.component.ts/html - Read-only detail view
   - {feature}-edit.component.ts/html - Edit existing record form
   
   Example: User management feature generates:
   - user-list.component.ts/html
   - user-create.component.ts/html  
   - user-detail.component.ts/html
   - user-edit.component.ts/html

2. For non-CRUD features (dashboard, report, search), generate:
   - {component-name}.component.ts - Complete implementation
   - {component-name}.component.html - Template using Axis components
   - {component-name}.component.scss - Styles if needed

3. Shared files per feature domain:
   - {domain}.service.ts - API service (one per domain, not per component)
   - {domain}.model.ts - TypeScript interfaces (or models/ directory with one file per entity)

**Security Infrastructure (once per epic):**
4. guards/auth.guard.ts - Route guard for authentication check
5. guards/rbac.guard.ts - Route guard for role-based access control
6. interceptors/rbac-http.interceptor.ts - HTTP interceptor for RBAC tokens
7. interceptors/global-error.interceptor.ts - HTTP interceptor for error handling

**Routing & Documentation:**
8. app.routes.ts - Angular routing with guard assignments on protected routes
9. SUMMARY.md - Written to the stage output directory (e.g. workspaces/{workspace_id}/ui-code/SUMMARY.md).
   CRITICAL: This file is read by subsequent epics (Step 0A of axis-ui-generator) to prevent
   duplicate component/service/route generation. Use this EXACT structured format:

   ```markdown
   ---
   epic: {epic_id}
   workspace: {workspace_id}
   generated_at: {ISO-8601 timestamp}
   ---

   ## Components
   | Selector | Class | Module | Purpose |
   |---|---|---|---|
   | app-example | ExampleComponent | ExampleModule | One-line description |

   ## Services
   | Class | Scope | Key Methods |
   |---|---|---|
   | ExampleService | root | getExample(), createExample() |

   ## Routes
   | Path | Component | Guard |
   |---|---|---|
   | example | ExampleComponent | AuthGuard |

   ## Shared Utilities
   | Name | Type | Purpose |
   |---|---|---|
   | ExamplePipe | Pipe | Formats example values |

   ## Imported from Prior Epics
   | Name | Source Epic | Usage in This Epic |
   |---|---|---|
   | QuoteService | epic-1 | Injected into ReviewService |

   ## Files Generated
   | Layer | Count | Sample |
   |---|---|---|
   | Components (TS) | N | example.component.ts |
   | Templates (HTML) | N | example.component.html |
   | Services | N | example.service.ts |
   | Guards | N | auth.guard.ts |
   | Interceptors | N | rbac-http.interceptor.ts |
   | Total | N | — |
   ```

REQUIREMENTS:
- Follow all 13 mandatory Axis conventions
- Use ONLY Axis components (NO Bootstrap, NO Material, NO native HTML)
- Ensure production-ready, complete implementation
- DO NOT generate any test files (*.spec.ts, TestBed, jasmine.createSpyObj).
  Test generation is exclusively owned by the ui-smoke stage (M7) via
  AIDLC-axis:axis-test — writing spec files here creates duplicates and
  conflicts when M7 runs.

${hasFigmaImages ? `
## Figma Fidelity Requirements (MANDATORY — Figma images are present)

FIGMA-1 SCREEN INVENTORY: Before writing any file, confirm the Step 0.5 screen inventory.
  For each in-scope screen state: screen name | component file | source (TDD / Figma-only)
  For each out-of-scope screen: name | reason | target workspace

FIGMA-2 COMPLETE GENERATION — for each in-scope screen:
  - source=TDD: implement per TDD spec AND match Figma layout section-by-section
  - source=Figma-only (no TDD spec): implement entirely from the Figma image
  - Card-grid in Figma → generate div.module-cards-grid > button.module-card (NOT nav-list, NOT axis-ui-generator nav-list type)
  - Modal in Figma → generate as @if overlay or separate component (NOT omitted)
  - 2-column layout in Figma → generate CSS flex/grid wrapper (NOT collapsed to single column)
  - Navigation tiles on a dashboard → each tile is a clickable card element, not a list item

FIGMA-3 NO STUBS — every in-scope screen must have a complete template. These are NOT acceptable:
  ✗  <axis-page-header title="X" /><p>Content rendered after server authorisation.</p>
  ✗  Any in-scope component template with fewer than 15 meaningful lines for a screen
     that shows a form, table, or card-grid in the Figma

FIGMA-4 SELF-CHECK — after generating each component, verify against its Figma image:
  ✓ Layout structure matches (card-grid / form / table / sidebar / modal as shown in image)
  ✓ All field labels match Figma text exactly (no paraphrasing)
  ✓ All table columns present with correct column headers
  ✓ All modal dialogs generated if visible in Figma
  ✓ All buttons present with correct labels
  If any check fails, fix before completing.
` : ''}

OUTPUT PATH: ${outputPath || 'src/app/'}
`)
```

**Key Points:**
- TDD sections passed same way as dynamic generator
- axis-ui-generator's Step 0-pre handles TDD detection
- Agent receives extracted section paths for selective reading

### Router (Ambiguous Cases)

For requests that need analysis or when TDD content must be read first:

```typescript
Task(subagent_type: "AIDLC-axis:axis-router", prompt: `
User Request: ${userRequest}

${tddPath ? `
**TDD File Path:** ${tddPath}

**Instructions:** Process this TDD path according to your workflow (Step 1-2). You will extract sections and route to appropriate agent.
` : ''}

## Instructions

1. **Check for TDD**: If TDD path not provided above, request it from user
2. **Extract TDD**: Invoke tdd-extractor to break down monolithic TDD
3. **Analyze Request**: Read relevant TDD sections to understand requirements
4. **Detect Pattern**: Determine if static or dynamic based on POM/DynamoDB/AUG indicators
5. **Route to Agent**:
   - axis-ui-generator for static UI
   - dynamic-ui-generator for dynamic UI
6. **Pass Context**: Delegate with TDD sections and extracted context
7. **Generate Code**: Ensure complete, production-ready implementation
8. **Report Results**: Summarize what was created

If uncertain after analysis, ask the user to clarify.
`)
```

**Key Points:**
- Router handles full TDD workflow internally
- Use when pattern detection is uncertain
- Router extracts TDD and routes to correct agent

---

## TDD Context Flow

This diagram shows how TDD context flows through the system:

```
User Request
    ↓
[axis-implement skill]
    ↓
STEP 0: FIGMA PNG AUTO-DISCOVERY (ALWAYS RUNS FIRST)
    ├─→ Resolve figma_png/epic-N/ (worker-injected path or fallback)
    ├─→ Glob figma_png/epic-N/*.png
    ├─→ If PNGs found: Read all images → set hasFigmaImages=true, figmaEpicId="epic-N"
    └─→ If no PNGs: set hasFigmaImages=false → Step 1 still runs
    ↓
STEP 1: CHECK FOR TDD
    ├─→ If hasFigmaImages=true: scan lld/ for ui-tdd.md silently
    │   ├─→ Found → set hasTDDContext=true
    │   └─→ Not found → set hasTDDContext=false (Step 1.5 will hard-stop)
    ├─→ If hasFigmaImages=false: TDD check is BLOCKING
    │   ├─→ Detect TDD path in request; if not found → present 3 options to user
    │   └─→ If found → set hasTDDContext=true
    ↓
⛔ STEP 1.5: MANDATORY PREREQUISITE GATE (NON-NEGOTIABLE)
    ├─→ hasFigmaImages=true  AND hasTDDContext=true  → ✅ PROCEED
    ├─→ hasFigmaImages=false AND hasTDDContext=true  → ❌ HARD STOP (Figma missing)
    ├─→ hasFigmaImages=true  AND hasTDDContext=false → ❌ HARD STOP (UI-TDD missing)
    └─→ hasFigmaImages=false AND hasTDDContext=false → ❌ HARD STOP (neither present)
    ↓ (only if gate passes)
STEP 2: EXTRACT TDD SECTIONS
    ├─→ Invoke tdd-extractor with ui-tdd.md path
    ├─→ Receive extracted section paths
    ↓
STEP 3: DETECT UI PATTERN
    ├─→ POM/Interface? → dynamic-ui-generator
    ├─→ Static request? → axis-ui-generator
    ├─→ Ambiguous? → axis-router
    ↓
STEP 4: DELEGATE TO AGENT — passes BOTH:
    ├─→ ## Epic Context  (epicId — scopes guards, interceptors, output paths)
    ├─→ ## Figma Visual Design Input  (figmaEpicId screens — visual truth for layout)
    ├─→ ## TDD Context  (extracted section paths — behavioral truth)
    └─→ Agent generates components for this epic only; gate ensures both inputs present
    ↓
[Code Generated — scoped to epic-N]
```

**Benefits:**
- ✅ TDD extracted ONCE at skill level
- ✅ Agents receive pre-extracted sections (no re-extraction)
- ✅ Agents read only needed sections (57-98% token savings)
- ✅ Consistent architecture across all generated code
- ✅ Virtual TDD context supported when no physical file exists

---

## Implementation Guidelines

### Axis Framework Conventions

All generated code must follow:
1. **Standalone Components**: Angular 17 standalone pattern (Axis v18.0.32 requires Angular 17)
2. **AxisSharedModule**: Import for all Axis components
3. **No External UI Libraries**: NO Bootstrap, NO Material, NO native HTML
4. **Reactive Forms**: Use FormGroup, FormControl, Validators
5. **TypeScript Strict**: Full type safety with interfaces
6. **Accessibility**: ARIA labels, semantic HTML, keyboard navigation
7. **Responsive Design**: Mobile-first with Axis responsive utilities
8. **Error Handling**: Comprehensive validation and error messages

### File Structure

Generated code should follow:
```
src/app/[feature]/
├── [component-name].component.ts
├── [component-name].component.html
├── [component-name].component.scss
├── [component-name].model.ts (interfaces)
└── [component-name].aug.json (dynamic UI only)
```

### Quality Requirements

- **Complete**: All files generated, no placeholders
- **Production-Ready**: No TODOs, no mock data (unless specified)
- **Type-Safe**: Full TypeScript interfaces and type annotations
- **Tested**: Include component structure suitable for unit testing
- **Documented**: Clear component purpose and usage comments

---

## Error Handling

| Situation | Response |
|-----------|----------|
| **TDD path not provided** | Ask user: "Please provide the Feature TDD file path" |
| **TDD file not found** | Display error and offer to ADLC virtual TDD via AskUserQuestion |
| **TDD extraction fails** | Show error, offer to read full file or ADLC virtual context |
| **Ambiguous UI pattern** | Route through axis-router for analysis |
| **No output path specified** | Use default: `src/app/` |

---

## Related Skills & Agents

**Skills:**
- `axis-docs` - Component API reference and examples
- `axis-types` - TypeScript type definitions
- `generation-patterns` - Implementation patterns and examples

**Agents:**
- `tdd-extractor` - Extracts TDD sections for token efficiency
- `axis-router` - Planning and routing coordinator
- `axis-ui-generator` - Static UI code generation
- `dynamic-ui-generator` - Dynamic UI with DynamoDB
- `axis-documentation` - Component documentation lookup
- `axis-development-guide` - Framework conventions and patterns

---

## Common Use Cases

### Form Generation
"Create a contact form with name, email, phone, and message fields"

### Dashboard/Layout
"Build a dashboard with a card grid layout and summary statistics"

### Data Entry with TDD
"Generate a producer information form from reference_material/producer-ui-design.md"

### Dynamic Forms with POM
"Create a dynamic form that loads structure from DynamoDB using this POM: [interface definition]"

### Component Modification
"Update the login form to add remember me checkbox and forgot password link"

---

## Troubleshooting

**Issue**: Skill skipped TDD check and jumped directly to code generation

**Solution**: The skill MUST always execute Step 1 first. If you see this happening, the workflow was violated. The correct behavior is:
1. Check for TDD path in request
2. If not found → ASK USER for TDD path (blocking)
3. Wait for user response
4. Then proceed to pattern detection

**Issue**: TDD not provided, code lacks proper architecture

**Solution**: Skill will automatically ask for TDD path as Step 1 (mandatory). If unavailable, ADLCs virtual context via AskUserQuestion.

**Issue**: Wrong generator selected (static vs dynamic)

**Solution**: Be explicit about requirements:
- For static: "Create a simple form with Axis components"
- For dynamic: "Create a dynamic form with POM mapping and DynamoDB"

**Issue**: Agent re-extracts TDD (duplicate work)

**Solution**: Ensure "TDD Categories Available:" header is included in delegation prompt with section paths.

**Issue**: Missing component imports

**Solution**: Ensure AxisSharedModule is imported and referenced in the skill output

**Issue**: Non-Axis components used

**Solution**: Re-invoke with emphasis: "Use ONLY Axis components, no Bootstrap or Material"

---

## Examples

### Example 1: User provides TDD path

**User:** "Generate a client information form from reference_material/client-info-ui-design.md"

**Skill Actions:**
1. Detects TDD path: `reference_material/client-info-ui-design.md`
2. Invokes tdd-extractor: `Task(subagent_type: "AIDLC-axis:tdd-extractor", prompt: "Extract sections from reference_material/client-info-ui-design.md")`
3. Receives section paths
4. Analyzes request: detects "form" keyword
5. Checks TDD for dynamic indicators
6. Routes to appropriate agent with TDD sections

### Example 2: User doesn't provide TDD

**User:** "Create a login form"

**Skill Actions:**
1. ⚠️ **STEP 1 CHECK**: No TDD path detected in request
2. ⛔ **STOP**: Do not proceed to pattern detection
3. **ASK USER**: "To ensure correct architecture, endpoints, and models, please provide the Feature TDD file path (e.g., reference_material/login-ui-design.md)"
4. **WAIT**: User provides: "docs/login-ui-design.md"
5. **STEP 2**: Invoke tdd-extractor with path
6. **STEP 3**: Receive sections, detect pattern, and proceed to agent delegation

**❌ WRONG Behavior (DO NOT DO THIS):**
1. User: "Create a login form"
2. Skill detects "form" keyword → immediately jumps to pattern detection
3. Delegates to axis-ui-generator without TDD context
4. ❌ Generated code lacks proper architecture, endpoints, models

### Example 3: User has no TDD

**User:** "I don't have a TDD file"

**Skill Actions:**
1. Uses AskUserQuestion to ADLC:
   - Repository structure (project root, folder locations)
   - API endpoints (base URL, authentication)
   - Component architecture (state management, validation)
2. Constructs virtual TDD context
3. Routes to agent with virtual context
4. Agent generates code using ADLCed information

### Example 4: POM structure provided

**User:** "Generate a policy form with this POM: [interface PolicyObjectModel { ... }]"

**Skill Actions:**
1. Detects POM/interface definition (Priority 1)
2. Routes to dynamic-ui-generator (regardless of TDD)
3. Passes POM structure in delegation
4. dynamic-ui-generator creates aug.json with POM mappings

---

## Reporting to the AIDLC Platform (ECS UI tracking)

> **SERVER CLI GUARD:** If `aidlc.config.json` does **not** exist in your current
> working directory, skip this entire ECS section and run only the main workflow
> above. These steps are for the **local Claude Code session only**.

The local session creates the ECS run and monitors progress. All generation
is performed by the ECS server CLI — do **not** generate or copy files locally.

---

**Step 0 — Read config**
```powershell
# Resolve absolute path at startup so the script works regardless of working directory drift
$cfgPath = (Resolve-Path "aidlc.config.json" -ErrorAction Stop).Path
$cfg     = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
$BASE    = $cfg.central_base_url.TrimEnd('/')
$TOKEN   = [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env)
# Fall back to relay file if env var is not set
if (-not $TOKEN) {
    $relayFile = Join-Path (Split-Path $cfgPath) ".aidlc_token"
    if (Test-Path $relayFile) { $TOKEN = (Get-Content $relayFile -Raw -Encoding UTF8).Trim() }
}
$WS    = $cfg.workspace_id
$HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
$STAGE = "ui-code"
```

**Step 0.1 — Token Validation (MANDATORY — runs before any ECS call)**

After reading the config, validate the token. If it is missing or expired, **ask the user to paste their Okta token inline** — no separate script to run.

```powershell
# ── Helper: decode JWT expiry (returns Unix epoch seconds, or 0 on failure) ──
function Get-JwtExpiry {
    param([string]$Token)
    try {
        $parts = $Token.Split('.')
        if ($parts.Count -lt 2) { return 0 }
        $payload = $parts[1]
        $mod = $payload.Length % 4
        if ($mod -ne 0) { $payload += '=' * (4 - $mod) }
        $json = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($payload))
        return [long]($json | ConvertFrom-Json).exp
    } catch { return 0 }
}

$TOKEN_VALID = $false
if ($TOKEN -and $TOKEN.StartsWith("eyJ")) {
    $exp = Get-JwtExpiry $TOKEN
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    if ($exp -eq 0 -or ($exp - $now) -gt 60) { $TOKEN_VALID = $true }
}

if (-not $TOKEN_VALID) {
    # Check for a DPAPI-stored refresh token — worker will auto-refresh silently
    $refreshStore = Join-Path $env:APPDATA "aidlc-auth\refresh.dat"
    if (Test-Path $refreshStore) {
        Write-Host "✓ Stored Okta refresh token found — worker will auto-refresh. Proceeding..."
        $TOKEN_VALID = $true
    }
}
```

If `$TOKEN_VALID` is still `$false`, **do not proceed to Step 1**. Ask the user to paste their token:

```
AskUserQuestion({
  questions: [{
    question: "Your Okta token is missing or expired. Please paste your fresh Bearer token to continue (use the Other field).",
    header: "Okta Token",
    multiSelect: false,
    options: [
      {
        label: "Paste token (use the Other field below)",
        description: "Copy your Okta Bearer token (starts with eyJ...) and paste it in the Other field. It will be saved automatically so the CLI worker can use it."
      },
      {
        label: "Cancel — I will set it manually",
        description: "Run in PowerShell:  $env:AIDLC_TOKEN='eyJ...'  then re-invoke the skill."
      }
    ]
  }]
})
```

When the user pastes the token via the **Other** field:
1. Save it to the relay file and update the auth header:
   ```powershell
   $relayFile = Join-Path (Split-Path $cfgPath) ".aidlc_token"
   Set-Content $relayFile $pastedToken.Trim() -Encoding UTF8
   $TOKEN = $pastedToken.Trim()
   $HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
   ```
2. Tell the user:
   ```
   ✓ Token saved. Continuing...
   ℹ  To avoid this prompt in future sessions, run once:
      .\plugins\AIDLC-launcher\scripts\aidlc-auth.ps1
      (stores a 24-hour Okta refresh token — no more manual pastes)
   ```
3. Proceed to Step 0.5.

**Step 0.5 — Collect Figma export ROOT path (if not already saved)**

Check `aidlc.config.json` for `figma_export_path`. If it is **not** set:

```
AskUserQuestion({
  questions: [{
    question: "Provide the ROOT folder path that contains your epic-specific Figma PNG subfolders.\n\nExpected structure:\n  <root>\\epic-1\\screen1.png\n  <root>\\epic-1\\screen2.png\n  <root>\\epic-2\\screen1.png\n\nThe worker will automatically append the epic ID (e.g. epic-1, epic-2) to this root path and load only the screens for the current epic.",
    header: "Figma Root",
    multiSelect: false,
    options: [
      {
        label: "Skip — no Figma designs",
        description: "Proceed without Figma visual grounding. Code will be generated from TDD/LLD spec only."
      },
      {
        label: "I will type the root path below (use Other)",
        description: "Type the absolute ROOT folder path in the Other field (e.g. C:\\figma_exports). Do NOT include the epic subfolder — the worker appends it automatically."
      }
    ]
  }]
})
```

- **Path provided via Other field** → write `aidlc.config.json` back with `figma_export_path` set to the root path.
  Print:
  ```
  ✓ Figma export root path saved: <path>
    Worker will resolve <path>\epic-N\ per epic and inject it into each UI-code generation prompt.
    Folder structure required:
      <path>\epic-1\*.png   ← screens for epic-1
      <path>\epic-2\*.png   ← screens for epic-2
      <path>\epic-N\*.png   ← screens for epic-N
  ```
- **Skip** → print `⚠ Proceeding without Figma visual grounding.` and continue.

If `figma_export_path` **is already set**, print:
```
✓ Figma export root path: <figma_export_path>
  Worker will resolve <figma_export_path>\epic-N\ per epic automatically.
```

**Step 1 — Smart run management: cancel queued / attach running / create fresh**
```powershell
# Check for an existing active run for this stage
$existing = $null
try {
    $existing = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS&stage_key=$STAGE" -Headers $HDR).items |
        Where-Object { $_.state -in @("queued", "running") } |
        Sort-Object queued_at -Descending |
        Select-Object -First 1
} catch {}

if ($existing -and $existing.state -eq "queued") {
    # Queued but not started — cancel immediately and restart fresh
    Invoke-RestMethod "$BASE/pipeline-runs/$($existing.run_id)/cancel" -Headers $HDR -Method Post | Out-Null
    Write-Host "Cancelled queued run $($existing.run_id) — creating fresh run."
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true; force=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
} elseif ($existing -and $existing.state -eq "running") {
    # Already being processed by the worker — attach and monitor, do NOT cancel
    $RUN_ID = $existing.run_id
    Write-Host "Run already in progress: $RUN_ID — attaching to monitor."
} else {
    # No active run — create a fresh one
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true; force=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
}
```

**Step 2 — Monitor and display elapsed time**
```powershell
do {
    Start-Sleep -Seconds 15
    # API wraps response in a "run" envelope — unwrap before accessing fields
    $run     = (Invoke-RestMethod "$BASE/pipeline-runs/$RUN_ID" -Headers $HDR).run
    $elapsed = if ($run.started_at) {
        $s = [datetime]::Parse($run.started_at)
        $e = if ($run.finished_at) { [datetime]::Parse($run.finished_at) } else { Get-Date }
        "$([int]($e - $s).TotalSeconds)s"
    } else { "queued" }
    $files = if ($run.files_written) { $run.files_written.Count } else { 0 }
    Write-Host "  [$elapsed]  state=$($run.state)  files=$files"
} while ($run.state -notin @("waiting_for_approval","completed","failed","cancelled"))
```

**Step 3 — Final timing summary**
```powershell
$fmt = { param($t) if ($t) { [datetime]::Parse($t).ToLocalTime().ToString("HH:mm:ss") } else { "—" } }
$sec = if ($run.started_at -and $run.finished_at) {
    [int]([datetime]::Parse($run.finished_at) - [datetime]::Parse($run.started_at)).TotalSeconds
} else { 0 }
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
Write-Host "  Run     : $RUN_ID"
Write-Host "  Stage   : $STAGE"
Write-Host "  State   : $($run.state)"
Write-Host "  Queued  : $(& $fmt $run.queued_at)"
Write-Host "  Started : $(& $fmt $run.started_at)"
Write-Host "  Finished: $(& $fmt $run.finished_at)"
Write-Host "  Elapsed : ${sec}s"
Write-Host "  Files   : $($run.files_written.Count) written"
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
```

**Step 4 — Generation Summary**
```powershell
# Categorise files_written by Angular / Axis layer
$files = $run.files_written
$groups = [ordered]@{
    "Components (TS)"    = @($files | Where-Object { $_ -like "*.component.ts" })
    "Templates (HTML)"   = @($files | Where-Object { $_ -like "*.component.html" })
    "Styles (SCSS)"      = @($files | Where-Object { $_ -like "*.component.scss" -or ($_ -like "*.scss" -and $_ -notlike "*.component.scss") })
    "Services"           = @($files | Where-Object { $_ -like "*.service.ts" })
    "Models / Interfaces"= @($files | Where-Object { $_ -like "*.model.ts" -or $_ -like "*.interface.ts" })
    "Modules"            = @($files | Where-Object { $_ -like "*.module.ts" })
    "Routing"            = @($files | Where-Object { $_ -like "*routing*" -or $_ -like "*routes*" })
    "AUG Config (JSON)"  = @($files | Where-Object { $_ -like "*.aug.json" })
    "Tests (Spec)"       = @($files | Where-Object { $_ -like "*.spec.ts" })
    "Other"              = @($files | Where-Object {
        $_ -notlike "*.component.*" -and $_ -notlike "*.service.ts" -and
        $_ -notlike "*.model.ts"    -and $_ -notlike "*.interface.ts" -and
        $_ -notlike "*.module.ts"   -and $_ -notlike "*routing*" -and
        $_ -notlike "*routes*"      -and $_ -notlike "*.aug.json" -and
        $_ -notlike "*.spec.ts"
    })
}
Write-Host ""
Write-Host "┌──────────────────────────────────────────────────────────────────┐"
Write-Host "│              GENERATION SUMMARY — ui-code (M2)                   │"
Write-Host "├──────────────────────────────┬─────────┬────────────────────────┤"
Write-Host "│ Category                     │  Count  │ Sample files           │"
Write-Host "├──────────────────────────────┼─────────┼────────────────────────┤"
foreach ($key in $groups.Keys) {
    $items = $groups[$key]
    if ($items.Count -gt 0) {
        $sample = ($items | ForEach-Object { [System.IO.Path]::GetFileName($_) } | Select-Object -First 2) -join ", "
        if ($sample.Length -gt 24) { $sample = $sample.Substring(0,21) + "..." }
        Write-Host ("│ {0,-28} │ {1,7} │ {2,-22} │" -f $key, $items.Count, $sample)
    }
}
Write-Host "├──────────────────────────────┼─────────┼────────────────────────┤"
Write-Host ("│ {0,-28} │ {1,7} │ {2,-22} │" -f "TOTAL", $files.Count, "")
Write-Host "└──────────────────────────────┴─────────┴────────────────────────┘"
$wsPath = Join-Path (Split-Path $cfgPath) "workspaces\$WS\ui-code"
Write-Host ""
Write-Host "  Output path : $wsPath"
```

**Step 4.5 — Post-generation SUMMARY.md existence check (MANDATORY)**

```powershell
# SUMMARY.md is a mandatory output — verify it was written
$summaryFile = $files | Where-Object { $_ -like "*/SUMMARY.md" -or $_ -like "*\SUMMARY.md" }
if ($summaryFile) {
    Write-Host ""
    Write-Host "  ✓ SUMMARY.md written: $($summaryFile | Select-Object -First 1)"
} else {
    Write-Host ""
    Write-Host "  ⛔ SUMMARY.md was NOT written by the generator."
    Write-Host "    SUMMARY.md is a mandatory output of the ui-code stage."
    Write-Host "    Its absence causes UNVERIFIABLE screen classifications in"
    Write-Host "    integration-validator (Figma Coverage Check — Step 1.5)."
    Write-Host ""
    Write-Host "    Expected location: workspaces\$WS\ui-code\SUMMARY.md"
    Write-Host "    Action required  : Re-run the ui-code stage. If the problem"
    Write-Host "                       persists, check the sub-agent logs for the"
    Write-Host "                       reason SUMMARY.md was skipped."
}
```

> ⛔ **Do NOT approve this run while SUMMARY.md is missing.** Approving without it
> means integration-validator cannot confirm Figma screen coverage for this epic —
> every screen will be classified UNVERIFIABLE and the pipeline will WARN instead of PASS.

**Step 5 — Review in ECS UI**
```
https://poc-ecs-build-ui.npsdlchgapp.us-east-1.aws.aig.net/aidlc-platform-management/pipeline
```

Approval persona: **Developer**
