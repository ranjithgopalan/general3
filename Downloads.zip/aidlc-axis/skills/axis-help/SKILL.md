---
name: axis-help
description: Comprehensive plugin help, skill reference, agent hierarchy, and component documentation index. Auto-invokes for help and documentation requests about AIDLC-axis plugin.
---

# AIDLC-axis Plugin Help

Comprehensive help and reference documentation for the AIDLC-axis plugin - Angular UI generation using Axis framework (v18.0.32).

## Auto-Invocation Triggers

This skill automatically activates when detecting help and documentation requests:

**Trigger keywords:**
- help, documentation, docs, guide
- how to use, how do I, how can I
- what skills, what commands, what can
- plugin info, plugin help, show me
- component list, available components

**Example requests:**
- "Help me use the AIDLC-axis plugin"
- "What skills are available in AIDLC-axis?"
- "Show me the Axis component list"
- "How do I generate a form?"
- "What agents does this plugin have?"

---

## Plugin Overview

**AIDLC-axis** is a comprehensive Claude Code plugin for Angular UI development using the Axis framework (v18.0.32).

### Key Capabilities
- **UI Generation**: Static and dynamic Angular UI from natural language, mockups, or LLD specs
- **Code Validation**: Validate code against Axis conventions and Angular best practices
- **Test Generation**: Comprehensive Jasmine unit tests with >80% coverage
- **Codebase Exploration**: Understand existing Angular/Axis code
- **Component Documentation**: Complete API reference for 78 Axis components

### Version Information
- **Plugin Version**: 2.0.0 (Skills-based architecture)
- **Axis Framework**: v18.0.32
- **Angular**: 18.x (standalone components)

---

## Skills (6 Total)

The plugin provides 6 auto-invoking skills:

### 1. axis-implement
**Purpose**: Generate, modify, or fix Angular UI code

**Triggers**: generate, create, build, implement, modify, update, change, fix

**Examples**:
- "Create a login form with username and password"
- "Generate a dashboard from ./output/UI-LLD.md"
- "Build a user profile page with tabs"

**Routes to**: axis-ui-generator (static), dynamic-ui-generator (DynamoDB), or axis-router (ambiguous)

---

### 2. axis-explore
**Purpose**: Explore and understand existing Angular/Axis codebase

**Triggers**: find, explain, compare, show, how does, what is, where is, understand

**Examples**:
- "How does authentication work in this codebase?"
- "Find all components using axis-datagrid"
- "Explain the validation pattern used here"

**Routes to**: axis-router for coordinated exploration

---

### 3. axis-validate
**Purpose**: Validate code against Axis conventions and standards

**Triggers**: validate, check, review, verify, audit, compliance, quality

**Examples**:
- "Validate my login component at src/app/login/login.component.ts"
- "Check code quality for src/app/forms/"
- "Review the dashboard for Axis compliance"

**Routes to**: axis-code-validator

---

### 4. axis-test
**Purpose**: Generate unit tests with flexible approach

**Triggers**: test, spec, unit test, generate test, coverage

**Examples**:
- "Generate tests for src/app/login/login.component.ts"
- "Create unit tests for my user profile component"

**Routes to**: axis-router → axis-test-generator

---

### 5. axis-jasmine-test
**Purpose**: Generate comprehensive Jasmine tests with >80% coverage

**Triggers**: jasmine test, comprehensive test, detailed test, full coverage

**Examples**:
- "Generate comprehensive Jasmine tests for src/app/login/login.component.ts"
- "Create detailed test suite with >80% coverage"

**Routes to**: axis-test-generator (direct)

---

### 6. axis-help (This Skill)
**Purpose**: Plugin help and documentation

**Triggers**: help, documentation, how to use, what skills, plugin info

**Examples**:
- "Help me use the AIDLC-axis plugin"
- "What skills are available?"

---

## Agents (7 Total)

The plugin coordinates 7 specialized agents:

| Agent | Purpose | Permission | Used By |
|-------|---------|------------|---------|
| **axis-router** | Exploration, planning, coordination | default | axis-implement, axis-explore, axis-test |
| **axis-ui-generator** | Static Angular UI generation | default | axis-implement |
| **dynamic-ui-generator** | DynamoDB-driven dynamic UI | default | axis-implement |
| **axis-code-validator** | Code validation & compliance | plan | axis-validate |
| **axis-test-generator** | Jasmine unit test generation | default | axis-test, axis-jasmine-test |
| **axis-documentation** | Component API reference | plan | All skills (as needed) |
| **axis-development-guide** | Conventions & patterns | plan | All skills (as needed) |

---

## Agent Hierarchy

```
┌─────────────────────────────────────────────────────────────┐
│                     User Request                             │
│              (Natural Language Prompt)                       │
└─────────────────────┬───────────────────────────────────────┘
                      │
        ┌─────────────┼─────────────┬──────────────┬─────────┐
        ▼             ▼             ▼              ▼         ▼
┌──────────────┐ ┌──────────┐ ┌──────────┐ ┌─────────┐ ┌────────┐
│axis-implement│ │  axis-   │ │  axis-   │ │ axis-   │ │ axis-  │
│              │ │ explore  │ │ validate │ │  test   │ │  help  │
│(UI Gen)      │ │(Explore) │ │(Validate)│ │ (Test)  │ │ (Help) │
└──────┬───────┘ └────┬─────┘ └────┬─────┘ └────┬────┘ └────────┘
       │              │             │            │
       ▼              ▼             ▼            ▼
┌─────────────────────────────────────────────────────────────┐
│                     axis-router                              │
│              (Planning & Coordination)                       │
└─────────────────────┬───────────────────────────────────────┘
                      │
      ┌───────────────┼───────────────┬────────────┐
      ▼               ▼               ▼            ▼
┌──────────┐  ┌─────────────┐  ┌──────────┐  ┌──────────┐
│  axis-   │  │  dynamic-   │  │  axis-   │  │  axis-   │
│    ui-   │  │     ui-     │  │   code-  │  │   test-  │
│generator │  │ generator   │  │validator │  │generator │
│(Static)  │  │(DynamoDB)   │  │          │  │          │
└──────────┘  └─────────────┘  └──────────┘  └──────────┘
```

---

## Component Documentation (axis-docs skill)

The plugin includes comprehensive documentation for **78 Axis UI components** (v18.0.32).

### Component Categories

| Category | Count | Components |
|----------|-------|------------|
| **Form Controls** | 14 | button, checkbox, radio, input, dropdown, datepicker, timepicker, slider, file-upload, editor, rating, captcha, duallist, chip |
| **Layout** | 7 | accordion, card, tab, modal, bottom-sheet, carousel, scroll-container |
| **Navigation** | 6 | navbar, breadcrumb, paginator, portal-menu, progress-step, progress-tracker |
| **Charts** | 10 | donut-chart, gauge-chart, funnel-chart, bubble-chart, horizontal-bar-chart, multi-bar-grouped-chart, area-plus-line-chart, bar-plus-multi-line-chart, d3-charts, word-cloud-chart |
| **Data Display** | 6 | datagrid, list, styled-list, tree, calendar, datamaps |
| **Feedback** | 7 | alert, loading, notifications, tooltip, tour, simple-feedback, count |
| **Advanced** | 7 | aug (axis-ui-generator), search-account, search-address, screen-capture, bodymap, date-range-picker, idle-timer |
| **Utilities** | 6 | customvalidators, helper-functions, cache-service, logger, json-translator, truncate |

### Accessing Component Documentation

To view specific component documentation:
```
"Show me the API for axis-datagrid"
"How do I use axis-dropdown with search?"
"What are the properties of axis-datepicker?"
```

The **axis-docs** skill provides:
- Component API (inputs, outputs, methods)
- AUG JSON structure for dynamic forms
- Usage examples (TypeScript + HTML)
- Common patterns and best practices

---

## Common Workflows

### 1. Generate UI from Description
```
"Create a user registration form with:
- Name, email, password fields
- Date of birth picker
- Country dropdown
- Submit and cancel buttons"
```

**Flow**: axis-implement → axis-router → axis-ui-generator → Generated code

---

### 2. Generate UI from LLD
```
"Generate the form from ./output/client-info-UI-LLD.md"
```

**Flow**: axis-implement → axis-router (reads LLD) → dynamic-ui-generator or axis-ui-generator → Generated code

---

### 3. Validate Generated Code
```
"Validate the login component at src/app/login/login.component.ts"
```

**Flow**: axis-validate → axis-code-validator → Validation report

---

### 4. Generate Tests
```
"Generate comprehensive Jasmine tests for src/app/login/login.component.ts"
```

**Flow**: axis-jasmine-test → axis-test-generator → .spec.ts file

---

### 5. Explore Codebase
```
"How does authentication work in this codebase?"
```

**Flow**: axis-explore → axis-router → GLOB/GREP/READ → Explanation

---

### 6. Multi-Step Workflow
```
"Generate a contact form and validate it"
```

**Flow**: axis-implement → axis-ui-generator → Generated code → axis-validate → axis-code-validator → Validation report

---

## Axis Framework Conventions

Generated code follows these mandatory conventions:

### 1. Standalone Components
```typescript
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [AxisSharedModule, CommonModule],
  templateUrl: './login.component.html'
})
```

### 2. AxisSharedModule Import
```typescript
import { AxisSharedModule } from 'axis-shared';
```

### 3. No External UI Libraries
❌ NO Bootstrap, NO Material, NO native HTML form elements

✅ Use ONLY Axis components

### 4. Reactive Forms
```typescript
import { FormGroup, FormControl, Validators } from '@angular/forms';

this.loginForm = new FormGroup({
  username: new FormControl('', [Validators.required]),
  password: new FormControl('', [Validators.required, Validators.minLength(8)])
});
```

### 5. TypeScript Strict Mode
```typescript
interface UserModel {
  id: number;
  name: string;
  email: string;
}
```

### 6. Accessibility
```html
<axis-input
  [label]="'Username'"
  aria-label="Enter your username"
  [(ngModel)]="username"
></axis-input>
```

---

## Troubleshooting

### Issue: Wrong skill invoked
**Solution**: Be more specific in your request
- Instead of: "Create something"
- Use: "Create a login form with username and password fields"

### Issue: Static instead of dynamic UI generated
**Solution**: Explicitly mention POM or DynamoDB:
- "Create a dynamic form with POM mapping"
- "Generate UI that fetches structure from DynamoDB"

### Issue: Validation not catching issues
**Solution**: Ensure you specify the file path:
- "Validate src/app/login/login.component.ts"
- Not just: "Validate my code"

### Issue: Tests not comprehensive enough
**Solution**: Use axis-jasmine-test instead of axis-test:
- "Generate comprehensive Jasmine tests with >80% coverage"

---

## Guardrails & Safety

All skills and agents follow these guardrails:

### Blocked Content
- Harmful or malicious code
- Security vulnerabilities
- Hardcoded secrets or credentials
- Rule circumvention attempts

### Best Practices
- **Admit Uncertainty**: "UNCERTAIN: Missing [X]. Required: [Y]."
- **Data Privacy**: Use placeholders like `{USER_EMAIL}`, `{API_KEY}`
- **Bias Awareness**: Inclusive language, diverse examples
- **Output Consistency**: End with validation checklist

---

## Migration from v1.x (Commands)

If you used the previous command-based version:

### Old Way (v1.x - Commands)
```
/AIDLC-axis:implement Create a form
/AIDLC-axis:validate src/app/component.ts
/AIDLC-axis:test src/app/component.ts
```

### New Way (v2.x - Skills)
```
Create a form with email and password fields
Validate the component at src/app/component.ts
Generate tests for src/app/component.ts
```

**Benefits**:
- More natural language interaction
- Skills auto-invoke based on context
- No need to remember command syntax
- Better discoverability

---

## Getting Help

For more information:
- View component documentation: "Show me axis-datagrid API"
- Check conventions: "What are the Axis coding conventions?"
- See examples: "Show me examples of form validation"
- Explore codebase: "How is authentication implemented here?"

---

## Related Documentation

### Skills
- `axis-docs` - Component API reference for all 78 Axis components
- `axis-types` - TypeScript type definitions
- `generation-patterns` - Implementation patterns and examples

### External Resources
- Axis Framework Documentation (v18.0.32)
- Angular Documentation (v18.x)
- TypeScript Documentation

---

## Version History

### v2.0.0 (Current)
- **BREAKING**: Removed commands, migrated to skills-only architecture
- Natural language invocation
- Auto-invoking skills based on context
- Improved discoverability

### v1.x
- Command-based architecture
- Explicit slash commands required
- Manual command invocation
