---
name: axis-explore
description: Explore and understand existing Angular/Axis codebase. Auto-invokes for questions about code structure, components, patterns, and implementation details.
---

# Axis Codebase Exploration

Auto-invoked skill for exploring and understanding Angular/Axis codebases. Helps locate components, explain patterns, and discover how things work.

## Auto-Invocation Triggers

This skill automatically activates when detecting exploration and understanding requests:

**Trigger keywords:**
- find, locate, search, where is
- explain, understand, how does, what is
- compare, difference, similarities
- show, display, list, document
- explore, discover, investigate

**Example requests:**
- "How does authentication work in this codebase?"
- "Find all components using axis-datagrid"
- "What is the structure of the user module?"
- "Explain the validation pattern used here"
- "Show me examples of form handling"
- "Where is the API service defined?"

---

## Question Type Analysis

The skill categorizes exploration requests into four types:

### 1. Find Questions
**Intent**: Locate specific files, components, services, or patterns

**Strategy**:
- GLOB for file patterns (`**/*.component.ts`)
- GREP for code patterns (class names, selectors, imports)
- Search across directory structures

**Example**: "Find all components in the auth module"

### 2. Explain Questions
**Intent**: Understand how something works or is implemented

**Strategy**:
- READ relevant files
- Analyze code structure and flow
- Cross-reference with Axis conventions
- Provide detailed explanations with code examples

**Example**: "How does the login flow work?"

### 3. Compare Questions
**Intent**: Understand differences between implementations or approaches

**Strategy**:
- READ multiple files for comparison
- Identify similarities and differences
- Explain trade-offs and design choices

**Example**: "What's the difference between axis-dropdown and axis-dropdown-multiselect?"

### 4. Document Questions
**Intent**: Get API reference, component documentation, or usage examples

**Strategy**:
- Reference `axis-docs` skill for component APIs
- Reference `axis-types` skill for TypeScript definitions
- Show examples from the codebase

**Example**: "Show me the API for axis-datepicker"

---

## Search Strategies

### File Pattern Search
Use GLOB when looking for files by pattern:
- Components: `**/*{name}*.component.ts`
- Services: `**/*{name}*.service.ts`
- Models: `**/*.model.ts`
- Tests: `**/*.spec.ts`

### Code Pattern Search
Use GREP when looking for code elements:
- Component selectors: `selector: 'app-{name}'`
- Class names: `class {ClassName}`
- Imports: `import.*from.*{package}`
- Methods: `{methodName}\(`
- Properties: `{propertyName}:`

### Content Analysis
Use READ when analyzing implementation details:
- Component logic and lifecycle
- Service implementations
- Form validation patterns
- Event handling
- State management

---

## Agent Delegation

Routes exploration requests through **axis-router** for coordinated analysis:

```
Task(subagent_type="AIDLC-axis:axis-router", prompt="""
## User Request
[user's exploration question]

## Intent: EXPLORE (Understand Codebase)

### 1. Analyze Question Type
Determine what user wants to know:
- **Find**: Locate specific components, services, patterns
- **Explain**: Understand how something works
- **Compare**: Differences between implementations
- **Document**: Get API reference for Axis components

### 2. Search Strategy
Based on question:
- GLOB for file patterns
- GREP for code patterns
- READ relevant files
- Cross-reference with Axis documentation

### 3. For Component Questions
- axis-documentation → Get Axis component API reference
- Read actual usage in codebase

### 4. For Pattern Questions
- axis-development-guide → Get conventions and best practices
- Find examples in existing code

### 5. Provide Clear Answer
- Direct answer to the question
- Code examples if relevant
- Links to related files (with file:line references)
- Suggestions for next steps
""")
```

---

## Integration with Other Skills

### axis-docs Skill
For Axis component documentation:
- Component APIs (inputs, outputs, methods)
- AUG JSON structure
- Usage examples
- Common patterns

The exploration skill automatically references axis-docs when questions involve:
- Axis component properties
- Component usage examples
- API documentation

### axis-types Skill
For TypeScript type definitions:
- Interface definitions
- Type aliases
- Enums and constants
- Generic type parameters

### axis-development-guide Agent
For framework conventions and patterns:
- Coding standards
- Architectural patterns
- Best practices
- Common pitfalls

---

## Output Format

Exploration results should include:

### Direct Answer
Clear, concise answer to the specific question

### Code Examples
Relevant code snippets with context and explanations

### File References
Links to files using `file:line` format for easy navigation:
- `src/app/auth/login.component.ts:42`
- `src/app/services/api.service.ts:15`

### Related Information
- Related components or services
- Documentation links
- Suggestions for further exploration

### Next Steps
Actionable suggestions based on the exploration findings

---

## Common Use Cases

### Component Location
**Request**: "Where is the user profile component?"

**Response**:
- File path with line numbers
- Component selector and structure
- Related services and models

### Pattern Understanding
**Request**: "How are forms validated in this app?"

**Response**:
- Validation pattern explanation
- Code examples from the codebase
- Reference to Axis validation conventions

### API Documentation
**Request**: "What are the properties of axis-datagrid?"

**Response**:
- Reference to axis-docs skill for full API
- Examples from the codebase
- Common usage patterns

### Architecture Overview
**Request**: "What's the structure of the feature modules?"

**Response**:
- Directory structure
- Module organization pattern
- Key components and services

---

## Best Practices

### Comprehensive Search
- Use multiple search strategies (GLOB + GREP + READ)
- Search across the entire codebase, not just obvious locations
- Include tests and documentation in search

### Contextual Explanations
- Explain not just what, but why
- Reference Axis conventions where applicable
- Show how code fits into the larger architecture

### Code Examples
- Include real examples from the codebase
- Show both simple and complex usage
- Highlight important patterns and conventions

### File Navigation
- Always provide file paths with line numbers
- Link to related files and dependencies
- Help users navigate to relevant code quickly

---

## Related Skills & Agents

**Skills:**
- `axis-docs` - Component API reference
- `axis-types` - TypeScript type definitions
- `generation-patterns` - Implementation examples

**Agents:**
- `axis-router` - Coordinates exploration workflow
- `axis-documentation` - Component documentation lookup
- `axis-development-guide` - Framework conventions
