---
name: axis-validate
description: Validate Angular/Axis code against framework conventions and standards. Auto-invokes for code validation, compliance checks, and quality audits.
---

# Axis Code Validation

Auto-invoked skill for validating Angular/Axis code against framework conventions, best practices, and project standards.

## Auto-Invocation Triggers

This skill automatically activates when detecting validation and quality check requests:

**Trigger keywords:**
- validate, check, review, verify, audit
- compliance, quality, violations, issues
- inspect, analyze, assess, evaluate
- standards, conventions, best practices

**Example requests:**
- "Validate my login component at src/app/login/login.component.ts"
- "Check code quality for src/app/forms/"
- "Review the dashboard for Axis compliance"
- "Verify accessibility standards in my components"
- "Audit the user module for violations"

---

## Validation Scope

The skill validates code against multiple rule sets:

### 1. Axis Framework Conventions
- **Component Usage**: Correct imports, properties, and patterns
- **CSS Classes**: Axis CSS only (NO Bootstrap, NO Material)
- **AxisSharedModule**: Proper module imports
- **Component APIs**: Correct usage of inputs, outputs, and methods

### 2. Angular 18 Best Practices
- **Standalone Components**: Modern Angular patterns
- **Signals**: Reactive state management
- **Dependency Injection**: Proper service injection
- **Lifecycle Hooks**: Correct hook usage and cleanup

### 3. Accessibility Requirements
- **ARIA Labels**: Proper accessibility attributes
- **Semantic HTML**: Meaningful element structure
- **Keyboard Navigation**: Tab order and keyboard support
- **Screen Reader Support**: Compatible markup and labels

### 4. Project-Specific Patterns
- **Coding Standards**: Project-specific conventions
- **Naming Conventions**: Consistent file and class naming
- **Architecture Patterns**: Module organization and structure

---

## Validation Process

### Step 1: Identify Target Code
- If file path provided, validate that specific file
- If directory path provided, validate all files in directory
- If no path provided, ask user what to validate

### Step 2: Load Validation Rules
- **axis-development-guide**: Axis framework conventions and patterns
- **master-tdd.md**: Project-specific technical requirements
- **Angular Style Guide**: Official Angular best practices
- **WCAG Guidelines**: Accessibility standards

### Step 3: Perform Validation Checks

**Component Structure:**
- Standalone component configuration
- Proper imports (AxisSharedModule, CommonModule)
- Component metadata (selector, template, styles)

**Axis Component Usage:**
- Correct component names and selectors
- Valid property bindings
- Proper event handling
- Required vs optional properties

**Styling:**
- No Bootstrap classes (col-*, row, container, etc.)
- No Material classes (mat-*)
- No native HTML form elements (use Axis equivalents)
- Proper use of Axis CSS utilities

**Forms:**
- Reactive forms with FormGroup/FormControl
- Proper validation patterns
- Error message handling
- Accessibility for form fields

**Code Quality:**
- TypeScript strict mode compliance
- No unused imports or variables
- Proper error handling
- Async operations handled correctly

**Sonar Code Quality Thresholds:**
- **Cognitive complexity ≤ 15 per function/method** — nested `if`/`for`/`switch`/`try` blocks
  and chained `&&`/`||` conditions each add up. Fix by extracting guard clauses (early
  `return` instead of nesting), pulling nested loops/branches into a named private method,
  and de-duplicating a condition repeated across branches into one helper.
- **≤ 7 parameters per function/method** — a function needing an 8th parameter should
  instead take a single options object/interface that groups the related values.
- **No empty `catch` block** — every caught error is logged or rethrown with context, never
  silently swallowed.
- **No unused imports.**
- **No magic numbers in business logic** — extract to a named `const`.
- **Test coverage > 65% minimum, 80%+ target** for new/changed component and service logic
  (see `axis-test` / `axis-jasmine-test` for how coverage is measured and reported).

If `eslint-plugin-sonarjs` is configured in the project (check `.eslintrc*` for
`sonarjs/cognitive-complexity` or `sonarjs/no-*` rules), run `ng lint` / `eslint` and treat
its findings as authoritative. If not configured, estimate complexity manually by counting
branch/loop/logical-operator occurrences per function via Grep, and count parameters per
function signature.

### Step 4: Report Findings

For each issue found, report:
- **File and Line Number**: Exact location of the issue
- **Rule Violated**: Which convention or standard
- **Severity**: Error, warning, or info
- **Description**: Clear explanation of the problem
- **Suggested Fix**: Specific corrective action

---

## Agent Delegation

Routes validation requests to **axis-code-validator** agent:

```
Task(subagent_type="AIDLC-axis:axis-code-validator", prompt="""
## User Request
[user's validation request]

## Intent: VALIDATE

### 1. Identify Target Code
- If path provided, validate that specific file/folder
- If no path, ask user what to validate

### 2. Load Validation Rules
- Read Axis framework conventions from axis-development-guide
- Check for project-specific rules in master-tdd.md (if exists)
- Apply Angular 18 best practices
- Check WCAG accessibility guidelines

### 3. Perform Validation
Check against:
- Axis component usage (correct imports, properties, patterns)
- Angular conventions (signals, standalone components, etc.)
- CSS classes (Axis CSS only, no Bootstrap/Material)
- Accessibility requirements (ARIA, semantic HTML)
- TypeScript best practices
- Form validation patterns
- Project-specific patterns
- Sonar code quality thresholds: cognitive complexity ≤ 15, ≤ 7 parameters per
  function/method, no empty catch blocks, no unused imports, no magic numbers,
  coverage > 65% (80%+ target)

### 4. Report Findings
For each issue found:
- File and line number (e.g., src/app/login.component.ts:42)
- Rule violated
- Severity (error/warning/info)
- Clear description of the problem
- Suggested fix with code example

### 5. Summary
- Total issues by severity
- Overall compliance score (if applicable)
- Priority fixes (most critical issues first)
- Compliance status (pass/fail)
""")
```

---

## Severity Levels

### Error (❌)
**Critical issues that must be fixed**
- Using non-Axis components (Bootstrap, Material, native HTML)
- Missing required properties
- Incorrect API usage that will cause runtime errors
- Security vulnerabilities

### Warning (⚠️)
**Issues that should be addressed**
- Accessibility improvements needed
- Deprecated patterns or APIs
- Code quality issues
- Performance concerns

### Info (ℹ️)
**Suggestions for improvement**
- Style guide recommendations
- Optimization opportunities
- Alternative patterns to consider

---

## Validation Report Format

```markdown
## Validation Report

**Target**: src/app/login/login.component.ts
**Rules**: Axis Framework + Angular 18 + Accessibility

### Issues Found

#### ❌ Error: Non-Axis Component Used
**Location**: src/app/login/login.component.ts:25
**Rule**: Axis component requirement
**Description**: Using native HTML <input> instead of axis-input
**Fix**: Replace with <axis-input [(ngModel)]="username" placeholder="Username"></axis-input>

#### ⚠️ Warning: Missing ARIA Label
**Location**: src/app/login/login.component.html:12
**Rule**: WCAG 2.1 - Accessibility
**Description**: Button missing aria-label for screen readers
**Fix**: Add aria-label="Submit login form" to axis-button

### Summary
- Errors: 1
- Warnings: 1
- Info: 0
- Total: 2

**Compliance**: ❌ FAIL (errors must be resolved)
**Priority Fixes**:
1. Replace native HTML input with axis-input
2. Add ARIA labels to interactive elements
```

---

## Common Validation Checks

### Axis Component Detection
```typescript
// ❌ ERROR: Native HTML form elements
<input type="text" />
<select><option></option></select>
<button>Click</button>

// ✅ CORRECT: Axis components
<axis-input [(ngModel)]="value"></axis-input>
<axis-dropdown [dataProvider]="options"></axis-dropdown>
<axis-button (onClick)="handleClick()">Click</axis-button>
```

### CSS Framework Detection
```html
<!-- ❌ ERROR: Bootstrap classes -->
<div class="container">
  <div class="row">
    <div class="col-md-6">

<!-- ❌ ERROR: Material classes -->
<div class="mat-card">
  <button class="mat-button">

<!-- ✅ CORRECT: Axis CSS or custom classes -->
<div class="custom-container">
  <div class="flex-row">
    <div class="column">
```

### Import Validation
```typescript
// ❌ ERROR: Missing AxisSharedModule
import { CommonModule } from '@angular/common';

// ✅ CORRECT: AxisSharedModule imported
import { AxisSharedModule } from 'axis-shared';
imports: [AxisSharedModule, CommonModule]
```

---

## Integration with Other Workflows

### Validation → Fix → Re-validate
1. Run validation to identify issues
2. Use axis-implement skill to fix issues
3. Re-run validation to confirm fixes

### Generate → Validate
1. Use axis-implement to generate code
2. Automatically validate generated code
3. Report any issues found

### Validate Against Spec
1. Validate code implementation
2. Compare against UI-TDD or LLD specification
3. Identify functional gaps or deviations

---

## Related Skills & Agents

**Skills:**
- `axis-implement` - Fix validation issues by regenerating code
- `axis-docs` - Component API reference for correct usage
- `generation-patterns` - Examples of correct implementation patterns

**Agents:**
- `axis-code-validator` - Performs the actual validation
- `axis-development-guide` - Provides framework conventions
- `axis-ui-generator` - Can fix issues by regenerating code

---

## Best Practices

### Run Validation Frequently
- Before code reviews
- After generating new code
- When refactoring existing code
- Before committing changes

### Address Errors First
- Fix all errors before warnings
- Errors indicate functional or framework compliance issues
- Warnings improve code quality and maintainability

### Use Validation for Learning
- Understand why certain patterns are required
- Learn Axis framework conventions
- Improve code quality over time

### Automate Validation
- Integrate into CI/CD pipeline
- Run as pre-commit hook
- Include in code review checklist
