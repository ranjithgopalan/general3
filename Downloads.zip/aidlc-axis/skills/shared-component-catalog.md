# Shared Component Catalog

This document catalogs common shared components typically found in Angular Axis applications. Use this as a reference when deciding whether to reuse existing components or generate new ones.

## Discovery Process

### 1. Check Feature TDD Section 6.4.2
Feature TDD documents often specify shared components in Section 6.4.2. Look for:
- Import statements referencing `@app/_shared/`
- References to `common-modal`, `common-grid`, or other shared components
- Service references like `CommonModalService`, `GridService`

### 2. Search _shared Folder
```bash
# Search for shared components
find src/app/_shared/components -name "*.component.ts"

# Search for shared services
find src/app/_shared/services -name "*.service.ts"

# Search for common- prefixed components
grep -r "export class Common" src/app/_shared/
```

### 3. Common Patterns
Shared components typically follow these naming conventions:
- `common-*` - Reusable UI components
- `shared-*` - Shared utilities and helpers
- Located in `src/app/_shared/` folder

---

## Common Shared Components

### UI Components

#### common-modal
**Purpose:** Modal dialog management with consistent styling and behavior

**Location:** `_shared/components/common-modal/`

**Service:** `_shared/services/common-modal.service.ts`

**Usage:**
```typescript
import { CommonModalService } from '@app/_shared/services/common-modal.service';

constructor(private commonModalService: CommonModalService) {}

openModal() {
  this.commonModalService.open({
    title: 'Modal Title',
    component: MyContentComponent,
    data: { /* data to pass */ },
    size: 'large' // small, medium, large
  });
}
```

**When to use:**
- Search modals (e.g., client search, policy search)
- Confirmation dialogs
- Detail views in modal form
- Any popup requiring consistent styling

---

#### common-grid
**Purpose:** Data grid with search, pagination, filtering, and sorting

**Location:** `_shared/components/common-grid/`

**Service:** `_shared/services/grid.service.ts`

**Usage:**
```typescript
import { CommonGridComponent } from '@app/_shared/components/common-grid/common-grid.component';

// In modal or component
this.commonModalService.open({
  component: CommonGridComponent,
  data: {
    columns: [
      { field: 'clientName', header: 'Client Name', sortable: true },
      { field: 'policyNumber', header: 'Policy #', filterable: true }
    ],
    dataSource: this.clientService.searchClients.bind(this.clientService),
    searchable: true,
    pageable: true
  }
});
```

**When to use:**
- Search results display
- Data tables with complex filtering
- Master-detail grids
- Any tabular data with search/filter/sort

---

#### common-table
**Purpose:** Simple data table without advanced features

**Location:** `_shared/components/common-table/`

**Usage:**
```typescript
<common-table
  [columns]="columns"
  [data]="tableData"
  [striped]="true"
  [bordered]="true">
</common-table>
```

**When to use:**
- Simple read-only data display
- No search/filter/pagination needed
- Small datasets (< 50 rows)

---

#### common-search
**Purpose:** Search input with autocomplete and debouncing

**Location:** `_shared/components/common-search/`

**Usage:**
```typescript
<common-search
  [placeholder]="'Search clients...'"
  [minLength]="3"
  [debounceTime]="300"
  (onSearch)="handleSearch($event)"
  (onSelect)="handleSelect($event)">
</common-search>
```

**When to use:**
- Type-ahead search fields
- Autocomplete dropdowns
- Search-as-you-type functionality

---

#### common-form
**Purpose:** Reusable form components and validators

**Location:** `_shared/components/common-form/`

**Includes:**
- `common-input.component.ts` - Standardized input with validation
- `common-dropdown.component.ts` - Dropdown with search
- `common-datepicker.component.ts` - Date picker wrapper

**When to use:**
- Forms requiring consistent styling
- Complex validation requirements
- Reusable form patterns

---

### Shared Services

#### modal.service.ts
**Purpose:** Centralized modal management

**Location:** `_shared/services/modal.service.ts`

**Methods:**
- `open(config)` - Open modal with component
- `close(result?)` - Close active modal
- `confirm(message)` - Confirmation dialog

---

#### grid.service.ts
**Purpose:** Grid data management and state

**Location:** `_shared/services/grid.service.ts`

**Methods:**
- `loadData(params)` - Fetch grid data
- `applyFilters(filters)` - Apply filter criteria
- `exportToExcel(data)` - Export grid data

---

#### validation.service.ts
**Purpose:** Common validation functions

**Location:** `_shared/services/validation.service.ts`

**Validators:**
- `requiredIf(condition)` - Conditional required
- `dateRange(min, max)` - Date range validation
- `phoneNumber()` - Phone format validation
- `email()` - Email validation
- `ssn()` - SSN format validation

---

### Shared Utilities

#### date.util.ts
**Purpose:** Date formatting and manipulation

**Location:** `_shared/utils/date.util.ts`

**Functions:**
- `formatDate(date, format)` - Format dates
- `parseDate(string)` - Parse date strings
- `isValidDate(date)` - Date validation

---

#### currency.util.ts
**Purpose:** Currency formatting

**Location:** `_shared/utils/currency.util.ts`

**Functions:**
- `formatCurrency(amount)` - Format as currency
- `parseCurrency(string)` - Parse currency string

---

## Decision Tree: Reuse vs Generate

### Use Shared Components When:
✅ Functionality matches existing shared component (>80% overlap)
✅ Feature TDD Section 6.4.2 specifies shared components
✅ Consistency with other features is important
✅ Component is likely to be reused elsewhere
✅ Time-to-market is critical (reuse is faster)

### Generate New Components When:
❌ No suitable shared component exists
❌ Shared component requires major modifications (>50% change)
❌ Feature has highly specific requirements
❌ Customization would break shared component for other features
❌ User explicitly requests new components

---

## Integration Pattern

When using shared components, follow this pattern:

```typescript
// 1. Import from _shared folder
import { CommonModalService } from '@app/_shared/services/common-modal.service';
import { CommonGridComponent } from '@app/_shared/components/common-grid/common-grid.component';

@Component({
  selector: 'app-client-info',
  standalone: true,
  imports: [
    // Include shared modules if needed
    CommonModalModule,
    CommonGridModule
  ]
})
export class ClientInfoComponent {
  // 2. Inject services
  constructor(private commonModalService: CommonModalService) {}

  // 3. Use shared components
  openClientSearchModal() {
    this.commonModalService.open({
      component: CommonGridComponent,
      data: {
        title: 'Search Clients',
        columns: [
          { field: 'clientName', header: 'Client Name', sortable: true },
          { field: 'clientCode', header: 'Client Code', filterable: true },
          { field: 'status', header: 'Status', filterable: true }
        ],
        dataSource: this.clientService.searchClients.bind(this.clientService),
        searchable: true,
        pageable: true,
        selectionMode: 'single'
      }
    }).then(selectedClient => {
      if (selectedClient) {
        // Handle selected client
        this.populateClientInfo(selectedClient);
      }
    });
  }
}
```

---

## Best Practices

1. **Always Check First**: Before generating new components, search for existing shared components
2. **TDD First**: Feature TDD Section 6.4.2 is the authoritative source for shared component usage
3. **Document Usage**: When using shared components, document configuration in code comments
4. **Contribute Back**: If you enhance a shared component, update it for all features to benefit
5. **Avoid Duplication**: If you find yourself implementing common functionality, consider creating a new shared component
6. **Maintain Consistency**: Use shared components to ensure UI/UX consistency across the application
7. **Import Correctly**: Always import from `@app/_shared/` path alias, not relative paths

---

## Questions to Ask

When deciding whether to reuse or generate:

1. **Does a shared component exist for this functionality?**
   - Check Feature TDD Section 6.4.2
   - Search `_shared/components/` folder
   - Search for `common-*` components

2. **Does the shared component meet >80% of requirements?**
   - If yes → Reuse and configure
   - If no → Consider generating new or extending shared

3. **Is this functionality used elsewhere in the application?**
   - If yes → Strong candidate for shared component
   - If no → May warrant feature-specific component

4. **What does the user prefer?**
   - Ask via AskUserQuestion if unclear
   - Recommend reuse when suitable

---

## Example: Client Search Modal

**Scenario:** Feature requires client search functionality with modal and grid

**Feature TDD Section 6.4.2 shows:**
```typescript
import { CommonModalService } from '@app/_shared/services/common-modal.service';
import { CommonGridComponent } from '@app/_shared/components/common-grid/common-grid.component';

openClientSearchModal() {
  this.commonModalService.open({
    component: CommonGridComponent,
    // ... configuration
  });
}
```

**Decision:** ✅ REUSE `common-modal` and `common-grid`

**Rationale:**
- Explicitly specified in TDD Section 6.4.2
- Standard search modal pattern
- 100% functionality match
- Consistent with other features
- Faster implementation

**Generated Code:**
- Import shared components from `@app/_shared/`
- Use `CommonModalService` to open modal
- Configure `CommonGridComponent` with columns and data source
- No new modal or grid components generated
