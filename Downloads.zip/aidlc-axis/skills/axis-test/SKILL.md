---
name: axis-test
description: Generate unit tests for Angular/Axis components. Auto-invokes for test generation requests with flexible testing approach.
---

# Axis Unit Test Generation

This stage (M7 — ui-smoke) is the **sole owner of all Angular/Axis Jasmine test generation**.
The implement stage (M2 — ui-code) produces source files only and must not write
any spec files. If any `.spec.ts` stubs exist under the downloaded ui-code artifacts,
treat them as scaffolding to complete or replace — never skip them and never assume they are complete.

Auto-invoked skill for generating unit tests for Angular/Axis components with comprehensive coverage.

## Auto-Invocation Triggers

This skill automatically activates when detecting test generation requests:

**Trigger keywords:**
- test, tests, testing, unit test
- spec, spec file, test file
- coverage, test coverage
- generate test, create test, write test

**Example requests:**
- "Generate tests for src/app/login/login.component.ts"
- "Create unit tests for my user profile component"
- "Write test coverage for the dashboard"
- "Test the form validation in my component"

---

## Test Generation Approach

This skill provides **general test generation** with flexible testing frameworks (Jest/Jasmine). For Jasmine-specific comprehensive testing, use the `axis-jasmine-test` skill instead.

### Coverage Goals
- **> 65% code coverage is the Sonar gate floor — never go below it**
- **80%+ code coverage is the target** for newly generated component/service logic
- All public methods tested
- All inputs and outputs tested
- User interactions tested
- Edge cases and error handling tested

### Testing Framework Support
- **Jasmine**: Angular's default testing framework
- **Jest**: Popular alternative with better performance
- **Angular Testing Utilities**: TestBed, ComponentFixture, fakeAsync, tick

---

## Test Generation Process

> ⚡ **AIDLC Launcher mode**: If `aidlc.config.json` **exists** in the current working directory,
> skip this entire workflow and jump directly to **Reporting to the AIDLC Platform** at the
> bottom of this file. The local session's only role is to create the ECS run and monitor the
> CLI subprocess — do **not** invoke agents or generate files locally.

### Step 1: Identify Target Component
- If file path provided, generate tests for that component
- If component name provided, locate the file
- If no path provided, ask user what to test

### Step 2: Analyze Component Structure
**Read and analyze**:
- Component TypeScript file (.component.ts)
- Component template (.component.html) if exists
- Component services and dependencies
- Component inputs and outputs
- Public methods and properties
- Form controls and validation

### Step 3: Generate Test Structure

**Create spec file with**:
- Proper imports (TestBed, ComponentFixture, testing utilities)
- describe block for the component
- beforeEach block with TestBed configuration
- Mock services and dependencies
- it blocks for each test case

### Step 4: Generate Test Cases

**Component Creation**:
```typescript
it('should create', () => {
  expect(component).toBeTruthy();
});
```

**Input Testing**:
```typescript
it('should update view when input changes', () => {
  component.userName = 'John Doe';
  fixture.detectChanges();
  expect(compiled.querySelector('.user-name').textContent).toContain('John Doe');
});
```

**Output Testing**:
```typescript
it('should emit event when button clicked', () => {
  spyOn(component.onSubmit, 'emit');
  const button = fixture.nativeElement.querySelector('button');
  button.click();
  expect(component.onSubmit.emit).toHaveBeenCalled();
});
```

**Method Testing**:
```typescript
it('should validate email format', () => {
  const result = component.validateEmail('test@example.com');
  expect(result).toBe(true);
});
```

**Service Interaction Testing**:
```typescript
it('should call API service on submit', () => {
  spyOn(apiService, 'submit').and.returnValue(of({ success: true }));
  component.submit();
  expect(apiService.submit).toHaveBeenCalledWith(component.formData);
});
```

**Edge Cases**:
```typescript
it('should handle empty input', () => {
  component.userName = '';
  const result = component.validate();
  expect(result).toBe(false);
});
```

---

## Agent Delegation

Routes test generation through **axis-router** for flexible handling.

This is M7 (ui-smoke) — the exclusive test-generation stage. Do NOT delegate
back to axis-implement or any code-generation agent.

Scan the ui-code artifacts for existing `.spec.ts` stubs first. Replace or
complete any stubs found there; do not leave placeholder or empty test methods.

**MANDATORY — always rewrite every spec file using the Write tool**, even if no
changes are needed. The pipeline worker detects artifacts by file modification
timestamp; skipping the write means the file is not captured in the artifact.

**MANDATORY — after writing all spec files, write a `TEST-SUMMARY.md`** to the
stage output directory (e.g. `workspaces/{workspace_id}/ui-smoke/TEST-SUMMARY.md`).
The report must contain:

```
# UI Test Review Summary
Stage: ui-smoke   Workspace: {workspace_id}

## Overview
| Metric | Value |
|---|---|
| Spec files reviewed | N |
| Spec files updated  | N |
| New spec files added | N |
| Total test methods  | N |

## Per-File Review
### {ComponentName}.spec.ts
- Status: Updated | No changes needed
- Issues fixed: <list or None>
- Methods added: <list or None>

## Coverage Matrix
| Component | Spec file | Methods | Inputs tested | Outputs tested | Auth tested |
|---|---|---|---|---|---|
| ... | ... | N | Yes/No | Yes/No | Yes/No |

## Gaps Remaining
<Any gaps that could not be addressed, or "None">
```

```
Task(subagent_type="AIDLC-axis:axis-router", prompt="""
## User Request
[user's test generation request]

## Intent: TEST (Generate Tests)

### 1. Identify Target Component
- If path provided, generate tests for that component
- If no path, ask user what to test

### 2. Analyze Component
- Read component TypeScript file
- Identify inputs, outputs, methods
- Detect dependencies and services
- Find template bindings and events
- Check for forms and validation

### 3. Generate Test Structure
Create spec file with:
- TestBed configuration with proper imports
- Mock services and dependencies (jasmine.SpyObj)
- describe/it blocks for each method
- Test cases for:
  - Component creation
  - Input binding
  - Output emission
  - User interactions
  - Service calls with mocks
  - Edge cases and error handling

### 4. Follow Testing Patterns
- Use Angular testing utilities
- Mock HTTP calls with HttpClientTestingModule
- Test async operations properly (fakeAsync/tick)
- Aim for >80% coverage

### 5. Output
- Create .spec.ts file alongside component
- Include all necessary imports
- Add comments explaining test intent
- Report estimated coverage percentage
""")
```

---

## Test File Structure

Generated test files follow this structure:

```typescript
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from './login.component';
import { AuthService } from '../services/auth.service';
import { AxisSharedModule } from 'axis-shared';
import { of } from 'rxjs';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let authService: jasmine.SpyObj<AuthService>;

  beforeEach(async () => {
    const authServiceSpy = jasmine.createSpyObj('AuthService', ['login', 'logout']);

    await TestBed.configureTestingModule({
      imports: [LoginComponent, AxisSharedModule],
      providers: [
        { provide: AuthService, useValue: authServiceSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    authService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // Additional tests...
});
```

---

## Testing Best Practices

### Mock External Dependencies
```typescript
// Mock services
const mockService = jasmine.createSpyObj('DataService', ['getData']);
mockService.getData.and.returnValue(of({ data: 'test' }));

// Mock HTTP calls
import { HttpClientTestingModule } from '@angular/common/http/testing';
```

### Test Async Operations
```typescript
import { fakeAsync, tick } from '@angular/core/testing';

it('should handle async operation', fakeAsync(() => {
  component.loadData();
  tick(1000); // Simulate time passing
  expect(component.data).toBeDefined();
}));
```

### Test Form Validation
```typescript
it('should validate required field', () => {
  const control = component.form.get('email');
  control.setValue('');
  expect(control.valid).toBe(false);
  expect(control.errors?.['required']).toBe(true);
});
```

### Test User Interactions
```typescript
it('should respond to button click', () => {
  spyOn(component, 'handleClick');
  const button = fixture.nativeElement.querySelector('button');
  button.click();
  expect(component.handleClick).toHaveBeenCalled();
});
```

---

## Axis Component Mocking

When testing components that use Axis components:

### Mock Axis Components
```typescript
@Component({
  selector: 'axis-input',
  template: '<input />'
})
class MockAxisInputComponent {
  @Input() ngModel: any;
  @Output() ngModelChange = new EventEmitter();
}
```

### Or Use NO_ERRORS_SCHEMA
```typescript
import { NO_ERRORS_SCHEMA } from '@angular/core';

TestBed.configureTestingModule({
  schemas: [NO_ERRORS_SCHEMA] // Ignores unknown elements
});
```

### Or Import AxisSharedModule
```typescript
import { AxisSharedModule } from 'axis-shared';

TestBed.configureTestingModule({
  imports: [AxisSharedModule]
});
```

---

## Common Test Patterns

### Component Creation
```typescript
it('should create', () => {
  expect(component).toBeTruthy();
});
```

### Property Initialization
```typescript
it('should initialize with default values', () => {
  expect(component.title).toBe('Login');
  expect(component.isLoading).toBe(false);
});
```

### Input Property
```typescript
it('should accept userName input', () => {
  component.userName = 'testuser';
  fixture.detectChanges();
  expect(component.userName).toBe('testuser');
});
```

### Output Event
```typescript
it('should emit loginSuccess event', () => {
  spyOn(component.loginSuccess, 'emit');
  component.login();
  expect(component.loginSuccess.emit).toHaveBeenCalledWith({ username: 'test' });
});
```

### Method Logic
```typescript
it('should calculate total correctly', () => {
  component.items = [1, 2, 3];
  const total = component.calculateTotal();
  expect(total).toBe(6);
});
```

---

## Related Skills & Agents

**Skills:**
- `axis-jasmine-test` - Comprehensive Jasmine tests with >80% coverage (use for detailed testing)
- `axis-implement` - Generate the component being tested
- `axis-validate` - Validate test quality and coverage

**Agents:**
- `axis-router` - Routes and coordinates test generation
- `axis-test-generator` - Specialized test generation agent
- `axis-development-guide` - Testing conventions and patterns

---

## When to Use This Skill vs axis-jasmine-test

### Use axis-test (this skill) when:
- You want general test generation
- You need flexibility in testing approach
- You're using Jest or other frameworks
- You want basic coverage quickly

### Use axis-jasmine-test when:
- You need comprehensive Jasmine-specific tests
- You want >80% coverage guarantee
- You need detailed test cases for all scenarios
- You want production-ready test suites

---

## Output

After generating tests, expect:
- `.spec.ts` file created alongside component
- All necessary imports included
- TestBed configuration set up
- Mock services and dependencies
- Test cases for all public APIs
- Estimated coverage percentage
- Instructions for running tests

**Run tests with**:
```bash
ng test
# or
npm test
```

---

## Reporting to the AIDLC Platform (ECS UI tracking)

> **SERVER CLI GUARD:** If `aidlc.config.json` does **not** exist in your current
> working directory, skip this entire ECS section and run only the main workflow
> above. These steps are for the **local Claude Code session only**.

The local session creates the ECS run and monitors progress. All generation
is performed by the ECS server CLI — do **not** generate or copy files locally.

---

**Step 0 — Read config**
```powershell
# Resolve absolute path at startup so the script works regardless of working directory drift
$cfgPath = (Resolve-Path "aidlc.config.json" -ErrorAction Stop).Path
$cfg     = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
$BASE    = $cfg.central_base_url.TrimEnd('/')
$TOKEN   = [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env)
# Fall back to relay file if env var is not set
if (-not $TOKEN) {
    $relayFile = Join-Path (Split-Path $cfgPath) ".aidlc_token"
    if (Test-Path $relayFile) { $TOKEN = (Get-Content $relayFile -Raw -Encoding UTF8).Trim() }
}
$WS    = $cfg.workspace_id
$HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
$STAGE = "ui-smoke"
```

**Step 1 — Smart run management: cancel queued / attach running / create fresh**
```powershell
# Check for an existing active run for this stage
$existing = $null
try {
    $existing = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS&stage_key=$STAGE" -Headers $HDR).items |
        Where-Object { $_.state -in @("queued", "running") } |
        Sort-Object queued_at -Descending |
        Select-Object -First 1
} catch {}

if ($existing -and $existing.state -eq "queued") {
    # Queued but not started — cancel immediately and restart fresh
    Invoke-RestMethod "$BASE/pipeline-runs/$($existing.run_id)/cancel" -Headers $HDR -Method Post | Out-Null
    Write-Host "Cancelled queued run $($existing.run_id) — creating fresh run."
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true; force=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
} elseif ($existing -and $existing.state -eq "running") {
    # Already being processed by the worker — attach and monitor, do NOT cancel
    $RUN_ID = $existing.run_id
    Write-Host "Run already in progress: $RUN_ID — attaching to monitor."
} else {
    # No active run — create a fresh one
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true; force=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
}
```

**Step 2 — Monitor and display elapsed time**
```powershell
do {
    Start-Sleep -Seconds 15
    # API wraps response in a "run" envelope — unwrap before accessing fields
    $run     = (Invoke-RestMethod "$BASE/pipeline-runs/$RUN_ID" -Headers $HDR).run
    $elapsed = if ($run.started_at) {
        $s = [datetime]::Parse($run.started_at)
        $e = if ($run.finished_at) { [datetime]::Parse($run.finished_at) } else { Get-Date }
        "$([int]($e - $s).TotalSeconds)s"
    } else { "queued" }
    $files = if ($run.files_written) { $run.files_written.Count } else { 0 }
    Write-Host "  [$elapsed]  state=$($run.state)  files=$files"
} while ($run.state -notin @("waiting_for_approval","completed","failed","cancelled"))
```

**Step 3 — Final timing summary**
```powershell
$fmt = { param($t) if ($t) { [datetime]::Parse($t).ToLocalTime().ToString("HH:mm:ss") } else { "—" } }
$sec = if ($run.started_at -and $run.finished_at) {
    [int]([datetime]::Parse($run.finished_at) - [datetime]::Parse($run.started_at)).TotalSeconds
} else { 0 }
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
Write-Host "  Run     : $RUN_ID"
Write-Host "  Stage   : $STAGE"
Write-Host "  State   : $($run.state)"
Write-Host "  Queued  : $(& $fmt $run.queued_at)"
Write-Host "  Started : $(& $fmt $run.started_at)"
Write-Host "  Finished: $(& $fmt $run.finished_at)"
Write-Host "  Elapsed : ${sec}s"
Write-Host "  Files   : $($run.files_written.Count) written"
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
```

**Step 4 — Generation Summary**
```powershell
# Categorise files_written by test layer
$files = $run.files_written
$groups = [ordered]@{
    "Spec Files"         = @($files | Where-Object { $_ -like "*.spec.ts" })
    "Test Fixtures"      = @($files | Where-Object { $_ -like "*fixture*" -or $_ -like "*mock*" })
    "Test Helpers"       = @($files | Where-Object { $_ -like "*helper*" -or $_ -like "*util*test*" })
    "Summary / Reports"  = @($files | Where-Object { $_ -like "*.md" })
    "Other"              = @($files | Where-Object {
        $_ -notlike "*.spec.ts" -and $_ -notlike "*fixture*" -and
        $_ -notlike "*mock*"    -and $_ -notlike "*helper*"  -and
        $_ -notlike "*.md"
    })
}
Write-Host ""
Write-Host "┌──────────────────────────────────────────────────────────────────┐"
Write-Host "│              GENERATION SUMMARY — ui-smoke (M7)                  │"
Write-Host "├──────────────────────────────┬─────────┬────────────────────────┤"
Write-Host "│ Category                     │  Count  │ Sample files           │"
Write-Host "├──────────────────────────────┼─────────┼────────────────────────┤"
foreach ($key in $groups.Keys) {
    $items = $groups[$key]
    if ($items.Count -gt 0) {
        $sample = ($items | ForEach-Object { [System.IO.Path]::GetFileName($_) } | Select-Object -First 2) -join ", "
        if ($sample.Length -gt 24) { $sample = $sample.Substring(0,21) + "..." }
        Write-Host ("│ {0,-28} │ {1,7} │ {2,-22} │" -f $key, $items.Count, $sample)
    }
}
Write-Host "├──────────────────────────────┼─────────┼────────────────────────┤"
Write-Host ("│ {0,-28} │ {1,7} │ {2,-22} │" -f "TOTAL", $files.Count, "")
Write-Host "└──────────────────────────────┴─────────┴────────────────────────┘"
$wsPath = Join-Path (Split-Path $cfgPath) "workspaces\$WS\ui-smoke"
Write-Host ""
Write-Host "  Output path : $wsPath"
```

**Step 5 — Review in ECS UI**
```
https://poc-ecs-build-ui.npsdlchgapp.us-east-1.aws.aig.net/aidlc-platform-management/pipeline
```

Approval persona: **Tester**
