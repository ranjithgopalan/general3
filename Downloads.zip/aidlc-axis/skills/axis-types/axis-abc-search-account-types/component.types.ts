/**
 * Account search component types
 * @packageDocumentation
 */

import type { EventEmitter } from '@angular/core';
import type { FormGroup } from '@angular/forms';
import type { AccountSearchConfig, AccountData } from './account.types';

/**
 * Axis ABC Search Account component interface
 * This component provides a comprehensive account search functionality with state/province filtering
 */
export interface IAxisAbcSearchAccountComponent {
  /**
   * Configuration object for the account search component
   * Defines search parameters, API endpoints, validation rules, and display settings
   */
  config: AccountSearchConfig;

  /**
   * Event emitted when an account is selected from the search results
   * Contains the complete account data object that was selected by the user
   */
  onAccountSelect: EventEmitter<AccountData>;

  /**
   * Event emitted when the search form is reset
   * Triggers when the user initiates a new search, clearing previous results
   */
  resetOnSearch: EventEmitter<void>;

  /**
   * View-only mode flag
   * When true, the component displays account information without allowing modifications
   * Disables all input fields and action buttons
   * @default false
   */
  viewonly: boolean;

  /**
   * ARIA labelledby attribute value for accessibility
   * Should reference the ID of the element that labels this search component
   * Used by screen readers to provide context about the search functionality
   */
  ariaLabelledby: string;

  /**
   * Minimum number of characters required before triggering a search
   * Prevents excessive API calls for very short queries
   * Must be a positive integer
   * @default 3
   */
  minCharLength: number;

  /**
   * Default order-by field for sorting search results
   * Specifies which account property to use for initial sorting
   * Common values: 'accountName', 'accountNumber', 'city', 'state'
   * Can be prefixed with '-' for descending order (e.g., '-accountName')
   */
  orderbyset: string;

  /**
   * Reactive form group that manages the account search form
   * Contains form controls for account number, name, city, state/province, etc.
   * Provides validation, value tracking, and state management
   */
  searchAccountFormGroup: FormGroup;

  /**
   * Flag indicating whether the search form has been submitted
   * Set to true when search is initiated, used to display validation messages
   * and manage form state during the search lifecycle
   * @default false
   */
  searchSubmitFlag: boolean;

  /**
   * Loading state indicator for search results
   * True while the API call is in progress, false when complete or idle
   * Used to display loading spinners or disable search button
   * @default false
   */
  searchResultLoading: boolean;

  /**
   * Flag indicating whether an account has been selected from results
   * True when user has clicked on a search result item
   * Prevents duplicate selections and manages UI state
   * @default false
   */
  isAccountSelected: boolean;

  /**
   * Array of account objects returned from the search operation
   * Contains the complete list of accounts matching the search criteria
   * Each item is an AccountData object with full account details
   * null or empty array when no results found
   */
  accountList: AccountData[] | null;

  /**
   * Array of state/province options for the dropdown
   * Populated based on the selected country code
   * Each item contains code, name, and country information
   * Used to filter accounts by geographic location
   */
  stateProvinceList: StateProvinceData[] | null;

  /**
   * Initialize component and set up form controls
   * Called once when component is created
   * Sets up reactive form, loads initial data, and configures validators
   */
  ngOnInit(): void;

  /**
   * Load the list of states/provinces based on country code
   * Fetches geographic data from the service and populates the dropdown
   * @param countryCode - Optional ISO country code (e.g., 'US', 'CA')
   *                      If not provided, loads all states/provinces
   */
  loadStateProvinceList(countryCode?: string): void;

  /**
   * Handle form submission and initiate account search
   * Validates form inputs, constructs search parameters, and calls the service
   * Updates accountList with results or displays error messages
   * Sets searchSubmitFlag and searchResultLoading appropriately
   */
  onSubmitAccountSearch(): void;

  /**
   * Check if a value exists and return it, otherwise return the default
   * Helper method to safely extract nested object properties
   * Prevents errors when accessing potentially undefined values
   * @param valueToCheck - The value or object path to check
   * @returns The value if it exists, otherwise null or default value
   */
  checkGetIfAvailable(valueToCheck: unknown): unknown;

  /**
   * Change the sorting order of search results
   * Updates the orderbyset property and re-sorts the accountList
   * @param orderby - The field name to sort by (e.g., 'accountName', '-accountNumber')
   *                  Prefix with '-' for descending order
   */
  changeOrderBy(orderby: string): void;

  /**
   * Handle the selection of an account from the search results
   * Emits the onAccountSelect event with the selected account data
   * Updates component state to reflect selection
   * @param data - The complete account data object that was selected
   */
  onSelectingAccount(data: AccountData): void;
}

/**
 * State or province data structure
 * Represents a geographic subdivision used in address filtering
 */
export interface StateProvinceData {
  /**
   * ISO country code
   * Two-letter code identifying the country (e.g., 'US', 'CA', 'MX')
   */
  countryCode: string;

  /**
   * State or province code
   * Abbreviated identifier for the state/province (e.g., 'CA' for California, 'ON' for Ontario)
   * Typically 2-3 characters
   */
  stateProvCode: string;

  /**
   * Full name of the state or province
   * Human-readable name displayed in the UI (e.g., 'California', 'Ontario')
   */
  stateProvName: string;
}
