/**
 * Angular pipe types for account search
 * @packageDocumentation
 */

import type { PipeTransform } from '@angular/core';

/**
 * OrderBy pipe interface
 * Angular pipe for sorting arrays by specified fields
 * Supports single and multi-field sorting with ascending/descending order
 */
export interface IOrderByPipe extends PipeTransform {
  /**
   * Current sort configuration
   * Array of field names with optional direction prefix
   * Examples: ['name'], ['-date'], ['status', '-name']
   */
  value: string[];

  /**
   * Transform method for sorting arrays
   * Implements the PipeTransform interface for Angular pipes
   *
   * @param input - The array to be sorted
   *                Can be array of primitives or objects
   *                Returns input unchanged if not an array
   *
   * @param config - Sort configuration string or array
   *                 Single field: 'fieldName' or '-fieldName'
   *                 Multiple fields: ['field1', '-field2', 'field3']
   *                 Prefix with '-' for descending order
   *                 No prefix means ascending order
   *
   * @returns Sorted array based on the configuration
   *          Original array reference is not modified (returns new sorted array)
   *
   * @example
   * // Sort by single field ascending
   * accounts | orderBy: 'accountName'
   *
   * @example
   * // Sort by single field descending
   * accounts | orderBy: '-accountName'
   *
   * @example
   * // Sort by multiple fields
   * accounts | orderBy: ['status', '-accountName']
   *
   * @example
   * // Sort primitive array
   * numbers | orderBy: '-'  // descending order
   */
  transform<T>(input: T[], config?: string | string[]): T[];
}

/**
 * OrderBy comparator function type
 * Internal function used for comparing two values during sorting
 */
export type OrderByComparator = (
  a: unknown,
  b: unknown,
  direction: 1 | -1
) => number;

/**
 * Sort configuration for OrderBy pipe
 * Defines how sorting should be applied to an array
 */
export interface OrderByConfig {
  /**
   * Field name to sort by
   * Can be a simple property name or a nested path using dot notation
   * Examples: 'name', 'address.city', 'contact.phone'
   */
  field: string;

  /**
   * Sort direction
   * 1 for ascending (A-Z, 0-9)
   * -1 for descending (Z-A, 9-0)
   * @default 1
   */
  direction: 1 | -1;

  /**
   * Case sensitivity for string comparison
   * When false, 'A' and 'a' are considered equal
   * @default false
   */
  caseSensitive?: boolean;

  /**
   * Null/undefined handling
   * Determines where null/undefined values appear in sorted results
   * Options:
   * - 'first': null values appear at the beginning
   * - 'last': null values appear at the end
   * @default 'last'
   */
  nullHandling?: 'first' | 'last';

  /**
   * Custom comparator function
   * Optional function to override default comparison logic
   * Receives two values and direction, returns comparison result
   */
  comparator?: OrderByComparator;
}

/**
 * OrderBy providers array type
 * Used for Angular dependency injection configuration
 */
export type OrderByProviders = unknown[];

/**
 * Sort result metadata
 * Information about the sorting operation performed
 */
export interface SortResultMetadata {
  /**
   * The field(s) used for sorting
   * Array of field names
   */
  sortedBy: string[];

  /**
   * Sort directions applied
   * Maps field names to their sort direction
   * Example: { accountName: 1, createdDate: -1 }
   */
  directions: Record<string, 1 | -1>;

  /**
   * Number of items sorted
   * Total count of elements in the sorted array
   */
  itemCount: number;

  /**
   * Sort execution time in milliseconds
   * Useful for performance monitoring
   */
  executionTime?: number;

  /**
   * Number of null/undefined values encountered
   * Count of items with null values in sort fields
   */
  nullCount?: number;
}

/**
 * OrderBy utility functions type
 * Static helper methods for sorting operations
 */
export interface OrderByUtils {
  /**
   * Parse sort configuration string into OrderByConfig array
   * Converts strings like 'name' or '-date' into config objects
   * @param config - Sort configuration string or array
   * @returns Array of OrderByConfig objects
   */
  parseConfig(config: string | string[]): OrderByConfig[];

  /**
   * Extract nested property value from object
   * Safely navigates object paths using dot notation
   * @param obj - The object to extract from
   * @param path - Property path (e.g., 'address.city')
   * @returns The value at the path, or undefined if not found
   */
  getNestedValue(obj: unknown, path: string): unknown;

  /**
   * Compare two values of any type
   * Handles strings, numbers, dates, booleans, null/undefined
   * @param a - First value to compare
   * @param b - Second value to compare
   * @param direction - Sort direction (1 or -1)
   * @param caseSensitive - Whether string comparison is case-sensitive
   * @returns Comparison result (-1, 0, or 1)
   */
  compareValues(
    a: unknown,
    b: unknown,
    direction: 1 | -1,
    caseSensitive?: boolean
  ): number;

  /**
   * Check if a value is null or undefined
   * @param value - The value to check
   * @returns True if value is null or undefined
   */
  isNullOrUndefined(value: unknown): boolean;

  /**
   * Sort array in place
   * Mutates the original array
   * @param array - The array to sort
   * @param config - Sort configuration
   * @returns The same array reference, now sorted
   */
  sortInPlace<T>(array: T[], config: OrderByConfig[]): T[];

  /**
   * Create a sorted copy of array
   * Does not mutate the original array
   * @param array - The array to sort
   * @param config - Sort configuration
   * @returns A new sorted array
   */
  sortCopy<T>(array: T[], config: OrderByConfig[]): T[];
}
