/**
 * State and province model types
 * @packageDocumentation
 */

/**
 * State or Province model
 * Represents a geographic subdivision (state, province, territory) within a country
 * Used for address validation and geographic filtering in account searches
 */
export interface StateProvinceModel {
  /**
   * ISO 3166-1 alpha-2 country code
   * Two-letter code identifying the country this state/province belongs to
   * Examples:
   * - 'US' for United States
   * - 'CA' for Canada
   * - 'MX' for Mexico
   * - 'GB' for United Kingdom
   * - 'AU' for Australia
   */
  countryCode?: string;

  /**
   * State or province abbreviation code
   * Short code identifying the state, province, or territory
   * Typically 2-3 characters
   * Examples:
   * - US states: 'CA' (California), 'NY' (New York), 'TX' (Texas)
   * - Canadian provinces: 'ON' (Ontario), 'BC' (British Columbia), 'QC' (Quebec)
   * - Mexican states: 'JAL' (Jalisco), 'NLE' (Nuevo León)
   * Used in API requests and database queries for efficient filtering
   */
  stateProvCode?: string;

  /**
   * Full name of the state, province, or territory
   * Human-readable name displayed in UI dropdowns and labels
   * Examples:
   * - 'California'
   * - 'Ontario'
   * - 'New South Wales'
   * - 'Île-de-France'
   * Should be properly capitalized and include any special characters
   * Used for display purposes and user-friendly identification
   */
  stateProvName?: string;
}

/**
 * Complete list of state/province data
 * Constant array containing all available states and provinces
 * Populated from the axis-abc-search-account service data
 */
export type StateProvinceList = StateProvinceModel[];

/**
 * State/Province lookup by country
 * Maps country codes to their respective state/province lists
 * Useful for efficient filtering and lookup operations
 */
export type StateProvinceByCountry = Record<string, StateProvinceModel[]>;

/**
 * State/Province dropdown option
 * Formatted data structure for dropdown components
 */
export interface StateProvinceDropdownOption {
  /**
   * Display label for the dropdown option
   * Typically the full state/province name
   * Example: 'California'
   */
  label: string;

  /**
   * Value to be used when this option is selected
   * Typically the state/province code
   * Example: 'CA'
   */
  value: string;

  /**
   * Country code this state/province belongs to
   * Used for filtering options by country
   * Example: 'US'
   */
  countryCode: string;

  /**
   * Optional flag to disable this option
   * When true, the option appears but cannot be selected
   * Useful for temporarily unavailable regions
   * @default false
   */
  disabled?: boolean;

  /**
   * Optional grouping key
   * Used to group related options in the dropdown
   * Example: 'North America', 'Europe'
   */
  group?: string;

  /**
   * Optional icon or flag to display with the option
   * Can be a CSS class, emoji, or image URL
   * Example: '🇺🇸', 'flag-us', '/flags/us.png'
   */
  icon?: string;

  /**
   * Optional tooltip text
   * Additional information displayed on hover
   * Example: 'Pacific Coast state, capital: Sacramento'
   */
  tooltip?: string;
}

/**
 * State/Province filter criteria
 * Used to filter the state/province list based on various criteria
 */
export interface StateProvinceFilter {
  /**
   * Filter by country code
   * Only return states/provinces for this country
   * Example: 'US'
   */
  countryCode?: string;

  /**
   * Filter by multiple country codes
   * Return states/provinces for any of these countries
   * Example: ['US', 'CA', 'MX']
   */
  countryCodes?: string[];

  /**
   * Search term to filter by name or code
   * Case-insensitive partial match on stateProvName or stateProvCode
   * Example: 'new' matches 'New York', 'New Jersey', 'Newfoundland'
   */
  searchTerm?: string;

  /**
   * Filter by state/province code pattern
   * Regular expression or wildcard pattern
   * Example: '^N' matches codes starting with 'N'
   */
  codePattern?: string;

  /**
   * Include only active/enabled states
   * When provided, filters based on an active status
   * Useful if state/province data includes active flags
   */
  activeOnly?: boolean;

  /**
   * Sort order for results
   * Options:
   * - 'name-asc': Sort by name ascending (A-Z)
   * - 'name-desc': Sort by name descending (Z-A)
   * - 'code-asc': Sort by code ascending
   * - 'code-desc': Sort by code descending
   * @default 'name-asc'
   */
  sortOrder?: 'name-asc' | 'name-desc' | 'code-asc' | 'code-desc';

  /**
   * Maximum number of results to return
   * Useful for limiting dropdown options
   * @default unlimited
   */
  limit?: number;
}

/**
 * State/Province validation result
 * Result of validating a state/province code against the data
 */
export interface StateProvinceValidationResult {
  /**
   * Whether the state/province code is valid
   * True if the code exists in the data for the given country
   */
  isValid: boolean;

  /**
   * The validated state/province model
   * Only present if isValid is true
   */
  stateProvince?: StateProvinceModel;

  /**
   * Error message if validation failed
   * Describes why the validation failed
   * Examples:
   * - 'State code not found'
   * - 'Invalid country code'
   * - 'State code does not belong to specified country'
   */
  errorMessage?: string;

  /**
   * Suggested alternatives
   * List of similar state/province codes that might be correct
   * Useful for fuzzy matching and user corrections
   */
  suggestions?: StateProvinceModel[];
}
