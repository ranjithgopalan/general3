/**
 * Account search service types
 * @packageDocumentation
 */

import type { Observable } from 'rxjs';
import type { AccountSearchRequest, AccountSearchResponse, AccountData } from './account.types';
import type { StateProvinceModel } from './state-province.types';

/**
 * HTTP headers interface from Angular common/http
 */
export interface HttpHeaders {
  /**
   * Appends a new value to existing values for given header
   */
  append(name: string, value: string | string[]): HttpHeaders;

  /**
   * Deletes all header values for given name
   */
  delete(name: string, value?: string | string[]): HttpHeaders;

  /**
   * Gets the first value of a header
   */
  get(name: string): string | null;

  /**
   * Gets all values of a header
   */
  getAll(name: string): string[] | null;

  /**
   * Checks for existence of a header
   */
  has(name: string): boolean;

  /**
   * Returns list of all header names
   */
  keys(): string[];

  /**
   * Sets or overrides header value for given name
   */
  set(name: string, value: string | string[]): HttpHeaders;
}

/**
 * Axis ABC Search Account service interface
 * Provides methods for searching accounts and managing related data
 */
export interface IAxisAbcSearchAccountService {
  /**
   * Retrieve the complete list of state and province data
   * Returns all available states and provinces across all supported countries
   * Data is typically cached for performance
   * @returns Promise resolving to array of state/province models
   * @throws Error if the data cannot be loaded or parsed
   */
  getStateProvinceList(): Promise<StateProvinceModel[]>;

  /**
   * Create HTTP headers for API requests
   * Constructs headers including authentication, content type, and custom values
   * Merges base headers with any additional headers from config
   * @param baseHeader - Base header object or configuration
   *                     Should include authentication tokens and API version
   * @returns HttpHeaders instance ready for HTTP requests
   */
  createHeaders(baseHeader: BaseHeaderConfig): HttpHeaders;

  /**
   * Execute account search operation
   * Sends search parameters to the API and returns matching accounts
   * Handles request construction, header injection, and error handling
   * @param searchAccountObject - Search criteria and parameters
   *                              Contains fields like accountName, city, state, etc.
   * @param config - API configuration including endpoint URL and auth settings
   * @returns Observable of the HTTP response containing search results
   * @throws Error if the request fails or returns invalid data
   */
  findAccountOperation(
    searchAccountObject: AccountSearchRequest,
    config: ServiceConfig
  ): Observable<AccountSearchResponse>;

  /**
   * Retrieve detailed information for a specific account
   * Fetches complete account data using the account number as identifier
   * More efficient than searching when account number is known
   * @param accountNumber - Unique identifier for the account
   *                        Should be a valid, existing account number
   * @param config - API configuration including endpoint URL and auth settings
   * @returns Observable of the HTTP response containing account details
   * @throws Error if the account is not found or request fails
   */
  getAccountOperation(
    accountNumber: string,
    config: ServiceConfig
  ): Observable<AccountData>;

  /**
   * Get current date and time in ISO 8601 format
   * Utility method for generating timestamps
   * Returns date in UTC timezone with full precision
   * @returns ISO 8601 formatted date string (e.g., '2024-01-15T10:30:00.000Z')
   */
  getCurrentDateISO(): string;
}

/**
 * Base header configuration for API requests
 * Defines common headers needed for authenticated API calls
 */
export interface BaseHeaderConfig {
  /**
   * Content type for the request body
   * Typically 'application/json' for JSON payloads
   * @default 'application/json'
   */
  'Content-Type'?: string;

  /**
   * Acceptable response content type
   * Indicates what content types the client can process
   * @default 'application/json'
   */
  Accept?: string;

  /**
   * API version identifier
   * Used for API versioning and compatibility
   * Example: 'v1', '1.0', '2024-01-15'
   */
  'API-Version'?: string;

  /**
   * Bearer authentication token
   * JWT or OAuth token for request authentication
   * Format: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'
   */
  Authorization?: string;

  /**
   * API key for service authentication
   * Alternative to bearer token authentication
   * Should be kept secure and not exposed in client code
   */
  'X-API-Key'?: string;

  /**
   * Unique request identifier
   * Used for request tracking and debugging
   * Typically a UUID or timestamp-based ID
   */
  'X-Request-ID'?: string;

  /**
   * Client application identifier
   * Identifies the calling application for analytics and access control
   * Example: 'axis-account-search-ui'
   */
  'X-Client-ID'?: string;

  /**
   * Client application version
   * Used for compatibility checking and analytics
   * Example: '1.0.0', '2024.01.15'
   */
  'X-Client-Version'?: string;

  /**
   * Correlation ID for distributed tracing
   * Links related requests across microservices
   * Should be propagated through the entire request chain
   */
  'X-Correlation-ID'?: string;

  /**
   * User agent string
   * Identifies the client browser or application making the request
   * Example: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)...'
   */
  'User-Agent'?: string;

  /**
   * Additional custom headers
   * Allows for arbitrary custom headers to be included
   * Key-value pairs for organization-specific requirements
   */
  [key: string]: string | undefined;
}

/**
 * Service configuration for API operations
 * Contains all settings needed to execute service calls
 */
export interface ServiceConfig {
  /**
   * Base URL for the account search API
   * Should be a fully qualified URL including protocol
   * Example: 'https://api.example.com/v1/accounts'
   */
  baseUrl: string;

  /**
   * Search endpoint path
   * Relative path appended to baseUrl for search operations
   * @default '/search'
   */
  searchEndpoint?: string;

  /**
   * Get account endpoint path
   * Relative path appended to baseUrl for get operations
   * Typically includes a parameter placeholder for account number
   * @default '/account/{accountNumber}'
   */
  getEndpoint?: string;

  /**
   * Authentication token or API key
   * Used for securing API requests
   * Should be retrieved from secure storage, not hardcoded
   */
  authToken?: string;

  /**
   * API version string
   * Specifies which version of the API to call
   * Example: 'v1', '1.0.0', '2024-01-15'
   */
  apiVersion?: string;

  /**
   * Request timeout in milliseconds
   * Maximum time to wait for a response before aborting
   * @default 30000
   */
  timeout?: number;

  /**
   * Number of retry attempts for failed requests
   * How many times to retry before giving up
   * @default 0
   */
  retryAttempts?: number;

  /**
   * Delay between retry attempts in milliseconds
   * Exponential backoff is recommended for production
   * @default 1000
   */
  retryDelay?: number;

  /**
   * Enable request/response logging
   * When true, logs all HTTP requests and responses
   * Useful for debugging but may impact performance
   * @default false
   */
  enableLogging?: boolean;

  /**
   * Enable response caching
   * When true, caches GET request responses for performance
   * @default false
   */
  enableCaching?: boolean;

  /**
   * Cache duration in milliseconds
   * How long to cache responses before refreshing
   * Only applies when enableCaching is true
   * @default 300000 (5 minutes)
   */
  cacheDuration?: number;

  /**
   * Additional custom headers for all requests
   * Merged with per-request headers
   * Example: { 'X-Tenant-ID': 'tenant123' }
   */
  customHeaders?: Record<string, string>;

  /**
   * HTTP client configuration
   * Advanced settings for the underlying HTTP client
   */
  httpConfig?: {
    /**
     * Enable HTTP request interception
     * Allows middleware to modify requests before sending
     * @default false
     */
    enableInterceptors?: boolean;

    /**
     * Enable HTTP response transformation
     * Allows middleware to transform responses before returning
     * @default false
     */
    enableTransformers?: boolean;

    /**
     * Enable CORS credentials
     * Include cookies and auth headers in cross-origin requests
     * @default false
     */
    withCredentials?: boolean;

    /**
     * Response type expected from the server
     * Options: 'json', 'text', 'blob', 'arraybuffer'
     * @default 'json'
     */
    responseType?: 'json' | 'text' | 'blob' | 'arraybuffer';
  };
}

/**
 * Service request context
 * Contains metadata about the current request
 */
export interface ServiceRequestContext {
  /**
   * Unique identifier for this request
   * Generated for each API call for tracking
   */
  requestId: string;

  /**
   * Timestamp when the request was initiated
   * ISO 8601 format
   */
  timestamp: string;

  /**
   * User identifier making the request
   * Username, email, or user ID
   */
  userId?: string;

  /**
   * Session identifier
   * Links multiple requests in the same user session
   */
  sessionId?: string;

  /**
   * Client IP address
   * IPv4 or IPv6 address of the client
   */
  clientIp?: string;

  /**
   * Request source or channel
   * Identifies where the request originated
   * Examples: 'web', 'mobile', 'api', 'batch'
   */
  source?: string;

  /**
   * Additional context data
   * Custom key-value pairs for organization-specific needs
   */
  metadata?: Record<string, unknown>;
}
