/**
 * Angular module types for account search
 * @packageDocumentation
 */

/**
 * Axis ABC Search Account Module interface
 * Angular module that provides account search functionality
 * Declares and exports components, services, and pipes needed for account search
 */
export interface IAxisAbcSearchAccountModule {
  /**
   * Module constructor
   * Called once when the module is loaded by Angular
   * Can be used for module-level initialization
   */
  constructor(): void;
}

/**
 * Module configuration options
 * Used to configure the AxisAbcSearchAccountModule at import time
 */
export interface AccountSearchModuleConfig {
  /**
   * Default API endpoint URL
   * Base URL for all account search API calls
   * Can be overridden per-component via config input
   * Example: 'https://api.example.com/v1/accounts'
   */
  apiEndpoint?: string;

  /**
   * Default authentication token
   * Used for all API requests unless overridden
   * Should be retrieved from secure storage
   */
  authToken?: string;

  /**
   * Default API version
   * Version string included in API request headers
   * Example: 'v1', '1.0.0', '2024-01-15'
   */
  apiVersion?: string;

  /**
   * Enable module-wide logging
   * When true, enables console logging for debugging
   * Should be false in production
   * @default false
   */
  enableLogging?: boolean;

  /**
   * Default minimum character length for search
   * Applied to all search fields unless overridden
   * @default 3
   */
  defaultMinCharLength?: number;

  /**
   * Default country code
   * Used for state/province filtering
   * Example: 'US', 'CA', 'MX'
   */
  defaultCountry?: string;

  /**
   * Enable state/province preloading
   * When true, loads state/province data on module init
   * Improves performance but increases initial load time
   * @default false
   */
  preloadStateProvinces?: boolean;

  /**
   * Custom HTTP interceptors
   * Array of interceptor classes to register
   * Used for request/response transformation
   */
  httpInterceptors?: unknown[];

  /**
   * Custom error handler
   * Function to handle module-level errors
   * Receives error object and context information
   */
  errorHandler?: (error: Error, context: string) => void;

  /**
   * Feature flags
   * Enable or disable specific features
   * Example: { fuzzySearch: true, advancedFilters: false }
   */
  features?: Record<string, boolean>;

  /**
   * Localization settings
   * Configure language and formatting options
   */
  localization?: LocalizationConfig;
}

/**
 * Localization configuration
 * Settings for internationalization and localization
 */
export interface LocalizationConfig {
  /**
   * Current locale identifier
   * BCP 47 language tag
   * Examples: 'en-US', 'fr-CA', 'es-MX'
   * @default 'en-US'
   */
  locale?: string;

  /**
   * Available locales
   * Array of supported locale identifiers
   */
  availableLocales?: string[];

  /**
   * Date format pattern
   * Format string for displaying dates
   * Examples: 'MM/DD/YYYY', 'DD-MM-YYYY', 'YYYY-MM-DD'
   * @default 'MM/DD/YYYY'
   */
  dateFormat?: string;

  /**
   * Currency code
   * ISO 4217 currency code
   * Examples: 'USD', 'CAD', 'EUR'
   * @default 'USD'
   */
  currency?: string;

  /**
   * Number formatting options
   * Decimal separator, thousands separator, etc.
   */
  numberFormat?: {
    /**
     * Decimal separator character
     * @default '.'
     */
    decimalSeparator?: string;

    /**
     * Thousands separator character
     * @default ','
     */
    thousandsSeparator?: string;

    /**
     * Number of decimal places
     * @default 2
     */
    decimalPlaces?: number;
  };

  /**
   * Translation keys
   * Custom translations for UI labels and messages
   * Maps translation keys to localized strings
   * Example: { 'search.button': 'Search', 'search.placeholder': 'Enter account name...' }
   */
  translations?: Record<string, string>;
}

/**
 * Module metadata
 * Information about the module and its contents
 */
export interface ModuleMetadata {
  /**
   * Module name
   * Human-readable name of the module
   */
  name: string;

  /**
   * Module version
   * Semantic version string
   * Example: '1.0.0', '2.1.3'
   */
  version: string;

  /**
   * Module description
   * Brief description of module functionality
   */
  description: string;

  /**
   * Exported components
   * Array of component names exported by this module
   */
  components: string[];

  /**
   * Exported services
   * Array of service names exported by this module
   */
  services: string[];

  /**
   * Exported pipes
   * Array of pipe names exported by this module
   */
  pipes: string[];

  /**
   * Exported directives
   * Array of directive names exported by this module
   */
  directives: string[];

  /**
   * Dependencies
   * Other Angular modules required by this module
   * Maps module names to version requirements
   */
  dependencies: Record<string, string>;

  /**
   * Peer dependencies
   * External modules that should be present in the consuming app
   */
  peerDependencies: Record<string, string>;
}

/**
 * Module provider configuration
 * Used for configuring services in forRoot() or forChild()
 */
export interface ModuleProviderConfig {
  /**
   * Service providers to register
   * Array of provider configurations
   */
  providers?: unknown[];

  /**
   * Multi-provider flag
   * When true, allows multiple instances of the same provider
   * @default false
   */
  multi?: boolean;

  /**
   * Module-scoped services
   * Services that should be scoped to this module instance
   * Array of service class references
   */
  scopedServices?: unknown[];

  /**
   * Singleton services
   * Services that should be singleton across the app
   * Array of service class references
   */
  singletonServices?: unknown[];
}

/**
 * Module initialization options
 * Options passed to module initialization methods
 */
export interface ModuleInitOptions {
  /**
   * Initialization mode
   * Controls when and how module is initialized
   * Options:
   * - 'eager': Initialize immediately on module load
   * - 'lazy': Initialize on first use
   * - 'manual': Require explicit initialization call
   * @default 'eager'
   */
  mode?: 'eager' | 'lazy' | 'manual';

  /**
   * Preload resources
   * When true, preloads required resources during init
   * @default false
   */
  preload?: boolean;

  /**
   * Initialization timeout in milliseconds
   * Maximum time to wait for initialization
   * @default 10000
   */
  timeout?: number;

  /**
   * Callback after successful initialization
   * Called when module is fully initialized
   */
  onInitComplete?: () => void;

  /**
   * Callback on initialization error
   * Called if initialization fails
   */
  onInitError?: (error: Error) => void;
}
