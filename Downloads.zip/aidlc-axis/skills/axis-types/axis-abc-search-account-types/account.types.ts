/**
 * Account data and configuration types
 * @packageDocumentation
 */

/**
 * Account search configuration
 * Defines all configuration options for the account search component
 */
export interface AccountSearchConfig {
  /**
   * Base URL for the account search API endpoint
   * Should be a fully qualified URL including protocol
   * Example: 'https://api.example.com/accounts'
   */
  apiEndpoint?: string;

  /**
   * API version string for request headers
   * Used to ensure compatibility with backend services
   * Example: 'v1.0', '2.0.0'
   */
  apiVersion?: string;

  /**
   * Authentication token or API key
   * Included in request headers for secured endpoints
   * Should be kept secure and not exposed in client code
   */
  authToken?: string;

  /**
   * Timeout for API requests in milliseconds
   * Request will be aborted if it exceeds this duration
   * @default 30000
   */
  requestTimeout?: number;

  /**
   * Maximum number of search results to return
   * Limits the size of accountList to prevent performance issues
   * @default 100
   */
  maxResults?: number;

  /**
   * Enable fuzzy matching for search queries
   * When true, allows approximate string matching for names and addresses
   * @default false
   */
  enableFuzzySearch?: boolean;

  /**
   * Default country code for state/province filtering
   * Two-letter ISO country code used when loading states
   * Example: 'US', 'CA', 'MX'
   */
  defaultCountry?: string;

  /**
   * Required fields that must be filled before search
   * Array of form field names that must have values
   * Example: ['accountName', 'city']
   */
  requiredFields?: string[];

  /**
   * Custom validation rules for form fields
   * Maps field names to validation functions or regex patterns
   * Example: { accountNumber: /^\d{6,10}$/ }
   */
  validationRules?: Record<string, unknown>;

  /**
   * Display format for account numbers
   * Template string for formatting account numbers in the UI
   * Example: 'XXX-XXX-XXXX' would format 1234567890 as 123-456-7890
   */
  accountNumberFormat?: string;

  /**
   * Enable or disable specific search fields
   * Maps field names to boolean visibility flags
   * Example: { taxId: false, phoneNumber: true }
   */
  enabledFields?: Record<string, boolean>;

  /**
   * Custom labels for form fields
   * Overrides default field labels with custom text
   * Example: { accountName: 'Company Name', city: 'Location' }
   */
  fieldLabels?: Record<string, string>;

  /**
   * Placeholder text for search inputs
   * Maps field names to placeholder text strings
   * Example: { accountName: 'Enter company name...' }
   */
  placeholders?: Record<string, string>;

  /**
   * Default sorting field and direction
   * Format: 'fieldName' or '-fieldName' for descending
   * Example: '-accountName' sorts by name in descending order
   */
  defaultSort?: string;

  /**
   * Enable case-sensitive search matching
   * When true, search queries must match exact case
   * @default false
   */
  caseSensitive?: boolean;

  /**
   * Additional request headers to include in API calls
   * Custom headers for authentication, tracking, or other purposes
   * Example: { 'X-Request-ID': '12345', 'X-Client-Version': '1.0' }
   */
  customHeaders?: Record<string, string>;
}

/**
 * Complete account data structure
 * Represents a single account with all associated information
 */
export interface AccountData {
  /**
   * Unique account identifier
   * Primary key for the account, guaranteed to be unique
   * Format varies by system but commonly numeric or alphanumeric
   */
  accountNumber?: string;

  /**
   * Legal or registered name of the account
   * Full business or individual name as registered
   * Required for most account operations
   */
  accountName?: string;

  /**
   * Commonly used or trading name
   * May differ from legal account name
   * Used for display purposes
   */
  dbaName?: string;

  /**
   * Account status indicator
   * Defines the current state of the account
   * Common values: 'Active', 'Inactive', 'Suspended', 'Closed', 'Pending'
   */
  status?: string;

  /**
   * Account type classification
   * Categorizes the account for business logic
   * Examples: 'Individual', 'Business', 'Corporate', 'Government', 'Non-Profit'
   */
  accountType?: string;

  /**
   * Primary street address line 1
   * First line of the physical or mailing address
   * Required for location-based services
   */
  addressLine1?: string;

  /**
   * Secondary street address line 2
   * Additional address information such as suite, floor, or building number
   * Optional field for extended addresses
   */
  addressLine2?: string;

  /**
   * City name
   * Municipality or city where the account is located
   * Required for geographic searches and filtering
   */
  city?: string;

  /**
   * State or province code
   * Two or three letter abbreviation for the state/province
   * Examples: 'CA' (California), 'ON' (Ontario), 'NY' (New York)
   */
  state?: string;

  /**
   * State or province full name
   * Complete name of the state or province
   * Used for display when code is insufficient
   */
  stateProvinceName?: string;

  /**
   * Postal or ZIP code
   * Postal code for mail delivery and geographic location
   * Format varies by country (e.g., '12345', '12345-6789', 'K1A 0B1')
   */
  postalCode?: string;

  /**
   * ISO country code
   * Two-letter code identifying the country
   * Examples: 'US', 'CA', 'MX', 'GB'
   */
  countryCode?: string;

  /**
   * Full country name
   * Human-readable country name
   * Examples: 'United States', 'Canada', 'United Kingdom'
   */
  countryName?: string;

  /**
   * Primary phone number
   * Main contact telephone number for the account
   * Format varies but should include area code
   * Example: '+1-555-123-4567' or '(555) 123-4567'
   */
  phoneNumber?: string;

  /**
   * Alternative phone number
   * Secondary contact number for the account
   * Used for backup contact or different departments
   */
  alternatePhoneNumber?: string;

  /**
   * Fax number
   * Facsimile number for document transmission
   * Format similar to phone number
   */
  faxNumber?: string;

  /**
   * Primary email address
   * Main email contact for the account
   * Must be valid email format
   * Example: 'contact@example.com'
   */
  email?: string;

  /**
   * Website URL
   * Account's website or online presence
   * Should be a valid URL including protocol
   * Example: 'https://www.example.com'
   */
  website?: string;

  /**
   * Tax identification number
   * Government-issued tax ID (e.g., EIN, SSN, VAT number)
   * Sensitive data - handle with appropriate security
   * Format varies by country and tax authority
   */
  taxId?: string;

  /**
   * Date the account was established or created
   * ISO 8601 date string format
   * Example: '2024-01-15' or '2024-01-15T10:30:00Z'
   */
  establishedDate?: string;

  /**
   * Date of the last activity on the account
   * Tracks when the account was last accessed or modified
   * ISO 8601 date string format
   */
  lastActivityDate?: string;

  /**
   * Name of the account manager or representative
   * Employee responsible for managing this account
   * May include full name or employee ID
   */
  accountManager?: string;

  /**
   * Credit limit amount
   * Maximum credit extended to the account
   * Numeric value representing currency amount
   * Example: 50000 represents $50,000
   */
  creditLimit?: number;

  /**
   * Current outstanding balance
   * Amount currently owed by or to the account
   * Positive for amounts owed, negative for credits
   * Example: 1250.50 represents $1,250.50
   */
  currentBalance?: number;

  /**
   * Currency code
   * Three-letter ISO 4217 currency code
   * Examples: 'USD', 'CAD', 'EUR', 'GBP'
   */
  currency?: string;

  /**
   * Account risk level or rating
   * Assessment of account risk for credit or operational purposes
   * Common values: 'Low', 'Medium', 'High', or numeric scores
   */
  riskRating?: string;

  /**
   * Industry classification code
   * NAICS, SIC, or other industry classification system code
   * Used for industry-specific reporting and analysis
   */
  industryCode?: string;

  /**
   * Industry description
   * Human-readable description of the account's industry
   * Examples: 'Retail Trade', 'Healthcare', 'Manufacturing'
   */
  industryDescription?: string;

  /**
   * Number of employees
   * Total employee count for business accounts
   * Used for sizing and segmentation
   */
  employeeCount?: number;

  /**
   * Annual revenue amount
   * Yearly revenue for business accounts
   * Numeric value representing currency amount
   * Example: 5000000 represents $5M annual revenue
   */
  annualRevenue?: number;

  /**
   * Parent account number
   * Links to a parent account in hierarchical structures
   * Used for corporate relationships and consolidation
   */
  parentAccountNumber?: string;

  /**
   * Parent account name
   * Name of the parent account
   * Useful for displaying hierarchy without additional lookups
   */
  parentAccountName?: string;

  /**
   * Custom field 1
   * User-defined field for organization-specific data
   * Type and usage defined by implementing organization
   */
  customField1?: string;

  /**
   * Custom field 2
   * Additional user-defined field
   * Type and usage defined by implementing organization
   */
  customField2?: string;

  /**
   * Custom field 3
   * Additional user-defined field
   * Type and usage defined by implementing organization
   */
  customField3?: string;

  /**
   * Notes or comments
   * Free-form text field for additional information
   * May contain special instructions, history, or observations
   */
  notes?: string;

  /**
   * Tags or labels
   * Array of string tags for categorization and filtering
   * Examples: ['vip', 'priority', 'international']
   */
  tags?: string[];

  /**
   * Date record was created
   * ISO 8601 timestamp when this record was first created in the system
   * Example: '2024-01-15T10:30:00Z'
   */
  createdDate?: string;

  /**
   * User who created the record
   * Username or user ID of the person who created this account
   */
  createdBy?: string;

  /**
   * Date record was last modified
   * ISO 8601 timestamp of the most recent update
   * Example: '2024-01-15T14:30:00Z'
   */
  modifiedDate?: string;

  /**
   * User who last modified the record
   * Username or user ID of the person who last updated this account
   */
  modifiedBy?: string;
}

/**
 * Account search request parameters
 * Defines the structure for search query parameters sent to the API
 */
export interface AccountSearchRequest {
  /**
   * Account number to search for
   * Exact or partial match depending on search mode
   */
  accountNumber?: string;

  /**
   * Account name to search for
   * Supports partial matching and wildcards
   */
  accountName?: string;

  /**
   * DBA name to search for
   * Searches the doing-business-as name field
   */
  dbaName?: string;

  /**
   * City to filter by
   * Searches for accounts in the specified city
   */
  city?: string;

  /**
   * State or province code to filter by
   * Two-letter state/province abbreviation
   */
  state?: string;

  /**
   * Postal code to filter by
   * Exact or range matching depending on implementation
   */
  postalCode?: string;

  /**
   * Country code to filter by
   * Two-letter ISO country code
   */
  countryCode?: string;

  /**
   * Phone number to search for
   * May support partial matching
   */
  phoneNumber?: string;

  /**
   * Email address to search for
   * Typically exact match for security
   */
  email?: string;

  /**
   * Tax ID to search for
   * Exact match for security and compliance
   */
  taxId?: string;

  /**
   * Account status filter
   * Comma-separated list or array of status values
   */
  status?: string | string[];

  /**
   * Account type filter
   * Comma-separated list or array of account types
   */
  accountType?: string | string[];

  /**
   * Page number for paginated results
   * Used for pagination, starting at 1
   * @default 1
   */
  page?: number;

  /**
   * Number of results per page
   * Controls pagination size
   * @default 20
   */
  pageSize?: number;

  /**
   * Sort field and direction
   * Format: 'fieldName' or '-fieldName' for descending
   * Example: 'accountName' or '-createdDate'
   */
  sortBy?: string;

  /**
   * Include inactive accounts in results
   * When false, only active accounts are returned
   * @default false
   */
  includeInactive?: boolean;
}

/**
 * Account search response structure
 * Complete response from the account search API
 */
export interface AccountSearchResponse {
  /**
   * Array of account data objects matching the search criteria
   * Empty array if no results found
   */
  accounts: AccountData[];

  /**
   * Total number of accounts matching the search
   * May be greater than accounts.length if paginated
   */
  totalCount: number;

  /**
   * Current page number
   * Reflects the page parameter from the request
   */
  currentPage: number;

  /**
   * Total number of pages available
   * Calculated from totalCount and pageSize
   */
  totalPages: number;

  /**
   * Number of results per page
   * Reflects the pageSize parameter from the request
   */
  pageSize: number;

  /**
   * Flag indicating if there are more results
   * True if currentPage < totalPages
   */
  hasMore: boolean;

  /**
   * Timestamp of the search execution
   * ISO 8601 timestamp when the search was performed
   */
  timestamp?: string;

  /**
   * Search execution time in milliseconds
   * Useful for performance monitoring
   */
  executionTime?: number;
}
