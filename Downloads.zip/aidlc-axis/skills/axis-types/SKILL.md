---
name: axis-types
description: Complete TypeScript type definitions for all AXIS framework components. Multi-category skill with progressive disclosure covering 8 component categories - UI Generator, Portal Menu, Search Account, Search Address, Charts, Components, DataGrid, and Notifications.
---

# AXIS TypeScript Types

Comprehensive TypeScript type system for the AXIS framework, organized by category for progressive disclosure.

## Type Categories

### Axis UI Generator Types

Complete type system for the Axis UI Generator (AUG) component.

**Package:** `axis-ui-generator-types`

**Type Files:**

*Essential (start here):*
- **[UI Structure Types](./axis-ui-generator-types/ui-structure.types.ts)** - Complete UI structure definition including sections, layout, and styling configuration
- **[UI Data Types](./axis-ui-generator-types/ui-data.types.ts)** - UIData for field values and ComponentStatus for state management
- **[Base Control Types](./axis-ui-generator-types/base-control.types.ts)** - Common properties shared by all 78+ control types
- **[Control Types](./axis-ui-generator-types/control.types.ts)** - ControlType enum with all available control types
- **[Layout Types](./axis-ui-generator-types/layout.types.ts)** - Layout configuration including LayoutType and LayoutSizeClass

*Form & Validation:*
- **[Validation Types](./axis-ui-generator-types/validation.types.ts)** - UIValidators and UIErrorMessages for comprehensive form validation
- **[Conditional Types](./axis-ui-generator-types/conditional.types.ts)** - ConditionalLogic for displayIf, requireIf, and disableIf conditions

*Events & Interactions:*
- **[Event Types](./axis-ui-generator-types/event.types.ts)** - UIEvent, UIEmitEvent, UIEmitUpdateEvent, and ContentRequest for API calls
- **[Menu Types](./axis-ui-generator-types/menu.types.ts)** - MenuIcon configuration for label and field menus

*Helper & Advanced:*
- **[Helper Types](./axis-ui-generator-types/helper.types.ts)** - AUGHelper interface with AddElementConfig, RefreshElementConfig, RecreateElementConfig
- **[AUG Instance Types](./axis-ui-generator-types/aug-instance.types.ts)** - AUGInstance interface for internal/advanced usage
- **[Route Types](./axis-ui-generator-types/route.types.ts)** - AUGRoute and AUGRoutes for navigation configuration

---

### Axis ABC Portal Menu Types

Complete type system for the Axis ABC Portal Menu component (navigation and notifications).

**Package:** `axis-abc-portal-menu-types`

**Type Files:**

*Essential (start here):*
- **[Portal Menu Common Types](./axis-abc-portal-menu-types/portal-menu-common.types.ts)** - MenuItem, MenuObject, NotificationItem, NotificationObject base types
- **[Portal Menu Component Types](./axis-abc-portal-menu-types/portal-menu-component.types.ts)** - IAxisAbcPortalMenuComponent and PortalMenuOptions

*Configuration & Setup:*
- **[Portal Menu Module Types](./axis-abc-portal-menu-types/portal-menu-module.types.ts)** - Module configuration including theming and event bus
- **[Portal Menu Routing Types](./axis-abc-portal-menu-types/portal-menu-routing.types.ts)** - Navigation, routes, breadcrumbs, and deep linking

*Advanced:*
- **[Portal Menu Service Types](./axis-abc-portal-menu-types/portal-menu-service.types.ts)** - State management, data providers, and analytics integration

---

### Axis ABC Search Account Types

Complete type system for the Axis ABC Search Account component (business account search).

**Package:** `axis-abc-search-account-types`

**Type Files:**

*Essential (start here):*
- **[Account Types](./axis-abc-search-account-types/account.types.ts)** - AccountSearchConfig, AccountData, and AccountSearchRequest
- **[Component Types](./axis-abc-search-account-types/component.types.ts)** - IAxisAbcSearchAccountComponent interface

*Configuration & Setup:*
- **[Module Types](./axis-abc-search-account-types/module.types.ts)** - Module configuration and localization settings
- **[Service Types](./axis-abc-search-account-types/service.types.ts)** - IAxisAbcSearchAccountService and ServiceConfig

*Advanced:*
- **[Pipe Types](./axis-abc-search-account-types/pipe.types.ts)** - OrderBy pipe and sorting utility types
- **[State/Province Types](./axis-abc-search-account-types/state-province.types.ts)** - Geographic data, filtering, and validation types

---

### Axis ABC Search Address Types

Complete type system for the Axis ABC Search Address component (Google Maps address search with autocomplete).

**Package:** `axis-abc-search-address-types`

**Type Files:**

*Essential (start here):*
- **[Address Component Types](./axis-abc-search-address-types/address-component.types.ts)** - IAxisAddressComponent, AddressData, AddressChangeEvent
- **[Address Module Types](./axis-abc-search-address-types/address-module.types.ts)** - Module configuration and injection tokens

*Google Maps Integration:*
- **[Address Service Types](./axis-abc-search-address-types/address-service.types.ts)** - IAxisGoogleMapService and API response types
- **[Google Maps Types](./axis-abc-search-address-types/google-maps-types.types.ts)** - Extended Google Maps types including geocoding and coordinates

*Advanced:*
- **[JSONP Interceptor Types](./axis-abc-search-address-types/jsonp-interceptor.types.ts)** - HTTP interceptor configuration for Google Maps API calls

---

### Axis Charts Types

Complete type system for Axis charting components (Bar, Donut, D3 charts, and specialized visualizations).

**Package:** `axis-charts-types`

**Type Files:**

*Essential (start here):*
- **[Chart Common Types](./axis-charts-types/chart-common.types.ts)** - Shared chart interfaces, data structures, and styling options

*Specific Chart Types:*
- **[Bar Chart Types](./axis-charts-types/bar-chart.types.ts)** - Bar, column, stacked, and grouped chart configurations
- **[Donut Chart Types](./axis-charts-types/donut-chart.types.ts)** - Donut and pie chart with legend configurations
- **[D3 Charts Types](./axis-charts-types/d3-charts.types.ts)** - Advanced D3.js-based visualization types
- **[Specialized Charts Types](./axis-charts-types/specialized-charts.types.ts)** - Gauge, funnel, treemap, and heatmap configurations
- **[Stacked Charts Types](./axis-charts-types/stacked-charts.types.ts)** - Stacked area and stacked bar chart types
- **[Combination Charts Types](./axis-charts-types/combination-charts.types.ts)** - Combined chart type configurations

*Configuration & Setup:*
- **[Colors Types](./axis-charts-types/colors.types.ts)** - Color palette and theme configurations
- **[Module Types](./axis-charts-types/module.types.ts)** - Chart module setup and configuration
- **[Utility Types](./axis-charts-types/utility.types.ts)** - Helper types, formatters, and utility functions

---

### Axis Components Types

Complete type system for core Axis UI components (buttons, modals, forms, alerts).

**Package:** `axis-components-types`

**Type Files:**

*Essential (start here):*
- **[Component Common Types](./axis-components-types/component-common.types.ts)** - Shared base interfaces for all Axis components
- **[Button Types](./axis-components-types/button.types.ts)** - Button component properties, variants, states, and event handling
- **[Input Types](./axis-components-types/input.types.ts)** - Text input field configurations and properties
- **[Dropdown Types](./axis-components-types/dropdown.types.ts)** - Dropdown and select component configurations

*Form Controls:*
- **[Checkbox Types](./axis-components-types/checkbox.types.ts)** - Checkbox component interfaces
- **[Radio Types](./axis-components-types/radio.types.ts)** - Radio button group configurations
- **[Slider Types](./axis-components-types/slider.types.ts)** - Slider and range control types
- **[Rating Types](./axis-components-types/rating.types.ts)** - Star rating component configuration
- **[Chiplist Types](./axis-components-types/chiplist.types.ts)** - Chip list and tag input types
- **[Duallist Types](./axis-components-types/duallist.types.ts)** - Dual list selection component
- **[Timepicker Types](./axis-components-types/timepicker.types.ts)** - Time picker component configuration

*Layout Components:*
- **[Card Types](./axis-components-types/card.types.ts)** - Card container component interfaces
- **[Accordion Types](./axis-components-types/accordion.types.ts)** - Accordion/collapsible panel types
- **[Tab Types](./axis-components-types/tab.types.ts)** - Tab navigation component configuration
- **[Modal Types](./axis-components-types/modal.types.ts)** - Modal and dialog component interfaces

*UI Elements:*
- **[Alert Types](./axis-components-types/alert.types.ts)** - Alert and notification banner types
- **[Loading Types](./axis-components-types/loading.types.ts)** - Loading spinner and progress indicators
- **[Icon Types](./axis-components-types/icon.types.ts)** - Icon component configuration
- **[Tooltip Types](./axis-components-types/tooltip.types.ts)** - Tooltip and popover types
- **[Navbar Types](./axis-components-types/navbar.types.ts)** - Navigation bar component interfaces
- **[Paginator Types](./axis-components-types/paginator.types.ts)** - Pagination component configuration

---

### Axis DataGrid Types

Complete type system for the Axis DataGrid component (advanced data tables with sorting, filtering, pagination).

**Package:** `axis-datagrid-types`

**Type Files:**

*Essential (start here):*
- **[DataGrid Common Types](./axis-datagrid-types/datagrid-common.types.ts)** - Grid configuration including columns, rows, and data binding

*Advanced Features:*
- **[DataGrid Plugins Types](./axis-datagrid-types/datagrid-plugins.types.ts)** - Sorting, filtering, pagination, and selection plugins
- **[DataGrid Service Types](./axis-datagrid-types/datagrid-service.types.ts)** - Grid services for state management and data operations

---

### Axis Notification Types

Complete type system for the Axis Notification component (notification bell, dropdown panel, polling).

**Package:** `axis-notification-types`

**Type Files:**

*Essential (start here):*
- **[Notification Data Types](./axis-notification-types/notification-data.types.ts)** - NotificationData, NotificationResponse, and event types
- **[Notification Config Types](./axis-notification-types/notification-config.types.ts)** - NotificationConfig and notification type enums

*Component & Service:*
- **[Notification Component Types](./axis-notification-types/notification-component.types.ts)** - IAxisNotificationComponent with custom item rendering
- **[Notification Service Types](./axis-notification-types/notification-service.types.ts)** - IAxisNotificationService with cache handling

*Module Setup:*
- **[Notification Module Types](./axis-notification-types/notification-module.types.ts)** - IAxisNotificationModule configuration

---

## Usage by Agent

**General workflow:**
1. **Identify the component** - Determine which AXIS component the task requires
2. **Browse type files** - Start with Essential types in the relevant category
3. **Read specific types as needed** - Progressive disclosure keeps context usage low
4. **Generate type-safe code** - Use the types to create fully typed implementations

**Component-specific guidance:**

*For Axis UI Generator (AUG) code generation:*
- Browse [axis-ui-generator-types/](./axis-ui-generator-types/) type files
- Start with ui-structure.types.ts, ui-data.types.ts, and helper.types.ts
- Read specific categories: control, validation, event types as needed
- Generate dynamic forms with full type safety

*For Portal Menu/Navigation:*
- Browse [axis-abc-portal-menu-types/](./axis-abc-portal-menu-types/) type files
- Focus on portal-menu-common.types.ts, portal-menu-component.types.ts, portal-menu-routing.types.ts
- Generate navigation menus with notifications

*For Account Search:*
- Browse [axis-abc-search-account-types/](./axis-abc-search-account-types/) type files
- Focus on account.types.ts, component.types.ts, service.types.ts
- Generate business account search interfaces

*For Address Search (Google Maps):*
- Browse [axis-abc-search-address-types/](./axis-abc-search-address-types/) type files
- Focus on address-component.types.ts and google-maps-types.types.ts
- Generate address autocomplete with maps

*For Charts & Visualizations:*
- Browse [axis-charts-types/](./axis-charts-types/) type files
- Start with chart-common.types.ts, then choose specific chart types: bar-chart, donut-chart, d3-charts, specialized-charts
- Generate data visualizations with custom configurations

*For Core UI Components:*
- Browse [axis-components-types/](./axis-components-types/) type files
- Start with component-common.types.ts, then focus on button, modal, input, or other specific component types
- Generate standard UI components

*For Data Tables:*
- Browse [axis-datagrid-types/](./axis-datagrid-types/) type files
- Focus on datagrid-common.types.ts and datagrid-plugins.types.ts
- Generate advanced data grids with sorting/filtering

*For Notifications:*
- Browse [axis-notification-types/](./axis-notification-types/) type files
- Focus on notification-data.types.ts, notification-config.types.ts, notification-component.types.ts, and notification-service.types.ts
- Generate notification systems with polling

## Benefits

1. **Complete AXIS Coverage** - Type definitions for all 8 major AXIS component categories
2. **Multi-category organization** - Scalable for multiple type systems
3. **Progressive disclosure** - Read only what you need to minimize context usage
4. **IntelliSense support** - Full IDE integration with autocomplete
5. **Type safety** - Catch errors at compile time before runtime
6. **Consistent patterns** - All categories follow the same documentation structure
7. **Zero runtime overhead** - Types are compile-time only
