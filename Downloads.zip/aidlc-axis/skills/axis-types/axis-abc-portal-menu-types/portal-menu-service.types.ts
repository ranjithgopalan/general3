/**
 * Portal menu service types
 * @packageDocumentation
 */

import type { Observable } from 'rxjs';
import type {
  MenuObject,
  NotificationObject,
  MenuItem,
  NotificationItem
} from './portal-menu-common.types';
import type { MenuRouteConfig } from './portal-menu-routing.types';

/**
 * Portal menu state
 * Represents the complete current state of the menu
 */
export interface PortalMenuState {
  /**
   * Current menu data
   * Full menu structure and configuration
   */
  menu: MenuObject;

  /**
   * Current notification data
   * All notifications and configuration
   */
  notifications: NotificationObject;

  /**
   * Currently active menu item ID
   * Which menu item is currently selected
   */
  activeItemId: string | null;

  /**
   * Currently expanded menu item IDs
   * Which sub-menus are currently open
   */
  expandedItems: string[];

  /**
   * Whether the menu is collapsed
   * Applies to sidebar and vertical menus
   */
  collapsed: boolean;

  /**
   * Whether the notification panel is open
   */
  notificationPanelOpen: boolean;

  /**
   * Current search query
   * Active search filter text
   */
  searchQuery: string;

  /**
   * Loading state
   * Whether menu data is being fetched
   */
  loading: boolean;

  /**
   * Error state
   * Any error that occurred during operations
   */
  error: Error | null;

  /**
   * Last updated timestamp
   * When the state was last modified
   */
  lastUpdated: number;
}

/**
 * Portal menu service interface
 * Defines the API for the service that manages menu state and operations
 */
export interface IPortalMenuService {
  /**
   * Observable of the current menu state
   * Subscribe to this to react to state changes
   */
  state$: Observable<PortalMenuState>;

  /**
   * Observable of the current menu data
   * Emits whenever menu structure changes
   */
  menu$: Observable<MenuObject>;

  /**
   * Observable of the current notification data
   * Emits whenever notifications change
   */
  notifications$: Observable<NotificationObject>;

  /**
   * Observable of the currently active menu item ID
   * Emits when active item changes
   */
  activeItemId$: Observable<string | null>;

  /**
   * Observable of expanded menu item IDs
   * Emits when any menu item is expanded or collapsed
   */
  expandedItems$: Observable<string[]>;

  /**
   * Observable of collapsed state
   * Emits when menu is collapsed or expanded
   */
  collapsed$: Observable<boolean>;

  /**
   * Observable of loading state
   * Emits when loading starts or completes
   */
  loading$: Observable<boolean>;

  /**
   * Observable of error state
   * Emits when errors occur
   */
  error$: Observable<Error | null>;

  /**
   * Get the current menu state synchronously
   * @returns Current state snapshot
   */
  getState(): PortalMenuState;

  /**
   * Get the current menu data synchronously
   * @returns Current menu structure
   */
  getMenu(): MenuObject;

  /**
   * Get the current notification data synchronously
   * @returns Current notifications
   */
  getNotifications(): NotificationObject;

  /**
   * Set the complete menu data
   * Replaces the entire menu structure
   * @param menu - New menu object
   */
  setMenu(menu: MenuObject): void;

  /**
   * Update menu data with partial changes
   * Merges provided data with existing menu
   * @param updates - Partial menu updates
   */
  updateMenu(updates: Partial<MenuObject>): void;

  /**
   * Add a menu item
   * @param item - Menu item to add
   * @param parentId - Optional parent ID for nesting
   */
  addMenuItem(item: MenuItem, parentId?: string): void;

  /**
   * Update a menu item
   * @param itemId - ID of item to update
   * @param updates - Partial item updates
   */
  updateMenuItem(itemId: string, updates: Partial<MenuItem>): void;

  /**
   * Remove a menu item
   * @param itemId - ID of item to remove
   */
  removeMenuItem(itemId: string): void;

  /**
   * Find a menu item by ID
   * Searches recursively through menu hierarchy
   * @param itemId - ID to search for
   * @returns Found menu item or undefined
   */
  findMenuItem(itemId: string): MenuItem | undefined;

  /**
   * Find menu items by property
   * @param property - Property name to search
   * @param value - Value to match
   * @returns Array of matching menu items
   */
  findMenuItemsBy(property: string, value: unknown): MenuItem[];

  /**
   * Get all menu items as a flat array
   * Includes nested children in depth-first order
   * @returns Flat array of all menu items
   */
  getAllMenuItems(): MenuItem[];

  /**
   * Set the active menu item
   * Updates highlighting and state
   * @param itemId - ID of item to activate
   */
  setActiveItem(itemId: string): void;

  /**
   * Clear the active menu item
   * Removes active state from all items
   */
  clearActiveItem(): void;

  /**
   * Get the currently active menu item
   * @returns Active menu item or undefined
   */
  getActiveItem(): MenuItem | undefined;

  /**
   * Expand a menu item (show children)
   * @param itemId - ID of item to expand
   */
  expandItem(itemId: string): void;

  /**
   * Collapse a menu item (hide children)
   * @param itemId - ID of item to collapse
   */
  collapseItem(itemId: string): void;

  /**
   * Toggle expansion of a menu item
   * @param itemId - ID of item to toggle
   */
  toggleItem(itemId: string): void;

  /**
   * Expand all menu items
   * Opens all sub-menus
   */
  expandAll(): void;

  /**
   * Collapse all menu items
   * Closes all sub-menus
   */
  collapseAll(): void;

  /**
   * Get expanded state of a menu item
   * @param itemId - ID to check
   * @returns true if expanded, false otherwise
   */
  isItemExpanded(itemId: string): boolean;

  /**
   * Collapse the menu (sidebar/vertical only)
   */
  collapseMenu(): void;

  /**
   * Expand the menu (sidebar/vertical only)
   */
  expandMenu(): void;

  /**
   * Toggle menu collapsed state
   */
  toggleMenuCollapse(): void;

  /**
   * Set the notification data
   * Replaces entire notification structure
   * @param notifications - New notification object
   */
  setNotifications(notifications: NotificationObject): void;

  /**
   * Add a notification
   * @param notification - Notification to add
   */
  addNotification(notification: NotificationItem): void;

  /**
   * Update a notification
   * @param notificationId - ID of notification to update
   * @param updates - Partial notification updates
   */
  updateNotification(notificationId: string, updates: Partial<NotificationItem>): void;

  /**
   * Remove a notification
   * @param notificationId - ID of notification to remove
   */
  removeNotification(notificationId: string): void;

  /**
   * Mark a notification as read
   * @param notificationId - ID of notification to mark
   */
  markNotificationAsRead(notificationId: string): void;

  /**
   * Mark all notifications as read
   */
  markAllNotificationsAsRead(): void;

  /**
   * Clear all notifications
   * Removes all notification items
   */
  clearAllNotifications(): void;

  /**
   * Get unread notification count
   * @returns Number of unread notifications
   */
  getUnreadCount(): number;

  /**
   * Open the notification panel
   */
  openNotificationPanel(): void;

  /**
   * Close the notification panel
   */
  closeNotificationPanel(): void;

  /**
   * Toggle notification panel visibility
   */
  toggleNotificationPanel(): void;

  /**
   * Fetch menu data from API
   * Loads menu configuration from server
   * @returns Observable of menu data
   */
  fetchMenu(): Observable<MenuObject>;

  /**
   * Fetch notification data from API
   * Loads notifications from server
   * @returns Observable of notification data
   */
  fetchNotifications(): Observable<NotificationObject>;

  /**
   * Refresh menu data
   * Reloads menu from API and updates state
   * @returns Observable that completes when refresh is done
   */
  refreshMenu(): Observable<void>;

  /**
   * Refresh notification data
   * Reloads notifications from API and updates state
   * @returns Observable that completes when refresh is done
   */
  refreshNotifications(): Observable<void>;

  /**
   * Save menu state to localStorage
   * Persists current state for later restoration
   */
  saveState(): void;

  /**
   * Load menu state from localStorage
   * Restores previously saved state
   */
  loadState(): void;

  /**
   * Clear saved state from localStorage
   * Removes persisted state data
   */
  clearSavedState(): void;

  /**
   * Reset menu to initial/default state
   * Clears all customizations and data
   */
  reset(): void;

  /**
   * Destroy the service
   * Cleanup subscriptions and resources
   */
  destroy(): void;
}

/**
 * Portal menu data provider interface
 * Defines contract for fetching menu and notification data
 */
export interface IPortalMenuDataProvider {
  /**
   * Fetch menu structure from data source
   * @returns Observable of menu data
   */
  getMenu(): Observable<MenuObject>;

  /**
   * Fetch notifications from data source
   * @returns Observable of notification data
   */
  getNotifications(): Observable<NotificationObject>;

  /**
   * Update menu data in data source
   * @param menu - Menu data to save
   * @returns Observable that completes when save is done
   */
  saveMenu(menu: MenuObject): Observable<void>;

  /**
   * Mark notification as read in data source
   * @param notificationId - ID of notification
   * @returns Observable that completes when update is done
   */
  markNotificationRead(notificationId: string): Observable<void>;

  /**
   * Dismiss notification in data source
   * @param notificationId - ID of notification
   * @returns Observable that completes when deletion is done
   */
  dismissNotification(notificationId: string): Observable<void>;
}

/**
 * Portal menu cache interface
 * Defines contract for caching menu data
 */
export interface IPortalMenuCache {
  /**
   * Get cached menu data
   * @returns Cached menu or undefined if not cached
   */
  getMenu(): MenuObject | undefined;

  /**
   * Set menu data in cache
   * @param menu - Menu data to cache
   * @param ttl - Time to live in milliseconds (optional)
   */
  setMenu(menu: MenuObject, ttl?: number): void;

  /**
   * Get cached notification data
   * @returns Cached notifications or undefined if not cached
   */
  getNotifications(): NotificationObject | undefined;

  /**
   * Set notification data in cache
   * @param notifications - Notification data to cache
   * @param ttl - Time to live in milliseconds (optional)
   */
  setNotifications(notifications: NotificationObject, ttl?: number): void;

  /**
   * Check if menu cache is valid (not expired)
   * @returns true if cache is valid, false otherwise
   */
  isMenuValid(): boolean;

  /**
   * Check if notification cache is valid (not expired)
   * @returns true if cache is valid, false otherwise
   */
  isNotificationsValid(): boolean;

  /**
   * Clear all cached data
   */
  clear(): void;

  /**
   * Clear menu cache only
   */
  clearMenu(): void;

  /**
   * Clear notification cache only
   */
  clearNotifications(): void;
}

/**
 * Portal menu state store interface
 * Defines contract for state management
 */
export interface IPortalMenuStateStore {
  /**
   * Get the current state
   * @returns Current state snapshot
   */
  getState(): PortalMenuState;

  /**
   * Set the complete state
   * @param state - New state
   */
  setState(state: PortalMenuState): void;

  /**
   * Update state with partial changes
   * @param updates - Partial state updates
   */
  updateState(updates: Partial<PortalMenuState>): void;

  /**
   * Subscribe to state changes
   * @param callback - Function called when state changes
   * @returns Unsubscribe function
   */
  subscribe(callback: (state: PortalMenuState) => void): () => void;

  /**
   * Get observable of state
   * @returns Observable that emits on state changes
   */
  getState$(): Observable<PortalMenuState>;

  /**
   * Reset state to initial values
   */
  reset(): void;
}

/**
 * Menu item permission checker interface
 * Defines contract for authorization logic
 */
export interface IMenuPermissionChecker {
  /**
   * Check if user has permission to access a menu item
   * @param item - Menu item to check
   * @returns true if user has access, false otherwise
   */
  hasPermission(item: MenuItem): boolean;

  /**
   * Check if user has permission to access a route
   * @param route - Route configuration to check
   * @returns true if user has access, false otherwise
   */
  hasRoutePermission(route: MenuRouteConfig): boolean;

  /**
   * Get user's current permissions
   * @returns Array of permission strings
   */
  getUserPermissions(): string[];

  /**
   * Set user's permissions
   * @param permissions - Array of permission strings
   */
  setUserPermissions(permissions: string[]): void;

  /**
   * Check if user has a specific permission
   * @param permission - Permission string to check
   * @returns true if user has permission, false otherwise
   */
  hasPermissionString(permission: string): boolean;

  /**
   * Check if user has any of the given permissions
   * @param permissions - Array of permission strings
   * @returns true if user has at least one permission
   */
  hasAnyPermission(permissions: string[]): boolean;

  /**
   * Check if user has all of the given permissions
   * @param permissions - Array of permission strings
   * @returns true if user has all permissions
   */
  hasAllPermissions(permissions: string[]): boolean;
}

/**
 * Menu analytics interface
 * Defines contract for tracking menu interactions
 */
export interface IMenuAnalytics {
  /**
   * Track menu item click
   * @param item - Menu item that was clicked
   */
  trackItemClick(item: MenuItem): void;

  /**
   * Track menu item selection
   * @param item - Menu item that was selected
   */
  trackItemSelect(item: MenuItem): void;

  /**
   * Track notification interaction
   * @param notification - Notification that was interacted with
   * @param action - Type of interaction (read, dismiss, click)
   */
  trackNotificationAction(notification: NotificationItem, action: string): void;

  /**
   * Track menu search
   * @param query - Search query text
   * @param resultsCount - Number of results found
   */
  trackSearch(query: string, resultsCount: number): void;

  /**
   * Track menu collapse/expand
   * @param collapsed - New collapsed state
   */
  trackMenuToggle(collapsed: boolean): void;

  /**
   * Track custom event
   * @param eventName - Name of the event
   * @param data - Additional event data
   */
  trackCustomEvent(eventName: string, data?: Record<string, unknown>): void;
}
