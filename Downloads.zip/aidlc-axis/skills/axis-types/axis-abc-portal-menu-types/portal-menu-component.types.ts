/**
 * Portal menu component types
 * @packageDocumentation
 */

import type { EventEmitter } from '@angular/core';
import type {
  MenuObject,
  NotificationObject,
  MenuItem,
  MenuEvent,
  NotificationEvent,
  MenuType
} from './portal-menu-common.types';

/**
 * Portal menu configuration options
 * Comprehensive settings for customizing the menu's appearance and behavior
 */
export interface PortalMenuOptions {
  /**
   * Whether to enable menu animations
   * Controls transitions, hover effects, and state changes
   * @default true
   */
  enableAnimations?: boolean;

  /**
   * Whether to enable keyboard navigation
   * Allows using arrow keys and enter to navigate the menu
   * @default true
   */
  enableKeyboardNav?: boolean;

  /**
   * Whether to automatically close sub-menus when clicking outside
   * Improves UX by closing dropdowns on external clicks
   * @default true
   */
  closeOnClickOutside?: boolean;

  /**
   * Whether to automatically highlight the active menu item based on current route
   * Syncs menu state with Angular router
   * @default true
   */
  autoHighlightActive?: boolean;

  /**
   * Maximum nesting depth for sub-menus
   * Limits how many levels of children are rendered
   * @default 3
   */
  maxDepth?: number;

  /**
   * Whether to show tooltips on hover
   * Displays additional information for menu items
   * @default true
   */
  showTooltips?: boolean;

  /**
   * Tooltip delay in milliseconds
   * Time to wait before showing tooltip on hover
   * @default 300
   */
  tooltipDelay?: number;

  /**
   * Whether to enable menu search/filter functionality
   * Adds a search box to filter menu items
   * @default false
   */
  enableSearch?: boolean;

  /**
   * Placeholder text for search input
   * Displayed in the search box when empty
   * @default 'Search menu...'
   */
  searchPlaceholder?: string;

  /**
   * Whether to show breadcrumbs for nested navigation
   * Displays navigation path for current location
   * @default false
   */
  showBreadcrumbs?: boolean;

  /**
   * Custom CSS classes for the menu container
   * Allows additional styling customization
   */
  containerClass?: string;

  /**
   * Custom CSS classes for menu items
   * Applied to all menu item elements
   */
  itemClass?: string;

  /**
   * Whether to enable right-click context menus
   * Shows additional options on right-click
   * @default false
   */
  enableContextMenu?: boolean;

  /**
   * Whether to persist menu state in localStorage
   * Remembers collapsed/expanded state across sessions
   * @default false
   */
  persistState?: boolean;

  /**
   * Storage key for persisted state
   * localStorage key name for saving menu state
   * @default 'axis-portal-menu-state'
   */
  stateStorageKey?: string;

  /**
   * Notification panel position relative to trigger button
   * Controls where the notification dropdown appears
   * @default 'bottom-right'
   */
  notificationPosition?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';

  /**
   * Auto-refresh interval for notifications in milliseconds
   * 0 disables auto-refresh
   * @default 0
   */
  notificationRefreshInterval?: number;

  /**
   * Whether to group notifications by date
   * Organizes notifications into Today, Yesterday, Earlier sections
   * @default false
   */
  groupNotificationsByDate?: boolean;

  /**
   * Custom z-index for the menu
   * Controls stacking order with other page elements
   * @default 1000
   */
  zIndex?: number;
}

/**
 * Portal menu component interface
 * Defines the complete API for the AxisAbcPortalMenuComponent
 */
export interface IAxisAbcPortalMenuComponent {
  /**
   * Current application name identifier
   * Used for highlighting the active application in the menu
   * Typically matches a menu item's ID or route
   * @example 'dashboard', 'reports', 'admin'
   */
  currentAppName: string;

  /**
   * Menu display type/mode
   * Controls the visual layout and behavior of the menu
   * - 'horizontal': Top navigation bar
   * - 'vertical': Side navigation panel
   * - 'sidebar': Collapsible side panel
   * - 'dropdown': Dropdown menu button
   * @default 'horizontal'
   */
  menuType: MenuType;

  /**
   * Complete menu data structure
   * Contains all navigation items, configuration, and styling
   * Can be dynamically updated to refresh the menu
   */
  menuObject: MenuObject;

  /**
   * Notification center data
   * Contains all notification items and configuration
   * Updates trigger automatic UI refresh
   */
  notificationObject: NotificationObject;

  /**
   * Whether to display the notifications panel/button
   * Hides notification functionality when false
   * Useful for user roles without notification access
   * @default true
   */
  showNotifications: boolean;

  /**
   * Internal state tracking mouse hover over notification panel
   * Used for managing dropdown visibility and interactions
   * Should not be set directly by consumers
   * @internal
   */
  notificationMouseOver: boolean;

  /**
   * Configuration options for menu behavior and appearance
   * Provides fine-grained control over menu features
   * Optional - uses defaults if not provided
   */
  options?: PortalMenuOptions;

  /**
   * Custom theme name or identifier
   * References a predefined theme or CSS class
   * @example 'dark', 'light', 'blue-theme', 'corporate'
   */
  theme?: string;

  /**
   * Whether the menu is currently collapsed
   * Only applicable for sidebar and vertical menu types
   * @default false
   */
  collapsed?: boolean;

  /**
   * User profile information
   * Displayed in menu header or profile section
   * Optional - some menus may not show user info
   */
  userProfile?: {
    /**
     * User's display name
     */
    name: string;

    /**
     * User's email address
     */
    email?: string;

    /**
     * User's avatar/profile picture URL
     */
    avatar?: string;

    /**
     * User's role or title
     */
    role?: string;
  };

  /**
   * Logo image URL or path
   * Displayed in menu header
   * Clicking navigates to home or configured route
   */
  logo?: string;

  /**
   * Logo navigation route
   * Where to navigate when logo is clicked
   * @default '/'
   */
  logoRoute?: string;

  /**
   * Whether the menu has been initialized
   * Internal state tracking component lifecycle
   * @internal
   */
  initialized?: boolean;

  /**
   * Currently active menu item ID
   * Synced with currentAppName and router state
   * Used for highlighting active item
   * @internal
   */
  activeItemId?: string;

  /**
   * Currently expanded menu item IDs
   * Tracks which sub-menus are open
   * Used for managing menu state
   * @internal
   */
  expandedItems?: string[];

  /**
   * Whether the notification panel is currently visible
   * Controls dropdown open/close state
   * @internal
   */
  notificationPanelVisible?: boolean;

  /**
   * Filtered menu items (when search is active)
   * Contains search results
   * @internal
   */
  filteredMenuItems?: MenuItem[];

  /**
   * Current search query text
   * User's search input
   * @internal
   */
  searchQuery?: string;

  /**
   * Event emitted when a menu item is clicked
   * Provides details about the clicked item and event
   * Consumers can use this to perform custom actions or analytics
   */
  onMenuItemClick?: EventEmitter<MenuEvent>;

  /**
   * Event emitted when a menu item is selected (activated)
   * Fires after navigation or state change is complete
   * Different from click - selection may occur without clicking
   */
  onMenuItemSelect?: EventEmitter<MenuEvent>;

  /**
   * Event emitted when the menu is collapsed
   * Only fires for collapsible menu types (sidebar, vertical)
   */
  onMenuCollapse?: EventEmitter<void>;

  /**
   * Event emitted when the menu is expanded
   * Only fires for collapsible menu types (sidebar, vertical)
   */
  onMenuExpand?: EventEmitter<void>;

  /**
   * Event emitted when a notification is interacted with
   * Fires for read, dismiss, or action button clicks
   * Consumers can use this to update backend notification state
   */
  onNotificationAction?: EventEmitter<NotificationEvent>;

  /**
   * Event emitted when all notifications are cleared
   * Fired when "Clear All" button is clicked
   */
  onNotificationClearAll?: EventEmitter<void>;

  /**
   * Event emitted when the notification panel is opened
   * Useful for loading fresh notification data
   */
  onNotificationPanelOpen?: EventEmitter<void>;

  /**
   * Event emitted when the notification panel is closed
   * Useful for cleanup or analytics
   */
  onNotificationPanelClose?: EventEmitter<void>;

  /**
   * Navigate to a specific menu item route
   * Programmatically trigger navigation
   * @param item - The menu item to navigate to
   */
  navigateToItem(item: MenuItem): void;

  /**
   * Toggle the collapsed state of the menu
   * Expands if collapsed, collapses if expanded
   */
  toggleCollapse(): void;

  /**
   * Collapse the menu (sidebar/vertical only)
   * No effect if already collapsed
   */
  collapse(): void;

  /**
   * Expand the menu (sidebar/vertical only)
   * No effect if already expanded
   */
  expand(): void;

  /**
   * Mark a notification as read
   * Updates the notification state and UI
   * @param notificationId - ID of the notification to mark as read
   */
  markNotificationAsRead(notificationId: string): void;

  /**
   * Dismiss/remove a notification
   * Removes from the notification list
   * @param notificationId - ID of the notification to dismiss
   */
  dismissNotification(notificationId: string): void;

  /**
   * Clear all notifications
   * Removes all notifications from the list
   */
  clearAllNotifications(): void;

  /**
   * Open the notification panel
   * Shows the notification dropdown
   */
  openNotificationPanel(): void;

  /**
   * Close the notification panel
   * Hides the notification dropdown
   */
  closeNotificationPanel(): void;

  /**
   * Toggle the notification panel visibility
   * Opens if closed, closes if open
   */
  toggleNotificationPanel(): void;

  /**
   * Refresh/reload notification data
   * Typically calls a service to fetch fresh notifications
   */
  refreshNotifications(): void;

  /**
   * Set the active menu item
   * Updates highlighting and state
   * @param itemId - ID of the item to activate
   */
  setActiveItem(itemId: string): void;

  /**
   * Expand a menu item (show its children)
   * @param itemId - ID of the item to expand
   */
  expandItem(itemId: string): void;

  /**
   * Collapse a menu item (hide its children)
   * @param itemId - ID of the item to collapse
   */
  collapseItem(itemId: string): void;

  /**
   * Toggle expansion of a menu item
   * Expands if collapsed, collapses if expanded
   * @param itemId - ID of the item to toggle
   */
  toggleItem(itemId: string): void;

  /**
   * Filter menu items based on search query
   * Updates the filtered menu view
   * @param query - Search text to filter by
   */
  filterMenuItems(query: string): void;

  /**
   * Clear the search filter
   * Resets to showing all menu items
   */
  clearSearch(): void;

  /**
   * Get the currently active menu item
   * @returns The active MenuItem or undefined
   */
  getActiveItem(): MenuItem | undefined;

  /**
   * Get all menu items in a flat array
   * Includes nested children in depth-first order
   * @returns Flat array of all menu items
   */
  getAllMenuItems(): MenuItem[];

  /**
   * Find a menu item by ID
   * Searches recursively through children
   * @param itemId - ID of the item to find
   * @returns The MenuItem or undefined if not found
   */
  findMenuItemById(itemId: string): MenuItem | undefined;

  /**
   * Update a menu item's properties
   * Merges the provided updates with existing item data
   * @param itemId - ID of the item to update
   * @param updates - Partial MenuItem object with properties to update
   */
  updateMenuItem(itemId: string, updates: Partial<MenuItem>): void;

  /**
   * Add a new menu item
   * Optionally specify parent ID to add as a child
   * @param item - The menu item to add
   * @param parentId - Optional parent item ID for nesting
   */
  addMenuItem(item: MenuItem, parentId?: string): void;

  /**
   * Remove a menu item
   * Also removes all its children
   * @param itemId - ID of the item to remove
   */
  removeMenuItem(itemId: string): void;

  /**
   * Lifecycle hook - component initialization
   * Sets up menu, subscriptions, and initial state
   */
  ngOnInit(): void;

  /**
   * Lifecycle hook - component destruction
   * Cleans up subscriptions and persists state if enabled
   */
  ngOnDestroy(): void;

  /**
   * Lifecycle hook - after view initialization
   * Used for DOM-dependent setup
   */
  ngAfterViewInit(): void;

  /**
   * Lifecycle hook - input property changes
   * Handles updates to @Input properties
   * @param changes - Object containing changed properties
   */
  ngOnChanges(changes: unknown): void;
}
