/**
 * Portal menu module types
 * @packageDocumentation
 */

/**
 * Configuration options for the AxisAbcPortalMenuModule
 * Used when importing the module in Angular applications
 */
export interface PortalMenuModuleConfig {
  /**
   * Default menu type for all portal menu instances
   * Can be overridden per component instance
   * @default 'horizontal'
   */
  defaultMenuType?: 'horizontal' | 'vertical' | 'sidebar' | 'dropdown';

  /**
   * Default theme identifier
   * Applied to all portal menu instances unless overridden
   * @default 'light'
   */
  defaultTheme?: string;

  /**
   * Whether to enable Angular router integration by default
   * Automatically syncs menu state with router navigation
   * @default true
   */
  enableRouterIntegration?: boolean;

  /**
   * Whether to enable notification features by default
   * Controls if notification functionality is available
   * @default true
   */
  enableNotifications?: boolean;

  /**
   * Global animation settings
   * Controls animation behavior across all menu instances
   * @default true
   */
  enableAnimations?: boolean;

  /**
   * Default notification auto-refresh interval in milliseconds
   * 0 disables auto-refresh
   * @default 0
   */
  notificationRefreshInterval?: number;

  /**
   * Whether to enable keyboard navigation by default
   * Allows arrow key and enter key navigation
   * @default true
   */
  enableKeyboardNav?: boolean;

  /**
   * Whether to persist menu state in localStorage by default
   * Remembers collapsed/expanded state across sessions
   * @default false
   */
  persistState?: boolean;

  /**
   * Default z-index for menu components
   * Controls stacking order with other page elements
   * @default 1000
   */
  defaultZIndex?: number;

  /**
   * Custom icon library mapping
   * Maps icon names to CSS classes or SVG paths
   * Allows using custom icon sets
   * @example { 'home': 'fas fa-home', 'user': 'fas fa-user' }
   */
  iconMapping?: Record<string, string>;

  /**
   * Default accessibility settings
   * ARIA labels and keyboard shortcuts
   */
  accessibility?: {
    /**
     * Whether to enable screen reader support
     * Adds appropriate ARIA attributes
     * @default true
     */
    enableScreenReader?: boolean;

    /**
     * Whether to enable high contrast mode support
     * Adds additional styling for accessibility
     * @default false
     */
    enableHighContrast?: boolean;

    /**
     * Keyboard shortcut to open menu
     * Key combination (e.g., 'Alt+M', 'Ctrl+Shift+N')
     * @default undefined
     */
    menuShortcut?: string;

    /**
     * Keyboard shortcut to open notifications
     * Key combination (e.g., 'Alt+N', 'Ctrl+Shift+B')
     * @default undefined
     */
    notificationShortcut?: string;
  };

  /**
   * Localization/internationalization settings
   * Default text labels and translations
   */
  i18n?: {
    /**
     * Default language code
     * ISO 639-1 language code (e.g., 'en', 'es', 'fr')
     * @default 'en'
     */
    defaultLanguage?: string;

    /**
     * Translation key prefix
     * Prefix for looking up translation keys
     * @default 'portal-menu'
     */
    translationPrefix?: string;

    /**
     * Default text labels for UI elements
     * Can be overridden with custom translations
     */
    labels?: {
      /** Search placeholder text */
      search?: string;
      /** Notifications panel title */
      notifications?: string;
      /** "No notifications" message */
      noNotifications?: string;
      /** "Mark all as read" button text */
      markAllRead?: string;
      /** "Clear all" button text */
      clearAll?: string;
      /** "View all" link text */
      viewAll?: string;
      /** Collapse menu tooltip */
      collapse?: string;
      /** Expand menu tooltip */
      expand?: string;
      /** User profile menu label */
      profile?: string;
      /** Logout button label */
      logout?: string;
    };
  };

  /**
   * Performance optimization settings
   * Controls rendering and update behavior
   */
  performance?: {
    /**
     * Whether to use virtual scrolling for long notification lists
     * Improves performance with many notifications
     * @default false
     */
    useVirtualScrolling?: boolean;

    /**
     * Maximum number of menu items to render initially
     * Lazy-loads additional items on demand
     * 0 disables lazy loading
     * @default 0
     */
    lazyLoadThreshold?: number;

    /**
     * Whether to debounce search input
     * Reduces search filtering calls during typing
     * @default true
     */
    debounceSearch?: boolean;

    /**
     * Search debounce delay in milliseconds
     * Time to wait after typing before filtering
     * @default 300
     */
    searchDebounceDelay?: number;
  };
}

/**
 * Portal menu module interface
 * Defines the structure of the AxisAbcPortalMenuModule
 */
export interface IAxisAbcPortalMenuModule {
  /**
   * Module configuration settings
   * Applied when the module is imported
   */
  config?: PortalMenuModuleConfig;

  /**
   * Static method to configure the module with custom options
   * Used in Angular module imports
   * @param config - Configuration options
   * @returns Module with providers configured
   * @example
   * ```typescript
   * imports: [
   *   AxisAbcPortalMenuModule.forRoot({
   *     defaultMenuType: 'sidebar',
   *     enableNotifications: true
   *   })
   * ]
   * ```
   */
  forRoot?: (config?: PortalMenuModuleConfig) => IAxisAbcPortalMenuModule;

  /**
   * Static method for feature module imports
   * Used when importing in child/lazy-loaded modules
   * @param config - Optional configuration overrides
   * @returns Module configured for feature use
   * @example
   * ```typescript
   * imports: [
   *   AxisAbcPortalMenuModule.forChild({
   *     defaultTheme: 'dark'
   *   })
   * ]
   * ```
   */
  forChild?: (config?: Partial<PortalMenuModuleConfig>) => IAxisAbcPortalMenuModule;
}

/**
 * Portal menu service configuration
 * Settings for the portal menu service that manages menu state
 */
export interface PortalMenuServiceConfig {
  /**
   * API endpoint for fetching menu data
   * URL to retrieve dynamic menu configuration
   * @example '/api/menu', 'https://api.example.com/v1/navigation'
   */
  menuApiEndpoint?: string;

  /**
   * API endpoint for fetching notification data
   * URL to retrieve user notifications
   * @example '/api/notifications', 'https://api.example.com/v1/notifications'
   */
  notificationApiEndpoint?: string;

  /**
   * HTTP headers to include in API requests
   * Authentication and custom headers
   * @example { 'Authorization': 'Bearer token', 'X-App-Version': '1.0.0' }
   */
  apiHeaders?: Record<string, string>;

  /**
   * Request timeout in milliseconds
   * Maximum time to wait for API responses
   * @default 30000
   */
  apiTimeout?: number;

  /**
   * Whether to cache menu data
   * Reduces API calls by caching menu structure
   * @default true
   */
  enableCaching?: boolean;

  /**
   * Cache duration in milliseconds
   * How long to cache menu data before refreshing
   * @default 300000 (5 minutes)
   */
  cacheDuration?: number;

  /**
   * Whether to retry failed API requests
   * Automatically retries on network errors
   * @default true
   */
  enableRetry?: boolean;

  /**
   * Maximum number of retry attempts
   * How many times to retry failed requests
   * @default 3
   */
  maxRetries?: number;

  /**
   * Retry delay in milliseconds
   * Time to wait between retry attempts
   * Uses exponential backoff if enabled
   * @default 1000
   */
  retryDelay?: number;

  /**
   * Whether to use exponential backoff for retries
   * Increases delay between retry attempts
   * @default true
   */
  useExponentialBackoff?: boolean;
}

/**
 * Portal menu event bus configuration
 * Settings for the event system that coordinates menu interactions
 */
export interface PortalMenuEventBusConfig {
  /**
   * Whether to enable event logging
   * Logs all menu events to console for debugging
   * @default false
   */
  enableLogging?: boolean;

  /**
   * Whether to enable event history
   * Maintains a history of recent events
   * @default false
   */
  enableHistory?: boolean;

  /**
   * Maximum number of events to keep in history
   * Limits memory usage for event history
   * @default 100
   */
  maxHistorySize?: number;

  /**
   * Whether to enable event replay
   * Allows replaying past events for testing/debugging
   * @default false
   */
  enableReplay?: boolean;

  /**
   * Custom event handlers
   * Map of event names to handler functions
   */
  customHandlers?: Record<string, (event: unknown) => void>;
}

/**
 * Portal menu theme configuration
 * Defines color schemes and styling options
 */
export interface PortalMenuTheme {
  /**
   * Unique theme identifier
   * Used to reference this theme
   * @example 'dark', 'light', 'blue-corporate'
   */
  name: string;

  /**
   * Display name for theme
   * Human-readable theme name
   * @example 'Dark Mode', 'Light Theme', 'Corporate Blue'
   */
  displayName?: string;

  /**
   * Color palette for the theme
   * Defines all colors used in the menu
   */
  colors: {
    /**
     * Primary brand color
     * Used for highlights, active states, and branding
     * @example '#007bff', '#1976d2', 'rgb(25, 118, 210)'
     */
    primary: string;

    /**
     * Secondary accent color
     * Used for secondary actions and accents
     */
    secondary?: string;

    /**
     * Background color for menu
     * Main background color
     */
    background: string;

    /**
     * Text color on background
     * Primary text color
     */
    text: string;

    /**
     * Border color
     * Used for dividers and borders
     */
    border?: string;

    /**
     * Hover state color
     * Background color when hovering menu items
     */
    hover?: string;

    /**
     * Active state color
     * Background color for active/selected items
     */
    active?: string;

    /**
     * Disabled state color
     * Text and background for disabled items
     */
    disabled?: string;

    /**
     * Notification badge colors by severity
     */
    notifications?: {
      /** Info notification badge color */
      info?: string;
      /** Warning notification badge color */
      warning?: string;
      /** Error notification badge color */
      error?: string;
      /** Success notification badge color */
      success?: string;
    };
  };

  /**
   * Typography settings
   * Font configuration for the theme
   */
  typography?: {
    /**
     * Font family for menu text
     * CSS font-family value
     * @example '"Roboto", sans-serif', 'Arial, Helvetica, sans-serif'
     */
    fontFamily?: string;

    /**
     * Base font size
     * Default text size in the menu
     * @example '14px', '1rem'
     */
    fontSize?: string;

    /**
     * Font weight for normal text
     * @example 400, 'normal'
     */
    fontWeight?: number | string;

    /**
     * Font weight for active items
     * @example 600, 'bold'
     */
    activeFontWeight?: number | string;

    /**
     * Line height
     * Text line height for readability
     * @example 1.5, '24px'
     */
    lineHeight?: number | string;
  };

  /**
   * Spacing settings
   * Padding and margin values
   */
  spacing?: {
    /**
     * Padding for menu items
     * @example '12px 16px', '0.75rem 1rem'
     */
    itemPadding?: string;

    /**
     * Margin between menu items
     * @example '4px', '0.25rem'
     */
    itemMargin?: string;

    /**
     * Indentation for nested items
     * @example '20px', '1.25rem'
     */
    nestedIndent?: string;
  };

  /**
   * Border and shadow settings
   */
  effects?: {
    /**
     * Border radius for rounded corners
     * @example '4px', '0.25rem', '50%'
     */
    borderRadius?: string;

    /**
     * Box shadow for menu
     * CSS box-shadow value
     * @example '0 2px 8px rgba(0,0,0,0.15)'
     */
    boxShadow?: string;

    /**
     * Transition duration for animations
     * @example '200ms', '0.2s'
     */
    transitionDuration?: string;
  };

  /**
   * Custom CSS variables
   * Additional theme-specific CSS custom properties
   * @example { '--menu-width': '250px', '--header-height': '60px' }
   */
  customProperties?: Record<string, string>;
}
