/**
 * Portal menu routing and navigation types
 * @packageDocumentation
 */

import type { UrlTree } from '@angular/router';

/**
 * Navigation strategy for menu item clicks
 * Defines how the application should handle navigation
 */
export type NavigationStrategy = 'router' | 'href' | 'custom' | 'none';

/**
 * Route match mode for highlighting active menu items
 * Determines how the current route is matched against menu items
 */
export type RouteMatchMode = 'exact' | 'prefix' | 'includes' | 'regex';

/**
 * Navigation extras for Angular router navigation
 * Extended options for controlling navigation behavior
 */
export interface MenuNavigationExtras {
  /**
   * Whether to skip location change (no URL update)
   * Useful for internal state changes without history
   * @default false
   */
  skipLocationChange?: boolean;

  /**
   * Whether to replace current history entry instead of adding new
   * Prevents back button from returning to previous state
   * @default false
   */
  replaceUrl?: boolean;

  /**
   * State object to pass to the new route
   * Accessible via Router.getCurrentNavigation()
   */
  state?: Record<string, unknown>;

  /**
   * Query parameters to include in the navigation
   * Appended to the URL as ?key=value
   * @example { 'tab': 'overview', 'id': '123' }
   */
  queryParams?: Record<string, string | number | boolean>;

  /**
   * How to handle query parameters during navigation
   * - 'merge': Merge with existing query params
   * - 'preserve': Keep existing query params
   * - '': Replace all query params
   * @default ''
   */
  queryParamsHandling?: 'merge' | 'preserve' | '';

  /**
   * Fragment/hash to navigate to
   * Appended to URL as #fragment
   * @example 'section-2', 'top'
   */
  fragment?: string;

  /**
   * Whether to preserve the fragment during navigation
   * @default false
   */
  preserveFragment?: boolean;

  /**
   * Relative navigation options
   * Navigation relative to a specific route
   */
  relativeTo?: unknown;
}

/**
 * Route configuration for menu items
 * Defines how menu items map to application routes
 */
export interface MenuRouteConfig {
  /**
   * Route path or URL
   * Can be Angular route path or external URL
   * @example '/dashboard', '/reports/annual', 'https://example.com'
   */
  path: string;

  /**
   * Navigation strategy to use
   * Controls how the navigation is performed
   * @default 'router'
   */
  strategy?: NavigationStrategy;

  /**
   * Route match mode for active highlighting
   * How to match current route against this menu item
   * @default 'prefix'
   */
  matchMode?: RouteMatchMode;

  /**
   * Regular expression pattern for custom route matching
   * Used when matchMode is 'regex'
   * @example '^/reports/.*'
   */
  matchPattern?: string | RegExp;

  /**
   * Additional navigation options
   * Passed to Angular router during navigation
   */
  extras?: MenuNavigationExtras;

  /**
   * Whether this route requires authentication
   * Menu item is hidden or disabled if user is not authenticated
   * @default false
   */
  requiresAuth?: boolean;

  /**
   * Required permissions/roles for this route
   * Array of permission strings that the user must have
   * @example ['admin', 'reports.view']
   */
  requiredPermissions?: string[];

  /**
   * Custom route guard logic
   * Function that returns whether navigation is allowed
   * @returns true if navigation is allowed, false or UrlTree to redirect
   */
  canActivate?: () => boolean | UrlTree | Promise<boolean | UrlTree>;

  /**
   * Whether to preload this route
   * Loads route module in advance for faster navigation
   * @default false
   */
  preload?: boolean;

  /**
   * Custom data to attach to this route
   * Accessible in route guards and components
   */
  data?: Record<string, unknown>;

  /**
   * Child routes configuration
   * Defines nested routing structure
   */
  children?: MenuRouteConfig[];

  /**
   * Redirect configuration
   * Automatically redirect to another route
   */
  redirectTo?: string;

  /**
   * Whether this is a default/fallback route
   * Used when no other routes match
   * @default false
   */
  isDefault?: boolean;
}

/**
 * Breadcrumb item for navigation path display
 * Represents one segment in the navigation breadcrumb trail
 */
export interface BreadcrumbItem {
  /**
   * Display label for the breadcrumb
   * Text shown to the user
   */
  label: string;

  /**
   * Route path for navigation
   * Where to navigate when breadcrumb is clicked
   */
  route?: string;

  /**
   * Icon identifier for the breadcrumb
   * Optional icon to display before label
   */
  icon?: string;

  /**
   * Whether this breadcrumb is clickable
   * Current page breadcrumb is typically not clickable
   * @default true
   */
  clickable?: boolean;

  /**
   * Custom CSS class for styling
   */
  className?: string;

  /**
   * Custom data associated with this breadcrumb
   */
  customData?: Record<string, unknown>;
}

/**
 * Breadcrumb configuration options
 * Settings for breadcrumb trail display
 */
export interface BreadcrumbConfig {
  /**
   * Whether to show breadcrumbs
   * @default false
   */
  enabled?: boolean;

  /**
   * Whether to show the home/root breadcrumb
   * Adds a home icon/link at the start
   * @default true
   */
  showHome?: boolean;

  /**
   * Label for the home breadcrumb
   * @default 'Home'
   */
  homeLabel?: string;

  /**
   * Route for the home breadcrumb
   * @default '/'
   */
  homeRoute?: string;

  /**
   * Separator character between breadcrumbs
   * @default '/'
   * @example '>', '›', '|', '-'
   */
  separator?: string;

  /**
   * Whether to auto-generate breadcrumbs from route hierarchy
   * Creates breadcrumbs based on URL path segments
   * @default true
   */
  autoGenerate?: boolean;

  /**
   * Maximum number of breadcrumbs to display
   * Truncates middle items if exceeded
   * 0 means no limit
   * @default 0
   */
  maxItems?: number;

  /**
   * Custom CSS class for breadcrumb container
   */
  containerClass?: string;

  /**
   * Custom CSS class for breadcrumb items
   */
  itemClass?: string;

  /**
   * Custom CSS class for breadcrumb separator
   */
  separatorClass?: string;
}

/**
 * Route activation event data
 * Emitted when a route becomes active through menu navigation
 */
export interface RouteActivationEvent {
  /**
   * The route that was activated
   * Full route configuration
   */
  route: MenuRouteConfig;

  /**
   * Previous route (if any)
   * Route that was active before this navigation
   */
  previousRoute?: MenuRouteConfig;

  /**
   * Navigation timestamp
   * When the route activation occurred
   */
  timestamp: number;

  /**
   * Whether this was the initial page load
   * True for first navigation, false for subsequent
   */
  isInitial: boolean;

  /**
   * Navigation extras used
   * Query params, state, etc. from the navigation
   */
  navigationExtras?: MenuNavigationExtras;
}

/**
 * Route guard result
 * Return value from route guard functions
 */
export type RouteGuardResult = boolean | UrlTree | Promise<boolean | UrlTree>;

/**
 * Custom route guard function
 * Determines whether navigation to a route is allowed
 */
export type RouteGuardFn = (route: MenuRouteConfig) => RouteGuardResult;

/**
 * Route resolver function
 * Resolves data before route activation
 */
export type RouteResolverFn<T = unknown> = (route: MenuRouteConfig) => T | Promise<T>;

/**
 * Navigation history entry
 * Represents a past navigation for history tracking
 */
export interface NavigationHistoryEntry {
  /**
   * Route that was navigated to
   */
  route: MenuRouteConfig;

  /**
   * Timestamp of navigation
   */
  timestamp: number;

  /**
   * URL that was navigated to
   */
  url: string;

  /**
   * Navigation extras used
   */
  extras?: MenuNavigationExtras;

  /**
   * User-triggered or automatic navigation
   */
  trigger: 'user' | 'auto' | 'programmatic';
}

/**
 * Navigation history configuration
 * Settings for tracking navigation history
 */
export interface NavigationHistoryConfig {
  /**
   * Whether to enable navigation history tracking
   * @default false
   */
  enabled?: boolean;

  /**
   * Maximum number of history entries to keep
   * Limits memory usage
   * @default 50
   */
  maxSize?: number;

  /**
   * Whether to persist history to localStorage
   * Remembers history across sessions
   * @default false
   */
  persist?: boolean;

  /**
   * localStorage key for persisted history
   * @default 'axis-portal-menu-history'
   */
  storageKey?: string;

  /**
   * Whether to track query parameters in history
   * @default true
   */
  trackQueryParams?: boolean;

  /**
   * Whether to track fragment/hash in history
   * @default true
   */
  trackFragment?: boolean;
}

/**
 * Route preloading strategy configuration
 * Controls how and when routes are preloaded
 */
export interface RoutePreloadingConfig {
  /**
   * Whether to enable route preloading
   * @default false
   */
  enabled?: boolean;

  /**
   * Preloading strategy
   * - 'all': Preload all lazy routes immediately
   * - 'visible': Preload routes for visible menu items
   * - 'hover': Preload on menu item hover
   * - 'custom': Use custom preload logic
   * @default 'visible'
   */
  strategy?: 'all' | 'visible' | 'hover' | 'custom';

  /**
   * Delay before preloading in milliseconds
   * Useful for hover strategy to avoid unnecessary loads
   * @default 100
   */
  delay?: number;

  /**
   * Custom preload function
   * Determines which routes to preload
   */
  shouldPreload?: (route: MenuRouteConfig) => boolean;

  /**
   * Maximum number of concurrent preload operations
   * Limits network/memory usage
   * @default 3
   */
  maxConcurrent?: number;
}

/**
 * External link configuration
 * Settings for handling external links in the menu
 */
export interface ExternalLinkConfig {
  /**
   * Whether to show an external link icon
   * Indicates that link opens in new context
   * @default true
   */
  showIcon?: boolean;

  /**
   * Icon to use for external links
   * @default 'external-link'
   */
  icon?: string;

  /**
   * Warning message before navigating to external links
   * Security warning for leaving the application
   */
  warningMessage?: string;

  /**
   * Whether to require confirmation for external links
   * Shows confirmation dialog before opening
   * @default false
   */
  requireConfirmation?: boolean;

  /**
   * Domains to treat as internal
   * Links to these domains won't show external indicators
   * @example ['example.com', 'app.example.com']
   */
  trustedDomains?: string[];

  /**
   * Whether to add rel="noopener noreferrer" to external links
   * Security best practice for target="_blank" links
   * @default true
   */
  addSecurityAttrs?: boolean;
}

/**
 * Deep linking configuration
 * Settings for handling deep links and bookmarks
 */
export interface DeepLinkingConfig {
  /**
   * Whether to enable deep linking
   * Allows direct navigation to nested menu items via URL
   * @default true
   */
  enabled?: boolean;

  /**
   * Whether to automatically expand parent menu items for deep links
   * Opens nested menus to show the active item
   * @default true
   */
  autoExpandParents?: boolean;

  /**
   * Whether to scroll to the active menu item on deep link
   * Ensures active item is visible
   * @default true
   */
  scrollToActive?: boolean;

  /**
   * Whether to validate deep link routes
   * Returns 404 or redirects for invalid routes
   * @default true
   */
  validateRoutes?: boolean;

  /**
   * Fallback route for invalid deep links
   * Where to redirect when route is not found
   * @default '/'
   */
  fallbackRoute?: string;
}
