/**
 * Common types for Axis ABC Portal Menu
 * @packageDocumentation
 */

/**
 * Menu type enumeration for different menu display modes
 * Defines how the portal menu is rendered and behaves
 */
export type MenuType = 'horizontal' | 'vertical' | 'sidebar' | 'dropdown';

/**
 * Navigation target options for menu items
 * Specifies how links should be opened when clicked
 */
export type NavigationTarget = '_self' | '_blank' | '_parent' | '_top';

/**
 * Menu item alignment options
 * Controls the visual alignment of menu items within the container
 */
export type MenuAlignment = 'left' | 'center' | 'right';

/**
 * Icon position relative to menu item text
 * Defines where the icon appears in relation to the label
 */
export type IconPosition = 'left' | 'right' | 'top' | 'bottom';

/**
 * Menu item state
 * Represents the current interactive state of a menu item
 */
export type MenuItemState = 'default' | 'active' | 'disabled' | 'hover';

/**
 * Notification severity levels
 * Used for styling and prioritizing notification badges
 */
export type NotificationSeverity = 'info' | 'warning' | 'error' | 'success';

/**
 * Base interface for menu item data
 * Represents a single navigation item in the portal menu
 */
export interface MenuItem {
  /**
   * Unique identifier for the menu item
   * Used for tracking, routing, and state management
   */
  id: string;

  /**
   * Display text shown to the user
   * Should be concise and descriptive of the destination or action
   */
  label: string;

  /**
   * Navigation route or URL path
   * Can be an Angular route path or external URL
   * @example '/dashboard', 'https://example.com', '/reports/annual'
   */
  route?: string;

  /**
   * Icon identifier or class name
   * References an icon from the icon library (e.g., Material Icons, Font Awesome)
   * @example 'home', 'fa-dashboard', 'material-icons:menu'
   */
  icon?: string;

  /**
   * Position of the icon relative to the label
   * Controls the visual layout of the menu item
   * @default 'left'
   */
  iconPosition?: IconPosition;

  /**
   * Tooltip text displayed on hover
   * Provides additional context or help information
   */
  tooltip?: string;

  /**
   * Whether the menu item is disabled
   * Disabled items are visible but not clickable
   * @default false
   */
  disabled?: boolean;

  /**
   * Whether the menu item is currently active/selected
   * Typically set based on the current route
   * @default false
   */
  active?: boolean;

  /**
   * Link target attribute
   * Controls how the navigation destination is opened
   * @default '_self'
   */
  target?: NavigationTarget;

  /**
   * Nested child menu items
   * Creates a hierarchical menu structure with sub-menus
   */
  children?: MenuItem[];

  /**
   * Badge or notification count
   * Displays a numeric indicator on the menu item
   * @example 5, 99, 999+
   */
  badge?: number | string;

  /**
   * Badge color or severity level
   * Styles the notification badge appropriately
   */
  badgeSeverity?: NotificationSeverity;

  /**
   * Custom CSS class names
   * Allows for additional styling customization
   */
  className?: string;

  /**
   * Custom data object
   * Stores arbitrary metadata associated with the menu item
   */
  customData?: Record<string, unknown>;

  /**
   * Required permission or role
   * Menu item is only shown to users with this permission
   * @example 'admin', 'user.read', 'reports.view'
   */
  permission?: string;

  /**
   * Whether the menu item should be hidden
   * Differs from disabled - hidden items are not rendered at all
   * @default false
   */
  hidden?: boolean;

  /**
   * Sort order/priority
   * Lower numbers appear first in the menu
   */
  order?: number;
}

/**
 * Menu section divider configuration
 * Creates visual separations between groups of menu items
 */
export interface MenuDivider {
  /**
   * Type identifier for the divider
   * Always set to 'divider' to distinguish from menu items
   */
  type: 'divider';

  /**
   * Optional label for the divider section
   * Creates a labeled section header
   */
  label?: string;

  /**
   * Custom CSS class names
   * Allows styling customization of the divider
   */
  className?: string;
}

/**
 * Complete menu object containing all menu data
 * Represents the full navigation structure for the portal
 */
export interface MenuObject {
  /**
   * Array of menu items and dividers
   * Defines the complete navigation structure in display order
   */
  items: (MenuItem | MenuDivider)[];

  /**
   * Menu title or header text
   * Displayed at the top of the menu
   */
  title?: string;

  /**
   * Logo URL or path
   * Displayed in the menu header
   */
  logo?: string;

  /**
   * Logo click action route
   * Where to navigate when the logo is clicked
   * @default '/'
   */
  logoRoute?: string;

  /**
   * Visual alignment of menu items
   * Controls the overall menu layout
   * @default 'left'
   */
  alignment?: MenuAlignment;

  /**
   * Whether to show icons for menu items
   * Global toggle for icon visibility
   * @default true
   */
  showIcons?: boolean;

  /**
   * Whether to show badges/notifications
   * Global toggle for badge visibility
   * @default true
   */
  showBadges?: boolean;

  /**
   * Whether the menu is collapsible
   * Enables collapse/expand behavior for the menu
   * @default false
   */
  collapsible?: boolean;

  /**
   * Initial collapsed state
   * Whether the menu starts in collapsed mode
   * @default false
   */
  collapsed?: boolean;

  /**
   * Custom theme identifier
   * References a predefined theme or style variant
   * @example 'dark', 'light', 'blue', 'custom'
   */
  theme?: string;
}

/**
 * Notification item data structure
 * Represents a single notification in the notification center
 */
export interface NotificationItem {
  /**
   * Unique notification identifier
   * Used for tracking read/unread status and dismissal
   */
  id: string;

  /**
   * Notification title or heading
   * Brief summary of the notification
   */
  title: string;

  /**
   * Detailed notification message
   * Full description or content of the notification
   */
  message: string;

  /**
   * Notification severity or type
   * Determines styling and urgency
   */
  severity: NotificationSeverity;

  /**
   * Timestamp of when the notification was created
   * ISO 8601 date string or Date object
   * @example '2026-01-15T10:30:00Z'
   */
  timestamp: string | Date;

  /**
   * Whether the notification has been read
   * Used for visual distinction between new and viewed notifications
   * @default false
   */
  read?: boolean;

  /**
   * Icon identifier for the notification
   * Visual indicator of notification type
   */
  icon?: string;

  /**
   * Action button configuration
   * Defines clickable actions within the notification
   */
  action?: {
    /**
     * Action button label text
     */
    label: string;

    /**
     * Navigation route when action is clicked
     */
    route?: string;

    /**
     * Callback function when action is clicked
     */
    callback?: () => void;
  };

  /**
   * Whether the notification is dismissible
   * If true, shows a close/dismiss button
   * @default true
   */
  dismissible?: boolean;

  /**
   * Custom data associated with the notification
   * Stores additional metadata or context
   */
  customData?: Record<string, unknown>;
}

/**
 * Notification object containing all notification data
 * Represents the complete notification center state
 */
export interface NotificationObject {
  /**
   * Array of notification items
   * All available notifications in chronological order (newest first)
   */
  items: NotificationItem[];

  /**
   * Total count of notifications
   * Used for display in badges and headers
   */
  totalCount: number;

  /**
   * Count of unread notifications
   * Used for badge display on notification icon
   */
  unreadCount: number;

  /**
   * Whether to show the notification panel
   * Controls visibility of the notification dropdown/panel
   * @default false
   */
  visible?: boolean;

  /**
   * Maximum number of notifications to display
   * Limits the visible list size
   * @default 10
   */
  maxVisible?: number;

  /**
   * Whether to enable notification sounds
   * Plays audio alert for new notifications
   * @default false
   */
  enableSound?: boolean;

  /**
   * Custom CSS class for notification panel
   * Allows styling customization
   */
  className?: string;
}

/**
 * User profile information displayed in the menu
 * Represents the currently authenticated user's details
 */
export interface UserProfile {
  /**
   * Unique user identifier
   * Primary key for the user
   */
  id: string;

  /**
   * User's full display name
   * Shown in the menu header or profile section
   */
  name: string;

  /**
   * User's email address
   * Contact information displayed in profile
   */
  email?: string;

  /**
   * URL or path to user's avatar image
   * Profile picture displayed in the menu
   */
  avatar?: string;

  /**
   * User's role or title
   * Job title or role description
   * @example 'Administrator', 'Manager', 'Developer'
   */
  role?: string;

  /**
   * User's department or organization
   * Additional context about the user
   */
  department?: string;

  /**
   * Additional custom profile data
   * Flexible storage for application-specific user data
   */
  customData?: Record<string, unknown>;
}

/**
 * Menu interaction event data
 * Emitted when user interacts with menu items
 */
export interface MenuEvent {
  /**
   * Type of menu event that occurred
   * Describes the user's interaction
   */
  type: 'click' | 'select' | 'collapse' | 'expand' | 'hover';

  /**
   * The menu item that triggered the event
   * Reference to the MenuItem object
   */
  item: MenuItem;

  /**
   * Original DOM event
   * Native browser event object
   */
  originalEvent?: Event;

  /**
   * Timestamp when the event occurred
   * Milliseconds since epoch
   */
  timestamp: number;
}

/**
 * Notification interaction event data
 * Emitted when user interacts with notifications
 */
export interface NotificationEvent {
  /**
   * Type of notification event that occurred
   * Describes the user's action
   */
  type: 'read' | 'dismiss' | 'action' | 'clear-all';

  /**
   * The notification item that triggered the event
   * Reference to the NotificationItem object
   * Undefined for 'clear-all' events
   */
  item?: NotificationItem;

  /**
   * Original DOM event
   * Native browser event object
   */
  originalEvent?: Event;

  /**
   * Timestamp when the event occurred
   * Milliseconds since epoch
   */
  timestamp: number;
}
