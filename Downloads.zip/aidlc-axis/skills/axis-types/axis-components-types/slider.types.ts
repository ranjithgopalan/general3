/**
 * @file Slider Component Types
 * @description Type definitions for range slider component with single or dual handles.
 * Supports custom formatting, tooltips, keyboard navigation, and configurable behavior.
 * @module types/slider
 * @packageDocumentation
 */

import type { EventEmitter, ElementRef, Renderer2 } from '@angular/core';
import type { ControlValueAccessor, FormControl } from '@angular/forms';
import type { BaseComponentProps } from './component-common.types';

/**
 * Slider value formatter interface
 *
 * Interface for custom formatting of slider values.
 *
 * @interface NouiFormatter
 *
 * @example
 * ```typescript
 * const currencyFormatter: NouiFormatter = {
 *   to: (value: number) => `$${value.toFixed(2)}`,
 *   from: (value: string) => parseFloat(value.replace('$', ''))
 * };
 *
 * const percentFormatter: NouiFormatter = {
 *   to: (value: number) => `${value}%`,
 *   from: (value: string) => parseInt(value.replace('%', ''))
 * };
 * ```
 */
export interface NouiFormatter {
  /**
   * Format number to string
   * Convert slider value to display string
   *
   * @param value - Numeric slider value
   * @returns Formatted string
   * @example (100) => "$100.00"
   */
  to(value: number): string;

  /**
   * Parse string to number
   * Convert display string back to numeric value
   *
   * @param value - Formatted string
   * @returns Numeric value
   * @example ("$100.00") => 100
   */
  from(value: string): number;
}

/**
 * Slider component properties
 *
 * Range slider with single or dual handles, custom formatting, and tooltips.
 *
 * @interface SliderComponentProps
 * @extends BaseComponentProps
 *
 * @example
 * ```typescript
 * // Single handle slider
 * const singleSlider: Partial<SliderComponentProps> = {
 *   min: 0,
 *   max: 100,
 *   step: 1,
 *   model: 50,
 *   connect: [true, false]
 * };
 *
 * // Range slider with two handles
 * const rangeSlider: Partial<SliderComponentProps> = {
 *   min: 0,
 *   max: 1000,
 *   step: 10,
 *   model: [200, 800],
 *   connect: [false, true, false],
 *   tooltips: [true, true]
 * };
 * ```
 */
export interface SliderComponentProps extends BaseComponentProps {
  /**
   * Minimum slider value
   * Lower bound of slider range
   *
   * @type {number}
   * @default 0
   * @example 0, -100, 1
   */
  min?: number;

  /**
   * Maximum slider value
   * Upper bound of slider range
   *
   * @type {number}
   * @default 100
   * @example 100, 1000, 10
   */
  max?: number;

  /**
   * Step increment value
   * Amount slider changes per step
   *
   * @type {number}
   * @default 1
   * @example 1, 5, 0.1
   */
  step?: number;

  /**
   * Current slider value(s)
   * Single value or array for range slider
   *
   * @type {number | number[]}
   * @example 50 // single handle, [20, 80] // range
   */
  model?: number | number[];

  /**
   * Slider behavior
   * How handles interact with each other
   *
   * @type {string}
   * @default 'tap'
   * @example 'tap', 'drag', 'fixed', 'snap'
   */
  behaviour?: string;

  /**
   * Connect segments between handles
   * Array indicating which segments are connected
   *
   * @type {boolean[]}
   * @default [true, false]
   * @example [true, false] // single, [false, true, false] // range
   */
  connect?: boolean[];

  /**
   * Slider direction
   * Orientation of the slider
   *
   * @type {string}
   * @default 'ltr'
   * @example 'ltr' // left-to-right, 'rtl' // right-to-left
   */
  direction?: string;

  /**
   * Slider label
   * Accessible label for the slider
   *
   * @type {string}
   * @example 'Price range', 'Volume'
   */
  label?: string;

  /**
   * Handle movement limit
   * Maximum distance handles can be moved
   *
   * @type {number}
   * @example 10, 50
   */
  limit?: number;

  /**
   * Value formatter
   * Custom formatting for values
   *
   * @type {NouiFormatter}
   * @see NouiFormatter
   */
  format?: NouiFormatter;

  /**
   * Page step increment
   * Step size for Page Up/Down keys
   *
   * @type {number}
   * @default 10
   * @example 10, 5, 1
   */
  pageSteps?: number;

  /**
   * Additional slider configuration
   * Extended configuration options
   *
   * @type {unknown}
   */
  config?: unknown;

  /**
   * Whether to enable keyboard navigation
   * Allow keyboard control
   *
   * @type {boolean}
   * @default true
   */
  keyboard?: boolean;

  /**
   * Custom keydown handler
   * Override default keyboard behavior
   *
   * @type {unknown}
   */
  onKeydown?: unknown;

  /**
   * Form control
   * Associated form control
   *
   * @type {FormControl}
   */
  formControl?: FormControl;

  /**
   * Tooltip configuration
   * Enable/configure tooltips for handles
   *
   * @type {unknown[]}
   * @example [true, true] // tooltips on both handles
   */
  tooltips?: unknown[];

  /**
   * Value text for accessibility
   * ARIA valuetext for handles
   *
   * @type {unknown[]}
   */
  valuetext?: unknown[];

  /**
   * Whether to hide mark divider
   * Hide tick marks on slider
   *
   * @type {boolean}
   * @default false
   */
  hideMarkDivider?: boolean;

  /**
   * Whether to hide tooltip label
   * Hide label inside tooltip
   *
   * @type {boolean}
   * @default false
   */
  hideToolTipLabel?: boolean;

  /**
   * Whether to hide mark divider values
   * Hide value labels on tick marks
   *
   * @type {boolean}
   * @default false
   */
  hideMarkDividerValues?: boolean;
}

/**
 * Slider component interface
 *
 * Full slider component with form control integration and event handling.
 *
 * @interface ISliderComponent
 * @extends SliderComponentProps
 * @extends ControlValueAccessor
 *
 * @example
 * ```typescript
 * // Handle slider events
 * sliderComponent.change.subscribe((values) => {
 *   console.log('Slider changed:', values);
 * });
 *
 * sliderComponent.slide.subscribe((values) => {
 *   console.log('Slider sliding:', values);
 * });
 *
 * // Programmatic control
 * sliderComponent.reset();
 * sliderComponent.disableSlider(true);
 * ```
 */
export interface ISliderComponent
  extends SliderComponentProps,
    ControlValueAccessor {
  /**
   * Element reference
   * Reference to slider element
   *
   * @type {ElementRef}
   */
  el: ElementRef;

  /**
   * Renderer for DOM manipulation
   * Angular renderer service
   *
   * @type {Renderer2}
   */
  renderer: Renderer2;

  /**
   * Event emitted on value change
   * Fires when slider value changes
   *
   * @type {EventEmitter<number | number[]>}
   */
  change: EventEmitter<number | number[]>;

  /**
   * Event emitted on slider update
   * Fires during slider interaction
   *
   * @type {EventEmitter<number | number[]>}
   */
  update: EventEmitter<number | number[]>;

  /**
   * Event emitted while sliding
   * Fires continuously during drag
   *
   * @type {EventEmitter<number | number[]>}
   */
  slide: EventEmitter<number | number[]>;

  /**
   * Event emitted when value is set
   * Fires when value is programmatically set
   *
   * @type {EventEmitter<number | number[]>}
   */
  set: EventEmitter<number | number[]>;

  /**
   * Event emitted when slide starts
   * Fires when user starts dragging
   *
   * @type {EventEmitter<number | number[]>}
   */
  start: EventEmitter<number | number[]>;

  /**
   * Event emitted when slide ends
   * Fires when user stops dragging
   *
   * @type {EventEmitter<number | number[]>}
   */
  end: EventEmitter<number | number[]>;

  /**
   * noUiSlider instance
   * Underlying slider library instance
   *
   * @type {unknown}
   */
  slider: unknown;

  /**
   * Slider handle elements
   * DOM elements for handles
   *
   * @type {unknown[]}
   */
  handles: unknown[];

  /**
   * Slider element reference
   * Reference to slider DOM element
   *
   * @type {unknown}
   */
  sliderRef: unknown;

  /**
   * Current slider value
   * Internal value state
   *
   * @type {number | number[]}
   */
  value: number | number[];

  /**
   * On change callback
   * Form control change handler
   *
   * @type {(value: number | number[]) => void}
   */
  onChange: (value: number | number[]) => void;

  /**
   * On touched callback
   * Form control touched handler
   *
   * @type {() => void}
   */
  onTouched: () => void;

  /**
   * Set tooltip CSS class
   * Apply custom tooltip styling
   */
  setTooltipClass(): void;

  /**
   * Convert string values to numbers
   * Parse formatted values
   *
   * @param values - String values array
   * @returns Numeric value or array
   */
  toValues(values: string[]): number | number[];

  /**
   * Handle slider events
   * Internal event handler
   *
   * @param event - Event object
   */
  eventHandler(event: unknown): void;

  /**
   * Default keyboard event handler
   * Handle keyboard navigation
   *
   * @param event - Keyboard event
   */
  defaultKeyHandler(event: KeyboardEvent): void;

  /**
   * Disable or enable slider
   * Set slider disabled state
   *
   * @param disabled - true to disable, false to enable
   */
  disableSlider(disabled: boolean): void;

  /**
   * Reset slider to initial state
   * Reset to default values
   */
  reset(): void;
}
