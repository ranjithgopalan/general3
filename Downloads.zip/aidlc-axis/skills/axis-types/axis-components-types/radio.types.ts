/**
 * Radio button component types for Axis Components library
 * @packageDocumentation
 */

import type { EventEmitter, ChangeDetectorRef } from '@angular/core';
import type {
  FormComponentProps,
  ChangeDetectableComponent
} from './component-common.types';

/**
 * Radio button component properties
 */
export interface RadioButtonComponentProps
  extends FormComponentProps,
    ChangeDetectableComponent {
  /** Whether radio button is checked */
  checked?: boolean;
  /** Radio button heading/label */
  heading?: string;
  /** Radio button group name */
  name?: string;
}

/**
 * Radio button component interface
 */
export interface IRadioButtonComponent extends RadioButtonComponentProps {
  /** Change detector reference */
  _changeDetRef: ChangeDetectorRef;
  /** Event emitted on change */
  onChangeEvent: EventEmitter<string | number | boolean>;
  /** Label section element */
  labelSection: HTMLElement;
  /** Initial inner HTML */
  initialInnerHtml: string;
  /** Handle change event */
  onChange(e: Event): void;
  /** Emit blur event */
  emitOnBlurEvent(): void;
}

/**
 * Radio button wrapper component interface
 */
export interface IRadioButtonWrapperComponent {
  /** Wrapper content */
  content?: string;
}
