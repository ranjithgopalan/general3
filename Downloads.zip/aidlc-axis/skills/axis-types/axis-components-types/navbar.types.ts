/**
 * Navbar component types for Axis Components library
 * @packageDocumentation
 */

import type { EventEmitter } from '@angular/core';
import type { BaseComponentProps } from './component-common.types';

/**
 * Navbar position options
 */
export type NavbarPosition = 'fixed-top' | 'fixed-bottom' | 'sticky-top' | 'static';

/**
 * Navbar theme options
 */
export type NavbarTheme = 'light' | 'dark' | 'primary' | 'transparent';

/**
 * Navbar item configuration
 */
export interface NavbarItem {
  /** Item label */
  label: string;
  /** Item link/route */
  link?: string;
  /** Item icon */
  icon?: string;
  /** Whether item is active */
  active?: boolean;
  /** Whether item is disabled */
  disabled?: boolean;
  /** Child/dropdown items */
  children?: NavbarItem[];
  /** Custom action handler */
  action?: () => void;
  /** Badge text */
  badge?: string;
  /** Badge color/variant */
  badgeVariant?: string;
  /** Additional custom properties */
  [key: string]: unknown;
}

/**
 * Navbar component properties
 */
export interface NavbarComponentProps extends BaseComponentProps {
  /** Navbar brand/logo text */
  brand?: string;
  /** Navbar brand image URL */
  brandImage?: string;
  /** Navbar brand link */
  brandLink?: string;
  /** Navbar theme */
  theme?: NavbarTheme;
  /** Navbar position */
  position?: NavbarPosition;
  /** Navigation items */
  items?: NavbarItem[];
  /** Whether navbar is expanded (mobile) */
  expanded?: boolean;
  /** Whether to show toggle button (mobile) */
  showToggle?: boolean;
  /** Whether navbar is collapsible */
  collapsible?: boolean;
  /** Custom CSS classes for navbar */
  navbarClasses?: string;
  /** Custom CSS classes for container */
  containerClasses?: string;
}

/**
 * Navbar component interface
 */
export interface INavbarComponent extends NavbarComponentProps {
  /** Event emitted when navbar item is clicked */
  onItemClick: EventEmitter<NavbarItem>;
  /** Event emitted when navbar is expanded/collapsed */
  onToggle: EventEmitter<boolean>;
  /** Event emitted when brand is clicked */
  onBrandClick: EventEmitter<Event>;
  /** Toggle navbar expansion (mobile) */
  toggle(): void;
  /** Expand navbar (mobile) */
  expand(): void;
  /** Collapse navbar (mobile) */
  collapse(): void;
  /** Handle item click */
  handleItemClick(item: NavbarItem): void;
  /** Set active item */
  setActiveItem(item: NavbarItem): void;
  /** Get active item */
  getActiveItem(): NavbarItem | null;
}

/**
 * Navbar service interface
 */
export interface INavbarService {
  /** Set navbar items */
  setItems(items: NavbarItem[]): void;
  /** Get navbar items */
  getItems(): NavbarItem[];
  /** Update navbar item */
  updateItem(index: number, item: Partial<NavbarItem>): void;
  /** Add navbar item */
  addItem(item: NavbarItem, index?: number): void;
  /** Remove navbar item */
  removeItem(index: number): void;
  /** Set active item by index */
  setActiveItemByIndex(index: number): void;
  /** Set active item by link */
  setActiveItemByLink(link: string): void;
}
