/**
 * Modal component types for Axis Components library
 * @packageDocumentation
 */

import type { EventEmitter, ElementRef, ChangeDetectorRef, Renderer2 } from '@angular/core';
import type { BaseComponentProps } from './component-common.types';

/**
 * Options for where to set focus automatically on dialog open
 */
export type AutoFocusTarget = 'first-tabbable' | 'first-heading';

/**
 * Modal backdrop configuration
 */
export type ModalBackdrop = 'static' | boolean;

/**
 * Modal size options
 */
export type ModalSize = 'sm' | 'small' | 'md' | 'medium' | 'lg' | 'large' | 'xl' | 'full';

/**
 * Modal component properties
 */
export interface ModalComponentProps extends BaseComponentProps {
  /** Modal heading/title */
  heading?: string;
  /** Modal size */
  size?: ModalSize;
  /** Modal height */
  height?: string;
  /** Modal top position */
  top?: string;
  /** Data top attribute */
  dataTop?: string;
  /** Modal role for accessibility */
  modalRole?: string;
  /** Enable modal animations */
  animation?: boolean;
  /** Backdrop configuration */
  backdrop?: ModalBackdrop;
  /** Whether to close on escape key */
  closeOnEscape?: boolean;
  /** Whether to close on outside click */
  closeOnOutsideClick?: boolean;
  /** Whether to show close button */
  closeButton?: boolean;
  /** Submit button label */
  submitButtonLabel?: string;
  /** Cancel button label */
  cancelButtonLabel?: string;
  /** Where to focus on open */
  autoFocus?: AutoFocusTarget | string | boolean;
  /** Whether to restore focus on close */
  restoreFocus?: boolean;
}

/**
 * Modal component interface
 */
export interface IModalComponent extends ModalComponentProps {
  /** Change detector reference */
  changeDetectorRef: ChangeDetectorRef;
  /** Renderer for DOM manipulation */
  renderer: Renderer2;
  /** Element reference */
  el: ElementRef;
  /** Event emitted before modal closes */
  onBeforeClose: EventEmitter<unknown>;
  /** Event emitted when modal closes */
  onClose: EventEmitter<unknown>;
  /** Event emitted when modal opens */
  onOpen: EventEmitter<unknown>;
  /** Event emitted on submit button click */
  onSubmit: EventEmitter<unknown>;
  /** Whether modal is currently opened */
  isOpened: boolean;
  /** Modal height in pixels */
  modalHeight: number;
  /** Modal body height in pixels */
  modalBodyHeight: number;
  /** Maximum height for modal */
  maxHeight: number;
  /** Minimum height for modal */
  minHeight: number;
  /** Modal root element reference */
  modalRoot: ElementRef;
  /** Modal heading element reference */
  modalHeading: ElementRef;
  /** Modal body element reference */
  modalBody: ElementRef;
  /** Modal wrapper element reference */
  modalWrapper: ElementRef;
  /** Modal footer element reference */
  modalFooter: ElementRef;
  /** Button that opened the modal */
  openButton: HTMLElement;
  /** Unique key for modal instance */
  uniqueKey: string;
  /** Open the modal */
  open(...args: unknown[]): void;
  /** Close the modal */
  close(...args: unknown[]): void;
  /** Set focus to modal elements */
  setFocus(): void;
  /** Calculate modal height */
  calculateModalHeight(): void;
  /** Handle focus within modal */
  handleFocus(event: KeyboardEvent): void;
  /** Prevent modal from closing */
  preventClosing(event: MouseEvent): void;
}

/**
 * Modal header component interface
 */
export interface IModalHeaderComponent {
  /** Modal header content */
  content?: string;
}

/**
 * Modal content component interface
 */
export interface IModalContentComponent {
  /** Modal content */
  content?: string;
}

/**
 * Modal footer component interface
 */
export interface IModalFooterComponent {
  /** Modal footer content */
  content?: string;
}

/**
 * Modal service configuration
 */
export interface ModalConfig extends ModalComponentProps {
  /** Modal content component or template */
  content?: unknown;
  /** Modal data to pass to content */
  data?: Record<string, unknown>;
}

/**
 * Modal service interface for programmatically creating modals
 */
export interface IModalService {
  /** Component reference for created modal */
  componentRef: ComponentRef<unknown>;
  /** Container element for modal */
  containerEl: HTMLElement;
  /** Unique key for modal instance */
  uniqueKey: string;
  /** Create a modal component programmatically */
  createModalComponent(component: unknown, data?: unknown): ComponentRef<unknown>;
  /** Open the created modal */
  openModal(): void;
  /** Destroy the modal component */
  destroyModalComponent(): void;
}

/**
 * ComponentRef import for modal service
 */
import type { ComponentRef } from '@angular/core';
