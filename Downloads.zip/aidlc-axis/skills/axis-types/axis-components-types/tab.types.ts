/**
 * @file Tab Component Types
 * @description Type definitions for tabbed navigation interface with responsive and vertical layouts.
 * Supports tab switching, lazy loading, custom templates, and dropdown overflow handling.
 * @module types/tab
 * @packageDocumentation
 */

import type {
  EventEmitter,
  ElementRef,
  ChangeDetectorRef,
  QueryList,
  ViewContainerRef,
  TemplateRef
} from '@angular/core';
import type { Subscription } from 'rxjs';
import type { BaseComponentProps } from './component-common.types';

/**
 * Tab set component properties
 *
 * Container component that manages multiple tabs with navigation controls.
 *
 * @interface TabSetComponentProps
 * @extends BaseComponentProps
 *
 * @example
 * ```typescript
 * const tabSetConfig: Partial<TabSetComponentProps> = {
 *   vertical: false,
 *   isScroll: true,
 *   responsive: true,
 *   ucid: 'main-tabs'
 * };
 * ```
 */
export interface TabSetComponentProps extends BaseComponentProps {
  /**
   * Whether tabs are displayed vertically
   * Vertical tab layout instead of horizontal
   *
   * @type {boolean}
   * @default false
   */
  vertical?: boolean;

  /**
   * Whether tabs are scrollable
   * Enable horizontal scrolling for many tabs
   *
   * @type {boolean}
   * @default false
   */
  isScroll?: boolean;

  /**
   * Whether tab set is responsive
   * Adapt layout to screen size
   *
   * @type {boolean}
   * @default true
   */
  responsive?: boolean;

  /**
   * Whether to show mobile/tablet view
   * Force mobile layout
   *
   * @type {boolean}
   * @default false
   */
  isMobile?: boolean;

  /**
   * Tab options configuration
   * Additional configuration for tabs
   *
   * @type {unknown}
   */
  options?: unknown;

  /**
   * Unique component ID
   * Identifier for tab set
   *
   * @type {string}
   * @example 'main-tabs', 'settings-tabs'
   */
  ucid?: string;

  /**
   * Whether tabs are in popup mode
   * Display tabs in popup/modal context
   *
   * @type {boolean}
   * @default false
   */
  isPopup?: boolean;
}

/**
 * Tab set component interface
 *
 * Manages tab collection with selection, navigation, and responsive behavior.
 *
 * @interface ITabSetComponent
 * @extends TabSetComponentProps
 *
 * @example
 * ```typescript
 * // Programmatically change tabs
 * tabSetComponent.setActiveTabWithIndex(2);
 * tabSetComponent.changeActiveTab(tab, event);
 *
 * // Listen for tab changes
 * tabSetComponent.tabChange.subscribe((tab) => {
 *   console.log('Tab changed:', tab.heading);
 * });
 * ```
 */
export interface ITabSetComponent extends TabSetComponentProps {
  /**
   * Change detector reference
   * Angular change detection
   *
   * @type {ChangeDetectorRef}
   */
  changeDetectorRef: ChangeDetectorRef;

  /**
   * Element reference
   * Reference to tab set element
   *
   * @type {ElementRef}
   */
  el: ElementRef;

  /**
   * Event emitted when tab is selected
   * Fires when user clicks a tab
   *
   * @type {EventEmitter<ITabComponent>}
   */
  onTabSelection: EventEmitter<ITabComponent>;

  /**
   * Event emitted when content initializes
   * Fires after tab content is initialized
   *
   * @type {EventEmitter<unknown>}
   */
  onContentInit: EventEmitter<unknown>;

  /**
   * Event emitted when tab changes
   * Primary tab change event
   *
   * @type {EventEmitter<ITabComponent>}
   */
  tabChange: EventEmitter<ITabComponent>;

  /**
   * Query list of tab components
   * Collection of child tabs
   *
   * @type {QueryList<ITabComponent>}
   */
  tabs: QueryList<ITabComponent>;

  /**
   * Query list of tab option components
   * Collection of tab options
   *
   * @type {QueryList<unknown>}
   */
  tabOptionsRef: QueryList<unknown>;

  /**
   * Tab element reference
   * Reference to tab container element
   *
   * @type {ElementRef}
   */
  tabRef: ElementRef;

  /**
   * Query list of tab item view containers
   * Collection of tab content containers
   *
   * @type {QueryList<ViewContainerRef>}
   */
  tabItems: QueryList<ViewContainerRef>;

  /**
   * Dropdown tabs array
   * Tabs that overflow into dropdown
   *
   * @type {unknown[]}
   */
  dropdownTabs: unknown[];

  /**
   * Dropdown width in pixels
   * Width of dropdown menu
   *
   * @type {number}
   */
  dropdownWidth: number;

  /**
   * Whether dropdown is active
   * Dropdown is open
   *
   * @type {unknown}
   */
  activeDropdown: unknown;

  /**
   * Active tab array
   * Currently selected tab(s)
   *
   * @type {unknown[]}
   */
  tab: unknown[];

  /**
   * Current tab index
   * Index of active tab
   *
   * @type {number}
   */
  tabIndex: number;

  /**
   * Whether content is visible
   * Internal visibility flag
   *
   * @type {boolean}
   */
  contentVisible: boolean;

  /**
   * Whether dropdown is shown
   * Dropdown visibility state
   *
   * @type {boolean}
   */
  isdropDown: boolean;

  /**
   * Whether tab content is present
   * Flag indicating content exists
   *
   * @type {boolean}
   */
  isTabContent: boolean;

  /**
   * Dropdown kind attribute
   * Kind/variant for dropdown
   *
   * @type {string}
   */
  dkind: string;

  /**
   * Dropdown icon
   * Icon for dropdown trigger
   *
   * @type {string}
   */
  dicon: string;

  /**
   * Tabs dropdown reference
   * Reference to dropdown component
   *
   * @type {unknown}
   */
  tabsDropdown: unknown;

  /**
   * Tabs dropdown template component
   * Template for dropdown
   *
   * @type {unknown}
   */
  tabsDropdownTemplate: unknown;

  /**
   * Resize subscription
   * Subscription to window resize events
   *
   * @type {Subscription}
   */
  resizeSubscription: Subscription;

  /**
   * Change active tab
   * Programmatically switch to a tab
   *
   * @param tab - Tab component to activate
   * @param event - Optional click event
   */
  changeActiveTab(tab: ITabComponent, event?: Event): void;

  /**
   * Set active class on tabs
   * Apply active styling to selected tab
   *
   * @param tabs - Regular tabs array
   * @param dropdownTabs - Dropdown tabs array
   * @param tab - Tab to mark as active
   */
  setActiveClass(tabs: unknown, dropdownTabs: unknown, tab: unknown): void;

  /**
   * Set active tab with event
   * Handle tab click event
   *
   * @param event - Click event
   * @param tab - Tab component
   * @param index - Tab index
   */
  setActiveTab(event: unknown, tab: ITabComponent, index: number): void;

  /**
   * Set tab content class
   * Apply classes to tab content area
   */
  setTabContentClass(): void;

  /**
   * Set active tab by index
   * Programmatically activate tab by index
   *
   * @param index - Zero-based tab index
   * @example
   * ```typescript
   * tabSet.setActiveTabWithIndex(0); // first tab
   * tabSet.setActiveTabWithIndex(2); // third tab
   * ```
   */
  setActiveTabWithIndex(index: number): void;

  /**
   * Calculate tabs width
   * Calculate width of each tab for responsive behavior
   *
   * @returns Array of tab widths
   */
  calculateTabsWidth(): unknown[];

  /**
   * Reset tab state
   * Reset tabs to initial state
   */
  reset(): void;

  /**
   * Calculate list width
   * Calculate total width of tab list
   */
  calculateListWidth(): void;

  /**
   * Track by index for ngFor
   * Performance optimization for tab rendering
   *
   * @param index - Tab index
   * @returns Index number
   */
  trackByIndex(index: number): number;
}

/**
 * Tab component properties
 *
 * Individual tab panel with heading, content, and state management.
 *
 * @interface TabComponentProps
 * @extends BaseComponentProps
 *
 * @example
 * ```typescript
 * const tabConfig: Partial<TabComponentProps> = {
 *   heading: 'Profile',
 *   active: true,
 *   disabled: false,
 *   error: false
 * };
 * ```
 */
export interface TabComponentProps extends BaseComponentProps {
  /**
   * Whether tab is active (selected)
   * Currently displayed tab
   *
   * @type {boolean}
   * @default false
   */
  active?: boolean;

  /**
   * Whether tab has error state
   * Display error indicator
   *
   * @type {boolean}
   * @default false
   */
  error?: boolean;

  /**
   * Tab heading text
   * Text displayed in tab button
   *
   * @type {string}
   * @example 'Profile', 'Settings', 'History'
   */
  heading?: string;

  /**
   * Reference identifier for tab
   * Identifier for tab lookup
   *
   * @type {string}
   * @example 'profile-tab', 'settings-tab'
   */
  reference?: string;

  /**
   * Header template reference
   * Custom template for tab header
   *
   * @type {TemplateRef<unknown>}
   */
  header?: TemplateRef<unknown>;

  /**
   * Whether tab is hidden
   * Hide tab from view
   *
   * @type {boolean}
   * @default false
   */
  hidden?: boolean;
}

/**
 * Tab component interface
 *
 * Individual tab with content, state, and lifecycle events.
 *
 * @interface ITabComponent
 * @extends TabComponentProps
 */
export interface ITabComponent extends TabComponentProps {
  /**
   * Element reference
   * Reference to tab element
   *
   * @type {ElementRef}
   */
  element: ElementRef;

  /**
   * Event emitted when content initializes
   * Fires after tab content is ready
   *
   * @type {EventEmitter<unknown>}
   */
  onContentInit: EventEmitter<unknown>;

  /**
   * Event emitted when tab is deselected
   * Fires when tab loses focus
   *
   * @type {EventEmitter<unknown>}
   */
  onDeSelect: EventEmitter<unknown>;

  /**
   * Event emitted when tab is selected
   * Fires when tab gains focus
   *
   * @type {EventEmitter<unknown>}
   */
  onSelect: EventEmitter<unknown>;

  /**
   * Tab heading reference
   * Reference to heading element
   *
   * @type {unknown}
   */
  tabHeadingRef: unknown;

  /**
   * Whether tab is hidden
   * Internal hidden state
   *
   * @type {boolean}
   */
  isHidden: boolean;

  /**
   * Internal data nested flag
   * Flag for nested data handling
   *
   * @type {boolean}
   */
  isDataNested: boolean;

  /**
   * Add data nested attribute
   * Internal method for nested data
   */
  addDataNested(): void;
}

/**
 * Tab heading component interface
 *
 * Container for tab heading content.
 */
export interface ITabHeadingComponent {
  // Container component for tab heading content
}

/**
 * Tab content component interface
 *
 * Container for tab body content.
 */
export interface ITabContentComponent {
  // Container component for tab content
}

/**
 * Tab options component interface
 *
 * Container for tab options/actions.
 */
export interface ITabOptionsComponent {
  // Container component for tab options
}

/**
 * Tab wrapper component properties
 *
 * Wrapper component for tab styling variants.
 *
 * @interface TabWrapperComponentProps
 */
export interface TabWrapperComponentProps {
  /**
   * Tab wrapper kind/variant
   * Style variant for tab wrapper
   *
   * @type {string}
   * @example 'primary', 'secondary'
   */
  kind?: string;

  /**
   * Data kind attribute
   * Alternative kind attribute
   *
   * @type {string}
   */
  dataKind?: string;
}

/**
 * Tab wrapper component interface
 */
export interface ITabWrapperComponent extends TabWrapperComponentProps {
  // Wrapper component for tab styling
}

/**
 * Get tab heading directive interface
 *
 * Directive to get tab heading template.
 */
export interface IGetTabHeadingDirective {
  /**
   * Template reference
   * Reference to heading template
   *
   * @type {TemplateRef<unknown>}
   */
  templateRef: TemplateRef<unknown>;
}

/**
 * Set tab heading directive interface
 *
 * Directive to set tab heading template.
 */
export interface ISetTabHeadingDirective {
  /**
   * View container reference
   * Reference to view container
   *
   * @type {ViewContainerRef}
   */
  viewRef: ViewContainerRef;

  /**
   * Tab heading template
   * Template to render
   *
   * @type {TemplateRef<unknown>}
   */
  setTabHeading: TemplateRef<unknown>;
}

/**
 * Get tab options directive interface
 *
 * Directive to get tab options template.
 */
export interface IGetTabOptionsDirective {
  /**
   * Template reference
   * Reference to options template
   *
   * @type {TemplateRef<unknown>}
   */
  templateRef: TemplateRef<unknown>;
}

/**
 * Set tab options directive interface
 *
 * Directive to set tab options template.
 */
export interface ISetTabOptionsDirective {
  /**
   * View container reference
   * Reference to view container
   *
   * @type {ViewContainerRef}
   */
  viewRef: ViewContainerRef;

  /**
   * Tab options template
   * Template to render
   *
   * @type {TemplateRef<unknown>}
   */
  setTabOptions: TemplateRef<unknown>;
}
