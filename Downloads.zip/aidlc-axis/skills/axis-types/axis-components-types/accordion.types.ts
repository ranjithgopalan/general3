/**
 * @file Accordion Component Types
 * @description Type definitions for collapsible accordion panels with expand/collapse functionality.
 * Supports single and multiple panel expansion modes with customizable icons and animations.
 * @module types/accordion
 * @packageDocumentation
 */

import type { EventEmitter, ElementRef, Renderer2 } from '@angular/core';
import type { BaseComponentProps } from './component-common.types';

/**
 * Accordion component properties
 *
 * Main accordion container that manages multiple collapsible panels.
 * Controls whether multiple panels can be open simultaneously.
 *
 * @interface AccordionComponentProps
 * @extends BaseComponentProps
 *
 * @example
 * ```typescript
 * const accordionConfig: Partial<AccordionComponentProps> = {
 *   closeOthers: true, // Only one panel open at a time
 *   font: 'Arial, sans-serif'
 * };
 * ```
 */
export interface AccordionComponentProps extends BaseComponentProps {
  /**
   * Whether to close other panels when one opens
   * When true, only one panel can be expanded at a time
   *
   * @type {boolean}
   * @default false
   */
  closeOthers?: boolean;
}

/**
 * Accordion component interface
 *
 * Manages multiple accordion group panels with expand/collapse functionality.
 *
 * @interface IAccordionComponent
 * @extends AccordionComponentProps
 *
 * @example
 * ```typescript
 * // Programmatically control accordion
 * accordionComponent.expandAll(event);
 * accordionComponent.openAccordionItem(0);
 * accordionComponent.closeAccordionItem(1);
 * ```
 */
export interface IAccordionComponent extends AccordionComponentProps {
  /**
   * Event emitted when group accordion state changes
   * Emits boolean indicating expand/collapse state
   *
   * @type {EventEmitter<boolean>}
   */
  onGroupAccordionChange: EventEmitter<boolean>;

  /**
   * Array of accordion group components
   * Collection of child accordion panels
   *
   * @type {IAccordionGroupComponent[]}
   */
  groups: IAccordionGroupComponent[];

  /**
   * Flag indicating all accordions should expand
   * Internal state for expand all functionality
   *
   * @type {boolean}
   */
  expandAllAccordions: boolean;

  /**
   * Flag for expand/collapse toggler state
   * Internal state for toggle functionality
   *
   * @type {boolean}
   */
  expandCollapseToggler: boolean;

  /**
   * Initialize expand/collapse flag
   * Internal initialization flag
   *
   * @type {boolean}
   */
  initExpandCollapseFlag: boolean;

  /**
   * Subscribe callback for accordion groups
   * Internal subscription method
   *
   * @param group - Accordion group component
   */
  accordionSubscribe: (group: IAccordionGroupComponent) => void;

  /**
   * Toggle all accordion panels
   * Toggles between expand all and collapse all states
   *
   * @param event - Click event
   */
  toggleAll(event: Event): void;

  /**
   * Expand all accordion panels
   * Opens all accordion panels simultaneously
   *
   * @param event - Click event
   */
  expandAll(event: Event): void;

  /**
   * Collapse all accordion panels
   * Closes all accordion panels simultaneously
   *
   * @param event - Click event
   */
  collapseAll(event: Event): void;

  /**
   * Expand/collapse toggler logic
   * Internal logic for handling toggle state
   */
  expandCollapseTogglerLogic(): void;

  /**
   * Toggle accordion items
   * Internal method for toggling accordion items
   *
   * @param event - Click event
   */
  toggleAccordionItems(event: Event): void;

  /**
   * Open specific accordion item by index
   * Programmatically opens an accordion panel
   *
   * @param index - Zero-based index of accordion item
   */
  openAccordionItem(index: number): void;

  /**
   * Close specific accordion item by index
   * Programmatically closes an accordion panel
   *
   * @param index - Zero-based index of accordion item
   */
  closeAccordionItem(index: number): void;

  /**
   * Toggle specific accordion item by index
   * Programmatically toggles an accordion panel open/closed
   *
   * @param index - Zero-based index of accordion item
   */
  toggleAccordionItem(index: number): void;
}

/**
 * Accordion group component properties
 *
 * Individual collapsible panel within an accordion container.
 * Can be expanded or collapsed independently (unless closeOthers is enabled).
 *
 * @interface AccordionGroupComponentProps
 * @extends BaseComponentProps
 *
 * @example
 * ```typescript
 * const panelConfig: Partial<AccordionGroupComponentProps> = {
 *   active: true, // Panel starts expanded
 *   disabled: false,
 *   customIcon: 'expand_more',
 *   ucid: 'panel-1'
 * };
 * ```
 */
export interface AccordionGroupComponentProps extends BaseComponentProps {
  /**
   * Custom icon for expand/collapse indicator
   * Icon name or configuration for the accordion indicator
   *
   * @type {unknown}
   * @example 'expand_more', 'chevron_right'
   */
  customIcon?: unknown;

  /**
   * Whether accordion panel is active (expanded)
   * Controls the expanded/collapsed state
   *
   * @type {boolean}
   * @default false
   */
  active?: boolean;

  /**
   * Whether panel uses collapse animation
   * Enables/disables collapse animation
   *
   * @type {boolean}
   * @default true
   */
  isCollapse?: boolean;

  /**
   * Unique component ID
   * Identifier for the accordion panel
   *
   * @type {string}
   * @example 'accordion-panel-1'
   */
  ucid?: string;
}

/**
 * Accordion group component interface
 *
 * Individual accordion panel with header, body, and optional right content.
 *
 * @interface IAccordionGroupComponent
 * @extends AccordionGroupComponentProps
 */
export interface IAccordionGroupComponent extends AccordionGroupComponentProps {
  /**
   * Parent accordion component
   * Reference to the container accordion
   *
   * @type {IAccordionComponent}
   */
  accordion: IAccordionComponent;

  /**
   * Event emitted when accordion state changes
   * Emits when panel expands or collapses
   *
   * @type {EventEmitter<boolean>}
   */
  onAccordionChange: EventEmitter<boolean>;

  /**
   * Internal subscription flag
   * Indicates if panel is subscribed to parent
   *
   * @type {boolean}
   */
  _isSubscribed: boolean;

  /**
   * Internal active state
   * Private property for active state management
   *
   * @type {boolean}
   */
  _active: boolean;

  /**
   * Internal collapse state
   * Private property for collapse state management
   *
   * @type {boolean}
   */
  _isCollapse: boolean;

  /**
   * Set active state of accordion panel
   * Programmatically expands the accordion panel
   *
   * @param event - Click event
   */
  setActiveAccordion(event: unknown): void;

  /**
   * Toggle accordion panel open/closed
   * Toggles the panel's expanded state
   */
  toggleOpen(): void;
}

/**
 * Accordion expand/collapse component properties
 *
 * Container for expand/collapse all controls.
 *
 * @interface AccordionExpandCollapseComponentProps
 */
export interface AccordionExpandCollapseComponentProps {
  // Container component with no specific props
}

/**
 * Accordion expand/collapse component interface
 */
export interface IAccordionExpandCollapseComponent
  extends AccordionExpandCollapseComponentProps {
  // Container component for expand/collapse controls
}

/**
 * Accordion expand/collapse right component properties
 *
 * Expand/collapse control typically placed on the right side.
 *
 * @interface AccordionExpandCollapseRightComponentProps
 */
export interface AccordionExpandCollapseRightComponentProps {
  /**
   * Text for collapse state
   * Label shown when accordion is expanded
   *
   * @type {string}
   * @default 'Collapse All'
   * @example 'Hide All', 'Collapse All'
   */
  collapseText?: string;

  /**
   * Text for expand state
   * Label shown when accordion is collapsed
   *
   * @type {string}
   * @default 'Expand All'
   * @example 'Show All', 'Expand All'
   */
  expandText?: string;
}

/**
 * Accordion expand/collapse right component interface
 */
export interface IAccordionExpandCollapseRightComponent
  extends AccordionExpandCollapseRightComponentProps {
  /**
   * Parent accordion component
   * Reference to the accordion container
   *
   * @type {IAccordionComponent}
   */
  accordionComponent: IAccordionComponent;

  /**
   * Event emitted on expand/collapse
   * Emits boolean indicating expand/collapse state
   *
   * @type {EventEmitter<boolean>}
   */
  onGroupAccordionChange: EventEmitter<boolean>;

  /**
   * Expand or collapse all panels
   * Handles click event for expand/collapse all
   *
   * @param event - Click event
   */
  expandCollapse(event: Event): void;
}

/**
 * Accordion expand/collapse body component interface
 *
 * Container for content within expand/collapse section.
 */
export interface IAccordionExpandCollapseBodyComponent {
  // Container component for expand/collapse body content
}

/**
 * Accordion body component interface
 *
 * Container for accordion panel content that shows/hides with expand/collapse.
 */
export interface IAccordionBodyComponent {
  /**
   * Parent accordion group component
   * Reference to the parent panel
   *
   * @type {IAccordionGroupComponent}
   */
  accordionGroupComponent: IAccordionGroupComponent;

  /**
   * Host element reference
   * Reference to the body element
   *
   * @type {ElementRef}
   */
  hostElement: ElementRef;

  /**
   * Renderer for DOM manipulation
   * Angular renderer service
   *
   * @type {Renderer2}
   */
  renderer: Renderer2;
}

/**
 * Accordion heading component interface
 *
 * Container for accordion panel heading/title content.
 */
export interface IAccordionHeadingComponent {
  // Container component for heading content
}

/**
 * Accordion heading right component interface
 *
 * Container for content on the right side of accordion heading.
 */
export interface IAccordionHeadingRightComponent {
  // Container component for right-aligned heading content
}
