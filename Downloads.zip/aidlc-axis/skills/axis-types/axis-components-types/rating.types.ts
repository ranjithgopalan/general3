/**
 * @file Rating Component Types
 * @description Type definitions for star rating component with interactive hover and click functionality.
 * Supports custom star templates, readonly/viewonly modes, and reset capability.
 * @module types/rating
 * @packageDocumentation
 */

import type { EventEmitter, TemplateRef, ChangeDetectorRef } from '@angular/core';
import type { ControlValueAccessor } from '@angular/forms';
import type { BaseComponentProps, FormComponentProps } from './component-common.types';

/**
 * Star template context for custom rendering
 *
 * Context data passed to custom star template.
 *
 * @interface StarTemplateContext
 *
 * @example
 * ```typescript
 * // Custom star template
 * <ng-template #customStar let-fill="fill" let-index="index">
 *   <span [class.filled]="fill === 100">
 *     ★ {{index + 1}}
 *   </span>
 * </ng-template>
 * ```
 */
export interface StarTemplateContext {
  /**
   * Fill percentage of star
   * Percentage value (0-100) for partial fill
   *
   * @type {number}
   * @example 0 // empty, 50 // half-filled, 100 // fully filled
   */
  fill: number;

  /**
   * Zero-based index of star
   * Position of star in rating scale
   *
   * @type {number}
   * @example 0 // first star, 1 // second star
   */
  index: number;
}

/**
 * Axis rating configuration service
 *
 * Default configuration values for all rating instances.
 *
 * @interface AxisRatingConfig
 *
 * @example
 * ```typescript
 * const config: AxisRatingConfig = {
 *   max: 5,
 *   readonly: false,
 *   resettable: false
 * };
 * ```
 */
export interface AxisRatingConfig {
  /**
   * Maximum rating value
   * Total number of stars
   *
   * @type {number}
   * @default 5
   * @example 5, 10
   */
  max: number;

  /**
   * Whether rating is readonly by default
   * Default readonly state
   *
   * @type {boolean}
   * @default false
   */
  readonly: boolean;

  /**
   * Whether rating is resettable by default
   * Allow resetting to 0
   *
   * @type {boolean}
   * @default false
   */
  resettable: boolean;
}

/**
 * Rating component properties
 *
 * Interactive star rating component with hover feedback and form integration.
 *
 * @interface RatingComponentProps
 * @extends BaseComponentProps
 * @extends FormComponentProps
 *
 * @example
 * ```typescript
 * const ratingConfig: Partial<RatingComponentProps> = {
 *   max: 5,
 *   rate: 3,
 *   readonly: false,
 *   resettable: true,
 *   starTemplate: customStarTemplate
 * };
 * ```
 */
export interface RatingComponentProps
  extends BaseComponentProps,
    FormComponentProps {
  /**
   * Maximum rating value
   * Total number of stars to display
   *
   * @type {number}
   * @default 5
   * @example 5, 10
   */
  max?: number;

  /**
   * Current rating value
   * Selected rating (0 to max)
   *
   * @type {number}
   * @default 0
   * @example 0 // no rating, 3 // 3 stars, 4.5 // 4.5 stars
   */
  rate?: number;

  /**
   * Whether rating is readonly
   * Display only, no interaction
   *
   * @type {boolean}
   * @default false
   */
  readonly?: boolean;

  /**
   * Whether rating can be reset
   * Allow clicking same rating to reset to 0
   *
   * @type {boolean}
   * @default false
   */
  resettable?: boolean;

  /**
   * Custom star template
   * Template for custom star rendering
   *
   * @type {TemplateRef<StarTemplateContext>}
   * @see StarTemplateContext
   */
  starTemplate?: TemplateRef<StarTemplateContext>;
}

/**
 * Rating component interface
 *
 * Full rating component with form control integration and event handling.
 *
 * @interface IRatingComponent
 * @extends RatingComponentProps
 * @extends ControlValueAccessor
 *
 * @example
 * ```typescript
 * // Handle rating events
 * ratingComponent.rateChange.subscribe((value) => {
 *   console.log('Rating changed to:', value);
 * });
 *
 * ratingComponent.onHover.subscribe((value) => {
 *   console.log('Hovering over rating:', value);
 * });
 *
 * // Programmatic control
 * ratingComponent.update(4);
 * ratingComponent.reset();
 * ```
 */
export interface IRatingComponent
  extends RatingComponentProps,
    ControlValueAccessor {
  /**
   * Change detector reference
   * Angular change detection
   *
   * @type {ChangeDetectorRef}
   */
  changeDetectorRef: ChangeDetectorRef;

  /**
   * Event emitted on hover
   * Fires when user hovers over a star
   *
   * @type {EventEmitter<number>}
   */
  onHover: EventEmitter<number>;

  /**
   * Event emitted on mouse leave
   * Fires when user stops hovering
   *
   * @type {EventEmitter<number>}
   */
  onLeave: EventEmitter<number>;

  /**
   * Event emitted when rating changes
   * Primary rating change event
   *
   * @type {EventEmitter<number>}
   */
  rateChange: EventEmitter<number>;

  /**
   * Star template contexts array
   * Context data for each star
   *
   * @type {StarTemplateContext[]}
   */
  contexts: StarTemplateContext[];

  /**
   * Next rate value on hover
   * Temporary rating value during hover
   *
   * @type {number}
   */
  nextRate: number;

  /**
   * Star template from content projection
   * Template provided via ng-content
   *
   * @type {TemplateRef<StarTemplateContext>}
   */
  starTemplateFromContent: TemplateRef<StarTemplateContext>;

  /**
   * On change callback
   * Form control change handler
   *
   * @type {(value: unknown) => void}
   */
  onChange: (value: unknown) => void;

  /**
   * On touched callback
   * Form control touched handler
   *
   * @type {() => void}
   */
  onTouched: () => void;

  /**
   * Get ARIA value text
   * Returns accessible text for rating
   *
   * @returns ARIA value text
   * @example "3 out of 5"
   */
  ariaValueText(): string;

  /**
   * Handle mouse enter on star
   * Update hover state
   *
   * @param value - Star value being hovered
   */
  enter(value: number): void;

  /**
   * Handle blur event
   * Clear hover state
   */
  handleBlur(): void;

  /**
   * Handle click on star
   * Update rating value
   *
   * @param value - Star value clicked
   */
  handleClick(value: number): void;

  /**
   * Handle keyboard navigation
   * Process keyboard input
   *
   * @param event - Keyboard event
   */
  handleKeyDown(event: KeyboardEvent): void;

  /**
   * Reset rating to 0
   * Clear rating value
   */
  reset(): void;

  /**
   * Update rating value
   * Set new rating
   *
   * @param value - New rating value
   * @param internalChange - Whether change is internal
   */
  update(value: number, internalChange?: boolean): void;

  /**
   * Get fill value for star
   * Calculate fill percentage
   *
   * @param index - Star index
   * @returns Fill percentage (0-100)
   */
  _getFillValue(index: number): number;

  /**
   * Update internal state
   * Recalculate contexts
   *
   * @param nextValue - Next rating value
   */
  _updateState(nextValue: number): void;

  /**
   * Get value constrained to valid range
   * Clamp value between 0 and max
   *
   * @param value - Input value
   * @returns Clamped value
   */
  getValueInRange(value: number): number;
}
