/**
 * Icon component types for Axis Components library
 * @packageDocumentation
 */

import type { ElementRef } from '@angular/core';
import type { BaseComponentProps } from './component-common.types';

/**
 * Icon type options
 */
export type IconType = 'custom' | 'material';

/**
 * Custom icon names
 */
export type CustomIconName =
  | 'alert'
  | 'cross'
  | 'danger'
  | 'do_not_enter'
  | 'dollar_sign'
  | 'download'
  | 'error'
  | 'fail'
  | 'filter'
  | 'help'
  | 'info'
  | 'information'
  | 'menu'
  | 'no_results'
  | 'none'
  | 'people_female'
  | 'people'
  | 'print'
  | 'shield_check_add'
  | 'shield_check'
  | 'success'
  | 'tick'
  | 'user_circle'
  | 'user_search'
  | 'warning';

/**
 * Material icon names
 */
export type MaterialIconName =
  | 'alert'
  | 'calendar'
  | 'change'
  | 'chart'
  | 'collapse'
  | 'download'
  | 'expand'
  | 'export'
  | 'file'
  | 'filter'
  | 'loading'
  | 'location'
  | 'no_results'
  | 'pdf'
  | 'preview'
  | 'sign_out'
  | 'sort_down'
  | 'sort_up'
  | 'success'
  | 'time'
  | 'upload';

/**
 * Icon name (custom or material)
 */
export type IconName = CustomIconName | MaterialIconName | string;

/**
 * Icons list configuration
 */
export interface IconsList {
  /** Custom icons */
  custom: Record<CustomIconName, string>;
  /** Material icons */
  material: Record<MaterialIconName, string>;
}

/**
 * Icon component properties
 */
export interface IconComponentProps extends BaseComponentProps {
  /** Icon name */
  icon: string;
  /** Icon type */
  type?: IconType;
  /** Icon color */
  color?: string;
  /** Icon size */
  size?: string;
}

/**
 * Icon component interface
 */
export interface IIconComponent extends IconComponentProps {
  /** Element reference */
  el: ElementRef;
  /** Icons list */
  iconsList: IconsList;
  /** Check if icon is custom */
  checkIfCustomIcon(): void;
  /** Check custom CSS class */
  checkCustomClass(): void;
  /** Update icon display */
  updateIcon(): void;
}
