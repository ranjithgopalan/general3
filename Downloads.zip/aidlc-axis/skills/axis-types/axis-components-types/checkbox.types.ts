/**
 * Checkbox component types for Axis Components library
 * @packageDocumentation
 */

import type { EventEmitter, ChangeDetectorRef } from '@angular/core';
import type {
  FormComponentProps,
  FormControlValueAccessor,
  ChangeDetectableComponent
} from './component-common.types';

/**
 * Checkbox component properties
 */
export interface CheckboxComponentProps
  extends FormComponentProps,
    ChangeDetectableComponent {
  /** Whether checkbox is checked */
  checked?: boolean;
  /** Checkbox heading/label */
  heading?: string;
}

/**
 * Checkbox component interface
 */
export interface ICheckboxComponent
  extends CheckboxComponentProps,
    FormControlValueAccessor<boolean> {
  /** Change detector reference */
  _changeDetRef: ChangeDetectorRef;
  /** Event emitted on change */
  onChangeEvent: EventEmitter<boolean>;
  /** Label section element */
  labelSection: HTMLElement;
  /** Initial inner HTML */
  initialInnerHtml: string;
  /** Toggle check state */
  toggleCheck(): void;
  /** Check the checkbox */
  check(): void;
  /** Uncheck the checkbox */
  unCheck(): void;
  /** Disable the checkbox */
  disable(): void;
  /** Activate/enable the checkbox */
  activate(): void;
  /** Handle change event */
  onChange(e?: Event): void;
  /** Toggle disable state */
  toggleDisable(): void;
  /** Emit blur event */
  emitOnBlurEvent(): void;
}

/**
 * Checkbox wrapper component interface
 */
export interface ICheckboxWrapperComponent {
  /** Wrapper content */
  content?: string;
}
