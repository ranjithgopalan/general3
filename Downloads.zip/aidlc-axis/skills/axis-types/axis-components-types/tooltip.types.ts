/**
 * Tooltip component types for Axis Components library
 * @packageDocumentation
 */

import type {
  ElementRef,
  ViewContainerRef,
  ChangeDetectorRef,
  Renderer2
} from '@angular/core';
import type {
  BaseComponentProps,
  PlacementPosition,
  ComponentConstants
} from './component-common.types';

/**
 * Tooltip trigger options
 */
export type TooltipTrigger = 'hover' | 'click' | 'focus' | 'manual';

/**
 * Tooltip directive properties
 */
export interface TooltipDirectiveProps {
  /** Tooltip content (text or template) */
  axisTooltip: string | unknown;
  /** Tooltip placement position */
  placement?: PlacementPosition;
  /** Tooltip trigger type */
  tooltipTrigger?: TooltipTrigger;
  /** Whether tooltip is nested */
  dataNested?: boolean;
  /** Whether to toggle on click */
  isToggleOnClick?: boolean;
  /** Minimum width for tooltip */
  minwidth?: string;
  /** Tooltip width */
  width?: string;
  /** Maximum height for tooltip */
  maxHeight?: string;
  /** Component to include in tooltip */
  axisIncludeComponent?: unknown;
  /** Context for tooltip content */
  context?: Record<string, unknown>;
}

/**
 * Tooltip component properties
 */
export interface TooltipComponentProps extends BaseComponentProps {
  /** Whether tooltip is nested */
  dataNested?: boolean;
  /** Whether to toggle on click */
  isToggleOnClick?: boolean;
  /** Minimum width */
  minwidth?: string;
  /** Tooltip width */
  width?: string;
  /** Maximum height */
  maxHeight?: string;
}

/**
 * Tooltip component interface
 */
export interface ITooltipComponent extends TooltipComponentProps {
  /** Renderer for DOM manipulation */
  renderer: Renderer2;
  /** Change detector reference */
  _ChangeDetectorRef: ChangeDetectorRef;
  /** Component constants */
  constants: ComponentConstants;
  /** Whether tooltip is open */
  isOpen: boolean;
  /** Host element */
  hostElement: HTMLElement;
  /** Host element native reference */
  hostElementNative: HTMLElement;
  /** Tooltip trigger type */
  tooltipTrigger: string;
  /** Tooltip content */
  content: string | unknown;
  /** Placement position */
  placement: PlacementPosition;
  /** Component to include */
  axisIncludeComponent: unknown;
  /** Context for content */
  context: Record<string, unknown>;
  /** Tooltip content element reference */
  toolTipContent: ElementRef;
  /** Tooltip container element reference */
  tooltipContainer: ElementRef;
  /** View container reference */
  container: ViewContainerRef;
  /** Left position in pixels */
  left: number;
  /** Right position in pixels */
  right: number;
  /** Top position in pixels */
  top: number;
  /** Arrow position */
  arrowPos: string;
  /** Arrow top position */
  arrowTop: number;
  /** Arrow left position */
  arrowLeft: number;
  /** Trigger event */
  event: Event;
  /** Whether device is mobile */
  isMobile: boolean;
  /** Whether device has touch support */
  isTouch: boolean;
  /** Buffer space for positioning */
  bufferSpace: number;
  /** Unique key for tooltip instance */
  uniqueKey: string;
  /** Display the tooltip */
  displayTooltip(): void;
  /** Close the tooltip */
  close(event: Event): void;
  /** Calculate tooltip position */
  calculatePosition(placement: PlacementPosition): void;
  /** Handle focus within tooltip */
  handleFocus(event: KeyboardEvent): void;
  /** Focus tooltip container */
  focusTooltipContainer(): void;
  /** Set event for positioning */
  setEvent(): { clientX: number; clientY: number };
}

/**
 * Tooltip shared service interface
 */
export interface ITooltipDataSharedService {
  /** Share tooltip data */
  shareData(data: TooltipData): void;
  /** Get shared tooltip data */
  getData(): TooltipData;
  /** Clear shared data */
  clearData(): void;
}

/**
 * Tooltip data for shared service
 */
export interface TooltipData {
  /** Tooltip content */
  content: string | unknown;
  /** Placement position */
  placement: PlacementPosition;
  /** Host element */
  hostElement: HTMLElement;
  /** Trigger event */
  event: Event;
  /** Component to include */
  axisIncludeComponent?: unknown;
  /** Context */
  context?: Record<string, unknown>;
  /** Tooltip trigger type */
  tooltipTrigger?: TooltipTrigger;
  /** Minimum width */
  minwidth?: string;
  /** Width */
  width?: string;
  /** Maximum height */
  maxHeight?: string;
  /** Whether nested */
  dataNested?: boolean;
  /** Whether toggle on click */
  isToggleOnClick?: boolean;
}
