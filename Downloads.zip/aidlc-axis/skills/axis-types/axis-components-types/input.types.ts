/**
 * @file Input Component Types
 * @description Type definitions for input components, directives, and validation in Axis Components library.
 * Includes input types, masks, validators, and formatting utilities.
 * @module types/input
 * @packageDocumentation
 */

import type { ElementRef } from '@angular/core';
import type { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/**
 * Input type options
 *
 * HTML5 input types supported by Axis input components.
 * Determines the type of data and input method.
 *
 * @type InputType
 *
 * @example
 * ```typescript
 * // Text input
 * const textType: InputType = 'text';
 *
 * // Email input with validation
 * const emailType: InputType = 'email';
 *
 * // Date picker
 * const dateType: InputType = 'date';
 * ```
 */
export type InputType =
  | 'text'           // Plain text input
  | 'password'       // Password input (obscured)
  | 'email'          // Email input with validation
  | 'number'         // Numeric input with spinners
  | 'tel'            // Telephone number input
  | 'url'            // URL input with validation
  | 'search'         // Search input with clear button
  | 'date'           // Date picker
  | 'time'           // Time picker
  | 'datetime-local' // Date and time picker
  | 'month'          // Month picker
  | 'week';          // Week picker

/**
 * Input mask type
 *
 * Pre-defined input mask patterns for common data formats.
 * Automatically formats input as user types.
 *
 * @type InputMaskType
 *
 * @example
 * ```typescript
 * // Phone number mask: (123) 456-7890
 * const phoneMask: InputMaskType = 'phone';
 *
 * // SSN mask: 123-45-6789
 * const ssnMask: InputMaskType = 'ssn';
 *
 * // Currency mask: $1,234.56
 * const currencyMask: InputMaskType = 'currency';
 *
 * // Custom pattern
 * const customMask: InputMaskType = 'custom';
 * ```
 */
export type InputMaskType =
  | 'phone'      // Phone number: (XXX) XXX-XXXX
  | 'ssn'        // Social Security: XXX-XX-XXXX
  | 'date'       // Date: MM/DD/YYYY
  | 'currency'   // Currency: $X,XXX.XX
  | 'percentage' // Percentage: XX.XX%
  | 'zip'        // ZIP code: XXXXX or XXXXX-XXXX
  | 'custom';    // Custom mask pattern

/**
 * Custom validators for Axis inputs
 */
export interface AxisCustomValidators {
  /** Email validator */
  email: ValidatorFn;
  /** Phone number validator */
  phone: ValidatorFn;
  /** SSN validator */
  ssn: ValidatorFn;
  /** ZIP code validator */
  zipCode: ValidatorFn;
  /** Min length validator */
  minLength(length: number): ValidatorFn;
  /** Max length validator */
  maxLength(length: number): ValidatorFn;
  /** Pattern validator */
  pattern(pattern: string | RegExp): ValidatorFn;
  /** Required validator */
  required: ValidatorFn;
  /** Min value validator */
  min(min: number): ValidatorFn;
  /** Max value validator */
  max(max: number): ValidatorFn;
}

/**
 * Input mask directive properties
 */
export interface InputMaskDirectiveProps {
  /** Input mask pattern */
  axisInputMask?: string;
  /** Mask type */
  maskType?: InputMaskType;
  /** Custom mask pattern */
  customMask?: string;
  /** Whether to show mask on focus */
  showMaskOnFocus?: boolean;
  /** Whether to show mask on hover */
  showMaskOnHover?: boolean;
  /** Placeholder character for mask */
  placeholderChar?: string;
}

/**
 * Input mask directive interface
 */
export interface IInputMaskDirective extends InputMaskDirectiveProps {
  /** Element reference */
  el: ElementRef;
  /** Apply mask to input */
  applyMask(value: string): string;
  /** Remove mask from value */
  unmask(value: string): string;
}

/**
 * Validate directive properties
 */
export interface ValidateDirectiveProps {
  /** Validation rules */
  axisValidate?: string | string[];
  /** Custom error messages */
  errorMessages?: Record<string, string>;
}

/**
 * Validate directive interface
 */
export interface IValidateDirective extends ValidateDirectiveProps {
  /** Validate the control */
  validate(control: AbstractControl): ValidationErrors | null;
}

/**
 * Input number directive properties
 */
export interface InputNumberDirectiveProps {
  /** Minimum value */
  min?: number;
  /** Maximum value */
  max?: number;
  /** Step increment */
  step?: number;
  /** Number of decimal places */
  decimals?: number;
  /** Thousands separator */
  thousandsSeparator?: string;
  /** Decimal separator */
  decimalSeparator?: string;
  /** Allow negative numbers */
  allowNegative?: boolean;
}

/**
 * Input number directive interface
 */
export interface IInputNumberDirective extends InputNumberDirectiveProps {
  /** Element reference */
  el: ElementRef;
  /** Format number for display */
  format(value: number): string;
  /** Parse displayed value to number */
  parse(value: string): number;
}

/**
 * Clear input directive properties
 */
export interface ClearInputDirectiveProps {
  /** Whether to show clear button */
  showClear?: boolean;
  /** Clear button icon */
  clearIcon?: string;
}

/**
 * Clear input directive interface
 */
export interface IClearInputDirective extends ClearInputDirectiveProps {
  /** Element reference */
  el: ElementRef;
  /** Clear the input value */
  clear(): void;
  /** Show clear button */
  showClearButton(): void;
  /** Hide clear button */
  hideClearButton(): void;
}

/**
 * Clear component interface
 */
export interface IClearComponent {
  /** Clear icon */
  icon?: string;
  /** Click event handler */
  onClick: () => void;
}

/**
 * Floating label directive properties
 */
export interface FloatingLabelDirectiveProps {
  /** Label text */
  axisFloatingLabel?: string;
  /** Whether label is always floating */
  alwaysFloat?: boolean;
}

/**
 * Floating label directive interface
 */
export interface IFloatingLabelDirective extends FloatingLabelDirectiveProps {
  /** Element reference */
  el: ElementRef;
  /** Float the label */
  float(): void;
  /** Sink the label */
  sink(): void;
}

/**
 * Policy number directive properties
 */
export interface PolicyNumberDirectiveProps {
  /** Policy number pattern */
  axisPolicyNumber?: string;
  /** Whether to auto-format */
  autoFormat?: boolean;
}

/**
 * Policy number directive interface
 */
export interface IPolicyNumberDirective extends PolicyNumberDirectiveProps {
  /** Element reference */
  el: ElementRef;
  /** Format policy number */
  format(value: string): string;
  /** Validate policy number */
  validate(value: string): boolean;
}

/**
 * Textarea autosize directive properties
 */
export interface TextareaAutosizeDirectiveProps {
  /** Minimum rows */
  minRows?: number;
  /** Maximum rows */
  maxRows?: number;
  /** Whether to enable autosize */
  axisTextareaAutosize?: boolean;
}

/**
 * Textarea autosize directive interface
 */
export interface ITextareaAutosizeDirective extends TextareaAutosizeDirectiveProps {
  /** Element reference */
  el: ElementRef;
  /** Resize textarea to fit content */
  resize(): void;
}

/**
 * Clear icon shared service interface
 */
export interface IClearIconSharedService {
  /** Register clear icon */
  register(id: string, callback: () => void): void;
  /** Unregister clear icon */
  unregister(id: string): void;
  /** Trigger clear */
  clear(id: string): void;
}

/**
 * Input language configuration
 */
export interface InputLanguageConfig {
  /** Language code */
  code: string;
  /** Language name */
  name: string;
  /** Validation messages */
  validationMessages: Record<string, string>;
  /** Placeholder text */
  placeholders: Record<string, string>;
}
