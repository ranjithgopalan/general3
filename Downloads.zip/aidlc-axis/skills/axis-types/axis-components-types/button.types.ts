/**
 * Button component types for Axis Components library
 * @packageDocumentation
 */

import type { EventEmitter, ChangeDetectorRef } from '@angular/core';
import type {
  BaseComponentProps,
  FormComponentProps,
  FormControlValueAccessor,
  ChangeDetectableComponent
} from './component-common.types';

/**
 * Basic button component properties
 */
export interface ButtonComponentProps extends BaseComponentProps {
  /** Button title */
  title: string;
  /** Button type */
  type: string;
}

/**
 * Button component interface
 */
export interface IButtonComponent
  extends ButtonComponentProps,
    FormControlValueAccessor {
  /** Propagate model changes */
  propagateModelChange: (value: unknown) => void;
  /** On touched callback */
  onTouched: () => void;
}

/**
 * Button toggle component properties
 */
export interface ButtonToggleComponentProps extends BaseComponentProps {
  /** Whether reset button is shown */
  isReset?: boolean;
  /** Whether the field is required */
  required?: boolean;
}

/**
 * Button toggle component interface
 */
export interface IButtonToggleComponent
  extends ButtonToggleComponentProps,
    FormControlValueAccessor {
  /** Event emitted with selected index */
  getSelectedIndex: EventEmitter<number>;
  /** Event emitted with selected value */
  getSelectedValue: EventEmitter<string | number | boolean>;
  /** Event emitted on reset */
  resetEvent: EventEmitter<unknown>;
  /** Array of child button components */
  ButtonToggleChildArray: unknown[];
  /** Currently selected index */
  selectedIndex: number;
  /** Currently selected value */
  selectedValue: string | number | boolean;
  /** Enable the reset icon */
  enableResetIcon(): void;
  /** Disable the reset icon */
  disableResetIcon(): void;
  /** Perform predefined selection */
  predefinedselection(comp: unknown): void;
  /** Toggle selection state */
  toggleOther(comp: unknown): void;
  /** Clear toggle selection */
  clearToggle(): void;
  /** Reset toggle to initial state */
  resetToggle(): void;
  /** Reset to default */
  reset(): void;
  /** Reset all buttons */
  resetAll(): void;
  /** Reset selection */
  resetSelection(): void;
  /** Disable toggle button */
  disableToggleBtn(): void;
  /** Enable toggle button */
  enableToggleBtn(): void;
  /** Toggle disable/enable state */
  disableEnableToggleBtn(): void;
}

/**
 * Button toggle child component properties
 */
export interface ButtonToggleChildComponentProps
  extends BaseComponentProps,
    ChangeDetectableComponent {
  /** Whether button is active */
  active?: boolean;
  /** Button value */
  value?: string | number | boolean;
}

/**
 * Button toggle child component interface
 */
export interface IButtonToggleChildComponent
  extends ButtonToggleChildComponentProps {
  /** Parent button toggle component */
  buttonToggle: IButtonToggleComponent;
  /** Change detector reference */
  _changeDetRef: ChangeDetectorRef;
  /** Internal active state */
  _active: boolean;
  /** Whether button is active */
  isActive: boolean;
  /** Toggle switch state */
  toggleSwitch(): void;
  /** Emit blur event */
  emitOnBlurEvent(): void;
}

/**
 * Toggle switch component properties
 */
export interface ToggleSwitchComponentProps extends FormComponentProps {
  /** Whether switch is checked */
  checked?: boolean;
  /** ARIA label text */
  ariaLabelText?: string;
}

/**
 * Toggle switch component interface
 */
export interface IToggleSwitchComponent
  extends ToggleSwitchComponentProps,
    FormControlValueAccessor {
  /** Event emitted on toggle */
  onToggle: EventEmitter<boolean>;
  /** Button toggle switch element */
  buttonToggleSwitch: HTMLElement;
  /** Whether component is disabled */
  isDisabled: string;
  /** Toggle flag state */
  toggleFlag: boolean;
  /** Get checked state */
  getChecked(): void;
  /** Toggle active state */
  toggleActive(event: Event): void;
}

/**
 * Toggle button component interface
 */
export interface IToggleButtonComponent extends ChangeDetectableComponent {
  /** Parent toggle switch component */
  toggleSwitchComponent: IToggleSwitchComponent;
  /** Emit blur event */
  emitOnBlurEvent(): void;
}
