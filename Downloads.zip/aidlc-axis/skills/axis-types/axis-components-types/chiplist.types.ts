/**
 * @file Chip List Component Types
 * @description Type definitions for selectable chip list component with keyboard navigation.
 * Supports single/multi-selection, dynamic addition/removal, and form integration.
 * @module types/chiplist
 * @packageDocumentation
 */

import type { EventEmitter, QueryList, ChangeDetectorRef } from '@angular/core';
import type { ControlValueAccessor } from '@angular/forms';
import type { BaseComponentProps, FormComponentProps } from './component-common.types';

/**
 * Chip component interface
 *
 * Individual chip item within a chip list.
 */
export interface IAxisChipComponent {
  /** Chip value/data */
  value: unknown;
  /** Whether chip is selected */
  selected: boolean;
  /** Whether chip is disabled */
  disabled: boolean;
  /** Whether chip is removable */
  removable: boolean;
  /** Event emitted when chip is selected */
  selectionChange: EventEmitter<unknown>;
  /** Event emitted when chip is removed */
  removed: EventEmitter<unknown>;
}

/**
 * Chip list component properties
 *
 * Container for selectable chip items with form control integration.
 *
 * @interface AxisChipListComponentProps
 * @extends BaseComponentProps
 * @extends FormComponentProps
 *
 * @example
 * ```typescript
 * const chipListConfig: Partial<AxisChipListComponentProps> = {
 *   dataProvider: [
 *     { label: 'Angular', value: 'angular' },
 *     { label: 'React', value: 'react' }
 *   ],
 *   multiple: true,
 *   selectable: true
 * };
 * ```
 */
export interface AxisChipListComponentProps
  extends BaseComponentProps,
    FormComponentProps {
  /**
   * ARIA orientation
   * Orientation for accessibility
   *
   * @type {string}
   * @default 'horizontal'
   * @example 'horizontal', 'vertical'
   */
  ariaOrientation?: string;

  /**
   * Function to compare chip values
   * Custom comparison for selection matching
   *
   * @type {(o1: unknown, o2: unknown) => boolean}
   * @example (a, b) => a.id === b.id
   */
  compareWith?: (o1: unknown, o2: unknown) => boolean;

  /**
   * Error state matcher
   * Custom error state logic
   *
   * @type {unknown}
   */
  errorStateMatcher?: unknown;

  /**
   * Whether multiple chips can be selected
   * Enable multi-selection mode
   *
   * @type {boolean}
   * @default false
   */
  multiple?: boolean;

  /**
   * Whether chips are selectable
   * Enable selection functionality
   *
   * @type {boolean}
   * @default true
   */
  selectable?: boolean;

  /**
   * Data provider for chips
   * Array of chip data items
   *
   * @type {unknown[]}
   * @example [{ label: 'Tag 1', value: '1' }, { label: 'Tag 2', value: '2' }]
   */
  dataProvider?: unknown[];
}

/**
 * Chip list component interface
 *
 * Full chip list with selection management and keyboard navigation.
 *
 * @interface IAxisChipListComponent
 * @extends AxisChipListComponentProps
 * @extends ControlValueAccessor
 *
 * @example
 * ```typescript
 * // Handle chip events
 * chipList.change.subscribe((selected) => {
 *   console.log('Selected chips:', selected);
 * });
 *
 * chipList.removed.subscribe((removed) => {
 *   console.log('Removed chip:', removed);
 * });
 *
 * // Programmatic control
 * chipList.add({ label: 'New', value: 'new' });
 * chipList.removeAll();
 * chipList.resetSelection();
 * ```
 */
export interface IAxisChipListComponent
  extends AxisChipListComponentProps,
    ControlValueAccessor {
  /**
   * Change detector reference
   * Angular change detection
   *
   * @type {ChangeDetectorRef}
   */
  changeDetectorRef: ChangeDetectorRef;

  /**
   * Event emitted when selection changes
   * Fires when chips are selected/deselected
   *
   * @type {EventEmitter<unknown>}
   */
  change: EventEmitter<unknown>;

  /**
   * Event emitted when chip is removed
   * Fires when chip is deleted
   *
   * @type {EventEmitter<unknown>}
   */
  removed: EventEmitter<unknown>;

  /**
   * Current model value
   * Selected chip value(s)
   *
   * @type {unknown}
   */
  model: unknown;

  /**
   * Query list of chip components
   * Collection of chip components
   *
   * @type {QueryList<IAxisChipComponent>}
   */
  chips: QueryList<IAxisChipComponent>;

  /**
   * Array of chip components
   * Internal chip list array
   *
   * @type {QueryList<IAxisChipComponent>}
   */
  axisChipListArray: QueryList<IAxisChipComponent>;

  /**
   * Selected chips list
   * Array of selected items
   *
   * @type {unknown[]}
   */
  selectedList: unknown[];

  /**
   * Error state flag
   * Whether list has validation errors
   *
   * @type {boolean}
   */
  errorState: boolean;

  /**
   * Focused state flag
   * Whether list has focus
   *
   * @type {boolean}
   */
  focused: boolean;

  /**
   * Selected items
   * Current selection (single or array)
   *
   * @type {unknown[] | unknown}
   */
  selected: unknown[] | unknown;

  /**
   * On model change callback
   * Internal change propagation
   *
   * @type {(value: unknown) => void}
   */
  propagateModelChange: (value: unknown) => void;

  /**
   * On touched callback
   * Form control touched handler
   *
   * @type {() => void}
   */
  onTouched: () => void;

  /**
   * Handle selection change
   * Process chip selection
   *
   * @param data - Selected chip data
   */
  onSelectionChange(data: unknown): void;

  /**
   * Handle chip removal
   * Process chip removal
   *
   * @param event - Remove event
   */
  onRemove(event: unknown): void;

  /**
   * Set predefined selection
   * Initialize with pre-selected chips
   */
  preDefinedSelection(): void;

  /**
   * Set predefined chip selection
   * Alternative selection initialization
   */
  preDefinedChipSelection(): void;

  /**
   * Reset selection
   * Clear all selections
   */
  resetSelection(): void;

  /**
   * Add new chip
   * Programmatically add chip
   *
   * @param data - Chip data
   */
  add(data: unknown): void;

  /**
   * Remove all chips
   * Clear all chips from list
   */
  removeAll(): void;

  /**
   * Handle keyboard navigation
   * Process keyboard input
   *
   * @param event - Keyboard event
   */
  handleKeyDown(event: unknown): void;

  /**
   * Navigate to next chip
   * Move focus to next chip
   *
   * @param event - Keyboard event
   */
  nextChip(event: unknown): void;

  /**
   * Navigate to previous chip
   * Move focus to previous chip
   *
   * @param event - Keyboard event
   */
  previousChip(event: unknown): void;

  /**
   * Navigate to first chip
   * Move focus to first chip
   */
  firstChip(): void;

  /**
   * Navigate to last chip
   * Move focus to last chip
   */
  lastChip(): void;
}
