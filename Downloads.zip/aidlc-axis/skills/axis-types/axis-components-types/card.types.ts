/**
 * Card component types for Axis Components library
 * @packageDocumentation
 */

import type { BaseComponentProps } from './component-common.types';

/**
 * Card component properties
 */
export interface CardComponentProps extends BaseComponentProps {
  /** Whether card has inverse styling */
  inverse?: string;
  /** Card kind/variant */
  kind?: string;
}

/**
 * Card component interface
 */
export interface ICardComponent extends CardComponentProps {
  /** Card content */
  content?: string;
}

/**
 * Card image container component interface
 */
export interface ICardImgContainerComponent {
  /** Image source URL */
  src?: string;
  /** Image alt text */
  alt?: string;
}

/**
 * Card row component interface
 */
export interface ICardRowComponent {
  /** Row content */
  content?: string;
}

/**
 * Card body component interface
 */
export interface ICardBodyComponent {
  /** Body content */
  content?: string;
}

/**
 * Card heading component interface
 */
export interface ICardHeadingComponent {
  /** Heading text */
  heading?: string;
}

/**
 * Card footer component interface
 */
export interface ICardFooterComponent {
  /** Footer content */
  content?: string;
}

/**
 * Card spotlight container component properties
 */
export interface CardSpotlightContainerComponentProps {
  /** Flex items alignment */
  alignflexitems?: string;
}

/**
 * Card spotlight container component interface
 */
export interface ICardSpotlightContainerComponent
  extends CardSpotlightContainerComponentProps {
  /** Container content */
  content?: string;
}

/**
 * Card content component properties
 */
export interface CardContentComponentProps {
  /** Card content type */
  cardcontent?: string;
}

/**
 * Card content component interface
 */
export interface ICardContentComponent extends CardContentComponentProps {
  /** Content */
  content?: string;
}

/**
 * Card heading body component interface
 */
export interface ICardHeadingBodyComponent {
  /** Heading body content */
  content?: string;
}

/**
 * Card heading right component interface
 */
export interface ICardHeadingRightComponent {
  /** Heading right content */
  content?: string;
}

/**
 * Card group component interface
 */
export interface ICardGroupComponent {
  /** Group content */
  content?: string;
}

/**
 * Card image overlay component interface
 */
export interface ICardImgOverlayComponent {
  /** Overlay content */
  content?: string;
}

/**
 * Card ribbon component properties
 */
export interface CardRibbonComponentProps extends BaseComponentProps {
  /** Ribbon icon */
  icon?: string;
  /** Ribbon color */
  color?: string;
  /** Ribbon background color */
  backgroundColor?: string;
  /** Ribbon size */
  size?: string;
  /** Whether ribbon is enabled */
  ribbon?: boolean;
}

/**
 * Card ribbon component interface
 */
export interface ICardRibbonComponent extends CardRibbonComponentProps {
  /** Ribbon content */
  content?: string;
}
