/**
 * @file Dropdown Component Types
 * @description Type definitions for dropdown, combobox, typeahead, and multiselect components.
 * Provides configuration for single-select, multi-select, searchable, and nested dropdowns with API integration.
 * @module types/dropdown
 * @packageDocumentation
 */

import type {
  EventEmitter,
  ElementRef,
  ViewContainerRef,
  ChangeDetectorRef,
  Renderer2
} from '@angular/core';
import type { HttpClient } from '@angular/common/http';
import type { Subject, Observable } from 'rxjs';
import type {
  BaseComponentProps,
  FormComponentProps,
  FormControlValueAccessor,
  ComponentConstants
} from './component-common.types';

/**
 * Dropdown data provider item
 *
 * Represents a single selectable item in a dropdown list.
 * Supports icons, images, badges, nested items, and custom properties.
 *
 * @interface DropdownDataItem
 *
 * @example
 * ```typescript
 * // Simple dropdown item
 * const option: DropdownDataItem = {
 *   label: 'United States',
 *   value: 'US'
 * };
 *
 * // Item with icon and badge
 * const userOption: DropdownDataItem = {
 *   label: 'John Doe',
 *   value: 123,
 *   icon: 'person',
 *   badge: 'Admin',
 *   disabled: false
 * };
 *
 * // Item with image
 * const productOption: DropdownDataItem = {
 *   label: 'iPhone 15 Pro',
 *   value: 'iphone-15-pro',
 *   image: '/assets/images/iphone-15-pro.jpg',
 *   badge: 'New'
 * };
 *
 * // Nested dropdown item
 * const categoryOption: DropdownDataItem = {
 *   label: 'Electronics',
 *   value: 'electronics',
 *   children: [
 *     { label: 'Phones', value: 'phones' },
 *     { label: 'Laptops', value: 'laptops' }
 *   ]
 * };
 * ```
 */
export interface DropdownDataItem {
  /**
   * Display label shown to the user
   * Text displayed in the dropdown list and button
   *
   * @type {string}
   * @example 'United States', 'Option 1', 'Select me'
   */
  label?: string;

  /**
   * Item value used for form submission
   * The actual value stored when this item is selected
   *
   * @type {string | number | boolean}
   * @example 'US', 123, true
   */
  value?: string | number | boolean;

  /**
   * Whether item is disabled
   * Disabled items are visible but cannot be selected
   *
   * @type {boolean}
   * @default false
   */
  disabled?: boolean;

  /**
   * Whether item is selected
   * Pre-selected state for the item
   *
   * @type {boolean}
   * @default false
   */
  selected?: boolean;

  /**
   * Icon for the item
   * Icon identifier (Material Icons or Font Awesome)
   *
   * @type {string}
   * @example 'person', 'fa-user', 'settings'
   */
  icon?: string;

  /**
   * Image URL for the item
   * Path to image displayed alongside label
   *
   * @type {string}
   * @example '/assets/images/flag-us.png', 'https://example.com/avatar.jpg'
   */
  image?: string;

  /**
   * Badge text
   * Small label or tag displayed next to the item
   *
   * @type {string}
   * @example 'New', 'Beta', 'Admin', '3'
   */
  badge?: string;

  /**
   * Child items for nested dropdowns
   * Creates hierarchical dropdown structure with sub-items
   *
   * @type {DropdownDataItem[]}
   * @example [{ label: 'Sub-item 1', value: '1-1' }, { label: 'Sub-item 2', value: '1-2' }]
   */
  children?: DropdownDataItem[];

  /**
   * Additional custom properties
   * Store arbitrary metadata for application-specific use
   *
   * @type {unknown}
   * @example { category: 'electronics', inStock: true, price: 999 }
   */
  [key: string]: unknown;
}

/**
 * Dropdown API call configuration
 *
 * Configuration for fetching dropdown data from remote APIs.
 * Supports both URL-based and callback-based data fetching for typeahead.
 *
 * @interface DropdownApiCall
 *
 * @example
 * ```typescript
 * // URL-based API call
 * const apiConfig: DropdownApiCall = {
 *   url: '/api/users',
 *   method: 'GET',
 *   headers: {
 *     'Authorization': 'Bearer token123',
 *     'Content-Type': 'application/json'
 *   }
 * };
 *
 * // Callback-based API call
 * const callbackConfig: DropdownApiCall = {
 *   callback: (searchText: string) => {
 *     return this.userService.searchUsers(searchText);
 *   },
 *   method: 'POST'
 * };
 *
 * // Simple GET call
 * const simpleConfig: DropdownApiCall = {
 *   url: 'https://api.example.com/countries',
 *   method: 'GET'
 * };
 * ```
 */
export interface DropdownApiCall {
  /**
   * API URL to fetch data from
   * Full or relative URL to the endpoint
   *
   * @type {string}
   * @example '/api/users', 'https://api.example.com/countries'
   */
  url?: string;

  /**
   * Callback function to fetch data
   * Alternative to URL for custom data fetching logic
   *
   * @type {(searchText: string) => Observable<DropdownDataItem[]>}
   * @param searchText - Current search/filter text
   * @returns Observable of dropdown items
   * @example (text) => this.service.search(text)
   */
  callback?: (searchText: string) => Observable<DropdownDataItem[]>;

  /**
   * HTTP method for the request
   * Type of HTTP request to make
   *
   * @type {'GET' | 'POST'}
   * @default 'GET'
   */
  method?: 'GET' | 'POST';

  /**
   * Request headers
   * Additional HTTP headers for the API request
   *
   * @type {Record<string, string>}
   * @example { 'Authorization': 'Bearer token', 'X-API-Key': 'abc123' }
   */
  headers?: Record<string, string>;
}

/**
 * Dropdown column configuration
 *
 * Configuration for multi-column dropdown display.
 * Defines columns to show in table-style dropdown menus.
 *
 * @interface DropdownColumn
 *
 * @example
 * ```typescript
 * // Single column
 * const nameColumn: DropdownColumn = {
 *   header: 'Name',
 *   field: 'name',
 *   width: '200px'
 * };
 *
 * // Multiple columns for table-style dropdown
 * const columns: DropdownColumn[] = [
 *   { header: 'Name', field: 'name', width: '40%' },
 *   { header: 'Email', field: 'email', width: '40%' },
 *   { header: 'Role', field: 'role', width: '20%' }
 * ];
 * ```
 */
export interface DropdownColumn {
  /**
   * Column header
   * Text displayed in the column header
   *
   * @type {string}
   * @example 'Name', 'Email', 'Status'
   */
  header: string;

  /**
   * Field name to display
   * Property name from DropdownDataItem to show in this column
   *
   * @type {string}
   * @example 'name', 'email', 'status'
   */
  field: string;

  /**
   * Column width
   * CSS width value for the column
   *
   * @type {string}
   * @default 'auto'
   * @example '200px', '40%', 'auto'
   */
  width?: string;
}

/**
 * Dropdown component properties
 *
 * Comprehensive configuration for dropdown components.
 * Supports standard dropdowns, comboboxes, typeahead, multi-select, and action menus.
 *
 * @interface DropdownComponentProps
 * @extends BaseComponentProps
 * @extends FormComponentProps
 *
 * @example
 * ```typescript
 * // Simple dropdown
 * const simpleDropdown: Partial<DropdownComponentProps> = {
 *   dataProvider: [
 *     { label: 'Option 1', value: '1' },
 *     { label: 'Option 2', value: '2' }
 *   ],
 *   placeholder: 'Select an option'
 * };
 *
 * // Typeahead with API
 * const typeahead: Partial<DropdownComponentProps> = {
 *   isTypeahead: true,
 *   placeholder: 'Search users...',
 *   apiCall: {
 *     url: '/api/users/search',
 *     method: 'GET'
 *   },
 *   debounce: 300,
 *   triggerLength: 3
 * };
 *
 * // Multi-select
 * const multiSelect: Partial<DropdownComponentProps> = {
 *   isMultiSearchSelect: true,
 *   isSelectAll: true,
 *   maxSelectionCount: 5,
 *   dataProvider: [...]
 * };
 * ```
 */
export interface DropdownComponentProps
  extends BaseComponentProps,
    FormComponentProps {
  // ============================================================================
  // Data Configuration
  // ============================================================================

  /**
   * Data items for dropdown
   * Array of selectable options
   *
   * @type {DropdownDataItem[]}
   * @see DropdownDataItem
   * @example [{ label: 'US', value: 'us' }, { label: 'CA', value: 'ca' }]
   */
  dataProvider?: DropdownDataItem[];

  // ============================================================================
  // Display Properties
  // ============================================================================

  /**
   * Dropdown heading/title
   * Header text displayed above the dropdown
   *
   * @type {string}
   * @example 'Select Country', 'Choose Option'
   */
  heading?: string;

  /**
   * Placeholder text
   * Text shown when no option is selected
   *
   * @type {string}
   * @example 'Select an option', 'Choose one...'
   */
  placeholder?: string;

  /**
   * Dropdown type
   * Visual variant or style
   *
   * @type {string}
   * @example 'primary', 'secondary', 'outline'
   */
  type?: string;

  /**
   * Dropdown size
   * Size variant for the dropdown button
   *
   * @type {string}
   * @default 'medium'
   * @example 'small', 'medium', 'large'
   */
  size?: string;

  /**
   * Dropdown width
   * Width of the dropdown in pixels
   *
   * @type {number}
   * @example 200, 300, 400
   */
  width?: number;

  /**
   * Dropdown alignment
   * Alignment of dropdown menu relative to button
   *
   * @type {'left' | 'right'}
   * @default 'left'
   */
  align?: 'left' | 'right';

  // ============================================================================
  // Dropdown Variants
  // ============================================================================

  /**
   * Whether dropdown is action menu
   * Shows menu of actions instead of form selection
   *
   * @type {boolean}
   * @default false
   */
  isActionMenu?: boolean;

  /**
   * Whether dropdown is combobox
   * Allows both typing and selection
   *
   * @type {boolean}
   * @default false
   */
  isCombobox?: boolean;

  /**
   * Whether dropdown is typeahead
   * Enables search-as-you-type with API integration
   *
   * @type {boolean}
   * @default false
   */
  isTypeahead?: boolean;

  /**
   * Whether dropdown is multi-select
   * Allows selecting multiple options
   *
   * @type {boolean}
   * @default false
   */
  isMultiSearchSelect?: boolean;

  /**
   * Whether to show select all option
   * Adds "Select All" checkbox for multi-select
   *
   * @type {boolean}
   * @default false
   */
  isSelectAll?: boolean;

  /**
   * Whether dropdown is nested multiselect
   * Supports hierarchical selection with children
   *
   * @type {boolean}
   * @default false
   */
  isNestedMultiselect?: boolean;

  /**
   * Whether to show selected items
   * Displays selected items as chips/tags
   *
   * @type {boolean}
   * @default false
   */
  showSelected?: boolean;

  // ============================================================================
  // Size & Layout Configuration
  // ============================================================================

  /**
   * Maximum number of items to display
   * Limits visible items in dropdown list
   *
   * @type {number}
   * @example 10, 50, 100
   */
  maxItemsLength?: number;

  /**
   * Maximum number of visible rows
   * Limits dropdown height by row count
   *
   * @type {number}
   * @default 10
   * @example 5, 10, 20
   */
  maxVisibleRows?: number;

  /**
   * Menu maximum height
   * Maximum height of dropdown menu in pixels
   *
   * @type {number}
   * @example 300, 400, 500
   */
  menuMaxHeight?: number;

  /**
   * Menu maximum width
   * Maximum width of dropdown menu in pixels
   *
   * @type {number}
   * @example 400, 600, 800
   */
  menuMaxWidth?: number;

  /**
   * Menu minimum width
   * Minimum width of dropdown menu in pixels
   *
   * @type {number}
   * @default 200
   * @example 150, 200, 300
   */
  menuMinWidth?: number;

  // ============================================================================
  // Search & Filter Configuration
  // ============================================================================

  /**
   * Message to show when no results found
   * Text displayed when search returns no matches
   *
   * @type {string}
   * @default 'No results found'
   * @example 'No matching items', 'Try a different search'
   */
  messageNoResults?: string;

  /**
   * Search placeholder text
   * Placeholder for the search input
   *
   * @type {string}
   * @example 'Search...', 'Type to filter'
   */
  searchPlaceholder?: string;

  /**
   * Number of search results to show
   * Limits search results display count
   *
   * @type {number}
   * @default 10
   * @example 5, 20, 50
   */
  noOfSearchResults?: number;

  /**
   * Search properties to search within
   * Array of property names to search in
   *
   * @type {string[]}
   * @example ['label', 'value', 'description']
   */
  searchProperties?: string[];

  /**
   * Whether to filter starting with search text
   * Matches only items that start with search text
   *
   * @type {boolean}
   * @default false
   */
  filterStartsWith?: boolean;

  /**
   * Whether to ignore accents in search
   * Normalizes accented characters for search
   *
   * @type {boolean}
   * @default false
   * @example true // 'café' matches 'cafe'
   */
  ignoreAccent?: boolean;

  /**
   * Whether to exclude first element on search
   * Skips first item when filtering
   *
   * @type {boolean}
   * @default false
   */
  excludeFirstElementOnSearch?: boolean;

  /**
   * Whether to enable multiselect filter
   * Enables search/filter for multi-select
   *
   * @type {boolean}
   * @default true
   */
  enableMultiSelectFilter?: boolean;

  // ============================================================================
  // Typeahead & API Configuration
  // ============================================================================

  /**
   * API call configuration for typeahead
   * Configuration for fetching data from API
   *
   * @type {DropdownApiCall}
   * @see DropdownApiCall
   */
  apiCall?: DropdownApiCall;

  /**
   * Debounce time for search in milliseconds
   * Delay before triggering search
   *
   * @type {number}
   * @default 300
   * @example 200, 500, 1000
   */
  debounce?: number;

  /**
   * Trigger length for typeahead
   * Minimum characters to trigger API search
   *
   * @type {number}
   * @default 3
   * @example 2, 3, 4
   */
  triggerLength?: number;

  /**
   * Field name to retrieve from selection
   * Property name to extract from selected item
   *
   * @type {string}
   * @example 'id', 'value', 'code'
   */
  retrieveFieldName?: string;

  /**
   * Backend field name for API calls
   * Parameter name for API requests
   *
   * @type {string}
   * @example 'search', 'query', 'term'
   */
  backendFieldName?: string;

  // ============================================================================
  // Icon & Visual Configuration
  // ============================================================================

  /**
   * Icon for dropdown button
   * Icon displayed on the button
   *
   * @type {string}
   * @example 'arrow_drop_down', 'expand_more', 'fa-chevron-down'
   */
  icon?: string;

  /**
   * Placeholder icon configuration
   * Icon configuration for placeholder state
   *
   * @type {Record<string, unknown>}
   */
  placeholderIcon?: Record<string, unknown>;

  /**
   * Whether to show arrow icon
   * Shows dropdown arrow indicator
   *
   * @type {boolean}
   * @default true
   */
  arrowIcon?: boolean;

  /**
   * Whether to show image
   * Enables image display for items
   *
   * @type {boolean}
   * @default false
   */
  isImage?: boolean;

  /**
   * Whether dropdown is icon only
   * Shows only icon without text
   *
   * @type {boolean}
   * @default false
   */
  isIconOnly?: boolean;

  /**
   * Whether label is visible
   * Controls label visibility
   *
   * @type {boolean}
   * @default true
   */
  isLabelVisible?: boolean;

  // ============================================================================
  // Multi-Column Configuration
  // ============================================================================

  /**
   * Column count for multi-column dropdown
   * Number of columns in table-style dropdown
   *
   * @type {number}
   * @example 2, 3, 4
   */
  columnCount?: number;

  /**
   * Columns configuration
   * Column definitions for table-style dropdown
   *
   * @type {DropdownColumn[]}
   * @see DropdownColumn
   */
  columns?: DropdownColumn[];

  /**
   * Rendering label field
   * Field name to use for display label
   *
   * @type {string}
   * @example 'name', 'title', 'displayName'
   */
  renderingLabel?: string;

  /**
   * Rendering image label field
   * Field name for image URL
   *
   * @type {string}
   * @example 'imageUrl', 'avatar', 'thumbnail'
   */
  renderingImageLabel?: string;

  // ============================================================================
  // Behavior Configuration
  // ============================================================================

  /**
   * Whether to enable tooltip
   * Shows tooltips on hover
   *
   * @type {boolean}
   * @default false
   */
  tooltip?: boolean;

  /**
   * Whether to close on outside click
   * Closes dropdown when clicking outside
   *
   * @type {boolean}
   * @default true
   */
  closeOnOutsideClick?: boolean;

  /**
   * Whether dropdown is readonly
   * Makes dropdown non-editable
   *
   * @type {boolean}
   * @default false
   */
  readonly?: boolean;

  /**
   * Whether dropdown is inside modal
   * Special handling for modal context
   *
   * @type {boolean}
   * @default false
   */
  isInsideModal?: boolean;

  /**
   * Whether to wrap text
   * Wraps long text instead of truncating
   *
   * @type {boolean}
   * @default false
   */
  wrap?: boolean;

  /**
   * Maximum selection count for multiselect
   * Limits number of selectable items
   *
   * @type {number}
   * @example 3, 5, 10
   */
  maxSelectionCount?: number;

  /**
   * Whether to clear on focus out
   * Clears input when focus is lost
   *
   * @type {boolean}
   * @default false
   */
  clearOnFocusOut?: boolean;

  /**
   * Whether to show loader
   * Displays loading indicator
   *
   * @type {boolean}
   * @default false
   */
  showLoader?: boolean;

  // ============================================================================
  // Validation Configuration
  // ============================================================================

  /**
   * Regular expression for validation
   * Pattern for input validation
   *
   * @type {RegExp}
   * @example /^[a-zA-Z]+$/ // Letters only
   */
  regExp?: RegExp;

  /**
   * Whether to enable client side validation
   * Validates input on client
   *
   * @type {boolean}
   * @default false
   */
  clientSideValidation?: boolean;

  // ============================================================================
  // Action Menu Configuration
  // ============================================================================

  /**
   * Custom title for button
   * Override default button title
   *
   * @type {string}
   * @example 'Actions', 'More Options'
   */
  customTitle?: string;

  /**
   * Action label for action menu
   * Label for action menu button
   *
   * @type {string}
   * @example 'Actions', 'Menu'
   */
  actionLabel?: string;

  /**
   * Button kind/variant
   * Visual style variant
   *
   * @type {string}
   * @example 'primary', 'secondary', 'ghost'
   */
  buttonKind?: string;

  /**
   * Data kind attribute
   * Custom data attribute
   *
   * @type {string}
   */
  dataKind?: string;

  /**
   * Component kind
   * Component variant identifier
   *
   * @type {string}
   */
  kind?: string;

  // ============================================================================
  // Advanced Configuration
  // ============================================================================

  /**
   * Whether headers are readonly
   * Makes column headers non-interactive
   *
   * @type {boolean}
   * @default false
   */
  readonlyHeaders?: boolean;

  /**
   * Whether data is shared
   * Indicates shared data source
   *
   * @type {boolean}
   * @default false
   */
  dataShared?: boolean;

  /**
   * Whether to insert dropdown before target
   * DOM insertion position
   *
   * @type {boolean}
   * @default false
   */
  insertBefore?: boolean;

  /**
   * Component context
   * Application-specific context data
   *
   * @type {unknown}
   */
  context?: unknown;

  /**
   * Template classes
   * CSS classes for template customization
   *
   * @type {string}
   */
  templateClasses?: string;

  /**
   * ARIA label for action
   * Accessibility label for actions
   *
   * @type {string}
   * @example 'Open dropdown menu', 'Select option'
   */
  ariaLabelAction?: string;
}

/**
 * Dropdown component interface
 */
export interface IDropdownComponent
  extends DropdownComponentProps,
    FormControlValueAccessor<string | number | boolean | DropdownDataItem[]> {
  /** Change detector reference */
  changeDetectorRef: ChangeDetectorRef;
  /** Element reference */
  elRef: ElementRef;
  /** HTTP client for API calls */
  httpClient: HttpClient;
  /** Renderer2 for DOM manipulation */
  renderer2: Renderer2;
  /** View container reference */
  viewContainerRef: ViewContainerRef;
  /** Event emitted on dropdown selection */
  onSelect: EventEmitter<DropdownDataItem>;
  /** Event emitted on multi-select */
  onMultiSelect: EventEmitter<DropdownDataItem[]>;
  /** Event emitted when dropdown opens/closes */
  openClose: EventEmitter<boolean>;
  /** Event emitted on search text change */
  onSearchText: EventEmitter<string>;
  /** Event emitted on dataprovider change */
  onDataproviderChange: EventEmitter<DropdownDataItem[]>;
  /** Event emitted on action button click */
  actionEvent: EventEmitter<unknown>;
  /** Subject for typeahead API call URL event */
  typeaheadApiCallUrlEvent: Subject<void>;
  /** Subject for typeahead API call function event */
  typeaheadApiCallFunctionEvent: Subject<void>;
  /** Component constants */
  constants: ComponentConstants;
  /** Whether dropdown is open */
  isOpen: boolean;
  /** Whether dropdown is loading */
  loadingList: boolean;
  /** Selected items array */
  selectedItems: DropdownDataItem[];
  /** Dropdown list array */
  dropdownListArray: unknown[];
  /** Search filter text */
  searchFilterText: string;
  /** Set model on dataprovider change */
  setModelonDataproviderChange(
    dataprovider: DropdownDataItem[],
    model: string | number | boolean
  ): void;
  /** Get selected items */
  getSelectedItems(): DropdownDataItem[];
  /** Empty selected items */
  emptySelectedItems(): void;
  /** Check if item is selected */
  isSelected(option: DropdownDataItem): boolean;
  /** Get current model value */
  getModel(): string | number | boolean | DropdownDataItem[];
  /** Reset model */
  resetModel(): void;
  /** Reset on blur */
  resetOnBlur(): void;
  /** Reset selection */
  resetSelection(): void;
  /** Reset dropdown with optional model */
  reset(model?: string | number | boolean): void;
  /** Disable dropdown */
  disableDropdown(): void;
  /** Enable dropdown */
  enableDropdown(): void;
  /** Toggle disable state */
  toggleDisableDropdown(): void;
  /** Display dropdown */
  displayDropdown(): void;
  /** Hide dropdown */
  hideDropdown(): void;
  /** Toggle dropdown list */
  toggleList(): void;
  /** Remove all selected items */
  removeAllSelectedItems(): void;
  /** Search filter function */
  searchFilter(searchText: string): void;
  /** Typeahead search function */
  typeaheadSearch(searchText: string): void;
}

/**
 * Dropdown list item component interface
 */
export interface IDropdownListComponent {
  /** List item data */
  data: DropdownDataItem;
  /** Whether item is selected */
  selected: boolean;
  /** Whether item is disabled */
  disabled: boolean;
  /** Event emitted on selection */
  onSelect: EventEmitter<DropdownDataItem>;
}
