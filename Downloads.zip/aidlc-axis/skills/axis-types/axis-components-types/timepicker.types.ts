/**
 * @file Timepicker Component Types
 * @description Type definitions for time input picker with spinner controls and keyboard navigation.
 * Supports 12/24 hour formats, min/max time validation, and AM/PM meridian display.
 * @module types/timepicker
 * @packageDocumentation
 */

import type { EventEmitter, ElementRef, ViewContainerRef, Renderer2 } from '@angular/core';
import type { ControlValueAccessor } from '@angular/forms';
import type { BaseComponentProps, FormComponentProps } from './component-common.types';

/**
 * Timepicker configuration service
 *
 * Default configuration values for all timepicker instances.
 *
 * @interface TimepickerConfig
 *
 * @example
 * ```typescript
 * const config: TimepickerConfig = {
 *   hourStep: 1,
 *   minuteStep: 5,
 *   secondsStep: 1,
 *   showMeridian: true,
 *   meridians: ['AM', 'PM'],
 *   arrowkeys: true,
 *   showSpinners: true,
 *   showSeconds: false,
 *   min: new Date(0, 0, 0, 8, 0, 0),  // 8:00 AM
 *   max: new Date(0, 0, 0, 18, 0, 0)  // 6:00 PM
 * };
 * ```
 */
export interface TimepickerConfig {
  /**
   * Hours increment step
   * Step value for hour changes
   *
   * @type {number}
   * @default 1
   * @example 1, 2, 3
   */
  hourStep: number;

  /**
   * Minutes increment step
   * Step value for minute changes
   *
   * @type {number}
   * @default 1
   * @example 1, 5, 15
   */
  minuteStep: number;

  /**
   * Seconds increment step
   * Step value for second changes
   *
   * @type {number}
   * @default 1
   * @example 1, 5, 10
   */
  secondsStep: number;

  /**
   * Whether to show meridian (AM/PM)
   * If true, works in 12H mode. If false, works in 24H mode.
   *
   * @type {boolean}
   * @default true
   */
  showMeridian: boolean;

  /**
   * Meridian labels
   * Labels for AM/PM based on locale
   *
   * @type {string[]}
   * @default ['AM', 'PM']
   * @example ['AM', 'PM'], ['am', 'pm']
   */
  meridians: string[];

  /**
   * Whether to enable arrow key navigation
   * If true, up/down arrow keys change time
   *
   * @type {boolean}
   * @default true
   */
  arrowkeys: boolean;

  /**
   * Whether to show spinner arrows
   * Show up/down arrows above/below inputs
   *
   * @type {boolean}
   * @default true
   */
  showSpinners: boolean;

  /**
   * Whether to show seconds input
   * Display seconds field
   *
   * @type {boolean}
   * @default false
   */
  showSeconds: boolean;

  /**
   * Minimum selectable time
   * Earliest time user can select
   *
   * @type {Date}
   * @example new Date(0, 0, 0, 8, 0, 0) // 8:00 AM
   */
  min: Date;

  /**
   * Maximum selectable time
   * Latest time user can select
   *
   * @type {Date}
   * @example new Date(0, 0, 0, 18, 0, 0) // 6:00 PM
   */
  max: Date;
}

/**
 * Axis timepicker component properties
 *
 * Time input component with dropdown picker, spinners, and keyboard navigation.
 *
 * @interface AxisTimePickerComponentProps
 * @extends BaseComponentProps
 * @extends FormComponentProps
 *
 * @example
 * ```typescript
 * const timepickerConfig: Partial<AxisTimePickerComponentProps> = {
 *   showMeridian: true,
 *   showSpinners: true,
 *   hourStep: 1,
 *   minuteStep: 15,
 *   placeholder: 'Select time',
 *   closeOnOutsideClick: true
 * };
 * ```
 */
export interface AxisTimePickerComponentProps
  extends BaseComponentProps,
    FormComponentProps {
  /**
   * Whether to enable arrow key navigation
   * Up/down arrows change time values
   *
   * @type {boolean}
   * @default true
   */
  arrowkeys?: boolean;

  /**
   * Whether to close picker on outside click
   * Close dropdown when clicking outside
   *
   * @type {boolean}
   * @default true
   */
  closeOnOutsideClick?: boolean;

  /**
   * Hour increment step
   * Hours change by this amount
   *
   * @type {number}
   * @default 1
   */
  hourStep?: number;

  /**
   * Minute increment step
   * Minutes change by this amount
   *
   * @type {number}
   * @default 1
   */
  minuteStep?: number;

  /**
   * Seconds increment step
   * Seconds change by this amount
   *
   * @type {number}
   * @default 1
   */
  secondsStep?: number;

  /**
   * Maximum selectable time
   * Latest time user can select
   *
   * @type {Date}
   */
  max?: Date;

  /**
   * Minimum selectable time
   * Earliest time user can select
   *
   * @type {Date}
   */
  min?: Date;

  /**
   * Meridian labels (AM/PM)
   * Custom labels for meridian
   *
   * @type {string[]}
   * @default ['AM', 'PM']
   */
  meridians?: string[];

  /**
   * Whether picker is initially open
   * Show picker on mount
   *
   * @type {boolean}
   * @default false
   */
  open?: boolean;

  /**
   * Whether to show spinner arrows
   * Display up/down arrows
   *
   * @type {boolean}
   * @default true
   */
  showSpinners?: boolean;

  /**
   * Whether to show meridian (AM/PM)
   * Use 12-hour format with AM/PM
   *
   * @type {boolean}
   * @default true
   */
  showMeridian?: boolean;

  /**
   * Whether to show seconds input
   * Display seconds field
   *
   * @type {boolean}
   * @default false
   */
  showSeconds?: boolean;

  /**
   * Whether timepicker is readonly
   * Display only, no editing
   *
   * @type {boolean}
   * @default false
   */
  readonly?: boolean;

  /**
   * Input placeholder text
   * Placeholder when no time selected
   *
   * @type {string}
   * @example 'Select time', 'HH:mm', '00:00'
   */
  placeholder?: string;
}

/**
 * Axis timepicker component interface
 *
 * Full timepicker component with form control integration and positioning logic.
 *
 * @interface IAxisTimePickerComponent
 * @extends AxisTimePickerComponentProps
 * @extends ControlValueAccessor
 *
 * @example
 * ```typescript
 * // Programmatic control
 * timepicker.openTimePicker(event);
 * timepicker.closeTimePicker(event);
 * const timestamp = timepicker.getTime();
 * ```
 */
export interface IAxisTimePickerComponent
  extends AxisTimePickerComponentProps,
    ControlValueAccessor {
  /**
   * Element reference
   * Reference to host element
   *
   * @type {ElementRef}
   */
  el: ElementRef;

  /**
   * View container reference
   * Container for dynamic component
   *
   * @type {ViewContainerRef}
   */
  viewContainerRef: ViewContainerRef;

  /**
   * Renderer for DOM manipulation
   * Angular renderer service
   *
   * @type {Renderer2}
   */
  renderer: Renderer2;

  /**
   * Event emitted when timepicker closes
   * Fires when picker is dismissed
   *
   * @type {EventEmitter<unknown>}
   */
  onTimepickerClose: EventEmitter<unknown>;

  /**
   * Component reference
   * Reference to picker component
   *
   * @type {unknown}
   */
  componentRef: unknown;

  /**
   * Current model value (Date)
   * Selected time value
   *
   * @type {Date}
   */
  modelValue: Date;

  /**
   * Timepicker display format
   * Format string for time display
   *
   * @type {string}
   * @example 'HH:mm', 'hh:mm A'
   */
  timepickerFormat: string;

  /**
   * Top position for picker
   * CSS top value for positioning
   *
   * @type {unknown}
   */
  top: unknown;

  /**
   * Container element
   * Picker container DOM element
   *
   * @type {HTMLElement}
   */
  containerEl: HTMLElement;

  /**
   * Scroll Y position
   * Scroll position when picker opens
   *
   * @type {number}
   */
  scrollYPosition: number;

  /**
   * Time picker component reference
   * Reference to picker instance
   *
   * @type {unknown}
   */
  timePickerComponentRef: unknown;

  /**
   * Unbind document event handler
   * Function to remove event listeners
   *
   * @type {() => void}
   */
  unbindDocumentEvent: () => void;

  /**
   * Validator function
   * Form validation function
   *
   * @type {unknown}
   */
  validator: unknown;

  /**
   * On touched callback
   * Form control touched handler
   *
   * @type {() => void}
   */
  onTouched: () => void;

  /**
   * On change callback
   * Form control change handler
   *
   * @type {(value: unknown) => void}
   */
  onChange: (value: unknown) => void;

  /**
   * Get time as timestamp
   * Returns time in milliseconds
   *
   * @returns Unix timestamp
   */
  getTime(): number;

  /**
   * Change time format
   * Switch between 12H/24H format
   */
  changeTimeFormat(): void;

  /**
   * Create timepicker component
   * Dynamically create picker instance
   */
  createTimepickerComponent(): void;

  /**
   * Update model value
   * Update selected time
   *
   * @param data - Time data
   */
  updateModelValue(data: unknown): void;

  /**
   * Display timepicker dropdown
   * Show the picker
   */
  displayTimepicker(): void;

  /**
   * Hide timepicker dropdown
   * Close the picker
   */
  hideTimepicker(): void;

  /**
   * Open timepicker
   * Open picker on event
   *
   * @param event - Click event
   */
  openTimePicker(event: Event): void;

  /**
   * Close timepicker
   * Close picker on event
   *
   * @param event - Click/blur event
   * @returns Whether picker was closed
   */
  closeTimePicker(event: unknown): boolean;

  /**
   * Remove timepicker
   * Destroy picker component
   */
  removeTimePicker(): void;

  /**
   * Add document event listener
   * Listen for outside clicks
   */
  addDocumentListener(): void;

  /**
   * Calculate picker position
   * Position picker relative to input
   */
  calculatePosition(): void;

  /**
   * Enable keyboard navigation
   * Set up keyboard event handlers
   */
  keyboardNavigation(): void;

  /**
   * Handle key down events
   * Process keyboard input
   *
   * @param event - Keyboard event
   */
  keyDownHandler(event: unknown): void;

  /**
   * Handle key up events
   * Process key release
   *
   * @param event - Keyboard event
   */
  onKeyup(event: unknown): void;

  /**
   * Smart positioning logic
   * Auto-position picker to fit viewport
   *
   * @param posObj - Position object
   * @param menuPosObj - Menu position object
   */
  smartPositioning(posObj: unknown, menuPosObj: unknown): void;

  /**
   * Position picker at top
   * Place picker above input
   *
   * @param posObj - Position object
   * @param menuPosObj - Menu position object
   * @param menuHeight - Menu height in pixels
   */
  topPositioning(posObj: unknown, menuPosObj: unknown, menuHeight: number): void;

  /**
   * Position picker at bottom
   * Place picker below input
   *
   * @param posObj - Position object
   * @param menuPosObj - Menu position object
   */
  bottomPositioning(posObj: unknown, menuPosObj: unknown): void;

  /**
   * Disable timepicker
   * Set disabled state
   */
  disableTimepicker(): void;

  /**
   * Enable timepicker
   * Remove disabled state
   */
  enableTimepicker(): void;

  /**
   * Toggle timepicker disabled state
   * Switch between enabled/disabled
   */
  toggleTimepicker(): void;
}
