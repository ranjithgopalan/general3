/**
 * Loading component types for Axis Components library
 * @packageDocumentation
 */

import type { BaseComponentProps } from './component-common.types';

/**
 * Loading size options
 */
export type LoadingSize = 'sm' | 'small' | 'md' | 'medium' | 'lg' | 'large';

/**
 * Loading component properties
 */
export interface LoadingComponentProps extends BaseComponentProps {
  /** Loading size */
  size?: LoadingSize;
  /** Loading message text */
  message?: string;
  /** Whether loading is overlay (full screen) */
  overlay?: boolean;
  /** Whether loading is visible */
  visible?: boolean;
  /** Custom spinner icon */
  spinnerIcon?: string;
}

/**
 * Loading component interface
 */
export interface ILoadingComponent extends LoadingComponentProps {
  /** Show loading indicator */
  show(): void;
  /** Hide loading indicator */
  hide(): void;
  /** Toggle loading visibility */
  toggle(): void;
}

/**
 * Loading service configuration
 */
export interface LoadingConfig extends LoadingComponentProps {
  /** Duration in milliseconds (0 for manual dismiss) */
  duration?: number;
  /** Whether to block user interaction */
  blocking?: boolean;
  /** Loading backdrop opacity */
  backdropOpacity?: number;
}

/**
 * Loading service interface
 */
export interface ILoadingService {
  /** Show loading with optional configuration */
  show(config?: LoadingConfig): void;
  /** Hide loading */
  hide(): void;
  /** Check if loading is currently visible */
  isVisible(): boolean;
}

/**
 * Loading reference returned by service
 */
export interface LoadingRef {
  /** Hide this loading instance */
  hide(): void;
  /** Update loading message */
  updateMessage(message: string): void;
  /** Update loading configuration */
  updateConfig(config: Partial<LoadingConfig>): void;
}
