/**
 * @file Dual List Component Types
 * @description Type definitions for dual list transfer component with drag-and-drop.
 * Supports item transfer between two lists, search, sorting, and keyboard navigation.
 * @module types/duallist
 * @packageDocumentation
 */

import type { EventEmitter, QueryList, ViewContainerRef, ChangeDetectorRef, ElementRef } from '@angular/core';
import type { BaseComponentProps, ComponentConstants } from './component-common.types';

/**
 * Dual list component properties
 *
 * Transfer items between available and selected lists with search and sorting.
 *
 * @interface DualListComponentProps
 * @extends BaseComponentProps
 *
 * @example
 * ```typescript
 * const dualListConfig: Partial<DualListComponentProps> = {
 *   availableItems: users,
 *   selectedItems: [],
 *   height: 300,
 *   showSearch: true,
 *   showCheckBox: true,
 *   draggable: true,
 *   renderingLabel: 'name'
 * };
 * ```
 */
export interface DualListComponentProps extends BaseComponentProps {
  /**
   * Available items array
   * Items in the left/available list
   *
   * @type {unknown[]}
   */
  availableItems?: unknown[];

  /**
   * Selected items array
   * Items in the right/selected list
   *
   * @type {unknown[]}
   */
  selectedItems?: unknown[];

  /**
   * List height in pixels
   * Height of both lists
   *
   * @type {number}
   * @default 200
   * @example 300, 400
   */
  height?: number;

  /**
   * List width in pixels
   * Width of both lists
   *
   * @type {number}
   * @example 300, 400
   */
  width?: number;

  /**
   * Whether to show Add button
   * Show button to add selected items
   *
   * @type {boolean}
   * @default true
   */
  showAddBtn?: boolean;

  /**
   * Whether to show Add All button
   * Show button to add all items
   *
   * @type {boolean}
   * @default true
   */
  showAddAllBtn?: boolean;

  /**
   * Whether to show Remove button
   * Show button to remove selected items
   *
   * @type {boolean}
   * @default true
   */
  showRemoveBtn?: boolean;

  /**
   * Whether to show Remove All button
   * Show button to remove all items
   *
   * @type {boolean}
   * @default true
   */
  showRemoveAllBtn?: boolean;

  /**
   * Whether to show Move Up button
   * Show button to move items up
   *
   * @type {boolean}
   * @default true
   */
  showMoveUpBtn?: boolean;

  /**
   * Whether to show Move Down button
   * Show button to move items down
   *
   * @type {boolean}
   * @default true
   */
  showMoveDownBtn?: boolean;

  /**
   * Whether to show all control buttons
   * Show all action buttons
   *
   * @type {boolean}
   * @default true
   */
  showControls?: boolean;

  /**
   * Right panel header text
   * Title for selected/right list
   *
   * @type {string}
   * @example 'Selected Items', 'Assigned Users'
   */
  rightHeader?: string;

  /**
   * Left panel header text
   * Title for available/left list
   *
   * @type {string}
   * @example 'Available Items', 'All Users'
   */
  leftHeader?: string;

  /**
   * Whether to show search input
   * Enable search functionality
   *
   * @type {boolean}
   * @default false
   */
  showSearch?: boolean;

  /**
   * Whether to show checkboxes
   * Enable checkbox selection
   *
   * @type {boolean}
   * @default false
   */
  showCheckBox?: boolean;

  /**
   * Whether items are draggable
   * Enable drag-and-drop functionality
   *
   * @type {boolean}
   * @default false
   */
  draggable?: boolean;

  /**
   * Property name for display label
   * Field to use for item display
   *
   * @type {string}
   * @example 'name', 'label', 'title'
   */
  renderingLabel?: string;

  /**
   * ARIA label for left panel
   * Accessibility label for available list
   *
   * @type {string}
   * @example 'Available items list'
   */
  ariaLabelLeft?: string;

  /**
   * ARIA label for right panel
   * Accessibility label for selected list
   *
   * @type {string}
   * @example 'Selected items list'
   */
  ariaLabelRight?: string;

  /**
   * Custom component for rendering
   * Component to use for item rendering
   *
   * @type {unknown}
   */
  axisIncludeComponent?: unknown;
}

/**
 * Dual list component interface
 *
 * Full dual list with transfer, search, sorting, and keyboard navigation.
 *
 * @interface IDualListComponent
 * @extends DualListComponentProps
 *
 * @example
 * ```typescript
 * // Handle selection events
 * dualList.onSelectionDone.subscribe((data) => {
 *   console.log('Selected items:', data.selectedItems);
 *   console.log('Available items:', data.availableItems);
 * });
 *
 * // Programmatic control
 * dualList.addSelected();
 * dualList.addAllItems();
 * dualList.removeSelected();
 * dualList.moveUp();
 * dualList.moveDown();
 * ```
 */
export interface IDualListComponent extends DualListComponentProps {
  /**
   * Change detector reference
   * Angular change detection
   *
   * @type {ChangeDetectorRef}
   */
  changeDetectorRef: ChangeDetectorRef;

  /**
   * Component constants
   * Localized text strings
   *
   * @type {ComponentConstants}
   */
  constants: ComponentConstants;

  /**
   * Event emitted when selection changes
   * Fires when items are transferred
   *
   * @type {EventEmitter<unknown>}
   */
  onSelectionDone: EventEmitter<unknown>;

  /**
   * Event emitted with all focused items
   * Fires with focused item data
   *
   * @type {EventEmitter<unknown>}
   */
  getAllFocusedItems: EventEmitter<unknown>;

  /**
   * Event emitted with focused item
   * Fires when single item is focused
   *
   * @type {EventEmitter<unknown>}
   */
  getFocusedItem: EventEmitter<unknown>;

  /**
   * Left panel items query list
   * Query list for left panel items
   *
   * @type {QueryList<ViewContainerRef>}
   */
  dualLeftListItem: QueryList<ViewContainerRef>;

  /**
   * Right panel items query list
   * Query list for right panel items
   *
   * @type {QueryList<ViewContainerRef>}
   */
  dualRightListItem: QueryList<ViewContainerRef>;

  /**
   * Left panel row content refs
   * Element references for left rows
   *
   * @type {QueryList<ElementRef>}
   */
  leftPanelRowContentRefs: QueryList<ElementRef>;

  /**
   * Left panel row refs
   * View container refs for left rows
   *
   * @type {QueryList<ViewContainerRef>}
   */
  leftPanelRowRefs: QueryList<ViewContainerRef>;

  /**
   * Right panel row content refs
   * Element references for right rows
   *
   * @type {QueryList<ElementRef>}
   */
  rightPanelRowContentRefs: QueryList<ElementRef>;

  /**
   * Right panel row refs
   * View container refs for right rows
   *
   * @type {QueryList<ViewContainerRef>}
   */
  rightPanelRowRefs: QueryList<ViewContainerRef>;

  /**
   * Selected items list
   * Currently selected items
   *
   * @type {unknown[]}
   */
  selectedList: unknown[];

  /**
   * Search input for left panel
   * Search text for available items
   *
   * @type {string}
   */
  searchInputLeft: string;

  /**
   * Search input for right panel
   * Search text for selected items
   *
   * @type {string}
   */
  searchInputRight: string;

  /**
   * Select all left panel flag
   * Whether all left items selected
   *
   * @type {boolean}
   */
  selectAllLeft: boolean;

  /**
   * Select all right panel flag
   * Whether all right items selected
   *
   * @type {boolean}
   */
  selectAllRight: boolean;

  /**
   * Internal available items
   * Internal storage for available items
   *
   * @type {unknown}
   */
  _availableItems: unknown;

  /**
   * Internal selected items
   * Internal storage for selected items
   *
   * @type {unknown}
   */
  _selectedItems: unknown;

  /**
   * Select items for transfer
   * Mark items for moving
   *
   * @param items - Items to select
   */
  selectItems(items: unknown): void;

  /**
   * Select current item
   * Mark current item for moving
   *
   * @param item - Item to select
   */
  selectCurrentItem(item: unknown): void;

  /**
   * Remove item from selection
   * Deselect item
   *
   * @param item - Item to remove
   */
  removeItem(item: unknown): void;

  /**
   * Add selected items to right list
   * Transfer selected items
   */
  addSelected(): void;

  /**
   * Add all items to right list
   * Transfer all available items
   */
  addAllItems(): void;

  /**
   * Remove selected items from right list
   * Transfer back to available
   */
  removeSelected(): void;

  /**
   * Remove all items from right list
   * Transfer all back to available
   */
  removeAll(): void;

  /**
   * Move selected items up
   * Reorder items up in list
   */
  moveUp(): void;

  /**
   * Move selected items down
   * Reorder items down in list
   */
  moveDown(): void;

  /**
   * Handle keyboard events
   * Process keyboard navigation
   *
   * @param event - Keyboard event
   */
  keyEvent(event: KeyboardEvent): void;

  /**
   * Emit dual list data
   * Emit current state
   */
  emitDualListData(): void;

  /**
   * Handle drag end event
   * Process drag-and-drop completion
   *
   * @param event - Drag event
   */
  dragend(event: DragEvent): void;
}
