/**
 * Alert component types for Axis Components library
 * @packageDocumentation
 */

import type { EventEmitter, ElementRef, ChangeDetectorRef } from '@angular/core';
import type {
  BaseComponentProps,
  AlertType,
  ComponentConstants
} from './component-common.types';

/**
 * Alert component properties
 */
export interface AlertComponentProps extends BaseComponentProps {
  /** Alert type/variant */
  type?: AlertType;
  /** Component kind */
  kind?: string;
  /** Whether alert is closed */
  closed?: boolean;
  /** Whether alert is dismissible */
  dismissible?: boolean;
  /** Whether to auto-close alert */
  autoClose?: boolean;
  /** Auto-close timeout in milliseconds */
  timeOut?: number;
  /** Whether to fade out on close */
  datafadeout?: boolean;
  /** Whether notification is visible */
  isNotificationVisible?: boolean;
  /** Top position for alert */
  top?: string;
}

/**
 * Alert component interface
 */
export interface IAlertComponent extends AlertComponentProps {
  /** Element reference */
  elementRef: ElementRef;
  /** Change detector reference */
  cd: ChangeDetectorRef;
  /** Event emitted when alert closes */
  onClose: EventEmitter<IAlertComponent>;
  /** Component constants */
  constants: ComponentConstants;
  /** Whether alert is active */
  active: boolean;
  /** Alert content */
  content: string;
  /** Whether alert is from alert service */
  alertService: boolean;
  /** Whether alert heading right section exists */
  alertHeadingRight: boolean;
  /** Alert heading content */
  alertHeadingContent: string;
  /** Alert body content */
  alertBodyContent: string;
  /** Alert heading right content */
  alertHeadingRightContent: string;
  /** Heading right content element reference */
  headingRightContent: ElementRef;
  /** Whether heading right content exists */
  headingRightContentExist: boolean;
  /** Close the alert */
  close(): void;
  /** Open the alert */
  openAlert(): void;
  /** Toggle accordion state (for expandable alerts) */
  toggleAccordion(): void;
}

/**
 * Alert notification component interface
 */
export interface IAlertNotificationComponent {
  /** Notification content */
  content?: string;
}

/**
 * Alert heading component interface
 */
export interface IAlertHeadingComponent {
  /** Heading content */
  content?: string;
}

/**
 * Alert heading right component interface
 */
export interface IAlertHeadingRightComponent {
  /** Heading right content */
  content?: string;
}

/**
 * Alert body component interface
 */
export interface IAlertBodyComponent {
  /** Body content */
  content?: string;
}

/**
 * Alert service configuration
 */
export interface AlertConfig extends AlertComponentProps {
  /** Alert message */
  message: string;
  /** Alert heading */
  heading?: string;
  /** Alert heading right content */
  headingRight?: string;
}
