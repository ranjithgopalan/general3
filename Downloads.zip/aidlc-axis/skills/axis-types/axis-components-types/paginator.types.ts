/**
 * @file Paginator Component Types
 * @description Type definitions for pagination controls with configurable page size and navigation.
 * Provides UI for page navigation, page size selection, and displays current page information.
 * @module types/paginator
 * @packageDocumentation
 */

import type { EventEmitter } from '@angular/core';
import type { BaseComponentProps, ComponentConstants } from './component-common.types';

/**
 * Page event data emitted by paginator
 *
 * Contains pagination state information when page changes.
 *
 * @interface PageEvent
 *
 * @example
 * ```typescript
 * const pageEvent: PageEvent = {
 *   length: 100,
 *   pageSize: 10,
 *   pageIndex: 2,
 *   totalPages: 10,
 *   startIndex: 20,
 *   endIndex: 29
 * };
 * ```
 */
export interface PageEvent {
  /**
   * Total number of pages
   * Calculated from length / pageSize
   *
   * @type {number}
   * @example 10 // for 100 items with page size 10
   */
  totalPages?: number;

  /**
   * Total number of items
   * Total length of the dataset
   *
   * @type {number}
   * @required
   * @example 100 // total items in dataset
   */
  length: number;

  /**
   * Current page index (zero-based)
   * The current page being displayed
   *
   * @type {number}
   * @default 0
   * @example 0 // first page, 1 // second page
   */
  pageIndex?: number;

  /**
   * Number of items per page
   * Size of each page
   *
   * @type {number}
   * @default 10
   * @example 10, 25, 50, 100
   */
  pageSize?: number;

  /**
   * Starting index of current page items
   * Zero-based index of first item on current page
   *
   * @type {number}
   * @example 0 // first page, 10 // second page (with pageSize 10)
   */
  startIndex?: number;

  /**
   * Ending index of current page items
   * Zero-based index of last item on current page
   *
   * @type {number}
   * @example 9 // first page (with pageSize 10), 19 // second page
   */
  endIndex?: number;
}

/**
 * Paginator component properties
 *
 * Configuration for pagination controls with customizable page sizes and navigation.
 *
 * @interface PaginatorComponentProps
 * @extends BaseComponentProps
 *
 * @example
 * ```typescript
 * const paginatorConfig: Partial<PaginatorComponentProps> = {
 *   length: 100,
 *   pageSize: 10,
 *   pageSizeOptions: [5, 10, 25, 50],
 *   showFirstLastButtons: true,
 *   hideInput: false
 * };
 * ```
 */
export interface PaginatorComponentProps extends BaseComponentProps {
  /**
   * Total number of items in dataset
   * Total length of data to paginate
   *
   * @type {number}
   * @required
   * @example 100 // 100 total items
   */
  length: number;

  /**
   * Current page size (items per page)
   * Number of items to display per page
   *
   * @type {number}
   * @default 10
   * @example 10, 25, 50
   */
  pageSize?: number;

  /**
   * Current page index (zero-based)
   * The active page number
   *
   * @type {number}
   * @default 0
   * @example 0 // first page, 1 // second page
   */
  pageIndex?: number;

  /**
   * Available page size options
   * Array of page sizes user can select from
   *
   * @type {number[]}
   * @default [5, 10, 25, 50]
   * @example [10, 20, 50, 100]
   */
  pageSizeOptions?: number[];

  /**
   * Whether to show first/last page buttons
   * Display buttons for jumping to first/last page
   *
   * @type {boolean}
   * @default false
   */
  showFirstLastButtons?: boolean;

  /**
   * Whether to show multiple page size dropdown
   * Display dropdown for selecting page size
   *
   * @type {boolean}
   * @default true
   */
  showMultiplePageSize?: boolean;

  /**
   * Whether to hide page input field
   * Hide the manual page number input
   *
   * @type {boolean}
   * @default false
   */
  hideInput?: boolean;

  /**
   * Whether to hide page size selector
   * Hide the page size dropdown
   *
   * @type {boolean}
   * @default false
   */
  hidePageSize?: boolean;
}

/**
 * Paginator component interface
 *
 * Full paginator component with navigation, page size selection, and event emissions.
 *
 * @interface IPaginatorComponent
 * @extends PaginatorComponentProps
 *
 * @example
 * ```typescript
 * // Handle pagination events
 * paginatorComponent.showItems.subscribe((event: PageEvent) => {
 *   console.log(`Page ${event.pageIndex}, showing items ${event.startIndex}-${event.endIndex}`);
 *   this.loadData(event.pageIndex, event.pageSize);
 * });
 *
 * // Programmatic navigation
 * paginatorComponent.setPage(5);
 * paginatorComponent.getNextPage(1); // next page
 * paginatorComponent.getNextPage(-1); // previous page
 * ```
 */
export interface IPaginatorComponent extends PaginatorComponentProps {
  /**
   * Event emitted when page display items change
   * Legacy event for item display changes
   *
   * @type {EventEmitter<unknown>}
   * @deprecated Use showItems instead
   */
  itemsDisplay: EventEmitter<unknown>;

  /**
   * Event emitted when pagination changes
   * Primary event with full pagination information
   *
   * @type {EventEmitter<PageEvent>}
   */
  showItems: EventEmitter<PageEvent>;

  /**
   * Component constants for localization
   * Localized text strings for UI elements
   *
   * @type {ComponentConstants}
   */
  constants: ComponentConstants;

  /**
   * Data provider for pagination
   * Internal data structure for page tracking
   *
   * @type {Array<{id: number; name: string}>}
   */
  dataProvider: Array<{ id: number; name: string }>;

  /**
   * Pagination state object
   * Internal pagination state
   *
   * @type {unknown}
   */
  pagination: unknown;

  /**
   * Settings configuration
   * Additional paginator settings
   *
   * @type {unknown}
   */
  settings: unknown;

  /**
   * Page input element reference
   * Reference to page number input field
   *
   * @type {unknown}
   */
  inputRef: unknown;

  /**
   * Page size dropdown reference
   * Reference to page size selector
   *
   * @type {unknown}
   */
  sizeDropdown: unknown;

  /**
   * Get current page index
   * Returns the current page number
   *
   * @type {number}
   * @readonly
   */
  readonly currentPageIndex: number;

  /**
   * Update paginator options
   * Recalculates pagination based on current settings
   */
  updateOptions(): void;

  /**
   * Navigate to next or previous page
   * Increments/decrements page by specified amount
   *
   * @param increment - Number of pages to move (positive or negative)
   * @example
   * ```typescript
   * paginator.getNextPage(1);  // next page
   * paginator.getNextPage(-1); // previous page
   * ```
   */
  getNextPage(increment: number): void;

  /**
   * Set specific page by index
   * Jumps to a specific page number
   *
   * @param pageIndex - Zero-based page index
   * @example
   * ```typescript
   * paginator.setPage(0);  // go to first page
   * paginator.setPage(5);  // go to 6th page
   * ```
   */
  setPage(pageIndex: number): void;

  /**
   * Get pagination event data
   * Returns current pagination state as PageEvent
   *
   * @param currentPage - Optional current page override
   * @returns Pagination event object
   */
  getPagination(currentPage?: number): PageEvent;

  /**
   * Handle page size selection
   * Triggered when user selects new page size
   *
   * @param event - Selection event from dropdown
   */
  onSelect(event: unknown): void;

  /**
   * Handle page input change
   * Triggered when user manually enters page number
   */
  onInput(): void;
}
