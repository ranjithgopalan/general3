/**
 * @file Component Common Types
 * @description Common types, interfaces, and base props shared across all Axis Components.
 * Provides base properties, form control interfaces, validation, and accessibility features.
 * @module types/component-common
 * @packageDocumentation
 */

import type { EventEmitter, ElementRef } from '@angular/core';
import type { AbstractControl, ValidationErrors } from '@angular/forms';

/**
 * Base component properties shared across all Axis Components
 *
 * Foundation interface providing common properties for all Axis components.
 * Includes accessibility, styling, and identification properties.
 *
 * @interface BaseComponentProps
 *
 * @example
 * ```typescript
 * const buttonProps: BaseComponentProps = {
 *   ariaLabel: 'Submit form',
 *   id: 'submit-btn',
 *   disabled: false,
 *   classes: 'custom-button primary'
 * };
 *
 * const inputProps: BaseComponentProps = {
 *   ariaLabel: 'Email address',
 *   ariaDescribedby: 'email-help-text',
 *   id: 'email-input',
 *   disabled: false
 * };
 * ```
 */
export interface BaseComponentProps {
  /**
   * ARIA label for accessibility
   * Provides accessible name for screen readers
   *
   * @type {string}
   * @see https://www.w3.org/WAI/ARIA/apg/
   * @example 'Submit form', 'Close dialog', 'Search'
   */
  ariaLabel?: string;

  /**
   * ID of element that labels this component
   * References another element's ID for labeling
   *
   * @type {string}
   * @see https://www.w3.org/WAI/ARIA/apg/
   * @example 'form-label-id', 'title-heading'
   */
  ariaLabelledby?: string;

  /**
   * ID of element that describes this component
   * References another element's ID for description
   *
   * @type {string}
   * @see https://www.w3.org/WAI/ARIA/apg/
   * @example 'help-text-id', 'error-message-id'
   */
  ariaDescribedby?: string;

  /**
   * Whether the component is disabled
   * Disables user interaction and applies disabled styling
   *
   * @type {boolean}
   * @default false
   */
  disabled?: boolean;

  /**
   * Whether the component is in view-only mode
   * Displays data without allowing edits
   *
   * @type {boolean}
   * @default false
   */
  viewonly?: boolean;

  /**
   * Font family for the component
   * CSS font-family value
   *
   * @type {string}
   * @example 'Roboto', 'Arial, sans-serif'
   */
  font?: string;

  /**
   * Custom CSS classes
   * Space-separated class names
   *
   * @type {string}
   * @example 'custom-style primary-button', 'mb-4 text-center'
   */
  classes?: string;

  /**
   * Component ID
   * Unique identifier for the component element
   *
   * @type {string}
   * @example 'submit-button', 'email-input', 'user-dropdown'
   */
  id?: string;

  /**
   * Relationship attribute
   * Defines relationship between resources (for links)
   *
   * @type {string}
   * @example 'nofollow', 'noopener', 'noreferrer'
   */
  rel?: string;
}

/**
 * Form control component properties
 */
export interface FormComponentProps extends BaseComponentProps {
  /** Whether the field is required */
  required?: boolean;
  /** Field name for form control */
  name?: string;
  /** Field value */
  value?: string | number | boolean;
  /** Tab index for keyboard navigation */
  tabIndex?: number;
}

/**
 * Component with change detection
 */
export interface ChangeDetectableComponent {
  /** Event emitted when component value changes */
  changeDetect: EventEmitter<unknown>;
  /** Event emitted on blur */
  emitBlurEvent: EventEmitter<unknown>;
}

/**
 * Angular form control value accessor interface
 */
export interface FormControlValueAccessor<T = unknown> {
  /** Write a new value to the component */
  writeValue(value: T): void;
  /** Register a callback function to be called when the value changes */
  registerOnChange(fn: (value: T) => void): void;
  /** Register a callback function to be called when the control is touched */
  registerOnTouched(fn: () => void): void;
  /** Validate the control value */
  validate(control: AbstractControl): ValidationErrors | null;
  /** Set the disabled state of the control */
  setDisabledState?(isDisabled: boolean): void;
}

/**
 * Position type for tooltips, popovers, etc.
 */
export type PlacementPosition = 'top' | 'bottom' | 'left' | 'right' | 'auto';

/**
 * Size options for components
 */
export type ComponentSize = 'sm' | 'small' | 'md' | 'medium' | 'lg' | 'large' | 'xl';

/**
 * Color/theme variants for components
 */
export type ComponentVariant =
  | 'primary'
  | 'secondary'
  | 'success'
  | 'danger'
  | 'warning'
  | 'info'
  | 'light'
  | 'dark';

/**
 * Alert types
 */
export type AlertType = 'success' | 'info' | 'warning' | 'danger' | 'error';

/**
 * Button types
 */
export type ButtonType = 'button' | 'submit' | 'reset';

/**
 * Icon configuration
 */
export interface IconConfig {
  /** Icon name/identifier */
  icon: string;
  /** Icon type (custom or material) */
  type?: 'custom' | 'material';
  /** Icon size */
  size?: string;
  /** Icon color */
  color?: string;
}

/**
 * Validation result
 */
export interface ValidationResult {
  [key: string]: unknown;
}

/**
 * Constants configuration for components - localized text strings
 */
export interface ComponentConstants {
  /** Text for 'Add' button or action */
  add: string;
  /** Text for 'Add All' button or action */
  addALL: string;
  /** Text for 'Remove' button or action */
  remove: string;
  /** Text for 'Remove All' button or action */
  removeAll: string;
  /** Text for 'Move Up' button or action */
  moveUp: string;
  /** Text for 'Move Down' button or action */
  moveDown: string;
  /** Text for 'Select File' button */
  selectFile: string;
  /** Text for 'Select Files' button (multiple) */
  selectFiles: string;
  /** Text label for 'Days' unit */
  days: string;
  /** Text label for 'Hours' unit */
  hours: string;
  /** Text label for 'Minutes' unit */
  minutes: string;
  /** Text label for 'Seconds' unit */
  seconds: string;
  /** Text for 'Select All' action */
  selectAll: string;
  /** Placeholder text prompting user to enter text */
  enterText: string;
  /** Text for 'Today' date selection */
  today: string;
  /** Text for 'Clear' button */
  clear: string;
  /** Text for 'Cancel' button */
  cancel: string;
  /** Text for 'Apply' button */
  apply: string;
  /** Text for 'Confirm' button */
  confirm: string;
  /** ARIA label for pagination controls */
  paginationLabel: string;
  /** Text for 'of' in pagination (e.g., '1 of 10') */
  of: string;
  /** Header text for 404 page not found error */
  pageNotFoundHeader: string;
  /** Body text for 404 page not found error */
  pageNotFoundText: string;
  /** Image source URL for 404 page not found error */
  pageNotFoundImageSrc: string;
  /** Header text for 504 gateway timeout error */
  gatewayTimeoutHeader: string;
  /** Body text for 504 gateway timeout error */
  gatewayTimeoutText: string;
  /** Image source URL for 504 gateway timeout error */
  gatewayTimeoutImageSrc: string;
  /** Text for reload button on gateway timeout page */
  gatewayTimeoutReloadButton: string;
  /** Header text for 401 unauthorized error */
  unAuthorizedHeader: string;
  /** Body text for 401 unauthorized error */
  unAuthorizedText: string;
  /** Image source URL for 401 unauthorized error */
  unAuthorizedImageSrc: string;
  /** Header text for 503 service unavailable error */
  serviceUnavailableHeader: string;
  /** Body text for 503 service unavailable error */
  serviceUnavailableText: string;
  /** Image source URL for 503 service unavailable error */
  serviceUnavailableImageSrc: string;
  /** Text for 'Save' button */
  saveBtn: string;
  /** Text for 'Cancel' button (alternate) */
  cancelBtn: string;
  /** Text for 'Add' button (alternate) */
  addBtn: string;
  /** Text for 'Enable Draw' button in image editor */
  enableDrawBtn: string;
  /** Text for 'Disable Draw' button in image editor */
  disableDrawBtn: string;
  /** Text for 'Load Image' action */
  loadImage: string;
  /** Text for 'Load Image URL' action */
  loadImageUrl: string;
  /** Text for 'Loading' state indicator */
  loading: string;
  /** Text for 'Load Error' message */
  loadError: string;
  /** Text for 'Remove Image' action */
  removeImage: string;
  /** Text label for rectangle drawing tool */
  rectangle: string;
  /** Text for 'Move' button */
  moveBtn: string;
  /** Text for 'Undo' action */
  undo: string;
  /** Text for 'Redo' action */
  redo: string;
  /** ARIA label for expand/collapse toggle */
  expandCollapse: string;
  /** ARIA label for alert close button */
  closeThisAlert: string;
  /** ARIA label for left arrow navigation */
  leftArrow: string;
  /** ARIA label for right arrow navigation */
  rightArrow: string;
  /** ARIA label for breadcrumb navigation */
  breadcrumb: string;
  /** ARIA label for remove date button in datepicker */
  removeDate: string;
  /** ARIA label for previous month button in datepicker */
  previousMonth: string;
  /** ARIA label for next month button in datepicker */
  nextMonth: string;
  /** ARIA label for year selector in datepicker */
  selectYear: string;
  /** ARIA label for previous year button in datepicker */
  previousYear: string;
  /** ARIA label for next year button in datepicker */
  nextYear: string;
  /** Placeholder text for search input */
  search: string;
  /** ARIA label for first page button in pagination */
  firstPage: string;
  /** ARIA label for previous page button in pagination */
  previousPage: string;
  /** ARIA label for next page button in pagination */
  nextPage: string;
  /** ARIA label for last page button in pagination */
  lastPage: string;
  /** ARIA label for scroll to top button */
  scrollTop: string;
  /** ARIA label for scroll to bottom button */
  scrollBottom: string;
  /** ARIA label for increase hours button in timepicker */
  increaseHours: string;
  /** ARIA label for hour input in timepicker */
  changeHour: string;
  /** ARIA label for decrease hours button in timepicker */
  decreaseHour: string;
  /** ARIA label for increase minutes button in timepicker */
  increaseMinutes: string;
  /** ARIA label for minute input in timepicker */
  changeMinute: string;
  /** ARIA label for decrease minutes button in timepicker */
  decreaseMinute: string;
  /** ARIA label for increase seconds button in timepicker */
  increaseSecond: string;
  /** ARIA label for decrease seconds button in timepicker */
  decreaseSecond: string;
  /** ARIA label for second input in timepicker */
  changeSecond: string;
  /** ARIA label for AM/PM toggle in timepicker */
  changeMeridian: string;
  /** Text for 'Step 1' in tour or wizard */
  step1: string;
  /** Text for 'Go to Step' navigation */
  goStep: string;
  /** Text for 'Pause Tour' button */
  pauseTour: string;
  /** Text for 'Continue Tour' button */
  continueTour: string;
  /** ARIA label for tooltip close button */
  closeTooltip: string;
  /** ARIA label for application menu */
  appMenu: string;
  /** ARIA label for clear field button */
  clearField: string;
  /** ARIA label for clear single option button */
  clearOption: string;
  /** ARIA label for clear all options button */
  clearAllOptions: string;
  /** ARIA label when chip is selected */
  chipSelected: string;
  /** ARIA label when chip is not selected */
  chipNotSelected: string;
  /** ARIA label for chip remove button */
  chipRemove: string;
}

/**
 * Element reference with native element
 */
export interface ElementRefWithNative extends ElementRef {
  nativeElement: HTMLElement;
}
