/**
 * @file Combination Chart Types
 * @description Type definitions for combination chart components (bar + line, area + line, multi-grouped).
 * These charts combine multiple visualization types in a single chart area.
 * @module types/combination-charts
 * @packageDocumentation
 */

import type { EventEmitter } from '@angular/core';
import type { BaseChartOptions, ChartSeries } from './chart-common.types';

/**
 * Chart bar multi-grouped component options
 *
 * Configuration for grouped bar charts with multiple bar series.
 *
 * @interface ChartBarMultiGroupedOptions
 * @extends BaseChartOptions
 */
export interface ChartBarMultiGroupedOptions extends BaseChartOptions {
  /** Bar labels array */
  barsLabels?: string[];
  /** Single bar label */
  barsLabel?: string;
  /** Enable clickable bars */
  clickableBars?: boolean;
  /** Message shown for clickable bars */
  clickableBarsMessage?: string;
  /** Use discrete colors per bar */
  discrete?: boolean;
  /** Hide Y-axis labels */
  hideYaxisLabels?: boolean;
  /** Hide badge colors in legend */
  hideBadgeColor?: boolean;
  /** Show grid lines */
  gridLines?: boolean;
  /** Custom tooltip template */
  customTooltip?: string;
  /** Value format string */
  valueFormat?: string;
  /** Number of Y-axis ticks */
  numTicks?: number;
  /** Custom Y-axis tick values */
  yTickValues?: unknown[];
  /** Enable selectable bars */
  selectableBars?: boolean;
  /** X-axis label */
  xAxisLabel?: string;
  /** Y-axis label */
  yAxisLabel?: string;
  /** Y2 axis tick format */
  y2TickFormat?: string;
}

/**
 * Chart bar multi-grouped component interface
 *
 * Grouped bar chart with multiple bar series displayed side-by-side.
 *
 * @interface IChartBarMultiGroupedComponent
 */
export interface IChartBarMultiGroupedComponent {
  /** Bar series keys */
  barKeys: string[];
  /** Number of bar groups */
  barsCount: number;
  /** Chart configuration options */
  chartOptions: ChartBarMultiGroupedOptions;
  /** Legend CSS classes */
  legendClass: Record<string, unknown>;
  /** Count of hidden chart series */
  countOfHiddenChart: number;

  /** Input: Chart options */
  options?: Partial<ChartBarMultiGroupedOptions>;
  /** Input: Chart data */
  data: ChartSeries[];
  /** Input: Selected data */
  selected: unknown;

  /** Output: Selection event */
  ShowSelection: EventEmitter<unknown>;

  /** Get D3 chart instance */
  getChartD3(): unknown;
  /** Get chart ID */
  getId(): string;
  /** Draw the chart */
  drawChart(): void;
  /** Highlight path/series */
  highlightPath(seriesType: unknown, seriesId: unknown): void;
  /** Handle bar click */
  clickBar(data: unknown, p: number, n?: number): void;
  /** Create tooltip */
  makeTooltip(): void;
  /** Show tooltip */
  showTooltip(d: unknown): void;
  /** Show label tooltip */
  showLabelTooltip(d: unknown, i: number): void;
  /** Create gradient */
  makeGradient(chart: unknown, chartId: string): void;
  /** Create tooltip element */
  createTooltip(): void;
  /** Handle mouse out */
  mouseOut(): void;
  /** Check if object is empty */
  isEmptyObject(obj: unknown): boolean;
  /** Track by index */
  trackByIndex(index: number): number;
  /** Handle resize */
  onResize(): void;
  /** Initialize */
  ngOnInit(): void;
  /** After view init */
  ngAfterViewInit(): void;
  /** Cleanup */
  ngOnDestroy(): void;
}

/**
 * Bar plus multi-line chart options
 *
 * Configuration for charts combining bars with multiple line series.
 *
 * @interface BarPlusMultiLineChartOptions
 * @extends BaseChartOptions
 */
export interface BarPlusMultiLineChartOptions extends BaseChartOptions {
  /** Bar series label */
  barsLabel?: string;
  /** Circle radius for line points */
  circleRadius?: number;
  /** Enable clickable bars */
  clickableBars?: boolean;
  /** Clickable bars message */
  clickableBarsMessage?: string;
  /** Use discrete colors */
  discrete?: boolean;
  /** Show grid lines */
  gridLines?: boolean;
  /** Use dashed lines */
  lineDashed?: boolean;
  /** Line series keys */
  lines?: string[];
  /** Line series labels */
  linesLabels?: string[];
  /** Number of ticks */
  numTicks?: number;
  /** Enable selectable bars */
  selectableBars?: boolean;
  /** Show X-axis */
  showXAxis?: boolean;
  /** Show Y-axis */
  showYAxis?: boolean;
  /** X-axis label */
  xAxisLabel?: string;
  /** Y1 axis label (left) */
  y1AxisLabel?: string;
  /** Y2 axis label (right) */
  y2AxisLabel?: string;
  /** Y2 tick format */
  y2TickFormat?: string;
  /** Y1 tick format */
  y1TickFormat?: string;
}

/**
 * Bar plus multi-line chart component interface
 *
 * Combination chart with bars and multiple line series.
 *
 * @interface IBarPlusMultiLineChartComponent
 */
export interface IBarPlusMultiLineChartComponent {
  /** Chart options */
  chartOptions: BarPlusMultiLineChartOptions;
  /** Legend classes */
  legendClass: Record<string, unknown>;
  /** Number of lines */
  lineCount: number;
  /** Line series keys */
  lineKeys: string[];
  /** Y-axis zero line for lines */
  yaxisZeroLine: boolean;
  /** Y-axis zero line for bars */
  yaxisZeroBar: boolean;

  /** Input: Options */
  options?: Partial<BarPlusMultiLineChartOptions>;
  /** Input: Data */
  data: unknown;
  /** Input: Selected */
  selected: unknown;

  /** Output: Selection */
  ShowSelection: EventEmitter<unknown>;

  /** Get D3 chart */
  getChartD3(): unknown;
  /** Draw chart */
  drawChart(): void;
  /** Highlight path */
  highlightPath(seriesType: unknown): void;
  /** Create tooltip */
  makeTooltip(): void;
  /** Show bar tooltip */
  showBarTooltip(count: unknown): void;
  /** Make tooltip content */
  makeTooltipCotent(count: unknown, message: unknown): string;
  /** Show label tooltip */
  showLabelTooltip(d: unknown, i: number): void;
  /** Show point tooltip */
  showPointTooltip(count: unknown): void;
  /** Make gradient */
  makeGradient(chart: unknown, chartId: string): void;
  /** Click bar */
  clickBar(data: unknown, i: number): void;
  /** Create tooltip */
  createTooltip(): void;
  /** Mouse out */
  mouseOut(): void;
  /** Get ID */
  getId(): string;
  /** Check empty */
  isEmptyObject(obj: unknown): boolean;
  /** Track by index */
  trackByIndex(index: number): number;
  /** Resize */
  onResize(): void;
  /** Init */
  ngOnInit(): void;
  /** After view init */
  ngAfterViewInit(): void;
  /** Destroy */
  ngOnDestroy(): void;
}

/**
 * Area plus line chart options
 *
 * Configuration for area charts combined with line series.
 *
 * @interface AreaPlusLineChartOptions
 * @extends BaseChartOptions
 */
export interface AreaPlusLineChartOptions extends BaseChartOptions {
  /** Area series label */
  areaLabel?: string;
  /** Line series keys */
  lines?: string[];
  /** Line series labels */
  linesLabels?: string[];
  /** Circle radius */
  circleRadius?: number;
  /** Use dashed lines */
  lineDashed?: boolean;
  /** Show grid lines */
  gridLines?: boolean;
  /** Number of ticks */
  numTicks?: number;
  /** X-axis label */
  xAxisLabel?: string;
  /** Y-axis label */
  yAxisLabel?: string;
  /** Y-axis tick format */
  yTickFormat?: string;
}

/**
 * Area plus line chart component interface
 *
 * Combination chart with area fill and line series.
 *
 * @interface IAreaPlusLineChartComponent
 */
export interface IAreaPlusLineChartComponent {
  /** Chart options */
  chartOptions: AreaPlusLineChartOptions;
  /** Legend classes */
  legendClass: Record<string, unknown>;
  /** Line keys */
  lineKeys: string[];
  /** Line count */
  lineCount: number;
  /** Y-axis zero value flag */
  yaxisZeroValue: boolean;
  /** Count of hidden charts */
  countOfHiddenChart: number;

  /** Input: Options */
  options?: Partial<AreaPlusLineChartOptions>;
  /** Input: Data */
  data: ChartSeries[];
  /** Input: Selected */
  selected: unknown;

  /** Output: Selection */
  ShowSelection: EventEmitter<unknown>;

  /** Get D3 chart */
  getChartD3(): unknown;
  /** Get ID */
  getId(): string;
  /** Draw chart */
  drawChart(): void;
  /** Mouse out */
  mouseOut(): void;
  /** Create tooltip */
  createTooltip(): void;
  /** Check empty */
  isEmptyObject(obj: unknown): boolean;
  /** Make gradient */
  makeGradient(chart: unknown, chartId: string, gradients: unknown, gradientStatus: unknown): void;
  /** Make tooltip */
  makeTooltip(): void;
  /** Show tooltip */
  showTooltip(d: unknown): void;
  /** Show label tooltip */
  showLabelTooltip(d: unknown, i: number): void;
  /** Highlight path */
  highlightPath(seriesType: unknown, seriesId: unknown): void;
  /** Click area */
  clickArea(data: unknown, i: number): void;
  /** Track by index */
  trackByIndex(index: number): number;
  /** Resize */
  onResize(): void;
  /** Init */
  ngOnInit(): void;
  /** After view init */
  ngAfterViewInit(): void;
  /** Destroy */
  ngOnDestroy(): void;
}
