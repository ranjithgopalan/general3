/**
 * @file Bar Chart Types
 * @description Type definitions for horizontal and vertical bar chart components.
 * Includes options for standard bar charts, combo charts (bars + lines), and bar-plus-multi-line charts.
 * @module types/bar-chart
 * @packageDocumentation
 */

import type { CartesianChartOptions, ChartSeries } from './chart-common.types';

/**
 * Options for bar charts (horizontal and vertical)
 *
 * Extends CartesianChartOptions with bar-specific configuration.
 * Supports interactive bars, dual axes, and combo charts with lines.
 *
 * @interface BarChartOptions
 * @extends CartesianChartOptions
 *
 * @example
 * ```typescript
 * // Simple bar chart
 * const simpleOptions: BarChartOptions = {
 *   caption: 'Sales by Quarter',
 *   height: 400,
 *   barsLabel: 'Revenue',
 *   clickableBars: true,
 *   yaxisZeroLine: true
 * };
 *
 * // Combo chart with bars and lines
 * const comboOptions: BarChartOptions = {
 *   caption: 'Sales & Trends',
 *   barsLabel: 'Revenue',
 *   lines: ['trend'],
 *   linesLabels: ['Trend Line'],
 *   lineDashed: true,
 *   y1AxisLabel: 'Revenue ($)',
 *   y2AxisLabel: 'Trend (%)',
 *   discrete: true
 * };
 * ```
 */
export interface BarChartOptions extends CartesianChartOptions {
  /**
   * Enable clickable bars
   * Allows users to click on bars to select them
   *
   * @type {boolean}
   * @default false
   * @example true // Bars emit click events
   */
  clickableBars?: boolean;

  /**
   * Message to show when bars are clickable
   * Tooltip or help text indicating bars are interactive
   *
   * @type {string}
   * @example 'Click to view details', 'Select for more information'
   */
  clickableBarsMessage?: string;

  /**
   * Enable selectable bars
   * Allows multi-selection of bars
   *
   * @type {boolean}
   * @default false
   */
  selectableBars?: boolean;

  /**
   * Bar labels
   * Label for the bar series (shown in legend)
   *
   * @type {string}
   * @example 'Revenue', 'Sales', 'Count'
   */
  barsLabel?: string;

  /**
   * Use discrete colors for each bar
   * Each bar gets a different color from the palette
   *
   * @type {boolean}
   * @default false
   * @example true // Bar 1: blue, Bar 2: green, Bar 3: red
   */
  discrete?: boolean;

  /**
   * Line style for combination charts
   * Makes lines dashed instead of solid
   *
   * @type {boolean}
   * @default false
   */
  lineDashed?: boolean;

  /**
   * Line series names
   * Array of series keys for lines in combo charts
   *
   * @type {string[]}
   * @example ['trend', 'target'] // Two line series
   */
  lines?: string[];

  /**
   * Labels for line series
   * Display names for each line series (shown in legend)
   *
   * @type {string[]}
   * @example ['Trend Line', 'Target Line']
   */
  linesLabels?: string[];

  /**
   * Circle radius for line points
   * Size of dots at data points on lines
   *
   * @type {number}
   * @default 4
   * @example 6 // 6px radius circles
   */
  circleRadius?: number;

  /**
   * Y-axis zero line for bars
   * Shows a line at y=0 for bar baseline
   *
   * @type {boolean}
   * @default false
   */
  yaxisZeroBar?: boolean;

  /**
   * Y-axis zero line
   * Shows a line at y=0 across the chart
   *
   * @type {boolean}
   * @default false
   */
  yaxisZeroLine?: boolean;

  /**
   * Y1 axis label (left axis)
   * Label for the primary Y-axis
   *
   * @type {string}
   * @example 'Revenue ($)', 'Units Sold'
   */
  y1AxisLabel?: string;

  /**
   * Y2 axis label (right axis)
   * Label for the secondary Y-axis in dual-axis charts
   *
   * @type {string}
   * @example 'Percentage (%)', 'Growth Rate'
   */
  y2AxisLabel?: string;

  /**
   * Y1 axis tick format
   * D3 format string for primary Y-axis
   *
   * @type {string}
   * @example '$,.0f' // Currency format
   * @example '.2f' // Two decimal places
   */
  y1TickFormat?: string;

  /**
   * Y2 axis tick format
   * D3 format string for secondary Y-axis
   *
   * @type {string}
   * @example '.0%' // Percentage format
   */
  y2TickFormat?: string;
}

/**
 * Bar chart data structure
 *
 * Extends ChartSeries with bar-specific properties.
 * Represents a series of bars in a bar chart.
 *
 * @interface BarChartData
 * @extends ChartSeries
 *
 * @example
 * ```typescript
 * const barData: BarChartData = {
 *   key: '2024 Sales',
 *   values: [
 *     { label: 'Q1', value: 150000 },
 *     { label: 'Q2', value: 175000 },
 *     { label: 'Q3', value: 200000 },
 *     { label: 'Q4', value: 225000 }
 *   ],
 *   color: '#4CAF50'
 * };
 *
 * const multipleSeriesData: BarChartData[] = [
 *   {
 *     key: 'Product A',
 *     values: [{ label: 'Jan', value: 100 }, { label: 'Feb', value: 120 }],
 *     color: '#FF6384'
 *   },
 *   {
 *     key: 'Product B',
 *     values: [{ label: 'Jan', value: 90 }, { label: 'Feb', value: 110 }],
 *     color: '#36A2EB'
 *   }
 * ];
 * ```
 */
export interface BarChartData extends ChartSeries {
  /**
   * Optional bar-specific color
   * Overrides the default color for all bars in this series
   *
   * @type {string}
   * @example '#4CAF50', 'rgb(76, 175, 80)', 'green'
   */
  color?: string;
}

/**
 * Bar opacity configuration
 */
export interface BarOpacity {
  /** Opacity value (0-1 or percentage string) */
  opacity: string;
}

/**
 * Horizontal bar chart component interface
 */
export interface IHorizontalBarChartComponent {
  /** Chart data */
  chartData: BarChartData[];
  /** Y-axis zero line enabled */
  yaxisZeroLine: boolean;
  /** Y-axis zero bar enabled */
  yaxisZeroBar: boolean;
  /** Unique chart identifier */
  chartId: string;
  /** Chart configuration options */
  chartOptions: BarChartOptions;
  /** Count of hidden charts */
  countOfHiddenChart: number;
  /** Whether chart has data */
  isDataPresent: boolean;
  /** Whether page is created */
  isPageCreated: boolean;
  /** Legend CSS class */
  legendClass: Record<string, unknown>;
  /** Bar opacity levels for each bar */
  barOpacity: BarOpacity[];
  /** Chart width in pixels */
  chartWidth: number;
  /** Gradient configurations */
  gradients: unknown[];
  /** Whether to hide negative axis */
  hideNegativeAxis: boolean;
  /** Selectable bar ratio for sizing */
  selectableBarRatio: number;
  /** Y-axis width in pixels */
  yWidth: number;
  /** Tick labels for left axis */
  tickLabelsLeft: unknown[];
  /** Tick labels for right axis */
  tickLabelsRight: unknown[];

  /** Chart options input */
  options?: Partial<BarChartOptions>;
  /** Chart data input */
  data: BarChartData[];
  /** Same scale for left and right axes */
  sameLeftRightScale?: boolean;

  /**
   * Get the chart ID
   * @returns Chart identifier
   */
  getId(): string;

  /**
   * Check if object is empty
   * @param obj - Object to check
   * @returns True if empty
   */
  isEmptyObject(obj: Record<string, unknown>): boolean;

  /**
   * Handle bar click event
   * @param data - The clicked bar data
   */
  clickBar(data: unknown): void;

  /**
   * Animate the chart
   */
  animateChart(): void;

  /**
   * Get bar and text widths
   */
  getBarAndTextWidth(): void;

  /**
   * Get next element
   * @param target - Current target element
   */
  getNext(target: unknown): void;

  /**
   * Get previous element
   * @param target - Current target element
   */
  getPrevious(target: unknown): void;

  /**
   * Navigate to first bar
   */
  goFirstBar(): void;

  /**
   * Hide tooltip
   */
  hideTooltip(): void;

  /**
   * Show tooltip
   * @param event - Mouse event
   * @param data - Bar data
   * @param position - Tooltip position
   * @param rowNum - Row number
   * @param valNum - Value number
   * @param badgeColor - Badge color
   */
  showTooltip(
    event: MouseEvent,
    data: unknown,
    position: string,
    rowNum: number,
    valNum: number,
    badgeColor: unknown
  ): void;

  /**
   * Create tooltip element
   */
  makeTooltip(): void;

  /**
   * Set active element
   * @param event - Event object
   */
  setActiveEl(event: unknown): void;

  /**
   * Show label tooltip
   * @param event - Mouse event
   * @param data - Label data
   */
  showLabelTooltip(event: MouseEvent, data: unknown): void;

  /**
   * Toggle bar opacity
   * @param index - Bar index
   */
  toggleOpacity(index: number): void;

  /**
   * Check if element is scrolled into view
   */
  isScrolledIntoView(): void;

  /**
   * Track by index for ngFor
   * @param index - Item index
   */
  trackByIndex(index: number): number;

  /**
   * Handle window resize event
   */
  onResize(): void;

  /**
   * Initialize component
   */
  ngOnInit(): void;

  /**
   * Handle input changes
   */
  ngOnChanges(): void;

  /**
   * After view init lifecycle hook
   */
  ngAfterViewInit(): void;

  /**
   * Draw the chart
   */
  drawChart(): void;

  /**
   * Cleanup on destroy
   */
  ngOnDestroy(): void;
}

/**
 * Vertical bar chart component interface (extends horizontal)
 */
export type IBarChartComponent = IHorizontalBarChartComponent;

/**
 * Bar plus line chart data
 *
 * Combined data structure for charts with both bars and lines.
 * Used in combination charts to display two data types simultaneously.
 *
 * @interface BarPlusLineChartData
 *
 * @example
 * ```typescript
 * const comboData: BarPlusLineChartData = {
 *   bars: [
 *     {
 *       key: 'Revenue',
 *       values: [
 *         { label: 'Q1', value: 150000 },
 *         { label: 'Q2', value: 175000 },
 *         { label: 'Q3', value: 200000 }
 *       ]
 *     }
 *   ],
 *   lines: [
 *     {
 *       key: 'Target',
 *       values: [
 *         { label: 'Q1', value: 160000 },
 *         { label: 'Q2', value: 180000 },
 *         { label: 'Q3', value: 190000 }
 *       ],
 *       color: '#FF6384'
 *     }
 *   ]
 * };
 * ```
 */
export interface BarPlusLineChartData {
  /**
   * Bar series data
   * Array of series to be rendered as bars
   *
   * @type {ChartSeries[]}
   * @example [{ key: 'Revenue', values: [...] }]
   */
  bars: ChartSeries[];

  /**
   * Line series data
   * Array of series to be rendered as lines
   *
   * @type {ChartSeries[]}
   * @example [{ key: 'Target', values: [...], color: '#FF6384' }]
   */
  lines: ChartSeries[];
}

/**
 * Bar plus multi-line chart component interface
 */
export interface IBarPlusMultiLineChartComponent extends Omit<IHorizontalBarChartComponent, 'data'> {
  /** Chart data with bars and lines */
  data: BarPlusLineChartData;
}
