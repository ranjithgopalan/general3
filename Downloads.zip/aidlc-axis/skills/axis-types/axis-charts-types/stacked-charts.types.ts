/**
 * @file Stacked Chart Types
 * @description Type definitions for stacked chart components (horizontal stacked, stacked progress).
 * Used for showing part-to-whole relationships with stacked segments.
 * @module types/stacked-charts
 * @packageDocumentation
 */

import type { BaseChartOptions, ChartDataPoint } from './chart-common.types';
import type { StackedProgressData } from './specialized-charts.types';

/**
 * Horizontal stacked chart options
 *
 * Configuration for horizontal stacked bar charts.
 *
 * @interface HorizontalStackedChartOptions
 * @extends BaseChartOptions
 */
export interface HorizontalStackedChartOptions extends BaseChartOptions {
  /** Chart width */
  width?: number;
  /** Font size */
  fontSize?: number;
  /** X-axis configuration */
  xAxis?: Record<string, unknown>;
  /** Padding around chart */
  padding?: number;
  /** Bar height */
  barHeight?: number;
  /** Label position */
  labelPosition?: 'inside' | 'outside';
  /** Enable label truncation */
  truncate?: boolean;
  /** Enable animation */
  animation?: boolean;
  /** Buffer space */
  bufferSpace?: number;
}

/**
 * Horizontal stacked chart component interface
 *
 * Stacked horizontal bars showing part-to-whole relationships.
 *
 * @interface IHorizontalStackedChartComponent
 */
export interface IHorizontalStackedChartComponent {
  /** Chart options */
  chartOptions: HorizontalStackedChartOptions;
  /** Stacked data map */
  stackedMap: Record<string, unknown>;
  /** Series keys */
  keys: string[];
  /** Default color palette */
  defaultColors: string[];
  /** Left margin tracking */
  useMarginLeft: unknown;

  /** Input: Options */
  options?: Partial<HorizontalStackedChartOptions>;
  /** Input: Data */
  data: ChartDataPoint[];

  /** Draw chart */
  draw(): void;
  /** Create stacked chart */
  createStackedChart(): void;
  /** Trim labels to fit */
  trimLabels(textElements: unknown, wordWidth: number, self: unknown): void;
  /** Handle mouse move */
  mouseMove(p: unknown, i: number, self: unknown, id: string): void;
  /** Destroy chart */
  destroy(): void;
  /** Draw chart */
  drawChart(): void;
  /** Handle key down */
  keyDown(): void;
  /** Append data table */
  appendTable(): void;
  /** Handle resize */
  onResize(): void;
  /** After view init */
  ngAfterViewInit(): void;
}

/**
 * Stacked progress indicator configuration
 */
export interface ProgressIndicator {
  /** Indicator value */
  value: number;
  /** Indicator label */
  label?: string;
  /** Indicator color */
  color?: string;
}

/**
 * Horizontal stacked progress chart options
 *
 * Configuration for progress bar charts with stacked segments.
 *
 * @interface HorizontalStackedProgressChartOptions
 * @extends BaseChartOptions
 */
export interface HorizontalStackedProgressChartOptions extends BaseChartOptions {
  /** Enable animation */
  animation?: boolean;
  /** Color indicator type */
  colorIndicator?: string;
  /** Show scale/axis */
  showScale?: boolean;
  /** Scale configuration */
  scale?: unknown[];
  /** Progress bar size */
  size?: 'small' | 'medium' | 'large';
  /** X-axis labels */
  xAxisLabels?: string[];
  /** Legend labels */
  legendLabels?: string[];
}

/**
 * Horizontal stacked progress chart component interface
 *
 * Progress bars with stacked segments showing completion status.
 *
 * @interface IHorizontalStackedProgressChartComponent
 */
export interface IHorizontalStackedProgressChartComponent {
  /** Chart options */
  chartOptions: HorizontalStackedProgressChartOptions;
  /** Chart width */
  chartWidth: number;
  /** Chart left position */
  chartLeft: number;
  /** Chart open state */
  chartOpen: boolean;
  /** Data error flag */
  dataError: boolean;
  /** Show indicators */
  showIndicators: string;

  /** Input: Indicators */
  indicators?: ProgressIndicator[];
  /** Input: Options */
  options?: Partial<HorizontalStackedProgressChartOptions>;
  /** Input: Data */
  data: StackedProgressData[];

  /** Handle scroll */
  onScroll(): void;
  /** Animate chart */
  animateChart(): void;
  /** Draw chart */
  drawChart(): void;
  /** Get ID */
  getId(): string;
  /** Get next element */
  getNext(target: unknown): void;
  /** Get previous element */
  getPrevious(target: unknown): void;
  /** Go to first bar */
  goFirstBar(): void;
  /** Check empty object */
  isEmptyObject(obj: unknown): boolean;
  /** Check if scrolled into view */
  isScrolledIntoView(): void;
  /** Set active element */
  setActiveEl(event: unknown): void;
  /** Track by index */
  trackByIndex(index: number): number;
  /** Initialize */
  ngOnInit(): void;
}
