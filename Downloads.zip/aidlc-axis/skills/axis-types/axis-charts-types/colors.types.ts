/**
 * Color definitions for Axis Charts
 * @packageDocumentation
 */

import type { ChartColors } from './chart-common.types';

/**
 * Axis Charts color palette
 * Provides predefined color schemes for charts
 */
export const colors: ChartColors = {
  names: {
    background1: [],
    background2: [],
    backgroundGradients: [],
    backgroundShades: [],
    buttons: [],
    foreground1: [],
    foreground2: [],
    status: []
  },
  values: {
    background1: [],
    background2: [],
    background1Gradients: [],
    backgroundShades: [],
    border: [],
    danger: '',
    disabled: '',
    foreground1: [],
    foreground2: [],
    gradient: [[]],
    gradientArea: [[]],
    gradientShades: [[[]]],
    info: '',
    primary: '',
    secondary: '',
    shades: [[]],
    shades0: [],
    shades1: [],
    success: '',
    status: [],
    tertiary: '',
    transparent: '',
    warning: ''
  }
};

/**
 * Color constants exported from axis-charts
 */
export type { ChartColors } from './chart-common.types';
