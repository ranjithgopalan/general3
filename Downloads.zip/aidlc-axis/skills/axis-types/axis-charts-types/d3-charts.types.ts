/**
 * D3 generic charts component types
 * @packageDocumentation
 */

/**
 * Generic D3 chart configuration options
 */
export interface D3ChartOptions {
  /** Chart type identifier */
  type?: string;
  /** Chart dimensions */
  dimensions?: {
    width?: number;
    height?: number;
  };
  /** Margins */
  margin?: {
    top?: number;
    right?: number;
    bottom?: number;
    left?: number;
  };
  /** Custom D3 configuration */
  d3Config?: Record<string, unknown>;
  /** Animation settings */
  animation?: {
    enabled?: boolean;
    duration?: number;
    easing?: string;
  };
  /** Axis configurations */
  axes?: {
    x?: D3AxisConfig;
    y?: D3AxisConfig;
  };
  /** Color scheme */
  colors?: string[] | D3ColorScale;
  /** Enable tooltips */
  tooltips?: boolean | D3TooltipConfig;
  /** Legend configuration */
  legend?: D3LegendConfig;
}

/**
 * D3 axis configuration
 */
export interface D3AxisConfig {
  /** Show the axis */
  show?: boolean;
  /** Axis label */
  label?: string;
  /** Scale type */
  scale?: 'linear' | 'log' | 'time' | 'ordinal';
  /** Domain range */
  domain?: [number, number] | string[];
  /** Tick count */
  ticks?: number;
  /** Tick format */
  tickFormat?: string | ((value: unknown) => string);
  /** Grid lines */
  gridLines?: boolean;
}

/**
 * D3 color scale configuration
 */
export interface D3ColorScale {
  /** Scale type */
  type?: 'categorical' | 'sequential' | 'diverging';
  /** Color range */
  range?: string[];
  /** Domain values */
  domain?: number[] | string[];
}

/**
 * D3 tooltip configuration
 */
export interface D3TooltipConfig {
  /** Enable tooltips */
  enabled?: boolean;
  /** Tooltip template */
  template?: string | ((data: unknown) => string);
  /** Position strategy */
  position?: 'mouse' | 'element';
  /** Offset from position */
  offset?: { x: number; y: number };
}

/**
 * D3 legend configuration
 */
export interface D3LegendConfig {
  /** Show legend */
  show?: boolean;
  /** Legend position */
  position?: 'top' | 'right' | 'bottom' | 'left';
  /** Legend orientation */
  orientation?: 'horizontal' | 'vertical';
  /** Enable legend interactions */
  interactive?: boolean;
}

/**
 * Generic D3 chart data structure
 */
export type D3ChartData = unknown;

/**
 * D3 charts component interface
 */
export interface ID3ChartsComponent {
  /** Unique chart identifier */
  chartId: string;
  /** Chart configuration options */
  options: D3ChartOptions;
  /** Chart data */
  data: D3ChartData;

  /**
   * Initialize component
   */
  ngOnInit(): void;

  /**
   * After view init lifecycle hook
   */
  ngAfterViewInit(): void;

  /**
   * Draw the chart
   */
  drawChart(): void;

  /**
   * Handle window resize event
   */
  onResize(): void;

  /**
   * Cleanup on destroy
   */
  ngOnDestroy(): void;
}
