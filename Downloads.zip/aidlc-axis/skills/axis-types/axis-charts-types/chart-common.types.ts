/**
 * @file Common Chart Types
 * @description Common types and interfaces shared across all Axis Charts components.
 * Provides base configurations for margins, data points, series, legends, axes, and color schemes.
 * @module types/chart-common
 * @packageDocumentation
 */

/**
 * Chart margin configuration
 *
 * Defines spacing around the chart content area in pixels.
 * Used to provide space for axes, labels, and legends.
 *
 * @interface ChartMargin
 *
 * @example
 * ```typescript
 * const margin: ChartMargin = {
 *   top: 20,
 *   right: 40,
 *   bottom: 50,
 *   left: 60
 * };
 *
 * const defaultMargin: ChartMargin = {
 *   top: 10,
 *   right: 10,
 *   bottom: 10,
 *   left: 10
 * };
 * ```
 */
export interface ChartMargin {
  /**
   * Top margin in pixels
   * Provides space above the chart content
   *
   * @type {number}
   * @example 20 // 20px top margin
   */
  top: number;

  /**
   * Right margin in pixels
   * Provides space to the right of the chart content
   *
   * @type {number}
   * @example 40 // 40px right margin
   */
  right: number;

  /**
   * Bottom margin in pixels
   * Provides space below the chart content, typically for X-axis labels
   *
   * @type {number}
   * @example 50 // 50px bottom margin for axis
   */
  bottom: number;

  /**
   * Left margin in pixels
   * Provides space to the left of the chart content, typically for Y-axis labels
   *
   * @type {number}
   * @example 60 // 60px left margin for axis
   */
  left: number;
}

/**
 * Chart data point representing a single value
 *
 * Generic interface for representing individual data points in charts.
 * Supports custom value types via the TValue generic parameter.
 *
 * @interface ChartDataPoint
 * @template TValue - Type of the value (defaults to number)
 *
 * @example
 * ```typescript
 * // Numeric data point
 * const salesData: ChartDataPoint = {
 *   label: 'Q1 2024',
 *   value: 150000,
 *   color: '#4CAF50'
 * };
 *
 * // String value data point
 * const categoryData: ChartDataPoint<string> = {
 *   label: 'Product A',
 *   value: 'High Priority',
 *   metadata: { category: 'electronics', inStock: true }
 * };
 *
 * // Date value data point
 * const timeData: ChartDataPoint<Date> = {
 *   label: 'Jan 2024',
 *   value: new Date('2024-01-01')
 * };
 * ```
 */
export interface ChartDataPoint<TValue = number> {
  /**
   * Label for the data point
   * Displayed in tooltips, legends, and axis labels
   *
   * @type {string}
   * @example 'Q1 2024', 'Product A', 'Monday'
   */
  label: string;

  /**
   * Value of the data point
   * The numeric or custom value to be visualized
   *
   * @type {TValue}
   * @example 150000 // Sales amount
   * @example 75 // Percentage
   * @example 'High' // Priority level
   */
  value: TValue;

  /**
   * Optional color override for this specific data point
   * Overrides the default color scheme for this point
   *
   * @type {string}
   * @example '#4CAF50' // Green hex color
   * @example 'rgb(255, 99, 71)' // RGB color
   * @example 'red' // Named color
   */
  color?: string;

  /**
   * Optional metadata for the data point
   * Store additional custom properties for this data point
   *
   * @type {Record<string, unknown>}
   * @example { category: 'electronics', inStock: true, sku: 'ABC123' }
   */
  metadata?: Record<string, unknown>;
}

/**
 * Series data for multi-series charts
 *
 * Represents a collection of data points grouped under a single series name.
 * Used in line charts, stacked bar charts, and other multi-series visualizations.
 *
 * @interface ChartSeries
 * @template TValue - Type of the values (defaults to number)
 *
 * @example
 * ```typescript
 * // Single series for line chart
 * const revenueS eries: ChartSeries = {
 *   key: '2024 Revenue',
 *   values: [
 *     { label: 'Q1', value: 150000 },
 *     { label: 'Q2', value: 175000 },
 *     { label: 'Q3', value: 200000 },
 *     { label: 'Q4', value: 225000 }
 *   ],
 *   color: '#4CAF50'
 * };
 *
 * // Multiple series for comparison
 * const series: ChartSeries[] = [
 *   { key: 'Product A', values: [...], color: '#FF6384' },
 *   { key: 'Product B', values: [...], color: '#36A2EB', disabled: false }
 * ];
 * ```
 */
export interface ChartSeries<TValue = number> {
  /**
   * Series name/identifier
   * Used in legends and tooltips to identify the series
   *
   * @type {string}
   * @example '2024 Revenue', 'Product A', 'Sales'
   */
  key: string;

  /**
   * Array of data points in this series
   * Each point represents a value at a specific position
   *
   * @type {Array<ChartDataPoint<TValue>>}
   * @example [{ label: 'Q1', value: 100 }, { label: 'Q2', value: 150 }]
   */
  values: Array<ChartDataPoint<TValue>>;

  /**
   * Optional color for the entire series
   * All data points in this series will use this color unless overridden
   *
   * @type {string}
   * @example '#4CAF50', 'rgb(255, 99, 71)', 'blue'
   */
  color?: string;

  /**
   * Whether this series is disabled/hidden
   * Disabled series are not rendered on the chart
   *
   * @type {boolean}
   * @default false
   */
  disabled?: boolean;
}

/**
 * Legend position options
 *
 * Controls where the chart legend is displayed relative to the chart content.
 *
 * @type LegendPosition
 *
 * @example
 * ```typescript
 * // Position legend at the top
 * const position: LegendPosition = 'top';
 *
 * // Hide the legend
 * const hidden: LegendPosition = 'none';
 * ```
 */
export type LegendPosition =
  | 'top'    // Legend above the chart
  | 'right'  // Legend to the right of the chart
  | 'bottom' // Legend below the chart
  | 'left'   // Legend to the left of the chart
  | 'none';  // No legend displayed

/**
 * Base chart options shared across all chart types
 *
 * Common configuration options that apply to all chart components.
 * Specific chart types extend this interface with additional options.
 *
 * @interface BaseChartOptions
 *
 * @example
 * ```typescript
 * const chartOptions: BaseChartOptions = {
 *   caption: 'Sales Performance 2024',
 *   height: 400,
 *   animation: true,
 *   showLegend: 'top',
 *   showTooltips: true,
 *   colors: ['#4CAF50', '#2196F3', '#FFC107'],
 *   margin: { top: 20, right: 20, bottom: 40, left: 60 }
 * };
 * ```
 */
export interface BaseChartOptions {
  /**
   * Chart caption/title
   * Displayed above the chart content
   *
   * @type {string}
   * @example 'Sales Performance 2024', 'Quarterly Revenue'
   */
  caption?: string;

  /**
   * Enable table callback functionality
   * Allows converting chart data to table format
   *
   * @type {boolean}
   * @default false
   */
  tableCallback?: boolean;

  /**
   * Enable chart animations
   * Animates chart rendering and transitions
   *
   * @type {boolean}
   * @default true
   */
  animation?: boolean;

  /**
   * Array of colors to use for chart elements
   * Colors are applied to series, bars, slices, etc. in order
   *
   * @type {string[]}
   * @example ['#FF6384', '#36A2EB', '#FFCE56']
   * @example ['rgb(255, 99, 132)', 'rgb(54, 162, 235)']
   */
  colors?: string[];

  /**
   * Enable gradient fills
   * Applies gradient fills to chart elements instead of solid colors
   *
   * @type {boolean}
   * @default false
   */
  gradient?: boolean;

  /**
   * Gradient color definitions
   * Array of color pairs [startColor, endColor] for gradients
   *
   * @type {string[][]}
   * @example [['#FF6384', '#FF9F40'], ['#36A2EB', '#4BC0C0']]
   */
  gradients?: string[][];

  /**
   * Chart height in pixels
   * Sets the rendered height of the chart
   *
   * @type {number}
   * @default 300
   * @example 400 // 400px height
   */
  height?: number;

  /**
   * Chart margins
   * Spacing around the chart content area
   *
   * @type {Partial<ChartMargin>}
   * @see ChartMargin
   * @example { top: 20, right: 20, bottom: 40, left: 60 }
   */
  margin?: Partial<ChartMargin>;

  /**
   * Legend display position
   * Controls where the legend appears or hides it
   *
   * @type {LegendPosition}
   * @see LegendPosition
   * @default 'bottom'
   * @example 'top' // Legend above chart
   * @example 'none' // No legend
   */
  showLegend?: LegendPosition;

  /**
   * Enable tooltips
   * Shows interactive tooltips on hover
   *
   * @type {boolean}
   * @default true
   */
  showTooltips?: boolean;

  /**
   * Custom tooltip template
   * HTML template string for customizing tooltip content
   *
   * @type {string}
   * @example '<div class="custom-tooltip">{label}: {value}</div>'
   */
  customTooltip?: string;

  /**
   * Show values on bars/slices
   * Displays the numeric value directly on chart elements
   *
   * @type {boolean}
   * @default false
   * @example true // Show "150" on bar
   */
  showValuesOnBar?: boolean;

  /**
   * Enable grid lines
   * Shows horizontal and/or vertical grid lines
   *
   * @type {boolean}
   * @default true
   */
  gridLines?: boolean;

  /**
   * Number of axis ticks
   * Controls the number of tick marks on axes
   *
   * @type {number}
   * @default 5
   * @example 10 // Show 10 tick marks
   */
  numTicks?: number;
}

/**
 * Axis configuration for charts with axes
 *
 * Configures the appearance and behavior of X or Y axes.
 *
 * @interface ChartAxis
 *
 * @example
 * ```typescript
 * const yAxis: ChartAxis = {
 *   show: true,
 *   label: 'Revenue ($)',
 *   tickFormat: '$,.0f',
 *   zeroLine: true
 * };
 *
 * const xAxis: ChartAxis = {
 *   show: true,
 *   label: 'Quarter',
 *   tickFormat: 'Q%d'
 * };
 * ```
 */
export interface ChartAxis {
  /**
   * Show this axis
   * Controls visibility of the axis line and ticks
   *
   * @type {boolean}
   * @default true
   */
  show?: boolean;

  /**
   * Axis label
   * Text displayed alongside the axis
   *
   * @type {string}
   * @example 'Revenue ($)', 'Time (Hours)', 'Category'
   */
  label?: string;

  /**
   * Tick format string
   * D3 format string for formatting tick values
   *
   * @type {string}
   * @example '$,.0f' // Currency: $1,000
   * @example '.2f' // Decimal: 123.45
   * @example '.0%' // Percentage: 75%
   */
  tickFormat?: string;

  /**
   * Enable zero line
   * Shows a special line at the zero value
   *
   * @type {boolean}
   * @default false
   */
  zeroLine?: boolean;
}

/**
 * Options for charts with X and Y axes
 *
 * Configuration for Cartesian coordinate system charts (bar, line, scatter, etc.).
 * Extends BaseChartOptions with axis-specific settings.
 *
 * @interface CartesianChartOptions
 * @extends BaseChartOptions
 *
 * @example
 * ```typescript
 * const options: CartesianChartOptions = {
 *   caption: 'Sales Data',
 *   height: 400,
 *   showXAxis: true,
 *   showYAxis: true,
 *   xAxisLabel: 'Quarter',
 *   yAxisLabel: 'Revenue ($)',
 *   yTickFormat: '$,.0f',
 *   xAxis: { show: true, tickFormat: 'Q%d' },
 *   yAxis: { show: true, zeroLine: true }
 * };
 * ```
 */
export interface CartesianChartOptions extends BaseChartOptions {
  /**
   * X-axis configuration
   * Detailed settings for the X-axis
   *
   * @type {ChartAxis}
   * @see ChartAxis
   */
  xAxis?: ChartAxis;

  /**
   * Y-axis configuration
   * Detailed settings for the Y-axis
   *
   * @type {ChartAxis}
   * @see ChartAxis
   */
  yAxis?: ChartAxis;

  /**
   * Show X-axis
   * Quick toggle to show/hide X-axis
   *
   * @type {boolean}
   * @default true
   */
  showXAxis?: boolean;

  /**
   * Show Y-axis
   * Quick toggle to show/hide Y-axis
   *
   * @type {boolean}
   * @default true
   */
  showYAxis?: boolean;

  /**
   * X-axis label
   * Quick way to set X-axis label text
   *
   * @type {string}
   * @example 'Quarter', 'Month', 'Date'
   */
  xAxisLabel?: string;

  /**
   * Y-axis label
   * Quick way to set Y-axis label text
   *
   * @type {string}
   * @example 'Revenue ($)', 'Count', 'Percentage'
   */
  yAxisLabel?: string;

  /**
   * Y-axis tick format
   * Quick way to set Y-axis tick formatting
   *
   * @type {string}
   * @example '$,.0f' // Currency
   * @example '.0%' // Percentage
   */
  yTickFormat?: string;
}

/**
 * Chart selection event data
 *
 * Event payload emitted when a chart element is clicked or selected.
 *
 * @interface ChartSelectionEvent
 * @template TData - Type of the data item (defaults to unknown)
 *
 * @example
 * ```typescript
 * // Handle bar chart selection
 * function onBarClick(event: ChartSelectionEvent<ChartDataPoint>) {
 *   console.log('Selected:', event.data.label, event.data.value);
 *   console.log('Index:', event.index);
 *   event.element.classList.add('highlighted');
 * }
 *
 * // Handle pie chart selection
 * function onSliceClick(event: ChartSelectionEvent) {
 *   alert(`You clicked: ${event.data.label}`);
 * }
 * ```
 */
export interface ChartSelectionEvent<TData = unknown> {
  /**
   * The selected data item
   * The full data object associated with the clicked element
   *
   * @type {TData}
   * @example { label: 'Q1', value: 150000, color: '#4CAF50' }
   */
  data: TData;

  /**
   * Index of the selected item
   * Zero-based position in the data array
   *
   * @type {number}
   * @example 0 // First item
   * @example 3 // Fourth item
   */
  index: number;

  /**
   * The chart element that was clicked
   * The actual DOM element (bar, slice, point, etc.)
   *
   * @type {HTMLElement}
   * @example <rect class="bar" ...>
   */
  element: HTMLElement;
}

/**
 * Color scheme names available in Axis Charts
 *
 * Named color palettes that can be referenced when configuring charts.
 *
 * @type ColorSchemeName
 *
 * @example
 * ```typescript
 * // Use a named color scheme
 * const scheme: ColorSchemeName = 'background1';
 *
 * // Apply to chart
 * const options = {
 *   colorScheme: 'foreground1' as ColorSchemeName
 * };
 * ```
 */
export type ColorSchemeName =
  | 'background1'        // Primary background color palette
  | 'background2'        // Secondary background color palette
  | 'backgroundGradients' // Background gradient variations
  | 'backgroundShades'   // Background shade variations
  | 'buttons'            // Button-specific color palette
  | 'foreground1'        // Primary foreground color palette
  | 'foreground2'        // Secondary foreground color palette
  | 'status';            // Status indicator colors

/**
 * Color configuration for charts
 *
 * Comprehensive color system used across all Axis Charts components.
 * Provides pre-defined palettes, gradients, semantic colors, and shade variations.
 *
 * @interface ChartColors
 *
 * @example
 * ```typescript
 * // Access named color schemes
 * const colors = chartColors.names.background1;
 * // ['#6A5ACD', '#FF6347', ...]
 *
 * // Access semantic colors
 * const primaryColor = chartColors.values.primary;
 * const dangerColor = chartColors.values.danger;
 *
 * // Access gradient definitions
 * const gradients = chartColors.values.gradient;
 * // [['#6A5ACD', '#FF6347'], ['#4CAF50', '#2196F3']]
 * ```
 */
export interface ChartColors {
  /**
   * Named color schemes mapped to their color arrays
   * Quick access to pre-defined color palettes by name
   *
   * @type {Record<ColorSchemeName, string[]>}
   * @example
   * ```typescript
   * const bg1 = colors.names.background1;
   * const fg1 = colors.names.foreground1;
   * const statusColors = colors.names.status;
   * ```
   */
  names: Record<ColorSchemeName, string[]>;

  /**
   * Color values and gradients organized by purpose
   * Comprehensive collection of colors for different chart elements and states
   */
  values: {
    /**
     * Primary background color palette array
     * Main color set for chart backgrounds and fills
     *
     * @type {string[]}
     * @example ['#6A5ACD', '#FF6347', '#4CAF50', '#2196F3']
     */
    background1: string[];

    /**
     * Secondary background color palette array
     * Alternative color set for backgrounds
     *
     * @type {string[]}
     * @example ['#9C27B0', '#FF9800', '#00BCD4']
     */
    background2: string[];

    /**
     * Gradient variations of background1 colors
     * Pre-computed gradient arrays for background1 palette
     *
     * @type {string[]}
     */
    background1Gradients: string[];

    /**
     * Shaded variations of background colors
     * Lighter/darker versions of background colors
     *
     * @type {string[]}
     */
    backgroundShades: string[];

    /**
     * Border color palette array
     * Colors for chart borders and outlines
     *
     * @type {string[]}
     * @example ['#E0E0E0', '#BDBDBD', '#9E9E9E']
     */
    border: string[];

    /**
     * Danger/error state color
     * Used for error indicators and destructive actions
     *
     * @type {string}
     * @example '#F44336'
     */
    danger: string;

    /**
     * Disabled state color
     * Used for disabled chart elements
     *
     * @type {string}
     * @example '#BDBDBD'
     */
    disabled: string;

    /**
     * Primary foreground color palette array
     * Main colors for text and foreground elements
     *
     * @type {string[]}
     */
    foreground1: string[];

    /**
     * Secondary foreground color palette array
     * Alternative colors for foreground elements
     *
     * @type {string[]}
     */
    foreground2: string[];

    /**
     * Two-color gradient combinations
     * Array of [startColor, endColor] pairs for gradients
     *
     * @type {string[][]}
     * @example [['#6A5ACD', '#FF6347'], ['#4CAF50', '#2196F3']]
     */
    gradient: string[][];

    /**
     * Area chart gradient combinations
     * Specific gradient pairs optimized for area charts
     *
     * @type {string[][]}
     * @example [['#6A5ACD', '#9C27B0'], ['#FF6347', '#FF9800']]
     */
    gradientArea: string[][];

    /**
     * Three-dimensional gradient shade arrays
     * Multi-level gradient definitions for complex effects
     *
     * @type {string[][][]}
     */
    gradientShades: string[][][];

    /**
     * Info state color
     * Used for informational messages and hints
     *
     * @type {string}
     * @example '#2196F3'
     */
    info: string;

    /**
     * Primary brand color
     * Main brand color for the application
     *
     * @type {string}
     * @example '#6A5ACD'
     */
    primary: string;

    /**
     * Secondary brand color
     * Secondary brand color for accents
     *
     * @type {string}
     * @example '#FF6347'
     */
    secondary: string;

    /**
     * Color shade variations organized as 2D array
     * Multiple shade levels for each base color
     *
     * @type {string[][]}
     */
    shades: string[][];

    /**
     * First set of color shades
     * Primary shade variations
     *
     * @type {string[]}
     */
    shades0: string[];

    /**
     * Second set of color shades
     * Secondary shade variations
     *
     * @type {string[]}
     */
    shades1: string[];

    /**
     * Success state color
     * Used for success messages and positive indicators
     *
     * @type {string}
     * @example '#4CAF50'
     */
    success: string;

    /**
     * Status indicator color palette array
     * Colors for status badges and indicators
     *
     * @type {string[]}
     * @example ['#4CAF50', '#FFC107', '#F44336']
     */
    status: string[];

    /**
     * Tertiary brand color
     * Third brand color for additional accents
     *
     * @type {string}
     * @example '#00BCD4'
     */
    tertiary: string;

    /**
     * Transparent/no-fill color value
     * Used for transparent fills
     *
     * @type {string}
     * @example 'transparent', 'rgba(0,0,0,0)'
     */
    transparent: string;

    /**
     * Warning state color
     * Used for warning messages and caution indicators
     *
     * @type {string}
     * @example '#FFC107'
     */
    warning: string;
  };
}
