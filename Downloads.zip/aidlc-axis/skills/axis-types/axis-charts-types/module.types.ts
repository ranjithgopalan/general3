/**
 * Angular module types for Axis Charts
 * @packageDocumentation
 */

import type { ModuleWithProviders } from '@angular/core';

/**
 * Chart module base interface
 */
export interface IChartModule {
  /** Module class reference */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  module: ModuleWithProviders<any>;
}

/**
 * All chart modules exported by axis-charts
 */
export interface IChartsModules {
  /** Donut chart module */
  DonutChartModule: IChartModule;
  /** Horizontal bar chart module */
  HorizontalBarChartModule: IChartModule;
  /** Gauge chart module */
  GaugeChartModule: IChartModule;
  /** Bubble chart module */
  BubbleChartModule: IChartModule;
  /** Funnel chart module */
  FunnelChartModule: IChartModule;
  /** Horizontal stacked chart module */
  HorizontalStackedChartModule: IChartModule;
  /** Horizontal stacked progress chart module */
  HorizontalStackedProgressChartModule: IChartModule;
  /** Area plus line chart module */
  AreaPlusLineChartModule: IChartModule;
  /** Bar plus line chart grouped module */
  BarPlusLineChartGroupedModule: IChartModule;
  /** Bar plus multi-line chart module */
  BarPlusMultiLineChartModule: IChartModule;
  /** Datamap chart module */
  DatamapChartModule: IChartModule;
  /** Body map chart module */
  BodymapChartModule: IChartModule;
  /** Word cloud chart module */
  WordcloudChartModule: IChartModule;
  /** D3 charts module */
  D3ChartsModule: IChartModule;
}
