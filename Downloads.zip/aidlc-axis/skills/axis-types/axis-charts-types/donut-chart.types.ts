/**
 * @file Donut Chart Types
 * @description Type definitions for donut chart and pie chart components.
 * Includes configuration for center content, slices, and interactive features.
 * @module types/donut-chart
 * @packageDocumentation
 */

import type { EventEmitter, ElementRef } from '@angular/core';
import type { BaseChartOptions, ChartMargin, ChartDataPoint, ChartSelectionEvent } from './chart-common.types';

/**
 * Center configuration for donut chart
 *
 * Controls the content displayed in the center hole of a donut chart.
 * Can show both label and value with customizable visibility.
 *
 * @interface DonutChartCenter
 *
 * @example
 * ```typescript
 * const centerConfig: DonutChartCenter = {
 *   label: 'Total Sales',
 *   labelVisible: true,
 *   value: '$1,250,000',
 *   valueVisible: true,
 *   size: 1.2
 * };
 *
 * const simpleCenter: DonutChartCenter = {
 *   label: 'Revenue',
 *   labelVisible: false,
 *   value: '85%',
 *   valueVisible: true,
 *   size: 1.0
 * };
 * ```
 */
export interface DonutChartCenter {
  /**
   * Label text to display in center
   * Descriptive text shown above or alongside the value
   *
   * @type {string}
   * @example 'Total Sales', 'Revenue', 'Completion'
   */
  label: string;

  /**
   * Whether to show the label
   * Controls visibility of the label text
   *
   * @type {boolean}
   * @default true
   */
  labelVisible: boolean;

  /**
   * Size multiplier for center content
   * Scales the font size and spacing of center text
   *
   * @type {number}
   * @default 1.0
   * @example 1.2 // 20% larger
   * @example 0.8 // 20% smaller
   */
  size: number;

  /**
   * Value text to display in center
   * Main numeric or text value shown prominently
   *
   * @type {string}
   * @example '$1,250,000', '85%', '1,234 users'
   */
  value: string;

  /**
   * Whether to show the value
   * Controls visibility of the value text
   *
   * @type {boolean}
   * @default true
   */
  valueVisible: boolean;
}

/**
 * Options specific to donut charts
 *
 * Extends BaseChartOptions with donut/pie chart specific configuration.
 * Controls slice appearance, interactivity, labels, and center content.
 *
 * @interface DonutChartOptions
 * @extends BaseChartOptions
 *
 * @example
 * ```typescript
 * const donutOptions: DonutChartOptions = {
 *   caption: 'Sales by Category',
 *   donutRatio: 0.5,
 *   clickableSlices: true,
 *   selectableSlices: true,
 *   labelsOutside: true,
 *   rotate: 90,
 *   highlighted: true
 * };
 *
 * const pieOptions: DonutChartOptions = {
 *   donutRatio: 0, // Set to 0 for pie chart
 *   showLegend: 'right',
 *   showTooltips: true
 * };
 * ```
 */
export interface DonutChartOptions extends BaseChartOptions {
  /**
   * Enable clickable slices
   * Allows users to click slices to trigger events
   *
   * @type {boolean}
   * @default false
   */
  clickableSlices?: boolean;

  /**
   * Donut hole size ratio (0-1)
   * - 0: Full pie chart (no hole)
   * - 0.5: Half radius hole (typical donut)
   * - 1: Ring with no center area
   *
   * @type {number}
   * @default 0.5
   * @example 0 // Pie chart
   * @example 0.5 // Standard donut
   * @example 0.75 // Thin ring
   */
  donutRatio?: number;

  /**
   * Rotation angle in degrees
   * Rotates the entire chart clockwise
   *
   * @type {number}
   * @default 0
   * @example 90 // Rotate 90 degrees
   * @example 180 // Half rotation
   */
  rotate?: number;

  /**
   * Enable slice highlighting
   * Highlights slices on hover
   *
   * @type {boolean}
   * @default false
   */
  highlighted?: boolean;

  /**
   * Initialize with a slice selected
   * Selects the first slice on chart load
   *
   * @type {boolean}
   * @default false
   */
  initSlice?: boolean;

  /**
   * Extra spacing between slices
   * Adds gaps between slices in pixels
   *
   * @type {number}
   * @default 0
   * @example 2 // 2px gap between slices
   */
  extraSpace?: number;

  /**
   * Padding radius for arcs
   * Inner padding for slice arcs
   *
   * @type {number}
   * @default 0
   */
  arcPaddingRadius?: number;

  /**
   * Buffer space for labels
   * Extra space reserved for label positioning
   *
   * @type {number}
   * @default 10
   */
  labelBufferSpace?: number;

  /**
   * Right line position adjustment
   * Fine-tune label line position on right side
   *
   * @type {number}
   * @default 0
   */
  rightLineAdjustment?: number;

  /**
   * Left line position adjustment
   * Fine-tune label line position on left side
   *
   * @type {number}
   * @default 0
   */
  leftLineAdjustment?: number;

  /**
   * Chart margins
   * Spacing around the chart
   *
   * @type {ChartMargin}
   * @see ChartMargin
   */
  margin?: ChartMargin;

  /**
   * Enable selectable slices
   * Allows multi-selection of slices
   *
   * @type {boolean}
   * @default false
   */
  selectableSlices?: boolean;

  /**
   * Label font size
   * Size of slice labels in pixels
   *
   * @type {number}
   * @default 12
   * @example 14 // 14px labels
   */
  labelFontSize?: number;

  /**
   * Position labels outside the donut
   * Places labels outside slices with connecting lines
   *
   * @type {boolean}
   * @default false
   * @example true // Labels outside with lines
   */
  labelsOutside?: boolean;

  /**
   * Buffer space around chart
   * Padding around the entire chart area
   *
   * @type {number}
   * @default 20
   */
  bufferSpace?: number;

  /**
   * Tooltips configuration
   * Custom tooltip template or configuration
   *
   * @type {string}
   * @example '<div>{label}: {value} ({percent}%)</div>'
   */
  tooltips?: string;

  /**
   * Enable label truncation
   * Truncates long labels with ellipsis
   *
   * @type {boolean}
   * @default false
   */
  truncate?: boolean;
}

/**
 * Donut chart data item
 *
 * Represents a single slice in a donut or pie chart.
 * Extends ChartDataPoint with donut-specific properties.
 *
 * @interface DonutChartData
 * @extends ChartDataPoint
 *
 * @example
 * ```typescript
 * const sliceData: DonutChartData = {
 *   label: 'Electronics',
 *   value: 45000,
 *   color: '#4CAF50',
 *   key: 'electronics',
 *   disabled: false
 * };
 *
 * const chartData: DonutChartData[] = [
 *   { label: 'Electronics', value: 45000, color: '#4CAF50' },
 *   { label: 'Clothing', value: 32000, color: '#2196F3' },
 *   { label: 'Food', value: 28000, color: '#FFC107' }
 * ];
 * ```
 */
export interface DonutChartData extends ChartDataPoint {
  /**
   * Slice key/identifier
   * Unique key for this slice
   *
   * @type {string}
   * @example 'electronics', 'clothing', 'category-1'
   */
  key?: string;

  /**
   * Whether this slice is disabled
   * Disabled slices are grayed out and non-interactive
   *
   * @type {boolean}
   * @default false
   */
  disabled?: boolean;
}

/**
 * Selected slice information
 *
 * Contains information about the currently selected donut slice.
 * Used for tracking selection state and emitting selection events.
 *
 * @interface DonutSliceSelection
 *
 * @example
 * ```typescript
 * const selection: DonutSliceSelection = {
 *   data: {
 *     label: 'Electronics',
 *     value: 45000,
 *     color: '#4CAF50'
 *   },
 *   index: 0
 * };
 *
 * // Handle selection change
 * function onSliceSelected(selection: DonutSliceSelection) {
 *   console.log(`Selected: ${selection.data.label}`);
 *   console.log(`Value: ${selection.data.value}`);
 *   console.log(`Position: ${selection.index}`);
 * }
 * ```
 */
export interface DonutSliceSelection {
  /**
   * The selected data item
   * Full data object for the selected slice
   *
   * @type {DonutChartData}
   * @see DonutChartData
   */
  data: DonutChartData;

  /**
   * Index of the selected slice
   * Zero-based position in the data array
   *
   * @type {number}
   * @example 0 // First slice
   * @example 2 // Third slice
   */
  index: number;
}

/**
 * Donut chart component interface
 */
export interface IDonutChartComponent {
  /** Enable animation */
  animation: boolean;
  /** Center content configuration */
  chartCenter: DonutChartCenter;
  /** Opacity of center content (0-1) */
  chartCenterOpacity: number;
  /** Chart data array */
  chartData: DonutChartData[];
  /** Unique chart identifier */
  chartId: string;
  /** Chart configuration options */
  chartOptions: DonutChartOptions;
  /** Sorted data array */
  dataSorted: DonutChartData[];
  /** Donut hole ratio */
  donutRatio: number;
  /** CSS class for donut ratio */
  donutRatioClass: string;
  /** Duration of highlight animation */
  highlightedDuration: number;
  /** Emphasis strength for highlights */
  highlightedEmphasis: number;
  /** Label of highlighted slice */
  highlightedLabel: string;
  /** Value of highlighted slice */
  highlightedValue: number;
  /** Tooltip for highlighted slice */
  highlightedTooltip: string;
  /** Whether chart has data */
  isDataPresent: boolean;
  /** Label font size */
  labelFontSize: number;
  /** Label vertical position */
  labelTop: number;
  /** Selected slice data */
  selectedSlice: DonutSliceSelection | null;
  /** Value font size */
  valueFontSize: number;
  /** Value letter spacing */
  valueLetterSpacing: number;
  /** Value vertical position */
  valueTop: number;
  /** Chart width in pixels */
  width: number;
  /** Show tooltip for center text */
  showCenterTextTooltip: boolean;
  /** Chart loaded state */
  onload: boolean;

  /** Center configuration (input) */
  center?: Partial<DonutChartCenter>;
  /** Chart height (input) */
  height?: number;
  /** Chart options (input) */
  options?: Partial<DonutChartOptions>;
  /** Chart data (input) */
  data: DonutChartData[];
  /** Selected slice (input/output) */
  selected: DonutSliceSelection | null;

  /** Selection change event emitter */
  ShowSelection: EventEmitter<ChartSelectionEvent<DonutChartData>>;

  /** Reference to center value element 1 */
  chartCenterValue1: ElementRef<HTMLElement>;
  /** Reference to center value element 2 */
  chartCenterValue2: ElementRef<HTMLElement>;
  /** Reference to center value element 3 */
  chartCenterValue3: ElementRef<HTMLElement>;

  /**
   * Calculate text width for given value
   * @param value - The text value
   * @param textHtml - The HTML element
   * @returns Width in pixels
   */
  findTextWidth(value: string, textHtml: HTMLElement): number;

  /**
   * Update element style based on chart dimensions
   * @param element - The element to update
   * @param chartWidth - Width of the chart
   * @param fontSize - Font size to apply
   * @param value - The text value
   */
  updateStyle(element: HTMLElement, chartWidth: number, fontSize: number, value: string): void;

  /**
   * Update font sizes for center text
   */
  updateFontSize(): void;

  /**
   * Handle item selection
   * @param event - The selection event
   */
  getSelectedItem(event: ChartSelectionEvent<DonutChartData>): void;

  /**
   * Enhance chart with additional features
   */
  enhanceChart(): void;

  /**
   * Apply highlighting to chart
   */
  highlightChart(): void;

  /**
   * Handle slice click event
   * @param data - The slice data
   * @param self - Component reference
   */
  clickSlice(data: DonutChartData, self: IDonutChartComponent): void;

  /**
   * Format number with comma separators
   * @param x - Number to format
   * @returns Formatted string
   */
  numberWithCommas(x: number | string): string;

  /**
   * Get the chart ID
   * @returns Chart identifier
   */
  getId(): string;

  /**
   * Get the D3 chart instance
   * @returns D3 chart object
   */
  getChartD3(): unknown;

  /**
   * Check if object is empty
   * @param obj - Object to check
   * @returns True if empty
   */
  isEmptyObject(obj: Record<string, unknown>): boolean;

  /**
   * Get the highlighted slice data
   */
  getHighlightedSlice(): void;

  /**
   * Handle window resize event
   */
  onResize(): void;

  /**
   * Initialize component
   */
  ngOnInit(): void;

  /**
   * Draw the chart
   */
  drawChart(): void;
}
