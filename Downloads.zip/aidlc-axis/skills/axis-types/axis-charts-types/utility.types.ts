/**
 * Chart utility function types
 * @packageDocumentation
 */

/**
 * Truncate text with ellipsis to fit in specified width
 * @param textElements - D3 selection of text elements
 * @param wordWidth - Maximum width in pixels
 */
export type DotMeFunction = (textElements: unknown, wordWidth: number) => void;

/**
 * Position tooltip relative to element or mouse
 * @param tooltip - D3 tooltip selection
 * @param focusElement - Optional element to position relative to
 */
export type PositionTooltipFunction = (tooltip: unknown, focusElement?: HTMLElement) => void;

/**
 * Hide tooltip on mouse out
 * @param tooltip - D3 tooltip selection
 * @returns The hidden tooltip
 */
export type MouseOutFunction = (tooltip: unknown) => unknown;

/**
 * Show tooltip for chart element
 * @param tooltip - D3 tooltip selection
 * @param chartId - Chart identifier
 * @returns The shown tooltip
 */
export type ShowTooltipFunction = (tooltip: unknown, chartId: string) => unknown;

/**
 * Table data for chart data table
 */
export interface ChartTableData {
  /** Column headers */
  headers: string[];
  /** Data rows */
  rows: Array<Array<string | number>>;
}

/**
 * Create accessible data table from chart data
 * @param data - Chart data
 * @param caption - Table caption
 * @param chart - D3 chart selection
 * @param chartId - Chart identifier
 * @param appendOutside - Whether to append outside chart container
 * @returns The created table element
 */
export type TabulateFunction = (
  data: ChartTableData,
  caption: string,
  chart: unknown,
  chartId: string,
  appendOutside?: boolean
) => HTMLTableElement | null;

/**
 * Chart utility functions interface
 */
export interface IChartUtilities {
  /** Text truncation function */
  dotMe: DotMeFunction;
  /** Tooltip positioning function */
  positionTooltip: PositionTooltipFunction;
  /** Mouse out handler */
  mouseOut: MouseOutFunction;
  /** Show tooltip function */
  showTooltip: ShowTooltipFunction;
  /** Table generation function */
  tabulate: TabulateFunction;
}
