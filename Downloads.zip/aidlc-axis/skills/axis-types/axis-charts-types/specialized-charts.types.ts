/**
 * Specialized chart component types (Gauge, Funnel, Bubble, etc.)
 * @packageDocumentation
 */

import type { BaseChartOptions, ChartDataPoint } from './chart-common.types';

/**
 * Gauge chart options
 */
export interface GaugeChartOptions extends BaseChartOptions {
  /** Minimum value */
  min?: number;
  /** Maximum value */
  max?: number;
  /** Threshold values for color zones */
  thresholds?: number[];
  /** Colors for different zones */
  zoneColors?: string[];
  /** Show value label */
  showValue?: boolean;
  /** Value label suffix (e.g., '%', '°F') */
  valueSuffix?: string;
  /** Needle color */
  needleColor?: string;
}

/**
 * Gauge chart data
 */
export interface GaugeChartData {
  /** Current value */
  value: number;
  /** Optional label */
  label?: string;
}

/**
 * Funnel chart stage data
 */
export interface FunnelChartData extends ChartDataPoint {
  /** Stage name */
  stage: string;
  /** Conversion rate to next stage */
  conversionRate?: number;
}

/**
 * Funnel chart options
 */
export interface FunnelChartOptions extends BaseChartOptions {
  /** Show conversion rates */
  showConversionRates?: boolean;
  /** Funnel curve style */
  curveType?: 'linear' | 'curved';
  /** Stage height mode */
  stageHeight?: 'proportional' | 'equal';
}

/**
 * Bubble chart data point
 */
export interface BubbleChartData {
  /** X-axis value */
  x: number;
  /** Y-axis value */
  y: number;
  /** Bubble size */
  size: number;
  /** Bubble label */
  label: string;
  /** Optional color */
  color?: string;
  /** Optional metadata */
  metadata?: Record<string, unknown>;
}

/**
 * Bubble chart series
 */
export interface BubbleChartSeries {
  /** Series name */
  key: string;
  /** Data points */
  values: BubbleChartData[];
  /** Series color */
  color?: string;
}

/**
 * Bubble chart options
 */
export interface BubbleChartOptions extends BaseChartOptions {
  /** X-axis label */
  xAxisLabel?: string;
  /** Y-axis label */
  yAxisLabel?: string;
  /** Show X-axis */
  showXAxis?: boolean;
  /** Show Y-axis */
  showYAxis?: boolean;
  /** Minimum bubble size */
  minBubbleSize?: number;
  /** Maximum bubble size */
  maxBubbleSize?: number;
  /** Enable bubble click */
  clickableBubbles?: boolean;
}

/**
 * Word cloud data item
 */
export interface WordCloudData {
  /** Word text */
  text: string;
  /** Word size/weight */
  size: number;
  /** Optional color */
  color?: string;
  /** Optional rotation */
  rotation?: number;
}

/**
 * Word cloud options
 */
export interface WordCloudOptions extends BaseChartOptions {
  /** Font family */
  fontFamily?: string;
  /** Rotation angles to use */
  rotations?: number[];
  /** Rotation probability (0-1) */
  rotationProbability?: number;
  /** Spiral type */
  spiral?: 'archimedean' | 'rectangular';
  /** Padding between words */
  padding?: number;
}

/**
 * Geographic data point
 */
export interface GeoDataPoint {
  /** Location code (e.g., state code, country code) */
  code: string;
  /** Value for this location */
  value: number;
  /** Location name */
  name?: string;
}

/**
 * Datamap/geographic chart options
 */
export interface DatamapChartOptions extends BaseChartOptions {
  /** Map scope (e.g., 'usa', 'world') */
  scope?: string;
  /** Projection type */
  projection?: string;
  /** Fill color for areas with no data */
  defaultFill?: string;
  /** Enable geographic fills */
  fills?: Record<string, string>;
  /** Zoom enabled */
  zoomable?: boolean;
}

/**
 * Body map data point
 */
export interface BodyMapData {
  /** Body part identifier */
  part: string;
  /** Value for this body part */
  value: number;
  /** Optional label */
  label?: string;
  /** Optional color */
  color?: string;
}

/**
 * Body map chart options
 */
export interface BodyMapChartOptions extends BaseChartOptions {
  /** Body view ('front' or 'back') */
  view?: 'front' | 'back';
  /** Highlighted body parts */
  highlighted?: string[];
  /** Enable clickable parts */
  clickable?: boolean;
}

/**
 * Horizontal stacked progress chart data
 */
export interface StackedProgressData {
  /** Segment label */
  label: string;
  /** Segment value */
  value: number;
  /** Segment color */
  color?: string;
  /** Segment percentage of total */
  percentage?: number;
}

/**
 * Stacked progress chart options
 */
export interface StackedProgressChartOptions extends BaseChartOptions {
  /** Show percentage labels */
  showPercentages?: boolean;
  /** Show value labels */
  showValues?: boolean;
  /** Total value (if different from sum) */
  total?: number;
}
