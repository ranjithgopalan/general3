/**
 * Type definitions for Axis JSONP Interceptor Service
 * @packageDocumentation
 */

import type { HttpEvent, HttpHandler, HttpRequest, HttpInterceptor } from '@angular/common/http';
import type { Observable } from 'rxjs';

/**
 * Interface for the Axis JSONP Interceptor.
 * Custom HTTP interceptor that extends Angular's JsonpInterceptor.
 * Handles JSONP requests for Google Maps API calls.
 */
export interface IAxisJsonpInterceptor extends HttpInterceptor {
  /**
   * Intercepts HTTP requests and handles JSONP conversions.
   * Specifically processes requests to Google Maps API endpoints.
   * Converts regular HTTP requests to JSONP format when needed.
   *
   * @param req - The outgoing HTTP request to intercept
   * @param next - The next interceptor in the chain, or the backend if no more interceptors
   * @returns Observable of the HTTP event stream, including the response
   *
   * @example
   * This interceptor automatically handles requests like:
   * ```typescript
   * // Request to Google Maps API
   * http.get('https://maps.googleapis.com/maps/api/geocode/json?address=...')
   * // Interceptor converts to JSONP format for cross-origin requests
   * ```
   */
  intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>>;
}

/**
 * Configuration options for the JSONP interceptor.
 */
export interface JsonpInterceptorConfig {
  /**
   * URL patterns that should be handled as JSONP requests.
   * Requests matching these patterns will be converted to JSONP format.
   * Supports glob patterns and regular expressions.
   * @example ['*://maps.googleapis.com/*', '*://maps.google.com/*']
   */
  jsonpUrls?: string[];

  /**
   * Name of the callback parameter for JSONP requests.
   * Google Maps API typically uses 'callback' as the parameter name.
   * @default 'callback'
   */
  callbackParam?: string;

  /**
   * Whether to allow credentials in JSONP requests.
   * Generally false for JSONP due to security restrictions.
   * @default false
   */
  withCredentials?: boolean;

  /**
   * Custom headers to include in JSONP requests.
   * Note: JSONP has limited header support due to script tag usage.
   */
  headers?: Record<string, string>;
}

/**
 * Error types that can occur during JSONP request processing.
 */
export interface JsonpError {
  /**
   * Error code identifying the type of error.
   * @example 'TIMEOUT' | 'NETWORK_ERROR' | 'PARSE_ERROR' | 'CALLBACK_ERROR'
   */
  code: string;

  /**
   * Human-readable error message describing what went wrong.
   * @example "JSONP request timed out after 30000ms"
   */
  message: string;

  /**
   * HTTP status code if applicable.
   * JSONP doesn't always have standard HTTP status codes.
   */
  status?: number;

  /**
   * The original HTTP request that failed.
   */
  request: HttpRequest<unknown>;

  /**
   * Additional error details or context.
   */
  details?: Record<string, unknown>;

  /**
   * Timestamp when the error occurred.
   */
  timestamp: number;
}

/**
 * Options for individual JSONP requests.
 * Can be attached to HttpRequest for per-request configuration.
 */
export interface JsonpRequestOptions {
  /**
   * Timeout in milliseconds for the JSONP request.
   * Request will be aborted if response doesn't arrive within this time.
   * @default 30000 (30 seconds)
   */
  timeout?: number;

  /**
   * Custom callback function name for this specific request.
   * If not provided, a unique name will be generated.
   * @example 'myCustomCallback'
   */
  callbackName?: string;

  /**
   * Whether to automatically retry failed JSONP requests.
   * @default false
   */
  retry?: boolean;

  /**
   * Number of retry attempts for failed requests.
   * Only applies if retry is true.
   * @default 3
   */
  maxRetries?: number;

  /**
   * Delay in milliseconds between retry attempts.
   * @default 1000 (1 second)
   */
  retryDelay?: number;
}
