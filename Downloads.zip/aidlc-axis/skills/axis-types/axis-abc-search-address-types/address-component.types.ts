/**
 * Type definitions for Axis ABC Search Address Component
 * @packageDocumentation
 */

import type { EventEmitter, ElementRef } from '@angular/core';
import type { AbstractControl, ValidationErrors } from '@angular/forms';

/**
 * Layout options for the address component display configuration.
 * Controls how the map is displayed in relation to the address input field.
 */
export interface AddressComponentLayout {
  /**
   * Display configuration without showing a map.
   * Only the address input field is visible.
   * @default 'NO_MAP'
   */
  NO_MAP: string;

  /**
   * Display configuration with a full-width map below the address input.
   * The map takes up the full container width and appears under the input field.
   * @default 'FULL_MAP'
   */
  FULL_MAP: string;

  /**
   * Display configuration with map positioned to the right of the address input.
   * Creates a side-by-side layout with input on left and map on right.
   * @default 'RIGHT_MAP'
   */
  RIGHT_MAP: string;
}

/**
 * Configuration object for customizing address component behavior and display.
 * Allows fine-grained control over address formatting, validation, and display options.
 */
export interface AddressComponentConfig {
  /**
   * Custom formatting rules for address display.
   * Defines which address components to include and in what order.
   * @example { street: true, city: true, state: true, zip: true, country: false }
   */
  formatting?: Record<string, boolean>;

  /**
   * Custom labels for address field components.
   * Allows internationalization or custom terminology for address parts.
   * @example { street: 'Street Address', city: 'City/Town', state: 'Province' }
   */
  labels?: Record<string, string>;

  /**
   * Validation rules for address components.
   * Specifies required fields and validation patterns.
   * @example { required: ['street', 'city'], patterns: { zip: /^\d{5}(-\d{4})?$/ } }
   */
  validation?: {
    /** Array of required address component field names */
    required?: string[];
    /** Regular expression patterns for field validation */
    patterns?: Record<string, RegExp>;
  };

  /**
   * Map display settings when map is enabled.
   * Controls zoom level, center point, and map UI options.
   */
  mapSettings?: {
    /** Initial zoom level for the map (1-20, where higher is more zoomed in) */
    zoom?: number;
    /** Whether to show zoom controls on the map */
    showZoomControls?: boolean;
    /** Whether to show map type controls (satellite, terrain, etc.) */
    showMapTypeControls?: boolean;
    /** Whether to show street view controls */
    showStreetViewControls?: boolean;
  };
}

/**
 * Structured address data returned from Google Maps API.
 * Contains all components of a geocoded address with latitude/longitude coordinates.
 */
export interface AddressData {
  /**
   * Full formatted address as returned by Google Maps.
   * Example: "1600 Amphitheatre Parkway, Mountain View, CA 94043, USA"
   */
  formattedAddress: string;

  /**
   * Street number component of the address.
   * Example: "1600"
   */
  streetNumber?: string;

  /**
   * Street name component (route) of the address.
   * Example: "Amphitheatre Parkway"
   */
  street?: string;

  /**
   * City or locality component of the address.
   * Example: "Mountain View"
   */
  city?: string;

  /**
   * State, province, or administrative area level 1.
   * Example: "California" or "CA"
   */
  state?: string;

  /**
   * Postal code or ZIP code.
   * Example: "94043"
   */
  postalCode?: string;

  /**
   * Country name.
   * Example: "United States"
   */
  country?: string;

  /**
   * ISO 3166-1 alpha-2 country code.
   * Example: "US" for United States
   */
  countryCode?: string;

  /**
   * Latitude coordinate of the geocoded address location.
   * Range: -90 to 90 degrees
   * @example 37.4224764
   */
  latitude: number;

  /**
   * Longitude coordinate of the geocoded address location.
   * Range: -180 to 180 degrees
   * @example -122.0842499
   */
  longitude: number;

  /**
   * Google Place ID for the address.
   * Unique identifier that can be used to retrieve place details.
   * @example "ChIJ2eUgeAK6j4ARbn5u_wAGqWA"
   */
  placeId?: string;

  /**
   * Types of the address components as defined by Google Maps.
   * Example: ["street_address", "premise", "political"]
   */
  types?: string[];

  /**
   * Additional address components not captured in standard fields.
   * May include sublocality, neighborhood, administrative areas, etc.
   */
  additionalComponents?: Record<string, string>;
}

/**
 * Event emitted when an address is selected or changed.
 * Contains both the structured address data and the original event.
 */
export interface AddressChangeEvent {
  /**
   * Structured address data containing all address components.
   */
  address: AddressData;

  /**
   * Whether the address was validated by Google Maps API.
   * False if manually entered without autocomplete selection.
   */
  isValid: boolean;

  /**
   * Original DOM or Angular event that triggered the change.
   */
  originalEvent?: Event;
}

/**
 * Event emitted when an invalid address is detected.
 * Provides information about validation failures.
 */
export interface InvalidAddressEvent {
  /**
   * The invalid address string that was entered.
   */
  addressString: string;

  /**
   * Specific validation error message or reason for invalidity.
   * @example "Address not found in Google Maps"
   * @example "Required field 'city' is missing"
   */
  error: string;

  /**
   * Error code categorizing the type of validation failure.
   * @example "NOT_FOUND" | "INCOMPLETE" | "INVALID_FORMAT"
   */
  errorCode?: string;

  /**
   * Original DOM or Angular event that triggered the validation.
   */
  originalEvent?: Event;
}

/**
 * Interface for the Axis Address Component implementing ControlValueAccessor.
 * Main Angular component for Google Maps address search with autocomplete.
 * Provides address input with optional map display and comprehensive validation.
 */
export interface IAxisAddressComponent {
  /**
   * Whether the Google Maps API has been successfully loaded.
   * Set to true after API initialization completes.
   * @default false
   */
  apiLoaded: boolean;

  /**
   * Array of ISO 3166-1 alpha-2 country codes to restrict autocomplete results.
   * Limits address suggestions to specified countries.
   * @example ['us', 'ca', 'mx'] // Restrict to North America
   * @default []
   */
  restrictedCountries: string[];

  /**
   * Whether to filter out addresses that don't include street numbers.
   * When true, only addresses with street-level precision are accepted.
   * Useful for requiring specific delivery addresses vs general locations.
   * @default false
   */
  filterStreet: boolean;

  /**
   * Type of address content to return in formatted output.
   * Options: 'full' | 'short' | 'custom'
   * - 'full': Returns complete formatted address
   * - 'short': Returns abbreviated version (e.g., state codes instead of full names)
   * - 'custom': Uses custom format defined in config
   * @default 'full'
   */
  contentType: string;

  /**
   * Whether to display the formatted address string below the input field.
   * Shows the Google Maps formatted address as read-only text.
   * @default false
   */
  showFormattedAddress: boolean;

  /**
   * Whether the component is in view-only mode.
   * When true, the input is read-only and cannot be modified.
   * Map (if visible) remains interactive for viewing.
   * @default false
   */
  viewonly: boolean;

  /**
   * ARIA label for accessibility.
   * Provides a descriptive label for screen readers when ariaLabelledby is not used.
   * @example "Enter your delivery address"
   */
  ariaLabel: string;

  /**
   * ID of element that labels this component for accessibility.
   * Used for ARIA labelling by reference to another element's ID.
   * @example "address-field-label"
   */
  ariaLabelledby: string;

  /**
   * ID of element that describes this component for accessibility.
   * Used for ARIA description by reference to another element's ID.
   * @example "address-field-help-text"
   */
  ariaDescribedby: string;

  /**
   * Configuration object for customizing component behavior.
   * See AddressComponentConfig for detailed options.
   */
  config: AddressComponentConfig;

  /**
   * Custom error message to display when address validation fails.
   * Overrides default validation error messages.
   * @example "Please enter a valid street address with city and state"
   */
  errorMessage: string;

  /**
   * Whether the map should be visible.
   * When true and layout includes a map, the map is shown.
   * @default false
   */
  isMapVisible: boolean;

  /**
   * Layout mode for component display.
   * One of: 'NO_MAP' | 'FULL_MAP' | 'RIGHT_MAP'
   * See AddressComponentLayout for descriptions.
   * @default 'NO_MAP'
   */
  layout: string;

  /**
   * Whether the address field is required for form validation.
   * When true, empty values will fail validation.
   * @default false
   */
  required: boolean;

  /**
   * Placeholder text shown in the address input field when empty.
   * @example "Enter your address"
   * @default "Search for an address"
   */
  placeholder: string;

  /**
   * Whether to allow manual address entry without Google Maps autocomplete.
   * When true, users can type and submit addresses without selecting from suggestions.
   * When false, users must select from autocomplete suggestions.
   * @default false
   */
  manualAddress: boolean;

  /**
   * Regular expression pattern for custom address validation.
   * Applied to the input value when manual address entry is enabled.
   * @example "^[0-9]+\\s+[A-Za-z]+.*" // Must start with numbers then street name
   */
  regex: string;

  /**
   * Event emitted when address is selected or changed.
   * Provides structured address data with all components.
   */
  addressChange: EventEmitter<AddressChangeEvent>;

  /**
   * Event emitted when an invalid address is detected.
   * Provides error details and the invalid input value.
   */
  invalidAddress: EventEmitter<InvalidAddressEvent>;

  /**
   * Reference to the native address input element.
   * Used for DOM manipulation and focus management.
   */
  addressRef: ElementRef;

  /**
   * Current address model value.
   * Can be a string (manual entry) or AddressData object (from autocomplete).
   */
  addressModel: string | AddressData;

  /**
   * Whether the input is disabled.
   * When true, user cannot interact with the input field.
   * @default false
   */
  disabled: boolean;

  /**
   * Whether the current address is invalid based on validation rules.
   * @default false
   */
  isInvalidAddress: boolean;

  /**
   * Layout constants object defining available layout modes.
   */
  readonly LAYOUT: AddressComponentLayout;

  /**
   * Google Maps MapOptions for configuring the embedded map.
   * Controls map appearance and behavior.
   */
  options: google.maps.MapOptions;

  /**
   * Center coordinates for the map display.
   * Updates when a new address is geocoded.
   */
  center: google.maps.LatLngLiteral;

  /**
   * Zoom level for the map.
   * Range: 1-20, where higher values show more detail.
   * @default 15
   */
  zoom: number;

  /**
   * Options for the marker displayed on the map at the address location.
   */
  markerOptions: google.maps.MarkerOptions;

  /**
   * Array of marker positions to display on the map.
   * Typically contains a single marker for the selected address.
   */
  markerPosition: google.maps.LatLngLiteral[];

  /**
   * Whether an address has been selected from the autocomplete suggestions.
   * True after user selects from dropdown, false after manual input changes.
   * @default false
   */
  isSelected: boolean;

  /**
   * Lifecycle hook called after component initialization.
   * Initializes the Google Maps API and sets up autocomplete.
   */
  ngOnInit(): void;

  /**
   * Lifecycle hook called before component destruction.
   * Cleans up event listeners and subscriptions.
   */
  ngOnDestroy(): void;

  /**
   * Writes a new value to the component.
   * Part of ControlValueAccessor interface for Angular forms integration.
   * @param value - Address string or AddressData object to set
   */
  writeValue(value: string | AddressData): void;

  /**
   * Registers a callback function to be called when the value changes.
   * Part of ControlValueAccessor interface.
   * @param fn - Callback function that receives the new value
   */
  registerOnChange(fn: (value: string | AddressData) => void): void;

  /**
   * Registers a callback function to be called when the control is touched.
   * Part of ControlValueAccessor interface.
   * @param fn - Callback function to call on touch events
   */
  registerOnTouched(fn: () => void): void;

  /**
   * Validates the address input value.
   * Part of Validator interface for custom form validation.
   * @param control - The AbstractControl to validate
   * @returns ValidationErrors object if invalid, null if valid
   */
  validate(control: AbstractControl): ValidationErrors | null;

  /**
   * Sets the disabled state of the component.
   * Part of ControlValueAccessor interface.
   * @param isDisabled - Whether the component should be disabled
   */
  setDisabledState(isDisabled: boolean): void;

  /**
   * Callback function for Google Maps autocomplete place_changed event.
   * Called when user selects an address from the autocomplete dropdown.
   * Retrieves place details and updates the component state.
   */
  autoCompleteServiceCallback(): void;

  /**
   * Initializes the Google Maps Places Autocomplete API.
   * Sets up the autocomplete widget and configures restrictions.
   */
  initializeAddressApi(): void;

  /**
   * Retrieves detailed place information by Place ID.
   * Used to get full address details after autocomplete selection.
   */
  getPlaceById(): void;

  /**
   * Maps Google Maps PlaceResult data to structured AddressData format.
   * Extracts address components and organizes them into the component's data model.
   * @param data - PlaceResult object from Google Maps API
   */
  mapAddress(data: google.maps.places.PlaceResult): void;

  /**
   * Gets formatted address string based on contentType setting.
   * Returns full or abbreviated address format.
   * @param data - Address data object
   * @returns Formatted address string
   */
  getAddressByContentType(data: AddressData): string;

  /**
   * Gets custom formatted address string based on config settings.
   * Applies custom formatting rules defined in component config.
   * @param data - Address data object
   * @returns Custom formatted address string
   */
  getCustomAddress(data: AddressData): string;

  /**
   * Clears the current address selection.
   * Resets the input field and removes map marker.
   * @param onClear - Optional callback function to execute after clearing
   */
  clearLocation(onClear?: () => void): void;

  /**
   * Clears the internal address model.
   * Resets the component state to initial empty state.
   */
  clearModel(): void;

  /**
   * Handles keydown events on the input field.
   * Manages special keys like Enter, Escape, and navigation keys.
   * @param event - Keyboard event
   */
  onKeyDown(event: KeyboardEvent): void;

  /**
   * Handles input events on the address field.
   * Resets validation state and tracks manual input changes.
   * @param event - Input event
   */
  onInput(event: Event): void;

  /**
   * Handles blur events when input loses focus.
   * Triggers validation and touch callbacks for form integration.
   */
  onBlurred(): void;
}
