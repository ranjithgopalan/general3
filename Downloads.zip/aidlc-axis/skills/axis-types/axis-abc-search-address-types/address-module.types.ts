/**
 * Type definitions for Axis Address Module
 * @packageDocumentation
 */

/**
 * Interface for the Axis Address Module.
 * Angular module that provides Google Maps address search functionality.
 * Includes the AxisAddressComponent and necessary dependencies.
 */
export interface IAxisAddressModule {
  /**
   * Module constructor.
   * Performs any necessary module-level initialization.
   */
  new (): IAxisAddressModule;
}

/**
 * Configuration for initializing the Axis Address Module.
 * Allows module-level settings that apply to all component instances.
 */
export interface AxisAddressModuleConfig {
  /**
   * Google Maps API key for all components in the module.
   * If not provided, components will need to initialize the API individually.
   * @example "AIzaSyB..."
   */
  apiKey?: string;

  /**
   * Default libraries to load with Google Maps API.
   * Applied to all components unless overridden at component level.
   * @default ['places']
   * @example ['places', 'geometry', 'visualization']
   */
  defaultLibraries?: string[];

  /**
   * Default region bias for all address searches.
   * Two-letter ISO country code.
   * @example "us" // Default to US addresses
   * @example "gb" // Default to UK addresses
   */
  defaultRegion?: string;

  /**
   * Default language for Google Maps API.
   * ISO 639-1 language code.
   * @default Browser language
   * @example "en" // English
   * @example "es" // Spanish
   */
  defaultLanguage?: string;

  /**
   * Whether to eagerly load Google Maps API on module initialization.
   * When true, API loads immediately when module is loaded.
   * When false, API loads on first component use.
   * @default false
   */
  eagerLoad?: boolean;

  /**
   * Global configuration applied to all address components.
   * Component-level config can override these settings.
   */
  globalComponentConfig?: {
    /**
     * Default layout for all components.
     * @default 'NO_MAP'
     */
    defaultLayout?: string;

    /**
     * Default placeholder text for all components.
     * @default "Search for an address"
     */
    defaultPlaceholder?: string;

    /**
     * Whether manual address entry is allowed by default.
     * @default false
     */
    allowManualEntry?: boolean;

    /**
     * Whether to filter out non-street addresses by default.
     * @default false
     */
    filterStreetAddresses?: boolean;
  };
}

/**
 * Injection token for providing module configuration.
 * Use this token to provide AxisAddressModuleConfig in Angular's DI system.
 *
 * @example
 * ```typescript
 * import { AXIS_ADDRESS_MODULE_CONFIG } from 'axis-abc-search-address-types';
 *
 * @NgModule({
 *   imports: [AxisAddressModule],
 *   providers: [
 *     {
 *       provide: AXIS_ADDRESS_MODULE_CONFIG,
 *       useValue: {
 *         apiKey: 'YOUR_API_KEY',
 *         defaultRegion: 'us',
 *         eagerLoad: true
 *       }
 *     }
 *   ]
 * })
 * export class AppModule { }
 * ```
 */
export const AXIS_ADDRESS_MODULE_CONFIG = 'AXIS_ADDRESS_MODULE_CONFIG';
