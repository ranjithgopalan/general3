/**
 * Type definitions for Axis Google Maps Service
 * @packageDocumentation
 */

import type { HttpClient } from '@angular/common/http';
import type { Observable, BehaviorSubject } from 'rxjs';

/**
 * Configuration options for Google Maps API initialization.
 * Defines which libraries to load and regional settings.
 */
export interface GoogleMapServiceConfig {
  /**
   * Google Maps API key for authentication.
   * Required for using Google Maps services.
   * Obtain from Google Cloud Console.
   * @example "AIzaSyB..."
   */
  apiKey: string;

  /**
   * Array of Google Maps libraries to load.
   * Common libraries: 'places', 'geometry', 'drawing', 'visualization'
   * @default ['places']
   * @example ['places', 'geometry']
   */
  libraries?: string[];

  /**
   * ISO 3166-1 alpha-2 country code for regional bias.
   * Biases autocomplete results toward a specific country.
   * Does not restrict results, just prioritizes them.
   * @example "us" // Bias toward United States
   * @example "gb" // Bias toward United Kingdom
   */
  region?: string;

  /**
   * Language code for Google Maps UI and results.
   * Uses ISO 639-1 language codes.
   * @default Browser language or "en"
   * @example "en" // English
   * @example "es" // Spanish
   * @example "fr" // French
   */
  language?: string;

  /**
   * Version of the Google Maps API to load.
   * Defaults to 'weekly' (latest stable release).
   * Can specify a specific version number for consistency.
   * @default "weekly"
   * @example "3.54" // Specific version
   */
  version?: string;
}

/**
 * Interface for the Axis Google Maps Service.
 * Manages Google Maps API initialization and loading state.
 * Provides centralized API management for multiple address components.
 */
export interface IAxisGoogleMapService {
  /**
   * Array of configuration values for the service.
   * Stores API keys, library names, and other settings.
   * @internal
   */
  values: string[];

  /**
   * List of Google Maps libraries to load.
   * Determines which API features are available.
   * Common values: ['places', 'geometry', 'drawing', 'visualization']
   * @default ['places']
   */
  libraries: string[];

  /**
   * Regional bias for Google Maps results.
   * Two-letter ISO country code (e.g., 'us', 'uk', 'ca').
   * Biases search results toward the specified region without restricting them.
   * @example "us" // Prefer US results
   * @example "ca" // Prefer Canadian results
   */
  region: string;

  /**
   * Whether the Google Maps API has been initialized.
   * True after successful API load, false before or if load failed.
   * @default false
   */
  mapInit: boolean;

  /**
   * Observable that emits the loading state of Google Maps API.
   * Emits true when API is loaded and ready, false otherwise.
   * Components can subscribe to know when API is available.
   * @example
   * ```typescript
   * service.mapLoaded$.subscribe(loaded => {
   *   if (loaded) {
   *     // Initialize autocomplete
   *   }
   * });
   * ```
   */
  mapLoaded$: BehaviorSubject<boolean>;

  /**
   * Gets the current API key value.
   * @returns The Google Maps API key string
   */
  get value(): string;

  /**
   * Sets the API key value.
   * Should be called before initializing the Google Maps API.
   * @param value - Google Maps API key
   */
  set value(value: string);

  /**
   * Initializes the Google Maps API by loading the script.
   * Only loads once, subsequent calls return the cached result.
   * Loads the Google Maps JavaScript API with configured libraries and region.
   *
   * @returns Observable that emits true when API is loaded successfully, false on error
   *
   * @example
   * ```typescript
   * this.googleMapService.initGoogleMap().subscribe(
   *   loaded => {
   *     if (loaded) {
   *       console.log('Google Maps API ready');
   *       this.initializeAutocomplete();
   *     } else {
   *       console.error('Failed to load Google Maps API');
   *     }
   *   }
   * );
   * ```
   */
  initGoogleMap(): Observable<boolean>;
}

/**
 * Service implementation class for Axis Google Maps functionality.
 * Injectable service that manages Google Maps API lifecycle.
 */
export interface AxisGoogleMapService extends IAxisGoogleMapService {
  /**
   * Constructor for the service.
   * @param httpClient - Angular HttpClient for making HTTP requests
   */
  new (httpClient: HttpClient): AxisGoogleMapService;
}

/**
 * Response structure from Google Maps Geocoding API.
 * Contains geocoding results for an address query.
 */
export interface GeocodingResponse {
  /**
   * Array of geocoding result objects.
   * Each result contains address components and location coordinates.
   */
  results: google.maps.GeocoderResult[];

  /**
   * Status of the geocoding request.
   * Values: 'OK', 'ZERO_RESULTS', 'OVER_QUERY_LIMIT', 'REQUEST_DENIED', 'INVALID_REQUEST', 'UNKNOWN_ERROR'
   */
  status: google.maps.GeocoderStatus;

  /**
   * Error message if status is not 'OK'.
   * Provides details about what went wrong with the request.
   */
  error_message?: string;
}

/**
 * Response structure from Google Maps Places Autocomplete API.
 * Contains predictions for address autocomplete suggestions.
 */
export interface AutocompleteResponse {
  /**
   * Array of autocomplete prediction objects.
   * Each prediction represents a suggested address matching the input.
   */
  predictions: google.maps.places.AutocompletePrediction[];

  /**
   * Status of the autocomplete request.
   * Values: 'OK', 'ZERO_RESULTS', 'INVALID_REQUEST', 'OVER_QUERY_LIMIT', 'REQUEST_DENIED', 'UNKNOWN_ERROR'
   */
  status: google.maps.places.PlacesServiceStatus;

  /**
   * Error message if status is not 'OK'.
   * Provides details about what went wrong with the request.
   */
  error_message?: string;
}

/**
 * Response structure from Google Maps Places Details API.
 * Contains detailed information about a specific place.
 */
export interface PlaceDetailsResponse {
  /**
   * Place details result object.
   * Contains comprehensive information about the requested place.
   */
  result: google.maps.places.PlaceResult;

  /**
   * Status of the place details request.
   * Values: 'OK', 'NOT_FOUND', 'INVALID_REQUEST', 'OVER_QUERY_LIMIT', 'REQUEST_DENIED', 'UNKNOWN_ERROR'
   */
  status: google.maps.places.PlacesServiceStatus;

  /**
   * HTML attributions for place data.
   * Required to be displayed when showing place information.
   */
  html_attributions: string[];

  /**
   * Error message if status is not 'OK'.
   * Provides details about what went wrong with the request.
   */
  error_message?: string;
}

/**
 * Options for Google Maps Places Autocomplete service.
 * Configures how autocomplete suggestions are generated.
 */
export interface AutocompleteOptions {
  /**
   * Bounds for biasing autocomplete results.
   * Results within these bounds are given higher priority.
   */
  bounds?: google.maps.LatLngBounds | google.maps.LatLngBoundsLiteral;

  /**
   * Whether to strictly restrict results to the specified bounds.
   * When true, only returns results within bounds.
   * When false, bounds are used for biasing only.
   * @default false
   */
  strictBounds?: boolean;

  /**
   * Types of places to return.
   * Can restrict to specific types like 'address', 'geocode', 'establishment', etc.
   * @example ['address'] // Only street addresses
   * @example ['geocode'] // All geocodable addresses
   */
  types?: string[];

  /**
   * Component restrictions for limiting results by country.
   * Object with country codes as values.
   * @example { country: 'us' } // Restrict to USA
   * @example { country: ['us', 'ca', 'mx'] } // Restrict to North America
   */
  componentRestrictions?: {
    country: string | string[];
  };

  /**
   * Fields to retrieve in the place result.
   * Limits API usage by requesting only needed data.
   * @example ['address_components', 'geometry', 'formatted_address']
   */
  fields?: string[];
}

/**
 * Request parameters for geocoding an address string.
 */
export interface GeocodeRequest {
  /**
   * Address string to geocode.
   * @example "1600 Amphitheatre Parkway, Mountain View, CA"
   */
  address: string;

  /**
   * Bounds for biasing geocoding results.
   * Results within these bounds are given higher priority.
   */
  bounds?: google.maps.LatLngBounds | google.maps.LatLngBoundsLiteral;

  /**
   * Component restrictions for filtering results.
   * Can restrict by country, postal code, route, or locality.
   * @example { country: 'US', postalCode: '94043' }
   */
  componentRestrictions?: google.maps.GeocoderComponentRestrictions;

  /**
   * Region code for biasing results.
   * Two-letter ISO country code.
   * @example "us"
   */
  region?: string;
}
