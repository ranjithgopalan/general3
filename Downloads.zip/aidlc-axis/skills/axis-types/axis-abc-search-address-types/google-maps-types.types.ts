/**
 * Extended type definitions for Google Maps API
 * Supplements the official @types/google.maps with additional utility types
 * @packageDocumentation
 */

/**
 * Simplified coordinate representation for easy data handling.
 * Alternative to google.maps.LatLng object for serialization and storage.
 */
export interface Coordinates {
  /**
   * Latitude coordinate in decimal degrees.
   * Valid range: -90 to 90
   * Positive values are north of the equator, negative are south.
   * @example 37.4224764 // Google headquarters latitude
   */
  lat: number;

  /**
   * Longitude coordinate in decimal degrees.
   * Valid range: -180 to 180
   * Positive values are east of the prime meridian, negative are west.
   * @example -122.0842499 // Google headquarters longitude
   */
  lng: number;
}

/**
 * Enhanced location data combining coordinates with address information.
 * Provides a complete representation of a geocoded location.
 */
export interface GeoLocation {
  /**
   * Latitude/longitude coordinates of the location.
   */
  coordinates: Coordinates;

  /**
   * Full formatted address string from Google Maps.
   * @example "1600 Amphitheatre Parkway, Mountain View, CA 94043, USA"
   */
  formattedAddress: string;

  /**
   * Google Place ID for this location.
   * Unique identifier that can be used to retrieve place details.
   * @example "ChIJ2eUgeAK6j4ARbn5u_wAGqWA"
   */
  placeId: string;

  /**
   * Types describing this location (e.g., street_address, political).
   * Array of type strings from Google Maps API.
   */
  types: string[];

  /**
   * Viewport bounds that should contain this location on a map.
   * Provides recommended bounds for displaying this location.
   */
  viewport?: {
    /** Northeast corner of the viewport */
    northeast: Coordinates;
    /** Southwest corner of the viewport */
    southwest: Coordinates;
  };
}

/**
 * Individual component of a structured address.
 * Represents a single element like street number, city, state, etc.
 */
export interface AddressComponent {
  /**
   * Full name of the address component.
   * @example "California" for a state
   * @example "Mountain View" for a city
   */
  longName: string;

  /**
   * Abbreviated name of the address component.
   * @example "CA" for California
   * @example "US" for United States
   */
  shortName: string;

  /**
   * Types that categorize this address component.
   * Multiple types can apply to a single component.
   * Common types: 'street_number', 'route', 'locality', 'administrative_area_level_1',
   * 'country', 'postal_code'
   * @example ["locality", "political"] for a city
   * @example ["administrative_area_level_1", "political"] for a state
   */
  types: string[];
}

/**
 * Complete structured address with all components parsed.
 * Breaks down a formatted address into individual parts.
 */
export interface ParsedAddress {
  /**
   * Street number (house/building number).
   * @example "1600"
   */
  streetNumber?: string;

  /**
   * Street name (route).
   * @example "Amphitheatre Parkway"
   */
  route?: string;

  /**
   * Full street address (combination of number and route).
   * @example "1600 Amphitheatre Parkway"
   */
  streetAddress?: string;

  /**
   * Neighborhood or sublocality.
   * @example "West Village"
   */
  neighborhood?: string;

  /**
   * City or locality.
   * @example "Mountain View"
   */
  locality?: string;

  /**
   * Sublocality level (for cities with subdivisions).
   * @example "Manhattan"
   */
  sublocality?: string;

  /**
   * Administrative area level 2 (typically county).
   * @example "Santa Clara County"
   */
  administrativeAreaLevel2?: string;

  /**
   * Administrative area level 1 (typically state/province).
   * @example "California"
   */
  administrativeAreaLevel1?: string;

  /**
   * Short form of administrative area level 1.
   * @example "CA"
   */
  administrativeAreaLevel1Short?: string;

  /**
   * Country name.
   * @example "United States"
   */
  country?: string;

  /**
   * ISO 3166-1 alpha-2 country code.
   * @example "US"
   */
  countryCode?: string;

  /**
   * Postal code (ZIP code in US).
   * @example "94043"
   */
  postalCode?: string;

  /**
   * Postal code suffix (ZIP+4 in US).
   * @example "1351"
   */
  postalCodeSuffix?: string;

  /**
   * Full postal code with suffix if available.
   * @example "94043-1351"
   */
  postalCodeFull?: string;

  /**
   * Premise (building name or complex).
   * @example "Building 43"
   */
  premise?: string;

  /**
   * Subpremise (apartment, suite, unit number).
   * @example "Suite 100"
   */
  subpremise?: string;

  /**
   * Full formatted address string.
   * @example "1600 Amphitheatre Parkway, Mountain View, CA 94043, USA"
   */
  formattedAddress?: string;
}

/**
 * Options for customizing address autocomplete behavior.
 */
export interface AutocompleteConfiguration {
  /**
   * Types of predictions to return.
   * 'address' - Street addresses
   * 'geocode' - All geocodable results
   * 'establishment' - Business results
   * '(regions)' - Administrative areas
   * '(cities)' - Cities only
   * @default ['geocode']
   */
  types?: string[];

  /**
   * Component restrictions to limit results by location.
   * @example { country: 'us' } - Restrict to USA
   * @example { country: ['us', 'ca', 'mx'] } - Restrict to North America
   */
  componentRestrictions?: {
    /** ISO 3166-1 alpha-2 country code(s) */
    country?: string | string[];
  };

  /**
   * Bounds to bias results (not strictly restrict).
   * Results within bounds get higher priority.
   */
  bounds?: {
    /** Northeast corner of bounding box */
    northeast: Coordinates;
    /** Southwest corner of bounding box */
    southwest: Coordinates;
  };

  /**
   * Whether to strictly restrict results to bounds.
   * If true, only returns results within bounds.
   * If false, bounds are used for biasing only.
   * @default false
   */
  strictBounds?: boolean;

  /**
   * Fields to include in place details.
   * Limits API usage by requesting only needed data.
   * @example ['address_components', 'formatted_address', 'geometry']
   */
  fields?: string[];

  /**
   * Session token for grouping autocomplete and details requests.
   * Used for billing optimization.
   */
  sessionToken?: google.maps.places.AutocompleteSessionToken;
}

/**
 * Result from an autocomplete prediction request.
 */
export interface AutocompletePrediction {
  /**
   * Human-readable description of the predicted place.
   * @example "1600 Amphitheatre Parkway, Mountain View, CA, USA"
   */
  description: string;

  /**
   * Google Place ID for retrieving full details.
   * @example "ChIJ2eUgeAK6j4ARbn5u_wAGqWA"
   */
  placeId: string;

  /**
   * Structured formatting of the prediction.
   */
  structuredFormatting: {
    /**
     * Main text of the prediction (usually the address).
     * @example "1600 Amphitheatre Parkway"
     */
    mainText: string;

    /**
     * Secondary text (usually city, state, country).
     * @example "Mountain View, CA, USA"
     */
    secondaryText: string;

    /**
     * Array of matched substrings for highlighting.
     * Indicates which parts of the text matched the query.
     */
    mainTextMatchedSubstrings?: Array<{
      /** Starting index of the match */
      offset: number;
      /** Length of the match */
      length: number;
    }>;
  };

  /**
   * Terms that make up the prediction.
   * Each term represents a part of the address.
   */
  terms: Array<{
    /** Offset in the description string */
    offset: number;
    /** The term text */
    value: string;
  }>;

  /**
   * Types describing the predicted place.
   * @example ["street_address", "geocode"]
   */
  types: string[];

  /**
   * Distance in meters from the specified origin.
   * Only present if an origin was specified in the request.
   */
  distanceMeters?: number;
}

/**
 * Request options for geocoding an address to coordinates.
 */
export interface GeocodeOptions {
  /**
   * Address string to geocode.
   * @example "1600 Amphitheatre Parkway, Mountain View, CA"
   */
  address?: string;

  /**
   * Place ID to geocode.
   * Alternative to address string.
   * @example "ChIJ2eUgeAK6j4ARbn5u_wAGqWA"
   */
  placeId?: string;

  /**
   * Bounds for biasing results.
   * Results within bounds are prioritized.
   */
  bounds?: {
    northeast: Coordinates;
    southwest: Coordinates;
  };

  /**
   * Component restrictions for filtering.
   * Can specify country, postal code, locality, route, or administrative area.
   * @example { country: 'US', postalCode: '94043' }
   */
  componentRestrictions?: {
    /** Route (street name) */
    route?: string;
    /** Locality (city) */
    locality?: string;
    /** Administrative area (state/province) */
    administrativeArea?: string;
    /** Postal code */
    postalCode?: string;
    /** Country code */
    country?: string;
  };

  /**
   * Region bias as a ccTLD (country code top-level domain).
   * @example "us" for United States
   */
  region?: string;

  /**
   * Coordinates to geocode (reverse geocoding).
   * Alternative to address string.
   */
  location?: Coordinates;
}

/**
 * Result from a geocoding request.
 */
export interface GeocodeResult {
  /**
   * Parsed address components.
   */
  addressComponents: AddressComponent[];

  /**
   * Full formatted address string.
   * @example "1600 Amphitheatre Parkway, Mountain View, CA 94043, USA"
   */
  formattedAddress: string;

  /**
   * Geometry information including location and bounds.
   */
  geometry: {
    /**
     * Precise location (latitude/longitude).
     */
    location: Coordinates;

    /**
     * Type of location precision.
     * @example "ROOFTOP" - Precise location
     * @example "RANGE_INTERPOLATED" - Interpolated between two precise points
     * @example "GEOMETRIC_CENTER" - Center point of a region
     * @example "APPROXIMATE" - Approximate location
     */
    locationType: string;

    /**
     * Recommended viewport for displaying this location.
     */
    viewport: {
      northeast: Coordinates;
      southwest: Coordinates;
    };

    /**
     * Bounding box that can fully contain the location.
     * May be different from viewport.
     */
    bounds?: {
      northeast: Coordinates;
      southwest: Coordinates;
    };
  };

  /**
   * Indicates geocoding precision wasn't exact.
   * True when geocoder had to approximate.
   * @default false
   */
  partialMatch?: boolean;

  /**
   * Google Place ID for this result.
   * @example "ChIJ2eUgeAK6j4ARbn5u_wAGqWA"
   */
  placeId: string;

  /**
   * Types describing this result.
   * @example ["street_address", "geocode"]
   */
  types: string[];

  /**
   * Plus code for the location (Open Location Code).
   */
  plusCode?: {
    /** Global 10-11 character Plus Code */
    globalCode: string;
    /** Shortened Plus Code with locality */
    compoundCode?: string;
  };
}

/**
 * Map marker configuration.
 * Simplified interface for creating map markers.
 */
export interface MarkerConfig {
  /**
   * Position of the marker on the map.
   */
  position: Coordinates;

  /**
   * Title text shown on hover.
   * @example "Selected Address"
   */
  title?: string;

  /**
   * Label text or configuration for the marker.
   * Can be a single character or full label config.
   */
  label?: string | {
    /** Text to display */
    text: string;
    /** Font size */
    fontSize?: string;
    /** Font weight */
    fontWeight?: string;
    /** Text color */
    color?: string;
  };

  /**
   * Whether the marker can be dragged.
   * @default false
   */
  draggable?: boolean;

  /**
   * Animation for the marker.
   * 'DROP' - Marker drops from top
   * 'BOUNCE' - Marker bounces
   * null - No animation
   */
  animation?: google.maps.Animation | null;

  /**
   * Custom icon for the marker.
   * Can be a URL string or full icon configuration.
   */
  icon?: string | google.maps.Icon | google.maps.Symbol;

  /**
   * Z-index for marker layering.
   * Higher values appear on top.
   */
  zIndex?: number;

  /**
   * Opacity of the marker (0.0 to 1.0).
   * @default 1.0
   */
  opacity?: number;

  /**
   * Whether the marker is visible.
   * @default true
   */
  visible?: boolean;
}

/**
 * Configuration for the embedded map display.
 */
export interface MapDisplayConfig {
  /**
   * Center coordinates for the map.
   */
  center: Coordinates;

  /**
   * Zoom level (1-20).
   * 1 = World view, 20 = Building level
   * @default 15
   */
  zoom: number;

  /**
   * Map type to display.
   * @default 'roadmap'
   */
  mapType?: 'roadmap' | 'satellite' | 'hybrid' | 'terrain';

  /**
   * Whether to show zoom controls.
   * @default true
   */
  zoomControl?: boolean;

  /**
   * Whether to show map type controls.
   * @default false
   */
  mapTypeControl?: boolean;

  /**
   * Whether to show scale control.
   * @default false
   */
  scaleControl?: boolean;

  /**
   * Whether to show street view controls.
   * @default false
   */
  streetViewControl?: boolean;

  /**
   * Whether to show rotate controls.
   * @default false
   */
  rotateControl?: boolean;

  /**
   * Whether to show fullscreen control.
   * @default false
   */
  fullscreenControl?: boolean;

  /**
   * Minimum zoom level allowed.
   * @default 0
   */
  minZoom?: number;

  /**
   * Maximum zoom level allowed.
   * @default 20
   */
  maxZoom?: number;

  /**
   * Whether gestures are enabled (pan, zoom, etc.).
   * @default true
   */
  gestureHandling?: 'cooperative' | 'greedy' | 'none' | 'auto';

  /**
   * Custom styles for the map.
   * Array of map style objects for customizing appearance.
   */
  styles?: google.maps.MapTypeStyle[];
}
