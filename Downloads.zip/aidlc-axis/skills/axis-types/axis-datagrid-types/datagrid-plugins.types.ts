/**
 * Plugin types and interfaces for Axis Datagrid plugins
 * @packageDocumentation
 */

import type { DatagridColumn, DatagridRow, DatagridModel } from './datagrid-common.types';
import type { ElementRef, OnInit, OnDestroy } from '@angular/core';
import type { AxisDatagridService } from './datagrid-service.types';

/**
 * Base plugin directive interface with common properties and methods
 */
export interface BasePluginDirective extends OnInit, OnDestroy {
  /**
   * Reference to the host element
   */
  el: ElementRef;

  /**
   * Grid service instance
   */
  gridService: AxisDatagridService;

  /**
   * Grid model configuration
   */
  model: DatagridModel;

  /**
   * Grid instance name
   */
  name: string;

  /**
   * Grid instance data
   */
  grid: Record<string, unknown>;

  /**
   * Initialize the plugin
   */
  ngOnInit(): void;

  /**
   * Start the plugin functionality
   */
  startDirective(): void;

  /**
   * Configure plugin settings
   */
  pluginConfig(): void;

  /**
   * Cleanup on destroy
   */
  ngOnDestroy(): void;
}

/**
 * Cell style plugin directive for applying custom styles to cells
 */
export interface AgpCellStyleDirective extends BasePluginDirective {
  /**
   * Cell style configuration
   */
  AgpCellStyleDirective: CellStyleConfig;
}

/**
 * Configuration for cell style plugin
 */
export interface CellStyleConfig {
  /**
   * Function that returns CSS class names based on cell data
   * @param value - Cell value
   * @param row - Row data object
   * @param column - Column definition
   * @returns CSS class name(s) to apply
   */
  className?: (value: unknown, row: DatagridRow, column: DatagridColumn) => string;

  /**
   * Function that returns inline styles based on cell data
   * @param value - Cell value
   * @param row - Row data object
   * @param column - Column definition
   * @returns Style object with CSS properties
   */
  style?: (value: unknown, row: DatagridRow, column: DatagridColumn) => Record<string, string>;

  /**
   * Predefined style rules based on conditions
   */
  rules?: CellStyleRule[];
}

/**
 * Cell style rule for conditional styling
 */
export interface CellStyleRule {
  /**
   * Condition function to evaluate if rule applies
   * @param value - Cell value
   * @param row - Row data object
   * @param column - Column definition
   * @returns true if rule should apply
   */
  condition: (value: unknown, row: DatagridRow, column: DatagridColumn) => boolean;

  /**
   * CSS class name(s) to apply when condition is true
   */
  className?: string;

  /**
   * Inline styles to apply when condition is true
   */
  style?: Record<string, string>;
}

/**
 * Condensed view plugin directive for compact row display
 */
export interface AgpCondensedDirective extends BasePluginDirective {
  /**
   * Condensed mode configuration
   */
  AgpCondensedDirective: CondensedConfig;
}

/**
 * Configuration for condensed view plugin
 */
export interface CondensedConfig {
  /**
   * Enable condensed mode
   * @default false
   */
  enabled?: boolean;

  /**
   * Reduced row height in condensed mode (in pixels)
   * @default 30
   */
  rowHeight?: number;

  /**
   * Reduced header height in condensed mode (in pixels)
   * @default 30
   */
  headerHeight?: number;

  /**
   * Reduced font size in condensed mode (in pixels)
   * @default 12
   */
  fontSize?: number;

  /**
   * Reduced cell padding in condensed mode (in pixels)
   * @default 4
   */
  cellPadding?: number;
}

/**
 * Drag column plugin directive for column reordering
 */
export interface AgpDragColumnDirective extends BasePluginDirective, OnDestroy {
  /**
   * Drag column configuration
   */
  AgpDragColumnDirective: DragColumnConfig;

  /**
   * CSS selector for draggable elements
   */
  dragElement: string;

  /**
   * CSS selector for drop target elements
   */
  dropElement: string;

  /**
   * Add subscriptions for drag events
   */
  addSubscriptions(): void;

  /**
   * Initialize drag column functionality
   */
  addDragColumn(): void;

  /**
   * Allow drop event handler
   * @param ev - Drag event
   */
  allowDrop(ev: DragEvent): void;

  /**
   * Drag leave event handler
   * @param ev - Drag event
   */
  dragLeave(ev: DragEvent): void;

  /**
   * Drag start event handler
   * @param ev - Drag event
   */
  dragStart(ev: DragEvent): void;

  /**
   * Drop event handler
   * @param ev - Drag event
   */
  drop(ev: DragEvent): void;

  /**
   * Handle drag and drop logic
   * @param dragColumnName - Name of dragged column
   * @param dropColumnName - Name of drop target column
   * @param name - Grid name
   */
  dragDrop(dragColumnName: string, dropColumnName: string, name: string): void;

  /**
   * Reorder columns after drag-drop
   */
  columnReOrder(): void;
}

/**
 * Configuration for drag column plugin
 */
export interface DragColumnConfig {
  /**
   * Enable column dragging
   * @default true
   */
  enabled?: boolean;

  /**
   * Columns that cannot be dragged
   */
  disabledColumns?: string[];

  /**
   * Show drop indicator
   * @default true
   */
  showDropIndicator?: boolean;

  /**
   * Callback when column order changes
   * @param columnOrder - New column order array
   */
  onOrderChange?: (columnOrder: string[]) => void;
}

/**
 * Filter plugin directive for data filtering
 */
export interface AgpFilterDirective extends BasePluginDirective, OnDestroy {
  /**
   * Filter configuration
   */
  AgpFilterDirective: FilterConfig;

  /**
   * Create regular expression from filter string
   * @param q - Filter query string
   * @returns RegExp or string
   */
  regExpFromString(q: string): RegExp | string;

  /**
   * Evaluate filter expressions against a value
   * @param expressionsList - Array of filter expressions [[operator, value], ...]
   * @param valueCompare - Value to compare against
   * @returns true if value matches filter criteria
   */
  evaluate(expressionsList: Array<[string, unknown]>, valueCompare: unknown): boolean;

  /**
   * Execute filter operation on grid data
   */
  runFilter(): void;

  /**
   * Get value from row data
   * @param row - Row data object
   * @param key - Column key
   * @param valueProperty - Property path for nested values
   * @param filter - Filter configuration
   * @returns Extracted value
   */
  getValue(row: DatagridRow, key: string, valueProperty: string, filter: FilterConfig): unknown;
}

/**
 * Configuration for filter plugin
 */
export interface FilterConfig {
  /**
   * Enable filtering
   * @default true
   */
  enable?: boolean;

  /**
   * Enable filtering (alternative property name)
   * @default true
   */
  enabled?: boolean;

  /**
   * Filter mode: client or server
   * @default 'client'
   */
  mode?: 'client' | 'server';

  /**
   * Active filter definitions per column (object format)
   */
  filters?: Record<string, ColumnFilterDefinition> | Array<FilterDefinition>;

  /**
   * Use OR logic for multiple filters instead of AND
   * @default false
   */
  orCondition?: boolean;

  /**
   * Debounce delay for filter input in milliseconds
   * @default 300
   */
  debounceTime?: number;

  /**
   * Show filter row in header
   * @default true
   */
  showFilterRow?: boolean;

  /**
   * Callback when filters change
   * @param filters - Current filter state
   */
  onFilterChange?: (filters: Record<string, ColumnFilterDefinition>) => void;
}

/**
 * Filter definition for array-based filter configuration
 */
export interface FilterDefinition {
  /**
   * Column field name to filter
   */
  field: string;

  /**
   * Filter type
   * - 'custom': Uses operators (>=, <=, >, <, ===) for date/number comparisons
   * - 'checkbox': Filters rows based on checkbox selection state
   */
  type?: 'custom' | 'checkbox';

  /**
   * Filter condition with operators (>=, <=, >, <, ===)
   * Can include multiple conditions separated by operators
   */
  condition?: string;

  /**
   * Filter value (can be array for range filters)
   */
  value?: unknown;

  /**
   * Property to filter on (default: 'content')
   * Can be 'content', 'value', 'pureContent', or a custom property path
   * @default 'content'
   */
  value_property?: string;
}

/**
 * Column filter definition
 */
export interface ColumnFilterDefinition {
  /**
   * Column name being filtered
   */
  column: string;

  /**
   * Filter operator(s): can be single operator or array of [operator, value] pairs
   */
  operator: string | Array<[string, unknown]>;

  /**
   * Filter value(s)
   */
  value: unknown;

  /**
   * Filter data type
   * - 'custom': Uses operators (>=, <=, >, <, ===) for date/number comparisons
   * - 'checkbox': Filters rows based on checkbox selection state
   * - Default (undefined): Uses regex pattern matching
   */
  type?: 'custom' | 'checkbox';

  /**
   * Case sensitive comparison
   * @default false
   */
  caseSensitive?: boolean;
}

/**
 * Fixed column plugin directive for pinning columns
 */
export interface AgpFixedDirective extends BasePluginDirective {
  /**
   * Fixed column configuration
   */
  AgpFixedDirective: FixedColumnConfig;
}

/**
 * Configuration for fixed column plugin
 */
export interface FixedColumnConfig {
  /**
   * Enable fixed columns
   * @default false
   */
  enabled?: boolean;

  /**
   * Columns fixed to the left
   */
  fixedLeft?: string[];

  /**
   * Columns fixed to the right
   */
  fixedRight?: string[];

  /**
   * Number of columns to fix on the left
   */
  fixedLeftCount?: number;

  /**
   * Number of columns to fix on the right
   */
  fixedRightCount?: number;
}

/**
 * In-cell edit plugin directive for inline editing
 */
export interface AgpInCellEditDirective extends BasePluginDirective {
  /**
   * In-cell edit configuration
   */
  AgpInCellEditDirective: InCellEditConfig;
}

/**
 * Configuration for in-cell edit plugin
 */
export interface InCellEditConfig {
  /**
   * Enable in-cell editing
   * @default false
   */
  enabled?: boolean;

  /**
   * Edit mode trigger: click, dblclick, or manual
   * @default 'dblclick'
   */
  trigger?: 'click' | 'dblclick' | 'manual';

  /**
   * Editable columns (if not specified, all columns are editable based on column config)
   */
  editableColumns?: string[];

  /**
   * Callback before edit starts
   * @param row - Row being edited
   * @param column - Column being edited
   * @returns false to cancel edit
   */
  onBeforeEdit?: (row: DatagridRow, column: DatagridColumn) => boolean;

  /**
   * Callback after edit completes
   * @param row - Row that was edited
   * @param column - Column that was edited
   * @param oldValue - Previous value
   * @param newValue - New value
   */
  onAfterEdit?: (row: DatagridRow, column: DatagridColumn, oldValue: unknown, newValue: unknown) => void;

  /**
   * Callback when edit is cancelled
   * @param row - Row being edited
   * @param column - Column being edited
   */
  onCancelEdit?: (row: DatagridRow, column: DatagridColumn) => void;

  /**
   * Custom validator function
   * @param value - New value to validate
   * @param row - Row being edited
   * @param column - Column being edited
   * @returns true if valid, false or error message if invalid
   */
  validator?: (value: unknown, row: DatagridRow, column: DatagridColumn) => boolean | string;
}

/**
 * Incremental scroll plugin directive for lazy loading during scroll
 */
export interface AgpIncrementalScrollDirective extends BasePluginDirective {
  /**
   * Incremental scroll configuration
   */
  AgpIncrementalScrollDirective: IncrementalScrollConfig;
}

/**
 * Configuration for incremental scroll plugin
 */
export interface IncrementalScrollConfig {
  /**
   * Enable incremental scrolling
   * @default false
   */
  enabled?: boolean;

  /**
   * Number of rows to load per batch
   * @default 50
   */
  batchSize?: number;

  /**
   * Scroll threshold (percentage) to trigger next load
   * @default 0.8 (80%)
   */
  threshold?: number;

  /**
   * Initial number of rows to load
   * @default 50
   */
  initialLoadSize?: number;

  /**
   * Callback to load more data
   * @param startIndex - Starting row index to load
   * @param count - Number of rows to load
   * @returns Promise resolving to loaded rows
   */
  loadMore?: (startIndex: number, count: number) => Promise<DatagridRow[]>;
}

/**
 * Keyboard navigation plugin directive
 */
export interface AgpKeyboardNavDirective extends BasePluginDirective {
  /**
   * Keyboard navigation configuration
   */
  AgpKeyboardNavDirective: KeyboardNavConfig;
}

/**
 * Configuration for keyboard navigation plugin
 */
export interface KeyboardNavConfig {
  /**
   * Enable keyboard navigation
   * @default false
   */
  enabled?: boolean;

  /**
   * Enable arrow key navigation
   * @default true
   */
  arrowKeys?: boolean;

  /**
   * Enable Tab key navigation
   * @default true
   */
  tabKey?: boolean;

  /**
   * Enable Enter key to start edit
   * @default true
   */
  enterToEdit?: boolean;

  /**
   * Enable Escape key to cancel edit
   * @default true
   */
  escapeToCancel?: boolean;

  /**
   * Enable Home/End keys to jump to first/last column
   * @default true
   */
  homeEndKeys?: boolean;

  /**
   * Enable Page Up/Page Down keys for pagination
   * @default true
   */
  pageKeys?: boolean;

  /**
   * Custom key binding handlers
   */
  customBindings?: Record<string, (event: KeyboardEvent) => void>;
}

/**
 * Mouse color/hover plugin directive for row hover effects
 */
export interface AgpMouseColorDirective extends BasePluginDirective {
  /**
   * Mouse color configuration
   */
  AgpMouseColorDirective: MouseColorConfig;
}

/**
 * Configuration for mouse color plugin
 */
export interface MouseColorConfig {
  /**
   * Enable hover effects
   * @default true
   */
  enabled?: boolean;

  /**
   * Hover background color
   */
  hoverColor?: string;

  /**
   * Active/selected row color
   */
  activeColor?: string;

  /**
   * Apply hover to entire row
   * @default true
   */
  hoverRow?: boolean;

  /**
   * Apply hover to individual cells
   * @default false
   */
  hoverCell?: boolean;
}

/**
 * Resize column plugin directive for column width adjustment
 */
export interface AgpResizeDirective extends BasePluginDirective {
  /**
   * Resize configuration
   */
  AgpResizeDirective: ResizeColumnConfig;
}

/**
 * Configuration for resize column plugin
 */
export interface ResizeColumnConfig {
  /**
   * Enable column resizing
   * @default true
   */
  enabled?: boolean;

  /**
   * Minimum column width in pixels
   * @default 50
   */
  minWidth?: number;

  /**
   * Maximum column width in pixels
   */
  maxWidth?: number;

  /**
   * Columns that cannot be resized
   */
  disabledColumns?: string[];

  /**
   * Show resize handle on hover
   * @default true
   */
  showHandle?: boolean;

  /**
   * Callback when column is resized
   * @param column - Column that was resized
   * @param newWidth - New width in pixels
   */
  onResize?: (column: DatagridColumn, newWidth: number) => void;
}

/**
 * Row style plugin directive for custom row styling
 */
export interface AgpRowStyleDirective extends BasePluginDirective {
  /**
   * Row style configuration
   */
  AgpRowStyleDirective: RowStyleConfig;
}

/**
 * Configuration for row style plugin
 */
export interface RowStyleConfig {
  /**
   * Function that returns CSS class names based on row data
   * @param row - Row data object
   * @param index - Row index
   * @returns CSS class name(s) to apply
   */
  className?: (row: DatagridRow, index: number) => string;

  /**
   * Function that returns inline styles based on row data
   * @param row - Row data object
   * @param index - Row index
   * @returns Style object with CSS properties
   */
  style?: (row: DatagridRow, index: number) => Record<string, string>;

  /**
   * Predefined style rules based on conditions
   */
  rules?: RowStyleRule[];
}

/**
 * Row style rule for conditional styling
 */
export interface RowStyleRule {
  /**
   * Condition function to evaluate if rule applies
   * @param row - Row data object
   * @param index - Row index
   * @returns true if rule should apply
   */
  condition: (row: DatagridRow, index: number) => boolean;

  /**
   * CSS class name(s) to apply when condition is true
   */
  className?: string;

  /**
   * Inline styles to apply when condition is true
   */
  style?: Record<string, string>;
}

/**
 * Sort plugin directive for data sorting
 */
export interface AgpSortDirective extends BasePluginDirective, OnDestroy {
  /**
   * Sort configuration
   */
  AgpSortDirective: SortConfig;

  /**
   * Whether sorting is disabled
   */
  sortDisabled: boolean;

  /**
   * Plugin configuration
   */
  config: Record<string, unknown>;

  /**
   * Prepare directive for initialization
   */
  prepareDirective(): void;

  /**
   * Add subscriptions for sort events
   */
  addSubscriptions(): void;

  /**
   * Add sort functionality to a column
   * @param columnName - Name of column to sort
   */
  addSort(columnName: string): void;

  /**
   * Handle concurrent/multi-column sort logic
   * @param alias - Column alias
   * @param element - HTML element
   * @param index - Sort index
   */
  concurrentSortLogic(alias: string, element: HTMLElement, index?: number): void;

  /**
   * Check if sort should be reset
   * @param resetObject - Reset configuration
   * @returns true if should reset
   */
  resetSortCondition(resetObject: Record<string, unknown>): boolean;

  /**
   * Update visual sort indicators
   */
  updateSortIndicator(): void;

  /**
   * Reset sort for an element
   * @param element - HTML element
   */
  resetSort(element: HTMLElement): void;

  /**
   * Remove all sort indicators
   */
  removeAllSortIndicator(): void;

  /**
   * Reset column headers
   * @param res - Reset data
   */
  resetColumnHeaders(res: unknown): void;

  /**
   * Reset other sort icons
   */
  resetOtherSortIcons(): void;

  /**
   * Change sort order
   * @param el - HTML element
   * @param orderBy - Sort direction
   */
  changeOrder(el: HTMLElement, orderBy?: string): void;

  /**
   * Execute sort on column
   * @param columnName - Column to sort
   */
  callSort(columnName: string): void;

  /**
   * Perform the sort operation
   */
  sort(): void;

  /**
   * Get column data type
   * @param columnName - Column name
   * @returns Column type
   */
  getColumnType(columnName: string): string;

  /**
   * Get comparison function for sorting
   * @returns Comparator function
   */
  compare(): (a: DatagridRow, b: DatagridRow) => number;
}

/**
 * Configuration for sort plugin
 */
export interface SortConfig {
  /**
   * Enable sorting (alternative property name)
   * @default true
   */
  load?: boolean;

  /**
   * Enable sorting
   * @default true
   */
  enabled?: boolean;

  /**
   * Sort mode: single or multiple column
   * @default 'single'
   */
  mode?: 'single' | 'multiple';

  /**
   * Sort type: client or server
   * @default 'client'
   */
  type?: 'client' | 'server';

  /**
   * Whether sorting is handled server-side
   * @default false
   */
  serverSort?: boolean;

  /**
   * Initial sort configuration
   */
  initialSort?: Array<{ column: string; direction: 'asc' | 'desc' }>;

  /**
   * Allow clearing sort
   * @default true
   */
  clearable?: boolean;

  /**
   * Columns that cannot be sorted
   */
  disabledColumns?: string[];

  /**
   * Column names that can be sorted
   */
  columnNames?: string[];

  /**
   * Map of column aliases to their data types
   */
  columns?: Record<string, string>;

  /**
   * Enable concurrent/multi-column sorting
   * @default false
   */
  concurrent?: boolean;

  /**
   * Sequence of columns for concurrent sorting
   */
  sortColumnsSequence?: string[];

  /**
   * Concurrent sort columns configuration
   */
  concurrentSortColumns?: Array<{ column: string; direction: 'asc' | 'desc' }>;

  /**
   * Callback when sort changes
   * @param sorts - Current sort state
   */
  onSortChange?: (sorts: Array<{ column: string; direction: 'asc' | 'desc' }>) => void;

  /**
   * Custom comparator functions per column
   */
  comparators?: Record<string, (a: unknown, b: unknown) => number>;
}

/**
 * Striped rows plugin directive
 */
export interface AgpStripedDirective extends BasePluginDirective {
  /**
   * Striped configuration
   */
  AgpStripedDirective: StripedConfig;
}

/**
 * Configuration for striped rows plugin
 */
export interface StripedConfig {
  /**
   * Enable striped rows
   * @default false
   */
  enabled?: boolean;

  /**
   * CSS class for odd rows
   * @default 'striped-odd'
   */
  oddRowClass?: string;

  /**
   * CSS class for even rows
   * @default 'striped-even'
   */
  evenRowClass?: string;

  /**
   * Background color for odd rows
   */
  oddRowColor?: string;

  /**
   * Background color for even rows
   */
  evenRowColor?: string;
}

/**
 * Tooltip plugin directive for cell tooltips
 */
export interface AgpTooltipDirective extends BasePluginDirective {
  /**
   * Tooltip configuration
   */
  AgpTooltipDirective: TooltipConfig;
}

/**
 * Configuration for tooltip plugin
 */
export interface TooltipConfig {
  /**
   * Enable tooltips
   * @default false
   */
  enabled?: boolean;

  /**
   * Show tooltip on hover
   * @default true
   */
  showOnHover?: boolean;

  /**
   * Delay before showing tooltip in milliseconds
   * @default 500
   */
  delay?: number;

  /**
   * Tooltip position relative to cell
   * @default 'top'
   */
  position?: 'top' | 'bottom' | 'left' | 'right' | 'auto';

  /**
   * Custom tooltip content function
   * @param value - Cell value
   * @param row - Row data
   * @param column - Column definition
   * @returns Tooltip content (HTML string or plain text)
   */
  content?: (value: unknown, row: DatagridRow, column: DatagridColumn) => string;

  /**
   * CSS class for tooltip element
   */
  tooltipClass?: string;
}

/**
 * Truncate plugin directive for text truncation
 */
export interface AgpTruncateDirective extends BasePluginDirective {
  /**
   * Truncate configuration
   */
  AgpTruncateDirective: TruncateConfig;
}

/**
 * Configuration for truncate plugin
 */
export interface TruncateConfig {
  /**
   * Enable text truncation
   * @default false
   */
  enabled?: boolean;

  /**
   * Maximum number of characters before truncation
   * @default 50
   */
  maxLength?: number;

  /**
   * Ellipsis text to append
   * @default '...'
   */
  ellipsis?: string;

  /**
   * Show full text on hover
   * @default true
   */
  showTooltip?: boolean;

  /**
   * Columns to apply truncation
   */
  columns?: string[];
}

/**
 * Virtual scroll plugin directive for efficient rendering of large datasets
 */
export interface AgpVirtualScrollDirective extends OnInit {
  /**
   * Reference to the host element
   */
  el: ElementRef;

  /**
   * Grid service instance
   */
  gridService: AxisDatagridService;

  /**
   * Grid model configuration
   */
  model: DatagridModel;

  /**
   * Whether the directive can start
   */
  canStart: boolean;

  /**
   * Grid instance name
   */
  name: string;

  /**
   * Grid instance data
   */
  grid: Record<string, unknown>;

  /**
   * Type of grid
   */
  typeOfGrid: string;

  /**
   * Plugin configuration
   */
  config: VirtualScrollConfig;

  /**
   * Reference to tbody element
   */
  bodyRef: HTMLElement;

  /**
   * Virtual scroll component instance
   */
  virtualComponent: unknown;

  /**
   * Initialize the directive
   */
  ngOnInit(): void;

  /**
   * Prepare directive for use
   */
  prepareDirective(): void;

  /**
   * Add event subscriptions
   */
  addSubscriptions(): void;

  /**
   * Create virtual scroll component
   */
  createVirtualComponent(): void;

  /**
   * Review and validate configuration
   * @param model - Grid model
   */
  reviewConfig(model: DatagridModel): void;

  /**
   * Start the directive
   */
  startDirective(): void;

  /**
   * Handle scroll event and fetch data
   * @param e - Scroll event
   */
  goGetData(e: Event): void;

  /**
   * Perform virtual scroll calculations and rendering
   * @param _name - Grid name
   * @param res - Response data
   */
  virtualScroll(_name?: string, res?: unknown): void;
}

/**
 * Configuration for virtual scroll plugin
 */
export interface VirtualScrollConfig {
  /**
   * Enable virtual scrolling
   * @default false
   */
  enabled?: boolean;

  /**
   * Row height in pixels (required for virtual scrolling)
   */
  rowHeight?: number;

  /**
   * Number of buffer rows to render above and below viewport
   * @default 5
   */
  bufferSize?: number;

  /**
   * Total number of rows in dataset
   */
  totalRows?: number;

  /**
   * Viewport height in pixels
   */
  viewportHeight?: number;

  /**
   * Scroll throttle time in milliseconds
   * @default 16
   */
  throttleTime?: number;
}

/**
 * Fixed column plugin directive (alternative implementation)
 */
export interface AgpFixedColumnDirective extends BasePluginDirective {
  /**
   * Fixed column configuration
   */
  AgpFixedColumnDirective: FixedColumnConfig;
}

/**
 * Sticky header plugin directive for fixed header during scroll
 */
export interface AgpStickyDirective extends BasePluginDirective {
  /**
   * Sticky configuration
   */
  AgpStickyDirective: StickyConfig;
}

/**
 * Configuration for sticky header plugin
 */
export interface StickyConfig {
  /**
   * Enable sticky header
   * @default false
   */
  enabled?: boolean;

  /**
   * Offset from top in pixels
   * @default 0
   */
  topOffset?: number;

  /**
   * Z-index for sticky header
   * @default 100
   */
  zIndex?: number;

  /**
   * Enable sticky for specific columns
   */
  stickyColumns?: string[];
}

/**
 * Max height plugin directive for limiting grid height
 */
export interface AgpMaxHeightDirective extends BasePluginDirective {
  /**
   * Max height configuration
   */
  AgpMaxHeightDirective: MaxHeightConfig;
}

/**
 * Configuration for max height plugin
 */
export interface MaxHeightConfig {
  /**
   * Maximum height in pixels or CSS value
   */
  maxHeight?: string | number;

  /**
   * Enable vertical scrolling when max height exceeded
   * @default true
   */
  enableScroll?: boolean;

  /**
   * Show scrollbar always or only on hover
   * @default 'auto'
   */
  scrollbarDisplay?: 'auto' | 'always' | 'hover';
}
