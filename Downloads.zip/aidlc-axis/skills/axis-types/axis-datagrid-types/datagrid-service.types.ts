/**
 * Service types and interfaces for Axis Datagrid service
 * @packageDocumentation
 */

import type { BehaviorSubject, Observable } from 'rxjs';
import type { DatagridRow, DatagridModel } from './datagrid-common.types';

/**
 * Axis Datagrid Service - Main service for managing grid instances
 */
export interface AxisDatagridService {
  /**
   * Collection of registered grid instances indexed by grid name
   */
  grids: Record<string, GridInstance>;

  /**
   * Default configuration applied to all grids
   */
  defaultConfig: DatagridDefaultConfig;

  /**
   * Observable indicating if content was clicked
   */
  isContentClicked: BehaviorSubject<ContentClickData>;

  /**
   * Registry of custom components available for rendering
   */
  customComponentsList: Record<string, unknown>;

  /**
   * Utility functions for common operations
   */
  utils: DatagridUtils;

  /**
   * Array of resize methods for handling column resizing
   */
  resizeMethods: Array<(name: string) => void>;

  /**
   * Register a new grid instance
   * @param name - Unique name for the grid
   */
  registerNewGrid(name: string): void;

  /**
   * Create action observables for a grid instance
   * @param name - Grid name
   */
  createActionsForGrid(name: string): void;

  /**
   * Get the configured row height for a grid
   * @param name - Grid name
   * @returns Row height in pixels
   */
  getRowHeight(name: string): number;

  /**
   * Add subscriptions for grid events
   * @param name - Grid name
   */
  addSubscriptions(name: string): void;

  /**
   * Handle content click event
   */
  isClicked(): void;

  /**
   * Add full data dump to grid instance
   * @param res - Data response containing rows
   */
  addFullDataDump(res: DataResponse): void;

  /**
   * Mark grid as ready after initialization
   * @param name - Grid name
   */
  gridReady(name: string): void;

  /**
   * Merge default configuration with grid-specific config
   * @param name - Grid name
   */
  mergeDefaultConfig(name: string): void;

  /**
   * Get the type of a value
   * @param c - Value to check type
   * @returns Type string
   */
  typeOf(c: unknown): string;

  /**
   * Update grid data with new rows
   * @param rows - Array of row data
   * @param name - Grid name
   * @param totalCount - Optional total count for pagination
   */
  update(rows: DatagridRow[], name: string, totalCount?: number): void;

  /**
   * Get all rows from a grid
   * @param name - Grid name
   * @returns Array of row data
   */
  getRows(name: string): DatagridRow[];

  /**
   * Handle column order changes
   * @param name - Grid name
   */
  columnOrder(name: string): void;

  /**
   * Get the current top visible row index
   * @param name - Grid name
   * @returns Top row index
   */
  currentTopRow(name: string): number;

  /**
   * Calculate grid dimensions and viewport
   * @param name - Grid name
   * @param preDefTop - Predefined top row index
   */
  calculate(name: string, preDefTop?: number): void;

  /**
   * Register a custom component for use in cells or headers
   * @param name - Component name
   * @param component - Component class or definition
   */
  registerCustomComponent(name: string, component: unknown): void;

  /**
   * Send update notification to grid subscribers
   * @param name - Grid name
   * @param data - Update data
   */
  sendUpdate(name: string, data: unknown): void;

  /**
   * Update the last changed timestamp for a grid
   * @param name - Grid name
   */
  changeLastChanged(name: string): void;

  /**
   * Send an action to a grid
   * @param name - Grid name
   * @param action - Action name
   * @param payload - Action payload data
   */
  sendAction(name: string, action: string, payload: unknown): void;

  /**
   * Get an action observable for a grid
   * @param name - Grid name
   * @param action - Action name
   * @returns Observable for the action
   */
  getAction(name: string, action: string): BehaviorSubject<unknown>;

  /**
   * Get full data dump from a grid (all rows, including filtered/hidden)
   * @param name - Grid name
   * @returns Array of all row data
   */
  fullDataDump(name: string): DatagridRow[];

  /**
   * Delete a row from the grid
   * @param rowsData - Row data or array of rows to delete
   * @param gridName - Grid name
   */
  deleteRow(rowsData: DatagridRow | DatagridRow[], gridName: string): void;

  /**
   * Update an existing row in the grid
   * @param rowData - Updated row data
   * @param gridName - Grid name
   */
  updateRow(rowData: DatagridRow, gridName: string): void;

  /**
   * Update a specific cell value in a row
   * @param payload - Update payload containing row, column, and new value
   * @param gridName - Grid name
   */
  updateRowCell(payload: CellUpdatePayload, gridName: string): void;

  /**
   * Add a new row to the grid
   * @param rowData - New row data
   * @param gridName - Grid name
   */
  addRow(rowData: DatagridRow, gridName: string): void;

  /**
   * Toggle visibility of a sub-column
   * @param name - Grid name
   * @param columnName - Sub-column name
   * @param parent - Parent column name
   */
  toggleSubColumn(name: string, columnName: string, parent: string): void;

  /**
   * Toggle visibility of one or more columns
   * @param name - Grid name
   * @param columnNames - Single column name or array of column names
   */
  toggleColumn(name: string, columnNames: string | string[]): void;

  /**
   * Export grid data to a file format
   * @param name - Grid name
   * @param type - Export format (csv, excel, pdf, json)
   * @param table - Table element or data
   */
  export(name: string, type: string, table: HTMLTableElement | unknown): void;

  /**
   * Destroy a grid instance and clean up resources
   * @param name - Grid name
   */
  destroyGrid(name: string): void;
}

/**
 * Grid instance data structure
 */
export interface GridInstance {
  /**
   * Grid name/identifier
   */
  name: string;

  /**
   * Grid configuration model
   */
  config: DatagridModel;

  /**
   * Current grid state
   */
  state: GridState;

  /**
   * Grid actions as observables
   */
  actions: Record<string, BehaviorSubject<unknown>>;

  /**
   * Observable for grid updates
   */
  update$: BehaviorSubject<GridUpdate>;

  /**
   * All rows (original, unfiltered data)
   */
  allRows: DatagridRow[];

  /**
   * Currently displayed rows (after filtering, sorting, pagination)
   */
  rows: DatagridRow[];

  /**
   * Filtered rows (before pagination)
   */
  filteredRows: DatagridRow[];

  /**
   * Total row count
   */
  totalCount: number;

  /**
   * Whether grid is ready/initialized
   */
  ready: boolean;

  /**
   * Last changed timestamp
   */
  lastChanged: number;

  /**
   * Grid element reference
   */
  element?: HTMLElement;

  /**
   * Viewport calculations
   */
  viewport?: ViewportData;

  /**
   * Subscription cleanup functions
   */
  subscriptions?: Array<() => void>;
}

/**
 * Grid state information
 */
export interface GridState {
  /**
   * Current page number (1-indexed)
   */
  currentPage: number;

  /**
   * Rows per page
   */
  pageSize: number;

  /**
   * Active sort configurations
   */
  sorts: Array<{ column: string; direction: 'asc' | 'desc'; priority?: number }>;

  /**
   * Active filter configurations
   */
  filters: Record<string, unknown>;

  /**
   * Selected row IDs
   */
  selectedRowIds: Array<string | number>;

  /**
   * Expanded row IDs (for expandable rows)
   */
  expandedRowIds: Array<string | number>;

  /**
   * Column order (array of column names)
   */
  columnOrder: string[];

  /**
   * Column widths
   */
  columnWidths: Record<string, number>;

  /**
   * Hidden column names
   */
  hiddenColumns: string[];

  /**
   * Loading state
   */
  loading: boolean;

  /**
   * Error message
   */
  error?: string;

  /**
   * Scroll position
   */
  scrollPosition: { top: number; left: number };
}

/**
 * Grid update notification data
 */
export interface GridUpdate {
  /**
   * Type of update
   */
  type: 'data' | 'config' | 'state' | 'action';

  /**
   * Update payload
   */
  payload: unknown;

  /**
   * Timestamp of update
   */
  timestamp: number;
}

/**
 * Viewport calculation data
 */
export interface ViewportData {
  /**
   * Height of viewport in pixels
   */
  height: number;

  /**
   * Width of viewport in pixels
   */
  width: number;

  /**
   * Index of first visible row
   */
  startIndex: number;

  /**
   * Index of last visible row
   */
  endIndex: number;

  /**
   * Number of visible rows
   */
  visibleRowCount: number;

  /**
   * Top row index
   */
  topRow: number;

  /**
   * Scroll top position
   */
  scrollTop: number;

  /**
   * Scroll left position
   */
  scrollLeft: number;
}

/**
 * Default configuration for all grids
 */
export interface DatagridDefaultConfig {
  /**
   * Default row height in pixels
   * @default 40
   */
  rowHeight?: number;

  /**
   * Default header height in pixels
   * @default 40
   */
  headerHeight?: number;

  /**
   * Default page size
   * @default 10
   */
  pageSize?: number;

  /**
   * Enable sorting by default
   * @default true
   */
  sortable?: boolean;

  /**
   * Enable filtering by default
   * @default true
   */
  filterable?: boolean;

  /**
   * Enable column resizing by default
   * @default true
   */
  resizable?: boolean;

  /**
   * Show borders by default
   * @default true
   */
  showBorders?: boolean;

  /**
   * Highlight row on hover by default
   * @default true
   */
  highlightRowOnHover?: boolean;

  /**
   * Empty message template
   */
  emptyMessage?: string;

  /**
   * Loading message template
   */
  loadingMessage?: string;

  /**
   * Error message template
   */
  errorMessage?: string;

  /**
   * Custom configuration properties
   */
  [key: string]: unknown;
}

/**
 * Utility functions provided by the service
 */
export interface DatagridUtils {
  /**
   * Check if an object has a nested property
   * @param obj - Object to check
   * @param props - Array of property names forming the path
   * @returns true if property exists
   */
  checkObjectProperty(obj: Record<string, unknown>, props: string[]): boolean;
}

/**
 * Content click event data
 */
export interface ContentClickData {
  /**
   * Grid name where click occurred
   */
  gridName: string;

  /**
   * Row that was clicked
   */
  row: DatagridRow;

  /**
   * Column name that was clicked
   */
  columnName: string;

  /**
   * Cell data
   */
  cell: unknown;

  /**
   * Mouse event
   */
  event: MouseEvent;

  /**
   * Timestamp of click
   */
  timestamp: number;
}

/**
 * Data response structure for loading grid data
 */
export interface DataResponse {
  /**
   * Array of row data
   */
  rows: DatagridRow[];

  /**
   * Total count of all available rows (for pagination)
   */
  totalCount?: number;

  /**
   * Current page number
   */
  currentPage?: number;

  /**
   * Page size
   */
  pageSize?: number;

  /**
   * Additional metadata
   */
  metadata?: Record<string, unknown>;
}

/**
 * Cell update payload for updating individual cells
 */
export interface CellUpdatePayload {
  /**
   * Row identifier
   */
  rowId: string | number;

  /**
   * Column name
   */
  columnName: string;

  /**
   * New cell value
   */
  value: unknown;

  /**
   * Optional: Previous value (for undo)
   */
  oldValue?: unknown;
}

/**
 * Export options for grid data export
 */
export interface ExportOptions {
  /**
   * Export format
   * Note: The grid service only explicitly handles 'pdf' format.
   * Other formats are passed to the EXPORT action subscriber.
   */
  format: 'csv' | 'excel' | 'pdf' | 'json';

  /**
   * File name (without extension)
   */
  fileName: string;

  /**
   * Which columns to include in export
   */
  columns?: string[];

  /**
   * Whether to include header row
   * @default true
   */
  includeHeaders?: boolean;

  /**
   * Which rows to export
   * @default 'all'
   */
  rowSelection?: 'all' | 'filtered' | 'selected' | 'current-page';

  /**
   * Custom formatting per column
   */
  columnFormatters?: Record<string, (value: unknown) => string>;

  /**
   * Additional export metadata
   */
  metadata?: Record<string, unknown>;
}

/**
 * Grid component interface
 */
export interface IAxisDatagridComponent {
  /**
   * Grid model configuration input
   */
  model: DatagridModel;

  /**
   * Output event emitter for grid events
   */
  output: Observable<GridOutputEvent>;

  /**
   * Reference to table element
   */
  thisTable: HTMLElement;

  /**
   * Reference to tbody element
   */
  tbody: HTMLElement;

  /**
   * Grid service instance
   */
  gridService: AxisDatagridService;

  /**
   * Grid name
   */
  name: string;

  /**
   * Grid instance data
   */
  grid: GridInstance;

  /**
   * Whether table is loading
   */
  tableLoading: boolean;

  /**
   * Initialize component
   */
  ngOnInit(): void;

  /**
   * After view initialization
   */
  ngAfterViewInit(): void;

  /**
   * Handle row click event
   * @param row - Row that was clicked
   */
  rowClicked(row: DatagridRow): void;

  /**
   * Handle cell click event
   * @param event - Mouse event
   * @param row - Row containing the cell
   * @param columnName - Column name
   * @param cell - Cell data
   */
  contentClicked(event: MouseEvent, row: DatagridRow, columnName: string, cell: unknown): void;

  /**
   * Handle header column click
   * @param column - Column that was clicked
   * @param subColumn - Optional sub-column
   */
  headerColumnClicked(column: unknown, subColumn?: unknown): void;

  /**
   * Handle row selection
   * @param event - Mouse event
   * @param row - Row to select
   * @param disabled - Whether row is disabled
   * @param hide - Whether selection checkbox is hidden
   * @param type - Selection type
   */
  selectRow(event: MouseEvent, row: DatagridRow, disabled: boolean, hide: boolean, type: string): void;

  /**
   * Export grid data
   * @param type - Export format
   */
  export(type: string): void;

  /**
   * Cleanup on destroy
   */
  ngOnDestroy(): void;
}

/**
 * Grid output event structure
 */
export interface GridOutputEvent {
  /**
   * Event type
   */
  type: 'rowClick' | 'cellClick' | 'selectionChange' | 'sortChange' | 'filterChange' | 'pageChange' | 'columnReorder' | 'columnResize' | 'cellEdit' | 'export' | 'init' | 'destroy';

  /**
   * Grid name
   */
  gridName: string;

  /**
   * Event data/payload
   */
  data: unknown;

  /**
   * Timestamp
   */
  timestamp: number;
}

/**
 * Grid module configuration interface
 */
export interface IAxisDatagridModule {
  /**
   * Module configuration
   */
  config?: DatagridModuleConfig;
}

/**
 * Module configuration options
 */
export interface DatagridModuleConfig {
  /**
   * Default grid configuration to apply
   */
  defaultConfig?: DatagridDefaultConfig;

  /**
   * Global plugin configurations
   */
  plugins?: Record<string, unknown>;

  /**
   * Custom component registry
   */
  customComponents?: Record<string, unknown>;

  /**
   * Locale/internationalization settings
   */
  locale?: DatagridLocale;
}

/**
 * Locale/internationalization settings
 */
export interface DatagridLocale {
  /**
   * Empty state message
   */
  emptyMessage?: string;

  /**
   * Loading message
   */
  loadingMessage?: string;

  /**
   * Error message
   */
  errorMessage?: string;

  /**
   * Pagination labels
   */
  pagination?: {
    /** First page button label */
    first?: string;
    /** Previous page button label */
    previous?: string;
    /** Next page button label */
    next?: string;
    /** Last page button label */
    last?: string;
    /** Rows per page label */
    rowsPerPage?: string;
    /** "of" label in "1-10 of 100" */
    of?: string;
  };

  /**
   * Sort labels
   */
  sort?: {
    /** Ascending sort label */
    ascending?: string;
    /** Descending sort label */
    descending?: string;
    /** Clear sort label */
    clear?: string;
  };

  /**
   * Filter labels
   */
  filter?: {
    /** Filter placeholder */
    placeholder?: string;
    /** Clear filter label */
    clear?: string;
    /** Apply filter label */
    apply?: string;
  };

  /**
   * Selection labels
   */
  selection?: {
    /** Select all label */
    selectAll?: string;
    /** Deselect all label */
    deselectAll?: string;
    /** Selected count label template (e.g., "{0} selected") */
    selectedCount?: string;
  };
}
