/**
 * Common types and interfaces for Axis Datagrid library
 * @packageDocumentation
 */

/**
 * Column definition for a datagrid column
 */
export interface DatagridColumn {
  /**
   * Unique identifier for the column
   */
  name: string;

  /**
   * Alias for the column (alternative to name)
   */
  alias?: string;

  /**
   * Display label shown in the column header
   */
  label?: string;

  /**
   * Property name in the data object to bind to this column
   */
  field?: string;

  /**
   * Maps to a property in the row data
   */
  mapTo?: string;

  /**
   * Column width in pixels or as a percentage string (e.g., "100px" or "20%")
   */
  width?: string | number;

  /**
   * Minimum width constraint in pixels
   */
  minWidth?: number;

  /**
   * Maximum width constraint in pixels
   */
  maxWidth?: number;

  /**
   * Column width configuration object
   */
  columnsWidth?: {
    /** Minimum width (e.g., "50px") */
    min?: string;
    /** Maximum width (e.g., "250px") */
    max?: string;
    /** Default width (e.g., "150px") */
    width?: string;
    /** Flex fraction for flexible width */
    fraction?: number;
  };

  /**
   * Column data type, used for sorting and filtering behavior
   * - 'text': String values (uppercased for comparison)
   * - 'number': Numeric values (default if not text/date/custom)
   * - 'date': Date values (converted to Date object if string)
   * - 'custom': Custom components (uses pureContent, treated like text for sorting)
   * - 'checkbox': Checkbox column
   * - 'radio': Radio button column
   */
  type?: 'text' | 'number' | 'date' | 'custom' | 'checkbox' | 'radio';

  /**
   * Whether the column is sortable
   * @default true
   */
  sortable?: boolean;

  /**
   * Whether the column is filterable
   * @default true
   */
  filterable?: boolean;

  /**
   * Whether the column is resizable by the user
   * @default true
   */
  resizable?: boolean;

  /**
   * Whether the column can be dragged to reorder
   * @default true
   */
  draggable?: boolean;

  /**
   * Whether the column is visible
   * @default true
   */
  visible?: boolean;

  /**
   * Whether the column is hidden (inverse of visible)
   * @default false
   */
  hide?: boolean;

  /**
   * Whether the column is hidden (alternative property name)
   * @default false
   */
  hidden?: boolean;

  /**
   * Whether to hide the column (alternative property name)
   * @default false
   */
  hideColumn?: boolean;

  /**
   * Whether the column is fixed/pinned to the left or right
   */
  fixed?: 'left' | 'right' | boolean;

  /**
   * Text alignment within the column cells
   * @default 'left'
   */
  align?: 'left' | 'center' | 'right';

  /**
   * CSS class name(s) to apply to column cells
   */
  className?: string;

  /**
   * CSS class name(s) to apply to column cells (alternative property name)
   */
  classes?: string | string[];

  /**
   * CSS class name(s) to apply to the column header
   */
  headerClassName?: string;

  /**
   * Custom cell template or component name for rendering cell content
   */
  cellTemplate?: string;

  /**
   * Custom header template or component name for rendering header content
   */
  headerTemplate?: string;

  /**
   * Format function or format string for displaying cell values
   */
  format?: string | ((value: unknown, row: DatagridRow) => string);

  /**
   * Filter configuration for this column
   */
  filter?: DatagridColumnFilter;

  /**
   * Sort configuration for this column
   */
  sort?: DatagridColumnSort;

  /**
   * Whether the column supports in-cell editing
   * @default false
   */
  editable?: boolean;

  /**
   * Editor type for in-cell editing
   * Note: Only these types are currently implemented in the in-cell-edit plugin
   */
  editor?: 'text' | 'number' | 'boolean' | 'date';

  /**
   * Options for editor configuration
   */
  editorOptions?: DatagridEditorOptions;

  /**
   * Child columns for grouped/nested column headers
   */
  columns?: DatagridColumn[];

  /**
   * Sub-columns for nested column headers (alternative property name)
   */
  subColumns?: DatagridColumn[];

  /**
   * Parent column name if this is a sub-column
   */
  parent?: string;

  /**
   * Whether to truncate long text with ellipsis
   * @default false
   */
  truncate?: boolean;

  /**
   * Tooltip content or function to generate tooltip
   */
  tooltip?: string | ((value: unknown, row: DatagridRow) => string);

  /**
   * Custom data properties for the column
   */
  data?: Record<string, unknown>;

  /**
   * Property path to access nested values in the data object (e.g., "user.name")
   */
  valueProperty?: string;

  /**
   * Sticky column behavior for horizontal scrolling
   */
  sticky?: boolean;

  /**
   * Custom comparison function for sorting
   */
  compareFn?: (a: unknown, b: unknown) => number;
}

/**
 * Filter configuration for a column
 */
export interface DatagridColumnFilter {
  /**
   * Filter type/mode
   * - 'custom': Uses operators (>=, <=, >, <, ===) for date/number comparisons
   * - 'checkbox': Filters rows based on checkbox selection state
   * - Default (undefined): Uses regex pattern matching
   */
  type?: 'custom' | 'checkbox';

  /**
   * Filter operator for comparisons (only used with type='custom')
   * Operators: '>=', '<=', '>', '<', '==='
   */
  operator?: string;

  /**
   * Current filter value(s)
   */
  value?: unknown;

  /**
   * Available options for select/multi-select filters
   */
  options?: Array<{ label: string; value: unknown }>;

  /**
   * Placeholder text for filter input
   */
  placeholder?: string;

  /**
   * Whether the filter is case-sensitive
   * @default false
   */
  caseSensitive?: boolean;

  /**
   * Custom filter function
   */
  filterFn?: (value: unknown, filterValue: unknown, row: DatagridRow) => boolean;
}

/**
 * Sort configuration for a column
 */
export interface DatagridColumnSort {
  /**
   * Current sort direction
   */
  direction?: 'asc' | 'desc' | null;

  /**
   * Sort priority for multi-column sorting (lower number = higher priority)
   */
  priority?: number;

  /**
   * Whether to allow clearing the sort
   * @default true
   */
  clearable?: boolean;
}

/**
 * Editor options for in-cell editing
 * Note: Options are limited to what's actually implemented in the in-cell-edit plugin
 */
export interface DatagridEditorOptions {
  /**
   * Minimum value for number editor
   */
  min?: number;

  /**
   * Maximum value for number editor
   */
  max?: number;

  /**
   * Step increment for number editor
   */
  step?: number;

  /**
   * Date format for date editor
   */
  dateFormat?: string;

  /**
   * Additional properties passed to the editor
   */
  props?: Record<string, unknown>;
}

/**
 * Row data object containing cell values and metadata
 */
export interface DatagridRow {
  /**
   * Unique identifier for the row
   */
  id?: string | number;

  /**
   * Row index in the grid
   */
  rowIndex?: number;

  /**
   * Whether the row is selected
   */
  selected?: boolean;

  /**
   * Whether the row is expanded (for expandable rows)
   */
  expanded?: boolean;

  /**
   * Whether the row is disabled/non-interactive
   */
  disabled?: boolean;

  /**
   * CSS class name(s) to apply to the row
   */
  className?: string;

  /**
   * CSS class name(s) to apply to the row (alternative property name)
   */
  rowClass?: string | string[];

  /**
   * CSS class name(s) to apply to the row (alternative property name)
   */
  class?: string | string[];

  /**
   * Custom style object for the row
   */
  style?: Record<string, string>;

  /**
   * Child rows for tree/hierarchical data
   */
  children?: DatagridRow[];

  /**
   * Nesting level for hierarchical data (0 = top level)
   */
  level?: number;

  /**
   * Parent row ID for hierarchical data
   */
  parentId?: string | number;

  /**
   * Whether this row has children
   */
  hasChildren?: boolean;

  /**
   * Whether to show nested grid for this row
   */
  showNestedGrid?: boolean;

  /**
   * Nested grid component reference for expandable nested grids
   */
  nestedGridComponent?: unknown;

  /**
   * Row-specific configuration
   */
  config?: Record<string, unknown>;

  /**
   * Array of cell data for this row
   */
  cells?: DatagridCell[];

  /**
   * Custom data properties - can contain any column values
   */
  [key: string]: unknown;
}

/**
 * Cell data object for individual cells in a row
 */
export interface DatagridCell {
  /**
   * Display content for the cell
   */
  content?: unknown;

  /**
   * Raw/pure content (used for custom components)
   */
  pureContent?: unknown;

  /**
   * Cell value (used for sorting/filtering)
   */
  value?: unknown;

  /**
   * Maps to header column alias
   */
  mapTo?: string;

  /**
   * Cell type
   */
  type?: string;

  /**
   * CSS classes for the cell
   */
  classes?: string | string[];

  /**
   * Whether the cell is disabled
   */
  disabled?: boolean;

  /**
   * Whether to hide the cell
   */
  hide?: boolean;

  /**
   * Sub-column cells for nested column headers
   */
  subColumns?: DatagridCell[];

  /**
   * Number of columns this cell spans
   */
  colspan?: number;

  /**
   * Number of rows this cell spans
   */
  rowspan?: number;

  /**
   * Tooltip content for the cell
   */
  tooltip?: unknown;

  /**
   * Custom data properties
   */
  [key: string]: unknown;
}

/**
 * Data source configuration for the datagrid
 */
export interface DatagridDataSource<TRow = DatagridRow> {
  /**
   * Array of row data objects
   */
  data: TRow[];

  /**
   * Total count of all available rows (for server-side pagination)
   */
  totalCount?: number;

  /**
   * Current page number (1-indexed)
   */
  currentPage?: number;

  /**
   * Number of rows per page
   */
  pageSize?: number;

  /**
   * Whether the data is currently loading
   */
  loading?: boolean;

  /**
   * Error message if data loading failed
   */
  error?: string;
}

/**
 * Pagination configuration
 */
export interface DatagridPagination {
  /**
   * Enable pagination
   * @default false
   */
  enabled?: boolean;

  /**
   * Current page number (1-indexed)
   * @default 1
   */
  currentPage?: number;

  /**
   * Number of rows per page
   * @default 10
   */
  pageSize?: number;

  /**
   * Available page size options
   */
  pageSizeOptions?: number[];

  /**
   * Total number of rows across all pages
   */
  totalCount?: number;

  /**
   * Pagination mode: client (all data loaded) or server (lazy loading)
   * @default 'client'
   */
  mode?: 'client' | 'server';

  /**
   * Show page size selector
   * @default true
   */
  showPageSizeSelector?: boolean;

  /**
   * Show total row count
   * @default true
   */
  showTotalCount?: boolean;

  /**
   * Position of pagination controls
   * @default 'bottom'
   */
  position?: 'top' | 'bottom' | 'both';
}

/**
 * Sorting configuration
 */
export interface DatagridSorting {
  /**
   * Enable sorting
   * @default true
   */
  enabled?: boolean;

  /**
   * Sorting mode: single column or multiple columns
   * @default 'single'
   */
  mode?: 'single' | 'multiple';

  /**
   * Active sort configurations per column
   */
  sortBy?: Array<{
    /** Column name to sort by */
    column: string;
    /** Sort direction */
    direction: 'asc' | 'desc';
    /** Priority for multi-column sort (lower = higher priority) */
    priority?: number;
  }>;

  /**
   * Sorting type: client (in-memory) or server (API-based)
   * @default 'client'
   */
  type?: 'client' | 'server';

  /**
   * Whether to allow clearing sort by clicking again
   * @default true
   */
  clearable?: boolean;

  /**
   * Custom sort comparator function
   */
  compareFn?: (a: DatagridRow, b: DatagridRow, column: string) => number;
}

/**
 * Filtering configuration
 */
export interface DatagridFiltering {
  /**
   * Enable filtering
   * @default true
   */
  enabled?: boolean;

  /**
   * Filtering type: client (in-memory) or server (API-based)
   * @default 'client'
   */
  type?: 'client' | 'server';

  /**
   * Active filter configurations per column
   */
  filterBy?: Array<{
    /** Column name to filter */
    column: string;
    /** Filter operator */
    operator: string;
    /** Filter value(s) */
    value: unknown;
  }>;

  /**
   * Filter mode: toolbar (show filter inputs) or menu (dropdown menus)
   * @default 'toolbar'
   */
  mode?: 'toolbar' | 'menu' | 'inline';

  /**
   * Debounce time in milliseconds for filter input
   * @default 300
   */
  debounceTime?: number;
}

/**
 * Selection configuration
 */
export interface DatagridSelection {
  /**
   * Enable row selection
   * @default false
   */
  enabled?: boolean;

  /**
   * Selection mode: single row or multiple rows
   * @default 'multiple'
   */
  mode?: 'single' | 'multiple';

  /**
   * Show checkbox column for selection
   * @default true
   */
  showCheckbox?: boolean;

  /**
   * Show select all checkbox in header
   * @default true
   */
  showSelectAll?: boolean;

  /**
   * Currently selected row IDs
   */
  selectedRowIds?: Array<string | number>;

  /**
   * Whether to preserve selection across page changes
   * @default false
   */
  preserveSelectionOnPageChange?: boolean;

  /**
   * Function to determine if a row is selectable
   */
  isRowSelectable?: (row: DatagridRow) => boolean;
}

/**
 * Virtual scrolling configuration for handling large datasets
 */
export interface DatagridVirtualScroll {
  /**
   * Enable virtual scrolling
   * @default false
   */
  enabled?: boolean;

  /**
   * Row height in pixels (required for virtual scrolling)
   */
  rowHeight?: number;

  /**
   * Number of buffer rows to render above and below visible area
   * @default 5
   */
  bufferSize?: number;

  /**
   * Total number of rows in the dataset
   */
  totalRows?: number;

  /**
   * Threshold for triggering data load (e.g., scroll position)
   */
  loadThreshold?: number;
}

/**
 * Full datagrid model structure with config, header, and body sections
 * This is the complete model structure used by axis-datagrid
 */
export interface DatagridFullModel {
  /**
   * Configuration section
   */
  config: DatagridConfig;

  /**
   * Header section with column definitions
   */
  header: DatagridHeader;

  /**
   * Body section with row data
   */
  body: DatagridBody;

  /**
   * Whether the grid is ready to be displayed
   */
  readyToShow?: boolean;

  /**
   * Last changed timestamp
   */
  lastChanged?: number;
}

/**
 * Grid header structure with rows and cells
 */
export interface DatagridHeader {
  /**
   * Header-level configuration
   */
  config?: Record<string, unknown>;

  /**
   * Header rows (typically one row with column headers)
   */
  rows: DatagridHeaderRow[];
}

/**
 * Header row containing header cells
 */
export interface DatagridHeaderRow {
  /**
   * Row-level configuration
   */
  config?: Record<string, unknown>;

  /**
   * Row index
   */
  rowIndex?: number;

  /**
   * Array of header cells (column definitions)
   */
  cells: DatagridHeaderCell[];
}

/**
 * Header cell (column definition)
 */
export interface DatagridHeaderCell {
  /**
   * Column content/label
   */
  content?: string | unknown;

  /**
   * Column alias (unique identifier)
   */
  alias?: string;

  /**
   * Column name
   */
  name?: string;

  /**
   * Column type
   */
  type?: string;

  /**
   * Column width configuration
   */
  columnsWidth?: {
    /** Minimum width (e.g., "50px") */
    min?: string;
    /** Maximum width (e.g., "250px") */
    max?: string;
    /** Default width (e.g., "150px") */
    width?: string;
    /** Flex fraction for flexible width */
    fraction?: number;
    /** Real/computed width (e.g., "150px") */
    realWidth?: string;
  };

  /**
   * Whether the column is hidden
   */
  hidden?: boolean;

  /**
   * Whether to hide the column
   */
  hideColumn?: boolean;

  /**
   * Maps to a property in the data
   */
  mapTo?: string;

  /**
   * CSS classes for the column
   */
  classes?: string | string[];

  /**
   * Sub-columns for nested/grouped headers
   */
  subColumns?: DatagridHeaderCell[];

  /**
   * Custom properties
   */
  [key: string]: unknown;
}

/**
 * Grid body structure with rows
 */
export interface DatagridBody {
  /**
   * Body-level configuration
   */
  config?: {
    /** Total count of rows */
    totalCount?: number;
    /** Additional configuration */
    [key: string]: unknown;
  };

  /**
   * Array of data rows
   */
  rows: DatagridBodyRow[];
}

/**
 * Body row containing cell data
 */
export interface DatagridBodyRow {
  /**
   * Row-level configuration
   */
  config?: Record<string, unknown>;

  /**
   * Row index
   */
  rowIndex?: number;

  /**
   * Array of cells in this row
   */
  cells: DatagridBodyCell[];

  /**
   * Child rows for nested/hierarchical data
   */
  children?: DatagridBodyRow[];

  /**
   * Whether the row is selected
   */
  selected?: boolean;

  /**
   * Whether to show nested grid for this row
   */
  showNestedGrid?: boolean;

  /**
   * Nested grid component reference
   */
  nestedGridComponent?: unknown;

  /**
   * Row CSS classes
   */
  rowClass?: string | string[];

  /**
   * Row CSS classes (alternative)
   */
  class?: string | string[];

  /**
   * Custom properties
   */
  [key: string]: unknown;
}

/**
 * Body cell data
 */
export interface DatagridBodyCell {
  /**
   * Cell display content
   */
  content?: unknown;

  /**
   * Raw/pure content (used for custom components)
   */
  pureContent?: unknown;

  /**
   * Cell value (used for sorting/filtering)
   */
  value?: unknown;

  /**
   * Maps to header column alias
   */
  mapTo?: string;

  /**
   * Cell type
   */
  type?: string;

  /**
   * CSS classes for the cell
   */
  classes?: string | string[];

  /**
   * Whether the cell is disabled
   */
  disabled?: boolean;

  /**
   * Whether the cell is checked (for checkboxes)
   */
  checked?: boolean;

  /**
   * Whether the cell is editable
   */
  editable?: boolean;

  /**
   * Whether to hide the cell
   */
  hide?: boolean;

  /**
   * Data heading attribute
   */
  'data-heading'?: string;

  /**
   * Sub-column cells for nested column headers
   */
  subColumns?: DatagridBodyCell[];

  /**
   * Number of columns this cell spans
   */
  colspan?: number;

  /**
   * Number of rows this cell spans
   */
  rowspan?: number;

  /**
   * Tooltip content for the cell
   */
  tooltip?: unknown;

  /**
   * Custom properties
   */
  [key: string]: unknown;
}

/**
 * Main datagrid configuration (config section of the full model)
 */
export interface DatagridConfig {
  /**
   * Unique name identifier for this grid instance
   */
  name: string;

  /**
   * ARIA label for accessibility
   */
  ariaLabel?: string;

  /**
   * Grid type
   */
  'grid-type'?: string;

  /**
   * Row height in pixels
   * @default 65
   */
  rowHeight?: number;

  /**
   * Grid height (in pixels, percentage, or 'auto')
   * @default '300px'
   */
  gridHeight?: string;

  /**
   * Scroll type for the grid
   * @default 'normal'
   */
  scrollType?: 'normal' | 'incremental' | 'virtual';

  /**
   * Number of cells to display in viewport for virtual scrolling
   * @default 10
   */
  viewportCellCount?: number;

  /**
   * Number of buffer rows to render outside viewport
   * @default 5
   */
  bufferRows?: number;

  /**
   * Whether to use API calls on scroll events
   * @default false
   */
  useApiOnScroll?: boolean;

  /**
   * Enable row selection
   * @default true
   */
  selectableRow?: boolean;

  /**
   * Enable dynamic height adjustment based on content
   * @default true
   */
  enableDynamicHeight?: boolean;

  /**
   * Minimum number of visible rows
   * @default 5
   */
  minVisibleRowsLength?: number;

  /**
   * Column order configuration (array of column mappings)
   */
  columnsOrder?: Array<{ from: string; to: string }>;

  /**
   * Total number of columns in the grid
   */
  columnsCount?: number;

  /**
   * CSS grid classes to apply
   */
  cssGridClass?: string[];

  /**
   * Columns that support sort reset functionality
   */
  resetSort?: string[];

  /**
   * Enable cell editing
   * @default false
   */
  cellEdit?: boolean;

  /**
   * Loading state indicator or custom loading component
   */
  loading?: boolean | unknown;

  /**
   * Custom no results UI component or template
   */
  noResultsUi?: unknown;

  /**
   * Table caption
   */
  caption?: string | unknown;

  /**
   * Download/export button configurations
   */
  download?: Array<{
    /** Button name/label */
    name: string;
    /** Export type/format */
    kind: string;
    /** CSS classes for the button */
    classes?: string | string[];
  }>;

  /**
   * CSS classes for the export buttons container
   */
  exportClasses?: string | string[];

  /**
   * Nested grid configuration for expandable nested grids
   */
  nestedGridOptions?: DatagridNestedGridOptions;

  /**
   * Enable keyboard navigation plugin
   */
  agpKeyboardNav?: boolean;

  /**
   * Enable drag column plugin
   */
  agpDragColumn?: boolean;

  /**
   * Enable cell style plugin
   */
  agpCellStyle?: boolean;

  /**
   * Enable condensed mode plugin
   */
  agpCondensed?: boolean;

  /**
   * Enable striped rows plugin
   */
  agpStriped?: boolean;

  /**
   * Enable tooltip plugin
   */
  agpTooltip?: boolean;

  /**
   * Truncate settings - columns to exclude from truncation
   */
  agpTruncateExcludeColumns?: string[];

  /**
   * Truncate settings - columns that support multiline truncation
   */
  agpTruncateMultiline?: string[];

  /**
   * Max height plugin configuration
   */
  agpMaxHeight?: unknown;

  /**
   * Fixed column plugin configuration
   */
  agpFixed?: unknown;

  /**
   * Fixed column plugin configuration (alternative)
   */
  agpFixedColumn?: unknown;

  /**
   * Sticky header plugin configuration
   */
  agpSticky?: unknown;

  /**
   * Resize column plugin configuration
   */
  agpResize?: unknown;

  /**
   * In-cell edit plugin configuration
   */
  agpInCellEdit?: unknown;

  /**
   * Incremental scroll plugin configuration
   */
  agpIncrementalScroll?: unknown;

  /**
   * Virtual scroll plugin configuration
   */
  agpVirtualScroll?: unknown;

  /**
   * Mouse color/hover plugin configuration
   */
  agpMouseColor?: unknown;

  /**
   * Row style plugin configuration
   */
  axisGridPluginRowStyle?: unknown;

  /**
   * Sort plugin configuration
   */
  agpSort?: unknown;

  /**
   * Filter plugin configuration
   */
  agpFilter?: unknown;

  /**
   * Custom configuration properties
   */
  [key: string]: unknown;
}

/**
 * Main datagrid configuration model (legacy/simplified interface)
 * @deprecated Use DatagridFullModel for the complete structure
 */
export interface DatagridModel<TRow = DatagridRow> {
  /**
   * Unique name identifier for this grid instance
   */
  name: string;

  /**
   * Column definitions
   */
  columns: DatagridColumn[];

  /**
   * Row data or data source configuration
   */
  data?: TRow[] | DatagridDataSource<TRow>;

  /**
   * Grid height (in pixels, percentage, or 'auto')
   * @default '300px'
   */
  height?: string | number;

  /**
   * Grid width (in pixels, percentage, or 'auto')
   */
  width?: string | number;

  /**
   * Maximum height constraint
   */
  maxHeight?: string | number;

  /**
   * Row height in pixels
   * @default 65
   */
  rowHeight?: number;

  /**
   * Header row height in pixels
   * @default 40
   */
  headerHeight?: number;

  /**
   * Pagination configuration
   */
  pagination?: DatagridPagination;

  /**
   * Sorting configuration
   */
  sorting?: DatagridSorting;

  /**
   * Filtering configuration
   */
  filtering?: DatagridFiltering;

  /**
   * Selection configuration
   */
  selection?: DatagridSelection;

  /**
   * Virtual scrolling configuration
   */
  virtualScroll?: DatagridVirtualScroll;

  /**
   * Scroll type for the grid
   * @default 'normal'
   */
  scrollType?: 'normal' | 'incremental' | 'virtual';

  /**
   * Number of cells to display in viewport for virtual scrolling
   * @default 10
   */
  viewportCellCount?: number;

  /**
   * Number of buffer rows to render outside viewport
   * @default 5
   */
  bufferRows?: number;

  /**
   * Whether to use API calls on scroll events
   * @default false
   */
  useApiOnScroll?: boolean;

  /**
   * Enable row selection
   * @default true
   */
  selectableRow?: boolean;

  /**
   * Enable dynamic height adjustment based on content
   * @default true
   */
  enableDynamicHeight?: boolean;

  /**
   * Minimum number of visible rows
   * @default 5
   */
  minVisibleRowsLength?: number;

  /**
   * Column order configuration (array of column mappings)
   */
  columnsOrder?: Array<{ from: string; to: string }>;

  /**
   * Total number of columns in the grid
   */
  columnsCount?: number;

  /**
   * CSS grid classes to apply
   */
  cssGridClass?: string[];

  /**
   * Columns that support sort reset functionality
   */
  resetSort?: string[];

  /**
   * Enable cell editing
   * @default false
   */
  cellEdit?: boolean;

  /**
   * Show grid borders
   * @default true
   */
  showBorders?: boolean;

  /**
   * Show horizontal grid lines
   * @default true
   */
  showHorizontalLines?: boolean;

  /**
   * Show vertical grid lines
   * @default true
   */
  showVerticalLines?: boolean;

  /**
   * Apply striped row styling (alternating row colors)
   * @default false
   */
  striped?: boolean;

  /**
   * Highlight row on hover
   * @default true
   */
  highlightRowOnHover?: boolean;

  /**
   * CSS class name(s) to apply to the grid container
   */
  className?: string;

  /**
   * Custom CSS styles for the grid
   */
  style?: Record<string, string>;

  /**
   * Enable responsive layout adjustments
   * @default false
   */
  responsive?: boolean;

  /**
   * Loading state indicator or custom loading component
   */
  loading?: boolean | unknown;

  /**
   * Loading message or template
   */
  loadingMessage?: string;

  /**
   * Empty state message when no data available
   */
  emptyMessage?: string;

  /**
   * Custom no results UI component or template
   */
  noResultsUi?: unknown;

  /**
   * Table caption
   */
  caption?: string | unknown;

  /**
   * Error message to display
   */
  errorMessage?: string;

  /**
   * Enable keyboard navigation
   * @default false
   */
  keyboardNavigation?: boolean;

  /**
   * Enable row expansion for detail views
   * @default false
   */
  expandableRows?: boolean;

  /**
   * Template or component for expanded row content
   */
  rowDetailTemplate?: string;

  /**
   * Enable tree/hierarchical data mode
   * @default false
   */
  treeMode?: boolean;

  /**
   * Property name that contains child rows in tree mode
   */
  childrenProperty?: string;

  /**
   * Export configuration
   */
  export?: DatagridExport;

  /**
   * Download/export button configurations
   */
  download?: Array<{
    /** Button name/label */
    name: string;
    /** Export type/format */
    kind: string;
    /** CSS classes for the button */
    classes?: string | string[];
  }>;

  /**
   * CSS classes for the export buttons container
   */
  exportClasses?: string | string[];

  /**
   * Nested grid configuration for expandable nested grids
   */
  nestedGridOptions?: DatagridNestedGridOptions;

  /**
   * Plugin configurations
   */
  plugins?: DatagridPluginConfig;

  /**
   * Custom configuration properties
   */
  [key: string]: unknown;
}

/**
 * Nested grid options for expandable nested grids
 */
export interface DatagridNestedGridOptions {
  /**
   * Allow multiple nested grids to be expanded simultaneously
   * When false, expanding one nested row will collapse others (accordion mode)
   * When true, multiple nested rows can be expanded at the same time
   * @default false
   */
  expandOthers?: boolean;

  /**
   * Icon to show for expanding nested rows
   * Material icon name
   * @default 'add_circle_outline'
   */
  expandMoreIcon?: string;

  /**
   * Icon to show for collapsing nested rows
   * Material icon name
   * @default 'remove_circle_outline'
   */
  expandLessIcon?: string;

  /**
   * Size of the expand/collapse icons
   * @default 'medium'
   */
  iconSize?: 'small' | 'medium' | 'large';

  /**
   * Color theme for the icons
   * @default 'primary'
   */
  iconColor?: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | string;
}

/**
 * Export configuration for data export functionality
 */
export interface DatagridExport {
  /**
   * Enable export functionality
   * @default false
   */
  enabled?: boolean;

  /**
   * Available export formats
   * Note: The grid service only explicitly handles 'pdf' format.
   * Other formats are passed to the EXPORT action subscriber.
   */
  formats?: Array<'csv' | 'excel' | 'pdf' | 'json'>;

  /**
   * File name for exported file (without extension)
   */
  fileName?: string;

  /**
   * Whether to export all data or only visible/filtered data
   * @default 'filtered'
   */
  mode?: 'all' | 'filtered' | 'selected';
}

/**
 * Plugin configuration container
 */
export interface DatagridPluginConfig {
  /**
   * Cell style plugin configuration
   */
  cellStyle?: Record<string, unknown>;

  /**
   * Condensed view plugin configuration
   */
  condensed?: Record<string, unknown>;

  /**
   * Drag column plugin configuration
   */
  dragColumn?: Record<string, unknown>;

  /**
   * Filter plugin configuration
   */
  filter?: Record<string, unknown>;

  /**
   * Fixed column plugin configuration
   */
  fixed?: Record<string, unknown>;

  /**
   * In-cell edit plugin configuration
   */
  inCellEdit?: Record<string, unknown>;

  /**
   * Incremental scroll plugin configuration
   */
  incrementalScroll?: Record<string, unknown>;

  /**
   * Keyboard navigation plugin configuration
   */
  keyboardNav?: Record<string, unknown>;

  /**
   * Mouse color/hover plugin configuration
   */
  mouseColor?: Record<string, unknown>;

  /**
   * Resize column plugin configuration
   */
  resizeColumn?: Record<string, unknown>;

  /**
   * Row style plugin configuration
   */
  rowStyle?: Record<string, unknown>;

  /**
   * Sort plugin configuration
   */
  sort?: Record<string, unknown>;

  /**
   * Striped rows plugin configuration
   */
  striped?: Record<string, unknown>;

  /**
   * Tooltip plugin configuration
   */
  tooltip?: Record<string, unknown>;

  /**
   * Truncate text plugin configuration
   */
  truncate?: Record<string, unknown>;

  /**
   * Virtual scroll plugin configuration
   */
  virtualScroll?: Record<string, unknown>;

  /**
   * Fixed column plugin configuration (alternative)
   */
  fixedColumn?: Record<string, unknown>;

  /**
   * Sticky header plugin configuration
   */
  sticky?: Record<string, unknown>;

  /**
   * Max height plugin configuration
   */
  maxHeight?: Record<string, unknown>;

  /**
   * Custom plugin configurations
   */
  [key: string]: unknown;
}

/**
 * Event emitted when a row is clicked
 */
export interface DatagridRowClickEvent<TRow = DatagridRow> {
  /**
   * The row data that was clicked
   */
  row: TRow;

  /**
   * Row index in the current view
   */
  index: number;

  /**
   * Original mouse event
   */
  event: MouseEvent;

  /**
   * Whether the row is currently selected
   */
  selected: boolean;
}

/**
 * Event emitted when a cell is clicked
 */
export interface DatagridCellClickEvent<TRow = DatagridRow> {
  /**
   * The row data containing the clicked cell
   */
  row: TRow;

  /**
   * Column definition for the clicked cell
   */
  column: DatagridColumn;

  /**
   * Cell value
   */
  value: unknown;

  /**
   * Row index in the current view
   */
  rowIndex: number;

  /**
   * Column index
   */
  columnIndex: number;

  /**
   * Original mouse event
   */
  event: MouseEvent;
}

/**
 * Event emitted when selection changes
 */
export interface DatagridSelectionChangeEvent<TRow = DatagridRow> {
  /**
   * Currently selected rows
   */
  selectedRows: TRow[];

  /**
   * IDs of selected rows
   */
  selectedRowIds: Array<string | number>;

  /**
   * Previously selected rows (before this change)
   */
  previousSelection: TRow[];
}

/**
 * Event emitted when sorting changes
 */
export interface DatagridSortChangeEvent {
  /**
   * Column name that was sorted
   */
  column: string;

  /**
   * New sort direction
   */
  direction: 'asc' | 'desc' | null;

  /**
   * All active sorts (for multi-column sorting)
   */
  sorts: Array<{ column: string; direction: 'asc' | 'desc'; priority?: number }>;
}

/**
 * Event emitted when filtering changes
 */
export interface DatagridFilterChangeEvent {
  /**
   * Column name that was filtered
   */
  column: string;

  /**
   * Filter operator
   */
  operator: string;

  /**
   * Filter value
   */
  value: unknown;

  /**
   * All active filters
   */
  filters: Array<{ column: string; operator: string; value: unknown }>;
}

/**
 * Event emitted when pagination changes
 */
export interface DatagridPageChangeEvent {
  /**
   * New current page number (1-indexed)
   */
  currentPage: number;

  /**
   * Page size (rows per page)
   */
  pageSize: number;

  /**
   * Previous page number
   */
  previousPage: number;

  /**
   * Total number of pages
   */
  totalPages: number;
}

/**
 * Event emitted when a cell value is edited
 */
export interface DatagridCellEditEvent<TRow = DatagridRow> {
  /**
   * The row being edited
   */
  row: TRow;

  /**
   * Column being edited
   */
  column: DatagridColumn;

  /**
   * Previous value before edit
   */
  oldValue: unknown;

  /**
   * New value after edit
   */
  newValue: unknown;

  /**
   * Row index
   */
  rowIndex: number;

  /**
   * Column name
   */
  columnName: string;
}

/**
 * Event emitted when column order changes (via drag-drop)
 */
export interface DatagridColumnReorderEvent {
  /**
   * Column that was moved
   */
  column: DatagridColumn;

  /**
   * Previous index
   */
  oldIndex: number;

  /**
   * New index
   */
  newIndex: number;

  /**
   * New column order (array of column names)
   */
  columnOrder: string[];
}

/**
 * Event emitted when a column is resized
 */
export interface DatagridColumnResizeEvent {
  /**
   * Column that was resized
   */
  column: DatagridColumn;

  /**
   * Previous width
   */
  oldWidth: number;

  /**
   * New width
   */
  newWidth: number;
}

/**
 * Output event types emitted by the datagrid component
 */
export type DatagridOutputEventType =
  | 'ROW_SELECTED'
  | 'ROW_UNSELECTED'
  | 'ROWS_SELECTED_ALL'
  | 'ROWS_UNSELECTED_ALL'
  | 'ROWS_CLICKED'
  | 'CONTENT_CLICKED'
  | 'HEADER_CLICKED'
  | 'GRID_UPDATED'
  | 'GRID_CHANGED'
  | 'EXPORT'
  | 'WINDOW_RESIZE'
  | 'DELETED_ROWS'
  | 'GRID_HAS_CHANGED';

/**
 * Base output event structure
 */
export interface DatagridOutputEvent<TPayload = unknown> {
  /**
   * Grid name that emitted the event
   */
  name: string;

  /**
   * Action/event type
   */
  action: DatagridOutputEventType;

  /**
   * Event payload data
   */
  payload?: TPayload;
}

/**
 * Row selected event payload
 */
export interface RowSelectedPayload {
  /**
   * Grid name
   */
  name: string;

  /**
   * Action type
   */
  action: 'ROW_SELECTED';

  /**
   * List of all selected rows
   */
  selectedList: DatagridRow[];

  /**
   * The row that was selected
   */
  row: DatagridRow;
}

/**
 * Row unselected event payload
 */
export interface RowUnselectedPayload {
  /**
   * Grid name
   */
  name: string;

  /**
   * Action type
   */
  action: 'ROW_UNSELECTED';

  /**
   * List of all selected rows
   */
  selectedList: DatagridRow[];

  /**
   * The row that was unselected
   */
  row: DatagridRow;
}

/**
 * All rows selected event payload
 */
export interface RowsSelectedAllPayload {
  /**
   * Grid name
   */
  name: string;

  /**
   * Action type
   */
  action: 'ROWS_SELECTED_ALL';

  /**
   * List of all selected rows
   */
  selectedList: DatagridRow[];
}

/**
 * All rows unselected event payload
 */
export interface RowsUnselectedAllPayload {
  /**
   * Grid name
   */
  name: string;

  /**
   * Action type
   */
  action: 'ROWS_UNSELECTED_ALL';
}

/**
 * Row clicked event payload
 */
export interface RowsClickedPayload {
  /**
   * Grid name
   */
  name: string;

  /**
   * The row that was clicked
   */
  row: DatagridRow;

  /**
   * Click type
   */
  type: string;
}

/**
 * Cell content clicked event payload
 */
export interface ContentClickedPayload {
  /**
   * Grid name
   */
  name: string;

  /**
   * Row containing the clicked cell
   */
  row: DatagridRow;

  /**
   * Column name
   */
  columnName: string;

  /**
   * Sub-column name (for nested columns)
   */
  subColumnName?: string;

  /**
   * Cell data
   */
  cell: DatagridCell | unknown;
}

/**
 * Header clicked event payload
 */
export interface HeaderClickedPayload {
  /**
   * Grid name
   */
  name: string;

  /**
   * Column that was clicked
   */
  column: DatagridColumn;

  /**
   * Sub-column that was clicked (for nested columns)
   */
  subColumn?: DatagridColumn;
}

/**
 * Grid changed event payload
 */
export interface GridChangedPayload {
  /**
   * Grid name
   */
  name: string;

  /**
   * Column that changed
   */
  column: DatagridColumn;
}

/**
 * Export event payload
 */
export interface ExportPayload {
  /**
   * Grid name
   */
  name: string;

  /**
   * Data to export
   */
  data: unknown;

  /**
   * Export type/format
   */
  type: string;
}

/**
 * Deleted rows event payload
 */
export interface DeletedRowsPayload {
  /**
   * Grid name
   */
  name: string;

  /**
   * Deleted row data
   */
  data: DatagridRow[];
}

/**
 * Grid has changed event payload
 */
export interface GridHasChangedPayload {
  /**
   * Grid name
   */
  name: string;

  /**
   * Grid instance
   */
  grid: unknown;

  /**
   * New rows added
   */
  newRows: DatagridRow[];
}
