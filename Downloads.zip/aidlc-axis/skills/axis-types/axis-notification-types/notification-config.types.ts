/**
 * Configuration types for Axis Notification system
 * @packageDocumentation
 */

/**
 * Configuration object for the Axis Notification service and component.
 *
 * This interface defines all configuration options that control the behavior
 * of the notification system, including API endpoints, polling intervals,
 * display settings, and custom templates.
 *
 * @example
 * ```typescript
 * const notificationConfig: NotificationConfig = {
 *   getAllNotificationsUrl: '/api/notifications',
 *   markAsReadUrl: '/api/notifications/read',
 *   deleteNotificationUrl: '/api/notifications/delete',
 *   checkForNotificationsUrl: '/api/notifications/check',
 *   pollingInterval: 30000,
 *   enableAutoRefresh: true,
 *   maxNotificationsDisplay: 10,
 *   showUnreadCount: true,
 *   customTemplate: MyCustomNotificationComponent
 * };
 * ```
 */
export interface NotificationConfig {
  /**
   * API endpoint URL to retrieve all notifications for the current user.
   *
   * This endpoint should return an array of notification objects with all
   * necessary fields (id, message, timestamp, read status, etc.).
   * Expected to support optional caching via cache-first strategy.
   *
   * @example '/api/notifications/all'
   * @example '/api/v1/user/notifications'
   */
  getAllNotificationsUrl?: string;

  /**
   * API endpoint URL to mark one or more notifications as read.
   *
   * This endpoint accepts an array of notification IDs and updates their
   * read status in the backend. Should return the updated notification list
   * or a success confirmation.
   *
   * @example '/api/notifications/mark-read'
   * @example '/api/v1/notifications/read'
   */
  markAsReadUrl?: string;

  /**
   * API endpoint URL to delete a specific notification.
   *
   * This endpoint accepts a single notification ID and permanently removes
   * it from the system. Should return the updated notification list or
   * a success confirmation.
   *
   * @example '/api/notifications/delete'
   * @example '/api/v1/notifications/remove'
   */
  deleteNotificationUrl?: string;

  /**
   * API endpoint URL to check for new notifications via polling.
   *
   * This endpoint is called periodically to check if new notifications
   * have arrived since the last check. Should return only new notifications
   * or an empty array if none exist.
   *
   * @example '/api/notifications/check-new'
   * @example '/api/v1/notifications/poll'
   */
  checkForNotificationsUrl?: string;

  /**
   * Time interval (in milliseconds) between automatic polling requests for new notifications.
   *
   * Controls how frequently the system checks for new notifications when
   * auto-refresh is enabled. Lower values provide more real-time updates
   * but increase server load. Common values: 15000 (15s), 30000 (30s), 60000 (1m).
   *
   * @default 30000
   * @example 15000 // Check every 15 seconds
   * @example 60000 // Check every minute
   */
  pollingInterval?: number;

  /**
   * Flag to enable or disable automatic polling for new notifications.
   *
   * When true, the notification service will automatically poll the
   * checkForNotificationsUrl endpoint at the specified pollingInterval.
   * When false, notifications are only fetched on manual refresh or page load.
   *
   * @default true
   */
  enableAutoRefresh?: boolean;

  /**
   * Maximum number of notifications to display in the notification panel.
   *
   * Limits the number of notifications shown in the dropdown/panel to prevent
   * overwhelming the UI. Older notifications beyond this limit may be hidden
   * or paginated. Set to undefined for no limit.
   *
   * @default 10
   * @example 5  // Show only the 5 most recent notifications
   * @example 20 // Show up to 20 notifications
   */
  maxNotificationsDisplay?: number;

  /**
   * Flag to show or hide the unread notification count badge.
   *
   * When true, displays a badge/counter with the number of unread notifications
   * on the notification bell icon. When false, no count is shown (though the
   * bell icon may still indicate presence of notifications).
   *
   * @default true
   */
  showUnreadCount?: boolean;

  /**
   * Flag to enable or disable notification sounds or audio alerts.
   *
   * When true, plays an audio notification when new notifications arrive.
   * When false, notifications are silent. Requires browser permission for
   * audio playback in some cases.
   *
   * @default false
   */
  enableSound?: boolean;

  /**
   * Path or URL to a custom sound file to play for notification alerts.
   *
   * Specifies the audio file to play when enableSound is true and a new
   * notification arrives. Should be a path to an audio file (mp3, wav, ogg)
   * accessible from the application.
   *
   * @example '/assets/sounds/notification.mp3'
   * @example 'https://cdn.example.com/notification-sound.wav'
   */
  soundUrl?: string;

  /**
   * Custom Angular component class to use for rendering individual notification items.
   *
   * Allows complete customization of the notification item template and behavior.
   * The component should accept a notification object as input and handle
   * click/action events. If not provided, the default notification template is used.
   *
   * @example MyCustomNotificationItemComponent
   */
  customTemplate?: unknown;

  /**
   * Additional custom properties that can be passed to the notification system.
   *
   * This allows for extensibility and passing of application-specific configuration
   * options that may be needed by custom templates or notification handlers.
   * The structure is flexible to accommodate various use cases.
   */
  [key: string]: unknown;
}

/**
 * Notification type/severity levels for categorizing and styling notifications.
 *
 * These types determine the visual appearance and urgency level of notifications.
 * Each type typically has associated colors, icons, and styling:
 * - info: Blue, informational messages (i icon)
 * - success: Green, successful operations (checkmark icon)
 * - warning: Yellow/orange, warnings and cautions (exclamation icon)
 * - error: Red, errors and critical issues (X or alert icon)
 *
 * @example
 * ```typescript
 * const notification: Notification = {
 *   id: 1,
 *   type: 'success',
 *   message: 'Data saved successfully'
 * };
 * ```
 */
export type NotificationType = 'info' | 'success' | 'warning' | 'error';

/**
 * Position options for displaying the notification panel/dropdown.
 *
 * Defines where the notification panel appears relative to the notification icon:
 * - top: Above the icon
 * - bottom: Below the icon (most common)
 * - left: To the left of the icon
 * - right: To the right of the icon
 * - center: Centered on screen (modal-like)
 *
 * @default 'bottom'
 */
export type NotificationPosition = 'top' | 'bottom' | 'left' | 'right' | 'center';

/**
 * Animation types for notification entry/exit transitions.
 *
 * Controls how notifications animate when they appear or disappear:
 * - fade: Simple opacity fade in/out
 * - slide: Slide from edge with optional direction
 * - bounce: Bouncy spring animation
 * - scale: Scale from small to full size
 * - none: No animation, instant display
 */
export type NotificationAnimation = 'fade' | 'slide' | 'bounce' | 'scale' | 'none';

/**
 * Duration presets for how long notifications remain visible (in milliseconds).
 *
 * Predefined durations for auto-dismissing notifications:
 * - short: 3000ms (3 seconds) - Quick confirmations
 * - medium: 5000ms (5 seconds) - Standard notifications
 * - long: 8000ms (8 seconds) - Important messages
 * - persistent: 0 or undefined - Requires manual dismissal
 *
 * Can also accept a custom number for specific millisecond durations.
 *
 * @example 'short'  // Auto-dismiss after 3 seconds
 * @example 'persistent' // Must be manually dismissed
 * @example 7000 // Custom 7 second duration
 */
export type NotificationDuration = 'short' | 'medium' | 'long' | 'persistent' | number;
