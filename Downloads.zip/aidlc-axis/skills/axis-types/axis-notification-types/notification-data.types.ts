/**
 * Data types for Axis Notification objects and payloads
 * @packageDocumentation
 */

import type { NotificationType } from './notification-config.types';

/**
 * Core notification data object representing a single notification.
 *
 * This interface defines the structure of a notification as received from
 * the backend API and displayed in the notification panel. Each notification
 * contains identifying information, content, metadata, and status flags.
 *
 * @example
 * ```typescript
 * const notification: NotificationData = {
 *   id: 12345,
 *   message: 'Your report has been generated',
 *   type: 'success',
 *   timestamp: new Date('2026-01-15T10:30:00Z'),
 *   isRead: false,
 *   title: 'Report Ready',
 *   actionUrl: '/reports/12345',
 *   actionLabel: 'View Report'
 * };
 * ```
 */
export interface NotificationData {
  /**
   * Unique identifier for this notification.
   *
   * Used to track, update, mark as read, or delete specific notifications.
   * Must be unique across all notifications for a user. Typically assigned
   * by the backend database.
   *
   * @example 12345
   * @example 'notif_abc123def456'
   */
  id: number | string;

  /**
   * The main notification message content.
   *
   * Primary text displayed in the notification. Should be concise and
   * clearly communicate what the notification is about. May contain
   * plain text or limited HTML depending on rendering implementation.
   *
   * @example 'Your password was changed successfully'
   * @example 'New message from John Doe'
   * @example 'System maintenance scheduled for tonight'
   */
  message: string;

  /**
   * Type/severity of the notification.
   *
   * Determines the visual styling, icon, and color scheme of the notification.
   * Helps users quickly identify the importance and nature of the notification.
   *
   * @see NotificationType
   * @default 'info'
   */
  type?: NotificationType;

  /**
   * Timestamp when the notification was created or sent.
   *
   * Used to display relative time (e.g., "5 minutes ago") or absolute time
   * in the notification panel. Also used for sorting notifications by recency.
   *
   * @example new Date('2026-01-15T10:30:00Z')
   * @example Date.now()
   */
  timestamp?: Date | string | number;

  /**
   * Flag indicating whether the notification has been read by the user.
   *
   * When false, the notification is considered "unread" and typically displayed
   * with visual emphasis (bold text, highlight, etc.). Affects the unread count
   * badge on the notification icon.
   *
   * @default false
   */
  isRead?: boolean;

  /**
   * Optional title or heading for the notification.
   *
   * Displayed above or alongside the message for added context or emphasis.
   * Typically shown in bold or larger font. Not all notifications require a title.
   *
   * @example 'Password Changed'
   * @example 'New Message'
   * @example 'System Alert'
   */
  title?: string;

  /**
   * Optional URL or route path to navigate to when the notification is clicked.
   *
   * Clicking the notification will navigate the user to this location.
   * Can be an absolute URL, relative path, or Angular route.
   * If not provided, clicking the notification may only mark it as read.
   *
   * @example '/dashboard'
   * @example '/messages/123'
   * @example 'https://example.com/reports/456'
   */
  actionUrl?: string;

  /**
   * Optional label text for the notification action button.
   *
   * If provided, displays a button with this label that navigates to actionUrl
   * or triggers a custom action. Commonly used for "View", "Open", "Dismiss", etc.
   *
   * @example 'View Message'
   * @example 'Open Report'
   * @example 'Go to Dashboard'
   */
  actionLabel?: string;

  /**
   * Optional name or path of an icon to display with the notification.
   *
   * Overrides the default icon associated with the notification type.
   * Can be an icon name (from icon library), CSS class, or path to an image.
   *
   * @example 'fa-envelope'
   * @example 'icon-success'
   * @example '/assets/icons/notification.svg'
   */
  icon?: string;

  /**
   * Optional category or classification for grouping similar notifications.
   *
   * Allows filtering or organizing notifications by category (e.g., "messages",
   * "system", "alerts"). Can be used for display grouping or filtering in the UI.
   *
   * @example 'messages'
   * @example 'system'
   * @example 'reports'
   */
  category?: string;

  /**
   * Optional priority level for sorting and display emphasis.
   *
   * Higher priority notifications can be displayed first or with special styling.
   * Priority values are typically: high (3), medium (2), low (1), or numeric scale.
   *
   * @example 'high'
   * @example 'medium'
   * @example 3
   */
  priority?: 'high' | 'medium' | 'low' | number;

  /**
   * Optional metadata or additional data associated with the notification.
   *
   * Allows passing custom data that may be needed by custom templates,
   * action handlers, or application-specific logic. Structure is flexible
   * to accommodate various use cases.
   *
   * @example { userId: 123, reportId: 456 }
   * @example { conversationId: 'conv_789', sender: 'John Doe' }
   */
  metadata?: Record<string, unknown>;

  /**
   * Additional custom properties that can be added to the notification.
   *
   * Provides extensibility for application-specific notification fields
   * without modifying the core interface.
   */
  [key: string]: unknown;
}

/**
 * Response payload structure for notification API endpoints.
 *
 * Standard response format returned by notification API endpoints.
 * Contains an array of notifications along with metadata about the result.
 *
 * @example
 * ```typescript
 * const response: NotificationResponse = {
 *   notifications: [
 *     { id: 1, message: 'First notification', isRead: false },
 *     { id: 2, message: 'Second notification', isRead: true }
 *   ],
 *   totalCount: 25,
 *   unreadCount: 8,
 *   success: true
 * };
 * ```
 */
export interface NotificationResponse {
  /**
   * Array of notification objects returned by the API.
   *
   * Contains the actual notification data. May be all notifications,
   * only new notifications, or a paginated subset depending on the endpoint.
   */
  notifications: NotificationData[];

  /**
   * Total number of notifications available for the user.
   *
   * Includes both read and unread notifications. Useful for pagination
   * or displaying total notification count. May be omitted if not applicable.
   */
  totalCount?: number;

  /**
   * Number of unread notifications.
   *
   * Count of notifications with isRead = false. Used to display the
   * unread badge count on the notification icon. May be omitted if not tracked.
   */
  unreadCount?: number;

  /**
   * Flag indicating whether the API request was successful.
   *
   * When true, the request completed successfully. When false, indicates
   * an error occurred and errorMessage may contain details.
   *
   * @default true
   */
  success?: boolean;

  /**
   * Error message if the API request failed.
   *
   * Contains a human-readable error message explaining what went wrong.
   * Only present when success is false.
   *
   * @example 'Failed to fetch notifications'
   * @example 'Authentication token expired'
   */
  errorMessage?: string;

  /**
   * Timestamp of when the response was generated.
   *
   * Can be used for cache validation or displaying when the notification
   * list was last updated.
   */
  timestamp?: Date | string | number;
}

/**
 * Event object emitted when a notification action is triggered.
 *
 * Contains information about the notification and the action that was performed.
 * Used by event handlers to process notification interactions.
 *
 * @example
 * ```typescript
 * onNotificationAction(event: NotificationActionEvent): void {
 *   console.log('Action:', event.action);
 *   console.log('Notification:', event.notification);
 *   if (event.action === 'click') {
 *     this.router.navigate([event.notification.actionUrl]);
 *   }
 * }
 * ```
 */
export interface NotificationActionEvent {
  /**
   * The type of action that was performed.
   *
   * Indicates what user interaction occurred:
   * - click: Notification was clicked
   * - delete: Delete button was clicked
   * - action: Action button was clicked
   * - markAsRead: Mark as read was triggered
   *
   * @example 'click'
   * @example 'delete'
   */
  action: 'click' | 'delete' | 'action' | 'markAsRead' | string;

  /**
   * The notification object that the action was performed on.
   *
   * Contains all the notification data associated with this action.
   */
  notification: NotificationData;

  /**
   * Original browser event object, if applicable.
   *
   * The underlying MouseEvent, KeyboardEvent, etc. that triggered the action.
   * Useful for preventing default behavior or accessing event details.
   */
  originalEvent?: Event;

  /**
   * Timestamp when the action occurred.
   *
   * Can be used for analytics or logging purposes.
   */
  timestamp?: Date | number;
}

/**
 * Parameters for marking notifications as read.
 *
 * Used when calling the mark-as-read API endpoint to update notification status.
 *
 * @example
 * ```typescript
 * const params: MarkAsReadParams = {
 *   notificationIds: [1, 2, 3, 4, 5],
 *   markAll: false
 * };
 * ```
 */
export interface MarkAsReadParams {
  /**
   * Array of notification IDs to mark as read.
   *
   * If empty and markAll is true, all notifications will be marked as read.
   */
  notificationIds: Array<number | string>;

  /**
   * Flag to mark all notifications as read regardless of the ID list.
   *
   * When true, ignores notificationIds and marks all user notifications as read.
   *
   * @default false
   */
  markAll?: boolean;
}

/**
 * Parameters for deleting a notification.
 *
 * Used when calling the delete notification API endpoint.
 *
 * @example
 * ```typescript
 * const params: DeleteNotificationParams = {
 *   notificationId: 12345
 * };
 * ```
 */
export interface DeleteNotificationParams {
  /**
   * The unique identifier of the notification to delete.
   *
   * Must match an existing notification ID for the current user.
   */
  notificationId: number | string;
}
