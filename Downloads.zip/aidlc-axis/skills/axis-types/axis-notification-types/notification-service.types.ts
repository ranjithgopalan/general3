/**
 * Service types for Axis Notification service
 * @packageDocumentation
 */

import type { Subject, Observable } from 'rxjs';
import type { HttpClient } from '@angular/common/http';
import type { NotificationConfig } from './notification-config.types';
import type { NotificationData, NotificationResponse, NotificationActionEvent } from './notification-data.types';

/**
 * Cache API response wrapper used by Axis notification service.
 *
 * This interface represents the structure returned by the AxisCacheService
 * for API calls with caching capabilities. It provides a promise-like interface
 * with additional caching and rehydration features.
 *
 * @template T The type of data expected in the API response
 */
export interface CacheApiResponse<T = unknown> {
  /**
   * Promise-like handler for the cached API response.
   *
   * Provides three callback functions:
   * - handleResponse: Called with the cached response data
   * - handleHydrate: Optional callback when fresh data is fetched (rehydration)
   * - error: Optional error handler for API failures
   *
   * @param handleResponse - Function to handle the initial (potentially cached) response
   * @param handleHydrate - Optional function to handle fresh data from server
   * @param error - Optional function to handle errors
   *
   * @example
   * ```typescript
   * cacheResponse.then(
   *   (data) => console.log('Cached data:', data),
   *   (freshData) => console.log('Fresh data:', freshData),
   *   (err) => console.error('Error:', err)
   * );
   * ```
   */
  then: (
    handleResponse: (data: T) => void,
    handleHydrate?: (data: T) => void,
    error?: (err: unknown) => void
  ) => void;

  /**
   * The raw Observable for the API call.
   *
   * Direct access to the underlying HTTP call Observable if needed
   * for advanced RxJS operations or custom handling.
   */
  callApi: Observable<T>;

  /**
   * HTTP method used for the API call.
   *
   * @example 'GET'
   * @example 'POST'
   * @example 'PUT'
   */
  method: string;

  /**
   * Full URL for the API endpoint being called.
   *
   * @example 'https://api.example.com/notifications'
   */
  url: string;

  /**
   * Flag indicating whether caching is enabled for this request.
   *
   * When true, the response will be cached and returned from cache on subsequent calls.
   */
  useCache: boolean;

  /**
   * Flag indicating whether to rehydrate (refresh) cached data.
   *
   * When true, cached data is returned immediately but a fresh API call
   * is made in the background to update the cache.
   */
  reHydrate: boolean;

  /**
   * Type of storage used for caching.
   *
   * - 'sessionStorage': Cache persists for the browser session only
   * - 'localStorage': Cache persists across browser sessions
   * - 'memory': Cache is stored in memory only (cleared on page refresh)
   *
   * @example 'sessionStorage'
   */
  storageType: string;

  /**
   * Cache key used to store and retrieve the cached response.
   *
   * Unique identifier for this cached data. Typically derived from the
   * API endpoint URL and query parameters.
   *
   * @example 'notifications_all'
   * @example 'notifications_user_123'
   */
  key: string;
}

/**
 * Type definition for the AxisNotificationService class.
 *
 * This interface defines the complete API surface of the Axis notification service,
 * including all methods for fetching, updating, and managing notifications, as well
 * as observables for real-time notification updates.
 *
 * @example
 * ```typescript
 * import { AxisNotificationService } from 'axis-notification';
 *
 * export class MyComponent {
 *   constructor(private notificationService: IAxisNotificationService) {
 *     this.notificationService.setConfig({
 *       getAllNotificationsUrl: '/api/notifications',
 *       pollingInterval: 30000
 *     });
 *   }
 *
 *   loadNotifications(): void {
 *     this.notificationService.getAllNotifications(true).then(
 *       (response) => {
 *         console.log('Notifications:', response);
 *       }
 *     );
 *   }
 * }
 * ```
 */
export interface IAxisNotificationService {
  /**
   * Subject that emits notification events.
   *
   * Emits events when notifications are received, updated, or deleted.
   * Subscribe to this to react to notification changes in your application.
   *
   * @example
   * ```typescript
   * this.notificationService.onNotification.subscribe((event) => {
   *   console.log('Notification event:', event);
   * });
   * ```
   */
  onNotification: Subject<NotificationActionEvent>;

  /**
   * Subject that emits notification action events.
   *
   * Emits events when a user interacts with a notification (clicks, deletes, etc.).
   * Subscribe to this to handle notification actions in your application.
   *
   * @example
   * ```typescript
   * this.notificationService.onActionNotification.subscribe((event) => {
   *   if (event.action === 'click') {
   *     this.router.navigate([event.notification.actionUrl]);
   *   }
   * });
   * ```
   */
  onActionNotification: Subject<NotificationActionEvent>;

  /**
   * Constant identifier for successful notification receive events.
   *
   * Used to identify the event type when new notifications are successfully received.
   *
   * @example 'NOTIFICATION_RECEIVE'
   */
  NOTIFICATION_RECEIVE: string;

  /**
   * Constant identifier for notification receive error events.
   *
   * Used to identify the event type when an error occurs while fetching notifications.
   *
   * @example 'NOTIFICATION_RECEIVE_ERROR'
   */
  NOTIFICATION_RECEIVE_ERROR: string;

  /**
   * Flag indicating whether a polling request is currently in progress.
   *
   * Used to prevent multiple concurrent polling requests. When true, indicates
   * that a request to check for new notifications is already pending.
   */
  isPendingPollRequest: boolean;

  /**
   * HTTP client instance for making API requests.
   *
   * Angular HttpClient used internally for all notification API calls.
   */
  readonly http: HttpClient;

  /**
   * Configure the notification service with API endpoints and settings.
   *
   * Must be called before using other service methods to set up API URLs,
   * polling intervals, and other configuration options. Can be called multiple
   * times to update configuration dynamically.
   *
   * @param configuration - Configuration object with API URLs and settings
   *
   * @example
   * ```typescript
   * this.notificationService.setConfig({
   *   getAllNotificationsUrl: '/api/notifications/all',
   *   markAsReadUrl: '/api/notifications/read',
   *   deleteNotificationUrl: '/api/notifications/delete',
   *   checkForNotificationsUrl: '/api/notifications/check',
   *   pollingInterval: 30000,
   *   enableAutoRefresh: true
   * });
   * ```
   */
  setConfig(configuration: NotificationConfig): void;

  /**
   * Fetch all notifications for the current user.
   *
   * Retrieves the complete list of notifications from the API. Supports
   * cache-first strategy to improve performance and reduce API calls.
   * When caching is enabled, returns cached data immediately and optionally
   * rehydrates with fresh data in the background.
   *
   * @param useCacheFirst - Whether to return cached data first (default: true)
   * @returns A cache-wrapped response object with notification data
   *
   * @example
   * ```typescript
   * // Use cache first, then rehydrate with fresh data
   * this.notificationService.getAllNotifications(true).then(
   *   (cachedData) => {
   *     this.notifications = cachedData.notifications;
   *   },
   *   (freshData) => {
   *     this.notifications = freshData.notifications; // Updated with fresh data
   *   }
   * );
   *
   * // Always fetch fresh data, bypass cache
   * this.notificationService.getAllNotifications(false).then(
   *   (data) => {
   *     this.notifications = data.notifications;
   *   }
   * );
   * ```
   */
  getAllNotifications(useCacheFirst?: boolean): CacheApiResponse<NotificationResponse>;

  /**
   * Mark one or more notifications as read.
   *
   * Updates the read status of specified notifications on the server.
   * After successful completion, the notifications will no longer be counted
   * in the unread badge and may be styled differently in the UI.
   *
   * @param notificationIdList - Array of notification IDs to mark as read
   * @returns A cache-wrapped response object with updated notification data
   *
   * @example
   * ```typescript
   * const unreadIds = [1, 2, 3, 4];
   * this.notificationService.markNotificationsAsRead(unreadIds).then(
   *   (response) => {
   *     console.log('Marked as read:', response);
   *     this.updateUnreadCount();
   *   },
   *   null,
   *   (error) => {
   *     console.error('Failed to mark as read:', error);
   *   }
   * );
   * ```
   */
  markNotificationsAsRead(notificationIdList: number[]): CacheApiResponse<NotificationResponse>;

  /**
   * Delete a specific notification.
   *
   * Permanently removes the notification from the system. This action cannot
   * be undone. After successful deletion, the notification will no longer appear
   * in the notification list and the unread count will be updated if applicable.
   *
   * @param notificationId - The unique ID of the notification to delete
   * @returns A cache-wrapped response object with updated notification data
   *
   * @example
   * ```typescript
   * this.notificationService.deleteNotification(12345).then(
   *   (response) => {
   *     console.log('Notification deleted');
   *     this.refreshNotificationList();
   *   },
   *   null,
   *   (error) => {
   *     console.error('Failed to delete:', error);
   *   }
   * );
   * ```
   */
  deleteNotification(notificationId: number): CacheApiResponse<NotificationResponse>;

  /**
   * Start subscribing to new notification updates via polling.
   *
   * Initiates the automatic polling mechanism to check for new notifications
   * at the configured polling interval. Should be called once during component
   * initialization if auto-refresh is enabled. Continues polling until stopped
   * or component is destroyed.
   *
   * @example
   * ```typescript
   * ngOnInit(): void {
   *   this.notificationService.subscribeForNewNotifications();
   * }
   * ```
   */
  subscribeForNewNotifications(): void;

  /**
   * Check for new notifications immediately (single poll).
   *
   * Makes a single API call to check if new notifications have arrived since
   * the last check. Used internally by the polling mechanism but can also be
   * called manually to force an immediate check.
   *
   * @returns Observable that emits the API response with new notifications
   *
   * @example
   * ```typescript
   * this.notificationService.checkForNotifications().subscribe(
   *   (response) => {
   *     console.log('New notifications:', response);
   *   },
   *   (error) => {
   *     console.error('Check failed:', error);
   *   }
   * );
   * ```
   */
  checkForNotifications(): Observable<Response>;

  /**
   * Emit a notification message to all subscribers.
   *
   * Internal method used to broadcast notification events to components
   * subscribed to the notification observables. Triggers the onNotification
   * subject with the specified event type and data.
   *
   * @param tp - Event type (NOTIFICATION_RECEIVE or NOTIFICATION_RECEIVE_ERROR)
   * @param dt - Optional array of notification objects
   *
   * @example
   * ```typescript
   * // Internal usage - typically called by the service itself
   * this.sendMessage('NOTIFICATION_RECEIVE', newNotifications);
   * ```
   */
  sendMessage(tp: string, dt?: NotificationData[]): void;

  /**
   * Clear all notification messages and reset state.
   *
   * Clears the notification subjects and resets any internal state.
   * Useful for cleanup or when logging out a user.
   *
   * @example
   * ```typescript
   * ngOnDestroy(): void {
   *   this.notificationService.clearMessage();
   * }
   * ```
   */
  clearMessage(): void;

  /**
   * Get an observable for notification events.
   *
   * Returns an observable that emits whenever notifications are received,
   * updated, or errors occur. Subscribe to this to react to notification
   * state changes in your application.
   *
   * @returns Observable that emits notification events
   *
   * @example
   * ```typescript
   * this.notificationService.getMessage().subscribe((event) => {
   *   if (event.type === 'NOTIFICATION_RECEIVE') {
   *     this.handleNewNotifications(event.data);
   *   } else if (event.type === 'NOTIFICATION_RECEIVE_ERROR') {
   *     this.handleError(event.error);
   *   }
   * });
   * ```
   */
  getMessage(): Observable<{
    type: string;
    data?: NotificationData[];
    error?: unknown;
  }>;

  /**
   * Get an observable for notification action events.
   *
   * Returns an observable that emits whenever a user interacts with a notification
   * (clicks, deletes, marks as read, etc.). Subscribe to this to handle user
   * actions on notifications.
   *
   * @returns Observable that emits notification action events
   *
   * @example
   * ```typescript
   * this.notificationService.getMessageOnAction().subscribe((event) => {
   *   if (event.action === 'click') {
   *     this.router.navigate([event.notification.actionUrl]);
   *   } else if (event.action === 'delete') {
   *     this.handleDelete(event.notification);
   *   }
   * });
   * ```
   */
  getMessageOnAction(): Observable<NotificationActionEvent>;

  /**
   * Get an observable for general notification events.
   *
   * Returns an observable that emits on various notification-related events.
   * Similar to getMessage() but may include additional event types.
   *
   * @returns Observable that emits notification events
   *
   * @example
   * ```typescript
   * this.notificationService.getMessageOnNotification().subscribe((event) => {
   *   console.log('Notification event:', event);
   * });
   * ```
   */
  getMessageOnNotification(): Observable<NotificationActionEvent>;
}
