/**
 * Module types for Axis Notification module
 * @packageDocumentation
 */

import type { ModuleWithProviders, Type } from '@angular/core';
import type { IAxisNotificationComponent } from './notification-component.types';
import type { IAxisNotificationService } from './notification-service.types';

/**
 * Type definition for the AxisNotificationModule class.
 *
 * This interface defines the Angular module that provides the notification
 * component and service. The module handles dependency injection, imports
 * required Angular modules, and exports the notification component for use
 * in other parts of the application.
 *
 * @example
 * ```typescript
 * // Import in your app module
 * import { AxisNotificationModule } from 'axis-notification';
 *
 * @NgModule({
 *   imports: [
 *     BrowserModule,
 *     HttpClientModule,
 *     AxisNotificationModule,
 *     // ... other modules
 *   ],
 *   declarations: [AppComponent],
 *   bootstrap: [AppComponent]
 * })
 * export class AppModule { }
 * ```
 *
 * @example
 * ```typescript
 * // Use the notification component in your template
 * @Component({
 *   selector: 'app-root',
 *   template: `
 *     <div class="app-header">
 *       <axis-notifications
 *         [config]="notificationConfig"
 *         [refreshMode]="true">
 *       </axis-notifications>
 *     </div>
 *   `
 * })
 * export class AppComponent {
 *   notificationConfig = {
 *     getAllNotificationsUrl: '/api/notifications',
 *     pollingInterval: 30000
 *   };
 * }
 * ```
 */
export interface IAxisNotificationModule {
  /**
   * Module constructor.
   *
   * Called when the module is instantiated by Angular's dependency injection system.
   * Typically used for initialization logic or logging.
   *
   * @example
   * ```typescript
   * constructor() {
   *   console.log('AxisNotificationModule loaded');
   * }
   * ```
   */
  constructor(): void;
}

/**
 * Configuration options for the AxisNotificationModule.
 *
 * Used when importing the module with custom configuration via forRoot() pattern.
 * Allows setting default values that will be used throughout the application
 * unless overridden at the component level.
 *
 * @example
 * ```typescript
 * import { AxisNotificationModule } from 'axis-notification';
 *
 * @NgModule({
 *   imports: [
 *     AxisNotificationModule.forRoot({
 *       defaultPollingInterval: 30000,
 *       defaultMaxNotificationsDisplay: 10,
 *       enableSoundByDefault: false
 *     })
 *   ]
 * })
 * export class AppModule { }
 * ```
 */
export interface NotificationModuleConfig {
  /**
   * Default polling interval (in milliseconds) for checking new notifications.
   *
   * This value will be used as the default for all notification components
   * unless overridden in the component's config input.
   *
   * @default 30000
   * @example 15000 // Check every 15 seconds
   * @example 60000 // Check every minute
   */
  defaultPollingInterval?: number;

  /**
   * Default maximum number of notifications to display in the panel.
   *
   * This value will be used as the default for all notification components
   * unless overridden in the component's config input.
   *
   * @default 10
   * @example 5  // Show only 5 most recent
   * @example 20 // Show up to 20 notifications
   */
  defaultMaxNotificationsDisplay?: number;

  /**
   * Flag to enable notification sounds by default.
   *
   * When true, all notification components will play sounds when new
   * notifications arrive (unless overridden at component level).
   *
   * @default false
   */
  enableSoundByDefault?: boolean;

  /**
   * Default sound URL for notification alerts.
   *
   * Path or URL to the audio file to play for new notifications.
   * Used when enableSoundByDefault is true.
   *
   * @example '/assets/sounds/notification.mp3'
   * @example 'https://cdn.example.com/notification.wav'
   */
  defaultSoundUrl?: string;

  /**
   * Flag to enable auto-refresh (polling) by default.
   *
   * When true, all notification components will automatically poll for
   * new notifications unless overridden at component level.
   *
   * @default true
   */
  enableAutoRefreshByDefault?: boolean;

  /**
   * Flag to show unread count badge by default.
   *
   * When true, all notification components will display the unread count
   * badge unless overridden at component level.
   *
   * @default true
   */
  showUnreadCountByDefault?: boolean;
}

/**
 * Type for ModuleWithProviders pattern used in Angular.
 *
 * Returned by static forRoot() or forChild() methods to provide
 * module configuration and services at the root or feature module level.
 *
 * @example
 * ```typescript
 * class AxisNotificationModule {
 *   static forRoot(config?: NotificationModuleConfig): ModuleWithProviders<AxisNotificationModule> {
 *     return {
 *       ngModule: AxisNotificationModule,
 *       providers: [
 *         AxisNotificationService,
 *         { provide: NOTIFICATION_CONFIG, useValue: config || {} }
 *       ]
 *     };
 *   }
 * }
 * ```
 */
export type NotificationModuleWithProviders = ModuleWithProviders<IAxisNotificationModule>;

/**
 * Angular component type for the notification component.
 *
 * Used for component references, dynamic component creation, and type checking.
 *
 * @example
 * ```typescript
 * const componentType: NotificationComponentType = AxisNotificationComponent;
 * const componentRef = viewContainerRef.createComponent(componentType);
 * ```
 */
export type NotificationComponentType = Type<IAxisNotificationComponent>;

/**
 * Angular service type for the notification service.
 *
 * Used for dependency injection typing and service references.
 *
 * @example
 * ```typescript
 * constructor(
 *   private notificationService: NotificationServiceType
 * ) {
 *   this.notificationService.setConfig({ ... });
 * }
 * ```
 */
export type NotificationServiceType = Type<IAxisNotificationService>;

/**
 * Injection token for notification module configuration.
 *
 * Used in Angular's dependency injection system to provide module-level
 * configuration that can be injected into services and components.
 *
 * @example
 * ```typescript
 * import { InjectionToken } from '@angular/core';
 *
 * export const NOTIFICATION_CONFIG = new InjectionToken<NotificationModuleConfig>(
 *   'AxisNotificationModuleConfig'
 * );
 *
 * // In module providers
 * providers: [
 *   { provide: NOTIFICATION_CONFIG, useValue: myConfig }
 * ]
 *
 * // In service/component
 * constructor(
 *   @Inject(NOTIFICATION_CONFIG) private config: NotificationModuleConfig
 * ) { }
 * ```
 */
export interface NotificationConfigToken {
  /**
   * The injection token identifier.
   */
  token: string;

  /**
   * The configuration value.
   */
  value: NotificationModuleConfig;
}
