/**
 * Component types for Axis Notification component
 * @packageDocumentation
 */

import type { ElementRef, QueryList, ViewContainerRef, Renderer2, ChangeDetectorRef } from '@angular/core';
import type { NotificationConfig } from './notification-config.types';
import type { NotificationData } from './notification-data.types';
import type { IAxisNotificationService } from './notification-service.types';

/**
 * Type definition for the AxisNotificationComponent class.
 *
 * This interface defines the complete API surface of the Axis notification component,
 * which provides the UI for displaying and managing notifications. The component
 * handles rendering the notification bell icon, dropdown panel, notification list,
 * and user interactions.
 *
 * @example
 * ```typescript
 * // In template
 * <axis-notifications
 *   [config]="notificationConfig"
 *   [icon]="bellIcon"
 *   [refreshMode]="true"
 *   [axisIncludeComponent]="customNotificationItem">
 * </axis-notifications>
 *
 * // In component
 * export class AppComponent {
 *   notificationConfig: NotificationConfig = {
 *     getAllNotificationsUrl: '/api/notifications',
 *     pollingInterval: 30000
 *   };
 *
 *   bellIcon = {
 *     name: 'fa-bell',
 *     color: '#007bff'
 *   };
 * }
 * ```
 */
export interface IAxisNotificationComponent {
  /**
   * Configuration object for the notification component and service.
   *
   * Provides all settings needed for API endpoints, polling, display options,
   * and behavior. This configuration is passed to the notification service
   * during initialization.
   *
   * @input
   * @example
   * ```typescript
   * config: NotificationConfig = {
   *   getAllNotificationsUrl: '/api/notifications/all',
   *   markAsReadUrl: '/api/notifications/read',
   *   deleteNotificationUrl: '/api/notifications/delete',
   *   pollingInterval: 30000,
   *   maxNotificationsDisplay: 10
   * };
   * ```
   */
  config: NotificationConfig;

  /**
   * Icon configuration for the notification bell icon.
   *
   * Defines the appearance of the notification icon displayed in the UI.
   * Can specify icon name, color, size, and other visual properties.
   * The structure depends on the icon library being used (Font Awesome, Material Icons, etc.).
   *
   * @input
   * @example
   * ```typescript
   * icon = {
   *   name: 'fa-bell',
   *   color: '#007bff',
   *   size: '24px'
   * };
   * ```
   */
  icon: {
    name?: string;
    color?: string;
    size?: string;
    class?: string;
    [key: string]: unknown;
  };

  /**
   * Flag to enable or disable manual refresh mode.
   *
   * When true, displays a refresh button in the notification panel that allows
   * users to manually refresh the notification list. When false, only automatic
   * polling updates are available (if configured).
   *
   * @input
   * @default false
   */
  refreshMode: boolean;

  /**
   * Custom Angular component class for rendering individual notification items.
   *
   * Allows complete customization of how each notification is displayed in the list.
   * The component receives a notification object as input and can implement custom
   * styling, layout, and interaction logic. If not provided, the default template is used.
   *
   * @input
   * @example
   * ```typescript
   * axisIncludeComponent = CustomNotificationItemComponent;
   * ```
   */
  axisIncludeComponent: unknown;

  /**
   * Array of all notifications currently loaded in the component.
   *
   * Contains the complete list of notifications fetched from the API.
   * This array is updated when new notifications arrive or when notifications
   * are deleted or marked as read.
   *
   * @example
   * ```typescript
   * notificationList: NotificationData[] = [
   *   { id: 1, message: 'First notification', isRead: false },
   *   { id: 2, message: 'Second notification', isRead: true }
   * ];
   * ```
   */
  notificationList: NotificationData[];

  /**
   * Flag indicating whether the notification panel is currently hidden.
   *
   * Controls the visibility of the notification dropdown/panel. When true,
   * the panel is hidden; when false, it's visible. Toggled when the user
   * clicks the notification icon.
   *
   * @default true
   */
  notificationHidden: boolean;

  /**
   * Flag indicating whether a notification fetch operation is in progress.
   *
   * Used to prevent multiple concurrent API calls and to display loading
   * indicators in the UI. When true, a loading spinner or skeleton may be shown.
   *
   * @default false
   */
  getNotificationCallInProgress: boolean;

  /**
   * Count of unread notifications.
   *
   * Displays the number of notifications with isRead = false.
   * This value is shown in a badge on the notification icon to alert users
   * to new or unread notifications.
   *
   * @default 0
   */
  unreadNotificationsCount: number;

  /**
   * Array of component references for dynamically created custom notification items.
   *
   * When using axisIncludeComponent, this array stores references to the
   * dynamically instantiated custom components. Used for component lifecycle
   * management and cleanup.
   */
  componentRef: Array<unknown>;

  /**
   * QueryList of element references for notification row content.
   *
   * References to the DOM elements containing each notification's content.
   * Used for dynamic manipulation, measuring, or applying styles to individual
   * notification elements.
   */
  rowContentRefs: QueryList<ElementRef>;

  /**
   * QueryList of view container references for notification rows.
   *
   * References to the view containers where custom notification components
   * are dynamically inserted. Used when axisIncludeComponent is provided
   * to create component instances.
   */
  rowRefs: QueryList<ViewContainerRef>;

  /**
   * Current notification object being processed or interacted with.
   *
   * Stores a reference to the notification currently being acted upon
   * (e.g., being deleted, marked as read, or clicked). Used internally
   * for state management during user interactions.
   */
  currObj: NotificationData | null;

  /**
   * Angular Renderer2 service for safe DOM manipulation.
   *
   * Used internally for adding/removing classes, setting styles, and
   * other DOM operations in a platform-safe manner.
   */
  readonly renderer: Renderer2;

  /**
   * Axis notification service instance.
   *
   * The injected service that handles all API calls, polling, and
   * notification state management. The component communicates with
   * the backend through this service.
   */
  readonly notificationService: IAxisNotificationService;

  /**
   * Angular ChangeDetectorRef for manual change detection.
   *
   * Used to trigger change detection when notification data is updated
   * asynchronously, ensuring the UI reflects the latest state.
   */
  readonly changeDetectorRef: ChangeDetectorRef;

  /**
   * Default polling interval in milliseconds.
   *
   * Fallback value used if no polling interval is specified in the configuration.
   * Typically 30000ms (30 seconds).
   */
  readonly DEFAULT_INTERVAL: number;

  /**
   * Initialize the component.
   *
   * Angular lifecycle hook called after the component is created.
   * Sets up the notification service configuration, subscribes to
   * notification events, and fetches the initial notification list.
   *
   * @example
   * ```typescript
   * ngOnInit(): void {
   *   this.notificationService.setConfig(this.config);
   *   this.subscribeForNewNotifications();
   *   this.getAllNotifications(true, false);
   * }
   * ```
   */
  ngOnInit(): void;

  /**
   * Post-initialization hook after view is ready.
   *
   * Angular lifecycle hook called after the component's view has been
   * fully initialized. Used for operations that require the DOM to be
   * ready, such as instantiating custom notification item components.
   *
   * @example
   * ```typescript
   * ngAfterViewInit(): void {
   *   this.updateTemplate();
   * }
   * ```
   */
  ngAfterViewInit(): void;

  /**
   * Update the notification template by instantiating custom components.
   *
   * Called when custom notification item components need to be created
   * or recreated. Iterates through the notification list and instantiates
   * the axisIncludeComponent for each notification if provided.
   *
   * @example
   * ```typescript
   * updateTemplate(): void {
   *   if (this.axisIncludeComponent && this.notificationList.length > 0) {
   *     this.notificationList.forEach((_, index) => {
   *       this.instantiateExternalListItem(index);
   *     });
   *   }
   * }
   * ```
   */
  updateTemplate(): void;

  /**
   * Instantiate a custom component for a specific notification list item.
   *
   * Dynamically creates an instance of axisIncludeComponent for the notification
   * at the specified index. The component is inserted into the appropriate
   * view container and receives the notification data as input.
   *
   * @param currIndex - Zero-based index of the notification in the list
   *
   * @example
   * ```typescript
   * instantiateExternalListItem(0); // Creates component for first notification
   * ```
   */
  instantiateExternalListItem(currIndex: number): void;

  /**
   * Handle new notification arrival from the service.
   *
   * Called when the notification service emits a new notification event
   * (either from polling or push updates). Updates the notification list,
   * recalculates the unread count, and triggers UI updates.
   *
   * @param notification - The new notification data or array of notifications
   *
   * @example
   * ```typescript
   * handleNewNotification(newNotifications: NotificationData[]): void {
   *   this.notificationList.unshift(...newNotifications);
   *   this.calculateUnReadNotificationsCount();
   *   this.changeDetectorRef.detectChanges();
   * }
   * ```
   */
  handleNewNotification(notification: NotificationData | NotificationData[]): void;

  /**
   * Subscribe to new notification updates from the service.
   *
   * Sets up subscriptions to the notification service's observables to
   * receive real-time updates when new notifications arrive. Calls
   * handleNewNotification() when events are received.
   *
   * @example
   * ```typescript
   * subscribeForNewNotifications(): void {
   *   this.notificationService.getMessage().subscribe((event) => {
   *     if (event.type === 'NOTIFICATION_RECEIVE') {
   *       this.handleNewNotification(event.data);
   *     }
   *   });
   * }
   * ```
   */
  subscribeForNewNotifications(): void;

  /**
   * Fetch all notifications from the API.
   *
   * Retrieves the complete notification list from the backend via the
   * notification service. Can optionally use cached data first for better
   * performance. Updates the component's notification list and unread count
   * upon successful retrieval.
   *
   * @param useCache - Whether to use cached data first (default: true)
   * @param refreshMode - Whether this is a manual refresh operation (default: false)
   *
   * @example
   * ```typescript
   * // Load with cache, not a manual refresh
   * this.getAllNotifications(true, false);
   *
   * // Force fresh data, manual refresh
   * this.getAllNotifications(false, true);
   * ```
   */
  getAllNotifications(useCache: boolean, refreshMode: boolean): void;

  /**
   * Success handler for getAllNotifications API call.
   *
   * Processes the response from the notification API, updates the local
   * notification list, calculates unread counts, and triggers change detection.
   * Called by getAllNotifications() when the API call succeeds.
   *
   * @param res - The API response containing notification data
   *
   * @example
   * ```typescript
   * getAllNotifications_success(response: NotificationResponse): void {
   *   this.notificationList = response.notifications;
   *   this.calculateUnReadNotificationsCount();
   *   this.getNotificationCallInProgress = false;
   * }
   * ```
   */
  getAllNotifications_success(res: NotificationData[] | { notifications: NotificationData[] }): void;

  /**
   * Calculate the number of unread notifications.
   *
   * Counts notifications with isRead = false and updates the
   * unreadNotificationsCount property. This value is displayed in the
   * badge on the notification icon.
   *
   * @example
   * ```typescript
   * calculateUnReadNotificationsCount(): void {
   *   this.unreadNotificationsCount = this.notificationList.filter(
   *     n => !n.isRead
   *   ).length;
   * }
   * ```
   */
  calculateUnReadNotificationsCount(): void;

  /**
   * Mark all currently displayed unread notifications as read.
   *
   * Collects the IDs of all unread notifications and calls the notification
   * service to mark them as read on the backend. Updates the UI after successful
   * completion. Typically triggered when the notification panel is opened.
   *
   * @example
   * ```typescript
   * markNotificationsAsRead(): void {
   *   const unreadIds = this.notificationList
   *     .filter(n => !n.isRead)
   *     .map(n => n.id);
   *
   *   if (unreadIds.length > 0) {
   *     this.notificationService.markNotificationsAsRead(unreadIds).then(
   *       (response) => this.markNotificationsAsRead_success(response)
   *     );
   *   }
   * }
   * ```
   */
  markNotificationsAsRead(): void;

  /**
   * Success handler for markNotificationsAsRead API call.
   *
   * Processes the response after successfully marking notifications as read.
   * Updates the local notification list to reflect the new read status and
   * recalculates the unread count.
   *
   * @param res - The API response containing updated notification data
   *
   * @example
   * ```typescript
   * markNotificationsAsRead_success(response: NotificationResponse): void {
   *   this.notificationList.forEach(n => n.isRead = true);
   *   this.calculateUnReadNotificationsCount();
   * }
   * ```
   */
  markNotificationsAsRead_success(res: NotificationData[] | { notifications: NotificationData[] }): void;

  /**
   * Delete a specific notification.
   *
   * Removes the specified notification from the system by calling the
   * notification service's delete endpoint. Updates the UI after successful
   * deletion by removing the notification from the list and updating counts.
   *
   * @param notificationId - The unique ID of the notification to delete
   *
   * @example
   * ```typescript
   * deleteNotification(12345): void {
   *   this.notificationService.deleteNotification(12345).then(
   *     (response) => this.deleteNotification_success(response)
   *   );
   * }
   * ```
   */
  deleteNotification(notificationId: number): void;

  /**
   * Success handler for deleteNotification API call.
   *
   * Processes the response after successfully deleting a notification.
   * Calls updateNotificationsAfterDelete to refresh the notification list
   * and update counts.
   *
   * @param res - The API response containing updated notification data
   *
   * @example
   * ```typescript
   * deleteNotification_success(response: NotificationResponse): void {
   *   this.updateNotificationsAfterDelete(response);
   * }
   * ```
   */
  deleteNotification_success(res: NotificationData[] | { notifications: NotificationData[] }): void;

  /**
   * Update the notification list after deleting a notification.
   *
   * Removes the deleted notification from the local list, recalculates
   * the unread count, and triggers change detection. Called by
   * deleteNotification_success().
   *
   * @param res - The API response containing updated notification data
   *
   * @example
   * ```typescript
   * updateNotificationsAfterDelete(response: NotificationResponse): void {
   *   this.notificationList = response.notifications;
   *   this.calculateUnReadNotificationsCount();
   * }
   * ```
   */
  updateNotificationsAfterDelete(res: NotificationData[] | { notifications: NotificationData[] }): void;

  /**
   * Handle refresh button click event.
   *
   * Triggered when the user clicks the refresh button in the notification panel
   * (if refreshMode is true). Fetches fresh notification data from the API,
   * bypassing the cache.
   *
   * @example
   * ```typescript
   * btnRefreshNotifications_clickHandler(): void {
   *   this.getAllNotifications(false, true);
   * }
   * ```
   */
  btnRefreshNotifications_clickHandler(): void;

  /**
   * Emit an action event for a notification.
   *
   * Triggered when the user clicks on a notification or its action button.
   * Emits an action event through the notification service that can be
   * handled by parent components or services.
   *
   * @param notification - The notification that was acted upon
   *
   * @example
   * ```typescript
   * emitOnAction(notification: NotificationData): void {
   *   this.notificationService.onActionNotification.next({
   *     action: 'click',
   *     notification: notification,
   *     timestamp: Date.now()
   *   });
   * }
   * ```
   */
  emitOnAction(notification: NotificationData): void;

  /**
   * Handle delete button click event for a specific notification.
   *
   * Triggered when the user clicks the delete button on a notification item.
   * Calls deleteNotification() to remove the notification from the system.
   *
   * @param notification - The notification to delete
   *
   * @example
   * ```typescript
   * btnDeleteNotification_clickHandler(notification: NotificationData): void {
   *   if (confirm('Delete this notification?')) {
   *     this.deleteNotification(notification.id);
   *   }
   * }
   * ```
   */
  btnDeleteNotification_clickHandler(notification: NotificationData): void;

  /**
   * Toggle the visibility of the notification panel.
   *
   * Opens or closes the notification dropdown/panel when the user interacts
   * with the notification icon. Handles mouse events (click, hover) and
   * optionally enables scrolling for the notification list.
   *
   * @param event - The browser event (click, mouseover, mouseout, etc.)
   * @param scrolling - Whether to enable scrolling in the notification panel (default: false)
   *
   * @example
   * ```typescript
   * // On icon click
   * toggleNotification(clickEvent, false);
   *
   * // On icon hover with scrolling
   * toggleNotification(hoverEvent, true);
   * ```
   */
  toggleNotification(event: Event, scrolling?: boolean): void;
}

/**
 * Properties for custom notification item components.
 *
 * When using axisIncludeComponent to provide a custom notification template,
 * the custom component should implement this interface to receive the necessary
 * data and callbacks.
 *
 * @example
 * ```typescript
 * @Component({
 *   selector: 'custom-notification-item',
 *   template: `
 *     <div class="notification-item" (click)="onNotificationClick()">
 *       <h4>{{ notification.title }}</h4>
 *       <p>{{ notification.message }}</p>
 *       <button (click)="onDeleteClick($event)">Delete</button>
 *     </div>
 *   `
 * })
 * export class CustomNotificationItemComponent implements CustomNotificationItemProps {
 *   @Input() notification!: NotificationData;
 *   @Input() onDelete?: (notification: NotificationData) => void;
 *   @Input() onAction?: (notification: NotificationData) => void;
 *
 *   onNotificationClick(): void {
 *     if (this.onAction) {
 *       this.onAction(this.notification);
 *     }
 *   }
 *
 *   onDeleteClick(event: Event): void {
 *     event.stopPropagation();
 *     if (this.onDelete) {
 *       this.onDelete(this.notification);
 *     }
 *   }
 * }
 * ```
 */
export interface CustomNotificationItemProps {
  /**
   * The notification data object to display.
   *
   * Contains all information about the notification including message,
   * type, timestamp, and metadata.
   */
  notification: NotificationData;

  /**
   * Optional callback function to handle notification deletion.
   *
   * Called when the user wants to delete this notification.
   * The parent component handles the actual API call.
   *
   * @param notification - The notification being deleted
   */
  onDelete?: (notification: NotificationData) => void;

  /**
   * Optional callback function to handle notification action/click.
   *
   * Called when the user clicks on the notification or its action button.
   * The parent component handles navigation or other actions.
   *
   * @param notification - The notification being acted upon
   */
  onAction?: (notification: NotificationData) => void;

  /**
   * Optional callback function to handle marking as read.
   *
   * Called when the notification should be marked as read.
   * The parent component handles the API call.
   *
   * @param notification - The notification being marked as read
   */
  onMarkAsRead?: (notification: NotificationData) => void;

  /**
   * Optional index of this notification in the list.
   *
   * Useful for styling alternating rows or other index-based logic.
   */
  index?: number;
}
