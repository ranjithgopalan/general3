/**
 * @file Layout Types
 * @description Type definitions for UI layout configuration in Axis UI Generator
 * @module types/layout
 */

/**
 * Available layout types for the UI structure
 * @typedef {('blank' | 'basic' | 'sidebar-left')} LayoutType
 */
export type LayoutType = 'blank' | 'basic' | 'sidebar-left';

/**
 * Layout size classes for responsive column widths
 * Maps to Axis CSS grid classes (axis-col-*)
 * @typedef {('a'|'b'|'c'|'d'|'e'|'f'|'g'|'h'|'i'|'j'|'k'|'l'|'m'|'n'|'o'|'p'|'q'|'z')} LayoutSizeClass
 */
export type LayoutSizeClass =
  | 'a'  // axis-col-sm-12 (full width)
  | 'b'  // axis-col-sm-6 (half width)
  | 'c'  // axis-col-sm-4 (third width)
  | 'd'  // axis-col-sm-3 (quarter width)
  | 'e'  // axis-col-sm-2
  | 'f'  // axis-col
  | 'g'  // axis-col-auto
  | 'h'  // axis-col-sm-6 axis-col-md-4 axis-col-lg-3 (responsive)
  | 'i'  // axis-col-sm-11
  | 'j'  // axis-col-sm-10
  | 'k'  // axis-col-sm-9
  | 'l'  // axis-col-sm-8
  | 'm'  // axis-col-sm-7
  | 'n'  // axis-col-sm-5
  | 'o'  // axis-col-sm-1
  | 'p'  // axis-col-sm-12 hidden
  | 'q'  // axis-col-xl
  | 'z'; // no class

/**
 * Layout configuration interface for the UI structure
 * Generic type TSections allows TypeScript to validate slot arrays against section keys
 *
 * @interface UILayout
 * @template TSections - Record of section definitions, defaults to Record<string, any>
 *
 * @example
 * ```typescript
 * const layout: UILayout = {
 *   type: 'blank',
 *   slots: {
 *     main: ['headerSection', 'contentSection'],
 *     sidebar: ['menuSection']
 *   }
 * };
 * ```
 */
export interface UILayout<TSections extends Record<string, unknown> = Record<string, unknown>> {
  /**
   * Type of layout to use
   * - 'blank': No predefined layout structure
   * - 'basic': Basic page layout
   * - 'sidebar-left': Layout with left sidebar
   *
   * @type {LayoutType}
   */
  type: LayoutType;

  /**
   * Named slots that contain arrays of section names
   * Keys are slot names (e.g., 'main', 'sidebar', 'header')
   * Values are arrays of section names that TypeScript validates against TSections keys
   *
   * @type {Object.<string, Array<keyof TSections>>}
   * @description Enforces valid section references - TypeScript will error on invalid section names
   */
  slots: {
    [slotName: string]: (keyof TSections)[]; // Array of section names - enforces valid section references
  };
}
