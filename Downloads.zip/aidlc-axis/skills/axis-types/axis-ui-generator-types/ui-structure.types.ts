/**
 * UI Structure Types
 * Main interface for the complete UI structure configuration
 */

import type { UILayout } from './layout.types';
import type { UIControl } from './controls';

/**
 * Section definition - typically a container or form
 */
export type UISection = UIControl;

/**
 * Main UI Structure interface
 * This is the root configuration object for Axis UI Generator
 *
 * Generic type TSections allows TypeScript to:
 * - Autocomplete section names in sectionsOrder array
 * - Validate that all sections in sectionsOrder exist in sections object
 * - Provide type-safe access to sections
 *
 * @example
 * ```typescript
 * const structure: UIStructure = {
 *   sections: {
 *     header: { type: 'container', name: 'header', fields: [] },
 *     content: { type: 'form', name: 'mainForm', data: { fields: [] } }
 *   },
 *   sectionsOrder: ['header', 'content'], // TypeScript validates these!
 *   layout: { type: 'blank', slots: { main: ['header', 'content'] } }
 * };
 * ```
 */
export interface UIStructure<TSections extends Record<string, UISection> = Record<string, UISection>> {
  /**
   * Unique identifier for this AUG instance
   * Generated automatically if not provided
   */
  id?: string;

  /**
   * Section definitions mapped by name
   * Keys will be used to type-check sectionsOrder
   */
  sections: TSections;

  /**
   * Ordered list of section names to render
   * TypeScript will autocomplete with keys from sections object
   */
  sectionsOrder: (keyof TSections)[];

  /**
   * Layout configuration
   * Slot arrays can also be type-checked against section keys
   */
  layout: UILayout<TSections>;

  /**
   * Debounce time (in milliseconds) for update events
   * @default 1
   */
  timeToEmitUpdate?: number;

  /**
   * Whether to emit update event after initial load
   * @default true
   */
  emitUpdateAfterLoad?: boolean;

  /**
   * Container reference (set automatically by AUG)
   * Angular ViewContainerRef for dynamic component creation
   */
  containerRef?: unknown;
}
