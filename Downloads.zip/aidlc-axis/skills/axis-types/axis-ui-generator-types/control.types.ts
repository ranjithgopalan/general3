/**
 * @file Control Types
 * @description Enumeration of all available UI control/component types in Axis UI Generator
 * @module types/control
 */

/**
 * All available control/component types in AUG (Axis UI Generator)
 *
 * This union type includes 78+ control types organized into categories:
 * - Core controls (section, container, card, etc.)
 * - Form controls (text, dropdown, checkbox, etc.)
 * - UI components (button, accordion, modal, etc.)
 * - Chart components (progressTracker, dataGrid, etc.)
 *
 * @typedef {string} ControlType
 *
 * @example
 * ```typescript
 * const controlType: ControlType = 'text';
 * const buttonType: ControlType = 'button';
 * const chartType: ControlType = 'dataGrid';
 * ```
 */
export type ControlType =
  // ============================================================================
  // Core Controls
  // ============================================================================
  /** Section container - top-level grouping */
  | 'section'
  /** Generic container for grouping controls */
  | 'container'
  /** @deprecated Use 'container' instead */
  | 'formGroup'
  /** Card wrapper component */
  | 'card'
  /** @deprecated Use 'card' instead */
  | 'cardGroup'
  /** Modal dialog container */
  | 'modalContainer'
  /** Static content display (text, HTML) */
  | 'content'
  /** Form label component */
  | 'formLabel'
  /** Custom component placeholder */
  | 'custom'

  // ============================================================================
  // Form Controls
  // ============================================================================
  /** Reactive form container */
  | 'form'
  /** Text input field */
  | 'text'
  /** Multi-line text area */
  | 'textarea'
  /** Dropdown/select control */
  | 'dropdown'
  /** Single checkbox */
  | 'checkbox'
  /** Group of checkboxes */
  | 'checkboxGroup'
  /** Radio button group */
  | 'radio'
  /** Toggle switch */
  | 'toggle'
  /** Range slider */
  | 'slider'
  /** Date picker */
  | 'datepicker'
  /** Date range picker */
  | 'daterange'
  /** Time picker */
  | 'timepicker'
  /** Date of birth picker */
  | 'dob'
  /** Star rating control */
  | 'rating'
  /** File upload control */
  | 'fileupload'
  /** CAPTCHA component */
  | 'captcha'
  /** Combo box (searchable dropdown) */
  | 'combobox'
  /** Type-ahead search input */
  | 'typeahead'
  /** Countdown timer */
  | 'countdown'

  // ============================================================================
  // UI Components
  // ============================================================================
  /** Button component */
  | 'button'
  /** Group of buttons */
  | 'buttonGroup'
  /** Row of buttons */
  | 'buttonRow'
  /** Wrapper for button groups */
  | 'buttonWrapper'
  /** Accordion/collapsible panel */
  | 'accordion'
  /** Alert/notification message */
  | 'alert'
  /** Tab navigation */
  | 'tab'
  /** Modal dialog */
  | 'modal'
  /** Navigation bar */
  | 'navbar'
  /** Breadcrumb navigation */
  | 'breadcrumb'
  /** Bottom sheet slide-up panel */
  | 'bottomSheet'
  /** Carousel/slider */
  | 'carousel'
  /** Calendar component */
  | 'calendar'
  /** Menu component */
  | 'menu'
  /** List component */
  | 'list'
  /** Styled list with icons */
  | 'styledList'
  /** Chip/tag list */
  | 'chipList'
  /** Dual list box (transfer list) */
  | 'dualList'
  /** Tree view */
  | 'tree'
  /** Pagination control */
  | 'paginator'
  /** Progress bar */
  | 'progressBar'
  /** Step progress indicator */
  | 'progressStep'
  /** Scrollable container */
  | 'scrollContainer'
  /** Icon component */
  | 'icon'
  /** Media player */
  | 'media'
  /** Timer component */
  | 'timer'
  /** Tooltip */
  | 'tooltip'
  /** Text truncation with expand */
  | 'truncate'
  /** Air Quality Index display */
  | 'aqi'
  /** Sidebar navigation */
  | 'sidebar'

  // ============================================================================
  // Chart Components (Dynamically Registered)
  // ============================================================================
  /** Progress tracker chart */
  | 'progressTracker'
  /** Data grid/table */
  | 'dataGrid'
  /** Rich text editor */
  | 'editor';
