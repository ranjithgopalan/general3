/**
 * @file AUG Instance Types
 * @description Type definitions for Axis UI Generator instance objects
 * @module types/aug-instance
 */

import type { FormGroup } from '@angular/forms';
import type { ComponentRef } from '@angular/core';
import type { Subscription } from 'rxjs';
import type { UIStructure } from './ui-structure.types';
import type { UIData, ComponentStatus } from './ui-data.types';
import type { UIControl } from './controls';
import type { AUGHelper } from './helper.types';

/**
 * AUG Instance interface
 *
 * Represents an Axis UI Generator instance with its internal state and references.
 * This is the main object that manages a dynamically generated UI structure.
 *
 * @interface AUGInstance
 *
 * @example
 * ```typescript
 * const augInstance: AUGInstance = {
 *   id: 'myForm_123',
 *   uiStructure: myUIStructure,
 *   uiData: myUIData,
 *   tree: flattenedTree,
 *   formGroups: new Map()
 * };
 * ```
 */
export interface AUGInstance {
  /**
   * Unique identifier for this AUG instance
   * Auto-generated if not provided
   *
   * @type {string}
   * @example 'userForm_abc123', 'dashboard_xyz789'
   */
  id: string;

  /**
   * The UI structure configuration
   * Defines the layout, sections, and controls
   *
   * @type {UIStructure}
   * @see UIStructure
   */
  uiStructure: UIStructure;

  /**
   * The UI data object
   * Contains actual field values
   *
   * @type {UIData}
   * @see UIData
   */
  uiData: UIData;

  /**
   * Flattened tree structure of controls
   * Internal representation for efficient lookups
   *
   * @type {Object.<string, UIControl>}
   */
  tree?: Record<string, UIControl>;

  /**
   * Angular FormGroup instances
   * Maps form names to FormGroup objects
   *
   * @type {Map<string, FormGroup>}
   */
  formGroups?: Map<string, FormGroup>;

  /**
   * Component references
   * Maps control names to Angular ComponentRef objects
   *
   * @type {Map<string, ComponentRef<unknown>>}
   */
  componentRefs?: Map<string, ComponentRef<unknown>>;

  /**
   * Helper functions for this instance
   * Provides programmatic access to AUG operations
   *
   * @type {AUGHelper}
   */
  helper?: AUGHelper;

  /**
   * Instance configuration options
   * Runtime settings and flags
   *
   * @type {Object}
   */
  config?: {
    /**
     * Debounce time for update events
     * @type {number}
     */
    timeToEmitUpdate?: number;

    /**
     * Whether to emit update after initial load
     * @type {boolean}
     */
    emitUpdateAfterLoad?: boolean;

    /**
     * Custom configuration properties
     * @type {unknown}
     */
    [key: string]: unknown;
  };

  /**
   * Event subscriptions
   * Tracks active event listeners for cleanup
   *
   * @type {Subscription[]}
   */
  subscriptions?: Subscription[];

  /**
   * Status tracking for controls
   * Maps control names to their current status (display, disable, class)
   *
   * @type {Record<string, ComponentStatus>}
   */
  controlStatus?: Record<string, ComponentStatus>;

  /**
   * Additional instance properties
   * Allows framework-specific extensions
   *
   * @type {unknown}
   */
  [key: string]: unknown;
}

/**
 * Reference to an AUG instance
 * Can be either the full instance object or just the instance ID string
 *
 * @typedef {AUGInstance | string} AUGInstanceRef
 *
 * @example
 * ```typescript
 * // Full instance
 * const ref1: AUGInstanceRef = augInstance;
 *
 * // Just the ID
 * const ref2: AUGInstanceRef = 'myForm_123';
 * ```
 */
export type AUGInstanceRef = AUGInstance | string;
