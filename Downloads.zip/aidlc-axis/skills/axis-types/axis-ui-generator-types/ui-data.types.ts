/**
 * @file UI Data Types
 * @description Type definitions for data management and component status tracking
 * @module types/ui-data
 */

/**
 * UI Data object containing actual field values
 *
 * Stores the data for all form controls in the UI structure.
 * Keys are field names (matching control 'name' properties),
 * values are the current data for those fields.
 *
 * Generic type TData allows specifying a typed data schema for type-safe field access.
 *
 * @interface UIData
 * @template TData - Optional typed data schema, defaults to Record<string, any>
 *
 * @example
 * ```typescript
 * // Without generic - flexible but untyped
 * const uiData: UIData = {
 *   firstName: 'John',
 *   lastName: 'Doe',
 *   email: 'john.doe@example.com',
 *   country: 'us'
 * };
 *
 * // With generic - type-safe field access
 * interface UserFormData {
 *   firstName: string;
 *   lastName: string;
 *   email: string;
 *   country: string;
 *   age?: number;
 * }
 *
 * const typedData: UIData<UserFormData> = {
 *   firstName: 'John',     // ✅ TypeScript validates
 *   lastName: 'Doe',       // ✅ TypeScript validates
 *   email: 'john@...com',  // ✅ TypeScript validates
 *   country: 'us',         // ✅ TypeScript validates
 *   age: 30                // ✅ Optional field
 *   // invalidField: 'x'   // ❌ TypeScript error!
 * };
 *
 * // Access with autocomplete
 * const name = typedData.firstName; // ✨ Autocompletes!
 * ```
 */
export type UIData<TData = Record<string, unknown>> = TData & {
  /**
   * Field data indexed by field name
   * Keys match the 'name' property of controls in UIStructure
   * Values can be any type (string, number, boolean, object, array, etc.)
   *
   * When using the generic TData parameter, known fields are typed.
   * Additional fields can still be added via this index signature.
   */
  [fieldName: string]: unknown;
};

/**
 * Component status tracking for conditional logic
 *
 * Tracks the display, disable, and class state of a component
 * based on conditional logic evaluation.
 *
 * @interface ComponentStatus
 *
 * @example
 * ```typescript
 * const status: ComponentStatus = {
 *   display: true,  // Component is visible
 *   disable: false, // Component is enabled
 *   class: true     // Component has active class
 * };
 * ```
 */
export interface ComponentStatus {
  /**
   * Whether the component should be displayed
   * Controlled by displayIf conditional logic
   *
   * @type {boolean}
   * @default true
   */
  display: boolean;

  /**
   * Whether the component should be disabled
   * Controlled by disableIf conditional logic
   *
   * @type {boolean}
   * @default false
   */
  disable: boolean;

  /**
   * Whether the component has active/special class
   * Controlled by dynamicClass conditional logic
   *
   * @type {boolean}
   * @default false
   */
  class: boolean;
}
