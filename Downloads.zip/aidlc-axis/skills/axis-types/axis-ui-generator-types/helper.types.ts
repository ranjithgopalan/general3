/**
 * @file Helper Types
 * @description Type definitions for AUG helper functions and operations
 * @module types/helper
 */

import type { ComponentRef } from '@angular/core';
import type { AbstractControlOptions } from '@angular/forms';
import type { UIStructure } from './ui-structure.types';
import type { UIData } from './ui-data.types';
import type { UIControl } from './controls';
import type { AUGInstance } from './aug-instance.types';

/**
 * Result of findElement operation
 *
 * Contains information about a found element and its position in the UI tree.
 *
 * @interface FindElementResult
 *
 * @example
 * ```typescript
 * const result: FindElementResult = {
 *   parent: parentControl,
 *   siblings: [control1, control2, control3],
 *   field: foundControl,
 *   index: 1
 * };
 * ```
 */
export interface FindElementResult {
  /**
   * Parent element containing the found element
   *
   * @type {UIControl}
   */
  parent: UIControl;

  /**
   * Array of sibling elements
   * All controls at the same level as the found element
   *
   * @type {UIControl[]}
   */
  siblings: UIControl[];

  /**
   * The found element itself
   *
   * @type {UIControl}
   */
  field: UIControl;

  /**
   * Index of the element within siblings array
   * Position of the found element among its siblings
   *
   * @type {number}
   * @example 0 // First element
   * @example 2 // Third element
   */
  index: number;
}

/**
 * Result of addElement operation
 *
 * Contains the Angular ComponentRef for a dynamically created element.
 *
 * @interface AddElementResult
 *
 * @example
 * ```typescript
 * const result: AddElementResult = {
 *   componentRef: componentRef
 * };
 * ```
 */
export interface AddElementResult {
  /**
   * Angular ComponentRef created for the element
   * Reference to the dynamically created Angular component
   *
   * @type {ComponentRef<unknown>}
   * @description ComponentRef from @angular/core
   */
  componentRef: ComponentRef<unknown>;
}

/**
 * Translation argument for complex translation scenarios
 *
 * Used for translating arrays of objects or complex nested structures.
 *
 * @interface TranslationArg
 *
 * @example
 * ```typescript
 * const translationArg: TranslationArg = {
 *   keyName: ['label', 'description'],
 *   payload: [
 *     { label: 'user.name', description: 'user.desc' },
 *     { label: 'user.email', description: 'user.emailDesc' }
 *   ]
 * };
 * ```
 */
export interface TranslationArg {
  /**
   * Array of property names to translate
   * Specifies which properties in the payload objects should be translated
   *
   * @type {string[]}
   * @example ['label', 'description', 'tooltip']
   */
  keyName: string[];

  /**
   * Payload to translate
   * Can be array of objects or single object with nested translations
   *
   * @type {unknown[] | Record<string, unknown>}
   * @example [{ label: 'key1' }, { label: 'key2' }]
   * @example { title: 'key1', items: [{ name: 'key2' }] }
   */
  payload: unknown[] | Record<string, unknown>;
}

/**
 * Helper function reference returned by AUG
 *
 * Provides programmatic access to AUG operations for dynamic UI manipulation.
 * These functions allow runtime modification of the UI structure, data, and behavior.
 *
 * @interface AUGHelper
 *
 * @example
 * ```typescript
 * // Access via AUG instance
 * augInstance.helper.addElement({ ... });
 * augInstance.helper.setData('firstName', 'John');
 * ```
 */
export interface AUGHelper {
  /**
   * Add a new element to the UI at runtime
   *
   * Dynamically creates and inserts a new control into the UI structure.
   *
   * @param {AddElementConfig} config - Configuration for element to add
   * @returns {AddElementResult | Promise<AddElementResult>} Component reference (sync) or Promise of component reference (async)
   *
   * @example
   * ```typescript
   * helper.addElement({
   *   referenceElementName: 'email',
   *   sectionName: 'userInfo',
   *   AUGinstance: 'myForm',
   *   addBefore: false,
   *   newElement: { type: 'text', name: 'phone', label: 'Phone' }
   * });
   * ```
   */
  addElement: (config: AddElementConfig) => AddElementResult | Promise<AddElementResult>;

  /**
   * Delete an element from the UI at runtime
   *
   * Removes a control from the UI structure and optionally its children.
   *
   * @param {AUGInstance} AUG - AUG instance containing the element
   * @param {string} AUGinstance - Instance identifier
   * @param {string} elementName - Name of element to delete
   * @param {boolean} [deleteChildren] - Whether to delete child elements
   * @param {boolean} [clearUiStructure] - Whether to clear from uiStructure
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.deleteElement(augInstance, 'myForm', 'phoneNumber', true, true);
   * ```
   */
  deleteElement: (AUG: AUGInstance, AUGinstance: string, elementName: string, deleteChildren?: boolean, clearUiStructure?: boolean) => void;

  /**
   * Trigger change detection on one or all elements
   *
   * Forces Angular to re-render the specified element or all elements.
   *
   * @param {RefreshElementConfig} [config] - Element to refresh (omit to refresh all)
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.refreshElement({ elementName: 'email', AUGinstance: 'myForm' });
   * ```
   */
  refreshElement: (config?: RefreshElementConfig) => void;

  /**
   * Recreate an element (delete and re-add)
   *
   * Destroys and recreates an element to reset its state.
   *
   * @param {RecreateElementConfig} config - Element to recreate
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.recreateElement({
   *   AUGinstance: 'myForm',
   *   elementName: 'email',
   *   sectionName: 'userInfo'
   * });
   * ```
   */
  recreateElement: (config: RecreateElementConfig) => void;

  /**
   * Clear and recreate entire AUG
   *
   * Destroys and rebuilds the entire UI from scratch.
   * Useful for resetting to initial state or applying major structural changes.
   *
   * @param {Object} [props] - Refresh options
   * @param {string} [props.scrollTo] - Element name to scroll to after refresh
   * @param {number} [props.offset] - Scroll offset in pixels
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.refreshClear({ scrollTo: 'firstName', offset: 100 });
   * ```
   */
  refreshClear: (props?: { scrollTo?: string; offset?: number }) => void;

  /**
   * Set data value for a form control
   *
   * Updates the value of a specific form control and triggers validation.
   *
   * @param {string} controlName - Name of the control to update
   * @param {unknown} data - New value to set (type depends on control type)
   * @param {string | null} [AUGinstance] - Instance identifier (optional)
   * @param {string | null} [formName] - Form name if control is in a nested form
   * @param {AbstractControlOptions} [setValueOptions] - Angular FormControl setValue options
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.setData('email', 'john@example.com', 'myForm');
   * helper.setData('age', 30, 'myForm', null, { emitEvent: false });
   * ```
   */
  setData: (controlName: string, data: unknown, AUGinstance?: string | null, formName?: string | null, setValueOptions?: AbstractControlOptions) => void;

  /**
   * Set a property on an element
   *
   * Updates any property of a control in the UI structure.
   *
   * @param {string} property - Property name to update
   * @param {unknown} value - New value for the property
   * @param {string} elementName - Name of element to update
   * @param {string} [AUGinstance] - Instance identifier (optional)
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.setProperty('label', 'Email Address', 'email', 'myForm');
   * helper.setProperty('disabled', true, 'submitButton', 'myForm');
   * ```
   */
  setProperty: (property: string, value: unknown, elementName: string, AUGinstance?: string) => void;

  /**
   * Trigger statusChanges for all form controls
   *
   * Forces validation to run on all controls in the form.
   *
   * @param {Object} [config] - Update configuration
   * @param {string} [config.AUGinstance] - Instance to update (omit for all)
   * @param {string} [config.parentForm] - Specific form to update (omit for all forms)
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.updateAllFields({ AUGinstance: 'myForm', parentForm: 'userForm' });
   * ```
   */
  updateAllFields: (config?: { AUGinstance?: string; parentForm?: string }) => void;

  /**
   * Re-evaluate conditional logic for all affected fields
   *
   * Checks displayIf, disableIf, or requireIf conditions and updates affected controls.
   *
   * @param {Object} config - Conditional update configuration
   * @param {Object} config.source - Source field that triggered the update
   * @param {string} config.source.name - Name of source field
   * @param {string} config.source.AUGinstance - Instance identifier
   * @param {'displayIf' | 'disableIf' | 'requireIf'} config.event - Type of condition to re-evaluate
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.updateFieldsConditionally({
   *   source: { name: 'country', AUGinstance: 'myForm' },
   *   event: 'displayIf'
   * });
   * ```
   */
  updateFieldsConditionally: (config: { source: { name: string; AUGinstance: string }; event: 'displayIf' | 'disableIf' | 'requireIf' }) => void;

  /**
   * Create flat data model from uiStructure
   *
   * Initializes all field values to null or provided values.
   * Traverses the UI structure and creates a flat key-value object.
   *
   * @param {UIStructure} uiStructure - UI structure to extract fields from
   * @param {UIData} [uiData] - Optional existing data to merge
   * @returns {UIData} Flat data model with all fields
   *
   * @example
   * ```typescript
   * const flatData = helper.createFlatModels(uiStructure, { email: 'john@example.com' });
   * // Result: { firstName: null, lastName: null, email: 'john@example.com', ... }
   * ```
   */
  createFlatModels: (uiStructure: UIStructure, uiData?: UIData) => UIData;

  /**
   * Delete AUG instance and clean up resources
   *
   * Destroys the AUG instance, removes event listeners, and cleans up memory.
   *
   * @param {AUGInstance} AUG - AUG instance to delete
   * @param {string} AUGinstance - Instance identifier
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.deleteAugInstance(augInstance, 'myForm');
   * ```
   */
  deleteAugInstance: (AUG: AUGInstance, AUGinstance: string) => void;

  /**
   * Check and trigger all interactions for all or specific field
   *
   * Manually triggers event handlers and conditional logic evaluation.
   *
   * @param {AUGInstance} AUG - AUG instance to check
   * @param {string} [fieldName] - Specific field name (omit to check all fields)
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.checkAllInteractions(augInstance, 'email');
   * helper.checkAllInteractions(augInstance); // Check all fields
   * ```
   */
  checkAllInteractions: (AUG: AUGInstance, fieldName?: string) => void;

  /**
   * Emit interaction event for a field
   *
   * Broadcasts a custom interaction event for a specific control.
   *
   * @param {Object} payload - Event payload
   * @param {string} payload.name - Field name
   * @param {UIControl} payload.uiStructure - Control configuration
   * @param {Event | unknown} [e] - Optional event object
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.emitInteraction({ name: 'email', uiStructure: emailControl }, event);
   * ```
   */
  emitInteraction: (payload: { name: string; uiStructure: UIControl }, e?: Event | unknown) => void;

  /**
   * Trigger change detection on one or all components
   *
   * Manually marks components for Angular change detection.
   *
   * @param {string | string[] | null} [fieldName] - Field name(s) to mark (omit for all)
   * @param {string | null} [AUGinstance] - Instance identifier (optional)
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.markForCheck('email', 'myForm');
   * helper.markForCheck(['email', 'password'], 'myForm');
   * helper.markForCheck(); // Mark all
   * ```
   */
  markForCheck: (fieldName?: string | string[] | null, AUGinstance?: string | null) => void;

  /**
   * Navigate to a route or URL
   *
   * Uses Angular Router to navigate to a different route.
   *
   * @param {string | unknown} payload - Route path string or navigation object
   * @param {unknown} [options] - Angular Router navigation options
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.navigate('/dashboard');
   * helper.navigate({ path: '/user/123', queryParams: { tab: 'profile' } });
   * ```
   */
  navigate: (payload: string | unknown, options?: unknown) => void;

  /**
   * Translate text or object using dictionary
   *
   * Looks up translation keys in the language dictionary.
   *
   * @param {string | TranslationArg} arg - Translation key or complex translation config
   * @returns {string | unknown} Translated string or modified payload
   *
   * @example
   * ```typescript
   * const text = helper.translate('user.name'); // Returns: "User Name"
   * const obj = helper.translate({ keyName: ['label'], payload: { label: 'key1' } });
   * ```
   */
  translate: (arg: string | TranslationArg) => string | unknown;

  /**
   * Translate array of objects in place (modifies directly)
   *
   * Modifies the array by translating specified properties.
   * WARNING: This mutates the original array.
   *
   * @param {TranslationArg} arg - Translation configuration
   * @param {unknown[]} array - Array of objects to translate
   * @returns {void}
   *
   * @example
   * ```typescript
   * const items = [{ label: 'key1' }, { label: 'key2' }];
   * helper.translateArray({ keyName: ['label'], payload: items }, items);
   * // items array is now modified with translated labels
   * ```
   */
  translateArray: (arg: TranslationArg, array: unknown[]) => void;

  /**
   * Scroll to an element on the page
   *
   * Smoothly scrolls the viewport to the specified element.
   *
   * @param {string | HTMLElement | Element} element - Element name, HTMLElement, or Element
   * @param {number} [offset] - Scroll offset in pixels
   * @param {number} [duration] - Animation duration in milliseconds
   * @param {boolean} [smooth] - Whether to use smooth scrolling
   * @param {ScrollBehavior} [behavior] - Native scroll behavior ('auto' | 'smooth')
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.fnScrollToElem('email', 100, 500, true, 'smooth');
   * helper.fnScrollToElem(document.getElementById('myElement'));
   * ```
   */
  fnScrollToElem: (element: string | HTMLElement | Element, offset?: number, duration?: number, smooth?: boolean, behavior?: ScrollBehavior) => void;

  /**
   * Bypass normal emit update flow and emit immediately
   *
   * Used for non-form components like buttons, charts that need immediate updates.
   * Skips the debounce timer and emits the event right away.
   *
   * @param {UIStructure | UIControl} uiStructure - UI structure or control
   * @param {UIData} uiData - Current data state
   * @param {string} eventType - Type of event ('click', 'change', etc.)
   * @param {unknown} eventSource - Source component or element
   * @param {unknown} eventData - Event payload data
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.bypassEmitUpdate(control, uiData, 'click', button, { value: 'clicked' });
   * ```
   */
  bypassEmitUpdate: (uiStructure: UIStructure | UIControl, uiData: UIData, eventType: string, eventSource: unknown, eventData: unknown) => void;

  /**
   * Start or restart the AUG
   *
   * Initializes all services and renders the UI.
   * Call this after making structural changes to uiStructure.
   *
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.start();
   * ```
   */
  start: () => void;

  /**
   * Emit completion event after AUG finishes loading
   *
   * Signals that the UI has finished rendering and is ready for interaction.
   *
   * @param {unknown} [routeEvent] - Optional route event data
   * @returns {void}
   *
   * @example
   * ```typescript
   * helper.emitComplete();
   * helper.emitComplete({ route: '/dashboard' });
   * ```
   */
  emitComplete: (routeEvent?: unknown) => void;

  /**
   * Rebuild the tree structure from flat uiStructure
   *
   * Updates the internal tree representation after structural changes.
   * Call this after modifying uiStructure to update the tree cache.
   *
   * @returns {void}
   *
   * @example
   * ```typescript
   * augInstance.uiStructure.sections.newSection = { ... };
   * helper.reDoTree();
   * ```
   */
  reDoTree: () => void;

  /**
   * Find an element in the uiStructure tree
   *
   * Searches the UI tree for a specific element and returns its context.
   *
   * @param {string} elementName - Name of element to find
   * @param {AUGInstance} AUG - AUG instance to search
   * @returns {FindElementResult | null} Element info or null if not found
   *
   * @example
   * ```typescript
   * const result = helper.findElement('email', augInstance);
   * if (result) {
   *   console.log('Found at index:', result.index);
   *   console.log('Siblings:', result.siblings);
   * }
   * ```
   */
  findElement: (elementName: string, AUG: AUGInstance) => FindElementResult | null;
}

/**
 * Configuration for adding a new element to the UI
 *
 * Defines where and how to insert a new control into the existing UI structure.
 *
 * @interface AddElementConfig
 *
 * @example
 * ```typescript
 * const config: AddElementConfig = {
 *   referenceElementName: 'email',
 *   sectionName: 'userInfo',
 *   AUGinstance: 'myForm',
 *   addBefore: false,
 *   newElement: { type: 'text', name: 'phone', label: 'Phone Number' },
 *   emitNotification: true
 * };
 * ```
 */
export interface AddElementConfig {
  /**
   * Name of existing element to use as reference point
   * New element will be added before or after this element
   *
   * @type {string}
   * @example 'email', 'submitButton'
   */
  referenceElementName: string;

  /**
   * Name of section containing the reference element
   * Specifies which section to add the element to
   *
   * @type {string}
   * @example 'userInfo', 'contactSection'
   */
  sectionName: string;

  /**
   * AUG instance identifier
   *
   * @type {string}
   * @example 'myForm', 'dashboard'
   */
  AUGinstance: string;

  /**
   * Whether to add element before reference element
   * If false, adds after reference element
   *
   * @type {boolean}
   * @default false
   */
  addBefore?: boolean;

  /**
   * The new control configuration to add
   *
   * @type {UIControl}
   */
  newElement: UIControl;

  /**
   * Whether to emit notification after adding element
   * Triggers event listeners and UI updates
   *
   * @type {boolean}
   * @default true
   */
  emitNotification?: boolean;
}

/**
 * Configuration for refreshing an element
 *
 * Specifies which element to trigger change detection on.
 *
 * @interface RefreshElementConfig
 *
 * @example
 * ```typescript
 * const config: RefreshElementConfig = {
 *   elementName: 'email',
 *   AUGinstance: 'myForm'
 * };
 * ```
 */
export interface RefreshElementConfig {
  /**
   * Name of element to refresh
   *
   * @type {string}
   * @example 'email', 'submitButton'
   */
  elementName: string;

  /**
   * AUG instance identifier
   * Optional - uses current instance if not specified
   *
   * @type {string}
   * @example 'myForm', 'dashboard'
   */
  AUGinstance?: string;
}

/**
 * Configuration for recreating an element
 *
 * Defines which element to delete and re-add (useful for resetting state).
 *
 * @interface RecreateElementConfig
 *
 * @example
 * ```typescript
 * const config: RecreateElementConfig = {
 *   AUG: augInstance,
 *   AUGinstance: 'myForm',
 *   elementName: 'email',
 *   sectionName: 'userInfo',
 *   workOnCopy: true
 * };
 * ```
 */
export interface RecreateElementConfig {
  /**
   * AUG instance object
   * Optional - uses current instance if not specified
   *
   * @type {AUGInstance}
   */
  AUG?: AUGInstance;

  /**
   * AUG instance identifier
   *
   * @type {string}
   * @example 'myForm', 'dashboard'
   */
  AUGinstance: string;

  /**
   * Name of element to recreate
   *
   * @type {string}
   * @example 'email', 'phoneNumber'
   */
  elementName: string;

  /**
   * Name of section containing the element
   *
   * @type {string}
   * @example 'userInfo', 'contactSection'
   */
  sectionName: string;

  /**
   * Whether to work on a copy of uiStructure
   * If true, doesn't modify original structure
   *
   * @type {boolean}
   * @default false
   */
  workOnCopy?: boolean;
}
