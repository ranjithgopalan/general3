/**
 * @file Event Types
 * @description Type definitions for event handling and API interactions
 * @module types/event
 */

/**
 * Available event listener types
 *
 * Standard DOM event types that can be attached to controls.
 *
 * @typedef {string} EventListenerType
 */
export type EventListenerType =
  /** Mouse click event */
  | 'click'
  /** Mouse double-click event */
  | 'dblclick'
  /** Value change event (for form controls) */
  | 'change'
  /** Input event (fires on every keystroke) */
  | 'input'
  /** Focus event (when control receives focus) */
  | 'focus'
  /** Blur event (when control loses focus) */
  | 'blur'
  /** Key up event (when key is released) */
  | 'keyup'
  /** Key down event (when key is pressed) */
  | 'keydown'
  /** Key press event (deprecated, use keydown instead) */
  | 'keypress'
  /** Mouse enter event (when mouse enters element) */
  | 'mouseenter'
  /** Mouse leave event (when mouse leaves element) */
  | 'mouseleave'
  /** Form submit event */
  | 'submit';

/**
 * Available event handler types
 *
 * Defines what action to take when an event is triggered.
 *
 * @typedef {string} EventHandlerType
 */
export type EventHandlerType =
  /** Execute a custom JavaScript function */
  | 'custom'
  /** Submit a form */
  | 'submit'
  /** Make an HTTP request to fetch/send data */
  | 'contentRequest'
  /** Navigate to a different route */
  | 'route';

/**
 * Event configuration for controls
 *
 * Defines event listeners and their handlers for UI controls.
 * Multiple events can be attached to a single control.
 *
 * @interface UIEvent
 *
 * @example
 * ```typescript
 * const clickEvent: UIEvent = {
 *   eventlistener: 'click',
 *   type: 'contentRequest',
 *   contentRequest: {
 *     url: '/api/submit',
 *     method: 'POST',
 *     showLoading: true
 *   }
 * };
 *
 * const customEvent: UIEvent = {
 *   eventlistener: 'change',
 *   type: 'custom',
 *   customFunction: (event) => {
 *     console.log('Value changed:', event.target.value);
 *   }
 * };
 * ```
 */
export interface UIEvent {
  /**
   * Type of DOM event to listen for
   *
   * @type {EventListenerType}
   * @example 'click', 'change', 'submit'
   */
  eventlistener: EventListenerType;

  /**
   * Type of handler to execute when event fires
   *
   * @type {EventHandlerType}
   * @example 'custom', 'contentRequest', 'route'
   */
  type: EventHandlerType;

  /**
   * Custom function to execute (when type is 'custom')
   * Can be a function reference or string function name
   *
   * @type {Function | string}
   * @example
   * ```typescript
   * customFunction: (event) => { console.log('Clicked!', event); }
   * // OR
   * customFunction: 'myGlobalFunction'
   * ```
   */
  customFunction?: Function | string;

  /**
   * Content request configuration (when type is 'contentRequest')
   * Defines API call to make when event fires
   *
   * @type {ContentRequest}
   * @see ContentRequest
   */
  contentRequest?: ContentRequest;

  /**
   * Route path to navigate to (when type is 'route')
   *
   * @type {string}
   * @example '/dashboard', '/users/123', '/settings'
   */
  route?: string;

  /**
   * Additional custom properties
   * Allows extending with custom event data
   *
   * @type {unknown}
   */
  [key: string]: unknown;
}

/**
 * Content request configuration for API calls
 *
 * Defines HTTP requests to make when events are triggered or routes are accessed.
 * Supports caching, loading indicators, and confirmation dialogs.
 *
 * @interface ContentRequest
 *
 * @example
 * ```typescript
 * const request: ContentRequest = {
 *   url: '/api/users',
 *   method: 'GET',
 *   showLoading: true,
 *   cache: 'memory',
 *   hydrateCache: 300000 // 5 minutes
 * };
 *
 * const postRequest: ContentRequest = {
 *   url: '/api/save',
 *   method: 'POST',
 *   body: { name: 'John', email: 'john@example.com' },
 *   submitProtection: {
 *     confirmationPrompt: {
 *       confirmationTitle: 'Confirm Save',
 *       confirmationMessage: 'Save changes?',
 *       confirmationYes: 'Yes, Save',
 *       confirmationNo: 'Cancel'
 *     }
 *   }
 * };
 * ```
 */
export interface ContentRequest {
  /**
   * API endpoint URL
   *
   * @type {string}
   * @example '/api/users', 'https://api.example.com/data'
   */
  url: string;

  /**
   * HTTP method
   *
   * @type {('GET'|'POST'|'PUT'|'DELETE'|'PATCH')}
   */
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

  /**
   * Request body (for POST, PUT, PATCH)
   * Typically JSON object or FormData
   *
   * @type {unknown}
   * @example { name: 'John', email: 'john@example.com' }
   */
  body?: unknown;

  /**
   * Additional request options
   * Headers, credentials, etc.
   *
   * @type {unknown}
   * @example { headers: { 'Authorization': 'Bearer token123' } }
   */
  options?: unknown;

  /**
   * URL query parameters
   * Will be appended to URL as ?key=value
   *
   * @type {Object.<string, unknown>}
   * @example { page: 1, limit: 10, filter: 'active' }
   */
  queryParams?: Record<string, unknown>;

  /**
   * Whether to show loading indicator during request
   *
   * @type {boolean}
   * @default false
   */
  showLoading?: boolean;

  /**
   * Whether this is a preload request
   * Preload requests are made before the UI is displayed
   *
   * @type {boolean}
   * @default false
   */
  isPreloading?: boolean;

  /**
   * Cache strategy for response
   * - 'memory': Cache in browser memory (lost on refresh)
   * - 'localStorage': Cache in localStorage (persists across sessions)
   *
   * @type {('memory'|'localStorage')}
   */
  cache?: 'memory' | 'localStorage';

  /**
   * Whether to preload this request
   * If true, request is made during initialization
   *
   * @type {boolean}
   * @default false
   */
  preload?: boolean;

  /**
   * Cache time-to-live in milliseconds
   * How long cached response remains valid
   *
   * @type {number}
   * @example 300000 // 5 minutes
   * @example 3600000 // 1 hour
   */
  hydrateCache?: number;

  /**
   * Submit protection with confirmation dialog
   * Prevents accidental submissions by requiring user confirmation
   *
   * @type {SubmitProtection}
   * @see SubmitProtection
   */
  submitProtection?: SubmitProtection;
}

/**
 * Submit protection with confirmation prompt
 *
 * Displays a confirmation dialog before executing a request.
 * Useful for destructive actions (delete, submit, etc.)
 *
 * @interface SubmitProtection
 *
 * @example
 * ```typescript
 * const protection: SubmitProtection = {
 *   confirmationPrompt: {
 *     confirmationTitle: 'Delete User',
 *     confirmationMessage: 'Are you sure you want to delete this user? This action cannot be undone.',
 *     confirmationYes: 'Yes, Delete',
 *     confirmationNo: 'Cancel'
 *   }
 * };
 * ```
 */
export interface SubmitProtection {
  /**
   * Confirmation prompt configuration
   * If provided, shows a modal dialog before proceeding
   *
   * @type {Object}
   */
  confirmationPrompt?: {
    /**
     * Title text for confirmation dialog
     *
     * @type {string}
     * @example 'Confirm Delete', 'Save Changes?', 'Submit Form'
     */
    confirmationTitle?: string;

    /**
     * Message text explaining the action
     * Can include details about what will happen
     *
     * @type {string}
     * @example 'Are you sure you want to delete this item? This action cannot be undone.'
     */
    confirmationMessage?: string;

    /**
     * Text for confirmation/yes button
     *
     * @type {string}
     * @default 'Yes'
     * @example 'Delete', 'Save', 'Submit', 'Proceed'
     */
    confirmationYes?: string;

    /**
     * Text for cancel/no button
     *
     * @type {string}
     * @default 'No'
     * @example 'Cancel', 'Go Back', 'Discard'
     */
    confirmationNo?: string;

    /**
     * Whether this is a sub-prompt within another modal
     * Affects styling and z-index
     *
     * @type {boolean}
     * @default false
     */
    isSubPrompt?: boolean;
  };
}
