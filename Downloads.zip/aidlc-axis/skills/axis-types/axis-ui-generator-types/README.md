# Type Definitions

This directory contains all TypeScript type definitions for Axis UI Generator.

## Files

### Core Types

- **`layout.types.ts`** - Layout configuration
  - `LayoutType` - Layout variants (blank, basic, sidebar-left)
  - `LayoutSizeClass` - Column width classes (a, b, c, d, z)
  - `UILayout<TSections>` - Layout structure with section slots

- **`control.types.ts`** - Control type enum
  - `ControlType` - Union of 78+ control type strings

- **`base-control.types.ts`** - Common control properties
  - `BaseControl` - Base interface all controls extend

### Form & Validation

- **`validation.types.ts`** - Form validation
  - `UIValidators` - Validation rules (required, email, pattern, etc.)
  - `UIErrorMessages` - Custom error messages

### Interaction

- **`event.types.ts`** - Event handling
  - `EventListenerType` - Event types (click, change, etc.)
  - `EventHandlerType` - Handler types (custom, contentRequest, etc.)
  - `UIEvent` - Event configuration
  - `ContentRequest` - API call configuration
  - `SubmitProtection` - Form submission protection

- **`conditional.types.ts`** - Conditional logic
  - `ConditionalLogic` - Display/disable/require conditions

### UI Components

- **`menu.types.ts`** - Menu configuration
  - `MenuIcon` - Menu icon configuration

- **`controls/`** - Specific control types (see [controls/README.md](./controls/README.md))
  - Container controls
  - Input controls
  - Selection controls
  - Button controls
  - Interactive controls
  - Date controls
  - File controls
  - Chart controls

### Structure & Data

- **`ui-structure.types.ts`** - Main UI structure
  - `UISection` - Section definition (container or form)
  - `UIStructure<TSections>` - Complete UI configuration

- **`ui-data.types.ts`** - Data management
  - `UIData` - Field values object
  - `ComponentStatus` - Component state

### Routing

- **`route.types.ts`** - Routing configuration
  - `AUGRoute` - Single route definition
  - `AUGRoutes` - Route collection

### Helpers

- **`helper.types.ts`** - Helper method interfaces
  - `FindElementResult` - Result from findElement()
  - `AddElementResult` - Result from addElement()
  - `TranslationArg` - Translation parameters
  - `AUGHelper` - Complete helper interface
  - `AddElementConfig` - addElement() parameters
  - `RefreshElementConfig` - refreshElement() parameters
  - `RecreateElementConfig` - recreateElement() parameters

## Type Safety Improvements

This library is **fully strongly typed** with **zero `any` types** in the codebase:

- ✅ All `any` types replaced with proper TypeScript types (`unknown`, `FormGroup`, `ComponentRef`, etc.)
- ✅ Full IntelliSense support for all properties and methods
- ✅ Compile-time validation catches type errors before runtime
- ✅ Type inference throughout - minimal manual type annotations needed

**Key Type Replacements:**

| Before | After | Benefit |
|--------|-------|---------|
| `helper: any` | `helper: AUGHelper` | Full autocomplete for 30+ helper methods |
| `formGroups: Map<string, any>` | `formGroups: Map<string, FormGroup>` | Angular FormGroup type safety |
| `componentRefs: Map<string, any>` | `componentRefs: Map<string, ComponentRef<unknown>>` | Proper Angular component typing |
| `subscriptions: any[]` | `subscriptions: Subscription[]` | RxJS subscription management |
| `value: any` | `value: unknown` | Forces type checking before use |
| `[key: string]: any` | `[key: string]: unknown` | Safer index signatures |

**If You Need Dynamic Types:**

While we've eliminated `any`, you can still handle dynamic data safely:

```typescript
// Use 'unknown' and type guards
const dynamicData: unknown = fetchFromApi();

if (isUIStructure(dynamicData)) {
  // TypeScript knows this is UIStructure now
  const structure: UIStructure = dynamicData;
}

// Or use type assertion with caution
const structure = dynamicData as UIStructure;
```

For gradual migration or legacy code integration, see [Migration Guide](../../docs/MIGRATION.md#issue-need-to-disable-type-checking-temporarily).

## Usage

All types are re-exported from the main package:

```typescript
import {
  // Core types
  UIStructure,
  UIData,
  UILayout,

  // Control types
  UIControl,
  TextControl,
  DropdownControl,
  ButtonControl,

  // Validation
  UIValidators,

  // Events
  UIEvent,
  ContentRequest,

  // Conditional logic
  ConditionalLogic,

  // Helpers
  AUGHelper,
  FindElementResult
} from 'axis-ui-generator-types';
```

## Type Hierarchy

```
BaseControl (base properties)
  ├── ContainerControl
  ├── CardControl
  ├── FormControl
  ├── TextControl
  ├── DropdownControl
  ├── ButtonControl
  ├── DatepickerControl
  └── ... (78+ control types)

UISection
  ├── Container section
  └── Form section

UIStructure<TSections>
  ├── sections: Record<string, UISection>
  ├── sectionsOrder: (keyof TSections)[]
  └── layout: UILayout<TSections>
```

## Adding New Types

### Example: Adding a new control type

1. **Create the type file**
   ```typescript
   // types/controls/rating.types.ts
   import type { BaseControl } from '../base-control.types';

   export interface RatingControl extends BaseControl {
     type: 'rating';
     max?: number;
     icon?: string;
   }
   ```

2. **Export from controls/index.ts**
   ```typescript
   export * from './rating.types';
   // Add to UIControl union
   ```

3. **Update control.types.ts**
   ```typescript
   export type ControlType =
     | 'rating'  // Add new type
     | 'text'
     | 'dropdown'
     // ... other types
   ```

4. **Done!** The type is now available:
   ```typescript
   import { RatingControl } from 'axis-ui-generator-types';
   ```
