/**
 * @file Base Control Types
 * @description Common properties shared by all controls
 * @module types/base-control
 */

import type { ControlType } from './control.types';
import type { LayoutSizeClass } from './layout.types';
import type { UIValidators, UIErrorMessages } from './validation.types';
import type { UIEvent } from './event.types';
import type { ConditionalLogic } from './conditional.types';
import type { MenuIcon } from './menu.types';

/**
 * Base properties common to all controls
 *
 * Generic type TCustomProps allows specifying typed custom properties
 * for framework-specific or application-specific extensions.
 *
 * @interface BaseControl
 * @template TCustomProps - Optional typed custom properties, defaults to Record<string, any>
 *
 * @example
 * ```typescript
 * // Without generic - standard properties
 * const control: BaseControl = {
 *   type: 'text',
 *   name: 'email',
 *   label: 'Email Address'
 * };
 *
 * // With generic - type-safe custom properties
 * interface MyCustomProps {
 *   trackingId: string;
 *   analyticsEvent: string;
 *   customRenderer?: (value: unknown) => string;
 * }
 *
 * const typedControl: BaseControl<MyCustomProps> = {
 *   type: 'text',
 *   name: 'email',
 *   label: 'Email',
 *   trackingId: 'email-input-123',      // ✅ Typed!
 *   analyticsEvent: 'email-changed',    // ✅ Typed!
 *   customRenderer: (v) => v.toString() // ✅ Typed!
 *   // invalidProp: 'test'               // ❌ TypeScript error!
 * };
 * ```
 */
export interface BaseControl<TCustomProps extends Record<string, unknown> = Record<string, unknown>> {
  // ============================================================================
  // Required properties
  // ============================================================================

  /**
   * Type of control/component
   * Determines which component will be rendered
   *
   * @type {ControlType}
   * @example 'text', 'dropdown', 'button', 'form', etc.
   */
  type: ControlType;

  /**
   * Unique name/identifier for the control
   * Used as form control name and for data binding
   *
   * @type {string}
   * @example 'firstName', 'email', 'submitButton'
   */
  name: string;

  // ============================================================================
  // Display properties
  // ============================================================================

  /**
   * Label text displayed above or beside the control
   *
   * @type {string}
   * @example 'First Name', 'Email Address', 'Country'
   */
  label?: string;

  /**
   * Placeholder text shown when control is empty
   *
   * @type {string}
   * @example 'Enter your email', 'Select a country'
   */
  placeholder?: string;

  /**
   * Help text displayed below the control
   * Provides additional context or instructions
   *
   * @type {string}
   * @example 'Must be at least 8 characters', 'We\'ll never share your email'
   */
  helpText?: string;

  /**
   * Text prefix displayed before the input
   *
   * @type {string}
   * @example '$', 'https://', '+1'
   */
  prefix?: string;

  /**
   * Default or current value of the control
   *
   * @type {unknown}
   * @example 'John', 42, true, ['option1', 'option2']
   */
  value?: unknown;

  // ============================================================================
  // Layout & Styling
  // ============================================================================

  /**
   * Size class for responsive column width
   * Can be single class or pipe-separated for responsive: "a|b|c|d"
   *
   * @type {LayoutSizeClass | string}
   * @example 'b' // Half width
   * @example 'a|b|c' // Full on mobile, half on tablet, third on desktop
   */
  size?: LayoutSizeClass | string;

  /**
   * CSS class name(s) to apply to the control
   *
   * @type {string}
   * @example 'custom-input', 'highlighted-field'
   */
  className?: string;

  /**
   * CSS class name(s) to apply to the host/wrapper element
   *
   * @type {string}
   * @example 'custom-wrapper', 'field-container'
   */
  hostClassName?: string;

  /**
   * Dynamic CSS class that changes based on conditions
   *
   * @type {string}
   * @example 'active-field', 'error-state'
   */
  dynamicClass?: string;

  // ============================================================================
  // State properties
  // ============================================================================

  /**
   * Whether the field is required
   * Shows required indicator and triggers validation
   *
   * @type {boolean}
   * @default false
   */
  required?: boolean;

  /**
   * Whether the control is disabled
   * Disables user interaction
   *
   * @type {boolean}
   * @default false
   */
  disabled?: boolean;

  /**
   * Whether the control is view-only (read-only)
   * Displays value but prevents editing
   *
   * @type {boolean}
   * @default false
   */
  viewonly?: boolean;

  /**
   * Whether to reserve space for the control even when hidden
   * Prevents layout shift when control visibility changes
   *
   * @type {boolean}
   * @default false
   */
  reservedSpace?: boolean;

  /**
   * Whether to disable default CSS classes
   * Allows full custom styling
   *
   * @type {boolean}
   * @default false
   */
  noDefaultClasses?: boolean;

  // ============================================================================
  // Conditional logic
  // ============================================================================

  /**
   * Conditions that control whether the field is displayed
   * Field is shown only when all conditions are met
   *
   * @type {ConditionalLogic}
   * @see ConditionalLogic
   * @example { country: 'us' } // Show only if country is 'us'
   * @example { employed: true, age: [18, 19, 20] } // Multiple conditions
   */
  displayIf?: ConditionalLogic;

  /**
   * Conditions that control whether the field is disabled
   * Field is disabled when all conditions are met
   *
   * @type {ConditionalLogic}
   * @see ConditionalLogic
   * @example { userType: 'guest' } // Disable for guests
   */
  disableIf?: ConditionalLogic;

  /**
   * Conditions that control whether the field is required
   * Field becomes required when all conditions are met
   *
   * @type {ConditionalLogic}
   * @see ConditionalLogic
   * @example { employed: true } // Required if employed
   */
  requireIf?: ConditionalLogic;

  // ============================================================================
  // Validation
  // ============================================================================

  /**
   * Validation rules to apply to the control
   *
   * @type {UIValidators}
   * @see UIValidators
   * @example { required: true, email: true, maxLength: 100 }
   */
  validators?: UIValidators;

  /**
   * Custom error messages for validation failures
   *
   * @type {UIErrorMessages}
   * @see UIErrorMessages
   * @example { required: 'Email is required', email: 'Invalid email format' }
   */
  errorMessages?: UIErrorMessages;

  // ============================================================================
  // Events
  // ============================================================================

  /**
   * Event handlers attached to the control
   * Can handle click, change, focus, blur, etc.
   *
   * @type {Array<UIEvent>}
   * @see UIEvent
   * @example [{ eventlistener: 'click', type: 'contentRequest', contentRequest: {...} }]
   */
  events?: UIEvent[];

  // ============================================================================
  // Menus
  // ============================================================================

  /**
   * Menu items attached to the control label
   * Provides inline actions like help, info, etc.
   *
   * @type {Array<MenuIcon>}
   * @see MenuIcon
   * @example [{ icon: 'help', tooltip: 'Help documentation', event: 'showHelp' }]
   */
  labelMenu?: MenuIcon[];

  /**
   * Menu items attached to the field itself
   * Provides inline actions like edit, delete, etc.
   *
   * @type {Array<MenuIcon>}
   * @see MenuIcon
   * @example [{ icon: 'edit', tooltip: 'Edit field', event: 'editField' }]
   */
  fieldMenu?: MenuIcon[];

  // ============================================================================
  // Form integration (set automatically by AUG)
  // ============================================================================

  /**
   * AUG instance identifier (set automatically)
   * Links control to specific AUG instance
   *
   * @type {string}
   * @internal
   */
  AUGinstance?: string;

  /**
   * Parent form name (set automatically)
   * Links control to containing form
   *
   * @type {string}
   * @internal
   */
  parentForm?: string;

  /**
   * Parent group name (set automatically)
   * Links control to containing group/container
   *
   * @type {string}
   * @internal
   */
  parentGroup?: string;

  /**
   * Section name (set automatically)
   * Links control to containing section
   *
   * @type {string}
   * @internal
   */
  sectionName?: string;

  /**
   * Angular ComponentRef (set automatically)
   * Reference to the dynamically created component
   *
   * @type {unknown}
   * @internal
   */
  containerRef?: unknown;

  /**
   * Parent control name (set automatically)
   * Links control to parent in hierarchy
   *
   * @type {string}
   * @internal
   */
  parentName?: string;

  /**
   * Generated element ID (set automatically)
   * Unique DOM element identifier
   *
   * @type {string}
   * @internal
   */
  elementId?: string;

  // ============================================================================
  // ARIA attributes
  // ============================================================================

  /**
   * HTML id attribute for the control
   * Used for accessibility and label association
   *
   * @type {string}
   * @example 'email-input', 'submit-button'
   */
  id?: string;

  /**
   * ID of the error message element
   * Used for aria-describedby accessibility
   *
   * @type {string}
   * @internal
   */
  errorId?: string;

  /**
   * Title attribute for the control
   * Provides tooltip or additional context
   *
   * @type {string}
   * @example 'Enter your email address'
   */
  title?: string;

  // ============================================================================
  // Time settings
  // ============================================================================

  /**
   * Debounce time in milliseconds for update events
   * Delays emitting updates to reduce event frequency
   *
   * @type {number}
   * @default 1
   * @example 300 // Wait 300ms after last change before emitting
   */
  timeToEmitUpdate?: number;

  // ============================================================================
  // Custom properties
  // ============================================================================

  /**
   * Custom properties for framework-specific extensions
   * When using the generic TCustomProps parameter, known properties are typed.
   * Additional properties can still be added via this index signature.
   *
   * @type {unknown}
   * @description Allows extending with custom properties beyond the standard ones
   */
  [key: string]: unknown;
}

// Make TCustomProps properties available on BaseControl
export type BaseControlWithCustom<TCustomProps extends Record<string, unknown> = Record<string, unknown>> =
  BaseControl<TCustomProps> & Partial<TCustomProps>;
