/**
 * @file Conditional Logic Types
 * @description Type definitions for conditional display, disable, and require logic
 * @module types/conditional
 */

/**
 * Conditional display/disable/require logic
 *
 * Maps field names to expected values that trigger the condition.
 * Used for displayIf, disableIf, and requireIf properties on controls.
 *
 * @typedef {Object.<string, string|number|boolean|Array<string|number|boolean>>} ConditionalLogic
 *
 * @description
 * - Keys: Field names to watch
 * - Values: Expected value(s) that trigger the condition
 *   - Single value: Field must equal this value
 *   - Array of values: Field must equal one of these values
 *
 * @example
 * ```typescript
 * // Show field only if country is 'us'
 * const displayIf: ConditionalLogic = {
 *   country: 'us'
 * };
 *
 * // Disable field if age is less than 18
 * const disableIf: ConditionalLogic = {
 *   age: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17]
 * };
 *
 * // Required if employed is true
 * const requireIf: ConditionalLogic = {
 *   employed: true
 * };
 *
 * // Show if country is 'us' or 'ca'
 * const displayIf: ConditionalLogic = {
 *   country: ['us', 'ca']
 * };
 *
 * // Multiple conditions (all must be true)
 * const displayIf: ConditionalLogic = {
 *   country: 'us',
 *   employed: true,
 *   age: [18, 19, 20, 21, 22]
 * };
 * ```
 */
export type ConditionalLogic = Record<string, string | number | boolean | Array<string | number | boolean>>;
