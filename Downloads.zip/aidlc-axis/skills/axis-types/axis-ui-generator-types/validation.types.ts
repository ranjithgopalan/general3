/**
 * @file Validation Types
 * @description Type definitions for form validation configuration
 * @module types/validation
 */

import type { ValidatorFn } from '@angular/forms';

/**
 * Angular Validators configuration for form controls
 *
 * Defines validation rules that will be applied to form controls.
 * Maps to Angular's built-in validators (Validators.required, Validators.email, etc.)
 *
 * Generic type TCustomValidators allows specifying typed custom validators.
 *
 * @interface UIValidators
 * @template TCustomValidators - Optional typed custom validators, defaults to Record<string, any>
 *
 * @example
 * ```typescript
 * // Basic validators without custom
 * const validators: UIValidators = {
 *   required: true,
 *   email: true,
 *   minLength: 5,
 *   maxLength: 100,
 *   pattern: /^[A-Z]/
 * };
 *
 * // With typed custom validators
 * interface CustomValidators {
 *   creditCard: (control: AbstractControl) => ValidationErrors | null;
 *   phoneNumber: (control: AbstractControl) => ValidationErrors | null;
 *   zipCode: (control: AbstractControl) => ValidationErrors | null;
 * }
 *
 * const typedValidators: UIValidators<CustomValidators> = {
 *   required: true,
 *   creditCard: myCreditCardValidator,  // ✅ Typed!
 *   phoneNumber: myPhoneValidator,      // ✅ Typed!
 *   // invalidValidator: () => {}       // ❌ TypeScript error!
 * };
 * ```
 */
export interface UIValidators<TCustomValidators extends Record<string, ValidatorFn> = Record<string, ValidatorFn>> {
  /**
   * Field is required
   * @type {boolean}
   */
  required?: boolean;

  /**
   * Checkbox must be checked (for boolean values)
   * @type {boolean}
   */
  requiredTrue?: boolean;

  /**
   * Minimum string length
   * @type {number}
   */
  minLength?: number;

  /**
   * Maximum string length
   * @type {number}
   */
  maxLength?: number;

  /**
   * Minimum numeric value
   * @type {number}
   */
  min?: number;

  /**
   * Maximum numeric value
   * @type {number}
   */
  max?: number;

  /**
   * Regular expression pattern to match
   * @type {string | RegExp}
   */
  pattern?: string | RegExp;

  /**
   * Validate email format
   * @type {boolean}
   */
  email?: boolean;

  /**
   * Custom validator functions
   * When using the generic TCustomValidators parameter, known validators are typed.
   * Additional validators can still be added via this index signature.
   *
   * @type {ValidatorFn | boolean | number | string | RegExp | undefined}
   * @description Allows adding custom Angular validator functions
   */
  [customValidator: string]: ValidatorFn | boolean | number | string | RegExp | undefined;
}

// Make TCustomValidators properties available on UIValidators
export type UIValidatorsWithCustom<TCustomValidators extends Record<string, ValidatorFn> = Record<string, ValidatorFn>> =
  UIValidators<TCustomValidators> & Partial<TCustomValidators>;

/**
 * Custom error messages for validators
 *
 * Provides user-friendly error messages to display when validation fails.
 * Keys correspond to validator names in UIValidators.
 *
 * Generic type TCustomMessages allows specifying typed custom error messages.
 *
 * @interface UIErrorMessages
 * @template TCustomMessages - Optional typed custom error messages
 *
 * @example
 * ```typescript
 * // Basic error messages
 * const errorMessages: UIErrorMessages = {
 *   required: 'This field is required',
 *   email: 'Please enter a valid email address',
 *   minLength: 'Must be at least 5 characters',
 *   pattern: 'Must start with a capital letter'
 * };
 *
 * // With typed custom messages
 * interface CustomMessages {
 *   creditCard: string;
 *   phoneNumber: string;
 * }
 *
 * const typedMessages: UIErrorMessages<CustomMessages> = {
 *   required: 'Required field',
 *   creditCard: 'Invalid credit card number',   // ✅ Typed!
 *   phoneNumber: 'Invalid phone number format'  // ✅ Typed!
 * };
 * ```
 */
export interface UIErrorMessages<TCustomMessages extends Record<string, string> = Record<string, string>> {
  /**
   * Error message for required validation failure
   * @type {string}
   */
  required?: string;

  /**
   * Error message for requiredTrue validation failure
   * @type {string}
   */
  requiredTrue?: string;

  /**
   * Error message for minLength validation failure
   * @type {string}
   */
  minLength?: string;

  /**
   * Error message for maxLength validation failure
   * @type {string}
   */
  maxLength?: string;

  /**
   * Error message for min validation failure
   * @type {string}
   */
  min?: string;

  /**
   * Error message for max validation failure
   * @type {string}
   */
  max?: string;

  /**
   * Error message for pattern validation failure
   * @type {string}
   */
  pattern?: string;

  /**
   * Error message for email validation failure
   * @type {string}
   */
  email?: string;

  /**
   * Custom error messages for custom validators
   * When using the generic TCustomMessages parameter, known messages are typed.
   *
   * @type {string}
   */
  [key: string]: string | undefined;
}

// Make TCustomMessages properties available on UIErrorMessages
export type UIErrorMessagesWithCustom<TCustomMessages extends Record<string, string> = Record<string, string>> =
  UIErrorMessages<TCustomMessages> & Partial<TCustomMessages>;
