/**
 * @file Menu Types
 * @description Type definitions for label and field menu configurations
 * @module types/menu
 */

/**
 * Label or field menu item configuration
 *
 * Defines menu items that can be attached to control labels or fields.
 * Used for inline actions like edit, delete, help, etc.
 *
 * @interface MenuIcon
 *
 * @example
 * ```typescript
 * const menuIcon: MenuIcon = {
 *   icon: 'edit',
 *   iconFont: 'material',
 *   event: 'editField',
 *   tooltip: 'Edit this field'
 * };
 * ```
 */
export interface MenuIcon {
  /**
   * Icon name/identifier
   * For Material Icons: 'edit', 'delete', 'help', 'info', etc.
   * For FontAwesome: 'fa-edit', 'fa-trash', 'fa-question-circle', etc.
   *
   * @type {string}
   */
  icon: string;

  /**
   * Icon font library to use
   * - 'material': Material Icons (default)
   * - 'fontawesome': Font Awesome icons
   *
   * @type {('material' | 'fontawesome')}
   * @default 'material'
   */
  iconFont?: 'material' | 'fontawesome';

  /**
   * Event name to trigger when menu item is clicked
   * Event will be emitted through AUG's event system
   *
   * @type {string}
   * @example 'editField', 'deleteField', 'showHelp'
   */
  event?: string;

  /**
   * Tooltip text to display on hover
   * Provides context about what the menu item does
   *
   * @type {string}
   * @example 'Edit this field', 'Delete this item', 'Show help documentation'
   */
  tooltip?: string;

  /**
   * Custom properties for extended functionality
   * Allows adding additional properties beyond the standard ones
   *
   * @type {unknown}
   */
  [key: string]: unknown;
}
