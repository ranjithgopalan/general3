/**
 * @file Route Configuration Types
 * @description Type definitions for AUG routing configuration
 * @module types/route
 */

import type { ContentRequest } from './event.types';

/**
 * Route configuration for AUG routing
 *
 * Defines a route with optional content requests and event handlers.
 * Used for SPA-style navigation within AUG applications.
 *
 * @interface AUGRoute
 *
 * @example
 * ```typescript
 * const route: AUGRoute = {
 *   path: '/dashboard',
 *   contentRequest: {
 *     url: '/api/dashboard',
 *     method: 'GET',
 *     showLoading: true
 *   },
 *   preload: true
 * };
 * ```
 */
export interface AUGRoute {
  /**
   * Route path (URL path or pattern)
   *
   * @type {string}
   * @example '/dashboard', '/users/:id', '/settings'
   */
  path: string;

  /**
   * Content request to execute when route is activated
   * Fetches data or triggers API calls on navigation
   *
   * @type {ContentRequest}
   * @see ContentRequest
   */
  contentRequest?: ContentRequest;

  /**
   * Router event handlers
   * Custom event handlers for route lifecycle events
   *
   * @type {Object.<string, unknown>}
   * @example { onEnter: () => {}, onLeave: () => {} }
   */
  routerEvents?: Record<string, unknown>;

  /**
   * Whether to preload this route's content
   * If true, content request executes before route activation
   *
   * @type {boolean}
   * @default false
   */
  preload?: boolean;
}

/**
 * Collection of AUG routes
 *
 * Container for multiple route configurations.
 * Used to define the complete routing structure for an AUG application.
 *
 * @interface AUGRoutes
 *
 * @example
 * ```typescript
 * const routes: AUGRoutes = {
 *   routes: [
 *     { path: '/dashboard', contentRequest: {...} },
 *     { path: '/profile', contentRequest: {...} },
 *     { path: '/settings', contentRequest: {...} }
 *   ]
 * };
 * ```
 */
export interface AUGRoutes {
  /**
   * Array of route configurations
   *
   * @type {Array<AUGRoute>}
   */
  routes: AUGRoute[];
}
