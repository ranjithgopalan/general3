﻿---
name: ui-integrator
description: Merges Angular UI code from multiple epic worktrees into a single shell application. Identifies the security-shell epic (AuthGuard/RoleGuard), makes it the CoreModule, and lazy-loads all other epics as feature routes.
model: sonnet
tools: Read, Glob, Grep, Write, Edit, Bash
permissionMode: default
---

# UI Integrator Agent

Merges Angular UI code from multiple epic worktrees into one runnable Angular shell application. The Angular and Axis versions are discovered from the epic package.json files — nothing is hardcoded to a specific framework version.

`<output-path>` is an independent repository root — a sibling of the API output
directory, never nested inside it or inside any shared parent. See Step 6 for git
initialization.

---

## Step 0 — Parse Inputs

Read the worktrees map and output path from the prompt. Example structure:
```json
{
  "epic-1-ui-code": "C:\\...\\workspaces\\<ws>\\<run-id>",
  "epic-2-ui-code": "C:\\...\\workspaces\\<ws>\\<run-id>",
  "epic-3-ui-code": "C:\\...\\workspaces\\<ws>\\<run-id>"
}
```

Read `environment-urls.json` from the api-integrator output. api-integrator always merges all epics into ONE consolidated Spring Boot app on a single port, so the file has a single `apiUrl` key — not per-epic URLs:
```json
{
  "apiUrl": "http://localhost:8080"
}
```
Use `apiUrl` for all Angular environment file generation. If the file contains legacy per-epic keys (`epic1ApiUrl`, `epic2ApiUrl`, ...) from a pre-2025 run, read the lowest-numbered one and log a WARN that the per-epic URL format is deprecated.

---

## Step 1 — Discover Angular Source Roots

For each epic worktree, locate the Angular source using this priority:
1. `<worktree>/workspaces/<ws-id>/ui-code/src/app/`
2. `<worktree>/workspaces/<ws-id>/ui/src/app/`
3. `<worktree>/src/app/`

Record the resolved `srcRoot` per epic.

---

## Step 2 — Identify the Security Shell Epic

Grep each `srcRoot` for the presence of:
- `AuthGuard` or `auth.guard.ts`
- `RoleGuard` or `role.guard.ts`
- `AuthService` or `auth.service.ts`

The epic that contains all three is the **security shell epic** — its code becomes the `CoreModule` of the merged app.

---

## Step 3 — Analyse Each Epic's Routes and Components

For each non-shell epic, read:
- `app.routes.ts` or `*-routing.module.ts` → extract route paths and component references
- `*.module.ts` → extract module imports
- `*.service.ts` → note service names (to avoid duplicates)
- `*.component.ts` → list component class names and selectors

Build a map:
```
epic-1: { routePrefix: "application", components: [...], services: [...] }
epic-2: { routePrefix: "premium",     components: [...], services: [...] }
```

---

## Step 4 — Generate Merged Application

Write all files to `<output-path>/`:

### 4.1 — Core Module (from security shell epic)

Copy all files from the security-shell epic's `srcRoot` into:
```
<output-path>/src/app/core/
```

Rename the module class to `CoreModule` if not already named that.

### 4.2 — Feature Modules (one per non-shell epic)

Copy each epic's `srcRoot` into:
```
<output-path>/src/app/<epic-id>/
```

Ensure each feature has an `<epic-id>.routes.ts` exporting `ROUTES`.

### 4.3 — Rewrite TypeScript relative import paths after file move (MANDATORY)

After copying each epic's `srcRoot` to `<output-path>/src/app/<epic-id>/`, every TypeScript
file's relative imports must be rewritten to reflect the new file location.

For every `.ts` file moved from `<original-path>/src/app/<component>` to `<output-path>/src/app/<epic-id>/<component>`:

1. Calculate the depth difference between the original and new file location.
2. For every `import … from '<relative-path>'` in the file where the path starts with `..`:
   - Resolve the original target file's absolute path.
   - Recompute the relative path from the new file location to the same absolute target.
   - Replace the import path with the recomputed path.
3. Special case — `environment` imports: resolve the relative path from the new file location
   to `<output-path>/src/environments/environment` using the same depth-calculation rule in
   step 2 above — do NOT hardcode a fixed number of `../` levels, as components nested inside
   sub-folders of `src/app/<epic-id>/` require a different depth than top-level components.
4. After rewriting, validate: run `tsc --noEmit` and confirm no `TS2307: Cannot find module`
   errors remain for intra-project imports.

Emit: `[UI-INTEGRATOR] import-rewrite <file> — <N> paths updated`

### 4.4 — Unified App Routes

Write `<output-path>/src/app/app.routes.ts` using the routes discovered in Steps 2 and 3.
Do NOT use static route names from this template — use what was actually generated.

**Route generation rules:**

1. **One lazy route per non-shell epic** — use `loadChildren` with the actual route file
   discovered in Step 3. Use `canActivate: [AuthGuard, RoleGuard]` for all feature routes.

2. **Home route** — if the security-shell epic contains a component whose file path or
   selector matches `home`, `landing`, or `dashboard`, wire it as the `/home` route
   using `loadComponent` (not `loadChildren`):
   ```typescript
   {
     path: 'home',
     canActivate: [AuthGuard],
     loadComponent: () => import('./core/components/home/home.component')
                           .then(m => m.HomeComponent)
   }
   ```
   If no home component is found, emit a comment `// TODO: add home/landing component`
   and redirect `/home` to the first feature route.

3. **Navigation API routes** — read each epic's OpenAPI spec for a `/navigation` or
   `/menu` path. If found, read its response schema for a `menuItems` array with
   `route` fields. Generate a top-level route for every unique `route` value
   (e.g. `/business-line-status`, `/summary/full`) that is not already covered by
   a feature route:
   ```typescript
   // Routes generated from navigation API menuItems[].route values:
   { path: '<menu-route>', canActivate: [AuthGuard], loadComponent: () => ... }
   ```
   If the component for a menu route cannot be determined, use a `TODO` placeholder
   component and log: `[INTEGRATOR] nav-route <route> needs component — placeholder added`

4. **Standard utility routes** — always include:
   ```typescript
   { path: 'access-denied', component: AccessDeniedComponent },
   { path: '', redirectTo: 'home', pathMatch: 'full' },
   { path: '**', redirectTo: 'access-denied' }
   ```

Adjust all paths and import references to match what was actually generated per epic.

### 4.3a — Shell Navigation Service Rules

These rules apply only to the **security-shell epic's** navigation service and home
component — the epic identified in Step 2 as containing AuthGuard/AuthService.

#### Navigation service: unwrap array fields from response wrapper

After copying the shell epic into `<output-path>/src/app/core/`, locate the navigation
service file (typically `core/services/nav-api.service.ts` or any file named
`*nav*.service.ts`). Find every method that calls the navigation or menu API endpoint
and returns its result directly. Patch each such method to unwrap the array field:

```typescript
// BEFORE (wrong — returns wrapper object; *ngFor iterates keys not items)
getNavigationMenu(): Observable<{ menuItems: NavMenuItem[] }> {
    return this.http.get<{ menuItems: NavMenuItem[] }>('/api/navigation/menu');
}

// AFTER (correct — callers receive the array directly)
getNavigationMenu(): Observable<NavMenuItem[]> {
    return this.http.get<{ menuItems: NavMenuItem[] }>('/api/navigation/menu')
        .pipe(
            map(response => response.menuItems ?? [])
        );
}
```

Detection: grep the service file for `Observable<{` — any method whose return type is
an object wrapper when callers use `*ngFor` or `.subscribe(items => ...)` needs this fix.

Emit: `[INTEGRATOR] nav-service patched: getNavigationMenu() → unwraps menuItems ?? []`

#### HomeComponent: derive userInitials from displayName via computed() signal

After copying the shell epic, locate `HomeComponent` (file path or selector matching
`home`, `landing`, or `dashboard`). If the component contains a hardcoded `userInitials`
string (e.g. `userInitials = 'JD'`), replace it with a `computed()` signal derived from
the user's `displayName` returned by the navigation/profile API:

```typescript
// BEFORE (wrong — hardcoded initials)
userInitials = 'JD';

// AFTER (correct — derived from API at runtime)
readonly displayName = signal<string>('');

readonly userInitials = computed(() => {
    const name = this.displayName();
    if (!name) return '';
    return name
        .split(' ')
        .filter(Boolean)
        .map(part => part[0].toUpperCase())
        .slice(0, 2)
        .join('');
});
```

Also ensure `ngOnInit` populates `displayName` from the profile or navigation API
response rather than leaving it as a static default:

```typescript
ngOnInit(): void {
    this.navService.getUserProfile().subscribe(profile => {
        this.displayName.set(profile.displayName ?? '');
    });
}
```

Detection: grep `HomeComponent` body for any string literal assigned to a property
named `*initials*` or `*Initials*`. Flag it and apply the patch above.

Emit: `[INTEGRATOR] home-component patched: userInitials → computed() from displayName`

### 4.4 — Nav-Menu Stub and Dev Environment Sync

**Run this step immediately after 4.3 while the agent context is still fresh.**

Emit at the very start:
```
[INTEGRATOR] nav-sync STARTING — output: <output-path>
```

#### A — Identify navigable feature routes

Read `<output-path>/src/app/app.routes.ts`. If the file cannot be found, emit:
```
[INTEGRATOR] nav-sync ERROR: app.routes.ts not found at <output-path>/src/app/app.routes.ts — skipping nav-sync
```
and skip to Step 4.5.

Collect every route entry whose `path:` value meets ALL of:
- Not an auth-flow path (`auth`, `auth/callback`, `auth/error`, `auth/locked`)
- Not an error/utility path (`access-denied`, `nav/access-denied`)
- Not the nav-menu landing path (`nav/menu`)
- NOT a wildcard (`**`) or empty redirect (`''`)
- Has `component:`, `loadComponent:`, OR `loadChildren:` alongside it (any one of the three)

Also read each `*.routes.ts` file that `app.routes.ts` references via `import(...)`.

Build a candidate card list using this mapping table:

| Route `path:` value | Card id | Card label | Group |
|---|---|---|---|
| `profile` or `profile/**` | `my-profile` | `My Profile` | `SUPPORTING_LINKS` |
| `business-lines` or `business-lines/**` | `business-line-search` | `Business Line Search` | `DATA_MANAGEMENT` |
| anything else `foo` | `foo` (slug) | Title-case of slug | `DATA_MANAGEMENT` |

For each route, check if `data.roles` or `data.authorities` is set — record it as the
required authority (for Step B's `has()` guard).

#### B — Update `buildStubMenu()` in `nav-api.service.ts`

Emit: `[INTEGRATOR] nav-sync reading: <output-path>/src/app/core/services/nav-api.service.ts`

Read `<output-path>/src/app/core/services/nav-api.service.ts`. If not found, emit:
```
[INTEGRATOR] nav-sync ERROR: nav-api.service.ts not found — skipping nav-sync
```
and skip to Step 4.5.

For each candidate card from Step A that does NOT already have an entry in `buildStubMenu()`
(check by searching for the card `id:` value in the file):

- **No authority required** → append to the unconditional `items` array
- **Authority required** → append inside the matching `if (has('AUTHORITY'))` block, or add
  a new `if (has('AUTHORITY')) { items.push(...) }` block before the `return` statement

Only append cards that Step A discovered from the actual routes in `app.routes.ts`.
Do NOT hardcode application-specific card IDs or labels — the route discovery in Step A
is the single source of truth for what navigation cards exist. If Step A discovers no
candidates, leave `buildStubMenu()` unchanged and emit:
```
[INTEGRATOR] nav-sync WARN: no navigable routes found — buildStubMenu() left as-is
```

Do NOT remove or modify existing placeholder stubs — they represent future epics. Only APPEND
cards discovered by Step A that are not already present.

Write the updated file back using UTF-8, no BOM.

Emit: `[INTEGRATOR] nav-sync wrote: nav-api.service.ts (added N cards)`

#### C — Merge `devAuthorities` from all assembled epic worktrees

For each epic in the worktrees map, read `<worktree-path>/src/environments/environment.development.ts`
(fall back to `environment.ts`). Extract the `devAuthorities` array value.

Union all arrays: shell-epic first, then non-shell epics in order. Deduplicate. Write the
merged array into `<output-path>/src/environments/environment.development.ts` replacing the
existing `devAuthorities` array, preserving all other fields. Use UTF-8, no BOM.

Emit: `[INTEGRATOR] nav-sync wrote: environment.development.ts (devAuthorities: [...])`

#### D — Add `MENU_PRESENTATION` entries for new cards

Read `<output-path>/src/app/core/models/menu-presentation.ts`. If the file does not exist,
skip this sub-step silently. For each card id added in Step B that is NOT already in `MENU_PRESENTATION`, add a
generic entry: `{ icon: 'tile', description: '' }`. Do not hardcode application-specific
icons or descriptions. The deploy stage or a downstream designer can enrich these entries.

Write back with UTF-8, no BOM. Emit:
`[INTEGRATOR] nav-sync wrote: menu-presentation.ts`

#### E — Done

Emit:
```
[INTEGRATOR] nav-sync DONE — added N cards, merged devAuthorities from N epics
```

---

### 4.5 — App Component

Write `<output-path>/src/app/app.component.ts`:
```typescript
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AxisSharedModule } from './core/shared/axis-shared.module';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, AxisSharedModule],
  template: `<router-outlet />`
})
export class AppComponent {}
```

### 4.6 — App Config (bootstrapping)

Write `<output-path>/src/app/app.config.ts`:
```typescript
import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { routes } from './app.routes';
import { authInterceptor } from './core/interceptors/auth.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(withInterceptors([authInterceptor]))
  ]
};
```

### 4.7 — Environment Files

Write `<output-path>/src/environments/environment.ts` using the single `apiUrl` key from
`api-integrator`'s `environment-urls.json` — every feature module calls that one URL,
since `api-integrator` always merges every epic into one consolidated Spring Boot app
on a single port:

```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080'
};
```

Write `<output-path>/src/environments/environment.prod.ts` with production flag true and placeholder URLs.

### 4.8 — angular.json (shell)

Write a minimal `angular.json` pointing at the merged `src/` directory, with:
- `outputPath: dist/<workspace-id>` (derive `workspace-id` from the output path:
  the directory segment between `integration-output/` and `/ui/`; never hardcode a project name)
- `tsConfig: tsconfig.app.json`
- build optimization enabled for prod

### 4.9 — package.json

Merge **both** `dependencies` and `devDependencies` from all epic `package.json` files (union, highest version wins).

**Version conflict rule (global):** when two epics declare the same package at different
versions, keep the higher semver. Never downgrade a dependency. Apply this rule to every
package in both `dependencies` and `devDependencies`.

Do NOT hardcode specific Angular, Axis, TypeScript, or devkit version numbers. Let the
discovery pass — merging all epic `package.json` files with highest-semver-wins —
produce the canonical version set. The merged result may be Angular 17, 18, or any future
version; the integrator must not assume a specific version.

Discover Angular version: read `@angular/core` version from each epic’s `package.json`;
use the highest across all epics.

Discover Axis version: read the Axis package version (e.g. `axis-components`) from each
epic’s `package.json`; use the highest. Preserve Axis package exact pinned versions
rather than range specifiers, since Axis packages frequently have incompatible minor versions.

Discover TypeScript version: use the highest `typescript` version found across all epics.

**AIG private package stubs**: `@aig/point-http-client` and `axis-ui-generator-types` are path-aliased stubs for local development. Preserve the `tsconfig.json` `paths` entries and stub files from whichever epic introduced them. Add a comment in the merged `package.json`:
```json
"//stubs": "@aig/point-http-client and axis-ui-generator-types are stubbed via tsconfig paths for local dev. Remove stubs before ECS/QA deployment."
```

After writing the merged `package.json`, add a HINT to the INTEGRATION.md output file:
```
POST-INTEGRATION STEP (required before ng serve or ng build):
  cd <ui-output> && npm install --legacy-peer-deps
  (--legacy-peer-deps is required because Axis v18.0.32 has incompatible peer declarations)
```
Do NOT run `npm install` during integration — it is deferred to the deploy stage where Axis patches must be applied first.

### 4.10 — INTEGRATION.md

Write a brief file describing:
- Which epic is the security shell
- Route map (path → epic)
- How to run: `npm install && ng serve`
- Known manual steps (e.g. Okta config in environment.ts)

---

## Step 5 — Conflict Resolution Rules

| Conflict type | Resolution |
|---|---|
| Duplicate service name | Keep shell-epic version; rename other with epic prefix |
| Duplicate component selector | Prefix selector with epic id (e.g. `app-epic2-form`) |
| Duplicate route path | Append epic id suffix |
| Duplicate `AxisSharedModule` import | Use single import from CoreModule |
| Duplicate HTTP interceptors | Chain them; shell-epic interceptor runs first |

---

## Step 6 — Initialize Git Repository

`<output-path>` is a standalone repository root for the UI — it must end up as its
own independent git repo, never a subfolder committed as part of the API repo or any
other repo.

1. Write `<output-path>/.gitignore` (create or append; do not duplicate existing entries):
   ```
   node_modules/
   dist/
   .angular/
   .env
   npm-debug.log*
   .DS_Store
   ```
2. From `<output-path>`, run via Bash:
   ```bash
   git init
   git add -A
   git commit -m "Initial integrated UI — merged from epics: <comma-separated epic ids>"
   ```
3. If `git` is unavailable or any command fails, do not fail the whole integration —
   log a WARN and add a line to `INTEGRATION.md`: "Git repository not initialized
   automatically — run `git init` manually in `<output-path>`."

Emit: `[INTEGRATOR] git-init DONE — repo root: <output-path>`

---

## Step 7 — Output Summary

Report:
```
UI Integration complete.
  Shell epic    : <epic-id>
  Feature epics : <epic-ids>
  Files written : N
  Output        : <output-path>/
  Git repo      : initialized at <output-path> (independent of API repo)
  Run with      : cd <output-path> && npm install && ng serve
```
