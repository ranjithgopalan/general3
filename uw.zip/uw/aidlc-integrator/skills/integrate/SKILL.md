---
name: integrate
description: Merge all epic UI, API, and DB-integration code into one validated application. Orchestrates api-integrator, ui-integrator, and integration-validator in sequence.
triggers:
  - "integrate epics"
  - "merge epics"
  - "integrate the application"
  - "combine epics"
  - "assemble application"
---

# AIDLC-integrator: integrate

Discovers all completed `ui-code`, `api-code`, and `db-integration` runs for a workspace
and merges them into a single validated Angular + Spring Boot application.
The `db-integration` output (`api-data-access` — stored-procedure DAOs, datasource config,
Flyway baseline) is merged into each epic's namespaced package by the `api-integrator` agent
so the single consolidated Spring Boot application includes the full data-access layer.

> ⚡ **AIDLC Launcher mode (ECS):** If `aidlc.config.json` **exists** in the current working
> directory, **skip Phases 0–4 entirely** and jump directly to the **ECS Reporting** section
> at the bottom of this file. The local session's only role is to create the ECS run and
> monitor the CLI subprocess — do **not** invoke agents or generate files locally.

> ⚡ **Local API Mode:** If `$env:AIDLC_RUN_ID -eq "local"`, the skill is running locally against
> the central API (localhost:8080 or configured URL). The skill reads `aidlc.config.json` directly
> (config file is always present — never renamed to .bak), discovers epic worktrees from the local
> temp directory structure (`%TEMP%\aidlc-ws\`), and merges code the same way as ECS mode.
> Skip Phase 0 (token check) — worker already set `$env:AIDLC_TOKEN`.

---

## Phase 0 — Token Check

**Step 0 — Check for AIDLC_TOKEN**

```bash
echo "${AIDLC_TOKEN:0:10}"
```

- **Non-empty** → tell the user `✓ AIDLC_TOKEN is set.` and proceed to Phase 1.
- **Empty** → ask:

```
AskUserQuestion({
  questions: [{
    question: "AIDLC_TOKEN is not set. How would you like to provide your Okta token?",
    header: "Okta Token",
    multiSelect: false,
    options: [
      {
        label: "Set it manually and re-run",
        description: "PowerShell: $env:AIDLC_TOKEN='eyJ...'   Git Bash: export AIDLC_TOKEN='eyJ...'"
      },
      {
        label: "Paste token here",
        description: "Click 'Other' below, type or paste your AIDLC token, then press Enter"
      }
    ]
  }]
})
```

- **"Set it manually"** → print the export command and **END**.
- **Token pasted** → run:
  ```bash
  export AIDLC_TOKEN="<pasted_token>"
  ```
  Tell the user `✓ AIDLC_TOKEN set for this session.` then proceed to Phase 1.

---

## Phase 1 — Read Config and Discover Worktrees

**Step 1 — Read config and derive base workspace ID**

```powershell
# Resolve config path: prefer live file, fall back to .bak (worker renamed it)
$cfgPath = if (Test-Path "aidlc.config.json") { "aidlc.config.json" } `
           elseif (Test-Path "aidlc.config.json.bak") { "aidlc.config.json.bak" } `
           else { throw "aidlc.config.json not found — run /launch first." }
$cfg   = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
$BASE  = $cfg.central_base_url.TrimEnd('/')
$TOKEN = if ($env:AIDLC_TOKEN) { $env:AIDLC_TOKEN } else { [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env) }
$HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }

# Strip any --epic-N suffix to get the base workspace ID
# e.g. "test-nk-ev2--epic-2"  →  "test-nk-ev2"
#      "test-nk-ev2"           →  "test-nk-ev2"  (unchanged)
$RAW_WS_ID  = $cfg.workspace_id
$BASE_WS_ID = $RAW_WS_ID -replace '--epic-\d+$', '' -replace '--[^-]+-\d+$', ''

Write-Host "Config workspace_id : $RAW_WS_ID"
Write-Host "Base workspace ID   : $BASE_WS_ID"
```

**Step 2 — Discover child epic workspaces and fetch prerequisites**

**Unified approach (follow AIDLC-PLUGIN-EXECUTION-CONTRACT.md):**

Query the Central API for completed ui-code and api-code runs, download their latest artifacts from S3 using the contract template (Phase 2: Steps 2A-2C), and place them in the temp directory.

See: `AIDLC-PLUGIN-EXECUTION-CONTRACT.md` → **Phase 2: Prerequisite Discovery** for the complete S3 download implementation that all plugins must follow.

Key steps:
1. Query API for completed runs by stage_key
2. Extract artifact IDs from run records
3. Download artifacts from S3 using `{centralBaseUrl}/artifacts/{artifactId}/download`
4. Extract to appropriate temp directory paths
5. Use downloaded artifacts for integration

**After downloading prerequisites:**

**Step 3 — Collect latest completed ui-code, api-code, and db-integration runs per epic**

```powershell
$worktrees   = @{}
$epicSummary = @()

foreach ($epic in $epics) {
    if ($isLocalMode) {
        # Local mode: look for code in the epic's temp directory structure
        $epicTempDir = $epic.path
        $uiCodePath = Join-Path $epicTempDir "integration-output" "*" "ui"
        $apiCodePath = Join-Path $epicTempDir "integration-output" "*" "api"
        $dbIntegrationPath = Join-Path $epicTempDir "db-integration" "integration-output"
        
        # Check if UI and API code directories exist
        $uiDirs = Get-ChildItem (Split-Path $uiCodePath) -Directory -Recurse | 
                  Where-Object { $_.Name -eq "ui" -and (Get-ChildItem $_.FullName).Count -gt 0 }
        $apiDirs = Get-ChildItem (Split-Path $apiCodePath) -Directory -Recurse | 
                   Where-Object { $_.Name -eq "api" -and (Get-ChildItem $_.FullName).Count -gt 0 }
        
        # Check if DB integration artifacts exist (schema-snapshot.json, SP-catalog.json, or DAO classes)
        $dbIntegrationExists = $false
        $dbWorktreePath = "—"
        if (Test-Path $dbIntegrationPath) {
            $hasSchema = Test-Path (Join-Path $dbIntegrationPath "schema" "schema-snapshot.json")
            $hasCatalog = Test-Path (Join-Path $dbIntegrationPath "schema" "SP-catalog.json")
            $hasDaoDir = Test-Path (Join-Path $dbIntegrationPath "src" "main" "java")
            
            if ($hasSchema -or $hasCatalog -or $hasDaoDir) {
                $dbIntegrationExists = $true
                $dbWorktreePath = $dbIntegrationPath
            }
        }
        
        if ($uiDirs)  { $worktrees["$($epic.epic_id)-ui-code"]  = $uiDirs[0].FullName }
        if ($apiDirs) { $worktrees["$($epic.epic_id)-api-code"] = $apiDirs[0].FullName }
        if ($dbIntegrationExists) { $worktrees["$($epic.epic_id)-db-integration"] = $dbWorktreePath }
        
        $epicSummary += [PSCustomObject]@{
            EpicId         = $epic.epic_id
            Name           = $epic.name
            UICode         = if ($uiDirs)  { "found" } else { "NOT FOUND" }
            APICode        = if ($apiDirs) { "found" } else { "NOT FOUND" }
            DBIntegration  = if ($dbIntegrationExists) { "found" } else { "NOT FOUND" }
            UIWorktree     = if ($uiDirs)  { $uiDirs[0].FullName } else { "—" }
            APIWorktree    = if ($apiDirs) { $apiDirs[0].FullName } else { "—" }
            DBWorktree     = $dbWorktreePath
            DBArtifactIds  = @()  # Local mode uses worktree paths, not artifact downloads
        }
    } else {
        # API/ECS mode: query the API for completed runs
        $runs   = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$($epic.id)" -Headers $HDR).items
        $uiRun  = $runs | Where-Object { $_.stage_key -eq "ui-code"        -and $_.state -in @("waiting_for_approval","completed") } |
                  Sort-Object queued_at -Descending | Select-Object -First 1
        $apiRun = $runs | Where-Object { $_.stage_key -eq "api-code"       -and $_.state -in @("waiting_for_approval","completed") } |
                  Sort-Object queued_at -Descending | Select-Object -First 1
        $dbRun  = $runs | Where-Object { $_.stage_key -eq "db-integration" -and $_.state -in @("waiting_for_approval","completed") } |
                  Sort-Object queued_at -Descending | Select-Object -First 1

        if ($uiRun)  { $worktrees["$($epic.epic_id)-ui-code"]        = $uiRun.worktree  }
        if ($apiRun) { $worktrees["$($epic.epic_id)-api-code"]       = $apiRun.worktree }
        if ($dbRun)  { $worktrees["$($epic.epic_id)-db-integration"] = $dbRun.worktree  }

        # Also collect db-integration artifact IDs so api-integrator can download them
        $dbArtifacts = if ($dbRun) {
            $dbRun.artifacts | Where-Object { $_.artifact_type -eq "api-data-access" } |
            Select-Object -ExpandProperty artifact_id
        } else { @() }

        $epicSummary += [PSCustomObject]@{
            EpicId         = $epic.epic_id
            Name           = $epic.name
            UICode         = if ($uiRun)  { $uiRun.state  } else { "NOT FOUND" }
            APICode        = if ($apiRun) { $apiRun.state } else { "NOT FOUND" }
            DBIntegration  = if ($dbRun)  { $dbRun.state  } else { "NOT FOUND" }
            UIWorktree     = if ($uiRun)  { $uiRun.worktree  } else { "—" }
            APIWorktree    = if ($apiRun) { $apiRun.worktree } else { "—" }
            DBWorktree     = if ($dbRun)  { $dbRun.worktree  } else { "—" }
            DBArtifactIds  = $dbArtifacts
        }
    }
}
```

**Step 4 — Print discovery table and gate check**

Print a clear summary so the developer can see what has been found:

```
Workspace   : <BASE_WS_ID>
Total epics : N

Epic ID        Name                    UI Code        API Code       DB Integration
───────────────────────────────────────────────────────────────────────────────────
epic-1         Application Lifecycle   completed      completed      completed
epic-2         Premium Validation      completed      completed      NOT FOUND
epic-3         Access Control          completed      NOT FOUND      NOT FOUND
```

**Gate rule:**

- If **zero epics** have both `ui-code` AND `api-code` completed → tell the user:
  ```
  No epics have both UI and API code ready. Run M2 and M3 for at least
  one epic before invoking /integrate.
  ```
  **Stop.**

- If **some epics** are missing `ui-code` or `api-code` → warn the user which epics will be skipped, then proceed with only the epics that have **both** stages ready.

- If **some epics** are missing `db-integration` but have `ui-code` + `api-code` → warn the user:
  ```
  ⚠ epic-2 has no db-integration run. It will be integrated without the DAO
    layer (stored-procedure DAOs, datasource config, Flyway baseline).
    Run M4 (db-integration) for this epic then re-run /integrate, or proceed
    with a partial merge now.
  ```
  Proceed with the epics that are ready — the `api-integrator` will skip the DAO merge for those epics.

- If **all epics** have all three stages → proceed immediately.

Print before proceeding:
```
Proceeding with N of N epics:
  ✓ epic-1  (UI: completed, API: completed, DB: completed)
  ✓ epic-2  (UI: completed, API: completed, DB: NOT FOUND — DAO layer skipped)
  ✗ epic-3  skipped — api-code not found
```

**Step 5 — Resolve output directory (always temp folder)**

Compute **absolute** output paths that always point to the temp directory, regardless of whether the skill runs
in local or worker mode. This ensures integrated code is always written to:
`%TEMP%\aidlc-ws\{wsId}\{stageKey}\integration-output\`

```powershell
# Compute temp directory base path
$wsId      = $cfg.workspace_id
$stageKey  = "epic-assemble"
$tempBase  = Join-Path (Join-Path (Join-Path $env:TEMP "aidlc-ws") $wsId) $stageKey

# Create temp directory if it doesn't exist
if (-not (Test-Path $tempBase)) {
    New-Item -ItemType Directory -Path $tempBase -Force | Out-Null
}

# Resolve output paths within temp directory
# API and UI are two INDEPENDENT repo roots — siblings directly under integration-output/,
# never nested inside a shared "$BASE_WS_ID/" folder. Each is initialized as its own git
# repository by its respective agent (api-integrator / ui-integrator), so they must never
# share a parent directory that could itself look like a combined repo.
$OUTPUT_API = [System.IO.Path]::GetFullPath((Join-Path (Join-Path $tempBase "integration-output") "$BASE_WS_ID-api"))
$OUTPUT_UI  = [System.IO.Path]::GetFullPath((Join-Path (Join-Path $tempBase "integration-output") "$BASE_WS_ID-ui"))
Write-Host "[INTEGRATOR] output-api : $OUTPUT_API"
Write-Host "[INTEGRATOR] output-ui  : $OUTPUT_UI"
Write-Host "[INTEGRATOR] temp-base  : $tempBase"
```

Store `$OUTPUT_API` and `$OUTPUT_UI` — use them **verbatim** in every subsequent Task() prompt.
The absolute paths to the temp directory guarantee sub-agents write to the correct location regardless of 
their working directory or execution mode (local vs. worker).

---

## Phase 2 — API Integration

Invoke the `api-integrator` agent:

```
Task(subagent_type: "AIDLC-integrator:api-integrator", prompt: """
## Worktrees
${worktrees | json}

## Epic Summary (includes DBArtifactIds per epic)
${epicSummary | json}

## Output path
${OUTPUT_API}
(This is an absolute path — use it EXACTLY as given for every file write. Do NOT shorten, truncate, or re-derive it.)

## Epics
${epics | json}

Merge all Spring Boot services into a single consolidated Spring Boot application —
one build.gradle, one classpath, every epic as a namespaced sub-package, no gateway module
(per your Step 1c–7). Duplicate class/bean names across epics are resolved automatically
by prefixing with the epic id — never abort. Write docker-compose.yml so the result
starts with one command.

## DB Integration merge instructions

For each epic in the Epic Summary:

1. **If `DBWorktree` is set** — check out (or read from) that worktree and copy
   the db-integration output files into the epic's namespaced package (per your Step 6):
   - `src/main/java/**/dao/`             ← stored-procedure DAO classes
   - `src/main/java/**/repository/`      ← read-only JPA lookup repositories
   - `src/main/resources/datasource/`    ← datasource config (application-datasource.yml)
   - `src/main/resources/db/migration/`  ← Flyway baseline SQL scripts
   - `src/main/java/**/config/DataSourceConfig.java` ← datasource Spring config

2. **If `DBArtifactIds` is non-empty** — download each artifact (artifact_type=
   `api-data-access`) from the ECS API and unzip it into the epic's namespaced package.
   Use the same path mapping as step 1.

3. **If both `DBWorktree` and `DBArtifactIds` are empty for an epic** — log a
   warning:
   ```
   ⚠ epic-<id>: db-integration not found — merged without DAO layer.
   ```
   Continue with the remaining epics.

4. **Conflict resolution** — if a DAO class name collides across epics (e.g. two
   epics each generated `PolicyDao.java`), prefix the class name and Spring bean
   name with the epic ID to make them unique (e.g. `Epic2PolicyDao`, `Epic3PolicyDao`) —
   same convention as your Step 1c/Step 6 duplicate-name handling. Never abort.

5. **Datasource config merge** — handled per-epic by the namespaced `DataSourceConfig`
   classes generated in Step 6; each epic's datasource properties stay under its own
   `<epicId>.datasource.*` namespace so identical or differing connection URLs never collide.

6. **Flyway merge** — combine all `V__baseline.sql` scripts, one directory per epic
   (`db/migration/<epicId>/`), so migrations never collide.
""")
```

Wait for completion before proceeding to Phase 3.

---

## Phase 3 — UI Integration

Invoke the `ui-integrator` agent:

```
Task(subagent_type: "AIDLC-integrator:ui-integrator", prompt: """
## Worktrees
${worktrees | json}

## Output path
${OUTPUT_UI}
(This is an absolute path — use it EXACTLY as given for every file write. Do NOT shorten, truncate, or re-derive it.)

## API base URLs (from api-integrator output)
Read ${OUTPUT_API}/environment-urls.json

## Epics
${epics | json}

Merge all Angular feature modules into one shell application. The epic whose
ui-code contains AuthGuard/RoleGuard becomes the CoreModule. All other epic
routes are lazy-loaded and protected by those guards.
""")
```

Wait for completion before proceeding to Phase 3.5.

---

## Phase 3.5 — Integration Validation + Auto-fix (auto-invoked)

Automatically invoke the `integration-validator` agent — no user prompt needed:

```
Task(subagent_type: "AIDLC-integrator:integration-validator", prompt: """
## ui-output
${OUTPUT_UI}

## api-output
${OUTPUT_API}

## Epics
${epics | json}

Validate the merged Angular and Spring Boot code. Fix every error you can
automatically. Return { status, fixedCount, warningCount, unresolvedErrors }.
""")
```

**Gate check on validator result:**

- If `status == "PASSED"`:
  - Print:
    ```
    ✓ Validation passed — N errors auto-fixed, N warnings (see VALIDATION-REPORT.md)
    ```
  - Proceed to Phase 4 — Completion Summary.

- If `status == "BLOCKED"`:
  - Print:
    ```
    ✗ Validation BLOCKED — N errors could not be auto-fixed.
    Review: integration-output/<workspace_id>/VALIDATION-REPORT.md
    ```
  - List each unresolved error to the user.
  - **Stop** — do NOT proceed until the user resolves the blockers and re-runs `/integrate`.

---

## Phase 3.5 — DB Integration Gate Check (Before Completion)

**Run immediately after validation completes and before declaring integration complete.**

Review the `$epicSummary` table from Step 3. For each epic:

1. **Check if epic requires database access:**
   - Read the epic's generated API code in `<api-output>/src/main/java/<epicId>/`
   - Search for indicators:
     - `@Repository` interfaces
     - `DataSourceConfig` class
     - `dao/` package
     - `JpaRepository` or `CrudRepository` imports
     - `@Transactional` annotations

2. **If epic requires database access:**
   
   a. **Check `DBIntegration` status in epic summary:**
      - If `DBIntegration = "found"` or `"completed"` → ✓ PASSED
      - If `DBIntegration = "NOT FOUND"` → proceed to step b
   
   b. **Emit BLOCKING ERROR:**
      ```markdown
      ## ❌ Integration BLOCKED — Missing DB Integration Layer
      
      Epic `<epicId>` requires database access but db-integration stage has not completed.
      
      **Evidence:**
      - @Repository interfaces found in: <list files>
      - DataSourceConfig class found in: <file path>
      - DAO classes expected but not found in db-integration output
      
      **Required action:**
      1. Run db-integration stage (EA2/db-wiring) for workspace `<workspace_id>`
      2. Ensure db-integration completes successfully and produces:
         - schema-snapshot.json
         - SP-catalog.json (enriched with parameters and result columns)
         - DAO implementations (generated when catalog confidence="enriched")
      3. Re-run `/integrate` to merge the DB layer
      
      **Epics affected:**
      | Epic ID | Repositories Found | DB Integration Status |
      |---|---|---|
      | epic-3 | 5 interfaces | ❌ NOT FOUND |
      | epic-7 | 3 interfaces | ❌ NOT FOUND |
      ```
   
   c. **Set gate status:**
      ```json
      {
        "status": "BLOCKED",
        "reason": "DB integration missing for epics that require database access",
        "affectedEpics": ["epic-3", "epic-7"],
        "requiredStage": "db-integration (EA2)"
      }
      ```
   
   d. **STOP — do not proceed to Phase 4 until DB integration completes.**

3. **If epic does NOT require database access:**
   - Skip DB integration check for this epic
   - Continue to next epic

4. **Gate result:**
   - If ALL epics requiring DB access have `DBIntegration = "found"` → ✓ GATE PASSED, proceed to Phase 4
   - If ANY epic requiring DB access has `DBIntegration = "NOT FOUND"` → ✗ GATE BLOCKED, stop here

---

## Phase 4 — Completion Summary

**Only run if Phase 3.5 gate check PASSED.**

Print:
```
✓ Integration complete!

Output:
  UI  → integration-output/<workspace_id>/ui/
  API → integration-output/<workspace_id>/api/

Reports:
  Validation     : integration-output/<workspace_id>/VALIDATION-REPORT.md

Files written:
  UI  : [N] files
  API : [N] files
```

---

## ECS Reporting (if aidlc.config.json present)

> **SERVER CLI GUARD:** If `aidlc.config.json` does **not** exist in your current
> working directory, skip this entire ECS section and run only the phases above.

```powershell
$cfg   = Get-Content "aidlc.config.json" | ConvertFrom-Json
$BASE  = $cfg.central_base_url
$TOKEN = [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env)
$WS    = $cfg.workspace_id
$HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
$STAGE = "epic-assemble"

# Cancel stale + create new run
try {
    $stale = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS" -Headers $HDR).runs
    $stale | Where-Object { $_.stage_key -eq $STAGE -and $_.state -eq "queued" } |
        ForEach-Object { Invoke-RestMethod "$BASE/pipeline-runs/$($_.run_id)/cancel" -Headers $HDR -Method Post | Out-Null }
} catch {}
$body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true; force=$true } | ConvertTo-Json
$run    = (Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body).run
$RUN_ID = $run.run_id
Write-Host "ECS run created: $RUN_ID"

# Monitor
do {
    Start-Sleep -Seconds 15
    $run   = (Invoke-RestMethod "$BASE/pipeline-runs/$RUN_ID" -Headers $HDR).run
    $elapsed = if ($run.started_at) {
        $s = [datetime]::Parse($run.started_at)
        $e = if ($run.finished_at) { [datetime]::Parse($run.finished_at) } else { Get-Date }
        "$([int]($e - $s).TotalSeconds)s"
    } else { "queued" }
    $files = if ($run.files_written) { $run.files_written.Count } else { 0 }
    Write-Host "  [$elapsed]  state=$($run.state)  files=$files"
} while ($run.state -notin @("waiting_for_approval","completed","failed","cancelled"))

$fmt = { param($t) if ($t) { [datetime]::Parse($t).ToString("HH:mm:ss") } else { "—" } }
$sec = if ($run.started_at -and $run.finished_at) {
    [int]([datetime]::Parse($run.finished_at) - [datetime]::Parse($run.started_at)).TotalSeconds
} else { 0 }
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
Write-Host "  Run     : $RUN_ID"
Write-Host "  Stage   : $STAGE"
Write-Host "  State   : $($run.state)"
Write-Host "  Elapsed : ${sec}s"
Write-Host "  Files   : $($run.files_written.Count) written"
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
```

Approval persona: **Tech Lead**
