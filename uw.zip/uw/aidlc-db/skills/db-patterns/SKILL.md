---
name: db-patterns
description: What relational metadata to capture for a modernization programme, and the read-only boundary that must not be crossed
---

# Database Reverse-Engineering Patterns

| File | Covers |
|------|--------|
| `read-only-rules.md` | The boundary, and what counts as breaching it |
| `procedure-signatures.md` | Parameter directions, result shapes, undiscoverable cases |

## What to capture, and why each item earns its place

| Item | Consumer | Consequence of missing it |
|------|----------|---------------------------|
| Column type and length | Entity mapping, DTOs | Silent truncation |
| **Nullability** | Row mappers, validation | Null becomes zero; a money defect |
| Defaults | Insert paths | Duplicated or contradictory defaults |
| Primary keys | Entity identity | Unreliable JPA identity |
| Foreign keys | ERD, relationship mapping | Relationships invisible to reviewers |
| Indexes | Query design | Queries that work on a small copy and not in production |
| **Procedure parameter directions** | DAO generation | Code that compiles, runs, returns nothing |
| Procedure result shapes | Row mappers | Invented column lists failing in production |
| Checksum | Artefact versioning | A new version every capture, even when nothing changed |

## What NOT to capture

Business rows. Ever. The purpose is structure, not data — and a legacy credit
database holds personal and financial information that has no business being in a
knowledge base or a prompt.
