# Procedure Signatures

## Parameter directions are the highest-risk detail in the snapshot

| Snapshot direction | DAO registration |
|--------------------|------------------|
| `in` | `setXxx(ordinal, value)` |
| `out` | `registerOutParameter(ordinal, type)` |
| `inout` | both, in that order |
| `return` | `registerOutParameter` at ordinal 1, with the call-assignment form |

An `OUT` registered as `IN` produces code that compiles, runs, and silently returns
nothing. No exception, no log line — which is why the direction must come from the
catalogue rather than from reading the procedure body or inferring from a name.

## Result shapes, and when they cannot be discovered

`sys.dm_exec_describe_first_result_set_for_object` analyses a procedure's first
result set without executing it. It fails when the result is built with dynamic
SQL, temp tables, or conditional branches returning different shapes — all common
in legacy code.

When it fails, the snapshot records `result_discoverable: false` with the reason.
That is a finding to report, not an error to hide:

- the DAO generator must fall back to explicit mapping plus an integration test
  that asserts the real column set against a restored copy
- **no column list may be invented.** A fabricated mapper fails in production
  against real money, and it will pass any test written from the same assumption

## Multiple result sets

A procedure returning several result sets is described only for its first. Note it,
and have the DAO iterate with `getMoreResults()`. Reading only the first is a
data-loss bug that a test written from the same assumption will not catch.

## Null is not zero

Record nullability for every result column. On a credit system a null limit
frequently means "unlimited" while zero means "no facility"; collapsing them is a
financial defect.
