# The Read-Only Boundary

## What is permitted

Catalogue metadata only:

- `INFORMATION_SCHEMA.*`
- `sys.*` (including `sys.dm_exec_describe_first_result_set*`, which analyses a
  procedure's result shape **without executing it**)

## What is not

| Prohibited | Why |
|------------|-----|
| `SELECT` against a business table | Not structure; frequently personal or financial data |
| `INSERT`/`UPDATE`/`DELETE`/`MERGE` | This estate has no write path by design |
| `CREATE`/`ALTER`/`DROP`/`TRUNCATE` | The schema is owned externally |
| `OPENROWSET`/`OPENQUERY`/`sp_executesql`/`xp_cmdshell` | Arbitrary execution |
| `WAITFOR` | A denial-of-service lever, not introspection |
| Multiple statements in one call | Defeats statement-level review |

## Enforced in three places, not one

1. **Statement guard.** The service allowlists catalogue objects and rejects
   anything else before it reaches a driver. It is an allowlist rather than a
   keyword blocklist: a query naming `dbo.Customers` is rejected without anyone
   having had to predict that table's name.
2. **Connection intent.** `ApplicationIntent=ReadOnly` is set when the datasource
   declares `readonly`. A routing hint, not a guarantee.
3. **Database login.** Least privilege — the account should be unable to write even
   if the other two failed.

Use all three. Any one of them alone is a single point of failure, and the
consequence of failure is a modified production table.

## Production is not a valid target

The guard prevents writes; it does not prevent load. A catalogue sweep across a
large legacy schema is real work for the server. Always point at a restored copy,
and confirm before capturing.
