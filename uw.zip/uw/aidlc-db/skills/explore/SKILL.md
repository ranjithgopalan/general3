---
name: explore
description: Explore a captured schema snapshot and answer questions about tables, procedures, keys and relationships.
triggers:
  - "explore the schema"
  - "what procedures exist"
  - "which tables reference"
  - "AIDLC-db explore"
---

# AIDLC-db: explore

## Agent Invocation

Use the Task tool with `subagent_type="router"` and the following prompt:

"""
## User Request
$ARGUMENTS

## Intent: EXPLORE

Answer from a captured snapshot only. Do not connect to the database and do not
infer a column that is not in the snapshot -- say "not in the snapshot" instead.

Where the answer depends on a procedure whose result shape is undiscoverable, say
so rather than describing what it probably returns.
"""

## Output

An answer with the snapshot id it came from. No files written.
