---
name: document
description: Produce a data dictionary and Draw.io ERD from a captured schema snapshot.
triggers:
  - "data dictionary"
  - "generate erd"
  - "entity relationship diagram"
  - "document the schema"
  - "AIDLC-db document"
---

# AIDLC-db: document

## Agent Invocation

Use the Task tool with `subagent_type="router"` and the following prompt:

"""
## User Request
$ARGUMENTS

## Intent: DOCUMENT

Dispatch to `dictionary-and-erd`. Require a snapshot id; refuse to work from
guesses, because a plausible-looking dictionary of invented columns is worse than
none.

Emphasise in the output:
- nullability on every column, and a flag on every nullable numeric column for
  business confirmation (null "unlimited" versus zero "none" is a money defect)
- columns whose name and type disagree, which indicate a rule the legacy
  application enforces and the schema does not
- Draw.io XML, editable, split by subject area beyond ~25 tables
- orphan tables called out separately
"""

## Output

`schema/data-dictionary.md`, `schema/erd-*.drawio`, `schema/schema.json`
