# AIDLC-db: db-wire (EA2 - DB Configuration)

Wires authoritative database configuration into the single consolidated Spring Boot
application produced by the `epic-assemble` stage (EA1) — one `pom.xml`, one
`application.yml`, every epic as a namespaced sub-package.

**This skill complies with** [`AIDLC-PLUGIN-EXECUTION-CONTRACT.md`](../AIDLC-PLUGIN-EXECUTION-CONTRACT.md)

## Unified Execution Model

- **Config**: Always read `aidlc.config.json` directly (never renamed to `.bak`)
- **Mode Detection**: Check `$env:AIDLC_RUN_ID` to determine local vs ECS execution
- **Prerequisites**: Integrated API code from EA1 (epic-assemble)
  - **Local mode**: Search `%TEMP%\aidlc-ws\{wsId}\epic-assemble\integration-output\`
  - **ECS mode**: Query central API for completed epic-assemble runs
- **Output**: ALWAYS write to temp directory: `%TEMP%\aidlc-ws\{wsId}\db-wiring\integration-output\`

---

## Phase 0 — Mode Detection

```powershell
if (-not (Test-Path "aidlc.config.json")) {
    throw "aidlc.config.json not found"
}

$cfg = Get-Content "aidlc.config.json" -Raw | ConvertFrom-Json
$workspaceId = $cfg.workspace_id
$isLocalMode = [System.Environment]::GetEnvironmentVariable("AIDLC_RUN_ID") -eq "local"

Write-Host "Mode: $(if ($isLocalMode) { 'LOCAL API' } else { 'ECS' })"
Write-Host "Workspace: $workspaceId"
```

## Phase 1 — Discover Integrated API Code (from EA1)

**Local mode** — Search temp directory:
```powershell
if ($isLocalMode) {
    $assemblyTempDir = Join-Path (Join-Path (Join-Path $env:TEMP "aidlc-ws") $workspaceId) "epic-assemble"
    # api-integrator writes to integration-output/<workspaceId>-api/ — its own repo root,
    # a sibling of <workspaceId>-ui/, never nested under a shared "<workspaceId>/" folder.
    $apiOutputPath = Join-Path $assemblyTempDir "integration-output\$workspaceId-api"
    
    if (Test-Path $apiOutputPath) {
        Write-Host "Found integrated API from EA1 in temp directory"
        $apiCodeWorktree = $apiOutputPath
    } else {
        throw "Integrated API code not found. Run EA1 (epic-assemble) first."
    }
}
```

**ECS mode** — Query central API:
```powershell
if (-not $isLocalMode) {
    $HDR = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
    $runsUrl = "$centralBaseUrl/pipeline-runs?workspace_id=$workspaceId&stage_key=epic-assemble"
    
    try {
        $runs = (Invoke-RestMethod $runsUrl -Headers $HDR).items
        $completedRun = $runs | Where-Object { $_.state -in @("completed", "waiting_for_approval") } |
                             Sort-Object queued_at -Descending |
                             Select-Object -First 1
        
        if ($completedRun) {
            Write-Host "Found completed EA1 run: $($completedRun.run_id)"
            $apiCodeWorktree = $completedRun.worktree
        } else {
            throw "No completed EA1 (epic-assemble) run found. Run EA1 first."
        }
    } catch {
        throw "Error discovering EA1 prerequisite: $_"
    }
}
```

---

> ⚡ **Execution note:** EA2 runs after EA1 is approved in ECS. Both local and ECS modes
> discover the integrated API code (either from temp directory or API), then wire the DB
> configuration into it. The workflow is identical regardless of mode.

---

## Phase 1 — Resolve workspace ID and output paths

Read `<wsId>` from `$env:AIDLC_WS_ID` or from the worker prompt
(`workspace_id=<wsId>`).

Set:

| Variable     | Value |
|---|---|
| `STAGE_DIR`  | `workspaces/<wsId>/db-wiring/` |
| `SCHEMA_DIR` | `workspaces/<wsId>/db-wiring/schema/` |
| `API_OUTPUT` | Resolved below |

**Resolve `API_OUTPUT` in priority order:**

1. `integration-output/<wsId>-api/` exists locally → `API_OUTPUT = integration-output/<wsId>-api/`
   (this is the API's own repo root — a sibling of `<wsId>-ui/`, never nested under it)
2. `--add-dir` context contains a Spring Boot project (single `pom.xml` at its root) under an
   `epic-assemble/` subfolder → copy contents to `integration-output/<wsId>-api/` then
   `API_OUTPUT = integration-output/<wsId>-api/`
3. Neither → print:
   ```
   ✗ Integrated API output not found at integration-output/<wsId>-api/
     The epic-assemble stage must complete and be approved before db-wiring runs.
   ```
   **Stop.**

---

## Phase 2 — Resolve paths and detect pre-existing artifacts

### Step 2A — Resolve DB details document path (optional when snapshot is pre-existing)

**Worker mode — extract from prompt:**

Look for the marker string `"DB details document path (pre-confirmed from aidlc.config.json"` in
the worker prompt. If found, extract the path on the same line and set `DB_DOC = <path>`.

Verify the file exists using the Read tool:
- Exists → proceed to Step 2B.
- Not found → print a warning and proceed to Step 2B (snapshot synthesis may provide a fallback):
  ```
  ⚠ DB details file not found: <DB_DOC>
    Will attempt to synthesize connection config from schema-snapshot.json if available.
  ```

**Manual mode — fallback when no path in prompt:**

If no marker string is found (skill invoked directly via `/AIDLC-db:db-wire`) AND no snapshot
marker is present:

```
AskUserQuestion({
  questions: [{
    question: "Provide the full path to your DB details document, OR skip if you are supplying schema-snapshot.json + SP-catalog.json directly (connection config will be synthesized from the snapshot).",
    header: "DB Document",
    multiSelect: false,
    options: [
      {
        label: "Paste file path",
        description: "Absolute path to a JSON db-details file or plain-text architecture document"
      },
      {
        label: "Synthesize from snapshot files",
        description: "Supply schema_snapshot_path + sp_catalog_path in aidlc.config.json — connection config is read from schema-snapshot.json automatically"
      },
      {
        label: "Skip — no DB wiring",
        description: "Leave datasource config as placeholder values. Re-run this stage later."
      }
    ]
  }]
})
```

- **Skip** → print `⚠ DB wiring skipped.` and **Stop.**
- **Path provided** → verify file exists. If missing, ask again. Set `DB_DOC = <path>`.
- **Synthesize from snapshot** → `DB_DOC` remains unset; synthesis happens in Step 2C.

### Step 2B — Detect pre-existing schema and SP catalog artifacts

Scan the worker prompt for two optional markers injected from `aidlc.config.json`:

**Schema snapshot marker:**
```
Schema snapshot path (pre-existing, pre-confirmed -- skip Phase 3 schema-reverse-engineer): <path>
```
If found:
- Extract `<path>` and verify the file exists using the Read tool.
- Exists → copy the file to `<SCHEMA_DIR>/schema-snapshot.json` using the Write tool (read then write).
  Set `SKIP_PHASE_3 = true`.
  Print: `✓ Pre-existing schema-snapshot.json loaded from <path> — Phase 3 will be skipped.`
- Not found → print a warning and continue (Phase 3 will regenerate it):
  ```
  ⚠ schema_snapshot_path set in config but file not found: <path>
    Falling back to Phase 3 schema-reverse-engineer.
  ```

**SP catalog marker:**
```
SP catalog path (pre-existing, pre-confirmed -- skip Phase 4 procedure-introspector): <path>
```
If found:
- Extract `<path>` and verify the file exists using the Read tool.
- Exists → copy the file to `<SCHEMA_DIR>/SP-catalog.json` using the Write tool (read then write).
  Set `SKIP_PHASE_4 = true`.
  Print: `✓ Pre-existing SP-catalog.json loaded from <path> — Phase 4 will be skipped.`
- Not found → print a warning and continue (Phase 4 will regenerate it):
  ```
  ⚠ sp_catalog_path set in config but file not found: <path>
    Falling back to Phase 4 procedure-introspector.
  ```

> **Note:** Both markers are optional. If neither is present, Phases 3 and 4 run normally.

### Step 2C — Synthesize db-details from snapshot (when DB_DOC is not set)

**Trigger:** `SKIP_PHASE_3 = true` AND `DB_DOC` is not set (no `db_details_path` was supplied).

Read `<SCHEMA_DIR>/schema-snapshot.json` (already copied in Step 2B). Extract:

| Snapshot field | Maps to db-details field |
|---|---|
| `host` | Split on `:` → `server` (hostname part), `port` (number part, default 1433) |
| `database` | `database_name` |
| `schema` | `schema_name` |
| `tables[].name` | `schema_snapshot.tables[]` |

Read `<SCHEMA_DIR>/SP-catalog.json` (already copied in Step 2B). Extract:

| Catalog field | Maps to db-details field |
|---|---|
| `procedures[].name` | `schema_snapshot.stored_procedures[]` |

Discover which epics have a datasource by globbing
`<API_OUTPUT>/src/main/java/**/config/DataSourceConfig.java` (written by `api-integrator`
Step 6). Use the parent directory name (the namespaced epic id, e.g. `epic1`) as the
`services[]` list — there is one `pom.xml` and one `application.yml` for the whole app now,
not one per entry.

Derive `env_var_prefix` from the first segment of `database_name` uppercased
(e.g. `CreditApp_MO` → `CREDITAPP`). If the database name is a single word, use it directly.

Build and write the synthesized file to `<SCHEMA_DIR>/db-details-synthesized.json`:

```json
{
  "databases": [
    {
      "id": "primary",
      "description": "Synthesized from schema-snapshot.json — <database_name> on <server>",
      "server": "<server>",
      "port": <port>,
      "database_name": "<database_name>",
      "schema_name": "<schema_name>",
      "driver": "sqlserver",
      "encrypt": true,
      "trust_server_certificate": false,
      "env_var_prefix": "<ENV_PREFIX>",
      "services": ["<module1>", "<module2>", "..."],
      "hikari": {
        "maximum_pool_size": 10,
        "minimum_idle": 2,
        "connection_timeout_ms": 30000
      }
    }
  ],
  "schema_snapshot": {
    "tables": ["<from snapshot tables[].name>"],
    "stored_procedures": ["<from SP-catalog procedures[].name>"]
  }
}
```

Set `DB_DOC = <SCHEMA_DIR>/db-details-synthesized.json`.

Print:
```
✓ db-details synthesized from schema-snapshot.json + SP-catalog.json
  Server   : <server>:<port>
  Database : <database_name>
  Schema   : <schema_name>
  Tables   : <N> tables
  Procs    : <N> stored procedures
  Services : <list>
  Written to: <SCHEMA_DIR>/db-details-synthesized.json
```

### Step 2D — Collect DB credentials for .env generation

**Worker mode — extract from prompt:**

Scan the worker prompt for pre-confirmed credential markers:
```
DB credentials (pre-confirmed — write to .env, skip AskUserQuestion for credentials): username=<value>
DB password (pre-confirmed — write to .env): <value>
```
If both markers are found, extract values and set `DB_CRED_USERNAME` and `DB_CRED_PASSWORD`.
Skip the `AskUserQuestion` below.

**Manual mode — fallback when no markers in prompt:**

If no credential markers are found (skill invoked directly, not via worker), ask the user:

```
AskUserQuestion({
  questions: [
    {
      question: "Enter the database username for <database_name> on <server>. This will be written to <API_OUTPUT>/.env — local dev only, move to cloud secrets before QA.",
      header: "DB Username",
      multiSelect: false,
      options: [
        { label: "Enter username", description: "Type the SQL Server login username (e.g. app_user, svc_creditapp)" }
      ]
    },
    {
      question: "Enter the database password for <database_name>. Stored in .env — local dev only.",
      header: "DB Password",
      multiSelect: false,
      options: [
        { label: "Enter password", description: "Paste the SQL Server password for the above user" }
      ]
    }
  ]
})
```

Store responses as `DB_CRED_USERNAME` and `DB_CRED_PASSWORD`.

Phase 5 (db-integrator) will use this synthesized file as `DB_DOC` and receive credentials
via the Task prompt to generate the actual `.env` file.

---

## Phase 3 — Schema Snapshot

> **Skip condition:** If `SKIP_PHASE_3 = true` (pre-existing `schema-snapshot.json` was copied to
> `<SCHEMA_DIR>` in Step 2B), print the message below and proceed directly to Phase 4:
> ```
> ⏭ Phase 3 skipped — using pre-existing schema-snapshot.json copied to <SCHEMA_DIR>/schema-snapshot.json
> ```

If `SKIP_PHASE_3` is not set, run:

```
Task(subagent_type: "AIDLC-db:schema-reverse-engineer", prompt: """
DB document path (already confirmed — skip Step 1 AskUserQuestion): <DB_DOC>

Parse the document for tbl* table names and sp*/SP_*/sp_* stored-procedure names.
Write schema snapshot to : <SCHEMA_DIR>/schema-snapshot.json
Write report to          : <SCHEMA_DIR>/SCHEMA-SNAPSHOT-REPORT.md

Follow Steps 2 → 3 → 4 → 5 of your standard flow.
""")
```

Wait for completion before Phase 4.

---

## Phase 4 — SP Catalog

> **Skip condition:** If `SKIP_PHASE_4 = true` (pre-existing `SP-catalog.json` was copied to
> `<SCHEMA_DIR>` in Step 2B), print the message below and proceed directly to Phase 5:
> ```
> ⏭ Phase 4 skipped — using pre-existing SP-catalog.json copied to <SCHEMA_DIR>/SP-catalog.json
> ```

If `SKIP_PHASE_4` is not set, run:

```
Task(subagent_type: "AIDLC-db:procedure-introspector", prompt: """
A schema-snapshot.json has been written at: <SCHEMA_DIR>/schema-snapshot.json

Use Step 1A — read stored_procedures[] from that file.
Do NOT ask the user for a document file path.

Write SP catalog to : <SCHEMA_DIR>/SP-catalog.json
Write report to     : <SCHEMA_DIR>/SP-CATALOG-REPORT.md

Follow Steps 1A → 3 → 4 → 5 of your standard flow.
""")
```

Wait for completion before Phase 4.5.

---

## Phase 4.5 — Generate Testcontainers Init Script

> **Skip condition:** If Phase 4 was skipped (pre-existing SP-catalog.json), also skip Phase 4.5.

Read `<SCHEMA_DIR>/schema-snapshot.json` to extract table schemas with columns and generate SQL Server DDL for Testcontainers.

```
Task(subagent_type: "AIDLC-db:schema-to-testcontainers", prompt: """
Read schema-snapshot.json from: <SCHEMA_DIR>/schema-snapshot.json

Generate SQL Server CREATE TABLE DDL for all tables with their columns, data types, and constraints.
Write to: <API_OUTPUT>/src/test/resources/schema/init.sql

This script will be used by springboot-test-generator with:
  .withInitScript("schema/init.sql")

Follow SQL Server syntax. Include:
  - All columns with correct data types (map snapshot types to SQL Server types)
  - Primary keys
  - NOT NULL constraints
  - DEFAULT values where specified
  - Indexes if present

Do NOT include stored procedures (Testcontainers tests use mocks for SPs).
""")
```

Print:
```
✓ Testcontainers init script generated
  Location: <API_OUTPUT>/src/test/resources/schema/init.sql
  Tables  : <N> tables from schema-snapshot.json
```

---

## Phase 5 — Wire DB into assembled API

Build the credential lines for the prompt:
- If `DB_CRED_USERNAME` was collected in Step 2D: include both credential lines.
- If credentials were not collected (manual mode with external db-details file): omit credential lines.

```
Task(subagent_type: "AIDLC-db:db-integrator", prompt: """
DB document path (already confirmed — skip Step 0 AskUserQuestion): <DB_DOC>
API output root: <API_OUTPUT>

Wire real database configuration into the single consolidated Spring Boot application
under <API_OUTPUT> — one pom.xml, one application.yml with namespaced per-epic
datasource blocks.
Validate and patch:
  - application.yml    (datasource URL, HikariCP pool, Flyway config)
  - .env.example       (DB_URL, DB_USER, DB_PASSWORD canonical block)
  - .env               (actual credentials — local dev only, DO NOT COMMIT)
  - docker-compose.yml (DB environment variables per service, env_file: - .env)
Cross-reference SP and table names from the document against Java source files.

[Include the following two lines only when DB_CRED_USERNAME is set:]
DB credentials (pre-confirmed — write to .env, skip AskUserQuestion for credentials): username=<DB_CRED_USERNAME>
DB password (pre-confirmed — write to .env): <DB_CRED_PASSWORD>

Write integration report to: <STAGE_DIR>/DB-INTEGRATION-REPORT.md

Follow Steps 1 → 11 of your standard flow.
""")
```

Wait for completion.

---

## Phase 5.5 — Generate DAOs (Conditional — Only When SP Catalog is Enriched)

Read `<SCHEMA_DIR>/SP-catalog.json` and check the `confidence` field.

**If `confidence = "enriched"`:**

The user has provided a fully enriched SP catalog with complete `parameters[]` and `result_columns[]`.
Generate stored-procedure DAOs to replace the `@Repository` stubs created by db-integrator.

```
Task(subagent_type: "AIDLC-springboot:stored-procedure-dao-generator", prompt: """
SP catalog path: <SCHEMA_DIR>/SP-catalog.json
API output root: <API_OUTPUT>

The SP-catalog.json has confidence="enriched" — all procedures have complete parameter and result column metadata.

Generate CallableStatement DAO implementations with explicit RowMapper classes for all stored procedures.
Replace @Profile("dev") stub interfaces generated by db-integrator with real implementations.

Write DAOs to: <API_OUTPUT>/src/main/java/**/dao/
Write RowMappers to: <API_OUTPUT>/src/main/java/**/dao/mapper/

Follow the family/variant pattern from the springboot-patterns documentation.
Include parameter binding and result set mapping for all procedures.

Write generation report to: <SCHEMA_DIR>/DAO-GENERATION-REPORT.md
""")
```

Print:
```
✓ DAO generation triggered (SP catalog is enriched)
  Catalog  : <SCHEMA_DIR>/SP-catalog.json
  Procedures: <N> stored procedures
  Output   : <API_OUTPUT>/src/main/java/**/dao/
  Report   : <SCHEMA_DIR>/DAO-GENERATION-REPORT.md
```

Set `DAO_STATUS = "PASSED"`.

**If `confidence = "names_only"` or missing:**

The SP catalog is a skeleton with procedure names only. DAO generation is blocked until the user enriches it.

Print:
```
⏭ DAO generation skipped — SP-catalog.json confidence="names_only"
  
  To enable DAO generation:
  1. Open <SCHEMA_DIR>/SP-catalog.json
  2. Add parameters[] and result_columns[] for each procedure
  3. Change confidence to "enriched"
  4. Re-run this stage
```

Set `DAO_STATUS = "BLOCKED"`.

---

## Phase 6 — Gate check and summary

Read `<STAGE_DIR>/DB-INTEGRATION-REPORT.md` for the gate result.

**If BLOCKED:**
```
✗ DB Wiring BLOCKED — unresolved errors in the integration report.
  Report : <STAGE_DIR>/DB-INTEGRATION-REPORT.md
  Fix the listed errors and re-queue this stage.
```

**If PASSED:**
```
✓ DB Wiring complete!

  Workspace : <wsId>

  Schema artifacts (<SCHEMA_DIR>):
    schema-snapshot.json   — <N> tables, <N> SPs  [pre-existing | generated]
    SP-catalog.json        — <N> procedures        [pre-existing | generated]

  Phases skipped (pre-existing artifacts used):
    Phase 3 schema-reverse-engineer : <skipped | ran>
    Phase 4 procedure-introspector  : <skipped | ran>

  API patches applied (<API_OUTPUT>):
    application.yml    — datasource / HikariCP / Flyway
    .env.example       — canonical DB variable block (REPLACE_WITH_ placeholders)
    .env               — actual credentials (local dev only, excluded from git)
    .gitignore         — .env entry added/verified
    docker-compose.yml — DB environment variables + env_file: - .env per service

  Reports:
    Schema  : <SCHEMA_DIR>/SCHEMA-SNAPSHOT-REPORT.md   (if Phase 3 ran)
    SPs     : <SCHEMA_DIR>/SP-CATALOG-REPORT.md         (if Phase 4 ran)
    DB Wire : <STAGE_DIR>/DB-INTEGRATION-REPORT.md

  Downstream gates:
    ✓ db-integrator   PASSED
    ✗ entity-mapper   BLOCKED — enrich schema-snapshot.json columns first
    <DAO_STATUS_SYMBOL> dao-generator   <DAO_STATUS> <DAO_STATUS_MESSAGE>

  Where:
    - If DAO_STATUS = "PASSED": symbol=✓, message="— DAOs generated from enriched SP-catalog.json"
    - If DAO_STATUS = "BLOCKED": symbol=✗, message="— enrich SP-catalog.json parameters first"
```

---

## Reporting to the AIDLC Platform (ECS UI tracking)

> **SERVER CLI GUARD:** If `aidlc.config.json` does **not** exist in your current
> working directory, skip this entire ECS section and run only Phases 1–6 above.
> These steps are for the **local launcher session only**.

The `db-wiring` ECS run is **created automatically by the pipeline** when
`epic-assemble` is approved — the launcher must **not** create a new run. This
section attaches to the existing run and monitors it until completion.

---

**Step 0 — Read config**
```powershell
$cfgPath = (Resolve-Path "aidlc.config.json" -ErrorAction Stop).Path
$cfg     = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
$BASE    = $cfg.central_base_url.TrimEnd('/')
$TOKEN   = [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env)
if (-not $TOKEN) {
    $relayFile = Join-Path (Split-Path $cfgPath) ".aidlc_token"
    if (Test-Path $relayFile) { $TOKEN = (Get-Content $relayFile -Raw -Encoding UTF8).Trim() }
}
$WS    = $cfg.workspace_id
$HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
$STAGE = "db-wiring"
```

**Step 0.1 — Token validation**
```powershell
function Get-JwtExpiry {
    param([string]$Token)
    try {
        $parts = $Token.Split('.')
        if ($parts.Count -lt 2) { return 0 }
        $payload = $parts[1]
        $mod = $payload.Length % 4
        if ($mod -ne 0) { $payload += '=' * (4 - $mod) }
        $json = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($payload))
        return [long]($json | ConvertFrom-Json).exp
    } catch { return 0 }
}

$TOKEN_VALID = $false
if ($TOKEN -and $TOKEN.StartsWith("eyJ")) {
    $exp = Get-JwtExpiry $TOKEN
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    if ($exp -eq 0 -or ($exp - $now) -gt 60) { $TOKEN_VALID = $true }
}
if (-not $TOKEN_VALID) {
    $refreshStore = Join-Path $env:APPDATA "aidlc-auth\refresh.dat"
    if (Test-Path $refreshStore) {
        Write-Host "✓ Stored Okta refresh token found — worker will auto-refresh. Proceeding..."
        $TOKEN_VALID = $true
    }
}
```

If `$TOKEN_VALID` is still `$false`, ask the user to paste a fresh token before continuing.

**Step 1 — Attach to the auto-created run**

The pipeline queues `db-wiring` automatically when `epic-assemble` is approved.
Find the active run — do NOT create a new one.

```powershell
$runs = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS&stage_key=$STAGE" -Headers $HDR).items
$RUN_ID = $null

# Prefer a run that is already claimed/running; fall back to queued
$active = $runs | Where-Object { $_.state -in @("running","claimed","queued") } |
          Sort-Object queued_at -Descending | Select-Object -First 1

if ($active) {
    $RUN_ID = $active.run_id
    Write-Host "Attaching to $STAGE run: $RUN_ID  (state=$($active.state)) — monitoring..."
} else {
    Write-Host "⚠ No active db-wiring run found for workspace $WS."
    Write-Host "  The pipeline creates this run automatically when epic-assemble is approved."
    Write-Host "  Approve the epic-assemble deliverable in ECS first, then re-run /launch."
    return
}
```

**Step 2 — Monitor until terminal state**
```powershell
do {
    Start-Sleep -Seconds 15
    $run     = (Invoke-RestMethod "$BASE/pipeline-runs/$RUN_ID" -Headers $HDR).run
    $elapsed = if ($run.started_at) {
        $s = [datetime]::Parse($run.started_at)
        $e = if ($run.finished_at) { [datetime]::Parse($run.finished_at) } else { Get-Date }
        "$([int]($e - $s).TotalSeconds)s"
    } else { "queued" }
    $files = if ($run.files_written) { $run.files_written.Count } else { 0 }
    Write-Host "  [$elapsed]  state=$($run.state)  files=$files"
} while ($run.state -notin @("waiting_for_approval","completed","failed","cancelled"))
```

**Step 3 — Final timing summary**
```powershell
$fmt = { param($t) if ($t) { [datetime]::Parse($t).ToLocalTime().ToString("HH:mm:ss") } else { "—" } }
$sec = if ($run.started_at -and $run.finished_at) {
    [int]([datetime]::Parse($run.finished_at) - [datetime]::Parse($run.started_at)).TotalSeconds
} else { 0 }
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
Write-Host "  Run     : $RUN_ID"
Write-Host "  Stage   : $STAGE"
Write-Host "  State   : $($run.state)"
Write-Host "  Queued  : $(& $fmt $run.queued_at)"
Write-Host "  Started : $(& $fmt $run.started_at)"
Write-Host "  Finished: $(& $fmt $run.finished_at)"
Write-Host "  Elapsed : ${sec}s"
Write-Host "  Files   : $($run.files_written.Count) written"
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
```

**Step 4 — Review in ECS UI**
```
https://poc-ecs-build-ui.npsdlchgapp.us-east-1.aws.aig.net/aidlc-platform-management/pipeline
```

Approval persona: **Architect**