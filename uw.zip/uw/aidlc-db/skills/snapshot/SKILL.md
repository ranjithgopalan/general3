---
name: snapshot
description: Capture a read-only schema and stored-procedure snapshot from an existing relational database, and publish the POM policy schema.
triggers:
  - "snapshot the schema"
  - "reverse engineer the database"
  - "discover schema"
  - "stored procedure signatures"
  - "AIDLC-db snapshot"
---

# AIDLC-db: snapshot

## Agent Invocation

Use the Task tool with `subagent_type="router"` and the following prompt:

"""
## User Request
$ARGUMENTS

## Intent: SNAPSHOT

1. Confirm the target is a NON-PRODUCTION copy. Stop and ask if it is production
   or unstated. "Read-only" prevents writes, not load.
2. Capture via `POST /api/v1/schema/snapshot`. Do not write SQL directly -- the
   service owns the statement-level read-only guard, and a second path to the
   database would be unguarded.
3. Capture parameter DIRECTIONS for every procedure. An OUT registered as IN
   produces code that compiles, runs and silently returns nothing.
4. Report how many procedure result shapes were undiscoverable, and name them.
   Silence here causes the DAO generator to invent a column list.
5. Publish `pom-schema.json`; AIDLC-opa hard-blocks without it.
6. Record the snapshot id and checksum in the summary.
"""

## Prerequisites

- A datasource registered in `datasources.yaml` with its password env var set
- The forward-engineering API reachable
- Confirmation that the target is a restored copy

---

## ECS Pipeline Stage Context

The `snapshot` skill is a **prerequisite** for the `db-integration` stage — it
does not directly own an ECS pipeline stage. After running a snapshot, the
schema data feeds into `api-code` (M7) and `db-integration` (M8), both of which
are executed by the **AIDLC-springboot: implement** skill.

When you are ready to report completion of the `db-integration` stage to ECS,
use the ECS reporting block in [AIDLC-springboot/skills/implement/SKILL.md](../../../AIDLC-springboot/skills/implement/SKILL.md)
with `$STAGE = "db-integration"`.

### Correct ECS Reporting Pattern (for reference)

The ECS does **not** expose `PATCH /pipeline-runs/{id}/status` or
`POST /pipeline-runs/{id}/deliverables`. The only supported completion path is:

1. Cancel any stale QUEUED run for the target stage (`worktree: null`)
2. Create a fresh run with `execute: true` + `force: true`
3. Poll until `waiting_for_approval`

See `AIDLC-springboot/skills/implement/SKILL.md` for the full PowerShell
implementation covering both `api-code` and `db-integration` stages.
