# Changelog - AIDLC-db

## **1.2.0** - Document mode only for schema and SP agents (2026-09-11)

### Changed

- `schema-reverse-engineer` rewritten to document mode only — no live DB, no
  service API. Reads a JSON or plain-text file, extracts `tbl*` table names and
  `sp*` SP names, writes `schema-snapshot.json` with `confidence: "names_only"`.
  Downstream gates (`entity-mapper`, `dao-generator`, `pom-schema`) BLOCKED until
  enriched; `db-integrator` OK (names sufficient for cross-reference validation).
- `procedure-introspector` rewritten to document mode only — reuses an existing
  `schema-snapshot.json` or reads the same document file. Produces `SP-catalog.json`
  with `confidence: "names_only"` and `dao_generator_gate: "BLOCKED"`. Prints a
  per-SP enrichment checklist with exact JSON format required.
- `router` updated: removed non-production gate; added document-file-first rule;
  updated refusals for document-only operation.
- `plugin.json` description and version updated to reflect document-driven approach.

## **1.1.0** - DB Integrator moved here (2026-09-11)

### Added

- `db-integrator` agent — wires authoritative DB configuration (datasource URL,
  HikariCP, Flyway, SP validation, `.env.example`, `docker-compose.yml`) into the
  assembled Spring Boot multi-module project after epic integration. Accepts a
  user-supplied DB details file in JSON (canonical) or plain-text (Format B) format.
  Moved from `AIDLC-integrator` so all DB-related work lives in one plugin.
- `db-integrator` entry in `router.md` routing matrix and Available Agents table.
- Keywords `db-integration` and `datasource-config` added to `plugin.json`.

### Changed

- Plugin description updated to mention integration-time DB config wiring alongside
  read-only reverse engineering.

---

## **1.0.0** - Initial release (2026-08-10)

### Added

- `router` with a non-production target gate. Capture is refused until the
  environment is confirmed, because read-only prevents writes but not load.
- `schema-reverse-engineer` - tables, columns, keys, indexes, procedure signatures
  with parameter directions, and the POM policy schema AIDLC-opa requires.
- `dictionary-and-erd` - data dictionary plus editable Draw.io ERD, split by
  subject area beyond ~25 tables.
- `entity-mapper` - JPA entity candidates, read-only by default, including an
  explicit list of tables that should NOT be mapped.
- `db-patterns` reference skill with `read-only-rules.md` and
  `procedure-signatures.md`.

### Design decisions

- **This plugin issues no SQL.** Capture goes through the forward-engineering
  service, which owns the statement-level guard. Two paths to the database would
  mean one of them is unguarded.
- **The guard is an allowlist, not a keyword blocklist.** A query naming
  `dbo.Customers` is rejected without anyone having predicted that table's name.
- **Undiscoverable result shapes are reported, not hidden.** A DAO generator given
  silence invents a column list, and a fabricated mapper fails in production.
- **Nullable numeric columns are flagged for business confirmation.** Null
  "unlimited" collapsing to zero "none" is a money defect.
