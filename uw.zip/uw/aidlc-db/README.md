# AIDLC-db

Read-only relational schema and stored-procedure reverse engineering for
modernization programmes.

## Why it exists

Stage 2 (FRD) needs schema ground truth, stage 9 (DB integration) needs
stored-procedure signatures, and stage 14 (OPA) needs a POM policy schema derived
from the data model. Nothing else in this estate captured stored-procedure
signatures over a live connection: the prior schema importer read
`INFORMATION_SCHEMA` tables and columns only, and procedure analysis came from
parsing `.sql` files and Excel exports.

## What it does NOT do

**It issues no SQL of its own.** Capture is delegated to the forward-engineering
service, which owns a statement-level read-only guard — an allowlist of
`INFORMATION_SCHEMA.*` and `sys.*` objects, so a query naming a business table is
rejected before reaching a driver. A second, unguarded path to the database would
defeat the point.

## Commands

| Skill | Purpose |
|-------|---------|
| `/AIDLC-db:snapshot` | Capture tables, columns, keys, indexes, procedure signatures; publish `pom-schema.json` |
| `/AIDLC-db:document` | Data dictionary and Draw.io ERD from a snapshot |
| `/AIDLC-db:explore` | Answer questions from a captured snapshot |

## Agents

| Agent | Produces |
|-------|----------|
| `router` | Routing, plus the non-production target gate |
| `schema-reverse-engineer` | Normalized schema JSON, procedure signatures, POM schema |
| `dictionary-and-erd` | Data dictionary (MD/DOCX) and editable Draw.io ERD |
| `entity-mapper` | JPA entity candidates, and which tables not to map |

## Prerequisites

1. A datasource in `datasources.yaml` with its password environment variable set.
   Credentials are referenced by name and never appear in the file.
2. The forward-engineering API reachable (default `http://localhost:8100`).
3. **Confirmation that the target is a restored copy.** The guard prevents writes,
   not load; a catalogue sweep across a large legacy schema is real work for the
   server.

## The three findings this plugin exists to surface

1. **Procedure parameter directions.** An `OUT` registered as `IN` produces code
   that compiles, runs and silently returns nothing.
2. **Undiscoverable result shapes.** A procedure built with dynamic SQL cannot be
   described by the catalogue. Reported and named — never papered over, because a
   DAO generator given silence invents a column list.
3. **Nullable numeric columns.** On a credit system a null limit often means
   "unlimited" while zero means "no facility". Every one is flagged for business
   confirmation.

## Refusals

- Production as the target
- Any `SELECT` against a business table
- Any DDL
- Working without a snapshot

## Validation

```bash
python scripts/validate-plugins.py --plugin AIDLC-db --verbose
```
