---
name: axis-version-constraints
description: Single source of truth for Axis framework and Angular version compatibility matrix — version-specific import rules, module patterns, and TypeScript path stubs. Apply before generating any Angular/Axis code.
---

# Axis Version Constraints

This file is the single source of truth for Axis framework and Angular version
compatibility. Every agent that generates Angular or Axis code MUST consult this
file before emitting imports, module declarations, or component patterns.

---

## Compatibility matrix

| Axis version | Angular version | Key constraint |
|---|---|---|
| 17.x.x | Angular 16 | Legacy — do not generate new code targeting this |
| 18.x.x | Angular 17 | Current UW Credit Risk target |
| 19.x.x | Angular 18 | Future — standalone components default |

---

## Rules

### Rule 1 — Always detect the Axis version from `package.json`

Before generating any Angular or Axis code, read the project's `package.json`
and extract the `@axis/components` version:

```bash
# Example lookup
grep '"@axis/components"' package.json
# → "@axis/components": "18.3.1"
```

Map the major version to the compatibility matrix above. Never assume a
default version. Never hardcode "Angular 18" or "Angular 17" in generated
code — always derive the Angular version from the Axis version in the matrix.

---

### Rule 2 — Axis 17.x.x (Angular 16) — Legacy

Do not generate new code that targets Axis 17.x.x / Angular 16. If the
detected version is 17.x.x, raise a warning to the user and confirm whether
they want legacy-compatible output before proceeding.

---

### Rule 3 — Axis 18.x.x (Angular 17) — AxisSharedModule is LOCAL

For Axis 18.x.x (Angular 17), `AxisSharedModule` is a **local module** defined
at `src/app/_shared/`. It must NOT be imported from `@axis/components`.

Correct:
```typescript
import { AxisSharedModule } from 'src/app/_shared/axis-shared.module';
// or the local barrel path configured for the project
```

Prohibited:
```typescript
import { AxisSharedModule } from '@axis/components'; // WRONG for Axis 18.x.x
```

Feature modules must import `AxisSharedModule` from the local path. Generating
an import from `@axis/components` for this type will cause a compilation error.

---

### Rule 4 — Axis 19.x.x (Angular 18) — Standalone components are default

For Axis 19.x.x (Angular 18), standalone components are the default pattern.
NgModule-based patterns are deprecated. Generated components must use the
`standalone: true` flag and import Axis components directly in their `imports`
array rather than via a shared module.

```typescript
@Component({
  standalone: true,
  imports: [AxisButtonComponent, AxisInputComponent, ...],
  ...
})
export class MyComponent { ... }
```

Do not generate `NgModule` declarations for new components when Axis 19.x.x is
detected unless the user explicitly requests NgModule compatibility.

---

### Rule 5 — `@axis/components` import alias is NEVER valid

The import alias `@axis/components` is never a valid direct import path for
shared modules, named component re-exports, or barrel imports in any Axis
version. Always use:

- The local `AxisSharedModule` path (Axis 18.x.x)
- Specific standalone component imports (Axis 19.x.x)

```typescript
// Prohibited in ALL versions:
import { SomeSharedThing } from '@axis/components';

// Correct for Axis 18.x.x:
import { AxisSharedModule } from 'src/app/_shared/axis-shared.module';

// Correct for Axis 19.x.x:
import { AxisButtonComponent } from '@axis/components/button'; // specific path
```

---

### Rule 6 — `@aig/point-http-client` requires a TypeScript path stub

The `@aig/point-http-client` package requires a `tsconfig` path stub before
TypeScript compilation succeeds. Add the following entry to `tsconfig.json`
(or `tsconfig.app.json`) under `compilerOptions.paths`:

```json
{
  "compilerOptions": {
    "paths": {
      "@aig/point-http-client": ["src/app/_stubs/point-http-client.stub.ts"]
    }
  }
}
```

Create the stub file at `src/app/_stubs/point-http-client.stub.ts` with the
minimal exported surface needed by the application. Without this stub the
Angular compiler will fail with a "cannot find module" error.

---

## Summary checklist

Before generating Axis/Angular code, confirm:

- [ ] `@axis/components` version read from `package.json`
- [ ] Angular version derived from compatibility matrix (not hardcoded)
- [ ] For Axis 18.x.x: `AxisSharedModule` imported from local `src/app/_shared/` path
- [ ] For Axis 19.x.x: `standalone: true` and direct component imports used
- [ ] `@axis/components` alias not used as a shared-module import path
- [ ] `@aig/point-http-client` path stub present in `tsconfig.json`
