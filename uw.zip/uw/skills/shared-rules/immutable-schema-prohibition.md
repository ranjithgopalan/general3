---
name: immutable-schema-prohibition
description: Shared prohibition rules for immutable-schema programmes — no DDL against existing objects. Apply across all AIDLC plugins (springboot, db, design) whenever the target relational schema is owned outside the application.
---

# Immutable Schema Prohibition Rules

These rules apply on any programme where the relational schema already exists
and the team has committed to leaving it unchanged. They are shared across all
AIDLC plugins and must be enforced by every agent that generates DDL, ORM
configuration, Flyway scripts, or batch job definitions.

---

## Prohibited operations (CRITICAL severity on violation)

1. **NEVER generate `ALTER`, `DROP`, or `TRUNCATE`** against any pre-existing
   table, column, index, or constraint. This includes:
   - `ALTER TABLE … ADD COLUMN`
   - `ALTER TABLE … DROP COLUMN`
   - `ALTER TABLE … MODIFY COLUMN`
   - `DROP TABLE`, `DROP INDEX`, `DROP CONSTRAINT`
   - `TRUNCATE TABLE`

2. **NEVER generate `CREATE TABLE`** for a table that already exists in
   `schema-snapshot.json`. Check the snapshot before emitting any `CREATE TABLE`
   statement. If the table name appears in the snapshot, the statement is
   prohibited.

3. **NEVER generate DDL inside a batch job, stored procedure, or Spring Boot
   startup** (`ApplicationRunner`, `CommandLineRunner`, `@PostConstruct`).
   Schema changes must go through the DBA-approved migration path only.

---

## ORM and migration configuration rules

4. **Flyway `flyway.clean` must always be disabled.**
   Every Flyway configuration file (including all Spring profiles) must contain:
   ```properties
   spring.flyway.clean-disabled=true
   ```
   or in YAML:
   ```yaml
   spring:
     flyway:
       clean-disabled: true
   ```
   There is no profile override that can enable `flyway.clean` on an
   immutable-schema programme.

5. **Spring JPA `ddl-auto` must be `none` or `validate`** — never `create`,
   `create-drop`, or `update`.
   ```properties
   spring.jpa.hibernate.ddl-auto=none
   ```
   A value of `update` will silently alter a production table the first time an
   entity mapping drifts from the physical schema.

6. **Spring Batch `BATCH_*` tables must be created in a SEPARATE datasource**,
   never in the application's immutable schema. Configure a dedicated batch job
   repository datasource (e.g. an in-memory H2 for local dev, a separate schema
   for production) so that Spring Batch never attempts to create or alter tables
   in the primary datasource.

---

## Detection and enforcement

Any generated file that contains one or more of the following patterns must be
flagged **CRITICAL** before the integration stage:

| Pattern | Reason |
|---|---|
| `ALTER TABLE` | Prohibited DDL against existing object |
| `DROP TABLE` | Prohibited DDL against existing object |
| `DROP INDEX` | Prohibited DDL against existing object |
| `TRUNCATE` | Prohibited DDL against existing object |
| `CREATE TABLE` (where table is in snapshot) | Duplicate definition of existing object |
| `ddl-auto=create` | ORM will re-create tables on startup |
| `ddl-auto=create-drop` | ORM will drop and re-create on startup |
| `ddl-auto=update` | ORM will silently alter columns on startup |
| `flyway.clean-disabled=false` | Enables schema wipe |
| `cleanDisabled: false` | Enables schema wipe (YAML form) |
| DDL in `ApplicationRunner`, `CommandLineRunner`, `@PostConstruct` | Schema mutation at startup |
| Spring Batch `BATCH_*` tables in primary schema | Batch metadata pollutes application schema |

The springboot-code-validator agent enforces these patterns automatically.
Violations must be resolved before the integration stage is approved.
