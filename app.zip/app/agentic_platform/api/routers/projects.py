"""Projects — one per the KB application (onboarding entry point).

`GET /projects` is what the console loads first: it answers "what can I work on,
and where has work started?". Every other view is scoped by the project chosen
here, then by a workspace within it.

Onboarding is `POST /projects` and does exactly one thing: open the project's
Global Workspace. The pipelines are shared templates, so there is nothing
per-project to copy — which is also why onboarding is idempotent and cheap.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from fastapi import APIRouter, Body, Depends, File, HTTPException, Form, Query, UploadFile
from pydantic import BaseModel, Field

from app.agentic_platform.api.security import current_principal
from app.agentic_platform.fe_core.auth.roles import Principal
from app.agentic_platform.fe_core.config import get_settings
from app.agentic_platform.fe_core.kb.gateway import build_gateway
from app.agentic_platform.fe_core.projects.service import ProjectOnboardingError, ProjectService
from app.agentic_platform.fe_core.store import get_store

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/projects", tags=["projects"])


def _service() -> ProjectService:
    settings = get_settings()
    return ProjectService(get_store(), build_gateway(settings),
                          settings.fe_pipeline_global)


@router.get("")
async def list_projects(
    principal: Principal = Depends(current_principal),
    lightweight: bool = Query(False, description="Skip per-project progress queries for faster list view"),
) -> dict:
    """the knowledge base's application catalogue joined with locally opened workspaces."""
    projects, warning = await _service().list_projects(lightweight=lightweight)
    payload = {
        "count": len(projects),
        "onboarded": sum(1 for p in projects if p.onboarded),
        "items": [p.to_dict() for p in projects],
    }
    if warning:
        # Say the list is partial. An empty or short list with no explanation
        # reads as "there are no projects", which is a different fact entirely.
        payload["degraded"] = warning
    return payload


@router.get("/{kb_application_id}")
async def get_project(
    kb_application_id: str,
    principal: Principal = Depends(current_principal),
) -> dict:
    projects, warning = await _service().list_projects()
    match = next(
        (p for p in projects if p.kb_application_id == kb_application_id), None)
    if match is None:
        raise HTTPException(
            status_code=404,
            detail=(f"no project '{kb_application_id}'."
                    + (f" {warning}" if warning else "")),
        )
    body = match.to_dict()
    body["workspaces"] = [
        {
            "id": w.id, "tier": w.tier.value, "label": w.label,
            "epic_id": w.epic_id, "epic_title": w.epic_title,
            "status": w.status.value,
        }
        for w in get_store().list_workspaces(kb_application_id)
    ]
    return body


@router.delete("/{kb_application_id}", status_code=200)
async def delete_project(
    kb_application_id: str,
    principal: Principal = Depends(current_principal),
) -> dict:
    """Delete a project's local state (workspaces, runs, artefacts, approvals).

    This removes everything this service has recorded for the project. The KB
    application entry in the knowledge base's catalogue is **not** touched —
    the project will reappear in the list from the catalogue and can be
    re-onboarded cleanly.

    Returns 404 when the project was never onboarded here (nothing to delete).
    """
    deleted = _service().delete(kb_application_id)
    if deleted == 0:
        raise HTTPException(
            status_code=404,
            detail=(
                f"project '{kb_application_id}' has no local state here "
                "(it may exist in the KB catalogue but was never onboarded)."
            ),
        )
    return {
        "kb_application_id": kb_application_id,
        "deleted": True,
        "workspaces_removed": deleted,
    }


class OnboardRequest(BaseModel):
    kb_application: str = Field(
        description=(
            "KB application name or id, as it appears in the knowledge base. This is the "
            "project: its code knowledge, business specs and schema all hang "
            "off it."
        ),
    )
    category: str = Field(
        default="brownfield",
        description=(
            "greenfield (no legacy system; requirements only) or brownfield "
            "(a legacy system exists). Recorded rather than inferred: for a "
            "greenfield project 'no code knowledge' is correct and expected, "
            "while for a brownfield one it means indexing has not finished."
        ),
    )
    intake_source: str = Field(
        default="existing-kb",
        description="requirements | reverse-engineering | git-repository | existing-kb | re-graph",
    )
    source_language: str | None = Field(
        default=None,
        description=(
            "Brownfield only: vb6-vba | vbscript-asp | mainframe. Recorded because "
            "'no code knowledge' then has a known cause instead of looking like an "
            "indexing failure."
        ),
    )
    target_framework: str | None = Field(
        default=None,
        description=(
            "angular-springboot | angular-fastapi. Decides which generators the "
            "code stages need, so a mismatch with the configured pipeline is "
            "reported here rather than eight stages later."
        ),
    )
    gear_id: str | None = Field(
        default=None,
        description=(
            "Application gear identifier for RE Graph context (e.g. 'japan'). "
            "If not provided, falls back to settings.GEAR_ID."
        ),
    )


@router.post("", status_code=201)
async def onboard_project(
    body: OnboardRequest = Body(...),
    principal: Principal = Depends(current_principal),
) -> dict:
    """Onboard a project: resolve its KB application and open the Global Workspace.

    Idempotent — the Global Workspace id is derived from the application id, so
    onboarding twice returns the same project rather than creating a second.
    """
    from app.agentic_platform.fe_core.projects.intake import (
        IntakeError,
        IntakeSource,
        ProjectCategory,
        describe,
        validate,
    )

    # Validate the pairing before touching the KB: a greenfield project onboarded
    # from a reverse-engineering report describes a system that does not exist.
    try:
        category = ProjectCategory(body.category)
        source = IntakeSource(body.intake_source)
        validate(category, source)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except IntakeError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    # Parsed before onboarding so an unknown value is a 422 about the request
    # rather than a stack unwind from inside the store.
    try:
        from app.agentic_platform.fe_core.projects.stacks import SourceLanguage, TargetFramework

        language = SourceLanguage(body.source_language) if body.source_language else None
        target = TargetFramework(body.target_framework) if body.target_framework else None
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    try:
        summary = await _service().onboard(
            body.kb_application,
            intake_source=source.value,
            intake={
                "category": category.value,
                "source_language": language.value if language else None,
                "target_framework": target.value if target else None,
                "gear_id": body.gear_id,
            },
        )
    except ProjectOnboardingError as exc:
        # 422: the request named something that cannot be resolved. Distinguished
        # from 503 because retrying an unknown application will never succeed.
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    payload = summary.to_dict()
    payload["category"] = category.value
    payload["intake_source"] = source.value
    payload["intake_note"] = describe(category, source)

    # Source and target, plus whether the configured pipeline can actually build
    # that target. Reported at onboarding: discovering it at the API stage means
    # the wrong language has already been generated.
    if language or target:
        from app.agentic_platform.fe_core.pipeline.registry import get_pipeline
        from app.agentic_platform.fe_core.projects.stacks import SOURCES, TARGETS, alignment
        from app.agentic_platform.fe_core.projects.stacks import describe as describe_stack

        payload["source_language"] = language.value if language else None
        payload["target_framework"] = target.value if target else None
        payload["stack_note"] = describe_stack(language, target)
        if language:
            payload["source_profile"] = {
                "label": SOURCES[language].label,
                "extensions": list(SOURCES[language].extensions),
                "note": SOURCES[language].note,
            }
        if target:
            settings = get_settings()
            declared: set[str] = set()
            for name in (settings.fe_pipeline_global, settings.fe_pipeline_mini):
                try:
                    declared |= set(get_pipeline(name).required_plugins())
                except Exception:  # noqa: BLE001
                    pass
            missing = alignment(target, declared)
            payload["target_profile"] = {
                "label": TARGETS[target].label,
                "ui": TARGETS[target].ui,
                "api": TARGETS[target].api,
                "tdd_agent": TARGETS[target].tdd_agent,
                "note": TARGETS[target].note,
            }
            payload["agents_aligned"] = not missing
            payload["missing_generators"] = missing
            if missing:
                payload["alignment_warning"] = (
                    f"the configured pipeline does not declare {', '.join(missing)}, "
                    f"which {TARGETS[target].label} needs. The code stages will "
                    "fail until those generators exist and the pipeline names them."
                )
    return payload


_embedding_drains: dict[str, "threading.Thread"] = {}


def _start_embedding_drain(settings, project_id: str) -> None:
    """Embed a project's remaining chunks in a daemon thread, one drain per project."""
    import threading  # noqa: PLC0415

    live = _embedding_drains.get(project_id)
    if live is not None and live.is_alive():
        return

    def _run() -> None:
        try:
            from app.agentic_platform.fe_core.rag.indexer import Indexer  # noqa: PLC0415
            from app.agentic_platform.fe_core.rag.retriever import ChunkStore  # noqa: PLC0415

            store = ChunkStore(settings.fe_db_url, settings.fe_db_schema)
            n = Indexer(store).embed_all(project_id)
            logger.info("Embedding drain finished for %s: %d chunk(s)", project_id, n)
        except Exception:  # noqa: BLE001
            logger.exception("Embedding drain failed for %s", project_id)

    t = threading.Thread(target=_run, name=f"embed-drain-{project_id}", daemon=True)
    _embedding_drains[project_id] = t
    t.start()


@router.post("/{kb_application_id}/documents", status_code=202)
async def upload_reverse_engineering_document(
    kb_application_id: str,
    file: UploadFile = File(...),
    document_kind: str = Form(
        default="reverse-engineering",
        description="requirements | reverse-engineering | business-spec | schema-export | target-architecture | sp-catalog",
    ),
    principal: Principal = Depends(current_principal),
) -> dict:
    """Seed a project's knowledge with an uploaded document.

    The second onboarding path. Linking an existing the KB application assumes
    the legacy system has already been reverse-engineered into the KB; for a
    project where it has not, this is how the starting knowledge arrives.

    Ingested at authority tier **C**, not D: a reverse-engineering report is
    documentary evidence produced by a tool against real source, which outranks
    unverified LLM output. It is still below A/B, because it is a derived summary
    rather than the source itself.

    Returns 202: the document is handed to the knowledge base and ingestion (chunking and
    embedding) continues asynchronously. Blocking here would make a slow KB look
    like a failed upload.
    """
    from app.agentic_platform.fe_core.rag.extract import UnreadableUpload, extract_text

    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=422, detail="the uploaded file is empty")

    # .docx is unwrapped rather than refused: a RED report is delivered as one, and
    # "not UTF-8" was true about the bytes and useless about the intent.
    # Off the event loop: extraction is CPU-bound and a large .docx blocked every
    # other request (including the dashboard's project list) while it ran.
    try:
        text, how = await asyncio.to_thread(extract_text, raw, file.filename or "upload")
    except UnreadableUpload as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    # Resolved against projects onboarded HERE first, and only then against the
    # catalogue. The order matters: this document is the project's knowledge, so
    # requiring the project to already exist in a reverse-engineering catalogue
    # refused the upload for exactly the projects that need it most -- a greenfield
    # project is never in that catalogue, and a brownfield one being seeded from a
    # RED report is not in it yet either.
    from app.agentic_platform.fe_core.projects.models import local_project_id
    from app.agentic_platform.fe_core.workspaces.models import global_workspace_id

    store_ = get_store()
    # Resolve the workspace the same way onboarding derived its id (a lowercase
    # slug), so a name with uppercase or underscores ("Ranjith_new" ->
    # "ranjith-new") still finds its Global Workspace instead of falling through to
    # the KB catalogue (which, when down, stalls on the read timeout then 404s).
    # The raw-id lookup is kept as a fallback for any project stored under it.
    _local_id = local_project_id(kb_application_id)
    workspace = (store_.get_workspace(global_workspace_id(_local_id))
                 or store_.get_workspace(global_workspace_id(kb_application_id)))
    project_id = workspace.kb_application_id if workspace is not None else None

    if project_id is None:
        onboarded = sorted(
            w.kb_application_id for w in store_.list_workspaces() if w.is_global)
        raise HTTPException(
            status_code=404,
            detail=(
                f"no project '{kb_application_id}' found locally. "
                f"Onboarded projects: "
                    f"{', '.join(onboarded) or '(none)'}. Onboard it first — the "
                    "upload attaches to a project, so there has to be one."
                ),
            )

    # Index into THIS service's corpus first, because that is what the chat and
    # the stage prompts actually read. Publishing onward to the knowledge base is
    # a mirror, and a platform version without an ingest endpoint must not make an
    # upload fail -- the document is usable here either way.
    source_path = f"upload://{document_kind}/{file.filename or 'document'}"
    indexed = {"chunks": 0, "embedded": 0, "detail": ""}

    # Keep the raw upload as corpus for the reverse-engineering (card KB) pipeline:
    # workspaces/<app>/corpus/<kind>/<filename>. The chunk index below is what
    # chat and stage prompts read; the card KB builder needs the source itself
    # (page/section loci) to write evidence-anchored cards. Non-fatal.
    try:
        corpus_dir = get_settings().corpus_root_for(project_id) / document_kind
        corpus_dir.mkdir(parents=True, exist_ok=True)
        safe_name = Path(file.filename or "document").name
        (corpus_dir / safe_name).write_bytes(raw)
    except Exception as exc:  # noqa: BLE001
        logger.warning("could not keep raw upload as corpus: %s", exc)
    try:
        from app.agentic_platform.fe_core.rag.chunker import chunk as chunk_text
        from app.agentic_platform.fe_core.rag.indexer import Indexer
        from app.agentic_platform.fe_core.rag.retriever import ChunkStore

        settings = get_settings()
        if not settings.uses_database():
            indexed["detail"] = (
                "not indexed: retrieval needs Postgres. Set FE_DB_URL and run "
                "`python run.py db-apply`."
            )
        else:
            # A large RED document chunks into tens of thousands of rows and
            # then embeds them via Bedrock — minutes of CPU and I/O. Run it in
            # a worker thread: done inline it pins the event loop and the whole
            # API (health checks included) goes silent until the upload ends.
            def _index_sync() -> tuple[int, int, str]:
                store = ChunkStore(settings.fe_db_url, settings.fe_db_schema)
                chunks = chunk_text(text, document_kind, source_path)
                written = store.replace_chunks(
                    project_id=project_id,
                    source_path=source_path,
                    chunks=chunks,
                    artifact_type=document_kind,
                )
                try:
                    embedded = Indexer(store).embed_pending(project_id)
                    return written, embedded, ""
                except Exception as exc:  # noqa: BLE001
                    # Chunks without embeddings are still found by keyword
                    # search, so this degrades retrieval, not the upload.
                    return written, 0, f"embedding deferred: {exc}"

            written, embedded, deferred = await asyncio.to_thread(_index_sync)
            indexed["chunks"] = written
            indexed["embedded"] = embedded
            if deferred:
                indexed["detail"] = deferred
            elif embedded and embedded < written:
                # The first pass is capped so this response returns in bounded
                # time; the rest is drained in a daemon thread. Semantic search
                # covers more of the document as it progresses; keyword search
                # covers all of it from the start.
                _start_embedding_drain(settings, project_id)
                indexed["detail"] = (
                    f"{embedded} of {written} chunks embedded; the remainder is "
                    "being embedded in the background")
    except Exception as exc:  # noqa: BLE001
        logger.exception("Local indexing failed for %s", file.filename)
        indexed["detail"] = f"indexing failed: {exc}"

    # Durable copy: raw + canonical Markdown into the ArtifactStore as an APPROVED
    # `input-<kind>` artefact (tier C) and an `intake_ready` outbox event, so every
    # stage can materialise the document and an orchestrator can start from it.
    stored: dict = {"ok": False, "detail": ""}
    try:
        from app.agentic_platform.fe_core.artifacts.intake import register_input_document  # noqa: PLC0415

        settings = get_settings()
        art = await asyncio.to_thread(
            register_input_document,
            store=store_, settings=settings, project_id=project_id,
            workspace_id=(workspace.id if workspace is not None else global_workspace_id(project_id)),
            pipeline=(workspace.pipeline if workspace is not None else settings.fe_pipeline_global),
            filename=file.filename or "document", document_kind=document_kind, raw=raw,
            canonical_md=text, extracted_as=how, uploaded_by=principal.email or principal.subject,
        )
        stored = {"ok": True, "artifact_id": art.id, "artifact_type": art.artifact_type,
                  "version": art.version, "content_uri": art.content_uri, "storage_kind": art.storage_kind}
    except Exception as exc:  # noqa: BLE001
        logger.exception("Intake artefact registration failed for %s", file.filename)
        stored["detail"] = f"not stored as artefact: {exc}"

    if not indexed["chunks"] and not stored["ok"]:
        # Nothing anywhere is a genuine failure.
        raise HTTPException(
            status_code=503,
            detail=(
                f"'{file.filename}' was read ({len(text):,} chars via {how}) but "
                f"stored nowhere. {indexed['detail']}"
            ),
        )

    return {
        "kb_application_id": project_id,
        "filename": file.filename,
        "document_kind": document_kind,
        "characters": len(text),
        "extracted_as": how,
        "authority_tier": "C",
        "indexed": indexed,
        "stored": stored,
    }


class RepositoryRequest(BaseModel):
    git_url: str = Field(
        description=(
            "https or scp-style ssh URL. Other schemes are refused because a "
            "clone executes remote configuration in some setups."
        ),
    )
    branch: str | None = Field(default=None, description="Defaults to the remote HEAD.")


@router.post("/{kb_application_id}/repository", status_code=202)
async def attach_repository(
    kb_application_id: str,
    body: RepositoryRequest = Body(...),
    principal: Principal = Depends(current_principal),
) -> dict:
    """Register a brownfield project's source repository.

    This records the repository as a KB source and returns 202. It does **not**
    index the code: that is the knowledge base's RED engine, which parses VB6/ASP/COBOL/Java and
    writes code knowledge. Until RED has run, the G1 PRD will report the
    code surface as unavailable rather than inferring a current state -- which is
    the honest outcome, and the reason the repository is recorded with its
    indexing status rather than silently accepted.
    """
    from app.agentic_platform.fe_core.projects.intake import IntakeError, normalise_git_url

    try:
        url = normalise_git_url(body.git_url)
    except IntakeError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    raise HTTPException(
        status_code=501,
        detail=(
            f"Repository registration via the KB REST API is not available. "
            f"Validated URL: {url}. Configure the KB backend to use this feature."
            ),
        )
