"""Turn an uploaded file into text the chunker can use.

A reverse-engineering report arrives as `.docx` -- 994 paragraphs and 99 tables in
the report this was written against. Refusing it as "not UTF-8" was correct about
the bytes and useless about the intent, so the container is unwrapped here rather
than at each call site.

Tables are rendered as Markdown pipes deliberately: both the markdown and tabular
chunkers understand that shape, so a table keeps its header when it is split. A
RED report is mostly tables, so losing them would lose most of the content.
"""

from __future__ import annotations

import io
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

ZIP_MAGIC = b"PK\x03\x04"
PDF_MAGIC = b"%PDF-"


class UnreadableUpload(ValueError):
    """The file cannot be turned into text. Surfaced as 422."""


#: Formats the intake path accepts, and how each becomes canonical Markdown.
SUPPORTED_SUFFIXES = (".docx", ".pdf", ".xlsx", ".xlsm", ".csv", ".pptx", ".drawio",
                      ".md", ".markdown", ".txt", ".html", ".htm", ".json", ".yaml", ".yml")


def extract_text(data: bytes, filename: str) -> tuple[str, str]:
    """Return (canonical_markdown, how). Raises UnreadableUpload when there is no text.

    Every container format is unwrapped to Markdown so the same chunkers, the
    same prompt inlining and the same evidence-citation rules apply regardless
    of how the document arrived. Tables become pipe tables; diagrams become a
    node/edge listing; spreadsheets become one pipe table per sheet.
    """
    suffix = Path(filename or "").suffix.lower()

    if suffix == ".pdf" or data[:5] == PDF_MAGIC:
        return _pdf(data, filename), "pdf"
    if suffix in (".xlsx", ".xlsm"):
        return _xlsx(data, filename), "xlsx"
    if suffix == ".pptx":
        return _pptx(data, filename), "pptx"
    if suffix == ".drawio" or (suffix in (".xml",) and b"<mxfile" in data[:2000]):
        return _drawio(data, filename), "drawio"
    if suffix == ".csv":
        return _csv(data, filename), "csv"
    if suffix == ".docx" or data[:4] == ZIP_MAGIC:
        return _docx(data, filename), "docx"
    if suffix in (".html", ".htm"):
        return _html(data, filename), "html"

    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise UnreadableUpload(
            f"'{filename}' is neither UTF-8 text nor a supported document "
            f"({', '.join(SUPPORTED_SUFFIXES)}). Ingesting undecodable bytes would put "
            "replacement characters into the corpus, and retrieval would later cite "
            "them as grounding."
        ) from exc
    return text, "utf-8"


# ---------------------------------------------------------------------------
# additional formats (Phase 2 intake)
# ---------------------------------------------------------------------------
def _pdf(data: bytes, filename: str) -> str:
    try:
        from pypdf import PdfReader  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover
        raise UnreadableUpload("reading .pdf needs pypdf. Run: pip install pypdf") from exc
    try:
        reader = PdfReader(io.BytesIO(data))
    except Exception as exc:  # noqa: BLE001
        raise UnreadableUpload(f"'{filename}' is not a readable PDF: {exc}") from exc
    parts: list[str] = [f"# {Path(filename).stem}"]
    empty = 0
    for i, page in enumerate(reader.pages, start=1):
        try:
            text = (page.extract_text() or "").strip()
        except Exception:  # noqa: BLE001
            text = ""
        if not text:
            empty += 1
            continue
        parts.append(f"\n## Page {i}\n\n{text}")
    if len(parts) == 1:
        raise UnreadableUpload(
            f"'{filename}' contains no extractable text ({empty} page(s) look like scans). "
            "Run OCR or export a text PDF / .docx first."
        )
    if empty:
        parts.append(f"\n> {empty} page(s) had no extractable text (likely images).")
    return "\n".join(parts)


def _table_md(rows: list[list[str]]) -> str:
    rows = [[("" if c is None else str(c)).replace("|", "\\|").replace("\n", " ").strip() for c in r] for r in rows]
    if not rows:
        return ""
    width = max(len(r) for r in rows)
    rows = [r + [""] * (width - len(r)) for r in rows]
    head, body = rows[0], rows[1:]
    out = ["| " + " | ".join(head) + " |", "|" + "---|" * width]
    out += ["| " + " | ".join(r) + " |" for r in body]
    return "\n".join(out)


def _xlsx(data: bytes, filename: str) -> str:
    try:
        import openpyxl  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover
        raise UnreadableUpload("reading .xlsx needs openpyxl. Run: pip install openpyxl") from exc
    try:
        wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    except Exception as exc:  # noqa: BLE001
        raise UnreadableUpload(f"'{filename}' is not a readable workbook: {exc}") from exc
    parts = [f"# {Path(filename).stem}"]
    for ws in wb.worksheets:
        rows: list[list[str]] = []
        for row in ws.iter_rows(values_only=True):
            vals = ["" if v is None else str(v) for v in row]
            if any(v.strip() for v in vals):
                rows.append(vals)
        if not rows:
            continue
        parts.append(f"\n## Sheet: {ws.title}\n\n{_table_md(rows)}")
    if len(parts) == 1:
        raise UnreadableUpload(f"'{filename}' has no non-empty sheets.")
    return "\n".join(parts)


def _csv(data: bytes, filename: str) -> str:
    import csv  # noqa: PLC0415
    text = data.decode("utf-8-sig", errors="replace")
    rows = [r for r in csv.reader(io.StringIO(text)) if any(c.strip() for c in r)]
    if not rows:
        raise UnreadableUpload(f"'{filename}' is empty.")
    return f"# {Path(filename).stem}\n\n{_table_md(rows)}"


def _pptx(data: bytes, filename: str) -> str:
    try:
        from pptx import Presentation  # noqa: PLC0415
    except ImportError as exc:  # pragma: no cover
        raise UnreadableUpload("reading .pptx needs python-pptx. Run: pip install python-pptx") from exc
    try:
        prs = Presentation(io.BytesIO(data))
    except Exception as exc:  # noqa: BLE001
        raise UnreadableUpload(f"'{filename}' is not a readable presentation: {exc}") from exc
    parts = [f"# {Path(filename).stem}"]
    for i, slide in enumerate(prs.slides, start=1):
        lines: list[str] = []
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False) and shape.text_frame.text.strip():
                lines.extend(t for t in shape.text_frame.text.splitlines() if t.strip())
            if getattr(shape, "has_table", False):
                rows = [[c.text for c in r.cells] for r in shape.table.rows]
                lines.append(_table_md(rows))
        if lines:
            parts.append(f"\n## Slide {i}\n\n" + "\n".join(lines))
    if len(parts) == 1:
        raise UnreadableUpload(f"'{filename}' contains no text.")
    return "\n".join(parts)


def _drawio(data: bytes, filename: str) -> str:
    """Draw.io: one section per diagram tab, listing shapes (labels) and edges.

    Compressed diagrams (base64 + raw deflate + URL-encoding) are inflated.
    """
    import base64  # noqa: PLC0415
    import html as _html_mod  # noqa: PLC0415
    import re  # noqa: PLC0415
    import urllib.parse  # noqa: PLC0415
    import zlib  # noqa: PLC0415
    import xml.etree.ElementTree as ET  # noqa: PLC0415

    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise UnreadableUpload(f"'{filename}' is not a readable draw.io/XML file: {exc}") from exc

    def _plain(v: str) -> str:
        v = _html_mod.unescape(v or "")
        v = re.sub(r"<br\s*/?>", " ", v)
        v = re.sub(r"<[^>]+>", " ", v)
        return re.sub(r"\s+", " ", v).strip()

    parts = [f"# {Path(filename).stem}"]
    diagrams = root.findall(".//diagram") or [root]
    for idx, dia in enumerate(diagrams, start=1):
        name = dia.get("name") or f"Diagram {idx}"
        model = dia.find(".//mxGraphModel")
        if model is None and (dia.text or "").strip():
            try:
                raw = base64.b64decode(dia.text.strip())
                inflated = zlib.decompress(raw, -15).decode("utf-8")
                model = ET.fromstring(urllib.parse.unquote(inflated))
            except Exception:  # noqa: BLE001
                model = None
        if model is None:
            continue
        cells = {c.get("id"): c for c in model.iter("mxCell")}
        nodes, edges = [], []
        for c in cells.values():
            label = _plain(c.get("value", ""))
            if c.get("edge") == "1":
                src = _plain(cells.get(c.get("source"), ET.Element("x")).get("value", "")) or c.get("source", "?")
                dst = _plain(cells.get(c.get("target"), ET.Element("x")).get("value", "")) or c.get("target", "?")
                edges.append(f"- {src} -> {dst}" + (f" : {label}" if label else ""))
            elif c.get("vertex") == "1" and label:
                nodes.append(f"- {label}")
        parts.append(f"\n## Tab: {name}\n\n### Shapes\n" + ("\n".join(nodes) or "- (none)")
                     + "\n\n### Connections\n" + ("\n".join(edges) or "- (none)"))
    if len(parts) == 1:
        raise UnreadableUpload(f"'{filename}' has no readable diagrams.")
    return "\n".join(parts)


def _html(data: bytes, filename: str) -> str:
    import html as _html_mod  # noqa: PLC0415
    import re  # noqa: PLC0415
    text = data.decode("utf-8-sig", errors="replace")
    text = re.sub(r"(?is)<(script|style).*?</\1>", "", text)
    text = re.sub(r"(?i)<h([1-6])[^>]*>", lambda m: "\n" + "#" * int(m.group(1)) + " ", text)
    text = re.sub(r"(?i)</(p|div|li|tr|h[1-6])>", "\n", text)
    text = re.sub(r"(?i)<br\s*/?>", "\n", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = _html_mod.unescape(text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n\n", text).strip()
    if not text:
        raise UnreadableUpload(f"'{filename}' contains no text.")
    return text


def _heading_level(style_name: str) -> int | None:
    """Markdown level for a Word style, or None when it is body text."""
    lowered = (style_name or "").lower()
    if lowered.startswith("title"):
        return 1
    if lowered.startswith("heading"):
        digits = "".join(c for c in lowered if c.isdigit())
        return min(int(digits), 6) if digits else 2
    return None


def _docx(data: bytes, filename: str) -> str:
    try:
        from docx import Document
    except ImportError as exc:
        raise UnreadableUpload(
            "reading .docx needs python-docx. Run: pip install python-docx"
        ) from exc

    try:
        document = Document(io.BytesIO(data))
    except Exception as exc:  # noqa: BLE001
        raise UnreadableUpload(
            f"'{filename}' is not a readable .docx: {exc}"
        ) from exc

    parts: list[str] = []
    table_count = 0

    # Build O(1) lookup maps to avoid O(n²) iteration
    para_map = {p._element: p for p in document.paragraphs}
    table_map = {t._tbl: t for t in document.tables}

    # Process elements in document order to preserve module→table relationships
    for element in document.element.body:
        tag = element.tag.split('}')[-1]  # Remove namespace

        if tag == 'p':  # Paragraph
            para = para_map.get(element)
            if para:
                text = para.text.strip()
                if not text:
                    continue
                level = _heading_level(para.style.name if para.style else "")
                # A Word heading becomes a Markdown heading, which is what gives the
                # markdown chunker its heading trail -- without it every chunk from an
                # 84,000-character report would be unattributed prose.
                parts.append(f"{'#' * level} {text}" if level else text)

        elif tag == 'tbl':  # Table
            table = table_map.get(element)
            if table:
                table_count += 1
                rows: list[list[str]] = []
                # `row.cells` rebuilds the whole table's merged-cell grid on every call,
                # which is quadratic in the row count and pinned the event loop for
                # minutes on a real RED report. Walk the raw <w:tc> elements once instead;
                # merged cells are then repeated per source column, which is fine for a
                # Markdown rendering.
                for tr in table._tbl.tr_lst:
                    cells = [
                        "\n".join(p.text for p in tc.p_lst).strip().replace("|", r"\|")
                        for tc in tr.tc_lst
                    ]
                    if any(cells):
                        rows.append(cells)
                if not rows:
                    continue
                width = max(len(r) for r in rows)
                rows = [r + [""] * (width - len(r)) for r in rows]

                parts.append("")
                parts.append(f"### Table {table_count}")
                parts.append("| " + " | ".join(rows[0]) + " |")
                parts.append("|" + "|".join(["---"] * width) + "|")
                for row in rows[1:]:
                    parts.append("| " + " | ".join(row) + " |")

    text = "\n\n".join(parts).strip()
    if not text:
        raise UnreadableUpload(
            f"'{filename}' opened as .docx but contained no text. It may be a scan, "
            "which needs OCR rather than extraction."
        )
    logger.info(
        "Extracted %d chars from %s (%d paragraphs, %d tables)",
        len(text), filename, len(document.paragraphs), len(document.tables),
    )
    return text
