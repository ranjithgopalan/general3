"""Architecture stage — context builder."""
