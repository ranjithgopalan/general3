---
name: worker
description: Directly monitors the AIDLC CLI worker. Invoked when the user types /worker. Auto-launches aidlc-worker.ps1 immediately without confirmation, then monitors the run until completion.
allowed-tools: Read Bash TodoWrite
arguments: []
---

# AIDLC CLI Worker Monitor

Launches the CLI worker immediately and monitors it. No confirmation prompt.

**Usage:**
```
/worker
```

The worker will:
1. Auto-launch `aidlc-worker.ps1` in a new PowerShell window
2. Monitor ECS for the active queued run in your workspace
3. Print progress every 15 seconds until completion

---

## Step 1 — Read Config

Read `aidlc.config.json` to get the ECS base URL and workspace ID:
```
Read({file_path: "./aidlc.config.json"})
```

Extract:
- `centralBaseUrl` = `central_base_url`
- `workspaceId` = `workspace_id`

If the file is missing, tell the user:
```
No aidlc.config.json found. Run /launch <workspace_id> first to configure.
```
and **END**.

---

## Step 2 — Auto-Launch Worker

Locate and launch the worker script immediately. No questions asked.

Run this using the Bash tool:
```powershell
$workerScript = Join-Path (Get-Location) "plugins\lib\common\aidlc-launcher\scripts\aidlc-worker.ps1"

if (-not (Test-Path $workerScript)) {
    Write-Host "ERROR: worker not found at $workerScript"
    exit 1
}

$tok  = $env:AIDLC_TOKEN -replace "'", "''"
$s    = $workerScript -replace "'", "''"
$cmd  = "-NoExit -Command `"`$env:AIDLC_TOKEN='$tok'; Write-Host 'AIDLC Worker v2.0 starting...'; & '$s'`""
Start-Process powershell -ArgumentList $cmd -WindowStyle Normal
Start-Sleep -Seconds 3
Write-Host "WORKER_LAUNCHED: $workerScript"
```

Tell the user:
```
✓ CLI Worker launched.
  Script : plugins\lib\common\aidlc-launcher\scripts\aidlc-worker.ps1
  Action : Polling ECS every 15 s — will claim the queued run automatically.

Monitoring ECS for workspace: [workspaceId]
Press Ctrl+C to stop monitoring.
```

---

## Step 3 — Monitor ECS Run

Poll the ECS API every 15 seconds until the run reaches a terminal state.

Use the Bash tool to run this monitoring loop:
```powershell
$cfg    = Get-Content "aidlc.config.json" | ConvertFrom-Json
$BASE   = $cfg.central_base_url.TrimEnd('/')
$WS     = $cfg.workspace_id
$HDR    = @{ Authorization = "Bearer $env:AIDLC_TOKEN"; "Content-Type" = "application/json" }
$done   = @("waiting_for_approval","completed","failed","cancelled")

Write-Host "Monitoring workspace: $WS"
Write-Host "ECS: $BASE"
Write-Host ""

while ($true) {
    try {
        $runs = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS" -Headers $HDR).items
        $active = $runs | Where-Object { $_.state -notin @("completed","cancelled") } |
                          Sort-Object -Property queued_at -Descending |
                          Select-Object -First 1
        if ($active) {
            $elapsed = if ($active.started_at) {
                $s = [datetime]::Parse($active.started_at)
                $e = if ($active.finished_at) { [datetime]::Parse($active.finished_at) } else { Get-Date }
                "$([int]($e - $s).TotalSeconds)s"
            } else { "queued" }
            $files = if ($active.files_written) { $active.files_written.Count } else { 0 }
            $ts    = (Get-Date).ToString("HH:mm:ss")
            Write-Host "[$ts]  run=$($active.run_id.Substring(0,8))  stage=$($active.stage_key)  state=$($active.state)  elapsed=$elapsed  files=$files"

            if ($active.state -in $done) {
                Write-Host ""
                Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                Write-Host "  Run     : $($active.run_id)"
                Write-Host "  Stage   : $($active.stage_key)"
                Write-Host "  State   : $($active.state)"
                Write-Host "  Files   : $($active.files_written.Count) written"
                Write-Host "  Elapsed : $elapsed"
                Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                break
            }
        } else {
            $ts = (Get-Date).ToString("HH:mm:ss")
            Write-Host "[$ts]  No active runs found for $WS — worker may not have claimed yet."
        }
    } catch {
        Write-Host "Poll error: $($_.Exception.Message)"
    }
    Start-Sleep -Seconds 15
}
```

---

## Step 4 — Final Status

When the loop exits, derive the dashboard URL from the config already read in Step 1
(same pattern as `launch/SKILL.md` Phase 1 Step 5 — never hardcode):

```powershell
$uri          = [System.Uri]$centralBaseUrl
$dashboardUrl = "$($uri.Scheme)://$($uri.Authority)/aidlc-platform-management/pipeline"
```

This resolves correctly for both modes:
- ECS mode (`central_base_url` = cloud URL) → ECS dashboard
- Local mode (`central_base_url` = `http://localhost:8080/...`) → local dashboard

Tell the user:

If `state = waiting_for_approval`:
```
✓ Stage complete — waiting for approver.
  Review deliverables at: [$dashboardUrl]
```

If `state = failed`:
```
✗ Stage failed. Check the worker window for error details.
  Run /launch [workspaceId] to retry.
```

If `state = completed`:
```
✓ Stage approved and completed.
  Run /launch [workspaceId] to advance to the next stage.
```

---

## Guardrails

```
OPERATIONAL_CONSTRAINTS[Type,Rules]:
  ALWAYS,"read aidlc.config.json before launching | auto-launch the worker immediately without asking | monitor ECS every 15 s | show run_id, stage_key, state, elapsed, files_written on each poll tick | print the ECS dashboard URL when terminal state is reached"
  NEVER,"ask the user for confirmation before launching the worker | skip monitoring after launch | invent run IDs or state values"
  STOP_AND_ASK,"aidlc.config.json is missing | AIDLC_TOKEN is not set | worker script not found at expected path"
```

---

## Version

**Version:** 2.0.0

**Changes in 2.0.0:**
- Removed `AskUserQuestion` confirmation step — worker launches immediately
- Added ECS monitoring loop with polling every 15 seconds
- Added terminal state detection and final status summary
