﻿---
name: launch
description: Zero-friction AIDLC pipeline launcher. Accepts a workspace ID, fetches the workspace bundle from the central API to auto-detect workspace type and current pipeline stage, auto-launches the CLI worker for CLI stages, then runs the correct plugin skill automatically — no menus required.
allowed-tools: Read Write Bash AskUserQuestion TodoWrite Skill
arguments: [workspace_id]
---

# AIDLC Pipeline Launcher

Provide a workspace ID and the launcher does the rest: it reads the ECS bundle,
determines the workspace type (Global / Architecture / Mini) and the stage that
is ready to run, **automatically launches the CLI worker** for CLI stages, then
invokes the correct plugin skill.

**Usage:**
```
/launch <workspace_id>
```

---

## Design Principle: Unified Execution

**The only difference between ECS and Local runs is the central API URL.**

Everything else is identical:
- Same worker execution
- Same temp directory structure: `%TEMP%\aidlc-ws\{wsId}\{stageKey}\`
- Same output location: `{temp-dir}\integration-output\`
- Same skill invocation
- Same polling and monitoring

**Config determines behavior:**
- `central_base_url: "http://localhost:8080/agentic_platform/api/v1/"` → Local mode (connects to local API)
- `central_base_url: "https://poc-aidlc-uw-credit-risk-agents.npsdlchgapp.us-east-1.aws.aig.net/agentic_platform/api/v1/"` → ECS mode (connects to cloud API)

## Manual Worker Launch (Standalone Execution)

To run the CLI worker independently:

```powershell
# Set your Okta token
$env:AIDLC_TOKEN = "eyJ..."  # Paste your Okta Bearer token

# Navigate to project root (wherever aidlc.config.json is located)
cd <your-project-root>

# Launch the worker
.\plugins\lib\common\aidlc-launcher\scripts\aidlc-worker.ps1
```

Example:
```powershell
$env:AIDLC_TOKEN = "eyJ..."
cd "C:\path\to\your\project\genai-aig-core-aidlc-platform-plugins-7419"
.\plugins\lib\common\aidlc-launcher\scripts\aidlc-worker.ps1
```

**The worker:**
- Reads `aidlc.config.json` for the central API URL (local or cloud)
- Polls the API every 15 seconds for queued runs
- Claims and executes pipeline stage skills in temp directory: `%TEMP%\aidlc-ws\{wsId}\{stageKey}\`
- Outputs code to: `{temp-dir}\integration-output\`
- Works identically for both local and ECS modes

Stays running until stopped (Ctrl+C).

---

## Phase 0 — Token Check

1. Tell the user: `Checking AIDLC_TOKEN...`

2. Check for an existing token — relay file, env var, then stored refresh token:
   ```powershell
   # 1. Relay file written by a previous launcher run
   $relayFile   = Join-Path (Get-Location) ".aidlc_token"
   $relayToken  = if (Test-Path $relayFile) { (Get-Content $relayFile -Raw -Encoding UTF8).Trim() } else { "" }

   # 2. Environment variable
   $envToken = $env:AIDLC_TOKEN

   # 3. DPAPI-encrypted refresh token written by aidlc-auth.ps1
   $refreshStore    = Join-Path $env:APPDATA "aidlc-auth\refresh.dat"
   $hasRefreshToken = Test-Path $refreshStore
   ```

   **Resolution order:**
   - `$relayToken` starts with `eyJ` → set `$env:AIDLC_TOKEN = $relayToken`, tell the user
     `✓ AIDLC_TOKEN loaded from .aidlc_token.` and proceed to Phase 1.
   - `$envToken` non-empty → tell the user `✓ AIDLC_TOKEN is set.` and proceed to Phase 1.
   - Both empty **and** `$hasRefreshToken` is `$true` → tell the user:
     ```
     ✓ Stored Okta refresh token found — the CLI worker will obtain an access token
       automatically at startup. No manual token needed. Proceeding...
     ```
     Proceed to Phase 1 immediately. (The worker calls `Invoke-OktaTokenRefresh` at boot.)
   - All three empty → ask:
     ```
     AskUserQuestion({
       questions: [{
         question: "AIDLC_TOKEN is not set. How would you like to authenticate?",
         header: "Okta Token",
         multiSelect: false,
         options: [
           { label: "Set up automatic token refresh (recommended)",
             description: "Run aidlc-auth.ps1 once — browser Okta login stores a refresh token. Worker auto-refreshes silently for up to 24 h. No manual token management ever again." },
           { label: "Paste token here",
             description: "Paste your Okta Bearer token now. Works for this session only — you will need to paste again when it expires (~1 hour)." },
           { label: "Set it manually and re-run",
             description: "Run in PowerShell:  $env:AIDLC_TOKEN='eyJ...'  then re-invoke /launch." }
         ]
       }]
     })
     ```

   ---

   ### Handler: "Set up automatic token refresh"

   1. Locate `aidlc-auth.ps1`:
      ```powershell
      $authScript = Join-Path (Get-Location) "plugins\lib\common\aidlc-launcher\scripts\aidlc-auth.ps1"
      Test-Path $authScript
      ```
      If not found → tell the user:
      ```
      ⚠ aidlc-auth.ps1 not found at plugins\lib\common\aidlc-launcher\scripts\.
        Pull the latest core-aidlc-v6 branch (git pull) and try again.
      ```
      **END.**

   2. Check whether Okta config is already saved:
      ```powershell
      $authCfgFile = Join-Path $env:APPDATA "aidlc-auth\auth-config.json"
      $savedCfg    = if (Test-Path $authCfgFile) { Get-Content $authCfgFile | ConvertFrom-Json } else { $null }
      ```
      - If `$savedCfg.okta_domain` and `$savedCfg.client_id` are both present → skip to step 4,
        tell the user:
        ```
        ✓ Using saved Okta config — domain: [okta_domain]  client_id: [client_id]
        ```
      - Otherwise → ask:
        ```
        AskUserQuestion({
          questions: [
            {
              question: "What is your Okta domain?",
              header: "Okta Domain",
              multiSelect: false,
              options: [
                { label: "aig.okta.com",        description: "Production Okta tenant (most users)" },
                { label: "aig.oktapreview.com", description: "Preview / non-prod Okta tenant" }
              ]
            },
            {
              question: "What is the OIDC app Client ID?",
              header: "Client ID",
              multiSelect: false,
              options: [
                { label: "Enter client ID",
                  description: "Paste the client_id from the Okta admin console (starts with 0oa...)" }
              ]
            }
          ]
        })
        ```
        Store as `$oktaDomain` and `$clientId`.

   3. Tell the user:
      ```
      Opening a browser window for Okta login.
      Complete sign-in and MFA, then return here — the launcher continues automatically.
      ```

   4. Launch `aidlc-auth.ps1` and **wait** for it to complete:
      ```powershell
      $authScript = Join-Path (Get-Location) "plugins\lib\common\aidlc-launcher\scripts\aidlc-auth.ps1"
      $domain  = if ($savedCfg.okta_domain) { $savedCfg.okta_domain } else { $oktaDomain }
      $client  = if ($savedCfg.client_id)   { $savedCfg.client_id   } else { $clientId   }
      $argStr  = "-NonInteractive -File `"$authScript`" -OktaDomain `"$domain`" -ClientId `"$client`""
      $proc    = Start-Process powershell -ArgumentList $argStr -PassThru -Wait
      ```

   5. After the process exits, verify the refresh token was stored:
      ```powershell
      $refreshStore = Join-Path $env:APPDATA "aidlc-auth\refresh.dat"
      Test-Path $refreshStore
      ```
      - **Exists** → tell the user:
        ```
        ✓ Okta authentication complete!
          Refresh token stored securely (Windows DPAPI — only your Windows user can decrypt it).
          The CLI worker will auto-refresh your access token for up to 24 hours.
        ```
        Proceed to Phase 1. (Worker calls `Invoke-OktaTokenRefresh` at boot — no token paste needed.)
      - **Missing** → browser flow did not complete:
        ```
        ⚠ Refresh token was not stored. Common causes:
          • Browser login did not complete (MFA timeout, cancelled)
          • Okta app does not have 'offline_access' scope enabled
          • Redirect URI http://localhost:9123/callback not registered in Okta app
          Ask your Okta admin to check the app settings, then try again.
          Falling back to manual token paste for this session.
        ```
        Continue with the **"Paste token here"** handler.

   ---

   ### Handler: "Paste token here"

   1. Receive the pasted token from the user's "Other" input.
   2. Run `export AIDLC_TOKEN="<token>"` (Bash).
   3. Write token to the relay file:
      ```
      Write({ file_path: "./.aidlc_token", content: "<token>" })
      ```
   4. Tell the user:
      ```
      ✓ AIDLC_TOKEN set for this session.
      ✓ Token saved to .aidlc_token — the CLI worker reads this file automatically.
      ⚠  Token expires in ~1 hour. Run .\plugins\lib\common\aidlc-launcher\scripts\aidlc-auth.ps1
         once to set up 24-hour auto-refresh and never paste tokens again.
      ```

   ---

   ### Handler: "Set it manually and re-run"

   Print the command and **END**:
   ```
   Run in PowerShell:
     $env:AIDLC_TOKEN = 'eyJ...'
   Then re-invoke:  /AIDLC-launcher:launch [workspaceId]
   ```

---

## Phase 1 — Resolve Central URL and Workspace ID

Goal: have `centralBaseUrl` and `workspaceId` ready before the API call.

1. **Read `aidlc.config.json`** if it exists:
   ```
   Read({file_path: "./aidlc.config.json"})
   ```
   Extract `central_base_url` → `existingUrl`. If the file is missing, set `existingUrl = null`.

2. **Resolve `centralBaseUrl`:**
   - If `$1` was provided as a skill argument AND `aidlc.config.json` has a `central_base_url`: use the existing URL silently.
   - If `aidlc.config.json` is missing or has no `central_base_url`: ask once:
     ```
     AskUserQuestion({
       questions: [{
         question: "What is the AIDLC platform base URL?",
         header: "Platform URL",
         multiSelect: false,
         options: [
           { label: "https://poc-aidlc-uw-credit-risk-agents.npsdlchgapp.us-east-1.aws.aig.net/agentic_platform/api/v1/",
             description: "ECS-hosted platform (standard pipeline)" },
           { label: "http://localhost:8080/agentic_platform/api/v1/",
             description: "Local platform — use when you have the AIDLC platform API running locally with your own changes" },
           { label: "Enter a custom URL",
             description: "Type the full base URL" }
         ]
       }]
     })
     ```
     Validate: must start with `http://` or `https://`. Re-ask if not.

3. **Resolve `workspaceId`:**
   - If skill was invoked as `/launch <workspace_id>`: use `$1` directly. Validate: must be ≥ 8 characters.
   - If no argument was passed: check `aidlc.config.json` for an existing `workspace_id`.
     - Found → ask:
       ```
       AskUserQuestion({
         questions: [{
           question: "No workspace ID was passed. Use the one from aidlc.config.json?",
           header: "Workspace ID",
           multiSelect: false,
           options: [
             { label: "[existingWorkspaceId] — use this", description: "Use the workspace ID already in aidlc.config.json" },
             { label: "Enter a different workspace ID",   description: "Type a new workspace ID below" }
           ]
         }]
       })
       ```
     - Not found → ask the user to type one.
   - Validate: must be ≥ 8 characters. If not, tell the user and ask again.

4. **Write `aidlc.config.json`** (always keep it current):
   ```
   Write({
     file_path: "./aidlc.config.json",
     content: JSON.stringify({
       "central_base_url": centralBaseUrl,
       "auth": { "bearer_env": "AIDLC_TOKEN" },
       "workspace_id": workspaceId
     }, null, 2)
   })
   ```
   Tell the user:
   ```
   ✓ Config written.
     central_base_url : [centralBaseUrl]
     workspace_id     : [workspaceId]
   ```

5. **Derive `$dashboardUrl`** — extract the URL origin (scheme + host + port) from `centralBaseUrl`
   and append `/aidlc-platform-management/pipeline`:
   ```powershell
   $uri          = [System.Uri]$centralBaseUrl
   $dashboardUrl = "$($uri.Scheme)://$($uri.Authority)/aidlc-platform-management/pipeline"
   ```
   Examples:
   - `http://localhost:8080/agentic_platform/api/v1/`  → `http://localhost:8080/aidlc-platform-management/pipeline`
   - `https://poc-aidlc-uw-credit-risk-agents.npsdlchgapp.us-east-1.aws.aig.net/agentic_platform/api/v1/` → `https://poc-aidlc-uw-credit-risk-agents.npsdlchgapp.us-east-1.aws.aig.net/aidlc-platform-management/pipeline`

   Use `$dashboardUrl` everywhere a dashboard link is shown — never hardcode the URL.

---

## Phase 2 — Auto-Discover Stage from Bundle API

1. Tell the user: `Fetching workspace bundle from [centralBaseUrl]...`

2. Call the workspace metadata endpoint.
   Use `centralBaseUrl` trimmed of trailing slashes. If it already ends with `/api/v1` or
   `/api/v1/`, append only `/workspaces/[workspaceId]`. Otherwise append `/api/v1/workspaces/[workspaceId]`.
   ```bash
   curl -s \
     -H "Authorization: Bearer $AIDLC_TOKEN" \
     -H "Content-Type: application/json" \
     "[centralBaseUrl_trimmed]/workspaces/[workspaceId]"
   ```
   Parse the JSON response. Extract:
   - `tier` or `workspace_type` (expect: `"global"`, `"architecture"`, `"mini"`)
   - `current_stage` or derive from `progress.ready[0]`
   - `status` (expect: `"open"`, `"READY"`, `"IN_PROGRESS"`, etc.)
   - `label` or `title` if present (for display only)
   - `progress.ready` — list of stage keys ready to run (use when `current_stage` absent)

3. **Handle API errors:**
   - HTTP 401: tell the user "Token rejected — check AIDLC_TOKEN and re-run /launch." and **END**.
   - HTTP 404: tell the user "Workspace [workspaceId] not found — verify the ID in the ECS UI." and **END**.
   - Any other non-2xx or empty body: tell the user the raw response and **END**.

4. **Resolve the stage to run:**

   Priority order:
   1. Use `current_stage` if present and non-null.
   2. Otherwise use `progress.ready[0]` (first ready stage key) if present.
   3. Otherwise fall back to the `tier`/`workspace_type` default first stage:
      - `global` → `G1`
      - `architecture` → `A1`
      - `mini` → `M1`
      - `epic-assembler` → `EA1`

   Map stage keys to stage codes using this table:

   | Stage key | Stage code | Pipeline |
   |---|---|---|
   | prd / brd | G1 | uw-cr-global |
   | frd | G2 | uw-cr-global |
   | epic-set | G3 | uw-cr-global |
   | adr | A1 | uw-cr-architecture |
   | nfr | A2 | uw-cr-architecture |
   | sdd | A3 | uw-cr-architecture |
   | srd | A4 | uw-cr-architecture |
   | lld | M1 | uw-cr-mini |
   | ui-code | M2 | uw-cr-mini |
   | api-code | M3 | uw-cr-mini |
   | security-opa | M5 | uw-cr-mini |
   | api-test | M6 | uw-cr-mini |
   | ui-smoke | M7 | uw-cr-mini |
   | epic-assemble | EA1 | uw-cr-epic-assembler |
   | db-wiring | EA2 | uw-cr-epic-assembler |
   | local-deployment | EA3 | uw-cr-epic-assembler |
   | ui-smoke | EA4 | uw-cr-epic-assembler |
   | ui-e2e | EA5 | uw-cr-epic-assembler |
   | pr-merge | EA6 | uw-cr-epic-assembler |

   If multiple ready stages exist:
   - **Special case M2+M3**: If `progress.ready` contains BOTH `ui-code` AND `api-code`, set `resolvedStage = "M2+M3"` automatically. Do NOT default to just M2 — parallel execution is always preferred for this pair so the worker can detect the group and spawn child processes for each simultaneously.
   - Otherwise: show all ready stages to the user and default to the one earliest in the pipeline sequence.

5. **Show the auto-selected plan to the user** and ask to confirm:

   Tell the user:
   ```
   Workspace detected:
     ID            : [workspaceId]
     Label         : [label]
     Type          : [tier/workspace_type]
     Current stage : [current_stage or derived]
     Status        : [status]
     Ready stages  : [progress.ready joined with ", "]
     Stage to run  : [resolvedStage] — [stage description]
   ```

   Then ask:
   ```
   AskUserQuestion({
     questions: [{
       question: "Run [resolvedStage] for workspace [workspaceId]?",
       header: "Confirm Run",
       multiSelect: false,
       options: [
         { label: "Yes — via ECS pipeline",        description: "Queue run in ECS central API; CLI worker polls and executes (standard flow)" },
         { label: "Run locally (no ECS)",           description: "Queue run on local central API (localhost); CLI worker polls and executes with local prerequisites" },
         { label: "No — choose a different stage", description: "Override the auto-detected stage" }
       ]
     }]
   })
   ```

   - "Yes — via ECS pipeline": Config already set to cloud central_base_url → proceed to Phase 3.
   - "Run locally (no ECS)": Update config central_base_url to `http://localhost:8080/agentic_platform/api/v1/` → proceed to Phase 3.
   - "No — choose a different stage": Ask the user to type the stage code (e.g. `M3`, or `M2+M3` to run UI + API in parallel). Set `resolvedStage` to that value. Validate it is one of the known stage codes (including `M2+M3`). Then proceed to Phase 3.

---

## Phase 2.5 — REMOVED (Unified Execution Model)

**Removed in v2.4.0.** Previously, Phase 2.5 allowed direct skill invocation in launcher session without worker.

**New unified model (v2.4.0+):**
- Both local and ECS modes always launch the CLI worker (Phase 3.5)
- Worker polls the API (localhost or cloud, based on config)
- Worker claims the run and executes the skill
- All downloads, merging, and extraction happen in the worker's temp directory
- **Only difference:** The `central_base_url` in config

This ensures identical execution logic and artifact handling regardless of mode.

---

## Phase 3 — Build Progress Tracker

Use `TodoWrite` to initialize a progress tracker tailored to `resolvedStage`.

**Single-stage runs (G1–G3 / A1–A4 / individual M1–M7 / EA1–EA3):**
```
TodoWrite({ todos: [
  { id: "t1", content: "Validate token",                       status: "completed",  activeForm: "Validating token"                  },
  { id: "t2", content: "Fetch workspace bundle",               status: "completed",  activeForm: "Fetching workspace bundle"          },
  { id: "t3", content: "Auto-launch CLI worker",               status: "pending",    activeForm: "Launching CLI worker"               },
  { id: "t4", content: "Run [resolvedStage] skill",            status: "pending",    activeForm: "Running [resolvedStage] skill"      },
  { id: "t5", content: "Create pipeline run (if needed)",      status: "pending",    activeForm: "Creating pipeline run"              },
  { id: "t6", content: "Poll until waiting_for_approval",      status: "pending",    activeForm: "Polling for completion"             },
  { id: "t7", content: "Await approver in dashboard",          status: "pending",    activeForm: "Awaiting approval"                  }
]})
```

> Skip t3 ("Auto-launch CLI worker") for G1/G2/G3/G4/G5/G6 — those are server-side (Bedrock/LangGraph).
> For CLI stages (A1–A4, M1–M7, EA1–EA3, EA4–EA5): always proceed to Phase 3.5.

Tell the user:
```
✓ Progress tracker initialized. Starting [resolvedStage] now...
Dashboard: [$dashboardUrl]
```

---

## Phase 3.5 — Launch Worker (CLI stages only)

**Skip this phase entirely for G1/G2/G3/G4/G5/G6 (server-side Bedrock/LangGraph stages).**

For CLI stages (A1–A4, M1–M3, M5–M7, EA1–EA3, EA4–EA5), mark todo t3 `in_progress` and
launch the worker in a **new, non-blocking window**. Phase 4 runs immediately after, invoking
the stage skill (control plane) which creates the ECS run; the background worker (data plane)
polls, claims, and executes generation in its temp directory. Both operate concurrently.

```powershell
$workerScript = Join-Path (Get-Location) "plugins\lib\common\aidlc-launcher\scripts\aidlc-worker.ps1"

if (-not (Test-Path $workerScript)) {
    throw "Worker script not found: $workerScript"
}

# $env:AIDLC_TOKEN already set in Phase 0 — no re-read needed
$s   = $workerScript -replace "'", "''"
$tok = $env:AIDLC_TOKEN -replace "'", "''"
$cmd = "-NoExit -Command `"`$env:AIDLC_TOKEN='$tok'; Write-Host 'AIDLC Worker starting...'; & '$s'`""
Start-Process powershell -ArgumentList $cmd -WindowStyle Normal

Write-Host "✓ CLI Worker launched (background window)."
Write-Host "  Script : plugins\lib\common\aidlc-launcher\scripts\aidlc-worker.ps1"
Write-Host "  Action : Polling ECS every 15s — will claim the queued run automatically."
Write-Host "  Launcher now creates the ECS run via the stage skill (Phase 4)."
```

**Worker will:**
1. Read `aidlc.config.json` (central_base_url)
2. Poll ECS every 15 s for queued CLI runs (`?required_runner=cli`)
3. Claim the run created by the stage skill in Phase 4
4. Download artifacts from S3
5. Execute generation in temp dir: `%TEMP%\aidlc-ws\{wsId}\{stageKey}\`

Mark todo t3 `completed` immediately after `Start-Process` returns.

---

## Phase 4 — Execute Skill

**For CLI stages:** The worker is running in the background window (launched in Phase 3.5).
The launcher now invokes the stage skill as the **control plane**: the skill runs smart run
management (`?workspace_id=$WS&stage_key=$STAGE` → cancel queued / attach running / create
fresh), then monitors the ECS run until `waiting_for_approval`. Concurrently, the background
worker polls ECS, claims the queued run, and executes the actual generation in its temp directory.

**For server-side stages (G1–G3):** No worker is involved — the skill runs generation directly
in the launcher session.

Mark todo t4 `in_progress` before invoking the skill, then `completed` when the skill returns.

Dispatch based on `resolvedStage`:

| Stage | Skill | Notes |
|---|---|---|
| G1 | `Skill({skill: "AIDLC-business-analyst:ba-brd"})` | Server-side — no worker needed |
| G2 | `Skill({skill: "AIDLC-business-analyst:ba-frd"})` | Server-side |
| G3 | `Skill({skill: "AIDLC-business-analyst:ba-generate"})` | Server-side |
| A1 | `Skill({skill: "AIDLC-tech-architect:adr-generate"})` | CLI — worker auto-launched in Phase 3.5 |
| A2 | `Skill({skill: "AIDLC-tech-architect:nfr-generate"})` | CLI |
| A3 | `Skill({skill: "AIDLC-tech-architect:sdd-generate"})` | CLI |
| A4 | `Skill({skill: "AIDLC-tech-architect:srd-generate"})` | CLI |
| M1 only | `Skill({skill: "AIDLC-design:generate"})` | CLI — stage key: `lld` |
| **M2+M3** | **See M2+M3 parallel dispatch block below** | **CLI — creates ui-code + api-code ECS runs simultaneously; worker auto-detects parallel group and spawns child processes** |
| M2 only | See **ui-code dispatch** block below | CLI — stage key: `ui-code` (use only when M3 is already running or not needed) |
| M3 only | `Skill({skill: "AIDLC-springboot:implement"})` | CLI — stage key: `api-code` (use only when M2 is already running or not needed) |
| M5 only | `Skill({skill: "AIDLC-security:review"})` | CLI — stage key: `security-opa` |
| M6 only | `Skill({skill: "AIDLC-springboot:test"})` | CLI — stage key: `api-test` |
| M7 only | `Skill({skill: "AIDLC-axis:axis-test"})` | CLI — stage key: `ui-smoke` |
| EA1 | `Skill({skill: "AIDLC-integrator:integrate"})` | CLI — stage key: `epic-assemble` |
| EA2 | See **db-wiring dispatch** block below | CLI — stage key: `db-wiring` |
| EA3 | `Skill({skill: "AIDLC-deploy:deploy"})` | CLI — stage key: `local-deployment` |
| EA4 | `Skill({skill: "AIDLC-playwright:generate"})` | CLI — stage key: `ui-smoke` |
| EA5 | `Skill({skill: "AIDLC-playwright:generate"})` | CLI — stage key: `ui-e2e` |
| EA6 | external — CI/CD harness | stage key: `pr-merge` |

### pr-merge (EA6) — CI/CD-Triggered Stage

`pr-merge` is owned by `kind: external` in `uw-cr-epic-assembler.yaml` — it is **not** launched
by the CLI worker. When `resolvedStage = "EA6"`:

1. **Do NOT invoke a skill or queue an ECS run.** The merge gate is opened by the CI/CD harness
   (Jenkins / GitHub Actions) after all E2E results are approved in ECS.
2. Tell the user:
   ```
   ℹ  EA6 — PR Merge is handled by the CI/CD harness, not the CLI worker.
      Once EA5 (ui-e2e) is approved in ECS, the pipeline opens the merge gate automatically.
      No manual action is needed — monitor Jenkins / GitHub Actions for the merge PR.
   ```
3. Mark todo t4 `completed` and proceed to Phase 5.

> **G4/G5/G6 (Feature / User Story / Coverage Validation):** These run server-side via the Global
> LangGraph/Bedrock worker. Inform the user they are server-driven and poll the workspace bundle
> until the global thread advances to A1 or M1.

The invoked stage skill handles ECS run creation (cancel stale → create fresh) and monitoring.
Mark todo t5 `in_progress` when the skill begins creating the ECS run, and t5 `completed` when
the run is confirmed created. Mark t6 `in_progress` while polling.

### ui-code dispatch (M2 — Figma visual grounding)

When `resolvedStage = "M2"` (stage key `ui-code`), collect the Figma PNG folder path for
this workspace once, save it to `aidlc.config.json`, then let the worker run the stage
headlessly. The worker injects the path into the axis-implement prompt automatically.

**Step 1 — Check if Figma export ROOT path is already saved**

Read `aidlc.config.json`. If `figma_export_path` is already set:

1. Print confirmation:
   ```
   ✓ Figma export ROOT path already saved: <figma_export_path>
     Validating epic subfolders...
   ```

2. **Validate epic subfolders exist and contain PNGs** — for each expected epic in this workspace (read epic IDs from the ECS workspace list or use `epic-1` through `epic-N` heuristic):
   ```
   Glob({ pattern: "<figma_export_path>/epic-N/*.png" })
   ```
   - **If at least one subfolder contains PNGs** → print:
     ```
     ✓ Epic subfolders confirmed:
         epic-1: N PNG file(s) found
         epic-2: N PNG file(s) found
       Proceeding to Step 3.
     ```
     Skip to Step 3.
   - **If NO epic subfolder contains any PNG** → warn and re-collect:
     ```
     ⛔ figma_export_path is set to <figma_export_path> but no epic subfolders
       with PNG files were found (checked: epic-1/, epic-2/, ...).

     Expected structure:
       <figma_export_path>\epic-1\home.png
       <figma_export_path>\epic-2\company-maintenance.png

     Please provide the correct ROOT path or create the epic subfolders first.
     ```
     Clear `figma_export_path` from `aidlc.config.json` and fall through to Step 2.

**Step 2 — Collect Figma export ROOT path (mandatory — no skip)**

> ⛔ Figma screens are mandatory for every workspace. The "Skip" option has been removed.
> Every ui-code run requires Figma PNGs. Do NOT proceed until a valid root path is confirmed.

```
AskUserQuestion({
  questions: [{
    question: "Stage ui-code is ready. Provide the ROOT folder containing your epic-specific Figma PNG subfolders.\n\nExpected structure:\n  <root>\\epic-1\\home.png\n  <root>\\epic-1\\account-maintenance.png\n  <root>\\epic-2\\company-maintenance.png\n\nThe worker automatically appends the epic ID (e.g. epic-1, epic-2) and loads only screens for the current epic. The path is saved to aidlc.config.json and reused headlessly on every subsequent run.",
    header: "Figma Root",
    multiSelect: false,
    options: [
      {
        label: "Type the root path below (use Other)",
        description: "Absolute ROOT folder path (e.g. C:\\figma_exports). Do NOT include the epic subfolder — the worker appends it automatically."
      }
    ]
  }]
})
```

- **Path provided** → validate the folder exists on disk using `Glob({ pattern: "<path>/*" })`.
  - If the folder does not exist → re-ask: `⛔ Folder not found: <path>. Please provide a valid root path.`
  - If the folder exists → read `aidlc.config.json` and write it back with `figma_export_path` added:
    ```
    Write({ file_path: "./aidlc.config.json", content: <existing JSON + figma_export_path field> })
    ```
    Print:
    ```
    ✓ Figma export root path saved to aidlc.config.json.
      Worker will resolve <path>\epic-N\ per epic and inject it into each ui-code run.
    ```

**Step 3 — Invoke axis-implement skill**

```
Skill({ skill: "AIDLC-axis:axis-implement" })
```

The CLI worker (auto-launched in Phase 3.5) claims the `ui-code` run, reads `figma_export_path`
from `aidlc.config.json`, and injects it into the axis-implement prompt so the correct
workspace screens are used for code generation.

---

### M2+M3 Parallel Dispatch (ui-code + api-code simultaneously)

When `resolvedStage = "M2+M3"`, **do NOT invoke stage skills** — they create a run and then
monitor it to completion, which is inherently sequential and prevents the worker's parallel-group
detection from firing. Instead, create both ECS runs directly via REST API so the worker sees
them queued at the same time and spawns a child process for each.

**Step 1 — Check if Figma export ROOT path is already saved**

Read `aidlc.config.json`. If `figma_export_path` is already set:

1. Print confirmation:
   ```
   ✓ Figma export ROOT path already saved: <figma_export_path>
     Validating epic subfolders...
   ```

2. **Validate epic subfolders exist and contain PNGs** — for each expected epic in this workspace:
   ```
   Glob({ pattern: "<figma_export_path>/epic-N/*.png" })
   ```
   - **If at least one subfolder contains PNGs** → print:
     ```
     ✓ Epic subfolders confirmed:
         epic-1: N PNG file(s) found
         epic-2: N PNG file(s) found
       Proceeding to Step 2.
     ```
     Skip to Step 2.
   - **If NO epic subfolder contains any PNG** → warn and re-collect:
     ```
     ⛔ figma_export_path is set to <figma_export_path> but no epic subfolders
       with PNG files were found (checked: epic-1/, epic-2/, ...).

     Expected structure:
       <figma_export_path>\epic-1\home.png
       <figma_export_path>\epic-2\company-maintenance.png

     Please provide the correct ROOT path or create the epic subfolders first.
     ```
     Clear `figma_export_path` from `aidlc.config.json` and fall through to ask below.

If not set (or cleared above), ask:

> ⛔ Figma screens are mandatory for every workspace. The "Skip" option has been removed.
> Do NOT proceed until a valid root path is confirmed.

```
AskUserQuestion({
  questions: [{
    question: "Stage ui-code is ready. Provide the ROOT folder containing your epic-specific Figma PNG subfolders.\n\nExpected structure:\n  <root>\\epic-1\\home.png\n  <root>\\epic-1\\account-maintenance.png\n  <root>\\epic-2\\company-maintenance.png\n\nThe worker automatically appends the epic ID (e.g. epic-1, epic-2) and loads only screens for the current epic. The path is saved to aidlc.config.json and reused headlessly on every subsequent run.",
    header: "Figma Root",
    multiSelect: false,
    options: [
      { label: "Type the root path below (use Other)", description: "Absolute ROOT folder path (e.g. C:\\figma_exports). Do NOT include the epic subfolder — the worker appends it automatically." }
    ]
  }]
})
```

- **Path provided** → validate the folder exists on disk using `Glob({ pattern: "<path>/*" })`.
  - If the folder does not exist → re-ask: `⛔ Folder not found: <path>. Please provide a valid root path.`
  - If the folder exists → write it back to `aidlc.config.json` as `figma_export_path`.
    Print:
    ```
    ✓ Figma export root path saved to aidlc.config.json.
      Worker will resolve <path>\epic-N\ per epic and inject it into each ui-code run.
    ```

**Step 2 — Smart run management for both stages (cancel queued / attach running / create fresh)**

Matches the same three-way pattern used in all tech-architect stage skills.

```powershell
$BASE = "[centralBaseUrl_trimmed]"
$WS   = "[workspaceId]"
$HDR  = @{ Authorization = "Bearer $env:AIDLC_TOKEN"; "Content-Type" = "application/json" }
$runUI = $null; $runAPI = $null

foreach ($sk in @("ui-code", "api-code")) {
    try {
        $active = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS&stage_key=$sk" -Headers $HDR).items |
                  Where-Object { $_.state -in @("queued", "running") } |
                  Sort-Object queued_at -Descending | Select-Object -First 1

        if ($active -and $active.state -eq "queued") {
            Invoke-RestMethod "$BASE/pipeline-runs/$($active.run_id)/cancel" -Headers $HDR -Method Post | Out-Null
            Write-Host "Cancelled queued $sk run $($active.run_id) — creating fresh."
        } elseif ($active -and $active.state -eq "running") {
            # Already being processed by the worker — attach and monitor, do NOT cancel
            if ($sk -eq "ui-code") { $runUI  = $active.run_id } else { $runAPI = $active.run_id }
            Write-Host "Attaching to running $sk run $($active.run_id)"
        }
    } catch { Write-Host "Smart-run check skipped for ${sk}: $_" }
}
```

**Step 3 — Create fresh ECS runs for stages not already running**

The worker polls every ~15 s. Both fresh runs must be created within that window so they appear
queued simultaneously when the worker next scans `$allPending`.

```powershell
if (-not $runUI) {
    $bodyUI = @{ stage = "ui-code";  workspace_id = $WS; execute = $true; force = $true } | ConvertTo-Json
    $runUI  = (Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $bodyUI -ContentType "application/json").run.run_id
    Write-Host "Created ui-code  run: $runUI"
}

if (-not $runAPI) {
    $bodyAPI = @{ stage = "api-code"; workspace_id = $WS; execute = $true; force = $true } | ConvertTo-Json
    $runAPI  = (Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $bodyAPI -ContentType "application/json").run.run_id
    Write-Host "Created api-code run: $runAPI"
}
```

Tell the user:
```
✓ Both ECS runs created and queued:
    ui-code  : [runUI]
    api-code : [runAPI]

  The worker's next poll will detect both in queued state simultaneously,
  fire the parallel-group rule (M2+M3), and spawn a child process for each.
  Monitor the dashboard for parallel progress:
  [$dashboardUrl]
```

Mark todos t5 `completed`.

**Step 4 — Poll both runs until terminal state**

Terminal states: `waiting_for_approval`, `approved`, `rejected`, `failed`, `cancelled`.

```powershell
$terminal = @("waiting_for_approval","approved","rejected","failed","cancelled")
$done     = @{}

do {
    Start-Sleep -Seconds 20
    foreach ($pair in @(@("ui-code",$runUI), @("api-code",$runAPI))) {
        $sk = $pair[0]; $rid = $pair[1]
        if ($done.ContainsKey($sk)) { continue }
        try {
            $r  = (Invoke-RestMethod "$BASE/pipeline-runs/$rid" -Headers $HDR).run
            $hb = if ($r.last_heartbeat_at) { $r.last_heartbeat_at } else { "—" }
            Write-Host "  $sk  state=$($r.state)  heartbeat=$hb  files=$($r.files_written.Count)"
            if ($r.state -in $terminal) { $done[$sk] = $r.state }
        } catch { Write-Host "  $sk poll error: $_" }
    }
} while ($done.Count -lt 2)

Write-Host "M2+M3 complete — ui-code: $($done['ui-code'])   api-code: $($done['api-code'])"
```

- Both reach `waiting_for_approval` → tell the user to approve both in the ECS UI. Mark t6 `completed`, t7 `in_progress`.
- Either reaches `failed` / `rejected` → report the failed stage and stop polling the other.

---

### db-wiring dispatch

When `resolvedStage = "db-wiring"`, the ECS run is queued automatically by the pipeline
after `epic-assemble` is approved. Do NOT create a new ECS run — only collect the DB
details path and credentials, then let the CLI worker execute the stage headlessly.

**Step 1 — Check if DB details path and credentials are already saved**

Read `aidlc.config.json`. If `db_details_path` is already set **and** `db_username` is also set, print:
```
✓ DB details path already saved: <db_details_path>
✓ DB credentials already saved (username: <db_username>)
  The worker will inject these into the db-wiring run automatically.
```
Skip to Step 3.

If `db_details_path` is set but `db_username` is missing, print:
```
✓ DB details path already saved: <db_details_path>
⚠ DB credentials not yet saved — collecting now (Step 2b).
```
Skip Step 2a and go directly to Step 2b.

**Step 2a — Ask for DB details path (first run only)**

```
AskUserQuestion({
  questions: [{
    question: "Stage db-wiring is ready. The CLI worker needs your DB details document to wire datasource configuration into the assembled Spring Boot project. Provide the path once — it will be saved to aidlc.config.json and used headlessly by the worker from now on.",
    header: "DB Details",
    multiSelect: false,
    options: [
      {
        label: "Paste file path",
        description: "Absolute path to a JSON db-details file or plain-text architecture document (e.g. C:\\Projects\\db_details_auth_module.txt)"
      },
      {
        label: "Skip — no DB wiring",
        description: "Worker runs db-wiring without a DB document. Datasource config will remain as placeholder values."
      }
    ]
  }]
})
```

- **Path provided** → continue to Step 2b.
- **Skip** → print `⚠ Skipped — worker will run db-wiring without a DB document or credentials.` Write the config with no `db_details_path` and proceed to Step 3.

**Step 2b — Ask for DB credentials**

These are written only to `aidlc.config.json` (local, gitignored) and injected by the worker directly into the headless Claude prompt — they are never uploaded to ECS. They are used by the db-wire skill to write the `.env` file for local development only.

```
AskUserQuestion({
  questions: [
    {
      question: "Enter the database username for this workspace. Saved locally to aidlc.config.json and injected by the worker — never stored in ECS.",
      header: "DB Username",
      multiSelect: false,
      options: [
        { label: "Enter username", description: "SQL Server login (e.g. app_user, svc_creditapp)" },
        { label: "Skip credentials", description: "Worker will generate .env with placeholder values — fill in manually later." }
      ]
    },
    {
      question: "Enter the database password. Saved locally to aidlc.config.json — local dev only, move to cloud secrets before QA.",
      header: "DB Password",
      multiSelect: false,
      options: [
        { label: "Enter password", description: "SQL Server password for the above username" },
        { label: "Skip password",  description: "Leave as placeholder in .env — fill in manually later." }
      ]
    }
  ]
})
```

- **Username and password provided** → read `aidlc.config.json` and write it back with `db_details_path`, `db_username`, and `db_password` added:
  ```
  Write({ file_path: "./aidlc.config.json", content: <existing JSON + db_details_path + db_username + db_password fields> })
  ```
  Print:
  ```
  ✓ DB details path saved to aidlc.config.json — worker will use it headlessly.
  ✓ DB credentials saved to aidlc.config.json (username: <db_username>) — worker will inject into the headless prompt.
  ```

- **Skip credentials** → write config with `db_details_path` only (no `db_username` / `db_password`). Print:
  ```
  ✓ DB details path saved.
  ⚠ Credentials skipped — .env will contain placeholder values. Fill them in manually after the run.
  ```

**Step 3 — Worker executes headlessly**

The CLI worker is auto-launched in Phase 3.5. It polls ECS, claims the `db-wiring` run,
reads `db_details_path`, `db_username`, and `db_password` from `aidlc.config.json`,
and injects all three into the headless Claude prompt before invoking `/AIDLC-db:db-wire`.
The db-wire skill reads the credential markers from the prompt and writes `.env` without
calling `AskUserQuestion`.

Mark todo t5 `completed` immediately (ECS run already exists — no creation needed).
Mark todo t6 `in_progress` while worker polls for the run to reach `waiting_for_approval`.

---

## Phase 5 — Completion Summary

1. Mark all remaining todos `completed`.

2. Tell the user: `✓ [resolvedStage] complete!`

3. Print a completion table:
   ```
   | Item         | Value                |
   |--------------|----------------------|
   | Stage        | [resolvedStage]      |
   | Workspace ID | [workspaceId]        |
   | Status       | Waiting for Approval |
   | ECS Dashboard| [url]                |
   ```

4. Show next stage and approver from this table:

   | Completed | Next Stage | Approver |
   |---|---|---|
   | G1 | G2 FRD | Business Analyst |
   | G2 | G3 EPIC-SET | Product Owner |
   | G3 | A1–A4 Architecture (+ G4–G6 server-side) | Architect |
   | A1 | A2 NFR | Architect |
   | A2 | A3 SDD | Architect |
   | A3 | A4 SRD | Architect |
   | A4 | M1 LLD/TDDs | Architect |
   | M1 | M2 UI Code + M3 API Code (parallel) | Developer |
   | M2 | M5 Security + OPA | Developer |
   | M3 | M5 Security + OPA | Developer |
   | M5 | M6 API Tests | Tester |
   | M6 | M7 UI Jasmine Tests | Tester |
   | M7 | EA1 — EPIC Assembly | Tester |
   | EA1 (epic-assemble) | EA2 — DB Configuration | Architect |
   | EA2 (db-wiring) | EA3 — Local Deployment | Developer |
   | EA3 (local-deployment) | EA4 — UI Smoke Test | DevOps |
   | EA4 (ui-smoke) | EA5 — UI E2E Test | Tester |
   | EA5 (ui-e2e) | EA6 — PR Merge | Tester |
   | EA6 (pr-merge) | Release complete | DevOps |

5. Ask:
   ```
   AskUserQuestion({
     questions: [{
       question: "What would you like to do next?",
       header: "Next Action",
       multiSelect: false,
       options: [
         { label: "Run next stage ([next stage])", description: "Re-fetch bundle and auto-run the next stage" },
         { label: "Open dashboard",                 description: "Review and approve the deliverable first" },
         { label: "Done for now",                  description: "Exit the launcher" }
       ]
     }]
   })
   ```
   - "Run next stage": restart from Phase 2 with the same `workspaceId`.
   - "Open dashboard": print `[$dashboardUrl]` and exit.
   - "Done for now": tell the user `Run /launch [workspaceId] any time to continue.` and exit.

---

## Guardrails

```
OPERATIONAL_CONSTRAINTS[Type,Rules]:
  ALWAYS,"check AIDLC_TOKEN before any API call | read aidlc.config.json for central_base_url before asking | fetch the workspace bundle to determine the stage — never guess it | write aidlc.config.json whenever workspace_id changes | derive $dashboardUrl from centralBaseUrl origin in Phase 1 step 5 — never hardcode the dashboard URL | use TodoWrite before invoking any skill | mark todos in_progress before and completed immediately after each step | auto-launch the CLI worker (Phase 3.5) for all CLI stages (A1–A4, M1–M7) without asking the user | print $dashboardUrl at completion | show next stage and approver at completion"
  NEVER,"run a CLI stage without first auto-launching the worker in Phase 3.5 | ask the user to manually start the worker for CLI stages | run a stage without first fetching the workspace bundle | skip the confirmation prompt before executing the stage | invent workspace IDs, stage values, or token values | proceed past a failed API call or skill invocation without telling the user what failed | use PATCH /pipeline-runs/{id}/status or POST /pipeline-runs/{id}/deliverables — these endpoints do not exist"
  STOP_AND_ASK,"API returns 401 or 404 | workspace bundle is missing tier/workspace_type and no fallback is derivable | aidlc.config.json cannot be written | skill invocation fails | workspace_id is fewer than 8 characters | run reaches failed state during the waiting_for_approval poll"
```

---

## Version and Compatibility

**Version:** 2.4.0

**Changes in 2.4.0:**
- Phase 2.5 "Local Execution Mode" removed — dead code that bypassed the worker and contradicted the unified model
- Phase 3.5: worker now launched non-blocking (`Start-Process` new window); duplicate token read removed (Phase 0 already sets `$env:AIDLC_TOKEN`); description corrected (worker does NOT create runs — the stage skill does)
- Phase 4: description corrected — worker = data plane (claims + executes), stage skill = control plane (smart run management + monitoring); both run concurrently
- M2+M3 dispatch: Step 2 upgraded from cancel-only to full three-way smart run management (cancel queued / attach running / create fresh), matching the tech-architect pattern; Step 3 now skips creation for stages already running

**Changes in 2.3.0:**
- Phase 0 updated: three-layer token resolution — relay file → env var → DPAPI refresh store
- Phase 0: "Set up automatic token refresh" option runs `aidlc-auth.ps1` inline (browser PKCE login, stores refresh token with Windows DPAPI)
- Phase 0: if a stored refresh token exists, launcher skips all token prompts entirely
- Phase 3.5: worker startup message updated to reflect auto-refresh capability

**Changes in 2.2.0:**
- Phase 3.5 added: CLI worker auto-launched for all A1–A4 and M1–M7 stages — no manual start required
- Phase 2 updated: supports `progress.ready` for stage resolution when `current_stage` absent
- centralBaseUrl handling: smart suffix detection avoids double `/api/v1/` in URLs

**Requires (installed via the AIDLC marketplace):**
- AIDLC-business-analyst (G1, G2, G3)
- AIDLC-tech-architect (A1, A2, A3, A4)
- AIDLC-design (M1)
- AIDLC-axis (M2, M7)
- AIDLC-springboot (M3, M6)
- AIDLC-security (M5)
- AIDLC-epic-assembler (EA1, EA2, EA3)
