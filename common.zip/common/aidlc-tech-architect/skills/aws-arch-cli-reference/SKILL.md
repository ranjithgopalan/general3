---
name: aws-arch-cli-reference
description: Reference documentation for aws-arch CLI commands. Non-executable reference for skills and agents.
version: 1.0.0
---

# AWS Architecture CLI Reference

**Purpose**: Comprehensive reference documentation for the `aws-arch` CLI tool. This skill provides command syntax, parameters, JSON output schemas, and usage examples for all CLI command groups.

**Note**: This is a **non-executable reference skill**. It serves as documentation for other skills (like aws-diagram-generator) and agents that need to invoke CLI commands.

---

## Table of Contents

1. [CLI Overview](#cli-overview)
2. [Command Groups](#command-groups)
3. [Project Management](#project-management)
4. [YAML Operations](#yaml-operations)
5. [Python Generation](#python-generation)
6. [Diagram Execution](#diagram-execution)
7. [Draw.io Conversion](#drawio-conversion)
8. [JSON Output Format](#json-output-format)
9. [Error Handling](#error-handling)
10. [Integration Patterns](#integration-patterns)

---

## CLI Overview

### Installation

The `aws-arch` CLI is part of the AIDLC-tech-architect plugin.

### Basic Usage

```bash
aws-arch [COMMAND_GROUP] [COMMAND] [ARGUMENTS] [OPTIONS]
```

### Global Options

- `--help`, `-h`: Show help message
- `--version`, `-v`: Show CLI version

### Common Patterns

All commands support:
- `--json` flag for machine-readable output
- Relative or absolute paths for project directories
- Exit codes: 0 (success), 1 (error/partial)

---

## Command Groups

The CLI has 5 command groups:

| Group | Purpose | Commands |
|-------|---------|----------|
| **project** | Project management | create, list, info, validate |
| **yaml** | YAML operations | validate, list-services |
| **python** | Python generation | generate, generate-all |
| **diagram** | Diagram execution | check, execute, execute-all, preview, list-outputs |
| **drawio** | Draw.io conversion | convert, convert-all |

---

## Project Management

**Command Group**: `aws-arch project`

### create

Create a new AWS architecture project with complete folder structure.

**Syntax**:
```bash
aws-arch project create <name> [OPTIONS]
```

**Arguments**:
- `name` (required): Project name (alphanumeric, hyphens, underscores only)

**Options**:
- `--path <path>`: Parent directory for project (default: current directory)
- `--template <name>`: Template to use (default: "default")
- `--force`: Overwrite existing project
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch project create my-aws-project
aws-arch project create my-project --path ~/projects --json
```

**Creates**:
```
my-aws-project/
├── requirements/         # TDD documents
├── yaml_specs/          # YAML specifications
├── python_scripts/      # Python diagram scripts
├── diagrams/            # PNG and DOT outputs
├── drawio/              # Draw.io XML files
├── README.md
└── .gitignore
```

**JSON Output (Success)**:
```json
{
  "status": "success",
  "message": "Project 'my-aws-project' created successfully",
  "data": {
    "project_name": "my-aws-project",
    "project_path": "/absolute/path/to/my-aws-project",
    "folders_created": [
      "requirements",
      "yaml_specs",
      "python_scripts",
      "diagrams",
      "drawio"
    ]
  }
}
```

**JSON Output (Error)**:
```json
{
  "status": "error",
  "message": "Project 'my-aws-project' already exists",
  "data": {
    "project_path": "/absolute/path/to/my-aws-project",
    "fix": "Use --force to overwrite or choose a different name"
  }
}
```

**Exit Codes**:
- `0`: Success
- `1`: Error (validation failed, already exists, permission denied)

---

### list

List all AWS architecture projects in a directory.

**Syntax**:
```bash
aws-arch project list [OPTIONS]
```

**Options**:
- `--path <path>`: Directory to search (default: current directory)
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch project list
aws-arch project list --path ~/projects --json
```

**JSON Output (Success)**:
```json
{
  "status": "success",
  "message": "Found 3 AWS architecture projects",
  "data": {
    "projects": [
      {
        "name": "project-1",
        "path": "/absolute/path/to/project-1",
        "valid": true,
        "folders": ["requirements", "yaml_specs", "python_scripts", "diagrams", "drawio"]
      },
      {
        "name": "project-2",
        "path": "/absolute/path/to/project-2",
        "valid": false,
        "missing_folders": ["diagrams", "drawio"]
      }
    ],
    "total_count": 3,
    "valid_count": 2,
    "invalid_count": 1
  }
}
```

**JSON Output (No Projects)**:
```json
{
  "status": "error",
  "message": "No AWS architecture projects found",
  "data": {
    "search_path": "/absolute/path/searched"
  }
}
```

**Exit Codes**:
- `0`: Success (at least 1 project found)
- `1`: No projects found

---

### info

Show detailed information about a project.

**Syntax**:
```bash
aws-arch project info <name> [OPTIONS]
```

**Arguments**:
- `name` (required): Project name

**Options**:
- `--path <path>`: Parent directory containing project (default: current directory)
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch project info my-aws-project
aws-arch project info my-project --path ~/projects --json
```

**JSON Output (Success)**:
```json
{
  "status": "success",
  "message": "Project information retrieved",
  "data": {
    "project_name": "my-aws-project",
    "project_path": "/absolute/path/to/my-aws-project",
    "valid": true,
    "folders": {
      "requirements": {
        "exists": true,
        "file_count": 2,
        "total_size": "173.9 KB"
      },
      "yaml_specs": {
        "exists": true,
        "file_count": 3,
        "total_size": "24.5 KB"
      },
      "python_scripts": {
        "exists": true,
        "file_count": 3,
        "total_size": "12.8 KB"
      },
      "diagrams": {
        "exists": true,
        "file_count": 6,
        "total_size": "2.8 MB"
      },
      "drawio": {
        "exists": true,
        "file_count": 3,
        "total_size": "853.8 KB"
      }
    },
    "files": {
      "readme_exists": true,
      "gitignore_exists": true
    }
  }
}
```

**JSON Output (Not Found)**:
```json
{
  "status": "error",
  "message": "Project 'my-project' not found",
  "data": {
    "search_path": "/absolute/path/searched"
  }
}
```

**Exit Codes**:
- `0`: Success
- `1`: Project not found

---

### validate

Validate project structure and required folders.

**Syntax**:
```bash
aws-arch project validate <name> [OPTIONS]
```

**Arguments**:
- `name` or `path` (required): Project name or path

**Options**:
- `--path <path>`: Parent directory (if using project name)
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch project validate my-aws-project
aws-arch project validate /path/to/my-project --json
```

**JSON Output (Valid)**:
```json
{
  "status": "success",
  "message": "Project structure is valid",
  "data": {
    "project_name": "my-aws-project",
    "project_path": "/absolute/path/to/my-aws-project",
    "valid": true,
    "required_folders": [
      "requirements",
      "yaml_specs",
      "python_scripts",
      "diagrams",
      "drawio"
    ],
    "all_folders_exist": true
  }
}
```

**JSON Output (Invalid)**:
```json
{
  "status": "error",
  "message": "Project structure is invalid",
  "data": {
    "project_name": "my-aws-project",
    "project_path": "/absolute/path/to/my-aws-project",
    "valid": false,
    "missing_folders": [
      "diagrams",
      "drawio"
    ],
    "errors": [
      "Missing required folder: diagrams",
      "Missing required folder: drawio"
    ],
    "fix": "Create missing folders or use 'aws-arch project create' to recreate project"
  }
}
```

**Exit Codes**:
- `0`: Valid
- `1`: Invalid or not found

---

## YAML Operations

**Command Group**: `aws-arch yaml`

### validate

Validate YAML specification files for syntax and structure.

**Syntax**:
```bash
aws-arch yaml validate <files...> [OPTIONS]
```

**Arguments**:
- `files` (required): One or more YAML files to validate (supports glob patterns)

**Options**:
- `--strict`: Enable strict validation (check additional fields)
- `--verbose`: Show detailed validation messages
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch yaml validate yaml_specs/01_c4_context.yaml
aws-arch yaml validate yaml_specs/*.yaml --json
aws-arch yaml validate yaml_specs/*.yaml --strict --verbose
```

**Validates**:
- YAML syntax (valid YAML format)
- Required fields (metadata, aws_services, nodes, edges)
- AWS service references (valid service names)
- Node definitions (id, label, service)
- Edge definitions (source, target references)

**JSON Output (All Valid)**:
```json
{
  "status": "success",
  "message": "All YAML files are valid",
  "data": {
    "total_files": 3,
    "valid_count": 3,
    "invalid_count": 0,
    "valid_files": [
      {
        "file": "yaml_specs/01_c4_context.yaml",
        "diagram_name": "C4 Context Diagram",
        "diagram_type": "c4_context",
        "node_count": 12,
        "edge_count": 8,
        "service_count": 5
      },
      {
        "file": "yaml_specs/02_c4_container.yaml",
        "diagram_name": "C4 Container Diagram",
        "diagram_type": "c4_container",
        "node_count": 24,
        "edge_count": 18,
        "service_count": 8
      }
    ]
  }
}
```

**JSON Output (Partial)**:
```json
{
  "status": "partial",
  "message": "2 of 3 YAML files are valid",
  "data": {
    "total_files": 3,
    "valid_count": 2,
    "invalid_count": 1,
    "valid_files": [...],
    "invalid_files": [
      {
        "file": "yaml_specs/03_infrastructure.yaml",
        "error": "Missing required field: metadata.diagram_name",
        "line": 5,
        "fix": "Add 'diagram_name' field to metadata section"
      }
    ]
  }
}
```

**JSON Output (All Invalid)**:
```json
{
  "status": "error",
  "message": "All YAML files failed validation",
  "data": {
    "total_files": 3,
    "valid_count": 0,
    "invalid_count": 3,
    "invalid_files": [
      {
        "file": "yaml_specs/01_c4_context.yaml",
        "error": "YAML syntax error: mapping values are not allowed here",
        "line": 12,
        "fix": "Check YAML indentation and syntax"
      }
    ]
  }
}
```

**Common Validation Errors**:
| Error | Fix |
|-------|-----|
| `Missing required field: metadata.diagram_name` | Add diagram_name to metadata |
| `Unknown AWS service: 'EC3'` | Check service name (should be 'EC2') |
| `Edge references unknown node: 'vpc1'` | Ensure node exists in nodes section |
| `YAML syntax error: mapping values...` | Check indentation and syntax |
| `Invalid diagram_type: 'custom'` | Use valid type (c4_context, c4_container, aws_infrastructure) |

**Exit Codes**:
- `0`: All valid
- `1`: Some or all invalid

---

### list-services

List available AWS services from the catalog.

**Syntax**:
```bash
aws-arch yaml list-services [OPTIONS]
```

**Options**:
- `--category <category>`: Filter by category (compute, storage, database, etc.)
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch yaml list-services
aws-arch yaml list-services --category compute --json
```

**JSON Output**:
```json
{
  "status": "success",
  "message": "Listed 245 AWS services",
  "data": {
    "total_count": 245,
    "categories": {
      "compute": 12,
      "storage": 8,
      "database": 15,
      "networking": 18,
      "security": 22,
      "analytics": 14
    },
    "services": [
      {
        "name": "EC2",
        "full_name": "Elastic Compute Cloud",
        "category": "compute",
        "import_path": "diagrams.aws.compute.EC2"
      },
      {
        "name": "S3",
        "full_name": "Simple Storage Service",
        "category": "storage",
        "import_path": "diagrams.aws.storage.S3"
      }
    ]
  }
}
```

**Exit Codes**:
- `0`: Success
- `1`: Error

---

## Python Generation

**Command Group**: `aws-arch python`

### generate

Generate Python diagram scripts from YAML specifications.

**Syntax**:
```bash
aws-arch python generate <files...> [OPTIONS]
```

**Arguments**:
- `files` (required): One or more YAML files (supports glob patterns)

**Options**:
- `--output-dir <path>`: Output directory for Python scripts (default: python_scripts/)
- `--no-batch`: Generate individual scripts instead of batch file
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch python generate yaml_specs/01_c4_context.yaml
aws-arch python generate yaml_specs/*.yaml --output-dir scripts/ --json
```

**Generates**:
- Python script for each YAML file
- Batch execution script (run_all.bat or run_all.sh)
- Uses mingrammer/diagrams library

**JSON Output (Success)**:
```json
{
  "status": "success",
  "message": "Generated 3 Python scripts",
  "data": {
    "total_files": 3,
    "successful": 3,
    "failed": 0,
    "generated_scripts": [
      {
        "source_yaml": "yaml_specs/01_c4_context.yaml",
        "output_file": "01_c4_context_diagram.py",
        "output_path": "python_scripts/01_c4_context_diagram.py",
        "line_count": 45,
        "success": true
      },
      {
        "source_yaml": "yaml_specs/02_c4_container.yaml",
        "output_file": "02_c4_container_diagram.py",
        "output_path": "python_scripts/02_c4_container_diagram.py",
        "line_count": 78,
        "success": true
      }
    ],
    "batch_file": "python_scripts/run_all.bat"
  }
}
```

**JSON Output (Partial)**:
```json
{
  "status": "partial",
  "message": "Generated 2 of 3 Python scripts",
  "data": {
    "total_files": 3,
    "successful": 2,
    "failed": 1,
    "generated_scripts": [...],
    "errors": [
      {
        "yaml_file": "yaml_specs/03_infrastructure.yaml",
        "error": "Template processing error: Invalid service mapping",
        "fix": "Check AWS service names in YAML"
      }
    ]
  }
}
```

**Exit Codes**:
- `0`: All successful
- `1`: Some or all failed

---

### generate-all

Generate Python scripts from all YAML files in a directory.

**Syntax**:
```bash
aws-arch python generate-all <directory> [OPTIONS]
```

**Arguments**:
- `directory` (required): Directory containing YAML files

**Options**:
- `--output-dir <path>`: Output directory (default: python_scripts/)
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch python generate-all yaml_specs/
aws-arch python generate-all yaml_specs/ --output-dir scripts/ --json
```

**JSON Output**: Same as `generate` command

**Exit Codes**:
- `0`: All successful
- `1`: Some or all failed

---

## Diagram Execution

**Command Group**: `aws-arch diagram`

### check

Check prerequisites for diagram generation (Python, Graphviz).

**Syntax**:
```bash
aws-arch diagram check <project> [OPTIONS]
```

**Arguments**:
- `project` (required): Project directory path

**Options**:
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch diagram check my-aws-project
aws-arch diagram check /path/to/project --json
```

**Checks**:
- Python version (3.8+ required)
- Graphviz installation
- Graphviz version and path

**JSON Output (All OK)**:
```json
{
  "status": "success",
  "message": "All prerequisites are met",
  "python": {
    "version": "3.10.5",
    "compatible": true
  },
  "graphviz": {
    "installed": true,
    "version": "2.50.0",
    "path": "/usr/local/bin/dot",
    "error": null
  }
}
```

**JSON Output (Missing Graphviz)**:
```json
{
  "status": "error",
  "message": "Prerequisites not met",
  "python": {
    "version": "3.10.5",
    "compatible": true
  },
  "graphviz": {
    "installed": false,
    "version": null,
    "path": null,
    "error": "Graphviz 'dot' command not found"
  },
  "installation_instructions": {
    "macos": "brew install graphviz",
    "windows": "choco install graphviz",
    "linux": "sudo apt-get install graphviz"
  }
}
```

**Exit Codes**:
- `0`: All OK
- `1`: Prerequisites not met

---

### execute

Execute diagram generation scripts.

**Syntax**:
```bash
aws-arch diagram execute <project> [OPTIONS]
```

**Arguments**:
- `project` (required): Project directory path

**Options**:
- `--diagram <name>`: Execute specific diagram (optional, default: all)
- `--skip-checks`: Skip prerequisite checks
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch diagram execute my-aws-project
aws-arch diagram execute my-project --diagram 01_c4_context --json
aws-arch diagram execute my-project --skip-checks
```

**Executes**:
- Python scripts in python_scripts/ directory
- Generates PNG and DOT files in diagrams/ directory
- Shows progress and results

**JSON Output (Success)**:
```json
{
  "status": "success",
  "message": "All diagrams generated successfully",
  "total_scripts": 3,
  "successful": 3,
  "failed": 0,
  "execution_time": 12.4,
  "png_count": 3,
  "dot_count": 3,
  "total_size": "2.8 MB",
  "results": [
    {
      "script": "01_c4_context_diagram",
      "success": true,
      "files": [
        "diagrams/01_c4_context.png",
        "diagrams/01_c4_context.dot"
      ],
      "error": null,
      "time": 4.2
    },
    {
      "script": "02_c4_container_diagram",
      "success": true,
      "files": [
        "diagrams/02_c4_container.png",
        "diagrams/02_c4_container.dot"
      ],
      "error": null,
      "time": 5.8
    }
  ]
}
```

**JSON Output (Partial)**:
```json
{
  "status": "partial",
  "message": "2 of 3 diagrams generated successfully",
  "total_scripts": 3,
  "successful": 2,
  "failed": 1,
  "execution_time": 10.5,
  "png_count": 2,
  "dot_count": 2,
  "total_size": "1.9 MB",
  "results": [...],
  "errors": [
    {
      "script": "03_infrastructure_diagram",
      "error_type": "Missing Package",
      "message": "ModuleNotFoundError: No module named 'diagrams'",
      "fix": "Install diagrams package: pip install diagrams"
    }
  ]
}
```

**JSON Output (All Failed)**:
```json
{
  "status": "error",
  "message": "All diagrams failed to generate",
  "total_scripts": 3,
  "successful": 0,
  "failed": 3,
  "execution_time": 2.1,
  "png_count": 0,
  "dot_count": 0,
  "total_size": "0 B",
  "results": [...],
  "errors": [...]
}
```

**Common Execution Errors**:
| Error Type | Example | Fix |
|------------|---------|-----|
| Missing Package | `ModuleNotFoundError: diagrams` | `pip install diagrams` |
| Graphviz Error | `Graphviz executables not found` | Install Graphviz |
| Syntax Error | `SyntaxError: invalid syntax` | Regenerate Python scripts |
| Permission Error | `PermissionError: [Errno 13]` | Check folder permissions |
| Timeout | `Script execution timed out` | Optimize diagram complexity |

**Exit Codes**:
- `0`: Success (all or partial)
- `1`: Error (all failed)

---

### execute-all

Execute all diagram scripts in project (convenience command).

**Syntax**:
```bash
aws-arch diagram execute-all <project> [OPTIONS]
```

**Arguments**:
- `project` (required): Project directory path

**Options**:
- `--skip-checks`: Skip prerequisite checks
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch diagram execute-all my-aws-project
aws-arch diagram execute-all /path/to/project --json
```

**Note**: Equivalent to `aws-arch diagram execute <project>`

**Exit Codes**: Same as `execute`

---

### preview

Preview what diagram scripts will be executed (dry run).

**Syntax**:
```bash
aws-arch diagram preview <project> [OPTIONS]
```

**Arguments**:
- `project` (required): Project directory path

**Options**:
- `--diagram <name>`: Preview specific diagram
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch diagram preview my-aws-project
aws-arch diagram preview my-project --diagram 01_c4_context --json
```

**JSON Output**:
```json
{
  "status": "success",
  "message": "Found 3 diagram scripts",
  "project": "my-aws-project",
  "script_count": 3,
  "scripts": [
    {
      "name": "01_c4_context_diagram.py",
      "path": "python_scripts/01_c4_context_diagram.py"
    },
    {
      "name": "02_c4_container_diagram.py",
      "path": "python_scripts/02_c4_container_diagram.py"
    }
  ]
}
```

**Exit Codes**:
- `0`: Scripts found
- `1`: No scripts found

---

### list-outputs

List generated diagram output files.

**Syntax**:
```bash
aws-arch diagram list-outputs <project> [OPTIONS]
```

**Arguments**:
- `project` (required): Project directory path

**Options**:
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch diagram list-outputs my-aws-project
aws-arch diagram list-outputs /path/to/project --json
```

**JSON Output**:
```json
{
  "status": "success",
  "message": "Found diagram output files",
  "png_count": 3,
  "dot_count": 3,
  "files": {
    "png": [
      {
        "name": "01_c4_context.png",
        "size": 865436,
        "path": "diagrams/01_c4_context.png"
      },
      {
        "name": "02_c4_container.png",
        "size": 1258734,
        "path": "diagrams/02_c4_container.png"
      }
    ],
    "dot": [
      {
        "name": "01_c4_context.dot",
        "size": 3456,
        "path": "diagrams/01_c4_context.dot"
      }
    ]
  }
}
```

**Exit Codes**:
- `0`: Files found
- `1`: No files found

---

## Draw.io Conversion

**Command Group**: `aws-arch drawio`

### convert

Convert a single DOT file to Draw.io XML format.

**Syntax**:
```bash
aws-arch drawio convert <dot-file> [OPTIONS]
```

**Arguments**:
- `dot-file` (required): Path to DOT file

**Options**:
- `--output <path>`: Output file path (default: same name with .drawio.xml extension)
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch drawio convert diagrams/01_c4_context.dot
aws-arch drawio convert diagrams/01_c4_context.dot --output custom.drawio.xml --json
```

**JSON Output (Success)**:
```json
{
  "status": "success",
  "message": "Converted DOT file to Draw.io format",
  "data": {
    "input_file": "diagrams/01_c4_context.dot",
    "output_file": "drawio/01_c4_context.drawio.xml",
    "node_count": 12,
    "edge_count": 8,
    "file_size": 159842
  }
}
```

**JSON Output (Error)**:
```json
{
  "status": "error",
  "message": "Failed to convert DOT file",
  "data": {
    "input_file": "diagrams/01_c4_context.dot",
    "error": "DOT syntax error at line 15: unexpected token",
    "fix": "Regenerate diagram or fix DOT file syntax"
  }
}
```

**Exit Codes**:
- `0`: Success
- `1`: Error

---

### convert-all

Convert all DOT files in project to Draw.io XML format.

**Syntax**:
```bash
aws-arch drawio convert-all <project> [OPTIONS]
```

**Arguments**:
- `project` (required): Project directory path

**Options**:
- `--json`: Output result as JSON

**Example**:
```bash
aws-arch drawio convert-all my-aws-project
aws-arch drawio convert-all /path/to/project --json
```

**JSON Output (Success)**:
```json
{
  "status": "success",
  "message": "Converted all DOT files to Draw.io format",
  "data": {
    "total_files": 3,
    "converted_count": 3,
    "failed_count": 0,
    "total_size": "853.8 KB",
    "conversions": [
      {
        "input_file": "diagrams/01_c4_context.dot",
        "output_file": "drawio/01_c4_context.drawio.xml",
        "success": true,
        "node_count": 12,
        "edge_count": 8
      },
      {
        "input_file": "diagrams/02_c4_container.dot",
        "output_file": "drawio/02_c4_container.drawio.xml",
        "success": true,
        "node_count": 24,
        "edge_count": 18
      }
    ]
  }
}
```

**JSON Output (Partial)**:
```json
{
  "status": "partial",
  "message": "Converted 2 of 3 DOT files",
  "data": {
    "total_files": 3,
    "converted_count": 2,
    "failed_count": 1,
    "total_size": "568.2 KB",
    "conversions": [...],
    "errors": [
      {
        "file": "diagrams/03_infrastructure.dot",
        "error": "DOT parsing error",
        "fix": "Regenerate diagram"
      }
    ]
  }
}
```

**Exit Codes**:
- `0`: Success (all or partial)
- `1`: Error (all failed or no files)

---

## JSON Output Format

### Standard Schema

All CLI commands follow a consistent JSON output schema:

```json
{
  "status": "success|partial|error",
  "message": "Human-readable message",
  "data": {
    // Command-specific data
  }
}
```

### Status Values

- `"success"`: Operation completed successfully
- `"partial"`: Operation partially succeeded (some items failed)
- `"error"`: Operation failed completely

### Parsing JSON Output

```python
import subprocess
import json

# Execute CLI command
result = subprocess.run(
    ["aws-arch", "command", "subcommand", "args", "--json"],
    capture_output=True,
    text=True
)

# Parse output
output = json.loads(result.stdout)

# Check status
if output["status"] == "success":
    data = output["data"]
    # Handle success
elif output["status"] == "partial":
    data = output["data"]
    errors = output["data"].get("errors", [])
    # Handle partial success
else:  # error
    error_message = output["message"]
    # Handle error
```

### Exit Code Mapping

| Status | Exit Code | Meaning |
|--------|-----------|---------|
| `success` | 0 | Complete success |
| `partial` | 0 | Partial success (at least 1 succeeded) |
| `error` | 1 | Complete failure |

**Note**: Both `success` and `partial` return exit code 0. Check JSON status to distinguish.

---

## Error Handling

### Error Categories

The CLI categorizes errors and provides fix suggestions:

| Category | Examples | Typical Fix |
|----------|----------|-------------|
| **Validation** | Invalid name, missing field | Check input, fix syntax |
| **File System** | Not found, permission denied | Check paths, permissions |
| **Prerequisites** | Python/Graphviz missing | Install required tools |
| **Execution** | Module not found, timeout | Install packages, optimize |
| **Conversion** | DOT syntax error | Regenerate diagram |

### Error Response Format

```json
{
  "status": "error",
  "message": "Human-readable error message",
  "data": {
    "error": "Detailed error description",
    "error_type": "Error category",
    "fix": "Suggested fix",
    "details": {
      // Additional error context
    }
  }
}
```

### Common Errors

#### Project Management

```json
// Project already exists
{
  "status": "error",
  "message": "Project 'my-project' already exists",
  "data": {
    "fix": "Use --force to overwrite or choose a different name"
  }
}

// Invalid project name
{
  "status": "error",
  "message": "Invalid project name",
  "data": {
    "error": "Project name must contain only alphanumeric characters, hyphens, and underscores",
    "fix": "Use a valid project name (e.g., 'my-aws-project')"
  }
}
```

#### YAML Validation

```json
// Missing required field
{
  "status": "error",
  "message": "YAML validation failed",
  "data": {
    "invalid_files": [
      {
        "file": "yaml_specs/01_context.yaml",
        "error": "Missing required field: metadata.diagram_name",
        "line": 5,
        "fix": "Add 'diagram_name' field to metadata section"
      }
    ]
  }
}
```

#### Diagram Execution

```json
// Missing package
{
  "status": "error",
  "message": "Diagram execution failed",
  "data": {
    "errors": [
      {
        "script": "01_c4_context_diagram",
        "error_type": "Missing Package",
        "message": "ModuleNotFoundError: No module named 'diagrams'",
        "fix": "Install diagrams package: pip install diagrams"
      }
    ]
  }
}

// Graphviz not installed
{
  "status": "error",
  "message": "Graphviz not installed",
  "graphviz": {
    "installed": false,
    "error": "Graphviz 'dot' command not found"
  },
  "installation_instructions": {
    "macos": "brew install graphviz",
    "windows": "choco install graphviz",
    "linux": "sudo apt-get install graphviz"
  }
}
```

---

## Integration Patterns

### Subprocess Invocation (Python)

```python
import subprocess
import json
from pathlib import Path

def run_cli_command(command: list, cwd: str = None) -> dict:
    """Execute CLI command and return parsed JSON output.

    Args:
        command: List of command arguments (e.g., ["aws-arch", "project", "create", "name", "--json"])
        cwd: Working directory for command execution

    Returns:
        Parsed JSON output as dictionary
    """
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        cwd=cwd
    )

    # Parse JSON output
    try:
        output = json.loads(result.stdout)
        return output
    except json.JSONDecodeError:
        # Handle non-JSON output (shouldn't happen with --json flag)
        return {
            "status": "error",
            "message": "Failed to parse CLI output",
            "data": {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.returncode
            }
        }

# Example usage
output = run_cli_command([
    "aws-arch", "project", "create", "my-project", "--json"
])

if output["status"] == "success":
    project_path = output["data"]["project_path"]
    print(f"Project created at: {project_path}")
else:
    error = output["message"]
    print(f"Error: {error}")
```

### Error Handling Pattern

```python
def execute_with_error_handling(command: list) -> tuple[bool, dict]:
    """Execute CLI command with error handling.

    Returns:
        Tuple of (success, output_data)
    """
    output = run_cli_command(command)

    if output["status"] == "success":
        return True, output["data"]

    elif output["status"] == "partial":
        # Handle partial success
        data = output["data"]
        errors = data.get("errors", [])

        # Log errors but continue
        for error in errors:
            print(f"Warning: {error}")

        return True, data  # Still considered success

    else:  # error
        # Handle error
        error_message = output["message"]
        fix_suggestion = output.get("data", {}).get("fix", "")

        print(f"Error: {error_message}")
        if fix_suggestion:
            print(f"Fix: {fix_suggestion}")

        return False, output.get("data", {})

# Example usage
success, data = execute_with_error_handling([
    "aws-arch", "yaml", "validate", "yaml_specs/*.yaml", "--json"
])

if success:
    print(f"Validated {data['total_files']} YAML files")
else:
    print("Validation failed")
```

### Project Path Handling

```python
from pathlib import Path

def get_project_path(project_name_or_path: str, parent_dir: str = None) -> Path:
    """Resolve project path from name or absolute path.

    Args:
        project_name_or_path: Project name or absolute path
        parent_dir: Parent directory (if using project name)

    Returns:
        Absolute path to project
    """
    path = Path(project_name_or_path)

    if path.is_absolute():
        return path
    else:
        # Treat as project name
        if parent_dir:
            return Path(parent_dir) / project_name_or_path
        else:
            return Path.cwd() / project_name_or_path

# Example usage
project_path = get_project_path("my-project", parent_dir="~/projects")
# Result: /Users/username/projects/my-project
```

### Workflow Integration

```python
def workflow_phase_yaml_validation(project_path: Path, yaml_files: list) -> bool:
    """Workflow Phase 3a: YAML Validation.

    Args:
        project_path: Project directory path
        yaml_files: List of YAML files to validate (relative to project)

    Returns:
        True if validation passed, False otherwise
    """
    # Build absolute paths
    yaml_paths = [str(project_path / f) for f in yaml_files]

    # Execute validation
    output = run_cli_command(
        ["aws-arch", "yaml", "validate"] + yaml_paths + ["--json"],
        cwd=str(project_path)
    )

    if output["status"] == "success":
        # All YAMLs valid
        print("✓ All YAML files are valid")
        return True

    elif output["status"] == "partial":
        # Some YAMLs invalid
        valid_count = output["data"]["valid_count"]
        invalid_count = output["data"]["invalid_count"]

        print(f"⚠ Validation partially failed:")
        print(f"  Valid: {valid_count}")
        print(f"  Invalid: {invalid_count}")

        # Show errors
        for error in output["data"]["invalid_files"]:
            print(f"  ✗ {error['file']}: {error['error']}")

        # Ask user what to do
        # (In real workflow, use AskUserQuestion tool)
        return False

    else:  # error
        # All YAMLs invalid
        print(f"✗ YAML Validation Failed: {output['message']}")
        return False

# Example usage in workflow
if workflow_phase_yaml_validation(project_path, yaml_files):
    # Continue to next phase
    pass
else:
    # Handle error or user decision
    pass
```

---

## Best Practices

### 1. Always Use --json Flag

For programmatic use, always include `--json` flag:

```python
# Good
subprocess.run(["aws-arch", "project", "create", "name", "--json"])

# Bad (human-readable output, hard to parse)
subprocess.run(["aws-arch", "project", "create", "name"])
```

### 2. Check Status Before Accessing Data

```python
output = run_cli_command(command)

# Always check status first
if output["status"] in ["success", "partial"]:
    data = output["data"]
    # Safe to access data
else:
    # Handle error
    error_message = output["message"]
```

### 3. Handle Partial Success

```python
if output["status"] == "partial":
    # Some items succeeded, some failed
    successful_count = output["data"]["successful"]
    failed_count = output["data"]["failed"]

    # Decide whether to continue or stop
    if successful_count > 0:
        # Continue with successful items
        pass
    else:
        # All failed (shouldn't happen with "partial" status)
        pass
```

### 4. Use Absolute Paths

```python
from pathlib import Path

# Convert to absolute path
project_path = Path("my-project").resolve()

# Use in CLI command
subprocess.run(["aws-arch", "project", "info", str(project_path), "--json"])
```

### 5. Capture and Log Errors

```python
output = run_cli_command(command)

if output["status"] == "error":
    # Log error details
    error_log = {
        "command": command,
        "error": output["message"],
        "timestamp": datetime.now().isoformat()
    }

    # Save to state or log file
    save_error_to_state(error_log)
```

---

## Summary

The `aws-arch` CLI provides comprehensive commands for AWS architecture diagram generation:

- **project**: Create and manage project structure
- **yaml**: Validate YAML specifications and list AWS services
- **python**: Generate Python diagram scripts
- **diagram**: Execute scripts and generate diagrams
- **drawio**: Convert DOT files to Draw.io XML

All commands support `--json` flag for machine-readable output with consistent schema:
```json
{"status": "success|partial|error", "message": "...", "data": {...}}
```

Exit codes: 0 (success/partial), 1 (error)

For skills integration, use subprocess with JSON parsing to invoke CLI commands programmatically.
