---
name: srd-generate
description: Generate the System Requirement Document from approved FRD, SDD and NFR, with a complete SR Inventory (Section 2) carrying scope tags for deterministic EPIC decomposition. Stage A4 of the UW CR Architecture Workspace.
---

Generate the System Requirement Document (SRD) for stage A4 of the Architecture
Workspace -- the sole input to EPIC decomposition.

## When this runs

Stage A4 of `pipelines/uw-cr-architecture.yaml`. It consumes `sdd`, `frd` and `nfr`;
it produces `srd`. Stage G8 decomposes the EPIC set from the SRD **alone**, and
approving that EPIC set opens one Mini Workspace per EPIC (FR-P4).

That makes this the highest-leverage document in the pipeline: a requirement
omitted here is never built, and no later stage can detect the omission.

## Workspace Output Resolution (ALWAYS RUN FIRST)

Before reading any inputs or writing any files, resolve the workspace:

```
workspace_id → from aidlc.config.json
OUT_DIR      → workspaces/{workspace_id}/design/
```

Create `OUT_DIR` if it does not exist.
- **Input files** (written by earlier stages): `{OUT_DIR}/frd.md`, `{OUT_DIR}/nfr.md`, `{OUT_DIR}/sdd.md`
- **Output files**: all written to `{OUT_DIR}/`

## CRITICAL: Single-pass execution

Context limits make multi-turn writing unsafe. **All reading, planning, and
writing must be completed in a single turn.** Follow this exact order:

1. Read `{OUT_DIR}/frd.md` — count every FRD requirement ID.
2. Read `{OUT_DIR}/nfr.md` — note every non-functional constraint.
3. Read `{OUT_DIR}/sdd.md` — note every design decision that creates a system requirement.
4. Plan all requirements and capability groupings mentally. Do NOT write planning notes to disk.
5. Write `{OUT_DIR}/srd-traceability.json` (medium — write this first).
6. Write `{OUT_DIR}/srd.md` **LAST** — after this Write call, output a single completion
   sentence and STOP. Do not re-read, do not verify, do not write anything else.

If you finish srd.md and notice a gap, add a `## Gaps and Limitations` section
inside srd.md itself. Never start a second turn to patch the output.

## Incremental section writing within srd.md

Write `srd.md` **in one Write call**, working top-to-bottom through the sections
below. Use a compact table layout for requirements so you can fit more per token:

```
| SR-nnn | Capability | Requirement | Source |
```

Pack each row tightly: one requirement per row, source inline. Avoid verbose
prose in the body rows — save narrative for the section introduction only (two
sentences max per section intro).

If you hit a natural stopping point before covering all requirements, add a
`## Remaining Requirements (Deferred)` section listing the un-expanded IDs
with one-line summaries. A partial-but-honest SRD is better than a truncated one
with no inventory of what was dropped.

## srd.md structure (write exactly in this order)

```
# System Requirement Document (SRD)
## AI Limitations Notice          ← verbatim block (see below) — include immediately after title
## Status
## Table of Contents
## 1. Purpose and Scope
## 2. SR Inventory                 ← write this before section 3; complete numbered list of every SR-ID
   | SR-ID | Summary | Priority | Scope |
   (Scope must be exactly "module" or "cross-cutting".
    cross-cutting = applies to all functional capabilities: audit writes, security headers,
    parameterised queries, HTML encoding, config externalisation, error handling.
    module = belongs to one specific capability.)
## 3. System Requirements          ← one sub-section per functional capability area (NOT EPIC-named)
   ### 3.1 <Capability name>
   | SR-nnn | summary | source |
   ...
## 4. Non-Functional Requirements  ← reference NFRs by ID; do not restate prose
## 5. Inter-Capability Dependencies
## 6. FRD Coverage Reconciliation
## 7. Gaps and Limitations         ← any gaps found; omit section if none
```

## Output files — write in this order

| # | File | Purpose | Typical size |
|---|------|---------|--------------|
| 1 | `{OUT_DIR}/srd-traceability.json` | `{"requirements": [{"id","sources","capability","scope"}]}` | < 2 000 tokens |
| 2 | `{OUT_DIR}/srd.md` | **The document — write last, then stop** | < 8 000 tokens |

Where `{OUT_DIR}` = `workspaces/{workspace_id}/design/` resolved from `aidlc.config.json`.

## Capability grouping principle

Group SRs by functional capability area — the natural subject-matter boundary
visible in the FRD (for example: authentication, navigation, user profile,
search). These groupings become the `### 3.x` section headings in srd.md.

Do NOT pre-group by EPIC and do NOT apply Gate A/B/C here. EPIC decomposition
is performed exclusively by the EPIC-set stage (G8 / ba-generate). The SRD's
job is to list every SR with a stable ID and scope tag so that stage has a
deterministic, fixed input.

For each SR assign one scope tag and record it in the SR Inventory table
(Section 2) and in srd-traceability.json:
- **`module`** — belongs to a single functional capability
- **`cross-cutting`** — applies to all capabilities (audit writes, security
  headers, parameterised queries, HTML encoding, config externalisation, error
  handling). A cross-cutting SR is never the founding SR of a capability section.

Never group by technical layer — "database layer", "error handling", "audit
logging" and "security hardening" are not capability areas.

## Grounding rules

1. **Cite or omit.** Every substantive statement traces to an approved upstream
   artefact. Write the citation inline: `[source: <type> v<version> / <section>]`.
2. **A refusal is not content.** If the KB returns nothing, say so. Do not
   substitute plausible text — a fabricated requirement poisons every downstream stage.
3. **Missing input stops you.** If a declared input is absent or unapproved, state
   what is missing and exit. Do not infer from titles.
4. **Never invent identifiers.** Requirement IDs, table names, and field names come
   from the inputs or schema snapshot only.

## AI Limitations block (include verbatim near top of srd.md)

> **This document was generated by a Large Language Model.** It may contain
> hallucinated requirements, may have lost detail through context compaction, and
> may be confidently wrong. It is a draft for human review, not an authority.
> No requirement in this document may be treated as approved until a named
> human approver has signed it off at the pipeline stage gate.

## Pre-write checklist (check mentally BEFORE calling Write on srd.md)

- FRD requirement count established and noted for coverage reconciliation
- SR Inventory table (Section 2) lists every SR-ID with Priority and Scope tag
- Every SR traces to at least one FRD, SDD, or NFR item
- NFRs referenced by ID only — not restated in full prose
- Cross-cutting SRs tagged `cross-cutting` in SR Inventory; all others tagged `module`
- No EPIC Gate A/B/C analysis performed — capability grouping only
- Inter-capability dependencies stated in section 5
- `srd-traceability.json` already written with `scope` field per requirement
- AI limitations block will appear near the top of srd.md
- Gaps and deferred requirements will be listed, not silently dropped

---

## Reporting to the AIDLC Platform (ECS UI tracking)

> **SERVER CLI GUARD:** If `aidlc.config.json` does **not** exist in your current
> working directory, skip this entire ECS section and run only the main workflow
> above. These steps are for the **local Claude Code session only**.

The local session creates the ECS run and monitors progress. All generation
is performed by the ECS server CLI — do **not** generate or copy files locally.

---

**Step 0 — Read config**
```powershell
$cfg   = Get-Content "aidlc.config.json" | ConvertFrom-Json
$BASE  = $cfg.central_base_url
$TOKEN = [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env)
$WS    = $cfg.workspace_id
$HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
$STAGE = "srd"
```

**Step 1 — Smart run management: cancel queued / attach running / create fresh**
```powershell
$existing = $null
try {
    $existing = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS&stage_key=$STAGE" -Headers $HDR).items |
        Where-Object { $_.state -in @("queued", "running") } |
        Sort-Object queued_at -Descending |
        Select-Object -First 1
} catch {}

if ($existing -and $existing.state -eq "queued") {
    Invoke-RestMethod "$BASE/pipeline-runs/$($existing.run_id)/cancel" -Headers $HDR -Method Post | Out-Null
    Write-Host "Cancelled queued run $($existing.run_id) — creating fresh run."
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
} elseif ($existing -and $existing.state -eq "running") {
    $RUN_ID = $existing.run_id
    Write-Host "Run already in progress: $RUN_ID — attaching to monitor."
} else {
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
}
```

**Step 2 — Monitor and display elapsed time**
```powershell
do {
    Start-Sleep -Seconds 15
    $run     = (Invoke-RestMethod "$BASE/pipeline-runs/$RUN_ID" -Headers $HDR).run
    $elapsed = if ($run.started_at) {
        $s = [datetime]::Parse($run.started_at)
        $e = if ($run.finished_at) { [datetime]::Parse($run.finished_at) } else { Get-Date }
        "$([int]($e - $s).TotalSeconds)s"
    } else { "queued" }
    $files = if ($run.files_written) { $run.files_written.Count } else { 0 }
    Write-Host "  [$elapsed]  state=$($run.state)  files=$files"
} while ($run.state -notin @("waiting_for_approval","completed","failed","cancelled"))
```

**Step 3 — Final timing summary**
```powershell
$fmt = { param($t) if ($t) { [datetime]::Parse($t).ToString("HH:mm:ss") } else { "—" } }
$sec = if ($run.started_at -and $run.finished_at) {
    [int]([datetime]::Parse($run.finished_at) - [datetime]::Parse($run.started_at)).TotalSeconds
} else { 0 }
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
Write-Host "  Run     : $RUN_ID"
Write-Host "  Stage   : $STAGE"
Write-Host "  State   : $($run.state)"
Write-Host "  Queued  : $(& $fmt $run.queued_at)"
Write-Host "  Started : $(& $fmt $run.started_at)"
Write-Host "  Finished: $(& $fmt $run.finished_at)"
Write-Host "  Elapsed : ${sec}s"
Write-Host "  Files   : $($run.files_written.Count) written"
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
```

**Step 4 — Review in ECS UI**
```
https://poc-ecs-build-ui.npsdlchgapp.us-east-1.aws.aig.net/aidlc-platform-management/pipeline
```

Approval persona: **Architect**
