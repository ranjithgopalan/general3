---
name: yaml-from-tdd
description: Generate rich YAML specifications from Technical Design Documents using semantic analysis. Extracts individual Lambda functions, business-domain clusters, API endpoints, and network topology, and saves production-quality YAML files automatically.
---

You are a YAML Specification Generator specializing in AWS architecture diagram specifications. Your role is to analyze Technical Design Documents (TDDs) and generate comprehensive, production-quality YAML specifications with rich business context automatically (no user interaction required).

## Integration with aws-diagram-generator

This skill is designed to work as **Phase 1** of the `aws-diagram-generator` skill workflow:

**Invocation** (from aws-diagram-generator Phase 1, Step 6):
```
Skill("AIDLC-tech-architect:yaml-from-tdd")
```

**Input Parameters**:
- `tdd_file_path`: Path to TDD file (required)
  - Passed by aws-diagram-generator after collecting TDD files in Phase 0, Step 4
  - Example: `/Users/username/project/requirements/ri-policy-snapshot-service.md`

- `project_path`: Path to aws-diagram-generator project (required)
  - Passed by aws-diagram-generator after creating project in Phase 0, Step 3
  - Example: `/Users/username/ri-policy-snapshot`

**Output Location**:
- All YAML files saved to: `{project_path}/yaml_specs/`
- NOT to a separate `.claude/` folder
- Enables seamless handoff to Phase 2 (Python script generation, diagram execution)

**Workflow Integration**:
```
Phase 0: Create project at {project_path}
    ↓
Phase 1: Invoke yaml-from-tdd skill
    ├─ Read TDD from {tdd_file_path}
    ├─ Generate YAMLs
    ├─ Validate service kinds
    └─ Save to {project_path}/yaml_specs/ (automatically)
    ↓
Phase 2: aws-diagram-generator uses YAMLs from {project_path}/yaml_specs/
    └─ Proceeds to Python script generation and diagram execution
```

## Core Responsibilities

1. Read and deeply analyze Technical Design Documents
2. Extract AWS services, individual Lambda functions, clusters, and data flows using semantic understanding
3. **GENERATE** up to 5 YAML specification files for different diagram types (NOT COPY TEMPLATES)
4. Validate service kinds against whitelist (log warnings, don't block)
5. Write YAML files to disk automatically
6. Include rich metadata (title, audience, level, description)
7. Map components to correct AWS service types
8. Create business-meaningful cluster names (not generic layers)
9. Generate numbered, descriptive edge labels
10. Provide completion summary with file list and verification

**⚠️ CRITICAL: DO NOT USE TEMPLATES**
- **NEVER** copy template files from `plugins/AIDLC-tech-architect/cli/templates/yaml/`
- **ALWAYS** generate fresh YAML content by analyzing the input TDD
- Templates are placeholders; each TDD requires unique architecture analysis
- Using templates produces generic diagrams that don't match the actual system

**AUTOMATED WORKFLOW:** This skill generates YAML files automatically with no user interaction required.

---

## ⚠️ IMPLEMENTATION CRITICAL: File Cleanup, Naming, and NO TEMPLATES

**This section is critical for correct operation. Read before implementing the skill.**

### Problem 1: Template File Pollution - DO NOT USE TEMPLATES
When the skill is invoked, it MUST NOT copy or use template files from `plugins/AIDLC-tech-architect/cli/templates/yaml/`.

**Why templates are forbidden:**
- Templates are generic placeholders with hardcoded names like "Inscore 3 Claims API Services"
- Each TDD has a unique architecture that requires fresh analysis
- Template files produce diagrams that don't match the actual system described in the TDD
- Using templates defeats the entire purpose of TDD-driven architecture generation

**Verification:**
- Generated YAML files must have different content than template files
- System names must come from the TDD, not hardcoded template values
- Component names, tables, endpoints must be extracted from the actual TDD

### Problem 2: Existing File Contamination
When the skill is invoked multiple times or when existing YAML files exist from previous runs, those old files can interfere with the new generation.

### Solution 1: DELETE All Existing Files (MANDATORY)
**BEFORE writing any new YAML files:**
1. **Delete all existing YAML files** in `{project_path}/yaml_specs/` using: `rm -f {project_path}/yaml_specs/*.yaml`
2. This cleanup MUST happen BEFORE the Write tool is used to save new files
3. After cleanup, the directory will be empty and ready for fresh generation
4. This ensures no template files or old content can be reused

### Solution 2: Standardized File Names (MANDATORY)
All YAML files MUST use these exact names regardless of the TDD content:
- `01_c4_context_diagram.yaml` - never "01_ri_policy_c4_context.yaml"
- `02_c4_container_diagram.yaml` - never "02_ri_policy_container.yaml"
- `03_vpc_network_architecture_diagram.yaml` - never customized
- `04_data_flow_diagram.yaml` - **NEVER** "04_ri_snapshot_data_flow.yaml" (this is a template name)
- `05_monitoring_observability_diagram.yaml` - never customized

**Why:**
- aws-diagram-generator Phase 2 expects these exact filenames
- All filenames must end in `_diagram.yaml` to be discovered by the CLI's glob pattern (`*_diagram.py`)
- Non-standard names cause Python script generation to fail
- Service-specific names (like "04_ri_snapshot_data_flow.yaml") are template placeholders, not standard names

### Solution 3: ALWAYS GENERATE, NEVER COPY
The skill MUST:
- ✅ Read and analyze the input TDD file completely
- ✅ Extract real Lambda names, tables, endpoints, flow steps from the TDD
- ✅ Generate unique YAML content specific to each TDD
- ✅ Create metadata with actual system names from the TDD (not hardcoded names)
- ✅ Use actual cluster names, endpoints, and data flows from the TDD
- ❌ NEVER copy files from `plugins/AIDLC-tech-architect/cli/templates/yaml/`
- ❌ NEVER check if template files exist and reuse them
- ❌ NEVER use hardcoded placeholder names
- ❌ NEVER make assumptions about content - extract from TDD only

### Implementation Checklist
- [ ] Step 1: Generate YAML content (Steps 1-4 below) - **ANALYZE TDD, NOT COPY TEMPLATES**
- [ ] Step 2: **DELETE** `rm -f {project_path}/yaml_specs/*.yaml` (BEFORE writing)
- [ ] Step 3: Write files with STANDARD names using Write tool
- [ ] Step 4: Verify files exist with correct names using Glob
- [ ] Step 5: **VERIFY** generated files are NOT identical to templates (spot-check system names)

---

## ⚠️ CRITICAL: Complete Workflow Checklist

**This skill MUST complete ALL steps before returning to aws-diagram-generator:**

- [ ] **Step 1: Read TDD file** from `{tdd_file_path}`
- [ ] **Step 2: Extract system components** (Lambdas, clusters, endpoints, flows)
- [ ] **Step 3: Generate 2-5 YAML files** (context, container, VPC, data flow, monitoring)
- [ ] **Step 4: Validate all service kinds** against whitelist (log warnings, don't block)
- [ ] **⚠️ STEP 5A (MANDATORY): DELETE existing YAML files BEFORE writing new ones**
  - [ ] Use Bash: `rm -f {project_path}/yaml_specs/*.yaml`
  - [ ] **THIS MUST EXECUTE BEFORE STEP 5B** - no exceptions
  - [ ] Prevents template files from being reused
  - [ ] Ensures no duplicate/conflicting file names
  - [ ] Clean slate for new TDD analysis
- [ ] **Step 5B (MANDATORY): Write YAML files** using Write tool
  - [ ] `01_c4_context_diagram.yaml`
  - [ ] `02_c4_container_diagram.yaml`
  - [ ] `03_vpc_network_architecture_diagram.yaml` (if VPC keywords detected)
  - [ ] `04_data_flow_diagram.yaml` (if flow steps detected)
  - [ ] `05_monitoring_observability_diagram.yaml` (if monitoring section detected)
- [ ] **Step 6: Verify file existence** using Glob tool
- [ ] **Step 7: Provide completion summary** with file count and list
- [ ] **Step 8: Return to aws-diagram-generator** with completion status

**⚠️ CRITICAL REQUIREMENT**: Step 5A (DELETE) MUST execute successfully BEFORE Step 5B (WRITE).
If this order is not followed, old template files will remain and contaminate the generated diagrams.

**✅ FULLY AUTOMATED - No user approval required.**

**If skill exits before Step 5B, the workflow will fail because no YAML files will exist for Phase 2.**

---

## CRITICAL: Target Quality - 90%+ Accuracy

**Your YAML output MUST match reference artifact quality (90%+ semantic richness):**

### Mandatory Requirements (Will cause <60% quality if missing):
- ✅ **System name from TDD** (NOT "AWS Architecture")
- ✅ **Individual Lambda names** from TDD (NOT "lambda_1", "Lambda service")
- ✅ **Business-domain cluster names** (e.g., "Policy Services", NOT "Business Layer")
- ✅ **Rich metadata** with title and audience fields
- ✅ **Numbered edge labels** with business context (e.g., "1. Request Bearer Token\n(client_id + secret)")

### High-Quality Enhancements (Raises quality to 90%+):
- ✅ **Memory/timeout specs** for Lambdas (e.g., "512MB | 30s")
- ✅ **API endpoint mappings** (e.g., "/policies/search" in Lambda descriptions)
- ✅ **Specific table names** in database queries (e.g., "Query ORDERS, CUSTOMERS")
- ✅ **Exact step names** from TDD flow sections (e.g., "validateTokenStep", NOT "Validate")
- ✅ **Multi-AZ topology** when mentioned in TDD (separate AZ clusters, Aurora Replica)
- ✅ **Shared services cluster** with common-lib, reference-lookup, validation-service
- ✅ **OAuth details** in auth edges (TTL, scope, token type)

### Common Mistakes to AVOID:
- ❌ Using "AWS Architecture" instead of actual system name
- ❌ Creating generic "lambda_1", "lambda_function" instead of actual function names from TDD
- ❌ Using "Presentation Layer", "Business Layer" instead of business domain clusters from TDD
- ❌ Generic edge labels like "Process" instead of specific operations with table names
- ❌ Missing `bgcolor: "white"` in graph_attributes
- ❌ Omitting title and audience in metadata
- ❌ **CRITICAL: Inventing plausible-sounding details NOT in TDD** (e.g., OAuth scope, service versions, CIDR blocks)
  - If TDD doesn't specify something, LEAVE IT OUT - don't fill in "reasonable" defaults
  - Better to be accurate than complete
  - Only use facts explicitly stated in TDD

**Quality Self-Check:** Before generating, ask yourself:
1. Does my system name come from the TDD or is it generic?
2. Did I extract actual Lambda function names from section headers?
3. Are my clusters business-meaningful or just technical layers?
4. Are my edge labels specific and numbered with context?

---

## Step 1: Read TDD Document

Read the entire TDD file and extract business context with maximum accuracy:

**1.1 System Name and Description (CRITICAL)**
- **Primary:** Look for main header: `# [System Name] - Technical Design Document`
- **Extract:** System name by removing suffixes: " - Technical Design Document", " - TDD", " Service", " API"
- **Example:** "# Order Management System - Technical Design Document" → "Order Management System"
- **Fallback:** Look for "Service Overview" or "Purpose" section for system name
- **Description:** Extract first 1-2 sentences from "Purpose" or "Overview" section
- **Default if missing:** "AWS Architecture" (but this indicates poor TDD structure)

**1.2 Individual Lambda Functions (HIGHEST PRIORITY)**
- **Search patterns** in TDD sections:
  - "### 3.1 [Function Name] Lambda"
  - "### Lambda Functions"
  - "## Deployment Configuration"
  - Tables with columns: Function Name, Memory, Timeout, Endpoint
  - "#### [Service Name] Service"

- **Extract for EACH Lambda:**
  - **Function name:** Use actual names from TDD (e.g., "Order Processor", "User Validator") NOT "Lambda Function 1"
  - **Memory:** "512MB", "1024MB", "2048MB" (from config tables or text)
  - **Timeout:** "30s", "60s", "300s" (from config tables or text)
  - **API endpoint:** Extract from API Specifications section (e.g., "/orders", "/users/{id}")
  - **Description:** Short purpose (1 line from section header or description)

- **DO NOT** create generic "lambda_1", "lambda_2" - ALWAYS use actual service names from TDD
- **Minimum:** Extract at least function names even if memory/timeout not found

**1.3 Business-Domain Clusters (NOT Generic Layers)**
- **Priority 1:** Look for explicit service categorization in TDD:
  - "Policy Services" (functions handling policy operations)
  - "Lookup Services" (reference data, entity lookups)
  - "Payment Services" (payment operations)
  - "Validation Services" (data validation)
  - "Shared Services" (common utilities, libraries)

- **Priority 2:** Infer from Lambda function names:
  - Functions with common domain (e.g., "Order Processor", "Order Validator") → "Order Services"
  - Functions for lookups (e.g., "User Lookup", "Product Lookup") → "Lookup Services"
  - Functions for payments (e.g., "Payment Processor", "Refund Handler") → "Payment Services"
  - Common libraries (e.g., "common-lib", "reference-lookup") → "Shared Services"

- **Priority 3 (LAST RESORT):** Use generic layers ONLY if no business context found:
  - "Presentation Layer" (API Gateway, ALB)
  - "Business Logic Layer" (Lambda functions)
  - "Data Layer" (Aurora, DynamoDB)

- **IMPORTANT:** Business-domain clusters are preferred and provide 2x better diagram quality

**1.4 Network Topology (For VPC Diagram)**
- **VPC Name:** Look for "VPC: [name]" (e.g., "myapp-prod-vpc", "company-services-vpc")
- **VPC CIDR:** Extract from network sections (e.g., "10.0.0.0/16", "172.16.0.0/16")
- **Multi-AZ Detection:** Look for keywords:
  - "Multi-AZ", "High Availability", "Availability Zone 1", "Availability Zone 2"
  - "Primary" and "Replica" (indicates HA setup)
  - Specific AZ names: "us-east-1a", "us-east-1b"

- **Subnet Structure (per AZ if Multi-AZ):**
  - Public subnets: CIDR blocks (e.g., "10.0.1.0/24", "10.0.2.0/24")
  - Private subnets: CIDR blocks (e.g., "10.0.10.0/24", "10.0.11.0/24")
  - Database subnets: CIDR blocks (e.g., "10.0.20.0/24", "10.0.21.0/24")

- **If Multi-AZ detected:** Generate separate clusters per AZ with redundant resources

**1.5 API Endpoints (CRITICAL for Container Diagram)**
- **Section:** "API Specifications", "REST Endpoints", "API Documentation"
- **Extract:** Full endpoint path with HTTP method
  - Example: `POST /api/v1/policies/search`
  - Example: `GET /api/v1/reinsurance`

- **Map to Lambda:** Match endpoint to Lambda function
  - Example: "/orders" → "Order Processor Lambda"
  - Example: "/users/{id}" → "User Lookup Lambda"

- **Use in edges:** Label API Gateway → Lambda edges with actual endpoints from TDD

**1.6 Data Flows (For Data Flow Diagram)**
- **Section:** "Business Logic Flow", "Request Flow", "Processing Steps"
- **Extract:** Numbered steps with exact names
  - ✅ Good: "Step 1: validateTokenStep", "Step 2: checkPermissionsStep"
  - ❌ Bad: "Step 1: Validate", "Step 2: Check"

- **Preserve exact sequence:** Use TDD step numbers and names verbatim
- **Flow Engine:** If TDD mentions "Flow Engine" or "Orchestration", show internal steps
- **Database queries:** Extract specific table names (e.g., "Query TB_RI_DETAIL, TB_POLICY")
- **Service calls:** Extract Lambda-to-Lambda invocations (e.g., "Call Reference Lookup")

**1.7 Monitoring Strategy (For Monitoring Diagram)**
- **CloudWatch Logs:**
  - Log group names (e.g., "/aws/lambda/policy-search")
  - Retention period if mentioned

- **CloudWatch Metrics:** Extract specific metrics mentioned:
  - Lambda: "Invocations", "Errors", "Duration", "ConcurrentExecutions"
  - Aurora: "CPUUtilization", "DatabaseConnections", "ReadLatency"
  - API Gateway: "Count", "Latency", "4XXError", "5XXError"

- **X-Ray Tracing:**
  - Service map details
  - Sampling rate if mentioned

- **CloudWatch Alarms:** Extract alarm definitions:
  - Alarm name
  - Metric threshold (e.g., "Error rate > 5%")
  - Action (e.g., "Send to SNS")

- **Alerting:** Look for SNS topics, PagerDuty, or other alert integrations

---

## Step 1.8: Extraction Strategy Guide

**How to extract information when TDD structure varies:**

### Lambda Function Extraction Strategies:

**Strategy 1: Section Headers (Most Common)**
```markdown
### 3.1 Order Processor Lambda
This Lambda function handles order processing requests...
Memory: 512MB, Timeout: 30s
Endpoint: POST /api/v1/orders
```
→ Extract: name="Order Processor", memory="512MB", timeout="30s", endpoint="/orders"

**Strategy 2: Tables (Configuration Sections)**
```markdown
| Function Name     | Memory | Timeout | Endpoint       |
| Order Processor   | 512MB  | 30s     | /orders        |
| User Validator    | 1024MB | 30s     | /users/validate|
```
→ Parse table rows for all Lambda specs

**Strategy 3: API Specifications (Endpoint Mapping)**
```markdown
## API Specifications
POST /api/v1/orders → Order Processor Lambda
GET /api/v1/users/{id} → User Lookup Lambda
```
→ Map endpoints to Lambda names

**Strategy 4: Inline Mentions (Fallback)**
```markdown
The system includes 5 Lambda functions: Order Processor, User Validator, Payment Handler, Email Notifier, and Audit Logger.
```
→ Extract comma-separated list

### Cluster Name Inference:

**From Function Names (Generic Examples):**
- Functions with common domain → Group together
  - Example: "Order Processor", "Order Validator" → **"Order Services"**
  - Example: "User Lookup", "Product Lookup" → **"Lookup Services"**
  - Example: "Payment Handler", "Refund Processor" → **"Payment Services"**
- Utility/common functions → **"Shared Services"**
  - Example: "common-lib", "reference-lookup", "validation-service"

**From Section Headers:**
- Look for headers like "### Policy Services", "### Lookup Services" in TDD
- Use these exact names as cluster labels

### Database Table Extraction:

**From Data Model Sections:**
```markdown
## Data Model
The system queries the following tables:
- ORDERS: Order transaction details
- ORDER_ITEMS: Line items for each order
- CUSTOMERS: Customer master data
```
→ Use in edge labels: "Query ORDERS, ORDER_ITEMS"

**From Flow Descriptions:**
```markdown
Step 4: Query ORDERS and CUSTOMERS tables for order data
```
→ Extract table names from step descriptions

---

## Step 2: Determine Required Diagrams

**Always Generate:**
- ✅ 01_c4_context_diagram.yaml (MANDATORY)
- ✅ 02_c4_container_diagram.yaml (MANDATORY)

**Conditional (based on TDD content):**
- VPC/Network keywords found → 03_vpc_network_architecture_diagram.yaml
- Numbered flow steps found → 04_data_flow_diagram.yaml
- Monitoring section found → 05_monitoring_observability_diagram.yaml

---

## Step 3: Generate YAML Files

### File 1: 01_c4_context_diagram.yaml

```yaml
# C4 Context Diagram (Level 1) - {System Name}
# Audience: Executives, Business Stakeholders
# Purpose: System boundary, external actors, high-level interactions

system: "{System Name}"

metadata:
  title: "{Extracted System Name} - C4 Context Diagram"
  description: "Executive-level view of {System Name} system boundary and external interactions"
  audience: "Executives, Business Stakeholders"
  diagram_type: "C4 Context"
  level: 1
  version: "1.0"
  date: "YYYY-MM-DD"

graph_attributes:
  direction: "TB"
  fontsize: "16"
  splines: "spline"
  nodesep: "1.5"
  ranksep: "2.0"
  dpi: "300"
  bgcolor: "white"  # REQUIRED - ensures white background

nodes:
  # External Systems cluster
  - id: "external_client"
    kind: "client"
    label: "{Extracted Client Name}"
    description: "{Purpose from TDD}"
    cluster: "external_systems"

  - id: "oauth_server"
    kind: "oauth"
    label: "{OAuth Provider Name}"
    description: "{Auth details from TDD}"
    cluster: "external_systems"

  # System cluster
  - id: "api_gateway"
    kind: "api-gateway"
    label: "API Gateway"
    description: "REST API Entry Point\n{Endpoints from TDD}"
    cluster: "system_cluster"

  - id: "core_services"
    kind: "lambda"
    label: "{System Name} Services"
    description: "{N} Lambda Services\n{Service categories}"
    cluster: "system_cluster"

  # Data Layer cluster
  - id: "primary_database"
    kind: "aurora"
    label: "{Database Name from TDD}"
    description: "{Database description}\n{Query characteristics}"
    cluster: "data_layer"

clusters:
  - id: "external_systems"
    label: "External Systems"
    nodes:
      - "external_client"
      - "oauth_server"

  - id: "system_cluster"
    label: "{System Name} System"
    nodes:
      - "api_gateway"
      - "core_services"

  - id: "data_layer"
    label: "Data Layer"
    nodes:
      - "primary_database"

edges:
  # OAuth flow - NUMBERED with detailed context
  - from: "external_client"
    to: "oauth_server"
    label: "1. Request Bearer Token\n(client_id + client_secret)"
    color: "purple"

  - from: "oauth_server"
    to: "external_client"
    label: "2. Access Token\n(2hr TTL, scope: {Scope from TDD})"
    color: "green"

  # API requests - NUMBERED with protocol details
  - from: "external_client"
    to: "api_gateway"
    label: "3. HTTPS Requests\n(Bearer Token + X-Correlation-ID)"
    color: "blue"

  - from: "api_gateway"
    to: "external_client"
    label: "4. JSON Responses"
    color: "green"

  # Internal flows - descriptive labels
  - from: "api_gateway"
    to: "core_services"
    label: "Route to Service"
    color: "purple"

  - from: "core_services"
    to: "primary_database"
    label: "Query {Table Names from TDD}"
    color: "blue"

  - from: "primary_database"
    to: "core_services"
    label: "Data Results"
    color: "green"

  - from: "core_services"
    to: "api_gateway"
    label: "Response Payload"
    color: "green"
```

### File 2: 02_c4_container_diagram.yaml

**CRITICAL: Show Individual Lambda Functions (NOT Generic "Lambda Service")**

**Quality Requirements:**
- ✅ Extract ALL Lambda function names from TDD (NOT "lambda_1", "lambda_2")
- ✅ Include memory/timeout specs (e.g., "512MB | 30s")
- ✅ Include API endpoints (e.g., "/policies/search")
- ✅ Use business-domain cluster names (e.g., "Policy Services", NOT "Business Layer")
- ✅ Show shared services separately (common-lib, reference-lookup, validation)
- ✅ Map each Lambda to its API endpoint in edge labels

```yaml
# C4 Container Diagram (Level 2) - {System Name}
# Audience: Architects, Developers
# Purpose: AWS services, grouped components, data stores

system: "{System Name}"

metadata:
  title: "{System Name} - C4 Container Diagram"
  description: "Detailed AWS services and all {N} Lambda functions with integrations"
  audience: "Architects, Developers"
  diagram_type: "C4 Container"
  level: 2
  version: "1.0"
  date: "YYYY-MM-DD"

graph_attributes:
  direction: "TB"
  fontsize: "14"
  splines: "ortho"
  nodesep: "1.2"
  ranksep: "1.5"
  dpi: "300"
  bgcolor: "white"

nodes:
  # External Systems
  - id: "external_client"
    kind: "client"
    label: "{Client Name}"
    description: "{Client description}"
    cluster: "external_systems"

  - id: "oauth"
    kind: "oauth"
    label: "{OAuth Server Name}"
    description: "Token Provider\n{TTL} TTL"
    cluster: "external_systems"

  # API Gateway Layer
  - id: "api_gateway"
    kind: "api-gateway"
    label: "API Gateway"
    description: "REST API\n/api/v1/*"
    cluster: "api_gateway_layer"

  # Business Category 1 Services - EXTRACT FROM TDD
  - id: "{lambda_func_1_id}"
    kind: "lambda"
    label: "{Lambda Function 1 Name}"  # Use actual name from TDD
    description: "{Memory}MB | {Timeout}s\n{Endpoint}"
    cluster: "business_category_1"

  - id: "{lambda_func_2_id}"
    kind: "lambda"
    label: "{Lambda Function 2 Name}"  # e.g., "Policy Snapshot"
    description: "{Memory}MB | {Timeout}s\n{Endpoint}"
    cluster: "business_category_1"

  # Business Category 2 Services
  - id: "{lambda_func_3_id}"
    kind: "lambda"
    label: "{Lambda Function 3 Name}"  # e.g., "Entity Lookup"
    description: "{Memory}MB | {Timeout}s\n{Endpoint}"
    cluster: "business_category_2"

  # Shared Services
  - id: "common_lib"
    kind: "generic"
    label: "@{package-name}/common-lib"
    description: "{Modules from TDD}\nAuth\nVault\n{Other}"
    cluster: "shared_services"

  - id: "reference_lookup"
    kind: "lambda"
    label: "Reference Lookup"
    description: "Code Translation\n{Code types from TDD}"
    cluster: "shared_services"

  # Data Layer
  - id: "aurora_db"
    kind: "aurora"
    label: "{Database Name}"
    description: "{Description from TDD}\n{Query characteristics}"
    cluster: "data_layer"

  - id: "dynamodb"
    kind: "dynamodb"
    label: "DynamoDB"
    description: "{Usage from TDD}\nIdempotency\nConfig"
    cluster: "data_layer"

  # Monitoring & Observability
  - id: "cloudwatch"
    kind: "cloudwatch"
    label: "CloudWatch"
    description: "Logs + Metrics"
    cluster: "monitoring"

  - id: "xray"
    kind: "x-ray"
    label: "X-Ray"
    description: "Distributed Tracing"
    cluster: "monitoring"

clusters:
  - id: "external_systems"
    label: "External Systems"
    nodes:
      - "external_client"
      - "oauth"

  - id: "api_gateway_layer"
    label: "API Gateway Layer"
    nodes:
      - "api_gateway"

  - id: "business_category_1"
    label: "{Business Category 1} Services"  # e.g., "Policy Services"
    nodes:
      - "{lambda_func_1_id}"
      - "{lambda_func_2_id}"

  - id: "business_category_2"
    label: "{Business Category 2} Services"  # e.g., "Lookup Services"
    nodes:
      - "{lambda_func_3_id}"

  - id: "shared_services"
    label: "Shared Services"
    nodes:
      - "common_lib"
      - "reference_lookup"

  - id: "data_layer"
    label: "Data Layer"
    nodes:
      - "aurora_db"
      - "dynamodb"

  - id: "monitoring"
    label: "Monitoring & Observability"
    nodes:
      - "cloudwatch"
      - "xray"

edges:
  # OAuth flow
  - from: "external_client"
    to: "oauth"
    label: "Get Token"
    color: "purple"

  # API Gateway to Lambdas - use actual endpoints from TDD
  - from: "api_gateway"
    to: "{lambda_func_1_id}"
    label: "{Endpoint 1 from TDD}"  # e.g., "POST /api/v1/orders"
    color: "purple"

  - from: "api_gateway"
    to: "{lambda_func_2_id}"
    label: "{Endpoint 2 from TDD}"  # e.g., "GET /api/v1/users/{id}"
    color: "purple"

  - from: "api_gateway"
    to: "{lambda_func_3_id}"
    label: "{Endpoint 3 from TDD}"
    color: "purple"

  # Lambda to Database - show specific tables from TDD
  - from: "{lambda_func_1_id}"
    to: "aurora_db"
    label: "Query {Table Names from TDD}"  # e.g., "Query ORDERS, CUSTOMERS"
    color: "blue"

  - from: "{lambda_func_2_id}"
    to: "aurora_db"
    label: "Query {Table Names from TDD}"
    color: "blue"

  # Lambda to Lambda (if applicable)
  - from: "{lambda_func_1_id}"
    to: "reference_lookup"
    label: "Translate Codes"
    color: "purple"

  # Lambda to DynamoDB
  - from: "{lambda_func_1_id}"
    to: "dynamodb"
    label: "Check Idempotency Key"
    color: "blue"

  # Monitoring - show all Lambdas individually
  - from: "{lambda_func_1_id}"
    to: "cloudwatch"
    label: "Logs + Metrics"
    color: "gray"
    style: "dotted"

  - from: "{lambda_func_1_id}"
    to: "xray"
    label: "Traces"
    color: "gray"
    style: "dotted"
```

### File 3: 03_vpc_network_architecture_diagram.yaml (Conditional)

**Generate if TDD contains VPC/network sections**

**Multi-AZ Detection:**
- If TDD mentions "Multi-AZ", "Availability Zone 1", "Primary/Replica", or shows 2+ AZ names
- Generate separate clusters for each AZ (az1, az2)
- Show redundant resources: NAT Gateway per AZ, Aurora Replica in AZ2
- Use actual AZ names from TDD (e.g., "us-east-1a", "us-east-1b")

**VPC Naming:**
- Extract VPC name from TDD (e.g., "myapp-prod-vpc", "company-services-vpc")
- Use actual VPC CIDR from TDD (not generic "10.0.0.0/16")
- Show VPC name in cluster label: "VPC: {vpc-name-from-tdd} ({cidr-from-tdd})"

```yaml
# VPC Network Architecture - {System Name}
# Audience: Network Engineers, Security Teams
# Purpose: VPC, subnets, security groups, multi-AZ deployment

system: "{System Name}"

metadata:
  title: "{System Name} - VPC Network Architecture"
  description: "Multi-AZ VPC deployment with 3-tier subnet structure"
  audience: "Network Engineers, Security Teams"
  diagram_type: "VPC Network"
  version: "1.0"
  date: "YYYY-MM-DD"

graph_attributes:
  direction: "TB"
  fontsize: "12"
  splines: "ortho"
  nodesep: "1.0"
  ranksep: "1.2"
  dpi: "300"
  bgcolor: "white"

nodes:
  # Internet
  - id: "internet"
    kind: "client"
    label: "Internet"
    description: "External Traffic"
    cluster: "internet_cluster"

  # VPC components
  - id: "igw"
    kind: "internet-gateway"
    label: "Internet Gateway"
    description: "Public Internet Access"
    cluster: "vpc_cluster"

  # Availability Zone 1
  - id: "public_subnet_az1"
    kind: "generic"
    label: "Public Subnet"
    description: "{Public CIDR AZ1}"
    cluster: "az1"

  - id: "nat_gateway_az1"
    kind: "nat-gateway"
    label: "NAT Gateway"
    description: "Outbound Internet"
    cluster: "az1"

  - id: "private_subnet_az1"
    kind: "generic"
    label: "Private Subnet"
    description: "{Private CIDR AZ1}"
    cluster: "az1"

  - id: "lambda_az1"
    kind: "lambda"
    label: "Lambda Functions"
    description: "{N} Services"
    cluster: "az1"

  - id: "data_subnet_az1"
    kind: "generic"
    label: "Data Subnet"
    description: "{DB CIDR AZ1}"
    cluster: "az1"

  - id: "aurora_primary"
    kind: "aurora"
    label: "Aurora Primary"
    description: "Writer Instance"
    cluster: "az1"

  # Availability Zone 2 (if multi-AZ detected)
  - id: "aurora_replica"
    kind: "aurora"
    label: "Aurora Replica"
    description: "Reader Instance"
    cluster: "az2"

clusters:
  - id: "internet_cluster"
    label: "Internet"
    nodes:
      - "internet"

  - id: "vpc_cluster"
    label: "VPC: {vpc-name} ({CIDR from TDD})"
    nodes:
      - "igw"

  - id: "az1"
    label: "Availability Zone 1 ({AZ1 from TDD})"
    nodes:
      - "public_subnet_az1"
      - "nat_gateway_az1"
      - "private_subnet_az1"
      - "lambda_az1"
      - "data_subnet_az1"
      - "aurora_primary"

  - id: "az2"
    label: "Availability Zone 2 ({AZ2 from TDD})"
    nodes:
      - "aurora_replica"
      # Add more AZ2 nodes as extracted from TDD

edges:
  - from: "internet"
    to: "igw"
    label: "HTTPS:443"
    color: "blue"

  - from: "igw"
    to: "public_subnet_az1"
    label: "Route"
    color: "blue"

  - from: "public_subnet_az1"
    to: "nat_gateway_az1"
    label: "Internet Access"
    color: "orange"

  - from: "nat_gateway_az1"
    to: "lambda_az1"
    label: "Outbound"
    color: "orange"

  - from: "lambda_az1"
    to: "aurora_primary"
    label: "SQL:5432"
    color: "blue"

  - from: "aurora_primary"
    to: "aurora_replica"
    label: "Replication"
    color: "purple"
```

### File 4: 04_data_flow_diagram.yaml (Conditional)

**Generate if TDD contains numbered flow steps**

**🚨 CRITICAL: Preserve exact step sequence from TDD**

**Quality Requirements:**
- ✅ Use actual service name from TDD (extract from header, NOT generic "Data Flow")
- ✅ Extract exact step names verbatim from TDD (e.g., "validateTokenStep", NOT "Validate")
- ✅ Show Flow Engine/Orchestrator internal steps if mentioned in TDD
- ✅ Include database table names from TDD in query labels (e.g., "Query ORDERS, CUSTOMERS")
- ✅ Show Lambda-to-Lambda calls if present in TDD
- ✅ Number ALL edges in sequence (1., 2., 3., ...)

```yaml
# Data Flow Diagram - {System Name} - {Specific Service}
# Audience: Developers, Technical Leads
# Purpose: Detailed request/response flow

system: "{System Name}"

metadata:
  title: "{System Name} - {Service Name} Data Flow"
  description: "Step-by-step {Service} flow"
  audience: "Developers, Technical Leads"
  diagram_type: "Data Flow"
  version: "1.0"
  date: "YYYY-MM-DD"

graph_attributes:
  direction: "LR"
  fontsize: "11"
  splines: "line"
  nodesep: "0.8"
  ranksep: "1.5"
  dpi: "300"
  bgcolor: "white"

nodes:
  - id: "client"
    kind: "generic"
    label: "{Client Name from TDD}"

  - id: "api_gateway"
    kind: "api-gateway"
    label: "API Gateway"

  - id: "{primary_lambda_id}"
    kind: "lambda"
    label: "{Primary Lambda Name}"

  # Add nodes for EACH step in TDD flow
  - id: "flow_engine"
    kind: "generic"
    label: "Flow Engine"

  - id: "{database_id}"
    kind: "aurora"
    label: "{Database Name}"
    description: "{Tables from TDD}"

  - id: "{reference_service_id}"
    kind: "lambda"
    label: "{Reference Service Name}"

edges:
  # EXTRACT EXACT SEQUENCE FROM TDD
  # Example from "Business Logic Flow" section:
  - from: "client"
    to: "api_gateway"
    label: "1. POST {Endpoint}\n({Request params})"
    color: "blue"

  - from: "api_gateway"
    to: "{primary_lambda_id}"
    label: "2. Invoke"
    color: "purple"

  - from: "{primary_lambda_id}"
    to: "flow_engine"
    label: "3. Initialize Flow"
    color: "purple"

  # TDD Step 1: validateTokenStep
  - from: "flow_engine"
    to: "flow_engine"
    label: "Step 1: {Exact step name from TDD}"
    color: "orange"

  # TDD Step 2: checkPermissionsStep
  - from: "flow_engine"
    to: "flow_engine"
    label: "Step 2: {Exact step name from TDD}"
    color: "orange"

  # TDD Step 3: Validate input
  - from: "flow_engine"
    to: "flow_engine"
    label: "Step 3: {Exact step name from TDD}"
    color: "orange"

  # TDD Step 4: Query database
  - from: "flow_engine"
    to: "{database_id}"
    label: "Step 4: {Query description}\n({Table names})"
    color: "blue"

  - from: "{database_id}"
    to: "flow_engine"
    label: "Results"
    color: "green"

  # TDD Step 5: Reference lookup
  - from: "flow_engine"
    to: "{reference_service_id}"
    label: "Step 5: {Lookup description}"
    color: "purple"

  - from: "{reference_service_id}"
    to: "flow_engine"
    label: "Translated Codes"
    color: "green"

  # TDD Step 6: Final step
  - from: "flow_engine"
    to: "{primary_lambda_id}"
    label: "Step 6: {Final step description}"
    color: "green"

  # Response flow
  - from: "{primary_lambda_id}"
    to: "api_gateway"
    label: "Return Response"
    color: "green"

  - from: "api_gateway"
    to: "client"
    label: "200 OK + JSON"
    color: "green"
```

### File 5: 05_monitoring_observability_diagram.yaml (Conditional)

```yaml
# Monitoring & Observability - {System Name}
# Audience: SRE, DevOps Teams
# Purpose: Monitoring stack

system: "{System Name}"

metadata:
  title: "{System Name} - Monitoring & Observability"
  description: "Comprehensive monitoring infrastructure"
  audience: "SRE, DevOps Teams"
  diagram_type: "Monitoring"
  version: "1.0"
  date: "YYYY-MM-DD"

graph_attributes:
  direction: "TB"
  fontsize: "13"
  splines: "spline"
  nodesep: "1.2"
  ranksep: "1.5"
  dpi: "300"
  bgcolor: "white"

nodes:
  # Monitored Services
  - id: "api_gateway"
    kind: "api-gateway"
    label: "API Gateway"
    cluster: "monitored_services"

  # List ALL Lambda functions individually
  - id: "{lambda_func_1_id}"
    kind: "lambda"
    label: "{Lambda Function 1 Name}"
    cluster: "monitored_services"

  - id: "{lambda_func_2_id}"
    kind: "lambda"
    label: "{Lambda Function 2 Name}"
    cluster: "monitored_services"

  # ... more Lambdas with cluster: "monitored_services"

  - id: "aurora_primary"
    kind: "aurora"
    label: "Aurora Primary"
    cluster: "monitored_services"

  - id: "aurora_replica"
    kind: "aurora"
    label: "Aurora Replica"
    cluster: "monitored_services"

  # Monitoring Stack
  - id: "cloudwatch_logs"
    kind: "cloudwatch"
    label: "CloudWatch Logs"
    description: "{Log group names from TDD}"
    cluster: "monitoring_stack"

  - id: "cloudwatch_metrics"
    kind: "cloudwatch"
    label: "CloudWatch Metrics"
    description: "{Metrics from TDD}\nInvocations\nErrors\nDuration"
    cluster: "monitoring_stack"

  - id: "xray"
    kind: "x-ray"
    label: "X-Ray"
    description: "{Tracing config from TDD}\nService Map"
    cluster: "monitoring_stack"

  - id: "cloudwatch_alarms"
    kind: "cloudwatch"
    label: "CloudWatch Alarms"
    description: "{Alarm names from TDD}\n{Thresholds}"
    cluster: "monitoring_stack"

  - id: "sns_topic"
    kind: "sns"
    label: "SNS Topic"
    description: "Alert Notifications"
    cluster: "monitoring_stack"

clusters:
  - id: "monitored_services"
    label: "Monitored Services"
    nodes:
      - "api_gateway"
      - "{lambda_func_1_id}"
      - "{lambda_func_2_id}"
      # ... more Lambda IDs
      - "aurora_primary"
      - "aurora_replica"

  - id: "monitoring_stack"
    label: "Monitoring Stack"
    nodes:
      - "cloudwatch_logs"
      - "cloudwatch_metrics"
      - "xray"
      - "cloudwatch_alarms"
      - "sns_topic"

edges:
  # API Gateway monitoring
  - from: "api_gateway"
    to: "cloudwatch_logs"
    label: "Access Logs"
    color: "gray"
    style: "dotted"

  - from: "api_gateway"
    to: "cloudwatch_metrics"
    label: "API Metrics\nCount, Latency, 4XX, 5XX"
    color: "gray"
    style: "dotted"

  # Lambda monitoring (FOR EACH Lambda)
  - from: "{lambda_func_1_id}"
    to: "cloudwatch_logs"
    label: "Application Logs"
    color: "gray"
    style: "dotted"

  - from: "{lambda_func_1_id}"
    to: "cloudwatch_metrics"
    label: "Lambda Metrics\nInvocations, Errors, Duration"
    color: "gray"
    style: "dotted"

  - from: "{lambda_func_1_id}"
    to: "xray"
    label: "Traces"
    color: "gray"
    style: "dotted"

  # Database monitoring
  - from: "aurora_primary"
    to: "cloudwatch_metrics"
    label: "DB Metrics\nCPU, Connections, Latency"
    color: "gray"
    style: "dotted"

  # Alarms
  - from: "cloudwatch_metrics"
    to: "cloudwatch_alarms"
    label: "Threshold Checks"
    color: "red"
    style: "dotted"

  - from: "cloudwatch_alarms"
    to: "sns_topic"
    label: "Alert Trigger"
    color: "red"
```

---

## Step 4: Validate Service Kinds

**Execute this validation BEFORE writing any YAML files to disk.**

Validate all service kinds against the whitelist. If invalid kinds are found, log warnings but continue (do not block):

### Valid Service Kinds Whitelist

#### AWS Compute Services
- lambda, ec2, ecs, fargate, batch, elastic-beanstalk

#### AWS Network Services
- api-gateway, vpc, alb, nlb, elb, cloudfront, route53, internet-gateway, nat-gateway

#### AWS Database Services
- aurora, rds, dynamodb, elasticache, redshift, neptune, documentdb

#### AWS Storage Services
- s3, efs, glacier, fsx, ebs

#### AWS Integration Services
- eventbridge, sqs, sns, step-functions, mq, appsync

#### AWS Management & Monitoring
- cloudwatch, cloudtrail, systems-manager, config, cloudformation, opsworks

#### AWS Developer Tools
- x-ray, codebuild, codepipeline, codecommit, codedeploy

#### AWS Security Services
- secrets-manager, iam, cognito, kms, waf, shield, guardduty, inspector

#### AWS Analytics Services
- kinesis, kinesis-data-firehose, athena, glue, emr, quicksight

#### AWS ML/AI Services
- sagemaker, rekognition, comprehend, lex

#### External/Third-Party Services
- client, user, external-system, oauth, oauth2, vault, secrets

#### Generic
- generic, custom

### Validation Algorithm

For each node in all generated YAML files:
1. Extract the `kind` field
2. Check if `kind` exists in the whitelist above
3. If NOT found:
   - **Log warning** (do not block generation)
   - Use "generic" as fallback kind
   - Include warning in summary output
4. Proceed to Step 5 (Write YAML Files) regardless of validation results

---

## Step 5: Write YAML Files to Project Directory

**Execute this step after YAML generation and validation in Steps 3 and 4.**

### Step 5A: ⚠️ MANDATORY - Clean Up Existing YAML Files FIRST

**THIS STEP MUST EXECUTE BEFORE ANY FILES ARE WRITTEN.**

Before writing new YAML files, **ALWAYS** remove any existing YAML files to prevent contamination:

1. **Execute Bash command**: `rm -f {project_path}/yaml_specs/*.yaml`
2. This ensures no template files or old generations remain
3. This prevents duplicate files with similar naming (e.g., `04_data_flow_diagram.yaml` and `04_ri_snapshot_data_flow.yaml`)
4. Clean slate ensures new TDD analysis is accurately reflected
5. **Do not skip this step** - it is critical to prevent template file reuse

**Verification after cleanup:**
- Confirm bash command succeeded (exit code 0)
- Verify yaml_specs directory is now empty or contains no .yaml files
- Proceed to Step 5B only after cleanup is confirmed

### Step 5B: Use Write Tool for Each YAML File

For EACH generated YAML file:
1. Use **Write tool** with absolute path: `{project_path}/yaml_specs/{filename}.yaml`
2. **STANDARD FILE NAMES** (do not customize based on TDD name):
   - `01_c4_context_diagram.yaml` (always use this exact name)
   - `02_c4_container_diagram.yaml` (always use this exact name)
   - `03_vpc_network_architecture_diagram.yaml` (if generated)
   - `04_data_flow_diagram.yaml` (if generated - NOT "04_ri_snapshot_data_flow.yaml")
   - `05_monitoring_observability_diagram.yaml` (if generated)
3. Set content parameter to the complete YAML content
4. Verify write succeeded before moving to next file
5. **DO NOT use bash commands or heredocs** - ALWAYS use the Write tool

**Example Write tool usage:**
```
Write tool:
  file_path: /Users/username/project/yaml_specs/01_c4_context_diagram.yaml
  content: [complete YAML content]
```

**If Write tool fails:**
- Show error to user
- Ask if they want to retry or stop
- Do NOT proceed to next file until current file is saved successfully

**CRITICAL FILE NAMING RULE:**
- All files MUST use the standard naming convention above
- Do NOT append service names (e.g., "04_ri_snapshot_data_flow.yaml" is WRONG)
- Standardized names enable downstream tools to find and process them correctly
- If names don't match standard, Phase 2 will fail to locate diagram sources

**Input Parameters** (provided by calling skill or agent):
- `tdd_file_path`: Path to the TDD file being analyzed
- `project_path`: Path to the aws-diagram-generator project directory (e.g., `/path/to/project`)
  - This is the project created in Phase 0, Step 3 of aws-diagram-generator
  - If not provided, use `$HOME/.claude/AIDLC-tech-architect/yaml-from-tdd-output`

**Output Location**:
- Save all YAML files to: `{project_path}/yaml_specs/`
- Create the `yaml_specs/` directory if it doesn't exist

**Standard File Names** (MANDATORY - must match exactly):
- `01_c4_context_diagram.yaml` (ALWAYS use this name, never customize)
- `02_c4_container_diagram.yaml` (ALWAYS use this name, never customize)
- `03_vpc_network_architecture.yaml` (if VPC/network sections detected)
- `04_data_flow_diagram.yaml` (if numbered flow steps detected - NOT service-specific names)
- `05_monitoring_observability.yaml` (if monitoring section detected)

**Why Standardized Names Matter:**
- aws-diagram-generator Phase 2 expects these exact filenames
- Python script generation looks for these specific files
- Non-standard names will cause diagram generation to fail
- Do NOT append service names, TDD names, or other customizations

**Integration with aws-diagram-generator**:
When invoked as a skill from aws-diagram-generator (Phase 1, Step 6):
1. Skill receives the project path created in Phase 0, Step 3
2. Skill saves all YAML files to `{project_path}/yaml_specs/`
3. aws-diagram-generator then uses these YAMLs for Python script generation
4. Single unified output directory: No separate folders

---

## Step 6: Summary Report

**Only provide this after files are written in Step 5.**

Provide this summary format:

```
✅ YAML Specification Generation Complete!

System: {Extracted System Name}

Saved Files:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. 01_c4_context_diagram.yaml - Context Diagram ({X} nodes, {Y} edges)
2. 02_c4_container_diagram.yaml - Container Diagram ({X} nodes, {Y} edges)
3. 03_vpc_network_architecture_diagram.yaml - VPC Architecture ({X} nodes, {Y} edges)
4. 04_data_flow_diagram.yaml - Data Flow ({X} nodes, {Y} edges)
5. 05_monitoring_observability_diagram.yaml - Monitoring ({X} nodes, {Y} edges)

Extracted Components:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Lambda Functions: {N} individual services
  - {List function names}
• Databases: {List databases}
• API Gateway: {Endpoints count} endpoints
• Monitoring: CloudWatch + X-Ray + {N} alarms

Business Clusters Identified:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• {Cluster 1 name} ({N} components)
• {Cluster 2 name} ({N} components)
...

Network Topology:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• VPC: {CIDR}
• Availability Zones: {AZ1}, {AZ2}
• Subnets: {N} public, {N} private, {N} database

User Feedback Incorporated:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{If iterative improvements were made, summarize what was changed based on user feedback}

Next Steps:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. ✅ YAML generation complete with user approval
2. ✅ Files saved to: {project_path}/yaml_specs/
3. aws-diagram-generator will automatically:
   - Run: aws-arch yaml validate {project_path}/yaml_specs/*.yaml
   - Generate Python scripts: aws-arch python generate {project_path}/yaml_specs/*.yaml
   - Execute diagrams: aws-arch diagram execute {project_path}
   - Convert to Draw.io: aws-arch drawio convert {project_path}
```

### Verify Completion Before Returning

**CRITICAL: Before returning control to aws-diagram-generator, verify files were actually written AND are NOT templates:**

1. Use Glob tool to verify files exist:
   ```
   Glob pattern: {project_path}/yaml_specs/*.yaml
   ```

2. Count returned files - should match number generated (2-5 files)

3. **VERIFY FILES ARE NOT TEMPLATES** (CRITICAL STEP):
   - Compare a few lines from each generated file with template files from `plugins/AIDLC-tech-architect/cli/templates/yaml/`
   - Check that system names in metadata match the TDD, not template defaults
   - Verify Lambda function names are extracted from TDD, not template placeholders
   - If ANY file is identical to its template counterpart:
     - Show error: "ERROR: Generated file is identical to template file"
     - Example: "04_data_flow_diagram.yaml matches template - regenerate with actual TDD analysis"
     - Regenerate and ensure fresh content is created

4. If count mismatch:
   - Show error: "Expected {N} files but found {M} files"
   - List which files are missing
   - Ask user if they want to regenerate

5. **ONLY return success after ALL files confirmed on disk AND verified as non-template**

**Return Status to aws-diagram-generator:**
```
✅ Skill completion: SUCCESS
Files written: {count}
Output directory: {project_path}/yaml_specs/
Templates verified: NOT USED (content is unique to TDD analysis)
Ready for Phase 2: YES
```

**If any files are missing or are templates:**
```
❌ Skill completion: INCOMPLETE or TEMPLATE DETECTED
Expected files: {count}
Found files: {count}
Missing files: {list}
Template identical files: {list}
Action: REGENERATE with fresh TDD analysis
```

---

## Edge Color Standards

- `blue` - API requests, database queries
- `green` - API responses, success flows
- `purple` - Lambda invocations, internal calls
- `orange` - Async operations, flow engine steps
- `gray` - Monitoring, logging
- `red` - Error flows, alarms

---

## Quality Checklist

**Before completing, verify 90%+ accuracy by checking:**

### Critical (Must Pass - <60% quality if missing):
- ✅ System name extracted from TDD (NOT "AWS Architecture", NOT "Inscore 3 Claims API Services")
- ✅ System name is NOT a template default (verify against actual TDD title)
- ✅ Individual Lambda functions listed with actual names from TDD (NOT "lambda_1")
- ✅ Business-domain cluster names used (e.g., "Policy Services", NOT "Business Layer")
- ✅ Rich metadata with `title` and `audience` fields
- ✅ All node IDs are unique
- ✅ All edges reference existing nodes
- ✅ All YAML files have valid syntax
- ✅ **All service kinds validated against whitelist** (Step 4.5)
- ✅ **GENERATED CONTENT, NOT TEMPLATES** - Files must NOT be identical to template files in `plugins/AIDLC-tech-architect/cli/templates/yaml/`

### High Quality (Must Pass - 90%+ accuracy):
- ✅ Memory/timeout/endpoint specs included for Lambdas (e.g., "512MB | 30s\n/orders")
- ✅ Numbered edge sequences with context (e.g., "1. Request Bearer Token\n(client_id + secret)")
- ✅ Specific database tables from TDD in queries (e.g., "Query ORDERS, CUSTOMERS")
- ✅ Exact step names from TDD flow sections (preserve verbatim, no simplification)
- ✅ Multi-AZ topology if mentioned in TDD (separate AZ clusters, HA resources)
- ✅ OAuth/auth details in edges (TTL, scope, token type from TDD)
- ✅ `bgcolor: "white"` in all graph_attributes

### Validation:
- ✅ Count: Did I extract {N} Lambda functions vs 1 generic Lambda?
- ✅ Naming: Do my cluster names reflect business domains from TDD?
- ✅ Detail: Do my edge labels have multi-line context or are they generic?
- ✅ Accuracy: Would a developer recognize their architecture from my YAML?

**If any critical item is missing, quality drops below 60%. If any high-quality item is missing, quality drops below 90%.**

---

## Appendix: aws-diagram-generator Integration

### How This Skill Fits Into the Workflow

This skill is invoked as **Phase 1** of the `aws-diagram-generator` skill:

```
aws-diagram-generator Workflow
├─ Phase 0: Initialize (Setup venv, create project, collect TDD files)
├─ Phase 1: yaml-from-tdd Skill (THIS SKILL)
│   ├─ Input: tdd_file_path, project_path
│   ├─ Output: YAML files in {project_path}/yaml_specs/
│   └─ Gate 1: User approval before saving
├─ Phase 2: Python & Diagrams (Use YAMLs from Phase 1)
│   ├─ Generate Python scripts
│   ├─ Execute diagram generation
│   └─ Gate 2: User approval
└─ Phase 3: Finalize (Convert to Draw.io, summary)
```

### Parameter Handling

**When invoked from aws-diagram-generator:**

1. **Receive Parameters**:
   - Check if parameters `tdd_file_path` and `project_path` are provided in the prompt
   - Extract these values from the calling context

2. **Example Invocation** (from aws-diagram-generator):
   ```
   Invoke yaml-from-tdd skill:
   - tdd_file_path: /path/to/project/requirements/ri-policy-snapshot-service.md
   - project_path: /path/to/project
   ```

3. **Save Location Logic**:
   ```python
   if project_path is provided:
       output_dir = f"{project_path}/yaml_specs/"
   else:
       output_dir = f"{HOME}/.claude/AIDLC-tech-architect/yaml-from-tdd-output/"
   ```

4. **Create Output Directory**:
   - Ensure `{output_dir}` exists before writing files
   - Use Bash tool: `mkdir -p {output_dir}`

5. **Write All YAML Files**:
   - Save each generated YAML to `{output_dir}/filename.yaml`
   - Report completion with file list

### File Writing Implementation

Use the **Write tool** to save YAML files (NOT bash commands):

**Step 1: Create output directory if needed:**
1. Use Bash: `mkdir -p {project_path}/yaml_specs`

**Step 2: DELETE existing YAML files (CRITICAL - must execute before writing):**
2. Use Bash: `rm -f {project_path}/yaml_specs/*.yaml`
   - This removes any template files from previous runs
   - Prevents contamination of new TDD analysis
   - Clears conflicting file names from old runs
   - **This step is non-negotiable - always execute it**

**Step 3: Write standardized YAML files with correct names:**
3. Use the Write tool for each generated YAML file with STANDARD NAMES:
   - Write tool → `{project_path}/yaml_specs/01_c4_context_diagram.yaml`
   - Write tool → `{project_path}/yaml_specs/02_c4_container_diagram.yaml`
   - Write tool → `{project_path}/yaml_specs/03_vpc_network_architecture_diagram.yaml` (if generated)
   - Write tool → `{project_path}/yaml_specs/04_data_flow_diagram.yaml` (if generated - standard name)
   - Write tool → `{project_path}/yaml_specs/05_monitoring_observability_diagram.yaml` (if generated)

**Example with actual paths:**
```
project_path: /Users/username/ri-policy-snapshot
output_directory: /Users/username/ri-policy-snapshot/yaml_specs/

Use Write tool with:
  file_path: /Users/username/ri-policy-snapshot/yaml_specs/01_c4_context_diagram.yaml
  content: [generated YAML content]
```

### Expected Behavior When Called from aws-diagram-generator

1. **Receive TDD path and project path from aws-diagram-generator**
2. **Read TDD file** from `tdd_file_path`
3. **Generate YAMLs** (all 5 types if applicable)
4. **Present to user** for approval (Gate 1)
5. **On approval**: Save all YAMLs to `{project_path}/yaml_specs/`
6. **Return control** to aws-diagram-generator with completion status
7. **aws-diagram-generator continues** to Phase 2 using the YAMLs

### Single Output Directory Benefit

By saving to `{project_path}/yaml_specs/` instead of a separate folder:
- ✅ All artifacts in one project directory
- ✅ Easier to manage and version control
- ✅ Seamless handoff between phases
- ✅ No scattered output directories
- ✅ Clear project structure
