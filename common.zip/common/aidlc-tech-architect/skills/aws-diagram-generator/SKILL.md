---
name: aws-diagram-generator
description: Generate AWS architecture diagrams from TDDs fully automatically. Streamlined 3-phase workflow with no approval gates for end-to-end diagram generation.
version: 2.0.0
---

# AWS Architecture Diagram Generator

**Purpose**: Streamlined workflow for generating AWS architecture diagrams from Technical Design Documents fully automatically. Runs all 3 phases automatically with no user approval gates or interruptions.

**Key Features**:
- 3-phase fully automated workflow
- No approval gates - runs end-to-end without user interaction
- Auto-run phases continuously
- Single error pause point per phase (user decides action)
- Fresh state created each invocation (no resume capability)
- Integrated project management (create/detect/validate)

---

## Table of Contents

1. [Workflow Overview](#workflow-overview)
2. [Critical Sequential Workflow](#critical-strict-sequential-workflow)
3. [Phase 0: Initialization (Auto)](#phase-0-initialization-auto)
4. [Phase 1: YAML Generation via yaml-from-tdd Skill](#phase-1-yaml-generation)
5. [Phase 2: Diagrams](#phase-2-diagrams)
6. [Phase 3: Finalize (Auto)](#phase-3-finalize-auto)
7. [Error Handling](#error-handling)
8. [State Management](#state-management)
9. [Resume Capability](#resume-capability)
10. [Implementation Guide](#implementation-guide)

---

## ⚠️ CRITICAL: STRICT SEQUENTIAL WORKFLOW

**THIS IS A LINEAR, NO-DEVIATION PROCESS. FOLLOW THESE STEPS IN EXACT ORDER:**

### Mandatory Step Sequence (DO NOT SKIP OR REORDER)

```
STEP 1: Setup Virtual Environment
  └─ Check if venv exists
  └─ Create venv if needed
  └─ Install dependencies
  └─ Cache AWS icons
  └─ Verify aws-arch CLI works

STEP 2: Activate Virtual Environment
  └─ Use venv python path for ALL subsequent commands

STEP 3: Initialize Project Setup
  └─ Project creation/validation (create new or use existing)
  └─ Requirements folder setup

STEP 4: Collect TDD Files
  └─ Prompt user to place TDD files in requirements/ folder
  └─ OR copy from user-provided path to requirements/
  └─ Wait for user confirmation
  └─ Validate TDD files exist

STEP 5: Invoke yaml-from-tdd Skill for YAML Generation
  └─ yaml-from-tdd reads TDD files from requirements/ folder
  └─ Extracts system name, Lambda functions, clusters, endpoints
  └─ Generates YAML files (C4, container, VPC, data flow, monitoring)
  └─ Validates service kinds
  └─ Writes to yaml_specs/ folder automatically

STEP 6: Generate Python Scripts from YAML
  └─ Run aws-arch CLI python generate command
  └─ Output to python_scripts/ folder
  └─ Validate Python syntax

STEP 7: Run Python Scripts to Generate Diagrams
  └─ Check prerequisites (Python 3.8+, Graphviz)
  └─ Execute diagram generation
  └─ Output PNG + DOT files to diagrams/ folder

STEP 8: Verify Diagram Generation
  └─ Verify PNG diagrams were generated successfully
  └─ Count files and validate output
  └─ Proceed automatically to Phase 3

STEP 9: Convert Diagrams to Draw.io Format
  └─ Run aws-arch CLI drawio convert-all command
  └─ Generate .drawio.xml files with native AWS icons
  └─ Output to drawio/ folder

STEP 10: Complete and Show Summary
  └─ Mark workflow as completed
  └─ Display final artifact summary
  └─ Provide file locations and next steps
```

**KEY RULES:**
- ✅ **MUST execute in exact order shown above**
- ✅ **DO NOT skip steps** - each step is mandatory
- ✅ **DO NOT deviate** - follow the sequence precisely
- ✅ **Use venv python for all CLI commands** (never bare `aws-arch`)
- ✅ **Fully automated workflow** - no approval gates required
- ✅ **Create a fresh workflow state each invocation** - resume is not supported

---

## Workflow Overview

```
Initialization (Auto)
  ├─ Project detect/create
  ├─ TDD collection
  └─ Ready confirmation

         ↓

Phase 1: YAML Generation (Invoke yaml-from-tdd Skill)
  ├─ yaml-from-tdd reads TDD from requirements/
  ├─ Extracts components and generates YAMLs
  ├─ Validates service kinds
  └─ Saves YAMLs to yaml_specs/ automatically

         ↓

Phase 2: Diagrams (Auto)
  ├─ Check prerequisites (Python, Graphviz)
  ├─ Generate Python scripts
  ├─ Execute diagrams (PNG/DOT)
  └─ Verify output and proceed to Phase 3

         ↓

Phase 3: Finalize (Auto)
  ├─ Convert to Draw.io XML
  └─ Show completion summary

         ↓

Complete! ✓
```

**No Approval Gates**: Fully automated workflow runs end-to-end without user interaction.

**Error Handling**: Single pause per phase with clear fix guidance. User decides whether to regenerate, fix manually, or stop.

**State Management**: Fresh workflow state created each invocation at `.claude/AIDLC-tech-architect/workflow-progress-state.json`. Resume is not supported.

---

## Phase 0: Initialization (Auto)

**Purpose**: Detect workflow state, handle project setup, and collect TDD files automatically.

**⚠️ MUST COMPLETE ALL STEPS IN ORDER:**
1. Virtual Environment Setup (STEP 1 - EXECUTE FIRST, BEFORE ANYTHING ELSE)
2. Initialize Fresh State (STEP 2)
3. Project Detection/Creation (STEP 3)
4. TDD Collection (STEP 4)
5. State Initialization (STEP 5)

### CRITICAL: Virtual Environment Setup (STEP 1 - EXECUTE FIRST)

**MUST execute this bash command before any other Phase 0 steps:**

```bash
# Setup virtual environment and get python path
VENV_PYTHON=$(python3 -c "
import sys
from pathlib import Path

# Add CLI to path
cli_path = Path.home() / '.claude' / 'plugins' / 'cache' / 'AIDLC-aig-claude' / 'AIDLC-tech-architect' / '0.9.1' / 'cli'
sys.path.insert(0, str(cli_path))

# Import and run VenvManager
from aws_arch.core.venv_manager import VenvManager
vm = VenvManager()
success, message = vm.setup_all()
if not success:
    print(f"Error: {message}", file=sys.stderr)
    sys.exit(1)
print(vm.get_python_executable())
")

# Verify venv is ready
if [ -z "$VENV_PYTHON" ]; then
    echo "❌ Virtual environment setup failed"
    exit 1
fi

echo "✅ Virtual environment ready: $VENV_PYTHON"
```

**Key Points:**
- Venv is created at: `~/.claude/venvs/ADLC/`
- VenvManager automatically:
  - Creates venv if it doesn't exist
  - Installs aws-arch CLI and dependencies
  - Caches AWS icons locally
- Environment variable `VENV_PYTHON` is set for use in subsequent commands

**After venv setup, use $VENV_PYTHON for all CLI commands** - never use bare `aws-arch` command.

All subsequent commands follow this pattern:
```bash
$VENV_PYTHON -m aws_arch.cli <command> <args>
```

Example usage:
```bash
# Generate Python scripts
$VENV_PYTHON -m aws_arch.cli python generate yaml_specs/*.yaml --output-dir python_scripts

# Validate YAML
$VENV_PYTHON -m aws_arch.cli yaml validate yaml_specs/*.yaml

# Execute diagrams
$VENV_PYTHON -m aws_arch.cli diagram execute $PROJECT_PATH

# Convert to Draw.io
$VENV_PYTHON -m aws_arch.cli drawio convert-all $PROJECT_PATH
```

### Initialize Fresh State (STEP 2 - Execute After Venv Setup)

**Execute this IMMEDIATELY after virtual environment is ready. Create a new workflow progress object.**

1. Always create a fresh workflow state object (do not load or check for existing state files)
2. Initialize state with empty phase tracking
3. Initialize empty artifact lists
4. Set current phase to 0 (initialization)

### Project Detection & Creation (STEP 3 - Execute After Resume Detection)

**Execute this AFTER resume detection is complete. Do not proceed to TDD collection until project is detected or created.**

**IMPORTANT: Always scan current directory FIRST before asking user.**

#### Step 3.1: Scan Current Directory for Existing Projects

1. Run project scan command:
   ```bash
   {venv_python_path} -m aws_arch.cli project scan --json
   ```

2. Parse JSON response to get list of existing projects in current directory

3. If projects found:
   - Show user the detected projects with their stats (YAML count, script count, diagram count)
   - Example display:
     ```
     🔍 Detected AWS Architecture Projects:

     1. customer-portal-system (YAMLs: 5, Scripts: 5, Diagrams: 5)
        Path: ./customer-portal-system

     2. payment-service-arch (YAMLs: 3, Scripts: 3, Diagrams: 0)
        Path: ./payment-service-arch
     ```

#### Step 3.2: Present Options to User

Present user with clear options:

**If projects detected:**
```
Found 2 existing projects in current directory.

Would you like to:
1. Use existing project: customer-portal-system
2. Use existing project: payment-service-arch
3. Create a new project
4. Specify a project path manually

Your choice:
```

**If no projects detected:**
```
No existing projects found in current directory.

Would you like to:
1. Create a new project here
2. Specify a project path manually

Your choice:
```

#### Step 3.3: Handle User Choice

**Option 1-2 (Use detected project):**
1. Use the selected project path from scan results
2. Validate using: `{venv_python_path} -m aws_arch.cli project validate {project_path} --json`
3. Extract project name from directory
4. Proceed to TDD collection

**Option 3 (Create new project):**
1. Prompt user for project name
2. Check if name already exists in detected projects
3. If name exists, warn user and ask for confirmation:
   ```
   ⚠️  Warning: A project named 'customer-portal-system' already exists at:
       ./customer-portal-system

   Are you sure you want to create a duplicate? (y/N):
   ```
4. Run: `{venv_python_path} -m aws_arch.cli project create {project_name} --json`
5. Extract project path from CLI response
6. Proceed to TDD collection

**Option 4 (Specify manually):**
1. Prompt user for project directory path
2. Validate using: `{venv_python_path} -m aws_arch.cli project validate {project_path} --json`
3. Extract project name from directory
4. Proceed to TDD collection

#### Step 3.4: Error Handling

If any step fails:
1. Show clear error message
2. Show the specific command that failed
3. Offer options:
   - Retry
   - Choose different project
   - Stop workflow

### TDD Collection (STEP 4 - Execute After Project Setup)

**Execute this AFTER project is detected/created. Collect TDD files from user before proceeding to Phase 1.**

1. Create `requirements/` directory in project if it doesn't exist
2. Show user the path where TDD files should be placed
3. Inform user of supported formats: `.md`, `.docx`, `.pdf`, `.txt`
4. If user provided a path in initial prompt, copy those files to `requirements/`
5. Ask user to confirm files are ready or show what's currently in the directory
6. List all found TDD files
7. If no files found, guide user to place files there and retry

### Initialize State (STEP 5 - Final Initialization Step)

**Execute this AFTER TDD collection is complete. Save state before proceeding to Phase 1.**

1. Create state object with project info, venv path, and empty artifact lists
2. Save state to `~/.claude/AIDLC-tech-architect/workflow-progress-state.json`
3. Update progress tracking with TodoWrite tool
4. Mark initialization complete and ready to proceed to Phase 1

---

## Phase 1: YAML Generation → Gate 1 (STEP 6)

**Purpose**: Generate YAML specifications from TDDs using the dedicated `yaml-from-tdd` skill.

**⚠️ CRITICAL: This phase is fully handled by the yaml-from-tdd skill, which manages:**
- TDD analysis and component extraction
- YAML specification generation (all 5 diagram types)
- Service kind validation
- File writing to `{project_path}/yaml_specs/`

**DO NOT DUPLICATE THIS LOGIC - Use the skill instead.**

**📖 For detailed information on:**
- How yaml-from-tdd extracts Lambda functions, clusters, endpoints, and database details
- How it generates the 5 YAML diagram types with rich metadata
- How validation is performed
- **See: `plugins/AIDLC-tech-architect/skills/yaml-from-tdd/SKILL.md`**

This file documents the orchestration only. All extraction and generation logic is in yaml-from-tdd.

**⚠️ CRITICAL - File Writing Responsibility:**
- The `yaml-from-tdd` skill handles ALL YAML file writing in its Step 5
- aws-diagram-generator NEVER writes YAML files
- Your role in Phase 1 is to invoke the skill and verify completion ONLY
- DO NOT use Write tool for YAML files - they are already saved by yaml-from-tdd

### Invoke yaml-from-tdd Skill

1. **For each TDD file** in `{project_path}/requirements/`:
   ```
   Invoke Skill: "AIDLC-tech-architect:yaml-from-tdd"
   Parameters:
     - tdd_file_path: {full path to TDD file}
     - project_path: {project path created in Phase 0}
   ```

2. **Skill handles internally:**
   - Reads and analyzes TDD file
   - Extracts system name, Lambda functions, clusters, API endpoints, database details
   - Generates up to 5 YAML files (C4 context, container, VPC, data flow, monitoring)
   - Validates service kinds against whitelist
   - Saves YAMLs to `{project_path}/yaml_specs/` automatically

3. **After skill completes:**

   **⚠️ CRITICAL: DO NOT WRITE YAML FILES**
   The yaml-from-tdd skill has ALREADY saved all YAML files to disk.
   Your role is VERIFICATION ONLY.

   - **Verify** YAML files exist using Glob tool: `{project_path}/yaml_specs/*.yaml`
   - **Count** generated files (expect 2-5 YAML files)
   - **Read** file list into state (file paths only, not content)
   - **Proceed** to Phase 2 (Python script generation)

   **DO NOT:**
   - ❌ Use Write tool to save YAML files (already saved!)
   - ❌ Re-read YAML content and save again
   - ❌ Create YAML files in this phase

### Phase 1 Completion: Handled by yaml-from-tdd Skill

The `yaml-from-tdd` skill automatically generates YAML files:
- Analyzes TDD and extracts components
- Generates YAML specifications
- Validates service kinds
- Saves YAML files to disk automatically
- Returns to aws-diagram-generator after YAML generation completes

**aws-diagram-generator proceeds** once yaml-from-tdd skill returns successfully.

---

## Phase 2: Diagrams (STEPS 7-8)

**Purpose**: Generate Python scripts and execute diagrams automatically.

**⚠️ MUST COMPLETE ALL SUBSTEPS IN ORDER:**
1. Check prerequisites (Python 3.8+, Graphviz)
2. Generate Python scripts from YAML files
3. Execute Python scripts to generate PNG/DOT diagrams
4. Verify PNG and DOT files were generated successfully
5. Automatically proceed to Phase 3

### Virtual Environment - Already Setup in Phase 0

The virtual environment was created and configured in Phase 0. Retrieve the stored venv python path from state and use it for all Phase 2 CLI commands.

**All Phase 2 commands use this pattern:**
```bash
{venv_python_path} -m aws_arch.cli <command> <args>
```

### Prerequisite Check

1. Run prerequisite check:
   ```bash
   {venv_python_path} -m aws_arch.cli diagram check {project_path} --json
   ```
2. Check if Python 3.8+ is available
3. Check if Graphviz is installed
4. If missing prerequisites:
   - Show user what's missing
   - Provide installation instructions (brew/apt-get/choco as appropriate)
   - Ask user to install and retry
5. If user chooses not to install, stop workflow

### Generate Python Scripts

1. Collect paths to all generated YAML files
2. Run Python generation using generate-all command for directory of YAMLs:
   ```bash
   {venv_python_path} -m aws_arch.cli python generate-all {project_path}/yaml_specs --output-dir {project_path}/python_scripts --json
   ```
3. Validate generation succeeded
4. If generation fails, show error and ask user to:
   - Regenerate YAMLs (go back to Phase 1)
   - Fix manually and retry
   - Stop workflow
5. Update state with generated Python script files
6. Proceed to diagram execution step

### Execute Diagrams

1. Run diagram execution command:
   ```bash
   {venv_python_path} -m aws_arch.cli diagram execute {project_path} --json
   ```
2. Monitor for execution errors or missing dependencies
3. If execution fails, show error and guide user through common fixes:
   - Missing diagrams package
   - Graphviz installation issues
   - Python script syntax errors
4. Ask user to:
   - Regenerate Python scripts
   - Fix manually and retry
   - Stop workflow
5. On success:
   - Collect generated PNG files from `{project_path}/diagrams/`
   - Collect generated DOT files from `{project_path}/diagrams/`
   - Update state with diagram artifacts
6. Automatically proceed to Phase 3

---

## Phase 3: Finalize (Auto) (STEP 9)

**Purpose**: Convert diagrams to Draw.io XML and show completion summary.

**⚠️ MUST COMPLETE IN ORDER:**
1. Convert PNG/DOT diagrams to Draw.io XML format with native AWS icons
2. Verify Draw.io files are generated successfully
3. Mark workflow as completed
4. Display completion summary and next steps

### Non-AWS components (required for the UW CR SDD)

`aws_arch` resolves **AWS** icons only. A component it does not recognise is
silently dropped or rendered as a bare box, so a diagram can look finished while
omitting the identity provider or the database. Emit these explicitly rather
than relying on the converter (the list is driven by `target_architecture.bands` in
the project domain pack — add any component named there that `aws_arch` cannot resolve):

| Component | Draw.io shape | Why it appears in this architecture |
|-----------|---------------|-------------------------------------|
| **Okta** | `shape=mxgraph.veeam.2d.user_directory` or a labelled rounded box, fill `#00297A`, font `#FFFFFF` | OIDC identity provider for both workspaces. FR-017/FR-P1 depend on it, so an SDD without it cannot show how access is enforced |
| **Jenkins** | `shape=mxgraph.azure.devops.build` or a labelled box, fill `#D33833` | The DevOps persona's build and deploy path (M12) |
| **MS SQL Server** | `shape=mxgraph.flowchart.database`, fill `#CC2927`, label `MS SQL — CreditApp (existing, read-only)` | The legacy database. **Label it read-only on the diagram.** A plain database icon invites a reader to assume the application owns the schema, which is exactly the constraint the programme must not break |
| **Spring Batch** | `shape=mxgraph.flowchart.predefined_process`, fill `#6DB33F` | Batch paths carried over from the legacy ASP jobs |
| **OPA sidecar** | labelled rounded box, fill `#566366`, font `#FFFFFF`, label `OPA (Rego)` | Policy decision point beside the API Gateway / services; without it the diagram cannot show where row-level scope is enforced |
| **Amazon SES** | `aws_arch` resolves `SimpleEmailService`; if it does not, labelled box fill `#DD344C` | Outbound email that replaces legacy SMTP/CDO sends (NotificationService) |
| **EventBridge Scheduler** | `aws_arch` `EventBridge`; label `EventBridge Scheduler` | Triggers the Spring Batch jobs (daily / monthly / quarterly) |
| **S3 inbound-feed bucket + event** | `aws_arch` `SimpleStorageService` + arrow to SQS | Where internal teams drop files (Party.xml / Hierarchy.xml / FX rate); the S3 event → SQS arrow shows how batch starts |

Rules:

- Draw MS SQL **outside** the application boundary, with the read-only label. Its
  position on the diagram is the clearest possible statement of the immutable-schema
  constraint.
- Show Okta on the request path into *both* the UI and the API, not just the UI —
  server-side token validation is where FR-P1 is actually enforced.
- If a component in the SDD has no icon and is not in this table, render a labelled
  box and **list it in the completion summary** as unresolved. Never omit it: a
  missing component in a design document reads as a design decision.

### Convert to Draw.io

1. Run Draw.io conversion with absolute path:
   ```bash
   # Ensure absolute path is used (resolves symlinks and relative paths)
   PROJECT_ABS_PATH=$(cd {project_path} && pwd)
   {venv_python_path} -m aws_arch.cli drawio convert-all "$PROJECT_ABS_PATH" --json
   ```

   **Alternative approach** (if in project directory):
   ```bash
   cd {project_path} && {venv_python_path} -m aws_arch.cli drawio convert-all . --json
   ```

2. Convert PNG/DOT diagrams to Draw.io XML format with native AWS icons
3. On success:
   - Verify Draw.io files exist in `{project_path}/drawio/`
   - Update state with Draw.io artifact list
   - Show user the files and instructions to open at https://app.diagrams.net/
4. If conversion fails (non-fatal):
   - Warn user that Draw.io conversion failed
   - Remind user that PNG diagrams are still available
   - Log error but continue to completion summary
5. Proceed to completion summary

### Completion Summary

1. Display completion message showing:
   - Project name and location
   - Count of all generated artifacts (TDDs, YAMLs, Python scripts, PNGs, DOTs, Draw.io files)
   - Directory structure with file counts
2. Show directory tree of all output locations:
   - `requirements/` - TDD files
   - `yaml_specs/` - YAML specifications
   - `python_scripts/` - Generated Python diagram scripts
   - `diagrams/` - PNG and DOT files
   - `drawio/` - Draw.io XML files
3. Provide next steps:
   - Review PNG diagrams
   - Edit Draw.io files in https://app.diagrams.net/
   - Export/share as needed
   - Commit to version control
4. Mark workflow as completed in state file
5. Update TodoWrite to mark all tasks as completed
6. Delete state file: `rm ~/.claude/AIDLC-tech-architect/workflow-progress-state.json`

---

## Error Handling

### Error Philosophy

**Single Pause Per Phase**: Each phase pauses once if an error occurs. User then decides whether to:
1. **Regenerate** - Go back to previous phase to regenerate inputs
2. **Fix Manually** - Pause workflow for manual fixes
3. **Stop** - Abort workflow

### Error Types & Handling

| Error Type | Phase | Handling | Options |
|------------|-------|----------|---------|
| Missing TDD files | Init | Tell user location | Continue with existing |
| YAML generation failed | 1 | Show error | Regenerate or stop |
| YAML validation failed | 1 | Show errors | Regenerate or stop |
| Missing Python/Graphviz | 2 | Show install instructions | Install & retry or stop |
| Python script error | 2 | Show error | Regenerate YAMLs or stop |
| Diagram execution error | 2 | Show error | Regenerate scripts or stop |
| Draw.io conversion error | 3 | Warn (non-fatal) | Continue (PNG available) |

### Error Logging

When errors occur:
1. Add error entry to state with phase, step, message, and timestamp
2. Save updated state
3. Show user the error and recovery options
4. Errors are non-fatal unless user chooses to stop

---

## State Management

### State File

Location: `~/.claude/AIDLC-tech-architect/workflow-progress-state.json`

**Fresh State Creation**: Each skill invocation creates a new state object. Previous state files are not loaded or checked. Every workflow starts fresh.

**State Cleanup**: After workflow completion, the state file is deleted. This ensures clean state for subsequent invocations.

### Minimal State Schema

```json
{
  "project_name": "my-project",
  "project_path": "/path/to/project",
  "venv_python_path": "/Users/username/.claude/venvs/ADLC/bin/python",
  "current_phase": 2,
  "completed": false,
  "phases": {
    "0_init": {"status": "completed"},
    "1_yaml": {"status": "completed", "approved": true},
    "2_diagrams": {"status": "in_progress", "approved": false},
    "3_finalize": {"status": "pending"}
  },
  "artifacts": {
    "tdd_files": ["requirements/architecture.md"],
    "yaml_files": ["yaml_specs/01_c4_context.yaml"],
    "python_scripts": ["python_scripts/01_diagram.py"],
    "png_files": ["diagrams/01_diagram.png"],
    "dot_files": ["diagrams/01_diagram.dot"],
    "drawio_files": ["drawio/01_diagram.drawio.xml"]
  },
  "errors": [],
  "last_updated": "2026-02-17T15:30:00Z"
}
```

**New Field: `venv_python_path`**
- Stores the path to the Python executable in the skill-managed virtual environment
- Set during Phase 0 (STEP 1: Virtual Environment Setup)
- Reused in all subsequent phases for CLI commands
- Example: `/Users/username/.claude/venvs/ADLC/bin/python`
- Used as: `$venv_python_path -m aws_arch.cli <command>`

### State Functions

Two utility functions manage workflow state:

1. **save_state(state: dict)** - Writes state to `~/.claude/AIDLC-tech-architect/workflow-progress-state.json`
   - Creates directory structure if needed
   - Uses JSON format for persistence

2. **load_state() -> dict** - Reads state from file
   - Returns None if file doesn't exist
   - Used at workflow start to detect incomplete workflows

---

## Resume Capability

**Resume is NOT supported.** Each invocation creates a new workflow progress object. Workflows do not persist between invocations.

If a workflow is interrupted:
- Manually copy output artifacts to a new location to preserve them
- Start a fresh workflow by invoking the skill again
- The state file is created fresh each time and does not carry over from previous executions

---

## Implementation Guide

### CLI Commands - ALWAYS Use Venv Python

**CRITICAL**: Never use bare `aws-arch` command. Always use the venv python executable:

```bash
# Pattern (Python)
[venv_python_path] -m aws_arch.cli <command> <args>

# Examples
{venv_python_path} -m aws_arch.cli project create <name> --json
{venv_python_path} -m aws_arch.cli diagram check <path> --json
{venv_python_path} -m aws_arch.cli python generate <yaml-files> --output-dir <dir> --json
{venv_python_path} -m aws_arch.cli diagram execute <project-path> --json
{venv_python_path} -m aws_arch.cli drawio convert-all <project-path> --json
```

**Where `venv_python_path` is stored in state after Phase 0 venv setup.**

### Tool Integration

**Phase 0 (Initialization):**
- **Bash**: Execute venv setup, project creation, TDD file collection
- **TodoWrite**: Track phase completion

**Phase 1 (YAML Generation):**
- **Skill**: Invoke `AIDLC-tech-architect:yaml-from-tdd` with `tdd_file_path` and `project_path`
- **Glob**: Verify YAML files exist after skill completes (read-only check)
- **⚠️ DO NOT USE Write**: yaml-from-tdd handles ALL file writing internally
- **Note**: yaml-from-tdd handles all its own tool integration (Read, Write)
- **aws-diagram-generator role**: Just invoke skill, verify files exist, and proceed to Phase 2

**Phase 2 (Diagrams):**
- **Bash**: Execute aws-arch CLI commands (python generate, diagram execute)
- **Glob**: Verify PNG and DOT files were generated successfully

**Phase 3 (Finalize):**
- **Bash**: Execute aws-arch CLI command (drawio convert-all)
- **TodoWrite**: Mark workflow complete

