﻿# AWS Diagram Generator User Guide

## Overview

The **aws-diagram-generator** skill transforms Technical Design Documents (TDDs) into professional AWS architecture diagrams through a fully automated 3-phase workflow. No user approval gates—just automated, end-to-end diagram generation.

## Table of Contents

1. [Quick Start](#quick-start)
2. [Prerequisites](#prerequisites)
3. [Workflow Overview](#workflow-overview)
4. [Usage Examples](#usage-examples)
5. [Understanding the Output](#understanding-the-output)
6. [Common Workflows](#common-workflows)
7. [Troubleshooting](#troubleshooting)

---

## Quick Start

### 1. Invoke the skill with natural language:
```
Generate AWS architecture diagrams from path/to/requirements
```

### 2. The skill will:
- Detect or create an AWS architecture project
- Collect TDD files from the specified path
- Automatically process through all 3 phases

### 3. Access your diagrams:
- PNG files: `your-project/diagrams/`
- Draw.io files: `your-project/drawio/`
- Open Draw.io files in https://app.diagrams.net/

---

## Prerequisites

### System Requirements
- **Python 3.8+** (installed on your system)
- **Graphviz** (system package)

### Installation

#### macOS
```bash
brew install graphviz
```

#### Linux (Ubuntu/Debian)
```bash
sudo apt-get install graphviz
```

#### Windows
```bash
choco install graphviz
# or download from https://graphviz.org/download/
```

### TDD File Formats
The skill accepts Technical Design Documents in these formats:
- `.md` (Markdown)
- `.docx` (Word documents)
- `.pdf` (PDF files)
- `.txt` (Plain text)

---

## Workflow Overview

The aws-diagram-generator runs through **3 automated phases**:

```
┌─────────────────────────────────────────────────────────────┐
│ Phase 0: INITIALIZATION (Automatic)                         │
├─────────────────────────────────────────────────────────────┤
│ • Setup virtual environment with aws-arch CLI                │
│ • Detect or create AWS architecture project                  │
│ • Collect TDD files from requirements/ folder                │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ Phase 1: YAML GENERATION (Automatic)                        │
├─────────────────────────────────────────────────────────────┤
│ • yaml-from-tdd skill reads TDD files                        │
│ • Extracts Lambda functions, clusters, endpoints            │
│ • Generates 5 YAML specs:                                    │
│   - C4 Context diagram                                       │
│   - Container diagram                                        │
│   - VPC network diagram                                      │
│   - Data flow diagram                                        │
│   - Monitoring diagram                                       │
│ • Validates service kinds                                    │
│ • Saves to yaml_specs/ folder                                │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ Phase 2: DIAGRAM GENERATION (Automatic)                     │
├─────────────────────────────────────────────────────────────┤
│ • Generate Python scripts from YAML files                    │
│ • Execute Python with Graphviz engine                        │
│ • Create PNG and DOT diagram files                           │
│ • Output to diagrams/ folder                                 │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│ Phase 3: FINALIZE (Automatic)                               │
├─────────────────────────────────────────────────────────────┤
│ • Convert PNG/DOT to Draw.io XML format                      │
│ • Add native AWS icons                                       │
│ • Output to drawio/ folder                                   │
│ • Display completion summary                                 │
└─────────────────────────────────────────────────────────────┘

                      ✅ Complete!
```

---

## Usage Examples

### Example 1: Generate diagrams from TDD files

**Step 1:** Invoke the skill with natural language
```
Generate AWS architecture diagrams from ./requirements/
```

**Step 2:** Respond to prompts to create or select a project
```
🔍 Scanning for existing projects...

No existing projects found in current directory.

Would you like to:
1. Create a new project here
2. Specify a project path manually

Your choice: 1
```

**Step 3:** Enter project name when prompted
```
Project name: my-api-service

✅ Project created at: ./my-api-service/
```

**Step 4:** The skill processes automatically
```
✅ Virtual environment ready
✅ Project initialized: my-api-service
✅ TDD files collected: requirements/architecture.md

🔄 Phase 1: Generating YAML specifications...
  ✓ C4 Context diagram
  ✓ Container diagram
  ✓ VPC network diagram
  ✓ Data flow diagram
  ✓ Monitoring diagram

🔄 Phase 2: Generating diagrams...
  ✓ Python scripts generated
  ✓ Diagrams executed
  ✓ PNG files created
  ✓ DOT files created

🔄 Phase 3: Converting to Draw.io...
  ✓ Draw.io files generated

✨ Workflow Complete!
```

### Example 2: Regenerate diagrams for an existing project

**Step 1:** Invoke the skill with the project path
```
Generate AWS architecture diagrams from ./payment-system/requirements/
```

**Step 2:** The skill detects the existing project
```
🔍 Scanning for existing projects...

Found existing project: payment-system
Path: ./payment-system

Using existing project: payment-system
```

**Step 3:** Workflow processes automatically with updated TDD files
```
✅ Project loaded: payment-system
✅ TDD files collected: requirements/payment-architecture.md

🔄 Phase 1: Regenerating YAML specifications...
  ✓ C4 Context diagram
  ✓ Container diagram
  ✓ VPC network diagram
  ✓ Data flow diagram
  ✓ Monitoring diagram

🔄 Phase 2: Regenerating diagrams...
  ✓ Python scripts generated
  ✓ Diagrams executed
  ✓ PNG files created
  ✓ DOT files created

🔄 Phase 3: Converting to Draw.io...
  ✓ Draw.io files generated

✨ Workflow Complete!
```

### Example 3: Use a custom project path

**Step 1:** Invoke the skill with a specific path
```
Generate AWS architecture diagrams from /opt/architecture-projects/customer-portal/requirements/
```

**Step 2:** The skill validates and processes
```
✅ Path validated: /opt/architecture-projects/customer-portal
✅ Project detected: customer-portal
✅ TDD files collected: 2 files

🔄 Processing workflow...
```

**Result:** Diagrams generated at `/opt/architecture-projects/customer-portal/diagrams/`

---

## Understanding the Output

### Project Directory Structure

After the workflow completes, your project contains:

```
my-api-service/
├── requirements/              # Your TDD source files
│   └── architecture.md        # (your input file)
│
├── yaml_specs/               # YAML specifications
│   ├── 01_c4_context.yaml   # System context diagram
│   ├── 02_c4_container.yaml # Container components
│   ├── 03_vpc_network.yaml  # Network topology
│   ├── 04_data_flow.yaml    # Data flow diagram
│   └── 05_monitoring.yaml   # Monitoring architecture
│
├── python_scripts/           # Generated Python diagram scripts
│   ├── 01_c4_context_diagram.py
│   ├── 02_c4_container_diagram.py
│   ├── 03_vpc_network_diagram.py
│   ├── 04_data_flow_diagram.py
│   └── 05_monitoring_diagram.py
│
├── diagrams/                 # PNG and DOT files
│   ├── 01_c4_context.png
│   ├── 01_c4_context.dot
│   ├── 02_c4_container.png
│   ├── 02_c4_container.dot
│   ├── 03_vpc_network.png
│   ├── 03_vpc_network.dot
│   ├── 04_data_flow.png
│   ├── 04_data_flow.dot
│   ├── 05_monitoring.png
│   └── 05_monitoring.dot
│
└── drawio/                   # Draw.io interactive files
    ├── 01_c4_context.drawio.xml
    ├── 02_c4_container.drawio.xml
    ├── 03_vpc_network.drawio.xml
    ├── 04_data_flow.drawio.xml
    └── 05_monitoring.drawio.xml
```

### Diagram Types Explained

| Diagram | Purpose | Use Case |
|---------|---------|----------|
| **C4 Context** | System boundaries and external systems | Show stakeholders the big picture |
| **Container** | System components and technologies | Technical team overview |
| **VPC Network** | AWS network architecture and subnets | Infrastructure team review |
| **Data Flow** | Data movement between components | Document data interactions |
| **Monitoring** | CloudWatch and observability setup | Operations and DevOps planning |

### File Formats

- **PNG files**: Ready-to-share visual diagrams, embeddable in documentation
- **DOT files**: Graphviz format for further processing or customization
- **Draw.io files**: Interactive, editable in https://app.diagrams.net/

---

## Common Workflows

### Workflow 1: Generate diagrams for a new microservice

1. **Create TDD** (or use uw-design to generate one)
   ```
   Generate a Service-TDD for a Lambda microservice
   ```

2. **Generate diagrams**
   ```
   Generate AWS architecture diagrams from ./requirements/
   ```
   - Choose to create a new project when prompted
   - Place your TDD file in the requirements folder

3. **Review and share**
   - Open PNG files in documentation
   - Open Draw.io files for collaborative editing

### Workflow 2: Update diagrams after architecture changes

1. **Update your TDD** with new components or changes and save to `requirements/`

2. **Regenerate diagrams**
   ```
   Generate AWS architecture diagrams from ./requirements/
   ```
   - The skill detects your existing project and regenerates

3. **Compare diagrams**
   - PNG files show the visual changes
   - Draw.io files can be edited for annotations

### Workflow 3: Generate multiple architecture views

**TDD content with clear sections:**
```markdown
# Payment System Architecture

## System Overview
- API Gateway
- Lambda functions (payment-processor, notification)
- DynamoDB tables

## Network Architecture
- VPC configuration
- Subnets and security groups
- NAT gateways

## Data Flow
- Payment request flow
- Notification pipeline
- Error handling

## Monitoring
- CloudWatch metrics
- Alarms
- Log groups
```

**Result:** 5 separate diagrams, each focusing on a specific architectural view

---

## Troubleshooting

### Issue: "Graphviz is not installed"

**Symptom:**
```
❌ Graphviz is not installed on your system
```

**Solution:**
```bash
# macOS
brew install graphviz

# Linux
sudo apt-get install graphviz

# Windows
choco install graphviz
```

### Issue: "Python 3.8+ required"

**Symptom:**
```
❌ Python 3.8 or higher is required
```

**Solution:**
Check your Python version:
```bash
python3 --version
```

Install or upgrade Python:
- macOS: `brew install python@3.11`
- Linux: `sudo apt-get install python3.11`
- Windows: Download from https://www.python.org/

### Issue: "No TDD files found"

**Symptom:**
```
⚠️  No TDD files found in requirements/ folder
```

**Solution:**
1. Place your TDD files in the `requirements/` folder of your project

2. Re-invoke the skill:
   ```
   Generate AWS architecture diagrams from ./your-project/requirements/
   ```

3. The skill will detect your existing project and regenerate the diagrams

### Issue: "YAML generation failed"

**Symptom:**
```
❌ YAML generation failed: Invalid service kind
```

**Possible Causes:**
- TDD contains unrecognized AWS service names
- Missing required sections in TDD

**Solution:**
1. Review the TDD for service names
2. Use standard AWS service names (Lambda, DynamoDB, API Gateway, etc.)
3. Ensure TDD has clear component descriptions
4. Try regenerating with a simpler TDD first

### Issue: "Draw.io conversion failed"

**Symptom:**
```
⚠️  Draw.io conversion failed (non-fatal)
```

**What this means:**
- PNG diagrams were generated successfully ✅
- Draw.io conversion had an issue (non-critical)
- You can still use the PNG files

**Solution:**
PNG diagrams are still available and fully functional. The Draw.io files are optional for collaborative editing.

### Issue: "Virtual environment setup timeout"

**Symptom:**
```
⏱️  Virtual environment setup is taking longer than expected
```

**Solution:**
This is normal on first run. The virtual environment is:
1. Creating a Python virtual environment
2. Installing dependencies (aws-arch, diagrams, etc.)
3. Caching AWS icons locally

Wait for the process to complete. Subsequent runs will be faster.

---

## Tips and Best Practices

### 1. Structure your TDD clearly
Use headings and sections for different architectural views:
```markdown
# System Name

## Components
- List of Lambda functions
- Databases
- External services

## Network Architecture
- VPC configuration
- Subnets

## Data Flow
- Request paths
- Event flows

## Monitoring
- Metrics
- Alarms
- Dashboards
```

### 2. Use version control
Commit your project to git:
```bash
cd your-project
git init
git add .
git commit -m "Initial architecture diagrams"
```

### 3. Iterate on diagrams
- Generate diagrams
- Review output
- Update TDD if needed
- Regenerate (it's fast!)

### 4. Customize Draw.io files
- Open in https://app.diagrams.net/
- Add annotations and labels
- Adjust layout for presentation
- Export as needed

### 5. Use PNG diagrams in documentation
- Embed in README.md files
- Include in architecture documentation
- Share with stakeholders

---

## Next Steps

After generating diagrams:

1. **Review the output**
   - View PNG files to understand architecture
   - Check all 5 diagram types were created

2. **Customize if needed**
   - Open Draw.io files for editing
   - Add annotations and notes
   - Adjust colors and layout

3. **Share and collaborate**
   - Embed PNG files in documentation
   - Share Draw.io files for team review
   - Export to other formats as needed

4. **Validate architecture**
   ```
   Validate the architecture diagrams in my-api-service/ against security best practices
   ```

5. **Generate implementation code**
   ```
   Generate Lambda functions from the architecture in my-api-service/
   ```

---

## Related Skills

- **`yaml-from-tdd`** — Generates YAML from TDDs (used internally by aws-diagram-generator)
- **`aws-arch-cli-reference`** — CLI command documentation for manual operations
- **`uw-design`** — Generate TDDs before creating diagrams
- **`gather-code`** — Validate architecture against security rules
- **`gather-lambda`** — Generate Lambda functions from architecture

---

## Support

For issues or questions:
- Check the Troubleshooting section above
- Review TDD format in example input files
- Visit the aidlc-tech-architect README for full documentation
