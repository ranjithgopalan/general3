# High-Level Design: AIDLC-tech-architect

**Document Type:** High-Level Design (HLD)

---

## Table of Contents
1. Architecture Overview
2. Component Design
3. Plugin Structure
4. Agent Design
5. Commands Design
6. Data Flow
7. Integration Points
8. Error Handling Strategy
9. Testing Strategy

## Architecture Overview

### System Context

```
┌─────────────────────────────────────────────────────────────────┐
│                        User Request                              │
│            "Design system architecture for this BRD"             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Unified Commands                              │
│          /generate, /explore, /validate                         │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│              tech-architect (Router Agent)                       │
│  • Intent Analysis                                               │
│  • Context ADLCing                                             │
│  • Agent Coordination                                            │
└─────────────────────────────────────────────────────────────────┘
                              │
          ┌───────────────────┼───────────────────┐
          ▼                   ▼                   ▼
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│  architecture-  │  │  adr-generator  │  │  tdd-generator  │
│    designer     │  │                 │  │                 │
│                 │  │                 │  │                 │
│ System arch,    │  │  ADR documents  │  │  Complete TDD   │
│ Tech stack      │  │                 │  │                 │
└─────────────────┘  └─────────────────┘  └─────────────────┘
```

### High-Level Architecture

The plugin follows the router + specialized designers pattern:

1. **Commands Layer** - Lightweight prompt enrichers that invoke the router
2. **Router Agent** - Context engineering and orchestration
3. **Designer Agents** - Specialized document generation

### Architectural Principles

1. **Single Responsibility** - Each agent has one job
2. **Plan-Confirm-Generate** - All designers present plans before execution
3. **Context Engineering** - Router ADLCs all context before delegation
4. **Justified Decisions** - All technology choices require rationale

## Component Design

### Layer 1: Request Analysis & Routing

The `tech-architect` agent analyzes incoming requests to determine:
- Intent (Architecture, ADR, Technology Stack, TDD, Coverage)
- Available inputs (BRD, PRD, requirements)
- Output path (document metadata, existing patterns, or user prompt)

### Layer 2: Specialized Designers

| Agent | Responsibility | Output |
|-------|---------------|--------|
| `architecture-designer` | System architecture creation | Architecture documentation, Tech stack |
| `adr-generator` | ADR creation | ADR-XXX documents |
| `tdd-generator` | Full TDD synthesis | `{feature}-TDD.md` |

## Plugin Structure

```
AIDLC-tech-architect/
├── .claude-plugin/
│   └── plugin.json              # Plugin manifest
├── requirements/
│   ├── hlr.md                   # High-Level Requirements
│   ├── tech-architect-brd.md    # Business Requirements Document
│   └── tech-architect-hld.md    # This document
├── agents/
│   ├── tech-architect.md        # Router agent
│   ├── architecture-designer.md # System architecture designer
│   ├── adr-generator.md         # ADR generator
│   └── tdd-generator.md         # TDD generator
├── commands/
│   ├── generate.md              # Generation command
│   ├── explore.md               # Exploration command
│   └── validate.md              # Validation command
├── __tests__/
│   └── *.test                   # Test cases
├── acceptance-criteria.md       # Plugin acceptance criteria
└── README.md                    # User documentation
```

## Agent Design

### Unified Commands

Commands are lightweight prompt enrichers:
- `generate.md` - Routes to router with GENERATE intent
- `explore.md` - Routes to router with EXPLORE intent
- `validate.md` - Routes to router with VALIDATE intent

### Router Agent: tech-architect

**Frontmatter:**
```yaml
name: tech-architect
description: Routes technical architecture requests to specialized agents. Use PROACTIVELY when users request system architecture design, technology stack selection, ADR creation, or Technical Design Documents.
model: inherit
tools: Read, Glob, Grep, Task, AskUserQuestion
permissionMode: plan
color: automatic
```

**Responsibilities:**
- Intent detection (Architecture, ADR, TDD, Coverage)
- Context ADLCing from source documents
- Output path discovery
- Agent coordination and handoff

### Designer Agents

**architecture-designer:**
```yaml
name: architecture-designer
model: inherit
tools: Read, Write, Edit, Glob, Grep
permissionMode: default
```

**adr-generator:**
```yaml
name: adr-generator
model: inherit
tools: Read, Write, Edit, Glob, Grep
permissionMode: default
```

**tdd-generator:**
```yaml
name: tdd-generator
model: inherit
tools: Read, Write, Edit, Glob, Grep
permissionMode: default
```

## Data Flow

### Architecture Generation Flow

```
1. User: "/generate architecture from BRD in /docs/"
2. generate.md → Enriches prompt, invokes tech-architect
3. tech-architect → Detects Architecture intent
4. tech-architect → ADLCs source documents (BRD, NFRs)
5. tech-architect → Discovers output path
6. tech-architect → Delegates to architecture-designer
7. architecture-designer → Reads source documents
8. architecture-designer → Presents plan for confirmation
9. User confirms
10. architecture-designer → Generates architecture documentation
11. Output: System architecture markdown with diagrams
```

### TDD Generation Flow

```
1. User: "/generate TDD from requirements"
2. generate.md → Enriches prompt, invokes tech-architect
3. tech-architect → Detects TDD intent
4. tech-architect → Checks for existing architecture, ADRs
5. tech-architect → ADLCs all available context
6. tech-architect → Delegates to tdd-generator
7. tdd-generator → Reads all inputs
8. tdd-generator → Presents plan for confirmation
9. User confirms
10. tdd-generator → Generates comprehensive TDD
11. Output: {feature}-TDD.md
```

## Integration Points

### Upstream Integrations

| Input | Source | Format |
|-------|--------|--------|
| BRD | business-analyst | Markdown |
| PRD | product-owner | Markdown |
| Requirements | User | MD, PDF |

### Downstream Integrations

| Output | Consumer | Purpose |
|--------|----------|---------|
| Architecture | design-agent | Detailed design |
| TDD | Implementation teams | Development guidance |
| ADRs | Future architects | Decision reference |

## Error Handling Strategy

| Error | Detection | Response |
|-------|-----------|----------|
| No source documents | Input empty | Request source documents |
| Unclear intent | Multiple matches | Ask user to clarify |
| Missing NFRs | No performance requirements | Ask about requirements |
| Technology constraints unknown | Platform unknown | Request constraints |

## Testing Strategy

### Test Categories

1. **Intent Detection** - Verify correct routing based on keywords
2. **Context ADLCing** - Verify source document reading
3. **Plan Presentation** - Verify plan-confirm workflow
4. **Generation Quality** - Verify output completeness
5. **Integration** - Verify multi-artifact workflows

### Test Files

- `__tests__/system_architecture_design.test`
- `__tests__/adr_creation.test`
- `__tests__/technology_stack.test`
- `__tests__/high_level_tdd_generation.test`

## Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 2.0 | 2024-01-15 | AI COE Team | Refactored to remove .claude_kb dependency |
| 1.0 | 2024-01-01 | AI COE Team | Initial version |
| 1.2 | 2025-12-19 | AI COE Team | Version bump for plugin bundle release v1.2.0 |
| 1.3 | 2026-01-09 | AI COE Team | Version bump for release v1.3.0 |
| 1.4 | 2026-01-21 | AI COE Team | Version bump for unified release v1.4.0 |
