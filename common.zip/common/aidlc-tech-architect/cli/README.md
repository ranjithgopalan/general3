# AWS Architecture CLI (`aws-arch`)

Modern CLI tool for generating professional AWS architecture diagrams from Technical Design Documents using the mingrammer/diagrams library with official AWS icons.

## Features

- 🚀 **Fast**: CLI-based, deterministic operations without LLM calls for validation and conversion
- 📊 **Multiple Formats**: YAML → Python → PNG/DOT → Draw.io XML
- 🎨 **Official AWS Icons**: Uses mingrammer/diagrams with official AWS icons
- 🏗️ **C4 Model**: Supports Context (L1) and Container (L2) diagrams
- ✅ **Validation**: Built-in YAML syntax, schema, and AWS service validation
- 🔄 **Hybrid Architecture**: Skills for semantic extraction, CLI for deterministic operations
- 🧪 **Testable**: Comprehensive test suite with >80% coverage

## Architecture Overview

The CLI implements a **hybrid architecture** combining LLM skills with deterministic CLI operations:

```
┌─────────────────────────────────────────────────────────────────┐
│                    AIDLC-tech-architect Plugin                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────┐                          ┌──────────────┐      │
│  │   Skills    │                          │  CLI (Typer) │      │
│  │ (Semantic)  │                          │(Deterministic)│      │
│  └──────┬──────┘                          └──────┬───────┘      │
│         │                                        │              │
│         ├──► yaml-from-tdd                       ├──► yaml      │
│         │    (TDD → YAML)                        │    validate  │
│         │    LLM-based                           │    list-svc  │
│         │    extraction                          │              │
│         │                                        ├──► python    │
│         └──► Skills TBD                          │    generate  │
│              (Future)                            │    generate-all│
│                                                  │              │
│                                                  └──► drawio    │
│                                                       convert   │
│                                                       convert-all│
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

### Logical Flow When Invoked

```mermaid
flowchart TD
    Start([User Invokes Plugin]) --> DetectIntent{Intent Detection}

    DetectIntent -->|Generate YAML| SkillYAML[yaml-from-tdd Skill]
    DetectIntent -->|Validate YAML| CLIValidate[aws-arch yaml validate]
    DetectIntent -->|Generate Python| CLIPython[aws-arch python generate]
    DetectIntent -->|Convert Draw.io| CLIDrawio[aws-arch drawio convert]

    SkillYAML --> ReadTDD[Read TDD Content]
    ReadTDD --> SemanticExtract[Semantic Extraction<br/>LLM Analysis]
    SemanticExtract --> GenYAML[Generate 5 YAML Files<br/>C4 Context/Container/VPC/Data/Monitor]
    GenYAML --> OutputYAML[Output to yaml_specs/]

    CLIValidate --> LoadConfig[Load AWS Services Config]
    LoadConfig --> ParseYAML[Parse YAML Files]
    ParseYAML --> ValidateSyntax{Syntax Valid?}
    ValidateSyntax -->|No| ReportSyntaxErr[Report Syntax Errors]
    ValidateSyntax -->|Yes| ValidateSchema{Schema Valid?}
    ValidateSchema -->|No| ReportSchemaErr[Report Schema Errors]
    ValidateSchema -->|Yes| ValidateServices{AWS Services Valid?}
    ValidateServices -->|No| ReportServiceErr[Report Service Errors]
    ValidateServices -->|Yes| ValidateEdges{Edge References Valid?}
    ValidateEdges -->|No| ReportEdgeErr[Report Edge Errors]
    ValidateEdges -->|Yes| Success1[✓ Validation Passed]

    CLIPython --> LoadYAML[Load YAML Specs]
    LoadYAML --> MapServices[Map AWS Services<br/>to Diagram Imports]
    MapServices --> GenPythonCode[Generate Python Code<br/>Using Templates]
    GenPythonCode --> GenBatchScripts[Generate Batch Scripts<br/>Windows + Unix]
    GenBatchScripts --> OutputPython[Output to python_scripts/]

    CLIDrawio --> ParseDOT[Parse DOT File<br/>using pydot]
    ParseDOT --> ExtractNodes[Extract Nodes & Edges]
    ExtractNodes --> MapIcons[Map AWS Icons<br/>to Draw.io Shapes]
    MapIcons --> TransformCoords[Transform Coordinates<br/>Y-axis Inversion]
    TransformCoords --> GenXML[Generate Draw.io XML<br/>mxGraph Format]
    GenXML --> OutputDrawio[Output to drawio/]

    ReportSyntaxErr --> End([End])
    ReportSchemaErr --> End
    ReportServiceErr --> End
    ReportEdgeErr --> End
    Success1 --> End
    OutputYAML --> End
    OutputPython --> End
    OutputDrawio --> End

    style SkillYAML fill:#e1f5ff
    style CLIValidate fill:#fff4e1
    style CLIPython fill:#fff4e1
    style CLIDrawio fill:#fff4e1
    style SemanticExtract fill:#e1f5ff
    style Success1 fill:#d4edda
```

### Component Responsibilities

| Component | Type | Responsibility | Quality | Speed |
|-----------|------|----------------|---------|-------|
| **yaml-from-tdd** | Skill (LLM) | Semantic TDD analysis → YAML generation | ~90% | Slower |
| **yaml validate** | CLI (Code) | YAML syntax/schema/service validation | 100% | Fast |
| **python generate** | CLI (Code) | YAML → Python script generation | 100% | Fast |
| **drawio convert** | CLI (Code) | DOT → Draw.io XML conversion | 100% | Fast |

### Why Hybrid?

**Skills for Semantic Operations:**
- TDD analysis requires understanding business context
- Extracting individual Lambda functions with memory/timeout
- Identifying business-domain clusters (not generic layers)
- Mapping API endpoints to services
- Understanding multi-AZ network topology

**CLI for Deterministic Operations:**
- Validation rules are fixed (AWS service kinds, schema structure)
- Code generation follows templates (YAML → Python)
- Format conversion is algorithmic (DOT → XML)
- Deterministic operations are faster and cheaper

## Installation

```bash
# From the CLI directory
cd plugins_disabled/AIDLC-tech-architect/cli

# Install in development mode
pip install -e .

# Or install with dev dependencies
pip install -e ".[dev]"
```

## Quick Start

```bash
# 1. Install the CLI
cd plugins_disabled/AIDLC-tech-architect/cli
pip install -e .

# 2. Use yaml-from-tdd skill to generate YAML specs from TDD
# (Invoke the skill with your TDD content)

# 3. Validate generated YAML
aws-arch yaml validate yaml_specs/*.yaml

# 4. Generate Python diagram scripts
aws-arch python generate yaml_specs/*.yaml

# 5. Execute Python scripts to create diagrams
cd python_scripts && ./generate_all.sh  # Unix/Mac
cd python_scripts && generate_all.bat   # Windows

# 6. Convert to Draw.io format
aws-arch drawio convert-all .
```

## Command Structure

The CLI provides three main command groups for diagram generation operations:

```
aws-arch
├── yaml          YAML specification operations
│   ├── validate              Validate YAML files (syntax, schema, services, edges)
│   └── list-services         List all valid AWS service kinds
│
├── python        Python script generation
│   ├── generate              Generate Python scripts from YAML files
│   └── generate-all          Generate from all YAMLs in directory
│
└── drawio        Draw.io XML conversion
    ├── convert               Convert single DOT file to Draw.io XML
    └── convert-all           Convert all DOT files in directory
```

### YAML Format Support

The CLI supports **two YAML formats**:

#### 1. Node-Based Format (Flat Structure)
Traditional flat format with all nodes at root level:

```yaml
system: "My System"
metadata:
  diagram_type: "c4_context"
  description: "System context"
  version: "1.0"

nodes:
  - id: "client"
    kind: "generic"
    label: "Client"
    description: "External client"
    cluster: "external"  # Optional: assign to cluster

  - id: "api"
    kind: "api-gateway"
    label: "API Gateway"
    cluster: "internal"

clusters:  # Optional: visual grouping
  - id: "external"
    label: "External Systems"
  - id: "internal"
    label: "Internal Services"

edges:
  - from: "client"
    to: "api"
    label: "HTTPS requests"
    color: "blue"
```

#### 2. Cluster-Based Format (Nested Structure)
Cluster-first format with components nested in clusters (from yaml-from-tdd skill):

```yaml
system: "My System"
metadata:
  diagram_type: "c4_context"
  description: "System context"
  version: "1.0"

clusters:
  - name: "External Systems"
    components:
      - id: "client"
        kind: "generic"
        label: "Client"
        description: "External client"

  - name: "Internal Services"
    components:
      - id: "api"
        kind: "api-gateway"
        label: "API Gateway"
        description: "REST API endpoint"

edges:
  - from: "client"
    to: "api"
    label: "HTTPS requests"
    color: "blue"
```

**Automatic Transformation:** The CLI automatically detects and transforms cluster-based format to node-based format internally, so both formats work seamlessly with all commands.

**Which Format to Use:**
- **Node-based**: When manually writing YAML or maintaining existing specs
- **Cluster-based**: Generated by yaml-from-tdd skill (more intuitive with business-domain organization)

### Integration with Skills

The CLI is designed to work with the **yaml-from-tdd skill** which handles semantic TDD analysis:

```
TDD Document → [yaml-from-tdd skill] → YAML Specs (cluster-based) → [aws-arch CLI] → Diagrams
```

The CLI transparently handles the cluster-based format generated by yaml-from-tdd, so no additional conversion steps are needed.

**Workflow:**
1. **yaml-from-tdd skill** (Semantic): Reads TDD, extracts architecture, generates 5 YAML files
2. **aws-arch yaml validate** (Deterministic): Validates YAML syntax, schema, and AWS services
3. **aws-arch python generate** (Deterministic): Converts YAML to executable Python scripts
4. **(Manual)** Execute Python scripts to generate PNG and DOT diagram files
5. **aws-arch drawio convert** (Deterministic): Converts DOT files to editable Draw.io XML

## Usage Examples

### Complete Workflow Example

Here's a complete example of generating AWS architecture diagrams:

```bash
# Step 1: Prepare your TDD document
# Place your Technical Design Document in a directory

# Step 2: Generate YAML specs using the yaml-from-tdd skill
# (This is done through the plugin skill interface, not CLI)

# Step 3: Validate the generated YAML
aws-arch yaml validate yaml_specs/*.yaml
# Output:
#   ✓ 01_c4_context.yaml - Valid
#   ✓ 02_c4_container.yaml - Valid
#   ✓ 03_vpc_network.yaml - Valid
#   ✓ 04_data_flow.yaml - Valid
#   ✓ 05_monitoring.yaml - Valid
#   Validation: 5 passed, 0 failed

# Step 4: Generate Python diagram scripts
aws-arch python generate yaml_specs/*.yaml
# Output: Creates python_scripts/ with 5 .py files + batch scripts

# Step 5: Execute the Python scripts
cd python_scripts
./generate_all.sh              # Unix/Mac
# OR
generate_all.bat               # Windows
cd ..

# Step 6: Convert to Draw.io format
aws-arch drawio convert-all python_scripts/
# Output: Creates .drawio.xml files from .dot files

# Done! Check the generated files:
# - python_scripts/*.py (Python source)
# - python_scripts/*.png (Diagram images)
# - python_scripts/*.dot (Graphviz DOT files)
# - python_scripts/*.drawio.xml (Editable in Draw.io)
```

### YAML Validation

```bash
# Validate single YAML file
aws-arch yaml validate specs/c4_context.yaml

# Validate multiple files
aws-arch yaml validate yaml_specs/*.yaml

# Strict mode (treat warnings as errors)
aws-arch yaml validate yaml_specs/*.yaml --strict

# JSON output for programmatic consumption
aws-arch yaml validate yaml_specs/*.yaml --json

# Verbose output with detailed errors
aws-arch yaml validate yaml_specs/*.yaml --verbose

# List all valid AWS service kinds
aws-arch yaml list-services

# Filter by category
aws-arch yaml list-services --category compute

# JSON output
aws-arch yaml list-services --json
```

**Validation Checks:**
- **YAML Syntax**: Valid YAML structure
- **Required Fields**: `metadata`, `nodes`, `edges` fields present
- **AWS Service Kinds**: All node `kind` values are valid AWS services
- **Edge References**: Edge `from`/`to` reference existing node IDs
- **Cluster Definitions**: Cluster node references are valid

### Python Script Generation

```bash
# Generate from single YAML
aws-arch python generate yaml_specs/01_c4_context.yaml

# Generate from multiple YAMLs
aws-arch python generate yaml_specs/*.yaml

# Specify output directory
aws-arch python generate yaml_specs/*.yaml --output-dir scripts/

# Generate without batch scripts
aws-arch python generate yaml_specs/*.yaml --no-batch

# Generate from directory
aws-arch python generate-all yaml_specs/

# JSON output
aws-arch python generate yaml_specs/*.yaml --json
```

**Generated Files:**
- Python scripts using mingrammer/diagrams library
- Batch execution scripts (Windows: `.bat`, Unix/Mac: `.sh`)
- Automatic Graphviz PATH configuration for Windows
- Import statements for all referenced AWS services

### Draw.io Conversion

```bash
# Convert single DOT file
aws-arch drawio convert diagrams/c4_context.dot

# Convert all DOT files in project
aws-arch drawio convert-all python_scripts/

# Specify output directory
aws-arch drawio convert diagrams/c4_context.dot --output-dir drawio/

# JSON output
aws-arch drawio convert diagrams/c4_context.dot --json
```

**Conversion Features:**
- Parses Graphviz DOT files using pydot
- Maps AWS service nodes to appropriate Draw.io icons
- Transforms coordinates (Y-axis inversion)
- Preserves edge styling (colors, dashing)
- Generates mxGraph XML format compatible with Draw.io

## JSON Output

All commands support `--json` flag for structured output, which is useful for integration with other tools or the plugin skills:

```bash
aws-arch yaml validate my-specs/*.yaml --json
```

Output format:

```json
{
  "status": "success",
  "message": "Validated 5 file(s)",
  "data": {
    "total_files": 5,
    "passed": 5,
    "failed": 0,
    "total_errors": 0,
    "total_warnings": 0,
    "results": [
      {
        "file_path": "yaml_specs/01_c4_context.yaml",
        "is_valid": true,
        "errors": [],
        "warnings": [],
        "error_count": 0,
        "warning_count": 0
      }
    ]
  }
}
```

## Configuration

### AWS Services Configuration

AWS service definitions are loaded from `aws_arch/config/aws_services.json`:

```json
{
  "services": {
    "lambda": {
      "name": "Lambda",
      "category": "compute",
      "description": "AWS Lambda serverless compute",
      "import_path": "diagrams.aws.compute.Lambda"
    },
    "api-gateway": {
      "name": "API Gateway",
      "category": "network",
      "description": "Amazon API Gateway",
      "import_path": "diagrams.aws.network.APIGateway"
    }
  },
  "categories": {
    "compute": "Compute Services",
    "network": "Networking & Content Delivery",
    "database": "Database Services",
    "storage": "Storage Services"
  }
}
```

### Extending AWS Services

To add support for additional AWS services:

1. Edit `aws_arch/config/aws_services.json`
2. Add service definition with correct import path from mingrammer/diagrams
3. Test with `aws-arch yaml list-services`

## Development

### Running Tests

```bash
# Run all tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=aws_arch --cov-report=html

# Run specific test file
pytest tests/test_utils.py -v
```

### Code Quality

```bash
# Format code
black aws_arch/ tests/

# Lint code
ruff aws_arch/ tests/

# Type checking
mypy aws_arch/
```

## Requirements

### System Dependencies

- **Python**: 3.8 or higher
- **Graphviz**: Required for diagram generation
  - Windows: https://graphviz.org/download/
  - macOS: `brew install graphviz`
  - Linux: `sudo apt-get install graphviz`

### Python Dependencies

Core dependencies (automatically installed):

- `typer>=0.9.0` - CLI framework
- `rich>=13.0.0` - Terminal formatting
- `pyyaml>=6.0` - YAML parsing
- `pydot>=1.4.2` - DOT file processing
- `diagrams>=0.23.4` - Diagram generation
- `jinja2>=3.1.0` - Template engine
- `python-docx>=1.1.0` - DOCX parsing
- `pypdf>=3.0.0` - PDF parsing

Development dependencies:

- `pytest>=7.4.0`
- `pytest-cov>=4.1.0`
- `pytest-mock>=3.11.0`
- `black>=23.7.0`
- `ruff>=0.0.286`
- `mypy>=1.5.0`

## Project Structure

```
cli/
├── aws_arch/                       Main package
│   ├── __init__.py                 Version and metadata
│   ├── __main__.py                 Entry point for python -m aws_arch
│   ├── cli.py                      Main Typer app with command groups
│   │
│   ├── commands/                   Command modules (Typer apps)
│   │   ├── __init__.py
│   │   ├── yaml_cmd.py             YAML validation and service listing
│   │   ├── python_cmd.py           Python script generation
│   │   └── drawio_cmd.py           Draw.io XML conversion
│   │
│   ├── core/                       Core logic modules
│   │   ├── __init__.py
│   │   ├── utils.py                Common utilities, JSON output, error handling
│   │   ├── yaml_validator.py      YAML validation engine
│   │   ├── python_generator.py    Python code generation from YAML
│   │   ├── aws_mapping.py          AWS service → diagrams import mapping
│   │   └── drawio_converter.py    DOT → Draw.io XML conversion
│   │
│   └── config/                     Configuration files
│       ├── __init__.py
│       └── aws_services.json       AWS service definitions and import paths
│
├── tests/                          Test suite
│   ├── __init__.py
│   ├── conftest.py                 Pytest fixtures and configuration
│   ├── test_utils.py               Utils module tests
│   ├── test_yaml_validator.py     YAML validation tests
│   ├── test_python_generator.py   Python generation tests
│   ├── test_drawio_converter.py   Draw.io conversion tests
│   └── fixtures/                   Test data
│       ├── yaml/                   Sample YAML specs
│       ├── tdd/                    Sample TDD documents
│       └── dot/                    Sample DOT files
│
├── pyproject.toml                  Project configuration and dependencies
├── setup.py                        Setup script for pip install
└── README.md                       This file
```

### Key Files

- **cli.py**: Main Typer application that registers command groups
- **commands/*.py**: Command modules for yaml, python, and drawio operations
- **core/utils.py**: Common utilities including JSON output formatting and error handling
- **core/yaml_validator.py**: YAML validation engine with syntax, schema, and semantic checks
- **core/python_generator.py**: Converts YAML specs to executable Python scripts
- **core/aws_mapping.py**: Maps AWS service kinds to mingrammer/diagrams import paths
- **core/drawio_converter.py**: Converts Graphviz DOT files to Draw.io XML format
- **config/aws_services.json**: AWS service registry with 40+ services

## Integration with Plugin

The CLI is designed to be invoked by the AIDLC-tech-architect plugin skills:

### From yaml-from-tdd Skill

The yaml-from-tdd skill generates YAML specifications and then the plugin can invoke CLI commands:

```python
# Skill generates YAML files
# Then invokes CLI for validation:
result = subprocess.run(
    ["aws-arch", "yaml", "validate", "yaml_specs/*.yaml", "--json"],
    capture_output=True,
    text=True
)
validation = json.loads(result.stdout)
```

### Direct CLI Usage

Users can also use the CLI directly for:

- **Development**: Iterative testing of YAML specs
- **Debugging**: Detailed validation errors with `--verbose`
- **Automation**: Scripting with `--json` output
- **Manual workflow**: Step-by-step diagram generation

### Example Integration Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    User invokes plugin skill                     │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │ yaml-from-tdd   │  ← Skill (Semantic)
                    │     Skill       │
                    └────────┬────────┘
                             │
                             ▼
                      Generate 5 YAML files
                             │
                             ▼
                    ┌─────────────────┐
                    │  aws-arch yaml  │  ← CLI (Deterministic)
                    │    validate     │
                    └────────┬────────┘
                             │
                    ┌────────┴────────┐
                    │                 │
              Valid │                 │ Invalid
                    ▼                 ▼
          ┌─────────────────┐  ┌──────────────┐
          │  aws-arch python│  │ Report Errors│
          │    generate     │  │ to User      │
          └────────┬────────┘  └──────────────┘
                   │
                   ▼
           Generate Python scripts
                   │
                   ▼
          ┌─────────────────┐
          │ User executes   │
          │ batch scripts   │
          └────────┬────────┘
                   │
                   ▼
          ┌─────────────────┐
          │  aws-arch drawio│
          │   convert-all   │
          └────────┬────────┘
                   │
                   ▼
             Final diagrams ready
```

## Troubleshooting

### Graphviz Not Found

**Symptom**: Python scripts fail with "graphviz executables not found on your system"

```bash
# Verify Graphviz installation
dot -V

# Install Graphviz if missing:
# Windows: Download from https://graphviz.org/download/ and install
# macOS: brew install graphviz
# Linux: sudo apt-get install graphviz

# Add to PATH (Windows)
set PATH=C:\Program Files\Graphviz\bin;%PATH%

# Add to PATH (macOS/Linux)
export PATH=/usr/local/bin:$PATH
```

The Python generator automatically adds Graphviz PATH configuration for Windows in generated scripts.

### YAML Validation Errors

**Symptom**: Validation fails with service kind errors

```bash
# Check which services are supported
aws-arch yaml list-services

# Check specific category
aws-arch yaml list-services --category compute

# Get detailed error information
aws-arch yaml validate yaml_specs/*.yaml --verbose
```

Common issues:
- **Unknown service kind**: Use exact service ID from `list-services` (e.g., `lambda`, not `aws-lambda`)
- **Edge references**: Ensure `from`/`to` fields reference actual node IDs in the YAML
- **Missing required fields**: YAML must have `metadata`, `nodes`, and `edges` sections

### Module Not Found

**Symptom**: `aws-arch: command not found` or `ModuleNotFoundError`

```bash
# Reinstall in development mode
cd plugins_disabled/AIDLC-tech-architect/cli
pip install -e .

# Or install with dev dependencies
pip install -e ".[dev]"

# Verify installation
aws-arch --version
```

### Permission Errors

**Symptom**: Permission denied when installing

```bash
# Use virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # Unix/Mac
# OR
venv\Scripts\activate     # Windows

# Then install
pip install -e .
```

### Python Generation Issues

**Symptom**: Generated Python scripts have syntax errors

- Ensure YAML validation passed before generating Python
- Check that all AWS services in YAML are supported (use `list-services`)
- Verify node IDs are valid Python identifiers (no spaces, special characters)

### Draw.io Conversion Issues

**Symptom**: DOT to XML conversion fails

```bash
# Verify DOT file is valid
dot -Tpng input.dot -o test.png

# Check pydot can parse it
python -c "import pydot; pydot.graph_from_dot_file('input.dot')"

# Use verbose mode for details
aws-arch drawio convert input.dot --verbose
```

## Implementation Status

This CLI is part of the migration from agent-based to hybrid architecture. Current implementation status:

### ✅ Completed (Phase 1 & 2a)

- **Phase 1a**: Project structure, core utilities, configuration
- **Phase 1b**: YAML validation (syntax, schema, AWS services, edges)
- **Phase 1c**: Draw.io conversion (DOT → XML with AWS icons)
- **Phase 2a**: Python generation (YAML → executable Python scripts)
- **Phase 2c**: YAML generation via yaml-from-tdd skill (skills-based semantic extraction)

### 🚧 In Progress

- Integration testing with yaml-from-tdd skill
- End-to-end workflow validation
- Performance benchmarking

### 📋 Planned (Future Phases)

- **Phase 3**: Workflow orchestration commands (project management, diagram execution)
- **Phase 4**: Additional skills (aws-architecture wrapper skill, C4 model reference)
- **Phase 5**: Comprehensive testing and documentation
- **Phase 6**: Deprecation of old agent-based components

For detailed migration plan, see [MIGRATION_PLAN.md](../MIGRATION_PLAN.md)

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 2.0.0 | 2026-02-16 | CLI foundation with validation, Python generation, and Draw.io conversion |
| 1.0.0 | 2024-01-01 | Initial agent-based implementation (deprecated) |

## Testing

### Running Tests

```bash
# Run all tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=aws_arch --cov-report=html

# Run specific test file
pytest tests/test_yaml_validator.py -v

# Run with verbose output
pytest tests/ -v -s
```

### Test Coverage

Current test coverage exceeds 80% across all core modules:

- `yaml_validator.py`: >90% coverage
- `drawio_converter.py`: 91% coverage
- `python_generator.py`: >85% coverage
- `utils.py`: >80% coverage

## License

MIT License - Internal use

## Links

- **Repository**: https://github.aig.net/genlite/genlite-aig-claude
- **Plugin Documentation**: [../README.md](../README.md)
- **Migration Plan**: [../MIGRATION_PLAN.md](../MIGRATION_PLAN.md)
- **Skills Documentation**: [../skills/yaml-from-tdd/SKILL.md](../skills/yaml-from-tdd/SKILL.md)

## Support

For issues or questions:

1. Check the documentation in this README
2. Review the [Migration Plan](../MIGRATION_PLAN.md) for architecture details
3. Run commands with `--help` flag for command-specific help
4. Enable verbose mode with `--verbose` for detailed output
5. Use `--json` flag for programmatic consumption
6. Report issues on the repository

## Contributing

When adding new features:

1. Follow the existing code structure and patterns
2. Add comprehensive tests (target >80% coverage)
3. Update this README with new commands and examples
4. Use type hints and docstrings
5. Follow PEP 8 style guidelines
6. Test on both Windows and Unix/Mac platforms
