"""Tests for AWS Architecture CLI."""
