"""Tests for project manager module."""

import shutil
from pathlib import Path

import pytest

from aws_arch.core.project_manager import ProjectManager


@pytest.fixture
def temp_base_dir(tmp_path):
    """Create temporary base directory for tests."""
    base_dir = tmp_path / "test_projects"
    base_dir.mkdir()
    return base_dir


@pytest.fixture
def project_manager(temp_base_dir):
    """Create ProjectManager instance with temp directory."""
    return ProjectManager(base_path=temp_base_dir)


class TestProjectManager:
    """Tests for ProjectManager class."""

    def test_init_default_path(self):
        """Test initialization with default path."""
        manager = ProjectManager()
        assert manager.base_path == Path.cwd()

    def test_init_custom_path(self, temp_base_dir):
        """Test initialization with custom path."""
        manager = ProjectManager(base_path=temp_base_dir)
        assert manager.base_path == temp_base_dir

    def test_validate_project_name_valid(self, project_manager):
        """Test validation of valid project names."""
        valid_names = [
            "my-project",
            "MyProject",
            "my_project",
            "project123",
            "proj-123_test",
        ]

        for name in valid_names:
            is_valid, error = project_manager.validate_project_name(name)
            assert is_valid, f"Name '{name}' should be valid"
            assert error == ""

    def test_validate_project_name_invalid(self, project_manager):
        """Test validation of invalid project names."""
        invalid_names = [
            "",
            "my project",  # space
            "my@project",  # special char
            "my.project",  # dot
            "my/project",  # slash
        ]

        for name in invalid_names:
            is_valid, error = project_manager.validate_project_name(name)
            assert not is_valid, f"Name '{name}' should be invalid"
            assert error != ""

    def test_project_exists(self, project_manager, temp_base_dir):
        """Test checking if project exists."""
        # Non-existent project
        assert not project_manager.project_exists("nonexistent")

        # Create a project directory
        project_dir = temp_base_dir / "test-project"
        project_dir.mkdir()

        # Now it should exist
        assert project_manager.project_exists("test-project")

    def test_create_project_success(self, project_manager, temp_base_dir):
        """Test successful project creation."""
        project_name = "test-project"

        success, message, project_path = project_manager.create_project(project_name)

        assert success
        assert "created successfully" in message.lower()
        assert project_path == temp_base_dir / project_name

        # Verify folder structure
        for folder in project_manager.REQUIRED_FOLDERS:
            folder_path = project_path / folder
            assert folder_path.exists(), f"Folder {folder} should exist"
            assert folder_path.is_dir(), f"{folder} should be a directory"

        # Verify files
        assert (project_path / "README.md").exists()
        assert (project_path / ".gitignore").exists()

    def test_create_project_invalid_name(self, project_manager):
        """Test project creation with invalid name."""
        success, message, project_path = project_manager.create_project("invalid name")

        assert not success
        assert "invalid" in message.lower() or "contain only" in message.lower()
        assert project_path is None

    def test_create_project_already_exists(self, project_manager, temp_base_dir):
        """Test project creation when project already exists."""
        project_name = "test-project"

        # Create project first time
        success, message, project_path = project_manager.create_project(project_name)
        assert success

        # Try to create again without force
        success, message, project_path = project_manager.create_project(project_name)
        assert not success
        assert "already exists" in message.lower()

    def test_create_project_force_recreate(self, project_manager, temp_base_dir):
        """Test project recreation with force flag."""
        project_name = "test-project"

        # Create project first time
        success, message, project_path = project_manager.create_project(project_name)
        assert success

        # Add a file to verify it gets recreated
        test_file = project_path / "test.txt"
        test_file.write_text("test")

        # Recreate with force
        success, message, project_path = project_manager.create_project(
            project_name, force=True
        )
        assert success

        # Original file should still exist (force doesn't delete existing)
        # but project structure should be valid
        assert project_path.exists()

    def test_list_projects_empty(self, project_manager):
        """Test listing projects when none exist."""
        projects = project_manager.list_projects()
        assert projects == []

    def test_list_projects_with_projects(self, project_manager, temp_base_dir):
        """Test listing projects when some exist."""
        # Create some projects
        project_manager.create_project("project1")
        project_manager.create_project("project2")

        # Create a non-project directory
        (temp_base_dir / "not-a-project").mkdir()

        projects = project_manager.list_projects()

        assert len(projects) == 2
        project_names = [p["name"] for p in projects]
        assert "project1" in project_names
        assert "project2" in project_names
        assert "not-a-project" not in project_names

    def test_get_project_info_exists(self, project_manager):
        """Test getting info for existing project."""
        project_name = "test-project"
        project_manager.create_project(project_name)

        info = project_manager.get_project_info(project_name)

        assert info is not None
        assert info["name"] == project_name
        assert info["is_valid"]
        assert "folders" in info
        assert "yaml_count" in info
        assert "total_files" in info

    def test_get_project_info_not_exists(self, project_manager):
        """Test getting info for non-existent project."""
        info = project_manager.get_project_info("nonexistent")
        assert info is None

    def test_is_valid_project(self, project_manager, temp_base_dir):
        """Test project validation."""
        # Create valid project
        project_name = "valid-project"
        success, message, project_path = project_manager.create_project(project_name)
        assert success

        # Should be valid
        assert project_manager._is_valid_project(project_path)

        # Create incomplete project (missing folders)
        incomplete_path = temp_base_dir / "incomplete"
        incomplete_path.mkdir()
        (incomplete_path / "requirements").mkdir()

        # Should be invalid (missing yaml_specs)
        assert not project_manager._is_valid_project(incomplete_path)

    def test_get_project_stats(self, project_manager):
        """Test getting project statistics."""
        project_name = "test-project"
        success, message, project_path = project_manager.create_project(project_name)
        assert success

        stats = project_manager._get_project_stats(project_path)

        assert "yaml_count" in stats
        assert "total_files" in stats
        assert isinstance(stats["yaml_count"], int)
        assert isinstance(stats["total_files"], int)
        assert stats["total_files"] >= 2  # At least README.md and .gitignore

    def test_format_project_list(self, project_manager):
        """Test formatting project list."""
        # Empty list
        result = project_manager.format_project_list([])
        assert "no projects" in result.lower()

        # With projects
        projects = [
            {
                "name": "project1",
                "path": "/path/to/project1",
                "yaml_count": 5,
                "total_files": 10,
            }
        ]
        result = project_manager.format_project_list(projects)
        # Should return a Table object or string representation
        assert result is not None

    def test_format_project_info(self, project_manager):
        """Test formatting project info."""
        info = {
            "name": "test-project",
            "path": "/path/to/project",
            "folders": {
                "requirements": 2,
                "yaml_specs": 5,
                "python_scripts": 3,
                "diagrams": 0,
                "drawio": -1,  # Missing
            },
            "yaml_count": 5,
            "total_files": 10,
            "is_valid": True,
        }

        result = project_manager.format_project_info(info)
        # Should return a Table object or string representation
        assert result is not None

    def test_create_readme_content(self, project_manager, temp_base_dir):
        """Test README.md content."""
        project_name = "test-project"
        success, message, project_path = project_manager.create_project(project_name)
        assert success

        readme_path = project_path / "README.md"
        assert readme_path.exists()

        content = readme_path.read_text()

        # Check key sections
        assert project_name in content
        assert "Project Structure" in content
        assert "Quick Start" in content
        assert "Requirements" in content
        assert "Workflow Steps" in content
        assert "TDD Preservation" in content

    def test_create_gitignore_content(self, project_manager, temp_base_dir):
        """Test .gitignore content."""
        project_name = "test-project"
        success, message, project_path = project_manager.create_project(project_name)
        assert success

        gitignore_path = project_path / ".gitignore"
        assert gitignore_path.exists()

        content = gitignore_path.read_text()

        # Check key patterns
        assert "__pycache__" in content
        assert "*.pyc" in content or "*.py[cod]" in content
        assert ".DS_Store" in content
        assert "*.log" in content


@pytest.mark.parametrize(
    "project_name,expected_valid",
    [
        ("valid-project", True),
        ("ValidProject", True),
        ("valid_project", True),
        ("project123", True),
        ("123project", True),
        ("", False),
        ("invalid project", False),
        ("invalid@project", False),
    ],
)
def test_validate_project_name_parametrized(
    project_manager, project_name, expected_valid
):
    """Parametrized test for project name validation."""
    is_valid, error = project_manager.validate_project_name(project_name)
    assert is_valid == expected_valid
    if not expected_valid:
        assert error != ""
