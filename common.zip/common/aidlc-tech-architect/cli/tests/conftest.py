"""Pytest configuration and fixtures for AWS Architecture CLI tests."""

import json
import tempfile
from pathlib import Path
from typing import Any, Dict

import pytest
from typer.testing import CliRunner


@pytest.fixture
def cli_runner():
    """Provide a Typer CLI runner for testing."""
    return CliRunner()


@pytest.fixture
def temp_dir(tmp_path):
    """Provide a temporary directory for testing."""
    return tmp_path


@pytest.fixture
def sample_project_structure(temp_dir):
    """Create a sample project structure for testing.

    Returns a dictionary with paths to all directories.
    """
    project_path = temp_dir / "test-project"
    project_path.mkdir()

    # Create subdirectories
    directories = {
        "root": project_path,
        "requirements": project_path / "requirements",
        "yaml_specs": project_path / "yaml_specs",
        "python_scripts": project_path / "python_scripts",
        "diagrams": project_path / "diagrams",
        "drawio": project_path / "drawio",
    }

    for dir_path in directories.values():
        if dir_path != project_path:
            dir_path.mkdir()

    return directories


@pytest.fixture
def sample_yaml_spec():
    """Provide a sample YAML specification for testing."""
    return """system: Test System

metadata:
  diagram_type: c4_context
  level: 1
  title: "Test Context Diagram"
  description: "Sample context diagram for testing"
  version: "1.0"
  created: "2026-02-16"

nodes:
  - id: user
    label: "User"
    kind: generic
    description: "End user of the system"

  - id: api
    label: "API Gateway"
    kind: api-gateway
    description: "REST API endpoint"

  - id: lambda_fn
    label: "Process Lambda"
    kind: lambda
    description: "Processes requests"

edges:
  - from: user
    to: api
    label: "HTTPS requests"
    color: blue

  - from: api
    to: lambda_fn
    label: "Invokes"
    color: green

output:
  graph_attr:
    fontsize: "14"
    bgcolor: "white"
    splines: "ortho"
    nodesep: "1.0"
    ranksep: "1.5"
    dpi: "300"
"""


@pytest.fixture
def sample_tdd_content():
    """Provide sample TDD content for testing."""
    return """# Technical Design Document

## System Overview

The payment processing system handles customer transactions using AWS services.

## Architecture Components

### API Layer
- **API Gateway**: REST API endpoint for customer requests
- **Lambda Function**: Processes payment requests

### Data Layer
- **DynamoDB**: Stores transaction records
- **Aurora**: Stores customer information

### Integration
- **EventBridge**: Routes events to downstream systems
- **SQS**: Dead letter queue for failed transactions

## Data Flow

1. Customer sends payment request to API Gateway
2. API Gateway invokes Lambda function
3. Lambda validates payment and stores in DynamoDB
4. Lambda publishes event to EventBridge
5. EventBridge routes to downstream services

## Non-Functional Requirements

- Response time < 500ms
- 99.9% availability
- Support 1000 TPS
"""


@pytest.fixture
def sample_json_output():
    """Provide a sample JSON output structure."""
    return {
        "status": "success",
        "message": "Operation completed successfully",
        "data": {"count": 5, "files": ["file1.yaml", "file2.yaml"]},
    }


@pytest.fixture
def aws_services_config():
    """Provide AWS services configuration for testing."""
    return {
        "lambda": {
            "name": "AWS Lambda",
            "category": "compute",
            "description": "Serverless compute",
        },
        "api-gateway": {
            "name": "Amazon API Gateway",
            "category": "network",
            "description": "API management",
        },
        "dynamodb": {
            "name": "Amazon DynamoDB",
            "category": "database",
            "description": "NoSQL database",
        },
    }


@pytest.fixture
def mock_platform_info():
    """Provide mock platform information."""
    return {
        "system": "Darwin",
        "version": "24.6.0",
        "machine": "arm64",
        "python_version": "3.11.5",
    }


def create_yaml_file(path: Path, content: str) -> Path:
    """Helper to create a YAML file with content."""
    path.write_text(content, encoding="utf-8")
    return path


def create_json_file(path: Path, data: Dict[str, Any]) -> Path:
    """Helper to create a JSON file with data."""
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def assert_file_exists(path: Path):
    """Helper to assert that a file exists."""
    assert path.exists(), f"File does not exist: {path}"


def assert_file_contains(path: Path, text: str):
    """Helper to assert that a file contains specific text."""
    content = path.read_text(encoding="utf-8")
    assert text in content, f"File does not contain '{text}': {path}"


def assert_valid_json(text: str):
    """Helper to assert that text is valid JSON."""
    try:
        json.loads(text)
    except json.JSONDecodeError as e:
        pytest.fail(f"Invalid JSON: {e}")


# Make helpers available to all tests
pytest.create_yaml_file = create_yaml_file
pytest.create_json_file = create_json_file
pytest.assert_file_exists = assert_file_exists
pytest.assert_file_contains = assert_file_contains
pytest.assert_valid_json = assert_valid_json
