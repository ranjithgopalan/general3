"""
Tests for Python diagram generator.
"""

import pytest
from pathlib import Path
import tempfile
import shutil
import yaml
import ast
import os

from aws_arch.core.python_generator import PythonGenerator, GenerationResult
from aws_arch.core.aws_mapping import (
    get_import_for_service,
    sanitize_node_id,
    get_class_name_for_service,
    generate_import_statements
)


# Fixtures

@pytest.fixture
def temp_output_dir():
    """Create a temporary output directory."""
    temp_dir = tempfile.mkdtemp()
    yield Path(temp_dir)
    shutil.rmtree(temp_dir)


@pytest.fixture
def fixtures_dir():
    """Get the fixtures directory."""
    return Path(__file__).parent / "fixtures" / "yaml"


@pytest.fixture
def simple_yaml(fixtures_dir):
    """Simple diagram YAML file."""
    return fixtures_dir / "simple_diagram.yaml"


@pytest.fixture
def context_yaml(fixtures_dir):
    """C4 context diagram YAML file."""
    return fixtures_dir / "c4_context.yaml"


@pytest.fixture
def container_yaml(fixtures_dir):
    """C4 container diagram YAML file."""
    return fixtures_dir / "c4_container.yaml"


# AWS Mapping Tests

class TestAWSMapping:
    """Test AWS service mapping functions."""

    def test_get_import_for_lambda(self):
        """Test import mapping for Lambda."""
        module, class_name = get_import_for_service('lambda')
        assert module == 'diagrams.aws.compute'
        assert class_name == 'Lambda'

    def test_get_import_for_api_gateway(self):
        """Test import mapping for API Gateway."""
        module, class_name = get_import_for_service('api-gateway')
        assert module == 'diagrams.aws.network'
        assert class_name == 'APIGateway'

    def test_get_import_for_sns(self):
        """Test SNS is in integration (common mistake)."""
        module, class_name = get_import_for_service('sns')
        assert module == 'diagrams.aws.integration'
        assert class_name == 'SimpleNotificationServiceSns'

    def test_get_import_for_xray(self):
        """Test X-Ray is in devtools (common mistake)."""
        module, class_name = get_import_for_service('x-ray')
        assert module == 'diagrams.aws.devtools'
        assert class_name == 'XRay'

    def test_get_import_for_cloudwatch(self):
        """Test CloudWatch is in management (common mistake)."""
        module, class_name = get_import_for_service('cloudwatch')
        assert module == 'diagrams.aws.management'
        assert class_name == 'Cloudwatch'

    def test_get_import_for_unknown_service(self):
        """Test unknown service returns None."""
        result = get_import_for_service('unknown-service')
        assert result is None

    def test_sanitize_node_id_with_hyphens(self):
        """Test node ID sanitization with hyphens."""
        assert sanitize_node_id('api-gateway') == 'api_gateway'

    def test_sanitize_node_id_with_spaces(self):
        """Test node ID sanitization with spaces."""
        assert sanitize_node_id('My Lambda Function') == 'my_lambda_function'

    def test_sanitize_node_id_with_numbers_start(self):
        """Test node ID starting with number."""
        assert sanitize_node_id('123-lambda') == 'node_123_lambda'

    def test_sanitize_node_id_python_keyword(self):
        """Test node ID that is a Python keyword."""
        assert sanitize_node_id('lambda') == 'lambda_node'
        assert sanitize_node_id('class') == 'class_node'

    def test_generate_import_statements(self):
        """Test generating import statements."""
        service_kinds = ['lambda', 'api-gateway', 'dynamodb']
        imports = generate_import_statements(service_kinds)

        # Check base imports
        assert 'from diagrams import Diagram, Cluster, Edge' in imports
        assert 'import os' in imports

        # Check service imports
        import_str = '\n'.join(imports)
        assert 'diagrams.aws.compute import Lambda' in import_str
        assert 'diagrams.aws.network import APIGateway' in import_str
        assert 'diagrams.aws.database import Dynamodb' in import_str


# Python Generator Tests

class TestPythonGenerator:
    """Test Python code generator."""

    def test_generator_initialization(self, temp_output_dir):
        """Test generator initialization."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        assert generator.output_dir == temp_output_dir

    def test_generate_from_simple_yaml(self, simple_yaml, temp_output_dir):
        """Test generation from simple YAML."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(simple_yaml)

        assert result.success is True
        assert result.python_file is not None
        assert result.python_file.exists()
        assert result.nodes_count == 3
        assert result.edges_count == 2
        assert result.clusters_count == 0

    def test_generate_from_context_yaml(self, context_yaml, temp_output_dir):
        """Test generation from C4 context YAML."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(context_yaml)

        assert result.success is True
        assert result.python_file is not None
        assert result.python_file.exists()
        assert result.nodes_count == 5
        assert result.edges_count == 5
        assert result.clusters_count == 1

    def test_generate_from_container_yaml(self, container_yaml, temp_output_dir):
        """Test generation from C4 container YAML."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(container_yaml)

        assert result.success is True
        assert result.python_file is not None
        assert result.python_file.exists()
        assert result.nodes_count == 8
        assert result.edges_count == 8
        assert result.clusters_count == 6

    def test_generated_python_is_valid_syntax(self, simple_yaml, temp_output_dir):
        """Test that generated Python has valid syntax."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(simple_yaml)

        assert result.success is True

        # Read generated Python
        with open(result.python_file, 'r') as f:
            python_code = f.read()

        # Try to parse as AST (will raise SyntaxError if invalid)
        try:
            ast.parse(python_code)
        except SyntaxError as e:
            pytest.fail(f"Generated Python has syntax error: {e}")

    def test_generated_python_has_required_imports(self, simple_yaml, temp_output_dir):
        """Test generated Python has required imports."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(simple_yaml)

        with open(result.python_file, 'r') as f:
            content = f.read()

        # Check for required imports
        assert 'from diagrams import Diagram, Cluster, Edge' in content
        assert 'import os' in content
        assert 'import sys' in content
        assert 'from diagrams.aws' in content

    def test_generated_python_has_graphviz_config(self, simple_yaml, temp_output_dir):
        """Test generated Python has Graphviz configuration."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(simple_yaml)

        with open(result.python_file, 'r') as f:
            content = f.read()

        # Check for Graphviz PATH configuration
        assert 'graphviz_path' in content
        assert 'Graphviz\\bin' in content

    def test_generated_python_has_correct_direction(self, simple_yaml, temp_output_dir):
        """Test generated Python uses correct direction."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(simple_yaml)

        with open(result.python_file, 'r') as f:
            content = f.read()

        # simple_diagram.yaml has direction: LR
        assert 'direction="LR"' in content

    def test_generated_python_has_png_and_dot_output(self, simple_yaml, temp_output_dir):
        """Test generated Python outputs both PNG and DOT formats."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(simple_yaml)

        with open(result.python_file, 'r') as f:
            content = f.read()

        # Critical: Must output both formats
        assert 'outformat=["png", "dot"]' in content

    def test_generated_python_has_clusters(self, context_yaml, temp_output_dir):
        """Test generated Python has cluster definitions."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(context_yaml)

        with open(result.python_file, 'r') as f:
            content = f.read()

        # Check for cluster
        assert 'with Cluster(' in content
        assert 'Payment Processing System' in content

    def test_generated_python_has_edges_with_labels(self, context_yaml, temp_output_dir):
        """Test generated Python has edges with labels and colors."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(context_yaml)

        with open(result.python_file, 'r') as f:
            content = f.read()

        # Check for edges with properties
        assert 'Edge(' in content
        assert 'label=' in content
        assert 'color=' in content

    def test_generate_from_directory(self, fixtures_dir, temp_output_dir):
        """Test generating from entire directory."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        results = generator.generate_from_directory(fixtures_dir)

        # Should find multiple YAML files (including invalid ones)
        assert len(results) >= 3

        # At least some should succeed (valid files)
        successful = [r for r in results if r.success]
        assert len(successful) >= 3

        # Check that our created fixtures succeeded
        successful_names = [r.yaml_file.name for r in successful]
        assert 'simple_diagram.yaml' in successful_names
        assert 'c4_context.yaml' in successful_names
        assert 'c4_container.yaml' in successful_names

    def test_generate_batch_scripts(self, fixtures_dir, temp_output_dir):
        """Test batch script generation."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        results = generator.generate_from_directory(fixtures_dir)

        python_files = [r.python_file for r in results if r.success]
        batch_win, batch_unix = generator.generate_batch_scripts(python_files)

        assert batch_win is not None
        assert batch_unix is not None
        assert batch_win.exists()
        assert batch_unix.exists()
        assert batch_win.name == "generate_all.bat"
        assert batch_unix.name == "generate_all.sh"

    def test_windows_batch_script_content(self, simple_yaml, temp_output_dir):
        """Test Windows batch script has correct content."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(simple_yaml)

        batch_win, _ = generator.generate_batch_scripts([result.python_file])

        with open(batch_win, 'r') as f:
            content = f.read()

        assert '@echo off' in content
        assert 'python --version' in content
        assert 'import diagrams' in content
        assert result.python_file.name in content

    def test_unix_batch_script_content(self, simple_yaml, temp_output_dir):
        """Test Unix batch script has correct content."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(simple_yaml)

        _, batch_unix = generator.generate_batch_scripts([result.python_file])

        with open(batch_unix, 'r') as f:
            content = f.read()

        assert '#!/bin/bash' in content
        assert 'command -v python3' in content  # Check for Python
        assert 'import diagrams' in content
        assert result.python_file.name in content

    def test_unix_script_is_executable(self, simple_yaml, temp_output_dir):
        """Test Unix script is made executable."""
        if os.name == 'nt':  # Skip on Windows
            pytest.skip("Executable check only on Unix systems")

        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(simple_yaml)

        _, batch_unix = generator.generate_batch_scripts([result.python_file])

        # Check if executable
        assert os.access(batch_unix, os.X_OK)

    def test_generation_with_invalid_yaml(self, temp_output_dir, tmp_path):
        """Test handling of invalid YAML."""
        # Create invalid YAML file
        invalid_yaml = tmp_path / "invalid.yaml"
        invalid_yaml.write_text("invalid: yaml: content: [")

        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(invalid_yaml)

        assert result.success is False
        assert result.error is not None
        assert "YAML parsing error" in result.error

    def test_generation_with_empty_yaml(self, temp_output_dir, tmp_path):
        """Test handling of empty YAML."""
        empty_yaml = tmp_path / "empty.yaml"
        empty_yaml.write_text("")

        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(empty_yaml)

        assert result.success is False
        assert result.error == "Empty YAML file"

    def test_warning_for_unknown_service(self, temp_output_dir, tmp_path):
        """Test warning is generated for unknown service kind."""
        # Create YAML with unknown service
        yaml_content = {
            'system': 'Test',
            'type': 'diagram',
            'nodes': [
                {'id': 'unknown', 'kind': 'unknown-service', 'label': 'Unknown'}
            ],
            'edges': []
        }

        unknown_yaml = tmp_path / "unknown.yaml"
        with open(unknown_yaml, 'w') as f:
            yaml.dump(yaml_content, f)

        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(unknown_yaml)

        assert result.success is True
        assert len(result.warnings) > 0
        assert any('unknown-service' in w for w in result.warnings)

    def test_output_filename_matches_input(self, simple_yaml, temp_output_dir):
        """Test output filename matches input YAML name."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(simple_yaml)

        expected_name = f"{simple_yaml.stem}.py"
        assert result.python_file.name == expected_name

    def test_graph_attributes_applied(self, context_yaml, temp_output_dir):
        """Test graph attributes from YAML are applied."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(context_yaml)

        with open(result.python_file, 'r') as f:
            content = f.read()

        # Check for graph attributes
        assert 'graph_attr = {' in content
        assert '"fontsize"' in content
        assert '"splines"' in content
        assert '"nodesep"' in content
        assert '"ranksep"' in content
        assert '"dpi": "300"' in content

    def test_system_name_in_diagram(self, context_yaml, temp_output_dir):
        """Test system name appears in generated diagram."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(context_yaml)

        with open(result.python_file, 'r') as f:
            content = f.read()

        assert 'Payment Processing System' in content

    def test_edge_styles_preserved(self, context_yaml, temp_output_dir):
        """Test edge styles (dashed, dotted) are preserved."""
        generator = PythonGenerator(output_dir=temp_output_dir)
        result = generator.generate_from_yaml_file(context_yaml)

        with open(result.python_file, 'r') as f:
            content = f.read()

        # context_yaml has dashed style edge
        assert 'style="dashed"' in content


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
