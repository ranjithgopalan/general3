"""Tests for diagram executor module."""

import subprocess
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

import pytest

from aws_arch.core.diagram_executor import DiagramExecutor, ExecutionResult, GraphvizInfo


@pytest.fixture
def temp_project(tmp_path):
    """Create temporary project structure."""
    project = tmp_path / "test-project"
    project.mkdir()

    # Create directories
    (project / "python_scripts").mkdir()
    (project / "diagrams").mkdir()
    (project / "drawio").mkdir()
    (project / "yaml_specs").mkdir()

    # Create sample Python scripts
    script1 = project / "python_scripts" / "01_test_diagram.py"
    script1.write_text("print('Script 1')")

    script2 = project / "python_scripts" / "02_sample_diagram.py"
    script2.write_text("print('Script 2')")

    return project


@pytest.fixture
def executor(temp_project):
    """Create DiagramExecutor instance."""
    return DiagramExecutor(project_path=temp_project)


class TestDiagramExecutor:
    """Tests for DiagramExecutor class."""

    def test_init(self, temp_project):
        """Test executor initialization."""
        executor = DiagramExecutor(project_path=temp_project)

        assert executor.project_path == temp_project
        assert executor.python_scripts_dir == temp_project / "python_scripts"
        assert executor.diagrams_dir == temp_project / "diagrams"
        assert executor.execution_results == []

    @patch("subprocess.run")
    def test_check_graphviz_installed(self, mock_run, executor):
        """Test checking Graphviz when installed."""
        # Mock successful Graphviz check
        mock_result = Mock()
        mock_result.returncode = 0
        mock_result.stderr = "dot - graphviz version 2.50.0"
        mock_result.stdout = ""
        mock_run.return_value = mock_result

        info = executor.check_graphviz()

        assert info.installed is True
        assert info.version == "2.50.0"
        assert info.error is None

    @patch("subprocess.run")
    def test_check_graphviz_not_installed(self, mock_run, executor):
        """Test checking Graphviz when not installed."""
        # Mock FileNotFoundError
        mock_run.side_effect = FileNotFoundError()

        info = executor.check_graphviz()

        assert info.installed is False
        assert info.version is None
        assert "not found" in info.error.lower()

    @patch("subprocess.run")
    def test_check_graphviz_error(self, mock_run, executor):
        """Test checking Graphviz with error."""
        # Mock non-zero return code
        mock_result = Mock()
        mock_result.returncode = 1
        mock_result.stderr = "error"
        mock_result.stdout = ""
        mock_run.return_value = mock_result

        info = executor.check_graphviz()

        assert info.installed is False
        assert info.error is not None

    def test_get_installation_instructions_macos(self, executor):
        """Test getting installation instructions for macOS."""
        with patch("platform.system", return_value="Darwin"):
            instructions = executor.get_installation_instructions()

            assert "brew install graphviz" in instructions
            assert "macOS" in instructions

    def test_get_installation_instructions_windows(self, executor):
        """Test getting installation instructions for Windows."""
        with patch("platform.system", return_value="Windows"):
            instructions = executor.get_installation_instructions()

            assert "choco install graphviz" in instructions
            assert "Windows" in instructions

    def test_get_installation_instructions_linux(self, executor):
        """Test getting installation instructions for Linux."""
        with patch("platform.system", return_value="Linux"):
            instructions = executor.get_installation_instructions()

            assert "apt-get install graphviz" in instructions
            assert "Linux" in instructions

    def test_check_python_version(self, executor):
        """Test checking Python version."""
        is_compatible, version = executor.check_python_version()

        assert isinstance(is_compatible, bool)
        assert isinstance(version, str)
        assert "." in version  # Version should have format X.Y.Z

    def test_ensure_output_directories(self, executor, temp_project):
        """Test ensuring output directories exist."""
        # Remove directories first
        (temp_project / "diagrams").rmdir()
        (temp_project / "drawio").rmdir()

        # Ensure they exist
        executor.ensure_output_directories()

        assert (temp_project / "diagrams").exists()
        assert (temp_project / "drawio").exists()

    def test_find_python_scripts_all(self, executor):
        """Test finding all Python scripts."""
        scripts = executor.find_python_scripts()

        assert len(scripts) == 2
        assert all(s.suffix == ".py" for s in scripts)
        assert all("diagram" in s.name for s in scripts)

    def test_find_python_scripts_specific(self, executor, temp_project):
        """Test finding specific Python script."""
        scripts = executor.find_python_scripts(diagram_name="01_test")

        assert len(scripts) == 1
        assert scripts[0].name == "01_test_diagram.py"

    def test_find_python_scripts_not_found(self, executor):
        """Test finding non-existent script."""
        scripts = executor.find_python_scripts(diagram_name="nonexistent")

        assert len(scripts) == 0

    def test_find_python_scripts_no_directory(self, temp_project):
        """Test finding scripts when directory doesn't exist."""
        # Remove python_scripts directory
        import shutil

        shutil.rmtree(temp_project / "python_scripts")

        executor = DiagramExecutor(project_path=temp_project)
        scripts = executor.find_python_scripts()

        assert len(scripts) == 0

    @patch("subprocess.run")
    def test_execute_script_success(self, mock_run, executor, temp_project):
        """Test successful script execution."""
        # Create output files
        (temp_project / "diagrams" / "01_test.png").write_text("png")
        (temp_project / "diagrams" / "01_test.dot").write_text("dot")

        # Mock successful execution
        mock_result = Mock()
        mock_result.returncode = 0
        mock_result.stderr = ""
        mock_result.stdout = "Success"
        mock_run.return_value = mock_result

        script = temp_project / "python_scripts" / "01_test_diagram.py"
        result = executor.execute_script(script)

        assert result.success is True
        assert len(result.output_files) == 2
        assert result.error_message is None
        assert result.execution_time > 0

    @patch("subprocess.run")
    def test_execute_script_failure(self, mock_run, executor, temp_project):
        """Test failed script execution."""
        # Mock failed execution
        mock_result = Mock()
        mock_result.returncode = 1
        mock_result.stderr = "ModuleNotFoundError: No module named 'diagrams'"
        mock_result.stdout = ""
        mock_run.return_value = mock_result

        script = temp_project / "python_scripts" / "01_test_diagram.py"
        result = executor.execute_script(script)

        assert result.success is False
        assert result.error_message is not None
        assert "ModuleNotFoundError" in result.error_message

    @patch("subprocess.run")
    def test_execute_script_timeout(self, mock_run, executor, temp_project):
        """Test script execution timeout."""
        # Mock timeout
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="python", timeout=300)

        script = temp_project / "python_scripts" / "01_test_diagram.py"
        result = executor.execute_script(script)

        assert result.success is False
        assert "timed out" in result.error_message.lower()

    def test_find_output_files(self, executor, temp_project):
        """Test finding output files."""
        # Create output files
        (temp_project / "diagrams" / "test.png").write_text("png")
        (temp_project / "diagrams" / "test.dot").write_text("dot")

        files = executor._find_output_files("test")

        assert len(files) == 2
        assert any("png" in f for f in files)
        assert any("dot" in f for f in files)

    def test_find_output_files_with_diagram_suffix(self, executor, temp_project):
        """Test finding output files with _diagram suffix."""
        # Create output files
        (temp_project / "diagrams" / "test.png").write_text("png")
        (temp_project / "diagrams" / "test.dot").write_text("dot")

        files = executor._find_output_files("test_diagram")

        assert len(files) == 2

    @patch("subprocess.run")
    def test_execute_all_success(self, mock_run, executor, temp_project):
        """Test executing all scripts successfully."""
        # Create output files
        (temp_project / "diagrams" / "01_test.png").write_text("png")
        (temp_project / "diagrams" / "01_test.dot").write_text("dot")
        (temp_project / "diagrams" / "02_sample.png").write_text("png")
        (temp_project / "diagrams" / "02_sample.dot").write_text("dot")

        # Mock successful execution
        mock_result = Mock()
        mock_result.returncode = 0
        mock_result.stderr = ""
        mock_result.stdout = "Success"
        mock_run.return_value = mock_result

        summary = executor.execute_all()

        assert summary["status"] == "success"
        assert summary["total_scripts"] == 2
        assert summary["successful"] == 2
        assert summary["failed"] == 0
        assert summary["png_count"] >= 2
        assert summary["dot_count"] >= 2

    @patch("aws_arch.core.diagram_executor.subprocess.run")
    def test_execute_all_partial(self, mock_run, executor, temp_project):
        """Test executing all scripts with some failures."""
        # Create output files for successful script
        (temp_project / "diagrams" / "01_test.png").write_text("png")
        (temp_project / "diagrams" / "01_test.dot").write_text("dot")

        # Create a side_effect function that tracks calls
        call_count = 0
        def subprocess_side_effect(*args, **kwargs):
            nonlocal call_count
            # Return success for script executions (skip venv calls)
            if len(args) > 0 and isinstance(args[0], list) and len(args[0]) > 1:
                if args[0][1].endswith(".py"):
                    result = Mock(returncode=0 if call_count == 0 else 1, stderr="", stdout="Output")
                    call_count += 1
                    return result
            # Return success for other calls (venv setup, pip, etc.)
            return Mock(returncode=0, stderr="", stdout="")

        mock_run.side_effect = subprocess_side_effect

        summary = executor.execute_all()

        assert summary["status"] == "partial"
        assert summary["total_scripts"] == 2
        assert summary["successful"] == 1
        assert summary["failed"] == 1

    @patch("subprocess.run")
    def test_execute_all_specific_diagram(self, mock_run, executor, temp_project):
        """Test executing specific diagram."""
        # Create output files
        (temp_project / "diagrams" / "01_test.png").write_text("png")
        (temp_project / "diagrams" / "01_test.dot").write_text("dot")

        # Mock successful execution
        mock_result = Mock()
        mock_result.returncode = 0
        mock_result.stderr = ""
        mock_result.stdout = "Success"
        mock_run.return_value = mock_result

        summary = executor.execute_all(diagram_name="01_test")

        assert summary["total_scripts"] == 1
        assert summary["successful"] == 1

    def test_execute_all_no_scripts(self, executor, temp_project):
        """Test executing when no scripts found."""
        # Remove scripts
        import shutil

        shutil.rmtree(temp_project / "python_scripts")
        (temp_project / "python_scripts").mkdir()

        summary = executor.execute_all()

        assert summary["status"] == "error"
        assert "No Python scripts found" in summary["message"]

    def test_get_directory_size(self, executor, temp_project):
        """Test getting directory size."""
        # Create files of known sizes
        (temp_project / "diagrams" / "file1.png").write_bytes(b"x" * 1024)  # 1 KB
        (temp_project / "diagrams" / "file2.png").write_bytes(b"x" * 1024)  # 1 KB

        size = executor._get_directory_size(temp_project / "diagrams")

        assert "KB" in size or "B" in size
        assert float(size.split()[0]) > 0

    def test_get_directory_size_empty(self, executor, temp_project):
        """Test getting size of empty directory."""
        size = executor._get_directory_size(temp_project / "drawio")

        assert size in ["0 B", "0.0 B"]

    def test_get_directory_size_nonexistent(self, executor, temp_project):
        """Test getting size of non-existent directory."""
        size = executor._get_directory_size(temp_project / "nonexistent")

        assert size == "0 B"

    def test_format_summary(self, executor):
        """Test formatting execution summary."""
        summary = {
            "total_scripts": 2,
            "successful": 1,
            "failed": 1,
            "execution_time": 10.5,
            "results": [
                {
                    "script": "test1",
                    "success": True,
                    "files": ["test1.png"],
                    "error": None,
                    "time": 5.0,
                },
                {
                    "script": "test2",
                    "success": False,
                    "files": [],
                    "error": "Error message",
                    "time": 5.5,
                },
            ],
        }

        table = executor.format_summary(summary)

        # Should return a Table object
        assert table is not None
        assert hasattr(table, "add_row")  # Rich Table has add_row method

    def test_get_error_details(self, executor):
        """Test getting error details."""
        # Add some execution results
        executor.execution_results = [
            ExecutionResult(
                script_name="test1",
                success=True,
                output_files=["test1.png"],
            ),
            ExecutionResult(
                script_name="test2",
                success=False,
                output_files=[],
                error_message="ModuleNotFoundError: No module named 'diagrams'",
            ),
            ExecutionResult(
                script_name="test3",
                success=False,
                output_files=[],
                error_message="SyntaxError: invalid syntax",
            ),
        ]

        errors = executor.get_error_details()

        assert len(errors) == 2
        assert errors[0]["script"] == "test2"
        assert errors[0]["error_type"] == "Missing Package"
        assert errors[1]["script"] == "test3"
        assert errors[1]["error_type"] == "Syntax Error"

    def test_parse_error_module_not_found(self, executor):
        """Test parsing ModuleNotFoundError."""
        error = "ModuleNotFoundError: No module named 'diagrams'"

        error_type, fix = executor._parse_error(error)

        assert error_type == "Missing Package"
        assert "pip install diagrams" in fix

    def test_parse_error_graphviz(self, executor):
        """Test parsing Graphviz error."""
        error = "Graphviz executables not found"

        error_type, fix = executor._parse_error(error)

        assert error_type == "Graphviz Error"
        assert "Graphviz" in fix

    def test_parse_error_syntax(self, executor):
        """Test parsing SyntaxError."""
        error = "SyntaxError: invalid syntax at line 10"

        error_type, fix = executor._parse_error(error)

        assert error_type == "Syntax Error"
        assert "Regenerate" in fix or "fix" in fix.lower()

    def test_parse_error_permission(self, executor):
        """Test parsing PermissionError."""
        error = "PermissionError: [Errno 13] Permission denied"

        error_type, fix = executor._parse_error(error)

        assert error_type == "Permission Error"
        assert "permission" in fix.lower()

    def test_parse_error_file_not_found(self, executor):
        """Test parsing FileNotFoundError."""
        error = "FileNotFoundError: [Errno 2] No such file or directory"

        error_type, fix = executor._parse_error(error)

        assert error_type == "File Not Found"
        assert "file" in fix.lower()

    def test_parse_error_unknown(self, executor):
        """Test parsing unknown error."""
        error = "Some unknown error occurred"

        error_type, fix = executor._parse_error(error)

        assert error_type == "Unknown Error"
        assert "Review" in fix or "check" in fix.lower()


@pytest.mark.parametrize(
    "error_message,expected_type",
    [
        ("ModuleNotFoundError: No module named 'diagrams'", "Missing Package"),
        ("Graphviz error", "Graphviz Error"),
        ("SyntaxError: invalid", "Syntax Error"),
        ("PermissionError: denied", "Permission Error"),
        ("FileNotFoundError: not found", "File Not Found"),
        ("Random error", "Unknown Error"),
    ],
)
def test_parse_error_parametrized(executor, error_message, expected_type):
    """Parametrized test for error parsing."""
    error_type, fix = executor._parse_error(error_message)
    assert error_type == expected_type
    assert fix is not None
    assert len(fix) > 0
