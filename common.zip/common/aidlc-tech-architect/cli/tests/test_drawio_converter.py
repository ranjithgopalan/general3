"""Tests for Draw.io converter."""

import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

from aws_arch.core.drawio_converter import (
    AWS_ICON_MAP,
    ConversionResult,
    DrawioConverter,
)


class TestConversionResult:
    """Tests for ConversionResult class."""

    def test_conversion_result_success(self):
        """Test ConversionResult for successful conversion."""
        result = ConversionResult(
            input_file="test.dot",
            output_file="test.drawio.xml",
            success=True,
            node_count=5,
            edge_count=3,
            aws_icon_count=2,
        )

        assert result.input_file == "test.dot"
        assert result.output_file == "test.drawio.xml"
        assert result.success is True
        assert result.node_count == 5
        assert result.edge_count == 3
        assert result.aws_icon_count == 2
        assert result.error is None

    def test_conversion_result_failure(self):
        """Test ConversionResult for failed conversion."""
        result = ConversionResult(
            input_file="test.dot",
            output_file="",
            success=False,
            error="Parse error",
        )

        assert result.success is False
        assert result.error == "Parse error"

    def test_conversion_result_to_dict(self):
        """Test ConversionResult.to_dict() conversion."""
        result = ConversionResult(
            input_file="test.dot",
            output_file="test.drawio.xml",
            success=True,
            node_count=5,
            edge_count=3,
            aws_icon_count=2,
        )

        result_dict = result.to_dict()

        assert result_dict["input_file"] == "test.dot"
        assert result_dict["output_file"] == "test.drawio.xml"
        assert result_dict["success"] is True
        assert result_dict["node_count"] == 5
        assert result_dict["edge_count"] == 3
        assert result_dict["aws_icon_count"] == 2


class TestDrawioConverterHelpers:
    """Tests for DrawioConverter helper methods."""

    def test_sanitize_label(self):
        """Test label sanitization."""
        converter = DrawioConverter()

        assert converter._sanitize_label('"Test Label"') == "Test Label"
        assert converter._sanitize_label('"Line1\\nLine2"') == "Line1\nLine2"
        assert converter._sanitize_label('"Test\\NLabel"') == "TestLabel"
        assert converter._sanitize_label(None) == ""
        assert converter._sanitize_label("") == ""

    def test_parse_pos(self):
        """Test position parsing."""
        converter = DrawioConverter()

        x, y = converter._parse_pos('"100,200"')
        assert x == 100.0
        assert y == 200.0

        x, y = converter._parse_pos('"100.5,200.5!"')
        assert x == 100.5
        assert y == 200.5

        x, y = converter._parse_pos(None)
        assert x is None
        assert y is None

        x, y = converter._parse_pos("invalid")
        assert x is None
        assert y is None

    def test_parse_bb(self):
        """Test bounding box parsing."""
        converter = DrawioConverter()

        bb = converter._parse_bb('"0,0,800,600"')
        assert bb is not None
        assert bb["llx"] == 0.0
        assert bb["lly"] == 0.0
        assert bb["urx"] == 800.0
        assert bb["ury"] == 600.0

        bb = converter._parse_bb(None)
        assert bb is None

        bb = converter._parse_bb("invalid")
        assert bb is None

    def test_parse_color(self):
        """Test color parsing."""
        converter = DrawioConverter()

        assert converter._parse_color('"blue"') == "#0000FF"
        assert converter._parse_color('"green"') == "#00FF00"
        assert converter._parse_color('"red"') == "#FF0000"
        assert converter._parse_color('"#ABCDEF"') == "#ABCDEF"
        assert converter._parse_color(None) == "#333333"
        assert converter._parse_color("invalid") == "#333333"


class TestDrawioConverterAWSIcons:
    """Tests for AWS icon mapping."""

    def test_aws_icon_map_contains_services(self):
        """Test AWS icon map contains expected services."""
        assert "lambda" in AWS_ICON_MAP
        assert "api-gateway" in AWS_ICON_MAP
        assert "dynamodb" in AWS_ICON_MAP
        assert "s3" in AWS_ICON_MAP
        assert "ec2" in AWS_ICON_MAP

    def test_aws_icon_map_aliases(self):
        """Test AWS icon map includes aliases."""
        assert "lambda-function" in AWS_ICON_MAP
        assert "api_gateway" in AWS_ICON_MAP
        assert "simple-storage-service-s3" in AWS_ICON_MAP


class TestDrawioConverterConversion:
    """Tests for DOT to Draw.io conversion."""

    def test_convert_simple_diagram(self, temp_dir):
        """Test conversion of simple diagram."""
        # Use fixture
        dot_file = Path(__file__).parent / "fixtures" / "dot" / "simple_diagram.dot"
        output_file = temp_dir / "simple_diagram.drawio.xml"

        converter = DrawioConverter()
        result = converter.convert_file(str(dot_file), str(output_file))

        assert result.success is True
        assert result.node_count == 2
        assert result.edge_count == 1
        assert Path(output_file).exists()

        # Verify XML structure
        tree = ET.parse(output_file)
        root = tree.getroot()
        assert root.tag == "mxfile"

    def test_convert_aws_diagram(self, temp_dir):
        """Test conversion of AWS diagram with icons."""
        # Use fixture
        dot_file = Path(__file__).parent / "fixtures" / "dot" / "aws_diagram.dot"
        output_file = temp_dir / "aws_diagram.drawio.xml"

        converter = DrawioConverter()
        result = converter.convert_file(str(dot_file), str(output_file))

        assert result.success is True
        assert result.node_count == 3
        assert result.edge_count == 2
        assert result.aws_icon_count == 3  # All 3 nodes are AWS services
        assert Path(output_file).exists()

        # Verify XML structure
        tree = ET.parse(output_file)
        root = tree.getroot()
        assert root.tag == "mxfile"

        # Check for AWS icon styles in cells
        xml_content = Path(output_file).read_text()
        assert "mxgraph.aws" in xml_content

    def test_convert_file_missing(self, temp_dir):
        """Test conversion of non-existent file."""
        converter = DrawioConverter()
        result = converter.convert_file("non_existent.dot", str(temp_dir / "output.xml"))

        assert result.success is False
        assert result.error is not None

    def test_convert_file_auto_output_path(self, temp_dir):
        """Test conversion with automatic output path."""
        # Create temporary DOT file
        dot_file = temp_dir / "test_auto.dot"
        dot_file.write_text(
            'digraph "Test" {\n'
            '  graph [bb="0,0,400,300"];\n'
            '  node1 [label="Node 1" pos="100,150!"];\n'
            "}\n"
        )

        converter = DrawioConverter()
        result = converter.convert_file(str(dot_file))

        assert result.success is True
        # Should create .drawio.xml in same directory
        expected_output = temp_dir / "test_auto.drawio.xml"
        assert Path(result.output_file) == expected_output
        assert expected_output.exists()

    def test_convert_multiple_files(self, temp_dir):
        """Test conversion of multiple files."""
        # Use fixtures
        fixtures_dir = Path(__file__).parent / "fixtures" / "dot"
        dot_files = [
            str(fixtures_dir / "simple_diagram.dot"),
            str(fixtures_dir / "aws_diagram.dot"),
        ]

        converter = DrawioConverter()
        results = converter.convert_files(dot_files, str(temp_dir))

        assert len(results) == 2
        assert all(r.success for r in results)
        assert results[0].node_count == 2
        assert results[1].node_count == 3
        assert results[1].aws_icon_count == 3

        # Check output files
        assert (temp_dir / "simple_diagram.drawio.xml").exists()
        assert (temp_dir / "aws_diagram.drawio.xml").exists()


class TestDrawioConverterXMLStructure:
    """Tests for generated XML structure."""

    def test_xml_has_required_elements(self, temp_dir):
        """Test generated XML has required Draw.io structure."""
        dot_file = Path(__file__).parent / "fixtures" / "dot" / "simple_diagram.dot"
        output_file = temp_dir / "test.drawio.xml"

        converter = DrawioConverter()
        converter.convert_file(str(dot_file), str(output_file))

        tree = ET.parse(output_file)
        root = tree.getroot()

        # Check mxfile structure
        assert root.tag == "mxfile"
        assert "host" in root.attrib
        assert root.attrib["host"] == "app.diagrams.net"

        # Check diagram
        diagram = root.find("diagram")
        assert diagram is not None
        assert "id" in diagram.attrib
        assert "name" in diagram.attrib

        # Check mxGraphModel
        model = diagram.find("mxGraphModel")
        assert model is not None

        # Check root
        model_root = model.find("root")
        assert model_root is not None

        # Check default cells (id 0 and 1)
        cells = list(model_root.findall("mxCell"))
        assert len(cells) >= 2
        assert cells[0].attrib["id"] == "0"
        assert cells[1].attrib["id"] == "1"

    def test_xml_node_attributes(self, temp_dir):
        """Test node cells have correct attributes."""
        dot_file = Path(__file__).parent / "fixtures" / "dot" / "simple_diagram.dot"
        output_file = temp_dir / "test.drawio.xml"

        converter = DrawioConverter()
        converter.convert_file(str(dot_file), str(output_file))

        tree = ET.parse(output_file)
        root = tree.getroot()
        model_root = root.find("diagram/mxGraphModel/root")

        # Find node cells (vertex=1)
        node_cells = [
            cell for cell in model_root.findall("mxCell") if cell.attrib.get("vertex") == "1"
        ]

        assert len(node_cells) == 2

        for cell in node_cells:
            assert "id" in cell.attrib
            assert "value" in cell.attrib
            assert "style" in cell.attrib
            assert "parent" in cell.attrib
            assert cell.attrib["parent"] == "1"

            # Check geometry
            geometry = cell.find("mxGeometry")
            assert geometry is not None
            assert "x" in geometry.attrib
            assert "y" in geometry.attrib
            assert "width" in geometry.attrib
            assert "height" in geometry.attrib

    def test_xml_edge_attributes(self, temp_dir):
        """Test edge cells have correct attributes."""
        dot_file = Path(__file__).parent / "fixtures" / "dot" / "simple_diagram.dot"
        output_file = temp_dir / "test.drawio.xml"

        converter = DrawioConverter()
        converter.convert_file(str(dot_file), str(output_file))

        tree = ET.parse(output_file)
        root = tree.getroot()
        model_root = root.find("diagram/mxGraphModel/root")

        # Find edge cells (edge=1)
        edge_cells = [
            cell for cell in model_root.findall("mxCell") if cell.attrib.get("edge") == "1"
        ]

        assert len(edge_cells) == 1

        for cell in edge_cells:
            assert "id" in cell.attrib
            assert "value" in cell.attrib
            assert "style" in cell.attrib
            assert "parent" in cell.attrib
            assert "source" in cell.attrib
            assert "target" in cell.attrib
            assert cell.attrib["parent"] == "1"

            # Check geometry
            geometry = cell.find("mxGeometry")
            assert geometry is not None
            assert geometry.attrib["relative"] == "1"
