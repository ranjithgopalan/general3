"""Tests for core utility functions."""

import json
from pathlib import Path

import pytest

from aws_arch.core.utils import (
    CLIError,
    OutputStatus,
    ValidationError,
    detect_platform,
    ensure_directory,
    find_files,
    format_file_size,
    format_json_output,
    get_file_size,
    is_linux,
    is_macos,
    is_windows,
    safe_read_file,
    safe_write_file,
    validate_directory_exists,
    validate_file_exists,
)


class TestJSONFormatting:
    """Tests for JSON output formatting."""

    def test_format_json_success(self):
        """Test formatting success JSON output."""
        result = format_json_output(
            OutputStatus.SUCCESS, "Test message", data={"key": "value"}
        )
        parsed = json.loads(result)

        assert parsed["status"] == "success"
        assert parsed["message"] == "Test message"
        assert parsed["data"]["key"] == "value"

    def test_format_json_error_with_errors(self):
        """Test formatting error JSON with error list."""
        result = format_json_output(
            OutputStatus.ERROR, "Operation failed", errors=["Error 1", "Error 2"]
        )
        parsed = json.loads(result)

        assert parsed["status"] == "error"
        assert len(parsed["errors"]) == 2
        assert "Error 1" in parsed["errors"]

    def test_format_json_with_warnings(self):
        """Test formatting JSON with warnings."""
        result = format_json_output(
            OutputStatus.WARNING, "Completed with warnings", warnings=["Warning 1"]
        )
        parsed = json.loads(result)

        assert parsed["status"] == "warning"
        assert len(parsed["warnings"]) == 1


class TestPlatformDetection:
    """Tests for platform detection functions."""

    def test_detect_platform(self):
        """Test platform detection returns expected fields."""
        info = detect_platform()

        assert "system" in info
        assert "version" in info
        assert "machine" in info
        assert "python_version" in info

    def test_platform_checks(self):
        """Test that exactly one platform check returns True."""
        checks = [is_windows(), is_macos(), is_linux()]
        assert sum(checks) == 1, "Exactly one platform should be detected"


class TestFileOperations:
    """Tests for file operation utilities."""

    def test_ensure_directory_creates_dir(self, temp_dir):
        """Test ensure_directory creates directory."""
        new_dir = temp_dir / "test_dir"
        result = ensure_directory(new_dir)

        assert result.exists()
        assert result.is_dir()

    def test_ensure_directory_with_existing(self, temp_dir):
        """Test ensure_directory with existing directory."""
        existing = temp_dir / "existing"
        existing.mkdir()

        result = ensure_directory(existing)
        assert result == existing

    def test_validate_file_exists_success(self, temp_dir):
        """Test validate_file_exists with existing file."""
        test_file = temp_dir / "test.txt"
        test_file.write_text("test")

        result = validate_file_exists(test_file)
        assert result == test_file

    def test_validate_file_exists_missing(self, temp_dir):
        """Test validate_file_exists raises on missing file."""
        missing = temp_dir / "missing.txt"

        with pytest.raises(CLIError):
            validate_file_exists(missing)

    def test_validate_directory_exists_success(self, temp_dir):
        """Test validate_directory_exists with existing dir."""
        result = validate_directory_exists(temp_dir)
        assert result == temp_dir

    def test_validate_directory_exists_missing(self, temp_dir):
        """Test validate_directory_exists raises on missing dir."""
        missing = temp_dir / "missing_dir"

        with pytest.raises(CLIError):
            validate_directory_exists(missing)

    def test_find_files_pattern(self, temp_dir):
        """Test find_files with pattern."""
        # Create test files
        (temp_dir / "file1.yaml").write_text("test")
        (temp_dir / "file2.yaml").write_text("test")
        (temp_dir / "file3.txt").write_text("test")

        results = find_files(temp_dir, "*.yaml")

        assert len(results) == 2
        assert all(f.suffix == ".yaml" for f in results)

    def test_find_files_recursive(self, temp_dir):
        """Test find_files with recursive search."""
        subdir = temp_dir / "subdir"
        subdir.mkdir()

        (temp_dir / "file1.yaml").write_text("test")
        (subdir / "file2.yaml").write_text("test")

        results = find_files(temp_dir, "*.yaml", recursive=True)

        assert len(results) == 2

    def test_get_file_size(self, temp_dir):
        """Test get_file_size returns correct size."""
        test_file = temp_dir / "test.txt"
        content = "test content"
        test_file.write_text(content)

        size = get_file_size(test_file)
        assert size == len(content.encode("utf-8"))

    def test_format_file_size(self):
        """Test format_file_size with various sizes."""
        assert format_file_size(500) == "500.0 B"
        assert format_file_size(1536) == "1.5 KB"
        assert format_file_size(1048576) == "1.0 MB"
        assert format_file_size(1073741824) == "1.0 GB"


class TestSafeFileIO:
    """Tests for safe file I/O operations."""

    def test_safe_read_file(self, temp_dir):
        """Test safe_read_file with valid file."""
        test_file = temp_dir / "test.txt"
        content = "test content"
        test_file.write_text(content)

        result = safe_read_file(test_file)
        assert result == content

    def test_safe_read_file_missing(self, temp_dir):
        """Test safe_read_file raises on missing file."""
        missing = temp_dir / "missing.txt"

        with pytest.raises(CLIError):
            safe_read_file(missing)

    def test_safe_write_file(self, temp_dir):
        """Test safe_write_file creates file."""
        test_file = temp_dir / "output.txt"
        content = "output content"

        result = safe_write_file(test_file, content)

        assert result.exists()
        assert result.read_text() == content

    def test_safe_write_file_no_overwrite(self, temp_dir):
        """Test safe_write_file raises when file exists and overwrite=False."""
        test_file = temp_dir / "existing.txt"
        test_file.write_text("existing")

        with pytest.raises(ValidationError):
            safe_write_file(test_file, "new content", overwrite=False)

    def test_safe_write_file_with_overwrite(self, temp_dir):
        """Test safe_write_file overwrites when overwrite=True."""
        test_file = temp_dir / "existing.txt"
        test_file.write_text("existing")

        safe_write_file(test_file, "new content", overwrite=True)

        assert test_file.read_text() == "new content"

    def test_safe_write_file_creates_parent_dirs(self, temp_dir):
        """Test safe_write_file creates parent directories."""
        nested_file = temp_dir / "sub1" / "sub2" / "file.txt"

        safe_write_file(nested_file, "content")

        assert nested_file.exists()
        assert nested_file.read_text() == "content"


class TestExceptions:
    """Tests for custom exceptions."""

    def test_cli_error(self):
        """Test CLIError exception."""
        with pytest.raises(CLIError) as exc_info:
            raise CLIError("Test error", exit_code=2)

        assert exc_info.value.message == "Test error"
        assert exc_info.value.exit_code == 2

    def test_validation_error_inherits_cli_error(self):
        """Test ValidationError inherits from CLIError."""
        with pytest.raises(CLIError):
            raise ValidationError("Validation failed")
