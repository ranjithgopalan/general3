# Simple REST API

## Overview

A simple REST API built with AWS Lambda and API Gateway.

## Components

The system uses:
- API Gateway for REST endpoints
- Lambda for request processing
- DynamoDB for data storage

## Architecture

External users call the API Gateway which invokes Lambda functions to read and write data to DynamoDB.
