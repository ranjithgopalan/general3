"""Tests for YAML validator."""

from pathlib import Path

import pytest

from aws_arch.core.yaml_validator import (
    ValidationResult,
    YamlValidator,
    VALID_EDGE_COLORS,
    VALID_EDGE_STYLES,
    REQUIRED_TOP_FIELDS,
    REQUIRED_METADATA_FIELDS,
)


class TestValidationResult:
    """Tests for ValidationResult class."""

    def test_validation_result_valid(self):
        """Test ValidationResult with valid result."""
        result = ValidationResult("test.yaml", True)

        assert result.file_path == "test.yaml"
        assert result.is_valid is True
        assert result.has_errors is False
        assert result.has_warnings is False
        assert result.error_count == 0
        assert result.warning_count == 0

    def test_validation_result_with_errors(self):
        """Test ValidationResult with errors."""
        errors = ["Error 1", "Error 2"]
        result = ValidationResult("test.yaml", False, errors=errors)

        assert result.is_valid is False
        assert result.has_errors is True
        assert result.error_count == 2
        assert result.errors == errors

    def test_validation_result_with_warnings(self):
        """Test ValidationResult with warnings."""
        warnings = ["Warning 1", "Warning 2"]
        result = ValidationResult("test.yaml", True, warnings=warnings)

        assert result.is_valid is True
        assert result.has_warnings is True
        assert result.warning_count == 2
        assert result.warnings == warnings

    def test_validation_result_to_dict(self):
        """Test ValidationResult.to_dict() conversion."""
        result = ValidationResult(
            "test.yaml",
            False,
            errors=["Error 1"],
            warnings=["Warning 1"]
        )

        result_dict = result.to_dict()

        assert result_dict["file"] == "test.yaml"
        assert result_dict["valid"] is False
        assert result_dict["error_count"] == 1
        assert result_dict["warning_count"] == 1
        assert "Error 1" in result_dict["errors"]
        assert "Warning 1" in result_dict["warnings"]


class TestYamlValidatorInit:
    """Tests for YamlValidator initialization."""

    def test_validator_loads_default_config(self):
        """Test validator loads default AWS services config."""
        validator = YamlValidator()

        # Should have loaded AWS services
        assert len(validator.valid_services) > 0

        # Should include common services
        assert "lambda" in validator.valid_services
        assert "api-gateway" in validator.valid_services
        assert "dynamodb" in validator.valid_services

    def test_validator_with_custom_config(self):
        """Test validator with custom AWS services config."""
        custom_config = {
            "services": {
                "service1": {"name": "Service 1", "aliases": ["s1"]},
                "service2": {"name": "Service 2", "aliases": []},
            }
        }

        validator = YamlValidator(aws_services_config=custom_config)

        assert "service1" in validator.valid_services
        assert "service2" in validator.valid_services
        assert "s1" in validator.valid_services  # Alias
        assert len(validator.valid_services) == 3  # 2 services + 1 alias


class TestYamlValidatorSyntax:
    """Tests for YAML syntax validation."""

    def test_validate_valid_yaml(self):
        """Test validation of valid YAML file."""
        fixture_path = Path(__file__).parent / "fixtures" / "yaml" / "valid_c4_context.yaml"

        validator = YamlValidator()
        result = validator.validate_file(str(fixture_path))

        # Should be valid (may have warnings about service kinds)
        if result.has_errors:
            print(f"Unexpected errors: {result.errors}")

        assert not result.has_errors

    def test_validate_invalid_syntax(self):
        """Test validation of YAML with syntax errors."""
        fixture_path = Path(__file__).parent / "fixtures" / "yaml" / "invalid_syntax.yaml"

        validator = YamlValidator()
        result = validator.validate_file(str(fixture_path))

        assert result.is_valid is False
        assert result.has_errors is True
        assert any("syntax" in err.lower() for err in result.errors)

    def test_validate_missing_file(self):
        """Test validation of non-existent file."""
        validator = YamlValidator()
        result = validator.validate_file("non_existent_file.yaml")

        assert result.is_valid is False
        assert result.has_errors is True
        assert any("not found" in err.lower() for err in result.errors)


class TestYamlValidatorStructure:
    """Tests for structure validation."""

    def test_validate_missing_top_level_fields(self):
        """Test validation catches missing top-level fields."""
        fixture_path = Path(__file__).parent / "fixtures" / "yaml" / "missing_fields.yaml"

        validator = YamlValidator()
        result = validator.validate_file(str(fixture_path))

        assert result.has_errors is True

        # Check for missing metadata fields
        error_messages = " ".join(result.errors)
        assert "description" in error_messages or "version" in error_messages


class TestYamlValidatorNodes:
    """Tests for node validation."""

    def test_validate_invalid_service_kind(self):
        """Test validation catches invalid AWS service kinds."""
        fixture_path = Path(__file__).parent / "fixtures" / "yaml" / "invalid_service.yaml"

        validator = YamlValidator()
        result = validator.validate_file(str(fixture_path))

        # Should have warnings about unknown service
        assert result.has_warnings is True
        warning_messages = " ".join(result.warnings)
        assert "fake-service-123" in warning_messages.lower() or "unknown service" in warning_messages.lower()

    def test_validate_missing_node_fields(self):
        """Test validation catches missing node fields."""
        fixture_path = Path(__file__).parent / "fixtures" / "yaml" / "missing_fields.yaml"

        validator = YamlValidator()
        result = validator.validate_file(str(fixture_path))

        assert result.has_errors is True

        # Should have errors about missing id and kind
        error_messages = " ".join(result.errors)
        assert "id" in error_messages.lower()


class TestYamlValidatorEdges:
    """Tests for edge validation."""

    def test_validate_invalid_edge_references(self):
        """Test validation catches edges referencing non-existent nodes."""
        fixture_path = Path(__file__).parent / "fixtures" / "yaml" / "invalid_edge_ref.yaml"

        validator = YamlValidator()
        result = validator.validate_file(str(fixture_path))

        assert result.has_errors is True

        # Should have errors about non-existent nodes
        error_messages = " ".join(result.errors)
        assert "does not exist" in error_messages.lower() or "node_does_not_exist" in error_messages

    def test_validate_missing_edge_fields(self):
        """Test validation catches missing edge fields."""
        fixture_path = Path(__file__).parent / "fixtures" / "yaml" / "missing_fields.yaml"

        validator = YamlValidator()
        result = validator.validate_file(str(fixture_path))

        assert result.has_errors is True

        # Should have errors about missing from/to
        error_messages = " ".join(result.errors)
        assert "from" in error_messages.lower() or "to" in error_messages.lower()


class TestYamlValidatorMultipleFiles:
    """Tests for validating multiple files."""

    def test_validate_multiple_files(self):
        """Test validation of multiple YAML files."""
        fixtures_dir = Path(__file__).parent / "fixtures" / "yaml"

        file_paths = [
            str(fixtures_dir / "valid_c4_context.yaml"),
            str(fixtures_dir / "invalid_service.yaml"),
        ]

        validator = YamlValidator()
        results = validator.validate_files(file_paths)

        assert len(results) == 2
        assert all(isinstance(r, ValidationResult) for r in results)


class TestYamlValidatorStrictMode:
    """Tests for strict mode validation."""

    def test_strict_mode_treats_warnings_as_errors(self):
        """Test strict mode converts warnings to errors."""
        fixture_path = Path(__file__).parent / "fixtures" / "yaml" / "invalid_service.yaml"

        validator = YamlValidator()

        # Normal mode - should have warnings
        normal_result = validator.validate_file(str(fixture_path), strict=False)

        # Strict mode - warnings become errors
        strict_result = validator.validate_file(str(fixture_path), strict=True)

        # In strict mode, should fail validation
        assert strict_result.is_valid is False
        # Should have more errors in strict mode (warnings converted)
        assert strict_result.error_count >= normal_result.error_count


class TestYamlValidatorHelpers:
    """Tests for helper methods."""

    def test_find_similar_service(self):
        """Test finding similar service names."""
        validator = YamlValidator()

        # Test exact match (case insensitive)
        similar = validator._find_similar_service("Lambda")
        assert similar is not None
        assert similar.lower() == "lambda"

        # Test contains match
        similar = validator._find_similar_service("gateway")
        assert similar is not None
        assert "gateway" in similar.lower()

    def test_find_similar_service_no_match(self):
        """Test finding similar service with no match."""
        validator = YamlValidator()

        similar = validator._find_similar_service("completely_nonexistent_service_xyz_123")
        # May return None or a weak match
        # Just ensure it doesn't crash


class TestYamlValidatorConstants:
    """Tests for validation constants."""

    def test_valid_edge_colors(self):
        """Test VALID_EDGE_COLORS contains expected colors."""
        assert "blue" in VALID_EDGE_COLORS
        assert "green" in VALID_EDGE_COLORS
        assert "red" in VALID_EDGE_COLORS

    def test_valid_edge_styles(self):
        """Test VALID_EDGE_STYLES contains expected styles."""
        assert "solid" in VALID_EDGE_STYLES
        assert "dashed" in VALID_EDGE_STYLES
        assert "dotted" in VALID_EDGE_STYLES

    def test_required_fields(self):
        """Test required field constants."""
        assert "system" in REQUIRED_TOP_FIELDS
        assert "metadata" in REQUIRED_TOP_FIELDS
        assert "edges" in REQUIRED_TOP_FIELDS

        assert "description" in REQUIRED_METADATA_FIELDS
        assert "version" in REQUIRED_METADATA_FIELDS
        assert "diagram_type" in REQUIRED_METADATA_FIELDS
