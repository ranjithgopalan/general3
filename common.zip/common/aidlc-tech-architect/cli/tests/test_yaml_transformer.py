"""Tests for YAML transformer (cluster-based to node-based format conversion)."""

import pytest
from pathlib import Path

from aws_arch.core.yaml_transformer import (
    sanitize_cluster_id,
    is_cluster_based_format,
    transform_cluster_format_to_nodes,
    validate_cluster_format,
)


class TestSanitizeClusterId:
    """Tests for cluster ID sanitization."""

    def test_simple_name(self):
        """Test sanitizing simple cluster name."""
        assert sanitize_cluster_id("External Systems") == "external_systems"

    def test_lowercase_conversion(self):
        """Test conversion to lowercase."""
        assert sanitize_cluster_id("EXTERNAL SYSTEMS") == "external_systems"

    def test_hyphenated_name(self):
        """Test handling hyphenated names."""
        assert sanitize_cluster_id("External-Systems") == "external_systems"

    def test_dotted_name(self):
        """Test handling names with dots."""
        assert sanitize_cluster_id("AWS.Services") == "aws_services"

    def test_special_characters_removed(self):
        """Test removal of special characters."""
        # Special chars are removed first, so no underscores are inserted
        assert sanitize_cluster_id("Data!@#$Layer") == "datalayer"

    def test_leading_digit_prefixed(self):
        """Test that leading digits are prefixed with underscore."""
        assert sanitize_cluster_id("3rd Party") == "_3rd_party"

    def test_empty_string(self):
        """Test handling of empty string."""
        assert sanitize_cluster_id("") == "cluster"

    def test_only_special_chars(self):
        """Test string with only special characters."""
        assert sanitize_cluster_id("!@#$%") == "cluster"

    def test_spaces_converted_to_underscores(self):
        """Test space to underscore conversion."""
        assert sanitize_cluster_id("Policy Services") == "policy_services"


class TestClusterFormatDetection:
    """Tests for cluster-based format detection."""

    def test_cluster_format_detected(self):
        """Test detection of cluster-based format."""
        spec = {
            'clusters': [
                {
                    'name': 'External',
                    'components': [
                        {'id': 'test', 'kind': 'client', 'label': 'Test'}
                    ]
                }
            ]
        }
        assert is_cluster_based_format(spec) is True

    def test_node_format_detected(self):
        """Test detection of node-based format."""
        spec = {
            'nodes': [
                {'id': 'test', 'kind': 'client', 'label': 'Test'}
            ]
        }
        assert is_cluster_based_format(spec) is False

    def test_no_format_detected(self):
        """Test when neither format present."""
        spec = {'edges': []}
        assert is_cluster_based_format(spec) is False

    def test_clusters_without_components(self):
        """Test clusters array without components."""
        spec = {
            'clusters': [
                {'id': 'test', 'label': 'Test'}
            ]
        }
        assert is_cluster_based_format(spec) is False

    def test_both_formats_present(self):
        """Test when both formats present (invalid)."""
        spec = {
            'nodes': [{'id': 'n1', 'kind': 'lambda', 'label': 'N1'}],
            'clusters': [
                {
                    'name': 'External',
                    'components': [
                        {'id': 'c1', 'kind': 'client', 'label': 'C1'}
                    ]
                }
            ]
        }
        # is_cluster_based_format returns False when both formats present
        # (we don't support mixed formats - must be one or the other)
        assert is_cluster_based_format(spec) is False

    def test_clusters_not_list(self):
        """Test when clusters is not a list."""
        spec = {
            'clusters': 'not a list'
        }
        assert is_cluster_based_format(spec) is False


class TestTransformClusterFormatToNodes:
    """Tests for cluster format transformation."""

    def test_simple_cluster_transformation(self):
        """Test transformation of simple single cluster."""
        spec = {
            'system': 'Test System',
            'metadata': {'description': 'Test', 'version': '1.0', 'diagram_type': 'c4'},
            'clusters': [
                {
                    'name': 'External Systems',
                    'components': [
                        {'id': 'client', 'kind': 'generic', 'label': 'Client', 'description': 'A client'}
                    ]
                }
            ],
            'edges': []
        }

        result = transform_cluster_format_to_nodes(spec)

        # Check structure
        assert 'nodes' in result
        assert 'clusters' in result
        assert len(result['nodes']) == 1
        assert len(result['clusters']) == 1

        # Check transformed node
        node = result['nodes'][0]
        assert node['id'] == 'client'
        assert node['label'] == 'Client'
        assert node['kind'] == 'generic'
        assert node['cluster'] == 'external_systems'
        assert node['description'] == 'A client'

        # Check transformed cluster
        cluster = result['clusters'][0]
        assert cluster['id'] == 'external_systems'
        assert cluster['label'] == 'External Systems'

    def test_multiple_clusters_transformation(self):
        """Test transformation with multiple clusters."""
        spec = {
            'system': 'Multi System',
            'metadata': {'description': 'Test', 'version': '1.0', 'diagram_type': 'c4'},
            'clusters': [
                {
                    'name': 'External',
                    'components': [
                        {'id': 'client1', 'kind': 'client', 'label': 'Client 1'}
                    ]
                },
                {
                    'name': 'Internal Services',
                    'components': [
                        {'id': 'api1', 'kind': 'api-gateway', 'label': 'API 1'},
                        {'id': 'lambda1', 'kind': 'lambda', 'label': 'Lambda 1'}
                    ]
                }
            ],
            'edges': []
        }

        result = transform_cluster_format_to_nodes(spec)

        # Check structure
        assert len(result['nodes']) == 3
        assert len(result['clusters']) == 2

        # Check node cluster assignments
        node_ids_by_cluster = {}
        for node in result['nodes']:
            cluster_id = node['cluster']
            if cluster_id not in node_ids_by_cluster:
                node_ids_by_cluster[cluster_id] = []
            node_ids_by_cluster[cluster_id].append(node['id'])

        assert 'external' in node_ids_by_cluster
        assert 'internal_services' in node_ids_by_cluster
        assert node_ids_by_cluster['external'] == ['client1']
        assert set(node_ids_by_cluster['internal_services']) == {'api1', 'lambda1'}

    def test_edge_preservation(self):
        """Test that edges are preserved during transformation."""
        spec = {
            'system': 'Test System',
            'metadata': {'description': 'Test', 'version': '1.0', 'diagram_type': 'c4'},
            'clusters': [
                {
                    'name': 'External',
                    'components': [
                        {'id': 'client', 'kind': 'client', 'label': 'Client'}
                    ]
                },
                {
                    'name': 'Internal',
                    'components': [
                        {'id': 'api', 'kind': 'api-gateway', 'label': 'API'}
                    ]
                }
            ],
            'edges': [
                {'from': 'client', 'to': 'api', 'label': 'HTTP', 'color': 'blue'}
            ]
        }

        result = transform_cluster_format_to_nodes(spec)

        # Check edge preserved
        assert len(result['edges']) == 1
        edge = result['edges'][0]
        assert edge['from'] == 'client'
        assert edge['to'] == 'api'
        assert edge['label'] == 'HTTP'
        assert edge['color'] == 'blue'

    def test_optional_fields_preserved(self):
        """Test that optional fields are preserved."""
        spec = {
            'system': 'Test System',
            'metadata': {'description': 'Test', 'version': '1.0', 'diagram_type': 'c4'},
            'clusters': [
                {
                    'name': 'Services',
                    'components': [
                        {
                            'id': 'lambda1',
                            'kind': 'lambda',
                            'label': 'Lambda 1',
                            'description': 'My Lambda'
                        }
                    ]
                }
            ],
            'edges': [],
            'output': {'graph_attr': {'fontsize': '14'}}
        }

        result = transform_cluster_format_to_nodes(spec)

        # Check optional fields preserved
        assert result.get('output') == {'graph_attr': {'fontsize': '14'}}
        assert result['nodes'][0].get('description') == 'My Lambda'

    def test_error_on_invalid_format(self):
        """Test error when not cluster-based format."""
        spec = {
            'system': 'Test',
            'metadata': {'description': 'Test', 'version': '1.0', 'diagram_type': 'c4'},
            'nodes': [
                {'id': 'test', 'kind': 'lambda', 'label': 'Test'}
            ],
            'edges': []
        }

        with pytest.raises(ValueError, match="not in cluster-based format"):
            transform_cluster_format_to_nodes(spec)

    def test_error_on_missing_cluster_name(self):
        """Test error when cluster missing name."""
        spec = {
            'system': 'Test',
            'metadata': {'description': 'Test', 'version': '1.0', 'diagram_type': 'c4'},
            'clusters': [
                {
                    'components': [
                        {'id': 'test', 'kind': 'lambda', 'label': 'Test'}
                    ]
                }
            ],
            'edges': []
        }

        with pytest.raises(ValueError, match="missing required field 'name'"):
            transform_cluster_format_to_nodes(spec)

    def test_error_on_missing_component_id(self):
        """Test error when component missing ID."""
        spec = {
            'system': 'Test',
            'metadata': {'description': 'Test', 'version': '1.0', 'diagram_type': 'c4'},
            'clusters': [
                {
                    'name': 'Services',
                    'components': [
                        {'kind': 'lambda', 'label': 'Test'}
                    ]
                }
            ],
            'edges': []
        }

        with pytest.raises(ValueError, match="missing required field 'id'"):
            transform_cluster_format_to_nodes(spec)

    def test_error_on_duplicate_component_ids(self):
        """Test error when duplicate component IDs across clusters."""
        spec = {
            'system': 'Test',
            'metadata': {'description': 'Test', 'version': '1.0', 'diagram_type': 'c4'},
            'clusters': [
                {
                    'name': 'Services1',
                    'components': [
                        {'id': 'lambda1', 'kind': 'lambda', 'label': 'L1'}
                    ]
                },
                {
                    'name': 'Services2',
                    'components': [
                        {'id': 'lambda1', 'kind': 'lambda', 'label': 'L2'}
                    ]
                }
            ],
            'edges': []
        }

        with pytest.raises(ValueError, match="Duplicate component ID 'lambda1'"):
            transform_cluster_format_to_nodes(spec)

    def test_error_on_invalid_edge_reference(self):
        """Test error when edge references non-existent node."""
        spec = {
            'system': 'Test',
            'metadata': {'description': 'Test', 'version': '1.0', 'diagram_type': 'c4'},
            'clusters': [
                {
                    'name': 'Services',
                    'components': [
                        {'id': 'lambda1', 'kind': 'lambda', 'label': 'L1'}
                    ]
                }
            ],
            'edges': [
                {'from': 'lambda1', 'to': 'nonexistent', 'label': 'Edge'}
            ]
        }

        with pytest.raises(ValueError, match="Target node 'nonexistent' not found"):
            transform_cluster_format_to_nodes(spec)


class TestValidateClusterFormat:
    """Tests for cluster format validation without transformation."""

    def test_valid_cluster_format(self):
        """Test validation of valid cluster format."""
        spec = {
            'clusters': [
                {
                    'name': 'Services',
                    'components': [
                        {'id': 'lambda1', 'kind': 'lambda', 'label': 'Lambda 1', 'description': 'Test'}
                    ]
                }
            ],
            'edges': []
        }

        errors, warnings = validate_cluster_format(spec)

        assert len(errors) == 0
        assert len(warnings) == 0

    def test_warning_on_missing_description(self):
        """Test warning when component missing description."""
        spec = {
            'clusters': [
                {
                    'name': 'Services',
                    'components': [
                        {'id': 'lambda1', 'kind': 'lambda', 'label': 'Lambda 1'}
                    ]
                }
            ],
            'edges': []
        }

        errors, warnings = validate_cluster_format(spec)

        assert len(errors) == 0
        assert len(warnings) == 1
        assert 'description' in warnings[0]

    def test_error_on_missing_required_fields(self):
        """Test errors for missing required fields."""
        spec = {
            'clusters': [
                {
                    'name': 'Services',
                    'components': [
                        {'id': 'lambda1', 'label': 'Lambda 1'}  # Missing 'kind'
                    ]
                }
            ],
            'edges': []
        }

        errors, warnings = validate_cluster_format(spec)

        assert len(errors) >= 1
        assert any('kind' in e for e in errors)

    def test_error_on_invalid_edge_reference(self):
        """Test error when edge references invalid node."""
        spec = {
            'clusters': [
                {
                    'name': 'Services',
                    'components': [
                        {'id': 'lambda1', 'kind': 'lambda', 'label': 'Lambda 1', 'description': 'Test'}
                    ]
                }
            ],
            'edges': [
                {'from': 'lambda1', 'to': 'nonexistent', 'label': 'Edge'}
            ]
        }

        errors, warnings = validate_cluster_format(spec)

        assert len(errors) >= 1
        assert any('nonexistent' in e for e in errors)


class TestTransformationRoundtrip:
    """Tests for realistic transformation scenarios."""

    def test_yaml_from_tdd_style_transformation(self):
        """Test transformation of yaml-from-tdd generated YAML."""
        spec = {
            'metadata': {
                'title': 'RI Policy Snapshot Service',
                'description': 'Reinsurance hierarchy retrieval',
                'audience': 'Architects',
                'diagram_type': 'C4 Context',
                'version': '1.0'
            },
            'system': 'RI Policy Snapshot Service',
            'clusters': [
                {
                    'name': 'External Systems',
                    'components': [
                        {
                            'id': 'oneclaim',
                            'kind': 'client',
                            'label': 'OneClaim',
                            'description': 'Claims Management System'
                        },
                        {
                            'id': 'oauth_server',
                            'kind': 'generic',
                            'label': 'OAuth2 Server',
                            'description': 'Token Generation'
                        }
                    ]
                },
                {
                    'name': 'AWS Services',
                    'components': [
                        {
                            'id': 'api_gateway',
                            'kind': 'api-gateway',
                            'label': 'API Gateway',
                            'description': 'REST API Entry Point'
                        },
                        {
                            'id': 'ri_policy_lambda',
                            'kind': 'lambda',
                            'label': 'RI Policy Snapshot Lambda',
                            'description': '1024MB | 30s'
                        }
                    ]
                }
            ],
            'edges': [
                {
                    'from': 'oneclaim',
                    'to': 'api_gateway',
                    'label': 'HTTPS requests',
                    'color': 'blue'
                },
                {
                    'from': 'api_gateway',
                    'to': 'ri_policy_lambda',
                    'label': 'Invokes',
                    'color': 'green'
                }
            ]
        }

        result = transform_cluster_format_to_nodes(spec)

        # Verify transformation
        assert 'nodes' in result
        assert 'clusters' in result
        assert len(result['nodes']) == 4
        assert len(result['clusters']) == 2
        assert len(result['edges']) == 2

        # Verify all nodes have cluster references
        for node in result['nodes']:
            assert 'cluster' in node
            assert node['cluster'] in ['external_systems', 'aws_services']

        # Verify edges are intact
        assert result['edges'][0]['from'] == 'oneclaim'
        assert result['edges'][0]['to'] == 'api_gateway'
        assert result['edges'][1]['from'] == 'api_gateway'
        assert result['edges'][1]['to'] == 'ri_policy_lambda'
