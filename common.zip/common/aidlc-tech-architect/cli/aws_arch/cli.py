"""Main CLI application using Typer.

This module defines the main Typer application and registers all command groups.
"""

import typer
from rich.console import Console
from typing import Optional

from aws_arch import __version__

# Initialize console for rich output
console = Console()

# Create main Typer app
app = typer.Typer(
    name="aws-arch",
    help="AWS Architecture Diagram Generator - Generate professional AWS diagrams from TDDs",
    add_completion=True,
    rich_markup_mode="rich",
    no_args_is_help=True,
)


def version_callback(show_version: bool):
    """Show version and exit."""
    if show_version:
        console.print(f"[bold cyan]aws-arch[/bold cyan] version [green]{__version__}[/green]")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
):
    """
    AWS Architecture Diagram Generator CLI.

    Generate professional AWS architecture diagrams from Technical Design Documents
    using the mingrammer/diagrams library with official AWS icons.

    [bold]Quick Start:[/bold]

        1. Create a project:    [cyan]aws-arch project create my-project[/cyan]
        2. Add your TDD:        Place in my-project/requirements/
        3. Generate diagrams:   [cyan]aws-arch workflow run my-project[/cyan]

    [bold]Command Groups:[/bold]

        • project    - Project management (create, list, info)
        • yaml       - YAML operations (validate, list-services)
        • python     - Python script generation
        • diagram    - Diagram execution
        • drawio     - Draw.io conversion
        • validate   - Validation operations
        • workflow   - Complete workflows
        • services   - AWS service information

    Use [cyan]aws-arch COMMAND --help[/cyan] for more information on a command.
    """
    pass


# Register command groups
from aws_arch.commands import drawio_cmd, yaml_cmd, python_cmd, project_cmd, diagram_cmd

app.add_typer(project_cmd.app, name="project", help="Project management operations")
app.add_typer(yaml_cmd.app, name="yaml", help="YAML specification operations")
app.add_typer(python_cmd.app, name="python", help="Python script generation")
app.add_typer(diagram_cmd.app, name="diagram", help="Diagram execution operations")
app.add_typer(drawio_cmd.app, name="drawio", help="Draw.io conversion operations")


if __name__ == "__main__":
    app()
