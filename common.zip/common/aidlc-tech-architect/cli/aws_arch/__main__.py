"""Entry point for the aws-arch CLI when run as a module.

This allows the CLI to be invoked as:
    python -m aws_arch
"""

from aws_arch.cli import app

if __name__ == "__main__":
    app()
