"""YAML command group for AWS Architecture CLI.

Commands for YAML specification operations:
- validate: Validate YAML specification files
- generate: Generate YAML specs from TDD (Phase 2)
"""

from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.table import Table

from aws_arch.core.utils import (
    OutputStatus,
    find_files,
    print_error,
    print_json_output,
    print_success,
    print_warning,
)
from aws_arch.core.yaml_validator import ValidationResult, YamlValidator

# Create Typer app for YAML commands
app = typer.Typer(help="YAML specification operations")

# Console for rich output
console = Console()


@app.command()
def validate(
    yaml_files: List[Path] = typer.Argument(
        ...,
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        help="YAML files to validate",
    ),
    strict: bool = typer.Option(
        False,
        "--strict",
        help="Treat warnings as errors",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output results as JSON",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed validation results",
    ),
):
    """Validate YAML specification files.

    Validates YAML files for:
    - YAML syntax
    - Required fields and structure
    - AWS service kinds
    - Edge references
    - Cluster definitions

    Examples:
        # Validate single file
        aws-arch yaml validate specs/c4_context.yaml

        # Validate multiple files
        aws-arch yaml validate specs/*.yaml

        # Strict mode (warnings as errors)
        aws-arch yaml validate specs/*.yaml --strict

        # JSON output
        aws-arch yaml validate specs/*.yaml --json
    """
    # Convert paths to strings
    file_paths = [str(f) for f in yaml_files]

    # Create validator
    validator = YamlValidator()

    # Validate all files
    results = validator.validate_files(file_paths, strict=strict)

    # Calculate totals
    total_files = len(results)
    passed_files = sum(1 for r in results if r.is_valid)
    failed_files = total_files - passed_files
    total_errors = sum(r.error_count for r in results)
    total_warnings = sum(r.warning_count for r in results)

    if json_output:
        # JSON output for skill consumption
        print_json_output(
            status=OutputStatus.SUCCESS if failed_files == 0 else OutputStatus.ERROR,
            message=f"Validated {total_files} file(s)",
            data={
                "total_files": total_files,
                "passed": passed_files,
                "failed": failed_files,
                "total_errors": total_errors,
                "total_warnings": total_warnings,
                "results": [r.to_dict() for r in results],
            },
        )
    else:
        # Rich console output
        console.print()
        console.print(
            f"[bold]Validating {total_files} YAML file(s)...[/bold]", style="cyan"
        )
        console.print()

        # Display results for each file
        for result in results:
            file_name = Path(result.file_path).name

            if result.is_valid:
                console.print(f"  [green]✓[/green] {file_name} - Valid")
            else:
                console.print(f"  [red]✗[/red] {file_name} - {result.error_count} error(s)")

            # Show detailed errors/warnings if verbose
            if verbose or not result.is_valid:
                if result.errors:
                    console.print(f"    [red]Errors:[/red]")
                    for error in result.errors:
                        console.print(f"      • {error}")

                if result.warnings and verbose:
                    console.print(f"    [yellow]Warnings:[/yellow]")
                    for warning in result.warnings:
                        console.print(f"      • {warning}")

        # Summary
        console.print()
        console.print("[bold]Validation Summary:[/bold]")
        console.print(f"  Total files: {total_files}")
        console.print(f"  Passed: [green]{passed_files}[/green]")
        console.print(f"  Failed: [red]{failed_files}[/red]")
        console.print(f"  Total errors: {total_errors}")
        console.print(f"  Total warnings: {total_warnings}")
        console.print()

        if failed_files == 0:
            if total_warnings > 0:
                print_success(
                    f"Validation passed with {total_warnings} warning(s)"
                )
            else:
                print_success("All files validated successfully!")
        else:
            print_error(f"Validation failed for {failed_files} file(s)")

    # Exit with appropriate code
    raise typer.Exit(0 if failed_files == 0 else 1)


@app.command(name="list-services")
def list_services(
    category: Optional[str] = typer.Option(
        None,
        "--category",
        "-c",
        help="Filter by category (compute, database, network, etc.)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON",
    ),
):
    """List all valid AWS service kinds for YAML specifications.

    Shows all AWS services that can be used in the 'kind' field of nodes.

    Examples:
        # List all services
        aws-arch yaml list-services

        # List by category
        aws-arch yaml list-services --category compute

        # JSON output
        aws-arch yaml list-services --json
    """
    # Load AWS services config
    validator = YamlValidator()

    # Get services from config file
    config_path = Path(__file__).parent.parent / "config" / "aws_services.json"
    import json

    from aws_arch.core.utils import safe_read_file

    config = json.loads(safe_read_file(config_path))
    services = config.get("services", {})
    categories = config.get("categories", {})

    # Filter by category if specified
    if category:
        services = {
            k: v for k, v in services.items() if v.get("category") == category.lower()
        }

    if json_output:
        print_json_output(
            status=OutputStatus.SUCCESS,
            message=f"Found {len(services)} service(s)",
            data={"services": services, "categories": categories},
        )
    else:
        # Display as table
        table = Table(title="AWS Services for YAML Specifications", show_header=True)
        table.add_column("Service Kind", style="cyan")
        table.add_column("Name", style="green")
        table.add_column("Category", style="yellow")
        table.add_column("Description")

        for service_id, service_info in sorted(services.items()):
            table.add_row(
                service_id,
                service_info.get("name", ""),
                service_info.get("category", ""),
                service_info.get("description", ""),
            )

        console.print()
        console.print(table)
        console.print()

        if category:
            console.print(f"Showing services in category: [yellow]{category}[/yellow]")
        else:
            console.print(f"Total services: [cyan]{len(services)}[/cyan]")
            console.print(
                "\nTip: Use [cyan]--category[/cyan] to filter by category "
                f"({', '.join(categories.keys())})"
            )
        console.print()


