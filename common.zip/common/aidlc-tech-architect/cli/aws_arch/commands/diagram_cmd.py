"""Diagram execution commands for AWS architecture projects.

This module provides Typer commands for executing diagram generation scripts.
"""

import json
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from aws_arch.core.diagram_executor import DiagramExecutor

app = typer.Typer(help="Diagram execution commands")
console = Console()


@app.command()
def check(
    project: Path = typer.Argument(..., help="Project directory path"),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output result as JSON",
    ),
):
    """Check prerequisites for diagram generation.

    Verifies that Graphviz and Python are properly installed
    and configured for diagram generation.

    Example:
        aws-arch diagram check my-project
    """
    executor = DiagramExecutor(project_path=project)

    # Check Python version
    python_ok, python_version = executor.check_python_version()

    # Check Graphviz
    graphviz_info = executor.check_graphviz()

    # Output results
    if json_output:
        result = {
            "status": "success" if (python_ok and graphviz_info.installed) else "error",
            "python": {
                "version": python_version,
                "compatible": python_ok,
            },
            "graphviz": {
                "installed": graphviz_info.installed,
                "version": graphviz_info.version,
                "path": graphviz_info.path,
                "error": graphviz_info.error,
            },
        }
        console.print_json(json.dumps(result))
    else:
        console.print("[bold]Prerequisites Check[/bold]\n")

        # Python check
        if python_ok:
            console.print(f"[green]✓[/green] Python {python_version} (compatible)")
        else:
            console.print(
                f"[red]✗[/red] Python {python_version} (requires 3.8+)")

        # Graphviz check
        if graphviz_info.installed:
            console.print(
                f"[green]✓[/green] Graphviz {graphviz_info.version} installed"
            )
            if graphviz_info.path:
                console.print(f"  [dim]Location: {graphviz_info.path}[/dim]")
        else:
            console.print(
                f"[red]✗[/red] Graphviz not installed"
            )
            console.print(f"  [dim]{graphviz_info.error}[/dim]")
            console.print("\n" + executor.get_installation_instructions())

    sys.exit(0 if (python_ok and graphviz_info.installed) else 1)


@app.command()
def execute(
    project: Path = typer.Argument(..., help="Project directory path"),
    diagram: Optional[str] = typer.Option(
        None,
        "--diagram",
        "-d",
        help="Specific diagram to execute (optional, default: all)",
    ),
    skip_checks: bool = typer.Option(
        False,
        "--skip-checks",
        help="Skip prerequisite checks",
    ),
    skip_venv_setup: bool = typer.Option(
        False,
        "--skip-venv-setup",
        help="Skip virtual environment validation (use system Python)",
    ),
    fallback_on_venv_fail: bool = typer.Option(
        True,
        "--fallback-on-venv-fail/--no-fallback",
        help="Fall back to system Python if venv fails (default: enabled)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output result as JSON",
    ),
):
    """Execute diagram generation scripts.

    Runs Python scripts to generate PNG and DOT diagram files.
    By default, executes all diagrams. Use --diagram to run a specific one.

    Example:
        aws-arch diagram execute my-project
        aws-arch diagram execute my-project --diagram 01_c4_context
    """
    if not project.exists():
        if json_output:
            result = {
                "status": "error",
                "message": f"Project directory not found: {project}",
            }
            console.print_json(json.dumps(result))
        else:
            console.print(
                f"[red]✗[/red] Project directory not found: {project}")
        sys.exit(1)

    executor = DiagramExecutor(project_path=project, use_system_python=skip_venv_setup)

    # Check prerequisites unless skipped
    if not skip_checks:
        # Check Python
        python_ok, python_version = executor.check_python_version()
        if not python_ok:
            if json_output:
                result = {
                    "status": "error",
                    "message": f"Python 3.8+ required, found {python_version}",
                }
                console.print_json(json.dumps(result))
            else:
                console.print(
                    f"[red]✗[/red] Python 3.8+ required, found {python_version}")
            sys.exit(1)

        # Check Graphviz
        graphviz_info = executor.check_graphviz()
        if not graphviz_info.installed:
            if json_output:
                result = {
                    "status": "error",
                    "message": "Graphviz not installed",
                    "graphviz_error": graphviz_info.error,
                }
                console.print_json(json.dumps(result))
            else:
                console.print(
                    "[red]✗[/red] Graphviz is required but not installed")
                console.print(executor.get_installation_instructions())
            sys.exit(1)

        if not json_output:
            console.print(
                f"[green]✓[/green] Prerequisites OK (Python {python_version}, Graphviz {graphviz_info.version})\n"
            )

    # Ensure output directories exist
    executor.ensure_output_directories()

    # Execute diagrams
    if not json_output:
        if diagram:
            console.print(f"[bold]Executing diagram: {diagram}[/bold]\n")
        else:
            console.print("[bold]Executing all diagrams...[/bold]\n")

    summary = executor.execute_all(
        diagram_name=diagram,
        skip_venv_setup=skip_venv_setup,
        fallback_on_venv_fail=fallback_on_venv_fail
    )

    # Output results
    if json_output:
        console.print_json(json.dumps(summary))
    else:
        console.print()  # Blank line

        # Display summary table
        table = executor.format_summary(summary)
        console.print(table)

        # Display statistics
        console.print(f"\n[bold]Statistics:[/bold]")
        console.print(f"  Total scripts: {summary['total_scripts']}")
        console.print(f"  [green]Successful: {summary['successful']}[/green]")
        if summary["failed"] > 0:
            console.print(f"  [red]Failed: {summary['failed']}[/red]")
        console.print(f"  Execution time: {summary['execution_time']:.1f}s")
        console.print(f"\n[bold]Output:[/bold]")
        console.print(f"  PNG files: {summary['png_count']}")
        console.print(f"  DOT files: {summary['dot_count']}")
        console.print(f"  Total size: {summary['total_size']}")

        # Display errors if any
        if summary["failed"] > 0:
            console.print("\n[bold red]Errors:[/bold red]")
            errors = executor.get_error_details()
            for error in errors:
                console.print(f"\n[red]✗[/red] {error['script']}")
                console.print(f"  Type: {error['error_type']}")
                console.print(f"  Fix: {error['fix']}")

        # Display next steps
        if summary["status"] == "success":
            console.print("\n[green]✓[/green] All diagrams generated successfully!")
            console.print("\n[bold]Next steps:[/bold]")
            console.print(
                f"  1. Review diagrams in {executor.diagrams_dir.relative_to(project)}"
            )
            console.print(f"  2. Convert to Draw.io: [cyan]aws-arch drawio convert-all {project.name}[/cyan]")
        elif summary["status"] == "partial":
            console.print(
                "\n[yellow]⚠[/yellow] Some diagrams failed. Review errors above."
            )
        else:
            console.print(
                "\n[red]✗[/red] All diagrams failed. Check errors above."
            )

    sys.exit(0 if summary["status"] in ["success", "partial"] else 1)


@app.command("execute-all")
def execute_all(
    project: Path = typer.Argument(..., help="Project directory path"),
    skip_checks: bool = typer.Option(
        False,
        "--skip-checks",
        help="Skip prerequisite checks",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output result as JSON",
    ),
):
    """Execute all diagram generation scripts in project.

    Convenience command that executes all diagrams at once.
    Equivalent to: aws-arch diagram execute <project>

    Example:
        aws-arch diagram execute-all my-project
    """
    # Call execute with no specific diagram
    from typer.testing import CliRunner

    runner = CliRunner()
    result = runner.invoke(
        execute,
        [str(project)],
        catch_exceptions=False,
    )
    sys.exit(result.exit_code)


@app.command()
def preview(
    project: Path = typer.Argument(..., help="Project directory path"),
    diagram: Optional[str] = typer.Option(
        None,
        "--diagram",
        "-d",
        help="Specific diagram to preview (optional, default: all)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output result as JSON",
    ),
):
    """Preview what diagram scripts will be executed (dry run).

    Shows which scripts will be executed without actually running them.

    Example:
        aws-arch diagram preview my-project
        aws-arch diagram preview my-project --diagram 01_c4_context
    """
    if not project.exists():
        if json_output:
            result = {
                "status": "error",
                "message": f"Project directory not found: {project}",
            }
            console.print_json(json.dumps(result))
        else:
            console.print(
                f"[red]✗[/red] Project directory not found: {project}")
        sys.exit(1)

    executor = DiagramExecutor(project_path=project)

    # Find scripts
    scripts = executor.find_python_scripts(diagram_name=diagram)

    if json_output:
        result = {
            "status": "success" if scripts else "error",
            "project": str(project),
            "script_count": len(scripts),
            "scripts": [
                {
                    "name": s.name,
                    "path": str(s),
                }
                for s in scripts
            ],
        }
        console.print_json(json.dumps(result))
    else:
        if not scripts:
            if diagram:
                console.print(
                    f"[yellow]⚠[/yellow] No script found for diagram '{diagram}'"
                )
            else:
                console.print(
                    "[yellow]⚠[/yellow] No Python scripts found in python_scripts/"
                )
            console.print(f"\nSearched in: {executor.python_scripts_dir}")
            sys.exit(1)

        console.print("[bold]Execution Preview[/bold]\n")
        console.print(f"Project: {project.name}")
        console.print(f"Scripts to execute: {len(scripts)}\n")

        table = Table(show_header=True)
        table.add_column("Script", style="cyan")
        table.add_column("Path", style="dim")

        for script in scripts:
            table.add_row(
                script.name,
                str(script.relative_to(project)),
            )

        console.print(table)

        console.print(f"\n[dim]This is a preview. No scripts will be executed.[/dim]")
        console.print(
            f"\nTo execute: [cyan]aws-arch diagram execute {project.name}[/cyan]"
        )

    sys.exit(0 if scripts else 1)


@app.command()
def list_outputs(
    project: Path = typer.Argument(..., help="Project directory path"),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output result as JSON",
    ),
):
    """List generated diagram output files.

    Shows all PNG and DOT files in the diagrams directory.

    Example:
        aws-arch diagram list-outputs my-project
    """
    if not project.exists():
        if json_output:
            result = {
                "status": "error",
                "message": f"Project directory not found: {project}",
            }
            console.print_json(json.dumps(result))
        else:
            console.print(
                f"[red]✗[/red] Project directory not found: {project}")
        sys.exit(1)

    diagrams_dir = project / "diagrams"

    if not diagrams_dir.exists():
        if json_output:
            result = {
                "status": "error",
                "message": "Diagrams directory not found",
            }
            console.print_json(json.dumps(result))
        else:
            console.print(
                "[yellow]⚠[/yellow] Diagrams directory not found",
            )
        sys.exit(1)

    # Find output files
    png_files = sorted(diagrams_dir.glob("*.png"))
    dot_files = sorted(diagrams_dir.glob("*.dot"))

    if json_output:
        result = {
            "status": "success",
            "png_count": len(png_files),
            "dot_count": len(dot_files),
            "files": {
                "png": [
                    {
                        "name": f.name,
                        "size": f.stat().st_size,
                        "path": str(f.relative_to(project)),
                    }
                    for f in png_files
                ],
                "dot": [
                    {
                        "name": f.name,
                        "size": f.stat().st_size,
                        "path": str(f.relative_to(project)),
                    }
                    for f in dot_files
                ],
            },
        }
        console.print_json(json.dumps(result))
    else:
        console.print("[bold]Diagram Output Files[/bold]\n")

        if not png_files and not dot_files:
            console.print("[yellow]⚠[/yellow] No output files found")
            console.print(f"\nSearched in: {diagrams_dir}")
            console.print(
                f"\nGenerate diagrams with: [cyan]aws-arch diagram execute {project.name}[/cyan]"
            )
            sys.exit(1)

        # Display PNG files
        if png_files:
            console.print(f"[bold]PNG Files ({len(png_files)}):[/bold]")
            for f in png_files:
                size_kb = f.stat().st_size / 1024
                console.print(f"  • {f.name} ({size_kb:.1f} KB)")

        # Display DOT files
        if dot_files:
            console.print(f"\n[bold]DOT Files ({len(dot_files)}):[/bold]")
            for f in dot_files:
                size_kb = f.stat().st_size / 1024
                console.print(f"  • {f.name} ({size_kb:.1f} KB)")

        console.print(f"\n[dim]Location: {diagrams_dir.relative_to(project)}[/dim]")


if __name__ == "__main__":
    app()
