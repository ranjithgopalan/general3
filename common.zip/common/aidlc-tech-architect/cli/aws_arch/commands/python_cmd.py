"""
Python Generation Commands

Commands for generating Python diagram scripts from YAML specifications.
"""

import typer
from pathlib import Path
from typing import List, Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box
import json

from ..core.python_generator import PythonGenerator

app = typer.Typer(help="Generate Python diagram scripts from YAML specifications")
console = Console()


@app.command(name="generate")
def generate_python(
    yaml_files: List[Path] = typer.Argument(
        ...,
        help="YAML specification file(s) to process",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True
    ),
    output_dir: Optional[Path] = typer.Option(
        "python_scripts",
        "--output-dir", "-o",
        help="Output directory for Python scripts"
    ),
    batch_scripts: bool = typer.Option(
        True,
        "--batch/--no-batch",
        help="Generate batch execution scripts"
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output results as JSON"
    ),
) -> None:
    """
    Generate Python diagram scripts from YAML specification files.

    Reads YAML specs and creates executable Python scripts using the
    mingrammer/diagrams library with official AWS icons.

    Examples:
        # Generate from single YAML
        aws-arch python generate yaml_specs/01_c4_context.yaml

        # Generate from multiple YAMLs
        aws-arch python generate yaml_specs/*.yaml

        # Specify output directory
        aws-arch python generate yaml_specs/*.yaml --output-dir scripts/

        # Generate without batch scripts
        aws-arch python generate yaml_specs/*.yaml --no-batch
    """
    # Validate arguments
    if not yaml_files:
        console.print("[red]❌ No YAML files provided[/red]")
        console.print("[yellow]Usage:[/yellow]")
        console.print("  aws-arch python generate file1.yaml file2.yaml")
        console.print("  aws-arch python generate-all yaml_specs/")
        raise typer.Exit(code=1)

    # Filter out empty paths
    valid_files = [f for f in yaml_files if f and str(f).strip()]
    if not valid_files:
        console.print("[red]❌ No valid YAML files found[/red]")
        raise typer.Exit(code=1)

    generator = PythonGenerator(output_dir=output_dir)

    # Process each YAML file
    results = []
    for yaml_file in valid_files:
        result = generator.generate_from_yaml_file(yaml_file)
        results.append(result)

    # Generate batch scripts if requested
    batch_win = None
    batch_unix = None
    if batch_scripts and any(r.success for r in results):
        successful_files = [r.python_file for r in results if r.success and r.python_file]
        if successful_files:
            batch_win, batch_unix = generator.generate_batch_scripts(successful_files)

    # Output results
    if json_output:
        _output_json(results, batch_win, batch_unix)
    else:
        _output_rich(results, batch_win, batch_unix, output_dir)

    # Exit with error if any generation failed
    if any(not r.success for r in results):
        raise typer.Exit(code=1)


@app.command(name="generate-all")
def generate_all(
    yaml_dir: Path = typer.Argument(
        ...,
        help="Directory containing YAML specification files",
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True
    ),
    output_dir: Optional[Path] = typer.Option(
        "python_scripts",
        "--output-dir", "-o",
        help="Output directory for Python scripts"
    ),
    batch_scripts: bool = typer.Option(
        True,
        "--batch/--no-batch",
        help="Generate batch execution scripts"
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output results as JSON"
    ),
) -> None:
    """
    Generate Python scripts from all YAML files in a directory.

    Processes all .yaml and .yml files in the specified directory.

    Examples:
        # Generate from all YAMLs in directory
        aws-arch python generate-all yaml_specs/

        # Specify output directory
        aws-arch python generate-all yaml_specs/ --output-dir scripts/
    """
    generator = PythonGenerator(output_dir=output_dir)

    # Check for YAML files
    yaml_files = list(yaml_dir.glob("*.yaml")) + list(yaml_dir.glob("*.yml"))
    if not yaml_files:
        console.print(f"[yellow]⚠ No YAML files found in {yaml_dir}[/yellow]")
        raise typer.Exit(code=1)

    # Process all YAML files
    results = generator.generate_from_directory(yaml_dir)

    # Generate batch scripts if requested
    batch_win = None
    batch_unix = None
    if batch_scripts and any(r.success for r in results):
        successful_files = [r.python_file for r in results if r.success and r.python_file]
        if successful_files:
            batch_win, batch_unix = generator.generate_batch_scripts(successful_files)

    # Output results
    if json_output:
        _output_json(results, batch_win, batch_unix)
    else:
        _output_rich(results, batch_win, batch_unix, output_dir)

    # Exit with error if any generation failed
    if any(not r.success for r in results):
        raise typer.Exit(code=1)


def _output_json(results, batch_win, batch_unix):
    """Output results as JSON."""
    output = {
        "status": "success" if all(r.success for r in results) else "error",
        "total_files": len(results),
        "successful": sum(1 for r in results if r.success),
        "failed": sum(1 for r in results if not r.success),
        "files": []
    }

    for result in results:
        file_info = {
            "yaml_file": str(result.yaml_file),
            "success": result.success,
        }

        if result.success:
            file_info.update({
                "python_file": str(result.python_file),
                "nodes": result.nodes_count,
                "edges": result.edges_count,
                "clusters": result.clusters_count,
                "warnings": result.warnings
            })
        else:
            file_info["error"] = result.error

        output["files"].append(file_info)

    if batch_win or batch_unix:
        output["batch_scripts"] = {
            "windows": str(batch_win) if batch_win else None,
            "unix": str(batch_unix) if batch_unix else None
        }

    console.print_json(data=output)


def _output_rich(results, batch_win, batch_unix, output_dir):
    """Output results using rich formatting."""
    successful = [r for r in results if r.success]
    failed = [r for r in results if not r.success]

    # Create summary table
    table = Table(title="Python Generation Results", box=box.ROUNDED)
    table.add_column("YAML File", style="cyan")
    table.add_column("Status", justify="center")
    table.add_column("Nodes", justify="right")
    table.add_column("Edges", justify="right")
    table.add_column("Clusters", justify="right")

    for result in results:
        if result.success:
            table.add_row(
                result.yaml_file.name,
                "✅ Success",
                str(result.nodes_count),
                str(result.edges_count),
                str(result.clusters_count)
            )
        else:
            table.add_row(
                result.yaml_file.name,
                "❌ Failed",
                "-",
                "-",
                "-"
            )

    console.print()
    console.print(table)
    console.print()

    # Show errors if any
    if failed:
        console.print("[red]❌ Errors:[/red]")
        for result in failed:
            console.print(f"  • {result.yaml_file.name}: {result.error}")
        console.print()

    # Show warnings if any
    all_warnings = []
    for result in successful:
        all_warnings.extend(result.warnings)

    if all_warnings:
        console.print("[yellow]⚠ Warnings:[/yellow]")
        for warning in all_warnings:
            console.print(f"  • {warning}")
        console.print()

    # Show success summary
    if successful:
        summary_text = f"""
✅ Generated {len(successful)} Python script(s)

📁 Output directory: {output_dir}/
📊 Total nodes: {sum(r.nodes_count for r in successful)}
🔗 Total edges: {sum(r.edges_count for r in successful)}
📦 Total clusters: {sum(r.clusters_count for r in successful)}
"""

        if batch_win or batch_unix:
            summary_text += "\n🔧 Batch scripts created:\n"
            if batch_win:
                summary_text += f"   • Windows: {batch_win}\n"
            if batch_unix:
                summary_text += f"   • Unix/Mac: {batch_unix}\n"

        summary_text += """
Next steps:
  1. Review generated Python scripts
  2. Run batch script to generate diagrams:
     • Windows: python_scripts/generate_all.bat
     • Unix/Mac: ./python_scripts/generate_all.sh
  3. Check generated PNG and DOT files
"""

        console.print(Panel(
            summary_text.strip(),
            title="🎉 Generation Complete",
            border_style="green",
            box=box.DOUBLE
        ))
    else:
        console.print(Panel(
            "No Python scripts were generated successfully.",
            title="❌ Generation Failed",
            border_style="red"
        ))


if __name__ == "__main__":
    app()
