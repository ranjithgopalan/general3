"""Draw.io command group for AWS Architecture CLI.

Commands for Draw.io conversion operations:
- convert: Convert single or multiple DOT files to Draw.io XML
- convert-all: Convert all DOT files in a directory
"""

from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.table import Table

from aws_arch.core.drawio_converter import DrawioConverter
from aws_arch.core.utils import (
    OutputStatus,
    find_files,
    print_error,
    print_json_output,
    print_success,
    print_warning,
)

# Create Typer app for Draw.io commands
app = typer.Typer(help="Draw.io conversion operations")

# Console for rich output
console = Console()


@app.command()
def convert(
    dot_files: List[Path] = typer.Argument(
        ...,
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        help="DOT files to convert",
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output-dir",
        "-o",
        help="Output directory for Draw.io files",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output results as JSON",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed conversion results",
    ),
):
    """Convert DOT files to Draw.io XML format.

    Converts Graphviz DOT files to Draw.io XML with native AWS icons.

    Features:
    - Uses pydot for proper DOT parsing
    - Maps AWS services to native Draw.io shapes (mxgraph.aws3/aws4)
    - Preserves edge styling, colors, and labels
    - Handles nested subgraphs (VPC → Subnets → Lambdas)

    Examples:
        # Convert single file
        aws-arch drawio convert diagram.dot

        # Convert multiple files
        aws-arch drawio convert diagrams/*.dot

        # Specify output directory
        aws-arch drawio convert diagrams/*.dot --output-dir drawio/

        # JSON output
        aws-arch drawio convert diagrams/*.dot --json
    """
    # Convert paths to strings
    file_paths = [str(f) for f in dot_files]

    # Prepare output directory
    output_dir_str = str(output_dir) if output_dir else None
    if output_dir_str:
        Path(output_dir_str).mkdir(parents=True, exist_ok=True)

    # Create converter
    converter = DrawioConverter()

    # Convert all files
    results = converter.convert_files(file_paths, output_dir_str)

    # Calculate totals
    total_files = len(results)
    success_count = sum(1 for r in results if r.success)
    failed_count = total_files - success_count
    total_nodes = sum(r.node_count for r in results if r.success)
    total_edges = sum(r.edge_count for r in results if r.success)
    total_aws_icons = sum(r.aws_icon_count for r in results if r.success)

    if json_output:
        # JSON output for skill consumption
        print_json_output(
            status=OutputStatus.SUCCESS if failed_count == 0 else OutputStatus.ERROR,
            message=f"Converted {success_count}/{total_files} file(s)",
            data={
                "total_files": total_files,
                "success": success_count,
                "failed": failed_count,
                "total_nodes": total_nodes,
                "total_edges": total_edges,
                "total_aws_icons": total_aws_icons,
                "results": [r.to_dict() for r in results],
            },
        )
    else:
        # Rich console output
        console.print()
        console.print(
            f"[bold]Converting {total_files} DOT file(s) to Draw.io...[/bold]",
            style="cyan",
        )
        console.print()

        # Display results for each file
        for result in results:
            file_name = Path(result.input_file).name

            if result.success:
                console.print(
                    f"  [green]✓[/green] {file_name} → {Path(result.output_file).name}"
                )
                if verbose:
                    console.print(
                        f"    Nodes: {result.node_count}, "
                        f"Edges: {result.edge_count}, "
                        f"AWS icons: {result.aws_icon_count}"
                    )
            else:
                console.print(f"  [red]✗[/red] {file_name} - Failed")
                if result.error:
                    console.print(f"    Error: {result.error}")

        # Summary
        console.print()
        console.print("[bold]Conversion Summary:[/bold]")
        console.print(f"  Total files: {total_files}")
        console.print(f"  Success: [green]{success_count}[/green]")
        console.print(f"  Failed: [red]{failed_count}[/red]")
        console.print(f"  Total nodes: {total_nodes}")
        console.print(f"  Total edges: {total_edges}")
        console.print(f"  AWS icons: {total_aws_icons}")
        console.print()

        if failed_count == 0:
            print_success("All files converted successfully!")
            console.print()
            console.print("[bold]To view:[/bold]")
            console.print("  1. Open https://app.diagrams.net/")
            console.print("  2. File → Open from → Device")
            console.print("  3. Select .drawio.xml file")
        else:
            print_error(f"Conversion failed for {failed_count} file(s)")

    # Exit with appropriate code
    raise typer.Exit(0 if failed_count == 0 else 1)


@app.command(name="convert-all")
def convert_all(
    project_dir: Path = typer.Argument(
        ...,
        exists=True,
        file_okay=False,
        dir_okay=True,
        readable=True,
        help="Project directory containing diagrams/ folder",
    ),
    diagrams_subdir: str = typer.Option(
        "diagrams",
        "--diagrams-dir",
        help="Subdirectory containing DOT files",
    ),
    output_subdir: str = typer.Option(
        "drawio",
        "--output-dir",
        help="Subdirectory for Draw.io output",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output results as JSON",
    ),
):
    """Convert all DOT files in a project directory.

    Finds all .dot files in the diagrams/ subdirectory and converts them
    to Draw.io XML format in the drawio/ subdirectory.

    Examples:
        # Convert all DOT files in project
        aws-arch drawio convert-all my-project/

        # Custom directories
        aws-arch drawio convert-all my-project/ --diagrams-dir output --output-dir xml

        # JSON output
        aws-arch drawio convert-all my-project/ --json
    """
    # Explicit validation of project directory
    if not project_dir or str(project_dir).strip() == '':
        print_error("Project directory argument is empty")
        console.print("[yellow]Usage:[/yellow]")
        console.print("  aws-arch drawio convert-all /path/to/project")
        console.print("  aws-arch drawio convert-all ./my-project")
        console.print()
        console.print("[yellow]Example:[/yellow]")
        console.print("  cd /path/to && aws-arch drawio convert-all my-project")
        raise typer.Exit(1)

    # Resolve to absolute path
    project_dir = project_dir.resolve()

    if not project_dir.exists():
        print_error(f"Project directory does not exist: {project_dir}")
        console.print(f"[yellow]Received argument:[/yellow] '{project_dir}'")
        raise typer.Exit(1)

    # Find diagrams directory
    diagrams_dir = project_dir / diagrams_subdir
    if not diagrams_dir.exists():
        print_error(f"Diagrams directory not found: {diagrams_dir}")
        raise typer.Exit(1)

    # Find all DOT files
    dot_files = find_files(diagrams_dir, "*.dot", recursive=False)

    if not dot_files:
        print_warning(f"No DOT files found in {diagrams_dir}")
        raise typer.Exit(0)

    # Create output directory
    output_dir = project_dir / output_subdir
    output_dir.mkdir(parents=True, exist_ok=True)

    if not json_output:
        console.print()
        console.print(
            f"[cyan]Found {len(dot_files)} DOT file(s) in {diagrams_dir}[/cyan]"
        )

    # Convert files using the convert command logic
    file_paths = [str(f) for f in dot_files]
    converter = DrawioConverter()
    results = converter.convert_files(file_paths, str(output_dir))

    # Calculate totals
    total_files = len(results)
    success_count = sum(1 for r in results if r.success)
    failed_count = total_files - success_count
    total_nodes = sum(r.node_count for r in results if r.success)
    total_edges = sum(r.edge_count for r in results if r.success)
    total_aws_icons = sum(r.aws_icon_count for r in results if r.success)

    if json_output:
        # JSON output for skill consumption
        print_json_output(
            status=OutputStatus.SUCCESS if failed_count == 0 else OutputStatus.ERROR,
            message=f"Converted {success_count}/{total_files} file(s)",
            data={
                "project_dir": str(project_dir),
                "diagrams_dir": str(diagrams_dir),
                "output_dir": str(output_dir),
                "total_files": total_files,
                "success": success_count,
                "failed": failed_count,
                "total_nodes": total_nodes,
                "total_edges": total_edges,
                "total_aws_icons": total_aws_icons,
                "results": [r.to_dict() for r in results],
            },
        )
    else:
        # Rich console output
        console.print()
        console.print("[bold]Conversion Results:[/bold]")
        console.print()

        # Display results
        for result in results:
            file_name = Path(result.input_file).name
            if result.success:
                console.print(f"  [green]✓[/green] {file_name}")
            else:
                console.print(f"  [red]✗[/red] {file_name}")
                if result.error:
                    console.print(f"    Error: {result.error}")

        # Summary
        console.print()
        console.print("[bold]Summary:[/bold]")
        console.print(f"  Success: [green]{success_count}[/green]/{total_files}")
        console.print(f"  Total nodes: {total_nodes}")
        console.print(f"  Total edges: {total_edges}")
        console.print(f"  AWS icons: {total_aws_icons}")
        console.print()
        console.print(f"[cyan]Output directory: {output_dir}[/cyan]")
        console.print()

        if failed_count == 0:
            print_success("All files converted successfully!")
        else:
            print_error(f"Conversion failed for {failed_count} file(s)")

    # Exit with appropriate code
    raise typer.Exit(0 if failed_count == 0 else 1)
