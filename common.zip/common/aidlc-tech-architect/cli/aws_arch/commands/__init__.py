"""Command modules for AWS Architecture CLI.

This package contains all CLI command groups:
- project: Project management
- tdd: TDD processing
- yaml: YAML operations
- python: Python generation
- diagram: Diagram execution
- drawio: Draw.io conversion
- validate: Validation
- workflow: Complete workflows
- services: AWS service information
"""
