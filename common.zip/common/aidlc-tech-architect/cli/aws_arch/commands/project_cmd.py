"""Project management commands for AWS architecture projects.

This module provides Typer commands for creating and managing projects.
"""

import json
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel

from aws_arch.core.project_manager import ProjectManager

app = typer.Typer(help="Project management commands")
console = Console()


@app.command()
def create(
    name: str = typer.Argument(..., help="Project name"),
    path: Optional[Path] = typer.Option(
        None,
        "--path",
        "-p",
        help="Base directory for project (default: current directory)",
    ),
    template: str = typer.Option(
        "default",
        "--template",
        "-t",
        help="Template to use (default: default)",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Force creation even if project exists",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output result as JSON",
    ),
):
    """Create a new AWS architecture project.

    Creates a complete project structure with all required directories,
    YAML templates, and documentation.

    Example:
        aws-arch project create my-aws-project
        aws-arch project create my-project --path ~/projects
    """
    # Initialize project manager
    manager = ProjectManager(base_path=path)

    # Create project
    success, message, project_path = manager.create_project(
        name=name,
        template=template,
        force=force,
    )

    # Output results
    if json_output:
        result = {
            "status": "success" if success else "error",
            "message": message,
            "project_path": str(project_path) if project_path else None,
        }
        console.print_json(json.dumps(result))
    else:
        if success:
            console.print(f"[green]✓[/green] {message}")
            console.print("\n[bold]Next steps:[/bold]")
            console.print("1. Add your TDD document to requirements/ folder")
            console.print(f"2. Run: [cyan]aws-arch workflow run {name}[/cyan]")
            console.print("3. Review generated diagrams in diagrams/ folder")
        else:
            console.print(f"[red]✗[/red] {message}", file=sys.stderr)
            if project_path and project_path.exists():
                console.print(
                    f"\n[yellow]Project already exists at:[/yellow] {project_path}"
                )
                console.print("\n[bold]Options:[/bold]")
                console.print("  • Use --force to recreate the project")
                console.print("  • Choose a different project name")
                console.print("  • Use the existing project")

    sys.exit(0 if success else 1)


@app.command("list")
def list_projects(
    path: Optional[Path] = typer.Option(
        None,
        "--path",
        "-p",
        help="Directory to search for projects (default: current directory)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output result as JSON",
    ),
):
    """List all AWS architecture projects in directory.

    Scans the specified directory for valid AWS architecture projects
    and displays their status.

    Example:
        aws-arch project list
        aws-arch project list --path ~/projects
    """
    # Initialize project manager
    manager = ProjectManager(base_path=path)

    # List projects
    projects = manager.list_projects()

    # Output results
    if json_output:
        result = {
            "status": "success",
            "count": len(projects),
            "projects": projects,
        }
        console.print_json(json.dumps(result))
    else:
        if not projects:
            console.print("[yellow]No projects found in current directory[/yellow]")
            console.print("\nCreate a new project with:")
            console.print("  [cyan]aws-arch project create <project-name>[/cyan]")
        else:
            table = manager.format_project_list(projects)
            console.print(table)
            console.print(f"\n[dim]Found {len(projects)} project(s)[/dim]")


@app.command()
def info(
    name: str = typer.Argument(..., help="Project name"),
    path: Optional[Path] = typer.Option(
        None,
        "--path",
        "-p",
        help="Base directory for projects (default: current directory)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output result as JSON",
    ),
):
    """Show detailed information about a project.

    Displays project structure, file counts, and status for each folder.

    Example:
        aws-arch project info my-project
        aws-arch project info my-project --json
    """
    # Initialize project manager
    manager = ProjectManager(base_path=path)

    # Get project info
    info = manager.get_project_info(name)

    # Output results
    if json_output:
        if info:
            result = {
                "status": "success",
                "project": info,
            }
        else:
            result = {
                "status": "error",
                "message": f"Project '{name}' not found",
            }
        console.print_json(json.dumps(result))
    else:
        if not info:
            console.print(f"[red]✗[/red] Project '{name}' not found", file=sys.stderr)
            console.print(f"\nSearched in: {manager.base_path}")
            console.print("\nList available projects with:")
            console.print("  [cyan]aws-arch project list[/cyan]")
            sys.exit(1)

        # Display project info
        table = manager.format_project_info(info)
        console.print(table)

        # Display path
        console.print(f"\n[bold]Path:[/bold] {info['path']}")

        # Display validation status
        if info["is_valid"]:
            console.print("[green]✓[/green] Project structure is valid")
        else:
            console.print(
                "[yellow]⚠[/yellow] Project structure is incomplete (missing required folders)"
            )

        # Display summary
        console.print(f"\n[bold]Summary:[/bold]")
        console.print(f"  YAML specs: {info['yaml_count']}")
        console.print(f"  Total files: {info['total_files']}")


@app.command()
def validate(
    name: str = typer.Argument(..., help="Project name"),
    path: Optional[Path] = typer.Option(
        None,
        "--path",
        "-p",
        help="Base directory for projects (default: current directory)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output result as JSON",
    ),
):
    """Validate project structure.

    Checks if project has all required directories and files.

    Example:
        aws-arch project validate my-project
    """
    # Initialize project manager
    manager = ProjectManager(base_path=path)

    # Get project info
    info = manager.get_project_info(name)

    if not info:
        if json_output:
            result = {
                "status": "error",
                "message": f"Project '{name}' not found",
            }
            console.print_json(json.dumps(result))
        else:
            console.print(f"[red]✗[/red] Project '{name}' not found", file=sys.stderr)
        sys.exit(1)

    # Check validation
    is_valid = info["is_valid"]
    missing_folders = [
        folder
        for folder, count in info["folders"].items()
        if count == -1
    ]

    # Output results
    if json_output:
        result = {
            "status": "success" if is_valid else "error",
            "is_valid": is_valid,
            "missing_folders": missing_folders,
            "project": info,
        }
        console.print_json(json.dumps(result))
    else:
        if is_valid:
            console.print(f"[green]✓[/green] Project '{name}' is valid")
            console.print(f"\nAll required folders present:")
            for folder in manager.REQUIRED_FOLDERS:
                count = info["folders"].get(folder, 0)
                console.print(f"  • {folder:20s} ({count} files)")
        else:
            console.print(
                f"[red]✗[/red] Project '{name}' has missing folders", file=sys.stderr
            )
            console.print(f"\nMissing folders:")
            for folder in missing_folders:
                console.print(f"  • {folder}")
            console.print("\nTo fix, create missing folders in:")
            console.print(f"  {info['path']}")

    sys.exit(0 if is_valid else 1)


@app.command("scan")
def scan_directory(
    directory: Optional[Path] = typer.Argument(
        None,
        help="Directory to scan (default: current directory)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output result as JSON",
    ),
):
    """Scan directory for AWS architecture projects.

    Searches for valid project directories in the specified location.
    A valid project must have at least requirements/ and yaml_specs/ folders.

    Example:
        aws-arch project scan
        aws-arch project scan /path/to/workspace
    """
    scan_dir = directory if directory else Path.cwd()

    if not scan_dir.exists():
        if json_output:
            result = {
                "status": "error",
                "message": f"Directory not found: {scan_dir}",
            }
            console.print_json(json.dumps(result))
        else:
            console.print(f"[red]✗[/red] Directory not found: {scan_dir}", file=sys.stderr)
        sys.exit(1)

    manager = ProjectManager(base_path=scan_dir)
    projects = manager.find_projects_in_directory()

    if json_output:
        result = {
            "status": "success",
            "directory": str(scan_dir),
            "project_count": len(projects),
            "projects": projects,
        }
        console.print_json(json.dumps(result))
    else:
        console.print(f"[bold]Scanning: {scan_dir}[/bold]\n")

        if not projects:
            console.print("[yellow]No AWS architecture projects found[/yellow]")
            console.print(f"\nCreate a new project: [cyan]aws-arch project create <name>[/cyan]")
            sys.exit(0)

        console.print(f"[green]Found {len(projects)} project(s):[/green]\n")

        # Create table
        from rich.table import Table
        table = Table(show_header=True)
        table.add_column("Project", style="cyan", no_wrap=True)
        table.add_column("YAMLs", justify="right")
        table.add_column("Scripts", justify="right")
        table.add_column("Diagrams", justify="right")
        table.add_column("Path", style="dim")

        for proj in projects:
            table.add_row(
                proj['name'],
                str(proj['yaml_count']),
                str(proj['script_count']),
                str(proj['diagram_count']),
                proj['path']
            )

        console.print(table)
        console.print(f"\n[dim]Use a project: [cyan]aws-arch diagram execute <project-path>[/cyan][/dim]")

    sys.exit(0)


if __name__ == "__main__":
    app()
