"""AWS Architecture Diagram Generator CLI.

A modern CLI tool for generating professional AWS architecture diagrams
from Technical Design Documents using the mingrammer/diagrams library.
"""

__version__ = "2.0.0"
__author__ = "GATHER Tech Architect"
__email__ = "tech-architect@gather.com"
