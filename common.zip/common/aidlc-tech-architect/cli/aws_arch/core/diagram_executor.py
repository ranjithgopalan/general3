"""Diagram execution engine for AWS architecture diagrams.

This module handles execution of Python diagram generation scripts,
monitors progress, and validates outputs.
"""

import os
import platform
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.panel import Panel
from rich.table import Table

from .venv_manager import VenvManager

console = Console()


@dataclass
class ExecutionResult:
    """Result of diagram script execution."""

    script_name: str
    success: bool
    output_files: List[str]
    error_message: Optional[str] = None
    execution_time: float = 0.0


@dataclass
class GraphvizInfo:
    """Graphviz installation information."""

    installed: bool
    version: Optional[str] = None
    path: Optional[str] = None
    error: Optional[str] = None


class DiagramExecutor:
    """Executes Python diagram generation scripts."""

    def __init__(self, project_path: Path, use_system_python: bool = False):
        """Initialize diagram executor.

        Args:
            project_path: Path to project root directory
            use_system_python: If True, use system Python instead of venv
        """
        self.project_path = Path(project_path)
        self.python_scripts_dir = self.project_path / "python_scripts"
        self.diagrams_dir = self.project_path / "diagrams"
        self.execution_results: List[ExecutionResult] = []
        self.use_system_python = use_system_python
        self.venv_manager = VenvManager() if not use_system_python else None

    def check_graphviz(self) -> GraphvizInfo:
        """Check if Graphviz is installed and get version.

        Returns:
            GraphvizInfo with installation status and version
        """
        try:
            result = subprocess.run(
                ["dot", "-V"],
                capture_output=True,
                text=True,
                timeout=5,
            )

            if result.returncode == 0:
                # Parse version from output (usually in stderr)
                output = result.stderr + result.stdout
                version_match = re.search(r"version\s+(\d+\.\d+\.\d+)", output, re.IGNORECASE)
                version = version_match.group(1) if version_match else "unknown"

                # Try to find dot executable path
                which_result = subprocess.run(
                    ["which", "dot"] if platform.system() != "Windows" else ["where", "dot"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                path = which_result.stdout.strip() if which_result.returncode == 0 else None

                return GraphvizInfo(
                    installed=True,
                    version=version,
                    path=path,
                )
            else:
                return GraphvizInfo(
                    installed=False,
                    error="Graphviz command 'dot' returned non-zero exit code",
                )

        except FileNotFoundError:
            return GraphvizInfo(
                installed=False,
                error="Graphviz 'dot' command not found",
            )
        except subprocess.TimeoutExpired:
            return GraphvizInfo(
                installed=False,
                error="Graphviz check timed out",
            )
        except Exception as e:
            return GraphvizInfo(
                installed=False,
                error=f"Error checking Graphviz: {str(e)}",
            )

    def get_installation_instructions(self) -> str:
        """Get platform-specific Graphviz installation instructions.

        Returns:
            Installation instructions as formatted string
        """
        system = platform.system()

        if system == "Darwin":  # macOS
            return """
[bold]macOS Installation:[/bold]
  brew install graphviz

[dim]After installation, restart your terminal.[/dim]
"""
        elif system == "Windows":
            return """
[bold]Windows Installation:[/bold]
  Option 1: Using Chocolatey
    choco install graphviz

  Option 2: Manual Installation
    1. Download from: https://graphviz.org/download/
    2. Run installer
    3. Add to PATH: C:\\Program Files\\Graphviz\\bin

[dim]After installation, restart your terminal.[/dim]
"""
        elif system == "Linux":
            return """
[bold]Linux Installation:[/bold]
  Ubuntu/Debian:
    sudo apt-get update
    sudo apt-get install graphviz

  CentOS/RHEL:
    sudo yum install graphviz

  Fedora:
    sudo dnf install graphviz

[dim]After installation, restart your terminal.[/dim]
"""
        else:
            return """
[bold]Installation:[/bold]
  Visit: https://graphviz.org/download/
  Follow instructions for your operating system.
"""

    def check_python_version(self) -> Tuple[bool, str]:
        """Check if Python version is 3.8 or higher.

        Returns:
            Tuple of (is_compatible, version_string)
        """
        version_info = sys.version_info
        version_string = f"{version_info.major}.{version_info.minor}.{version_info.micro}"
        is_compatible = version_info >= (3, 8)

        return is_compatible, version_string

    def ensure_venv_ready(self) -> Tuple[bool, str]:
        """Ensure virtual environment exists and has all dependencies.

        Returns:
            Tuple of (success: bool, message: str)
        """
        return self.venv_manager.setup_all()

    def ensure_output_directories(self) -> None:
        """Ensure output directories exist."""
        self.diagrams_dir.mkdir(parents=True, exist_ok=True)
        (self.project_path / "drawio").mkdir(parents=True, exist_ok=True)

    def find_python_scripts(self, diagram_name: Optional[str] = None) -> List[Path]:
        """Find Python diagram scripts to execute.

        Args:
            diagram_name: Optional specific diagram name to execute

        Returns:
            List of script paths to execute
        """
        if not self.python_scripts_dir.exists():
            return []

        if diagram_name:
            # Look for specific script
            script_path = self.python_scripts_dir / f"{diagram_name}_diagram.py"
            if script_path.exists():
                return [script_path]

            # Try without _diagram suffix
            script_path = self.python_scripts_dir / f"{diagram_name}.py"
            if script_path.exists():
                return [script_path]

            return []

        # Find all Python diagram scripts
        scripts = sorted(self.python_scripts_dir.glob("*_diagram.py"))
        if not scripts:
            # Try finding any .py files
            scripts = sorted(
                [
                    p
                    for p in self.python_scripts_dir.glob("*.py")
                    if p.name not in ["__init__.py", "test_*.py"]
                ]
            )

        return scripts

    def execute_script(self, script_path: Path) -> ExecutionResult:
        """Execute a single diagram generation script.

        Args:
            script_path: Path to Python script

        Returns:
            ExecutionResult with execution details
        """
        start_time = time.time()
        script_name = script_path.stem

        try:
            # Determine which Python to use (venv or system)
            if self.use_system_python or self.venv_manager is None:
                python_exe = sys.executable
            else:
                python_exe = str(self.venv_manager.get_python_executable())

            # Execute Python script
            result = subprocess.run(
                [python_exe, str(script_path)],
                capture_output=True,
                text=True,
                cwd=str(self.python_scripts_dir),
                timeout=300,  # 5 minute timeout
            )

            execution_time = time.time() - start_time

            # Check for output files
            output_files = self._find_output_files(script_name)

            if result.returncode == 0 and output_files:
                return ExecutionResult(
                    script_name=script_name,
                    success=True,
                    output_files=output_files,
                    execution_time=execution_time,
                )
            else:
                error_msg = result.stderr if result.stderr else result.stdout
                if not error_msg and not output_files:
                    error_msg = "Script executed but no output files generated"

                return ExecutionResult(
                    script_name=script_name,
                    success=False,
                    output_files=output_files,
                    error_message=error_msg,
                    execution_time=execution_time,
                )

        except subprocess.TimeoutExpired:
            return ExecutionResult(
                script_name=script_name,
                success=False,
                output_files=[],
                error_message="Script execution timed out (5 minutes)",
                execution_time=time.time() - start_time,
            )
        except Exception as e:
            return ExecutionResult(
                script_name=script_name,
                success=False,
                output_files=[],
                error_message=f"Execution error: {str(e)}",
                execution_time=time.time() - start_time,
            )

    def _find_output_files(self, script_name: str) -> List[str]:
        """Find output files generated by script.

        Args:
            script_name: Name of the script (without .py)

        Returns:
            List of generated file paths
        """
        output_files = []
        found_files = set()  # Use set to avoid duplicates

        # Common output patterns
        base_name = script_name.replace("_diagram", "")
        patterns = [
            f"{base_name}.png",
            f"{base_name}.dot",
            f"{script_name}.png",
            f"{script_name}.dot",
        ]

        for pattern in patterns:
            file_path = self.diagrams_dir / pattern
            if file_path.exists():
                relative_path = str(file_path.relative_to(self.project_path))
                if relative_path not in found_files:
                    found_files.add(relative_path)
                    output_files.append(relative_path)

        return output_files

    def execute_all(
        self,
        diagram_name: Optional[str] = None,
        skip_venv_setup: bool = False,
        fallback_on_venv_fail: bool = True
    ) -> Dict[str, any]:
        """Execute all or specific diagram generation scripts.

        Args:
            diagram_name: Optional specific diagram to execute
            skip_venv_setup: Skip venv validation entirely
            fallback_on_venv_fail: Fall back to system Python if venv fails

        Returns:
            Dictionary with execution summary
        """
        # Venv validation with graceful fallback
        if not skip_venv_setup and not self.use_system_python:
            venv_ready, message = self.ensure_venv_ready()

            if not venv_ready:
                if fallback_on_venv_fail:
                    console.print("[yellow]⚠ Virtual environment setup failed[/yellow]")
                    console.print(f"[yellow]  Reason: {message}[/yellow]")
                    console.print("[yellow]  Falling back to system Python...[/yellow]")

                    self.use_system_python = True
                    self.venv_manager = None

                    console.print(f"[cyan]Using: {sys.executable}[/cyan]")
                else:
                    return {
                        "status": "error",
                        "message": f"Virtual environment setup failed: {message}",
                        "results": [],
                    }

        # Show which Python is being used
        if skip_venv_setup or self.use_system_python:
            python_exe = sys.executable if self.use_system_python else str(self.venv_manager.get_python_executable() if self.venv_manager else sys.executable)
            # This is informational, will be shown during execution

        # Find scripts to execute
        scripts = self.find_python_scripts(diagram_name)

        if not scripts:
            if diagram_name:
                return {
                    "status": "error",
                    "message": f"No script found for diagram '{diagram_name}'",
                    "results": [],
                }
            else:
                return {
                    "status": "error",
                    "message": "No Python scripts found in python_scripts/",
                    "results": [],
                }

        # Reset results
        self.execution_results = []

        # Execute scripts with progress
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            task = progress.add_task(
                "[cyan]Executing diagram scripts...",
                total=len(scripts),
            )

            for script in scripts:
                progress.update(
                    task,
                    description=f"[cyan]Executing {script.name}...",
                )

                result = self.execute_script(script)
                self.execution_results.append(result)

                if result.success:
                    console.print(f"  [green]✓[/green] {script.name} completed")
                else:
                    console.print(f"  [red]✗[/red] {script.name} failed")

                progress.advance(task)

        # Generate summary
        return self._generate_summary()

    def _generate_summary(self) -> Dict[str, any]:
        """Generate execution summary.

        Returns:
            Dictionary with execution statistics
        """
        total = len(self.execution_results)
        successful = sum(1 for r in self.execution_results if r.success)
        failed = total - successful

        total_time = sum(r.execution_time for r in self.execution_results)

        # Count output files
        png_files = []
        dot_files = []

        for result in self.execution_results:
            for file_path in result.output_files:
                if file_path.endswith(".png"):
                    png_files.append(file_path)
                elif file_path.endswith(".dot"):
                    dot_files.append(file_path)

        # Get output directory size
        total_size = self._get_directory_size(self.diagrams_dir)

        return {
            "status": "success" if failed == 0 else "partial" if successful > 0 else "error",
            "total_scripts": total,
            "successful": successful,
            "failed": failed,
            "execution_time": round(total_time, 2),
            "png_count": len(png_files),
            "dot_count": len(dot_files),
            "total_size": total_size,
            "results": [
                {
                    "script": r.script_name,
                    "success": r.success,
                    "files": r.output_files,
                    "error": r.error_message,
                    "time": round(r.execution_time, 2),
                }
                for r in self.execution_results
            ],
        }

    def _get_directory_size(self, directory: Path) -> str:
        """Get human-readable directory size.

        Args:
            directory: Directory path

        Returns:
            Size string (e.g., "5.8 MB")
        """
        if not directory.exists():
            return "0 B"

        total_size = sum(f.stat().st_size for f in directory.rglob("*") if f.is_file())

        # Convert to human-readable
        for unit in ["B", "KB", "MB", "GB"]:
            if total_size < 1024.0:
                return f"{total_size:.1f} {unit}"
            total_size /= 1024.0

        return f"{total_size:.1f} TB"

    def format_summary(self, summary: Dict[str, any]) -> Table:
        """Format execution summary as rich table.

        Args:
            summary: Execution summary dictionary

        Returns:
            Rich Table object
        """
        table = Table(title="Diagram Execution Summary")
        table.add_column("Script", style="cyan", no_wrap=True)
        table.add_column("Status", style="bold")
        table.add_column("Files", justify="right")
        table.add_column("Time", justify="right", style="dim")

        for result in summary["results"]:
            status = "[green]✓ Success[/green]" if result["success"] else "[red]✗ Failed[/red]"
            files = str(len(result["files"]))
            time_str = f"{result['time']:.1f}s"

            table.add_row(result["script"], status, files, time_str)

        return table

    def get_error_details(self) -> List[Dict[str, str]]:
        """Get detailed error information for failed scripts.

        Returns:
            List of error detail dictionaries
        """
        errors = []

        for result in self.execution_results:
            if not result.success and result.error_message:
                # Parse error type and provide fix suggestion
                error_type, fix_suggestion = self._parse_error(result.error_message)

                errors.append(
                    {
                        "script": result.script_name,
                        "error_type": error_type,
                        "message": result.error_message[:200],  # Truncate long messages
                        "fix": fix_suggestion,
                    }
                )

        return errors

    def _parse_error(self, error_message: str) -> Tuple[str, str]:
        """Parse error message and provide fix suggestion.

        Args:
            error_message: Error message from script execution

        Returns:
            Tuple of (error_type, fix_suggestion)
        """
        if "ModuleNotFoundError" in error_message:
            if "diagrams" in error_message:
                return (
                    "Missing Package",
                    "Install diagrams package: pip install diagrams",
                )
            else:
                # Extract module name
                match = re.search(r"No module named '(\w+)'", error_message)
                module = match.group(1) if match else "required module"
                return (
                    "Missing Package",
                    f"Install package: pip install {module}",
                )

        if "Graphviz" in error_message or "dot" in error_message.lower():
            return (
                "Graphviz Error",
                "Ensure Graphviz is installed and in PATH",
            )

        if "SyntaxError" in error_message:
            return (
                "Syntax Error",
                "Regenerate Python scripts or fix manually",
            )

        if "PermissionError" in error_message:
            return (
                "Permission Error",
                "Check folder permissions or run with appropriate rights",
            )

        if "FileNotFoundError" in error_message:
            return (
                "File Not Found",
                "Ensure all required files (YAML specs) exist",
            )

        return ("Unknown Error", "Review error message and check script")
