"""YAML format transformer for AWS Architecture diagrams.

This module transforms YAML specifications from cluster-based format
(used by yaml-from-tdd skill) to node-based format (used by aws-arch CLI).

Cluster-based format (input from yaml-from-tdd):
  clusters:
    - name: "External Systems"
      components:
        - id: "oneclaim"
          kind: "client"
          label: "OneClaim"

Node-based format (expected by aws-arch CLI):
  nodes:
    - id: "oneclaim"
      kind: "client"
      label: "OneClaim"
      cluster: "external_systems"
  clusters:
    - id: "external_systems"
      label: "External Systems"
"""

import re
from typing import Any, Dict, List, Set


def sanitize_cluster_id(cluster_name: str) -> str:
    """Convert cluster name to a valid cluster ID.

    Transforms: "External Systems" -> "external_systems"
    - Lowercase
    - Replace spaces and hyphens with underscores
    - Remove special characters
    - Ensure it starts with letter or underscore

    Args:
        cluster_name: Human-readable cluster name

    Returns:
        Sanitized cluster ID suitable for use as identifier
    """
    # Lowercase
    sanitized = cluster_name.lower()

    # Replace spaces, hyphens, dots with underscores
    sanitized = re.sub(r'[\s\-\.]', '_', sanitized)

    # Remove any other special characters (keep only alphanumeric and underscore)
    sanitized = re.sub(r'[^a-z0-9_]', '', sanitized)

    # Remove leading/trailing underscores
    sanitized = sanitized.strip('_')

    # Ensure it starts with letter or underscore (prepend underscore if needed)
    if sanitized and sanitized[0].isdigit():
        sanitized = f"_{sanitized}"

    # Handle empty string case
    if not sanitized:
        sanitized = "cluster"

    return sanitized


def is_cluster_based_format(spec: Dict[str, Any]) -> bool:
    """Check if YAML uses cluster-based format.

    Detects if YAML has clusters with nested components (cluster-based)
    vs. flat nodes array (node-based).

    Args:
        spec: YAML specification dictionary

    Returns:
        True if cluster-based format detected
    """
    clusters = spec.get('clusters', [])
    if not isinstance(clusters, list):
        return False

    # Check if any cluster has components (cluster-based format)
    has_components = any(
        isinstance(cluster, dict) and 'components' in cluster
        for cluster in clusters
    )

    # Check if nodes array exists (node-based format)
    has_flat_nodes = 'nodes' in spec and isinstance(spec['nodes'], list)

    # Return True only if cluster-based (components) and NOT node-based (nodes)
    return has_components and not has_flat_nodes


def transform_cluster_format_to_nodes(spec: Dict[str, Any]) -> Dict[str, Any]:
    """Transform cluster-based YAML format to node-based format.

    Converts:
      Input:  clusters[].components[] -> Output: nodes[] with cluster references
              clusters[].name -> clusters[].id + clusters[].label

    Args:
        spec: YAML specification in cluster-based format

    Returns:
        Transformed YAML specification in node-based format

    Raises:
        ValueError: If input format is invalid or transformation fails
    """
    if not is_cluster_based_format(spec):
        raise ValueError(
            "Input YAML is not in cluster-based format. "
            "Expected 'clusters' with nested 'components', "
            "not flat 'nodes' array."
        )

    # Create new spec starting with metadata
    transformed: Dict[str, Any] = {}

    # Copy metadata and other top-level fields
    for key in ['system', 'metadata', 'edges', 'output', 'direction', 'graph_attributes']:
        if key in spec:
            transformed[key] = spec[key]

    # Transform clusters and extract nodes
    transformed['nodes'] = []
    transformed['clusters'] = []
    component_ids: Set[str] = set()

    clusters = spec.get('clusters', [])
    if not isinstance(clusters, list):
        raise ValueError("'clusters' must be a list")

    for cluster in clusters:
        if not isinstance(cluster, dict):
            raise ValueError(f"Cluster must be a dictionary, got {type(cluster)}")

        # Validate cluster has required fields
        if 'name' not in cluster:
            raise ValueError("Cluster missing required field 'name'")

        cluster_name = cluster['name']
        cluster_id = sanitize_cluster_id(cluster_name)

        # Add to transformed clusters array
        transformed['clusters'].append({
            'id': cluster_id,
            'label': cluster_name,
        })

        # Extract components and convert to nodes
        components = cluster.get('components', [])
        if not isinstance(components, list):
            raise ValueError(f"Cluster '{cluster_name}': 'components' must be a list")

        for component in components:
            if not isinstance(component, dict):
                raise ValueError(
                    f"Cluster '{cluster_name}': Component must be a dictionary"
                )

            # Validate required fields
            if 'id' not in component:
                raise ValueError(
                    f"Cluster '{cluster_name}': Component missing required field 'id'"
                )
            if 'label' not in component:
                raise ValueError(
                    f"Cluster '{cluster_name}': Component '{component.get('id')}' "
                    f"missing required field 'label'"
                )
            if 'kind' not in component:
                raise ValueError(
                    f"Cluster '{cluster_name}': Component '{component.get('id')}' "
                    f"missing required field 'kind'"
                )

            component_id = component['id']

            # Check for duplicate IDs
            if component_id in component_ids:
                raise ValueError(
                    f"Duplicate component ID '{component_id}' across clusters"
                )
            component_ids.add(component_id)

            # Build node from component
            node: Dict[str, Any] = {
                'id': component_id,
                'label': component['label'],
                'kind': component['kind'],
                'cluster': cluster_id,
            }

            # Copy optional fields
            if 'description' in component:
                node['description'] = component['description']

            transformed['nodes'].append(node)

    # Validate edges reference valid nodes
    if 'edges' in transformed and isinstance(transformed['edges'], list):
        for i, edge in enumerate(transformed['edges']):
            if not isinstance(edge, dict):
                continue

            from_id = edge.get('from')
            to_id = edge.get('to')

            if from_id and from_id not in component_ids:
                raise ValueError(
                    f"Edge #{i+1}: Source node '{from_id}' not found in components"
                )
            if to_id and to_id not in component_ids:
                raise ValueError(
                    f"Edge #{i+1}: Target node '{to_id}' not found in components"
                )

    return transformed


def validate_cluster_format(spec: Dict[str, Any]) -> tuple[List[str], List[str]]:
    """Validate YAML in cluster-based format.

    Checks structure and required fields without transforming.

    Args:
        spec: YAML specification to validate

    Returns:
        Tuple of (errors, warnings) lists
    """
    errors: List[str] = []
    warnings: List[str] = []

    # Check if it's cluster-based format
    if not is_cluster_based_format(spec):
        errors.append(
            "YAML is not in cluster-based format. "
            "Expected 'clusters' with nested 'components'."
        )
        return errors, warnings

    # Validate clusters
    clusters = spec.get('clusters', [])
    component_ids: Set[str] = set()

    for i, cluster in enumerate(clusters):
        cluster_num = i + 1

        if not isinstance(cluster, dict):
            errors.append(f"Cluster #{cluster_num}: Must be a dictionary")
            continue

        # Check required fields
        if 'name' not in cluster:
            errors.append(f"Cluster #{cluster_num}: Missing required field 'name'")
            continue

        cluster_name = cluster['name']

        # Validate components
        components = cluster.get('components', [])
        if not isinstance(components, list):
            errors.append(
                f"Cluster #{cluster_num} ('{cluster_name}'): 'components' must be a list"
            )
            continue

        for j, component in enumerate(components):
            component_num = j + 1

            if not isinstance(component, dict):
                errors.append(
                    f"Cluster #{cluster_num} ('{cluster_name}'): "
                    f"Component #{component_num} must be a dictionary"
                )
                continue

            # Check required fields
            if 'id' not in component:
                errors.append(
                    f"Cluster #{cluster_num} ('{cluster_name}'): "
                    f"Component #{component_num} missing 'id'"
                )
            else:
                component_id = component['id']
                if component_id in component_ids:
                    errors.append(
                        f"Cluster #{cluster_num} ('{cluster_name}'): "
                        f"Component #{component_num} has duplicate ID '{component_id}'"
                    )
                else:
                    component_ids.add(component_id)

            if 'label' not in component:
                comp_id = component.get('id', f'#{component_num}')
                errors.append(
                    f"Cluster #{cluster_num} ('{cluster_name}'): "
                    f"Component '{comp_id}' missing required field 'label'"
                )

            if 'kind' not in component:
                comp_id = component.get('id', f'#{component_num}')
                errors.append(
                    f"Cluster #{cluster_num} ('{cluster_name}'): "
                    f"Component '{comp_id}' missing required field 'kind'"
                )

            if 'description' not in component:
                comp_id = component.get('id', f'#{component_num}')
                warnings.append(
                    f"Cluster #{cluster_num} ('{cluster_name}'): "
                    f"Component '{comp_id}' missing 'description' (recommended)"
                )

    # Validate edges reference valid component IDs
    if 'edges' in spec and isinstance(spec['edges'], list):
        edges = spec['edges']
        for i, edge in enumerate(edges):
            edge_num = i + 1

            if not isinstance(edge, dict):
                continue

            from_id = edge.get('from')
            to_id = edge.get('to')

            if from_id and from_id not in component_ids:
                errors.append(
                    f"Edge #{edge_num}: Source node '{from_id}' not found in components"
                )
            if to_id and to_id not in component_ids:
                errors.append(
                    f"Edge #{edge_num}: Target node '{to_id}' not found in components"
                )

    return errors, warnings
