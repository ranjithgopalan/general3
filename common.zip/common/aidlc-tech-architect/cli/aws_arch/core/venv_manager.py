"""Virtual environment manager for AWS Architecture diagram generation.

Manages a shared virtual environment in ~/.claude/venvs/gather/
to ensure consistent dependencies and avoid system Python conflicts.
"""

import importlib
import os
import platform
import subprocess
import sys
import venv
from pathlib import Path
from typing import Dict, Tuple, Optional

from rich.console import Console

console = Console()


class VenvManager:
    """Manages virtual environment for diagram generation."""

    VENV_PATH = Path.home() / ".claude" / "venvs" / "gather"

    # Required dependencies for diagram generation
    DEPENDENCIES = [
        "diagrams>=0.23.4",
        "pydot>=1.4.2",
        "pyyaml>=6.0",
        "graphviz>=0.20.1",
        "typer>=0.9.0",
        "rich>=13.0.0",
        "jinja2>=3.1.0",
        "python-docx>=1.1.0",
        "pypdf>=3.0.0",
    ]

    # Package name to module name mapping for packages where pip name differs from import name
    PACKAGE_TO_MODULE = {
        "pyyaml": "yaml",          # pyyaml package installs as 'yaml' module
        "python-docx": "docx",     # python-docx package installs as 'docx' module
        "pypdf": "pypdf",          # pypdf package (explicit for clarity)
    }

    def __init__(self, force_reinstall: bool = False):
        """Initialize venv manager.

        Args:
            force_reinstall: If True, force clean reinstall of all dependencies
        """
        self.venv_path = self.VENV_PATH
        self.is_windows = platform.system() == "Windows"
        self.force_reinstall = force_reinstall
        self._setup_paths()
        # AWS Arch CLI is bundled with this plugin, relative to this file
        # venv_manager.py is at: cli/aws_arch/core/venv_manager.py
        # CLI root is at: cli/
        self.aws_arch_cli_path = Path(__file__).resolve().parent.parent.parent

    def _setup_paths(self) -> None:
        """Set up platform-specific paths."""
        if self.is_windows:
            self.python_exe = self.venv_path / "Scripts" / "python.exe"
            self.pip_exe = self.venv_path / "Scripts" / "pip.exe"
            self.activate_script = self.venv_path / "Scripts" / "activate.bat"
        else:
            self.python_exe = self.venv_path / "bin" / "python"
            self.pip_exe = self.venv_path / "bin" / "pip"
            self.activate_script = self.venv_path / "bin" / "activate"

    def ensure_venv_exists(self) -> bool:
        """Create virtual environment if it doesn't exist.

        Returns:
            True if venv exists or was successfully created, False otherwise
        """
        if self._venv_exists():
            return True

        try:
            console.print("[cyan]Creating virtual environment...[/cyan]")

            # Create venv directory
            self.venv_path.parent.mkdir(parents=True, exist_ok=True)

            # Create venv using venv module
            venv.create(self.venv_path, with_pip=True, upgrade_deps=True)

            if not self._venv_exists():
                console.print("[red]✗ Failed to create virtual environment[/red]")
                return False

            console.print(f"[green]✓ Virtual environment created: {self.venv_path}[/green]")
            return True

        except Exception as e:
            console.print(f"[red]✗ Error creating venv: {str(e)}[/red]")
            return False

    def _venv_exists(self) -> bool:
        """Check if venv already exists and has Python executable.

        Returns:
            True if venv is valid, False otherwise
        """
        return self.python_exe.exists() and self.pip_exe.exists()

    def install_dependencies(self) -> bool:
        """Install required dependencies in virtual environment.

        This includes:
        - PyPI packages (diagrams, pydot, etc.)
        - AWS Arch CLI in editable mode (from bundled plugin source)

        Returns:
            True if all dependencies installed successfully, False otherwise
        """
        if not self._venv_exists():
            console.print("[red]✗ Virtual environment does not exist[/red]")
            return False

        try:
            if self.force_reinstall:
                console.print("[cyan]Installing dependencies (force clean reinstall)...[/cyan]")
            else:
                console.print("[cyan]Installing dependencies...[/cyan]")

            # Upgrade pip first
            result = subprocess.run(
                [str(self.pip_exe), "install", "--upgrade", "pip"],
                capture_output=True,
                text=True,
                timeout=120,
            )

            if result.returncode != 0:
                console.print("[yellow]⚠ Warning: pip upgrade had issues[/yellow]")

            # Install PyPI dependencies
            for idx, package in enumerate(self.DEPENDENCIES, 1):
                console.print(f"[cyan]  [{idx}/{len(self.DEPENDENCIES)}] Installing {package.split('>=')[0]}...[/cyan]")

                # Build pip command with optional force-reinstall flag
                pip_cmd = [str(self.pip_exe), "install"]
                if self.force_reinstall:
                    pip_cmd.extend(["--force-reinstall", "--no-cache-dir"])
                pip_cmd.append(package)

                result = subprocess.run(
                    pip_cmd,
                    capture_output=True,
                    text=True,
                    timeout=300,
                )

                if result.returncode != 0:
                    console.print(f"[red]✗ Failed to install {package}[/red]")
                    console.print(f"[dim]{result.stderr[:200]}[/dim]")
                    return False

            # Install AWS Arch CLI in editable mode from bundled plugin
            if self.aws_arch_cli_path and (self.aws_arch_cli_path / "pyproject.toml").exists():
                console.print(f"[cyan]  [{len(self.DEPENDENCIES) + 1}/{len(self.DEPENDENCIES) + 1}] Installing aws-arch CLI (editable)...[/cyan]")

                pip_cmd = [str(self.pip_exe), "install", "-e"]
                if self.force_reinstall:
                    pip_cmd.extend(["--force-reinstall", "--no-cache-dir"])
                pip_cmd.append(str(self.aws_arch_cli_path))

                result = subprocess.run(
                    pip_cmd,
                    capture_output=True,
                    text=True,
                    timeout=300,
                )

                if result.returncode != 0:
                    console.print(f"[red]✗ Failed to install aws-arch CLI[/red]")
                    console.print(f"[dim]{result.stderr[:500]}[/dim]")
                    return False
            else:
                console.print(f"[yellow]⚠ Warning: aws-arch CLI source not found at {self.aws_arch_cli_path}[/yellow]")

            console.print("[green]✓ All dependencies installed[/green]")
            return True

        except subprocess.TimeoutExpired:
            console.print("[red]✗ Dependency installation timed out[/red]")
            return False
        except Exception as e:
            console.print(f"[red]✗ Error installing dependencies: {str(e)}[/red]")
            return False

    def get_python_executable(self) -> Path:
        """Get path to Python executable in venv.

        Returns:
            Path to Python executable
        """
        return self.python_exe

    def get_pip_executable(self) -> Path:
        """Get path to pip executable in venv.

        Returns:
            Path to pip executable
        """
        return self.pip_exe

    def get_activate_script(self) -> Path:
        """Get path to activation script.

        Returns:
            Path to activate script
        """
        return self.activate_script

    def check_dependencies(self) -> Dict[str, bool]:
        """Check if required dependencies are installed.

        Invalidates import cache before checking to work around Python 3.13
        import cache issues where the cache isn't invalidated between installs.

        Returns:
            Dictionary with package names as keys and installation status as values
        """
        if not self._venv_exists():
            return {pkg.split(">=")[0]: False for pkg in self.DEPENDENCIES}

        # Invalidate import caches to work around Python 3.13 import cache issues
        try:
            importlib.invalidate_caches()
        except Exception:
            pass  # Non-fatal if cache invalidation fails

        status = {}

        for package in self.DEPENDENCIES:
            pkg_name = package.split(">=")[0]

            # Determine the correct module name to import
            # Use mapping if available, fall back to simple replace('-', '_') logic
            module_name = self.PACKAGE_TO_MODULE.get(pkg_name, pkg_name.replace('-', '_'))

            try:
                result = subprocess.run(
                    [str(self.python_exe), "-c", f"import {module_name}"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                status[pkg_name] = result.returncode == 0
            except Exception:
                status[pkg_name] = False

        # Also check aws-arch CLI
        try:
            result = subprocess.run(
                [str(self.python_exe), "-m", "aws_arch.cli", "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            status["aws-arch"] = result.returncode == 0
        except Exception:
            status["aws-arch"] = False

        return status

    def pre_cache_diagrams_icons(self) -> bool:
        """Pre-download AWS icons from diagrams library.

        This ensures icons are cached before diagram generation,
        avoiding network issues during script execution.

        Returns:
            True if icons were pre-cached successfully, False otherwise
        """
        if not self._venv_exists():
            return False

        try:
            console.print("[cyan]Pre-caching AWS diagram icons...[/cyan]")

            # Python code to import diagrams and force icon cache initialization
            init_code = """
import os
import sys

# Ensure diagrams home exists
diagrams_home = os.path.expanduser("~/.diagrams")
if not os.path.exists(diagrams_home):
    os.makedirs(diagrams_home, exist_ok=True)

# Import diagrams and AWS modules to trigger icon download
try:
    from diagrams import Diagram
    from diagrams.aws.compute import Lambda
    from diagrams.aws.network import APIGateway
    from diagrams.aws.database import DynamoDB
    from diagrams.aws.storage import S3

    # Create a minimal diagram to trigger icon downloads
    with Diagram("icon-cache-test", show=False, outformat=[]):
        lambda_fn = Lambda("test")
        api = APIGateway("test")
        db = DynamoDB("test")
        bucket = S3("test")

    print("Icons cached successfully", file=sys.stderr)
except Exception as e:
    print(f"Warning: Icon caching failed: {e}", file=sys.stderr)
    sys.exit(0)  # Don't fail workflow if icons can't cache
"""

            result = subprocess.run(
                [str(self.python_exe), "-c", init_code],
                capture_output=True,
                text=True,
                timeout=60,
            )

            if result.returncode == 0:
                console.print("[green]✓ AWS icons pre-cached[/green]")
                return True
            else:
                console.print("[yellow]⚠ Icon pre-caching had issues (non-fatal)[/yellow]")
                return False

        except Exception as e:
            console.print(f"[yellow]⚠ Error pre-caching icons: {str(e)}[/yellow]")
            return False

    def setup_all(self) -> Tuple[bool, str]:
        """Complete venv setup: create, install dependencies, cache icons.

        Returns:
            Tuple of (success: bool, message: str)
        """
        if not self.ensure_venv_exists():
            return False, "Failed to create virtual environment"

        if not self.install_dependencies():
            return False, "Failed to install dependencies"

        # Pre-cache icons (non-fatal if fails)
        self.pre_cache_diagrams_icons()

        # Verify dependencies
        deps_status = self.check_dependencies()
        missing = [pkg for pkg, status in deps_status.items() if not status]

        if missing:
            return False, f"Missing dependencies: {', '.join(missing)}"

        return True, "Virtual environment ready"

    def display_info(self) -> None:
        """Display information about the virtual environment."""
        console.print("[bold]Virtual Environment Info:[/bold]")
        console.print(f"  Location: {self.venv_path}")
        console.print(f"  Python: {self.python_exe}")
        console.print(f"  Exists: {'✓' if self._venv_exists() else '✗'}")

        if self._venv_exists():
            deps_status = self.check_dependencies()
            console.print("[bold]Dependencies:[/bold]")
            for pkg, status in deps_status.items():
                symbol = "[green]✓[/green]" if status else "[red]✗[/red]"
                console.print(f"  {symbol} {pkg}")
