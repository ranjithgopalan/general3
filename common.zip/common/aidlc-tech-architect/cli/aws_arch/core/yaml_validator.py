"""YAML specification validator for AWS Architecture diagrams.

This module validates YAML specification files for:
- YAML syntax and structure
- Required fields
- AWS service kinds
- Edge references
- Cluster definitions
"""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import yaml

from aws_arch.core.utils import safe_read_file

# Valid edge colors
VALID_EDGE_COLORS = {
    "blue",
    "green",
    "purple",
    "orange",
    "gray",
    "grey",
    "red",
    "darkgreen",
    "darkblue",
    "brown",
    "teal",
    "black",
    "white",
}

# Valid edge styles
VALID_EDGE_STYLES = {"solid", "dashed", "dotted", "bold"}

# Required top-level fields
# Note: 'nodes' is optional - YAML can use either flat nodes OR cluster-based format
REQUIRED_TOP_FIELDS = {"system", "metadata", "edges"}

# Required metadata fields
REQUIRED_METADATA_FIELDS = {"description", "version", "diagram_type"}


class ValidationResult:
    """Result of YAML validation."""

    def __init__(
        self,
        file_path: str,
        is_valid: bool,
        errors: Optional[List[str]] = None,
        warnings: Optional[List[str]] = None,
    ):
        self.file_path = file_path
        self.is_valid = is_valid
        self.errors = errors or []
        self.warnings = warnings or []

    @property
    def has_errors(self) -> bool:
        """Check if result has errors."""
        return len(self.errors) > 0

    @property
    def has_warnings(self) -> bool:
        """Check if result has warnings."""
        return len(self.warnings) > 0

    @property
    def error_count(self) -> int:
        """Get number of errors."""
        return len(self.errors)

    @property
    def warning_count(self) -> int:
        """Get number of warnings."""
        return len(self.warnings)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON output."""
        return {
            "file": self.file_path,
            "valid": self.is_valid,
            "errors": self.errors,
            "warnings": self.warnings,
            "error_count": self.error_count,
            "warning_count": self.warning_count,
        }


class YamlValidator:
    """YAML specification validator for AWS Architecture diagrams."""

    def __init__(self, aws_services_config: Optional[Dict[str, Any]] = None):
        """Initialize validator.

        Args:
            aws_services_config: AWS services configuration dict. If None, loads from default location.
        """
        if aws_services_config is None:
            # Load from default config file
            config_path = Path(__file__).parent.parent / "config" / "aws_services.json"
            config_content = safe_read_file(config_path)
            aws_services_config = json.loads(config_content)

        # Build set of valid service kinds (including aliases)
        self.valid_services: Set[str] = set()
        for service_id, service_info in aws_services_config.get("services", {}).items():
            self.valid_services.add(service_id)
            # Add aliases
            for alias in service_info.get("aliases", []):
                self.valid_services.add(alias)

    def validate_file(self, file_path: str, strict: bool = False) -> ValidationResult:
        """Validate a YAML specification file.

        Args:
            file_path: Path to YAML file
            strict: If True, treat warnings as errors

        Returns:
            ValidationResult object with errors and warnings
        """
        # 1. Validate syntax
        syntax_valid, data, syntax_errors = self._validate_syntax(file_path)

        if not syntax_valid:
            return ValidationResult(file_path, False, errors=syntax_errors)

        all_errors: List[str] = []
        all_warnings: List[str] = []

        # 2. Validate structure
        struct_errors, struct_warnings = self._validate_structure(data)
        all_errors.extend(struct_errors)
        all_warnings.extend(struct_warnings)

        # 3. Validate nodes
        node_errors, node_warnings = self._validate_nodes(data)
        all_errors.extend(node_errors)
        all_warnings.extend(node_warnings)

        # 4. Validate edges
        edge_errors, edge_warnings = self._validate_edges(data)
        all_errors.extend(edge_errors)
        all_warnings.extend(edge_warnings)

        # 5. Validate clusters
        cluster_errors, cluster_warnings = self._validate_clusters(data)
        all_errors.extend(cluster_errors)
        all_warnings.extend(cluster_warnings)

        # In strict mode, treat warnings as errors
        if strict:
            all_errors.extend(all_warnings)
            all_warnings = []

        is_valid = len(all_errors) == 0

        return ValidationResult(file_path, is_valid, all_errors, all_warnings)

    def validate_files(
        self, file_paths: List[str], strict: bool = False
    ) -> List[ValidationResult]:
        """Validate multiple YAML files.

        Args:
            file_paths: List of file paths to validate
            strict: If True, treat warnings as errors

        Returns:
            List of ValidationResult objects
        """
        return [self.validate_file(fp, strict) for fp in file_paths]

    def _validate_syntax(self, file_path: str) -> Tuple[bool, Dict[str, Any], List[str]]:
        """Validate YAML syntax and load the file.

        Returns:
            Tuple of (is_valid, data, errors)
        """
        errors: List[str] = []

        try:
            content = safe_read_file(file_path)
            data = yaml.safe_load(content)

            if data is None:
                errors.append("YAML file is empty")
                return False, {}, errors

            if not isinstance(data, dict):
                errors.append("YAML root must be a dictionary")
                return False, {}, errors

            return True, data, errors

        except FileNotFoundError:
            errors.append(f"File not found: {file_path}")
            return False, {}, errors

        except yaml.YAMLError as e:
            errors.append(f"YAML syntax error: {e}")
            return False, {}, errors

        except Exception as e:
            errors.append(f"Error reading file: {e}")
            return False, {}, errors

    def _validate_structure(self, data: Dict[str, Any]) -> Tuple[List[str], List[str]]:
        """Validate required fields and structure.

        Supports both node-based and cluster-based formats:
        - Node-based: flat 'nodes' array with optional 'clusters'
        - Cluster-based: 'clusters' array with nested 'components'

        Returns:
            Tuple of (errors, warnings)
        """
        errors: List[str] = []
        warnings: List[str] = []

        # Check required top-level fields
        for field in REQUIRED_TOP_FIELDS:
            if field not in data:
                errors.append(f"Missing required top-level field: '{field}'")

        # Validate metadata
        if "metadata" in data:
            metadata = data["metadata"]
            if not isinstance(metadata, dict):
                errors.append("'metadata' must be a dictionary")
            else:
                for field in REQUIRED_METADATA_FIELDS:
                    if field not in metadata:
                        errors.append(f"Missing required metadata field: '{field}'")

        # Validate system field
        if "system" in data:
            if not isinstance(data["system"], str) or not data["system"].strip():
                errors.append("'system' field must be a non-empty string")

        # Validate graph_attr (optional but should be dict if present)
        if "output" in data:
            output = data["output"]
            if not isinstance(output, dict):
                warnings.append("'output' should be a dictionary")
            elif "graph_attr" in output and not isinstance(output["graph_attr"], dict):
                warnings.append("'output.graph_attr' should be a dictionary")

        # Detect format and validate accordingly
        has_flat_nodes = "nodes" in data and isinstance(data.get("nodes"), list)
        clusters = data.get("clusters", [])
        has_cluster_components = isinstance(clusters, list) and any(
            isinstance(c, dict) and "components" in c for c in clusters
        )

        # Check that format is valid (either flat nodes OR cluster-based, not both/neither)
        if has_flat_nodes and has_cluster_components:
            errors.append(
                "YAML cannot use both 'nodes' and 'clusters' with 'components'. "
                "Use either flat 'nodes' OR cluster-based 'clusters' (with 'components'), not both."
            )
        elif not has_flat_nodes and not has_cluster_components:
            errors.append(
                "YAML must have either 'nodes' array (flat format) "
                "OR 'clusters' with 'components' (cluster-based format)"
            )

        # Validate flat nodes format
        if has_flat_nodes:
            nodes = data["nodes"]
            if len(nodes) == 0:
                warnings.append("No nodes defined in the specification")

        # Validate cluster-based format
        if has_cluster_components:
            # Import transformer for validation
            from aws_arch.core.yaml_transformer import validate_cluster_format
            cluster_errors, cluster_warnings = validate_cluster_format(data)
            errors.extend(cluster_errors)
            warnings.extend(cluster_warnings)

        # Validate edges
        if "edges" in data:
            edges = data["edges"]
            if not isinstance(edges, list):
                errors.append("'edges' must be a list")
            elif len(edges) == 0:
                warnings.append("No edges defined in the specification")

        # Validate clusters (optional, for node-based format)
        if "clusters" in data and has_flat_nodes:
            clusters = data["clusters"]
            if not isinstance(clusters, list):
                errors.append("'clusters' must be a list")

        return errors, warnings

    def _validate_nodes(self, data: Dict[str, Any]) -> Tuple[List[str], List[str]]:
        """Validate node definitions.

        Returns:
            Tuple of (errors, warnings)
        """
        errors: List[str] = []
        warnings: List[str] = []

        if "nodes" not in data or not isinstance(data["nodes"], list):
            return errors, warnings

        nodes = data["nodes"]
        node_ids: Set[str] = set()

        for i, node in enumerate(nodes):
            node_num = i + 1

            if not isinstance(node, dict):
                errors.append(f"Node #{node_num}: Must be a dictionary")
                continue

            # Required fields
            if "id" not in node:
                errors.append(f"Node #{node_num}: Missing required field 'id'")
            else:
                node_id = node["id"]

                # Check for duplicate IDs
                if node_id in node_ids:
                    errors.append(f"Node #{node_num}: Duplicate node ID '{node_id}'")
                else:
                    node_ids.add(node_id)

            if "label" not in node:
                errors.append(
                    f"Node #{node_num} (ID: {node.get('id', 'unknown')}): "
                    f"Missing required field 'label'"
                )

            if "kind" not in node:
                errors.append(
                    f"Node #{node_num} (ID: {node.get('id', 'unknown')}): "
                    f"Missing required field 'kind'"
                )
            else:
                kind = node["kind"]
                if kind not in self.valid_services:
                    # Suggest similar services
                    similar = self._find_similar_service(kind)
                    suggestion = f" (did you mean '{similar}'?)" if similar else ""
                    warnings.append(
                        f"Node #{node_num} (ID: {node.get('id', 'unknown')}): "
                        f"Unknown service kind '{kind}'{suggestion}"
                    )

            # Optional but recommended fields
            if "description" not in node:
                warnings.append(
                    f"Node #{node_num} (ID: {node.get('id', 'unknown')}): "
                    f"Missing 'description' field (recommended)"
                )

        return errors, warnings

    def _validate_edges(self, data: Dict[str, Any]) -> Tuple[List[str], List[str]]:
        """Validate edge definitions.

        Returns:
            Tuple of (errors, warnings)
        """
        errors: List[str] = []
        warnings: List[str] = []

        if "edges" not in data or not isinstance(data["edges"], list):
            return errors, warnings

        # Collect all node IDs
        node_ids: Set[str] = set()
        if "nodes" in data and isinstance(data["nodes"], list):
            node_ids = {
                node.get("id") for node in data["nodes"] if isinstance(node, dict) and "id" in node
            }

        edges = data["edges"]

        for i, edge in enumerate(edges):
            edge_num = i + 1

            if not isinstance(edge, dict):
                errors.append(f"Edge #{edge_num}: Must be a dictionary")
                continue

            # Required fields
            if "from" not in edge:
                errors.append(f"Edge #{edge_num}: Missing required field 'from'")
            else:
                from_id = edge["from"]
                if from_id not in node_ids:
                    errors.append(f"Edge #{edge_num}: Source node '{from_id}' does not exist")

            if "to" not in edge:
                errors.append(f"Edge #{edge_num}: Missing required field 'to'")
            else:
                to_id = edge["to"]
                if to_id not in node_ids:
                    errors.append(f"Edge #{edge_num}: Target node '{to_id}' does not exist")

            # Optional fields validation
            if "color" in edge:
                color = edge["color"].lower()
                if color not in VALID_EDGE_COLORS and not color.startswith("#"):
                    warnings.append(
                        f"Edge #{edge_num} ({edge.get('from', '?')} → {edge.get('to', '?')}): "
                        f"Unknown color '{edge['color']}'. "
                        f"Valid colors: {', '.join(sorted(VALID_EDGE_COLORS))}"
                    )

            if "style" in edge:
                style = edge["style"]
                if style not in VALID_EDGE_STYLES:
                    warnings.append(
                        f"Edge #{edge_num} ({edge.get('from', '?')} → {edge.get('to', '?')}): "
                        f"Unknown style '{style}'. "
                        f"Valid styles: {', '.join(sorted(VALID_EDGE_STYLES))}"
                    )

            # Recommended field
            if "label" not in edge:
                warnings.append(
                    f"Edge #{edge_num} ({edge.get('from', '?')} → {edge.get('to', '?')}): "
                    f"Missing 'label' field (recommended)"
                )

        return errors, warnings

    def _validate_clusters(self, data: Dict[str, Any]) -> Tuple[List[str], List[str]]:
        """Validate cluster definitions.

        Returns:
            Tuple of (errors, warnings)
        """
        errors: List[str] = []
        warnings: List[str] = []

        if "clusters" not in data:
            return errors, warnings

        clusters = data["clusters"]

        if not isinstance(clusters, list):
            return errors, warnings

        cluster_ids: Set[str] = set()

        for i, cluster in enumerate(clusters):
            cluster_num = i + 1

            if not isinstance(cluster, dict):
                errors.append(f"Cluster #{cluster_num}: Must be a dictionary")
                continue

            # Required fields
            if "id" not in cluster:
                errors.append(f"Cluster #{cluster_num}: Missing required field 'id'")
            else:
                cluster_id = cluster["id"]

                # Check for duplicate IDs
                if cluster_id in cluster_ids:
                    errors.append(f"Cluster #{cluster_num}: Duplicate cluster ID '{cluster_id}'")
                else:
                    cluster_ids.add(cluster_id)

            if "label" not in cluster:
                errors.append(
                    f"Cluster #{cluster_num} (ID: {cluster.get('id', 'unknown')}): "
                    f"Missing required field 'label'"
                )

        return errors, warnings

    def _find_similar_service(self, service: str) -> Optional[str]:
        """Find similar service name for suggestions.

        Args:
            service: Service name to find similar match for

        Returns:
            Similar service name or None
        """
        service_lower = service.lower()

        # Exact match (case insensitive)
        for valid in self.valid_services:
            if valid.lower() == service_lower:
                return valid

        # Contains match
        for valid in self.valid_services:
            if service_lower in valid.lower() or valid.lower() in service_lower:
                return valid

        # Common substitutions
        substitutions = {
            "_": "-",
            "-": "_",
        }

        for old, new in substitutions.items():
            alt_service = service.replace(old, new)
            if alt_service in self.valid_services:
                return alt_service

        return None
