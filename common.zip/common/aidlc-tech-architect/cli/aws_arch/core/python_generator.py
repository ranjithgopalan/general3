"""
Python Diagram Generator

Converts YAML architecture specifications into executable Python scripts using
the mingrammer/diagrams library.
"""

import os
import yaml
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass

from .aws_mapping import (
    generate_import_statements,
    sanitize_node_id,
    get_class_name_for_service,
)


@dataclass
class GenerationResult:
    """Result of Python generation for a single YAML file."""
    success: bool
    yaml_file: Path
    python_file: Optional[Path] = None
    nodes_count: int = 0
    edges_count: int = 0
    clusters_count: int = 0
    error: Optional[str] = None
    warnings: List[str] = None

    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []


class PythonGenerator:
    """
    Generates Python diagram scripts from YAML specifications.
    """

    def __init__(self, output_dir: Optional[Path] = None):
        """
        Initialize the generator.

        Args:
            output_dir: Directory to write Python scripts to (default: python_scripts/)
        """
        self.output_dir = Path(output_dir) if output_dir else Path("python_scripts")
        self.warnings: List[str] = []
        self.errors: List[str] = []

    def generate_from_yaml_file(self, yaml_file: Path) -> GenerationResult:
        """
        Generate Python script from a single YAML file.

        Args:
            yaml_file: Path to YAML specification file

        Returns:
            GenerationResult with success status and metadata
        """
        try:
            # Read and parse YAML
            with open(yaml_file, 'r', encoding='utf-8') as f:
                spec = yaml.safe_load(f)

            if not spec:
                return GenerationResult(
                    success=False,
                    yaml_file=yaml_file,
                    error="Empty YAML file"
                )

            # Transform cluster-based format to node-based format if needed
            from aws_arch.core.yaml_transformer import is_cluster_based_format, transform_cluster_format_to_nodes
            if is_cluster_based_format(spec):
                spec = transform_cluster_format_to_nodes(spec)

            # Generate Python code
            python_code = self._generate_python_code(spec, yaml_file)

            # Determine output filename
            output_filename = self._get_output_filename(yaml_file)
            python_file = self.output_dir / output_filename

            # Ensure output directory exists
            self.output_dir.mkdir(parents=True, exist_ok=True)

            # Write Python file
            with open(python_file, 'w', encoding='utf-8') as f:
                f.write(python_code)

            # Make executable on Unix systems
            if os.name != 'nt':  # Not Windows
                os.chmod(python_file, 0o755)

            # Count elements
            nodes_count = len(spec.get('nodes', []))
            edges_count = len(spec.get('edges', []))
            clusters_count = len(spec.get('clusters', []))

            return GenerationResult(
                success=True,
                yaml_file=yaml_file,
                python_file=python_file,
                nodes_count=nodes_count,
                edges_count=edges_count,
                clusters_count=clusters_count,
                warnings=self.warnings.copy()
            )

        except yaml.YAMLError as e:
            return GenerationResult(
                success=False,
                yaml_file=yaml_file,
                error=f"YAML parsing error: {str(e)}"
            )
        except Exception as e:
            return GenerationResult(
                success=False,
                yaml_file=yaml_file,
                error=f"Generation error: {str(e)}"
            )
        finally:
            self.warnings.clear()

    def generate_from_directory(self, yaml_dir: Path) -> List[GenerationResult]:
        """
        Generate Python scripts from all YAML files in a directory.

        Args:
            yaml_dir: Directory containing YAML specification files

        Returns:
            List of GenerationResult for each YAML file
        """
        results = []
        yaml_files = sorted(yaml_dir.glob("*.yaml")) + sorted(yaml_dir.glob("*.yml"))

        for yaml_file in yaml_files:
            result = self.generate_from_yaml_file(yaml_file)
            results.append(result)

        return results

    def _generate_python_code(self, spec: Dict[str, Any], yaml_file: Path) -> str:
        """
        Generate Python code from parsed YAML specification.

        Args:
            spec: Parsed YAML specification
            yaml_file: Original YAML file path

        Returns:
            Complete Python script as string
        """
        # Extract spec components
        system_name = spec.get('system', 'AWS Architecture')
        diagram_type = spec.get('type', 'diagram')
        description = spec.get('description', f'{diagram_type} diagram')
        nodes = spec.get('nodes', [])
        clusters = spec.get('clusters', [])
        edges = spec.get('edges', [])
        graph_attr = spec.get('graph_attr', {})
        direction = spec.get('direction', 'TB')

        # Extract service kinds for imports
        service_kinds = [node.get('kind', 'generic') for node in nodes]

        # Generate import statements
        imports = generate_import_statements(service_kinds)

        # Generate Python code sections
        header = self._generate_header(system_name, diagram_type, description, yaml_file)
        graphviz_config = self._generate_graphviz_config()
        imports_section = '\n'.join(imports)
        graph_attr_code = self._generate_graph_attr(graph_attr)
        nodes_code = self._generate_nodes(nodes, clusters)
        edges_code = self._generate_edges(edges)

        # Determine output filename (without extension)
        output_filename = yaml_file.stem

        # Count nodes for icon info
        node_count = len(nodes)

        # Output directory setup code
        output_dir_setup = f'''
    # Determine output directory (relative to this script)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_dir = os.path.join(script_dir, "..", "diagrams")
    os.makedirs(output_dir, exist_ok=True)

    # Set output filename with directory
    output_path = os.path.join(output_dir, "{output_filename}")'''

        # Assemble complete Python script
        python_code = f'''{header}

{graphviz_config}

{imports_section}


def main():
    """Generate {diagram_type} diagram"""

{graph_attr_code}

{output_dir_setup}

    with Diagram(
        name="{system_name} - {diagram_type}",
        filename=output_path,
        direction="{direction}",
        graph_attr=graph_attr,
        show=False,
        outformat=["png", "dot"]
    ):
{nodes_code}

{edges_code}

    print(f"✅ Diagram generated: {{os.path.basename(output_path)}}.png")
    print(f"✅ DOT file: {{os.path.basename(output_path)}}.dot")
    print(f"✅ Output directory: {{output_dir}}")
    print(f"✅ AWS resources rendered: {node_count} service(s)")


if __name__ == "__main__":
    main()
'''

        return python_code

    def _generate_header(self, system_name: str, diagram_type: str,
                         description: str, yaml_file: Path) -> str:
        """Generate Python file header with docstring."""
        return f'''#!/usr/bin/env python3
"""
AWS Architecture Diagram: {system_name} - {diagram_type}
Generated from: {yaml_file.name}
Description: {description}
"""'''

    def _generate_graphviz_config(self) -> str:
        """Generate Graphviz PATH configuration and icon cache setup."""
        return '''import os
import sys

# Configure Graphviz PATH for Windows
graphviz_path = r"C:\\Program Files\\Graphviz\\bin"
if os.path.exists(graphviz_path):
    os.environ["PATH"] += os.pathsep + graphviz_path
else:
    # Try alternative common installation path
    graphviz_path_alt = r"C:\\Program Files (x86)\\Graphviz\\bin"
    if os.path.exists(graphviz_path_alt):
        os.environ["PATH"] += os.pathsep + graphviz_path_alt

# Set up diagrams icon directory for consistent caching
diagrams_home = os.path.expanduser("~/.diagrams")
if not os.path.exists(diagrams_home):
    os.makedirs(diagrams_home, exist_ok=True)'''

    def _sanitize_label(self, label: str) -> str:
        """
        Sanitize label text for use in Python string literals.

        Escapes special characters that would cause syntax errors:
        - Backslashes
        - Double quotes
        - Newlines
        - Carriage returns

        Args:
            label: Raw label text

        Returns:
            Sanitized label safe for use in Python string literals
        """
        if not label:
            return label

        # Order matters: escape backslashes first to avoid double-escaping
        sanitized = label.replace('\\', '\\\\')  # Backslash -> \\
        sanitized = sanitized.replace('"', '\\"')  # Quote -> \"
        sanitized = sanitized.replace('\n', '\\n')  # Newline -> \n
        sanitized = sanitized.replace('\r', '')  # Remove carriage returns

        return sanitized

    def _generate_graph_attr(self, graph_attr: Dict[str, Any]) -> str:
        """Generate graph_attr dictionary."""
        # Default values
        defaults = {
            "fontsize": "14",
            "splines": "ortho",
            "nodesep": "1.0",
            "ranksep": "1.5",
            "dpi": "300"
        }

        # Merge with provided attributes
        attrs = {**defaults, **graph_attr}

        # Generate dictionary
        lines = ['    graph_attr = {']
        for key, value in attrs.items():
            lines.append(f'        "{key}": "{value}",')
        lines.append('    }')

        return '\n'.join(lines)

    def _generate_nodes(self, nodes: List[Dict[str, Any]],
                        clusters: List[Dict[str, Any]]) -> str:
        """
        Generate node definitions, organized by clusters.

        Args:
            nodes: List of node specifications
            clusters: List of cluster specifications

        Returns:
            Python code for node definitions
        """
        lines = []

        # Create node ID to variable name mapping
        node_vars = {node['id']: sanitize_node_id(node['id']) for node in nodes}

        # Build cluster membership map
        cluster_nodes: Dict[str, List[Dict]] = {}
        unclustered_nodes = []

        for cluster in clusters:
            cluster_id = cluster['id']
            cluster_nodes[cluster_id] = []

        for node in nodes:
            node_cluster = node.get('cluster')
            if node_cluster and node_cluster in cluster_nodes:
                cluster_nodes[node_cluster].append(node)
            else:
                unclustered_nodes.append(node)

        # Generate unclustered nodes
        if unclustered_nodes:
            lines.append('        # Nodes')
            for node in unclustered_nodes:
                node_code = self._generate_node_definition(node, node_vars)
                lines.append(f'        {node_code}')
            lines.append('')

        # Generate clustered nodes
        for cluster in clusters:
            cluster_id = cluster['id']
            cluster_label = cluster.get('label', cluster_id)
            cluster_style = cluster.get('style', '')

            # Sanitize cluster label for safe use in Python strings
            sanitized_cluster_label = self._sanitize_label(cluster_label)

            lines.append(f'        # Cluster: {cluster_label}')

            if cluster_style:
                lines.append(f'        with Cluster("{sanitized_cluster_label}", graph_attr={{"style": "{cluster_style}"}}):')
            else:
                lines.append(f'        with Cluster("{sanitized_cluster_label}"):')

            if cluster_id in cluster_nodes and cluster_nodes[cluster_id]:
                for node in cluster_nodes[cluster_id]:
                    node_code = self._generate_node_definition(node, node_vars)
                    lines.append(f'            {node_code}')
            else:
                lines.append('            pass  # Empty cluster')

            lines.append('')

        return '\n'.join(lines)

    def _generate_node_definition(self, node: Dict[str, Any],
                                   node_vars: Dict[str, str]) -> str:
        """
        Generate a single node definition.

        Args:
            node: Node specification
            node_vars: Mapping of node IDs to variable names

        Returns:
            Python code for node definition
        """
        from .aws_mapping import get_import_for_service

        node_id = node['id']
        node_label = node.get('label', node_id)
        node_kind = node.get('kind', 'generic')

        var_name = node_vars[node_id]
        class_name = get_class_name_for_service(node_kind)

        # Sanitize node label for safe use in Python strings
        sanitized_node_label = self._sanitize_label(node_label)

        # Check if this kind is in the mapping (known kind) but falls back to Node
        is_known_kind = get_import_for_service(node_kind) is not None

        if class_name == 'Node' and not is_known_kind:
            # Truly unknown service kind (not in mapping at all) - graceful fallback to Node
            self.warnings.append(f"Unknown service kind '{node_kind}' for node '{node_id}' - using generic Node")
            return f'{var_name} = Node("{sanitized_node_label}")  # Graceful fallback: unknown service kind "{node_kind}"'

        return f'{var_name} = {class_name}("{sanitized_node_label}")'

    def _generate_edges(self, edges: List[Dict[str, Any]]) -> str:
        """
        Generate edge definitions.

        Args:
            edges: List of edge specifications

        Returns:
            Python code for edges
        """
        if not edges:
            return '        # No edges defined'

        lines = ['        # Edges']

        for edge in edges:
            from_id = edge.get('from')
            to_id = edge.get('to')
            label = edge.get('label', '')
            color = edge.get('color', '')
            style = edge.get('style', '')

            if not from_id or not to_id:
                self.warnings.append(f"Edge missing 'from' or 'to': {edge}")
                continue

            from_var = sanitize_node_id(from_id)
            to_var = sanitize_node_id(to_id)

            # Build Edge() parameters
            edge_params = []
            if label:
                # Sanitize label to prevent syntax errors from newlines and special chars
                sanitized_label = self._sanitize_label(label)
                edge_params.append(f'label="{sanitized_label}"')
            if color:
                edge_params.append(f'color="{color}"')
            if style:
                edge_params.append(f'style="{style}"')

            if edge_params:
                edge_str = f'Edge({", ".join(edge_params)})'
                lines.append(f'        {from_var} >> {edge_str} >> {to_var}')
            else:
                lines.append(f'        {from_var} >> {to_var}')

        return '\n'.join(lines)

    def _get_output_filename(self, yaml_file: Path) -> str:
        """
        Determine output Python filename from YAML filename.

        Args:
            yaml_file: Input YAML file path

        Returns:
            Output Python filename
        """
        return f"{yaml_file.stem}.py"

    def generate_batch_scripts(self, python_files: List[Path]) -> Tuple[Optional[Path], Optional[Path]]:
        """
        Generate batch execution scripts for Windows and Unix.

        Args:
            python_files: List of generated Python files

        Returns:
            Tuple of (windows_script_path, unix_script_path)
        """
        if not python_files:
            return None, None

        # Generate Windows batch script
        windows_script = self._generate_windows_batch(python_files)
        windows_path = self.output_dir / "generate_all.bat"

        with open(windows_path, 'w', encoding='utf-8', newline='\r\n') as f:
            f.write(windows_script)

        # Generate Unix shell script
        unix_script = self._generate_unix_batch(python_files)
        unix_path = self.output_dir / "generate_all.sh"

        with open(unix_path, 'w', encoding='utf-8', newline='\n') as f:
            f.write(unix_script)

        # Make Unix script executable
        if os.name != 'nt':
            os.chmod(unix_path, 0o755)

        return windows_path, unix_path

    def _generate_windows_batch(self, python_files: List[Path]) -> str:
        """Generate Windows batch script."""
        script_lines = [
            '@echo off',
            'setlocal enabledelayedexpansion',
            '',
            'REM AWS Architecture Diagrams - Generate All',
            'REM Generated automatically by aws-arch CLI',
            '',
            'REM Get script directory and change to it',
            'cd /d "%~dp0"',
            'if errorlevel 1 (',
            '    echo ERROR: Could not change to script directory',
            '    exit /b 1',
            ')',
            '',
            'echo ========================================',
            'echo AWS Architecture Diagram Generation',
            'echo ========================================',
            'echo.',
            '',
            'REM Check Python installation',
            'python --version >nul 2>&1',
            'if errorlevel 1 (',
            '    echo ERROR: Python not found. Please install Python 3.8+',
            '    exit /b 1',
            ')',
            '',
            'REM Check diagrams library',
            'python -c "import diagrams" >nul 2>&1',
            'if errorlevel 1 (',
            '    echo ERROR: diagrams library not found. Installing...',
            '    pip install diagrams',
            ')',
            '',
            'echo Generating diagrams...',
            'echo.',
            ''
        ]

        for idx, py_file in enumerate(python_files, 1):
            script_lines.extend([
                f'echo [{idx}/{len(python_files)}] Generating {py_file.stem}...',
                f'python "{py_file.name}"',
                'if errorlevel 1 (',
                f'    echo ERROR: Failed to generate {py_file.stem}',
                '    exit /b 1',
                ')',
                ''
            ])

        script_lines.extend([
            'echo.',
            'echo ========================================',
            'echo All diagrams generated successfully!',
            'echo ========================================',
            'echo.',
            'echo Output files created:',
            'echo   PNG: ..\\diagrams\\*.png (high resolution 300 DPI)',
            'echo   DOT: ..\\diagrams\\*.dot (Graphviz source)',
            'echo.',
            'pause'
        ])

        return '\r\n'.join(script_lines)

    def _generate_unix_batch(self, python_files: List[Path]) -> str:
        """Generate Unix shell script."""
        script_lines = [
            '#!/bin/bash',
            'set -e  # Exit on error',
            '',
            '# AWS Architecture Diagrams - Generate All',
            '# Generated automatically by aws-arch CLI',
            '',
            '# Get script directory and change to it',
            'SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"',
            'cd "$SCRIPT_DIR"',
            '',
            'echo "========================================"',
            'echo "AWS Architecture Diagram Generation"',
            'echo "========================================"',
            'echo ""',
            '',
            '# Check Python installation',
            'if ! command -v python3 &> /dev/null; then',
            '    echo "ERROR: Python 3 not found. Please install Python 3.8+"',
            '    exit 1',
            'fi',
            '',
            '# Check diagrams library',
            'if ! python3 -c "import diagrams" &> /dev/null; then',
            '    echo "ERROR: diagrams library not found. Installing..."',
            '    pip3 install diagrams',
            'fi',
            '',
            'echo "Generating diagrams..."',
            'echo ""',
            ''
        ]

        for idx, py_file in enumerate(python_files, 1):
            script_lines.extend([
                f'echo "[{idx}/{len(python_files)}] Generating {py_file.stem}..."',
                f'python3 "{py_file.name}"',
                'if [ $? -ne 0 ]; then',
                f'    echo "ERROR: Failed to generate {py_file.stem}"',
                '    exit 1',
                'fi',
                ''
            ])

        script_lines.extend([
            'echo ""',
            'echo "========================================"',
            'echo "All diagrams generated successfully!"',
            'echo "========================================"',
            'echo ""',
            'echo "Output files created:"',
            'echo "  PNG: ../diagrams/*.png (high resolution 300 DPI)"',
            'echo "  DOT: ../diagrams/*.dot (Graphviz source)"',
            'echo ""'
        ])

        return '\n'.join(script_lines)
