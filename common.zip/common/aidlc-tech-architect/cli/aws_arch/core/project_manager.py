"""Project management for AWS architecture diagram projects.

This module handles project creation, validation, and management operations.
"""

import json
import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from rich.console import Console
from rich.table import Table

console = Console()


class ProjectManager:
    """Manages AWS architecture diagram projects."""

    REQUIRED_FOLDERS = [
        "requirements",
        "yaml_specs",
        "python_scripts",
        "diagrams",
        "drawio",
    ]

    def __init__(self, base_path: Optional[Path] = None):
        """Initialize project manager.

        Args:
            base_path: Base directory for projects (default: current directory)
        """
        self.base_path = Path(base_path) if base_path else Path.cwd()

    def validate_project_name(self, name: str) -> Tuple[bool, str]:
        """Validate project name.

        Args:
            name: Project name to validate

        Returns:
            Tuple of (is_valid, error_message)
        """
        if not name:
            return False, "Project name cannot be empty"

        # Allow alphanumeric, hyphens, and underscores
        if not re.match(r"^[a-zA-Z0-9_-]+$", name):
            return (
                False,
                "Project name must contain only alphanumeric characters, hyphens, and underscores",
            )

        return True, ""

    def project_exists(self, name: str) -> bool:
        """Check if project already exists.

        Args:
            name: Project name

        Returns:
            True if project exists
        """
        project_path = self.base_path / name
        return project_path.exists() and project_path.is_dir()

    def find_projects_in_directory(self, directory: Optional[Path] = None) -> List[Dict[str, any]]:
        """Find valid AWS architecture projects in a directory.

        A valid project must have at least requirements/ and yaml_specs/ folders.

        Args:
            directory: Directory to search (default: base_path)

        Returns:
            List of project info dicts with name, path, yaml_count, etc.
        """
        search_dir = Path(directory) if directory else self.base_path

        if not search_dir.exists() or not search_dir.is_dir():
            return []

        projects = []

        # Scan immediate subdirectories
        try:
            for item in search_dir.iterdir():
                if not item.is_dir():
                    continue

                # Skip hidden directories
                if item.name.startswith('.'):
                    continue

                # Check for required folders
                has_requirements = (item / "requirements").exists()
                has_yaml_specs = (item / "yaml_specs").exists()

                # Consider it a project if it has at least requirements/ and yaml_specs/
                if has_requirements and has_yaml_specs:
                    stats = self._get_project_stats(item)

                    projects.append({
                        'name': item.name,
                        'path': str(item),
                        'yaml_count': stats['yaml_count'],
                        'script_count': stats['script_count'],
                        'diagram_count': stats['diagram_count'],
                        'is_valid': True,
                    })
        except (OSError, PermissionError):
            # Handle permission errors gracefully
            pass

        # Sort by most recently modified
        try:
            projects.sort(key=lambda p: Path(p['path']).stat().st_mtime, reverse=True)
        except (OSError, ValueError):
            pass

        return projects

    def create_project(
        self,
        name: str,
        template: str = "default",
        force: bool = False,
    ) -> Tuple[bool, str, Optional[Path]]:
        """Create a new AWS architecture project.

        Args:
            name: Project name
            template: Template to use (default: "default")
            force: Force creation even if project exists

        Returns:
            Tuple of (success, message, project_path)
        """
        # Validate project name
        valid, error = self.validate_project_name(name)
        if not valid:
            return False, error, None

        project_path = self.base_path / name

        # Check if project exists
        if project_path.exists() and not force:
            return (
                False,
                f"Project '{name}' already exists at {project_path}",
                project_path,
            )

        try:
            # Create folder structure
            success, message = self._create_folder_structure(project_path)
            if not success:
                return False, message, None

            # Copy templates
            success, message = self._copy_templates(project_path, template)
            if not success:
                console.print(f"[yellow]Warning: {message}[/yellow]")

            # Create README
            self._create_readme(project_path, name)

            # Create .gitignore
            self._create_gitignore(project_path)

            # Get project stats
            stats = self._get_project_stats(project_path)

            success_msg = (
                f"Project '{name}' created successfully at {project_path}\n"
                f"Folders: {len(self.REQUIRED_FOLDERS)}\n"
                f"YAML templates: {stats['yaml_count']}\n"
                f"Total files: {stats['total_files']}"
            )

            return True, success_msg, project_path

        except Exception as e:
            return False, f"Failed to create project: {str(e)}", None

    def _create_folder_structure(self, project_path: Path) -> Tuple[bool, str]:
        """Create project folder structure.

        Args:
            project_path: Path to project root

        Returns:
            Tuple of (success, message)
        """
        try:
            # Create project root
            project_path.mkdir(parents=True, exist_ok=True)

            # Create required folders
            for folder in self.REQUIRED_FOLDERS:
                (project_path / folder).mkdir(parents=True, exist_ok=True)

            return True, "Folder structure created"

        except Exception as e:
            return False, f"Failed to create folders: {str(e)}"

    def _copy_templates(self, project_path: Path, template: str) -> Tuple[bool, str]:
        """Copy YAML templates to project.

        Args:
            project_path: Path to project root
            template: Template name

        Returns:
            Tuple of (success, message)
        """
        # Find templates directory
        # Look in the CLI package directory
        cli_root = Path(__file__).parent.parent.parent
        templates_dir = cli_root / "templates" / "yaml"

        # If not found, look in reference directory
        if not templates_dir.exists():
            reference_dir = cli_root.parent / "reference" / "Requirements" / "artifacts"
            if reference_dir.exists():
                templates_dir = reference_dir

        if not templates_dir.exists():
            return (
                False,
                "YAML templates not found. You can add them manually to yaml_specs/",
            )

        # Copy YAML files
        yaml_specs_dir = project_path / "yaml_specs"
        copied = 0

        for yaml_file in templates_dir.glob("*.yaml"):
            dest = yaml_specs_dir / yaml_file.name
            shutil.copy2(yaml_file, dest)
            copied += 1

        if copied == 0:
            return False, "No YAML templates found to copy"

        return True, f"Copied {copied} YAML template(s)"

    def _create_readme(self, project_path: Path, project_name: str) -> None:
        """Create README.md for project.

        Args:
            project_path: Path to project root
            project_name: Name of the project
        """
        readme_content = f"""# {project_name} - AWS Architecture Diagrams

AWS architecture diagram generation project created by AWS Architecture Agent.

## Project Structure

```
{project_name}/
├── requirements/       # Place TDD documents here (.md, .docx, .pdf)
├── yaml_specs/        # YAML specifications (auto-generated or templates)
├── python_scripts/    # Python diagram scripts (auto-generated)
├── diagrams/          # PNG and DOT outputs
└── drawio/            # Draw.io XML outputs
```

## 🚨 CRITICAL: TDD Preservation & Completeness

**The `requirements/` folder contains the SOURCE OF TRUTH.**

### Rule 1: Copy ALL Files from Source Folder

**CRITICAL:** When copying TDDs from a source folder, you MUST copy **ALL files** in that folder, not just one:

✅ **DO:**
- Copy **ALL .md, .docx, .pdf files** from source folder to `requirements/`
- Include Master TDDs that contain shared definitions and context
- Include service-specific TDDs
- Copy supporting documentation files
- Preserve folder structure if subdirectories exist

❌ **DO NOT:**
- Copy only one file and skip others
- Skip Master TDDs or shared documentation
- Pick and choose which files to copy

**Example:**
```bash
Source: /source/requirements/
  - Master-TDD.md              ← MUST copy
  - service-tdd.md             ← MUST copy
  - other-docs.md              ← MUST copy

Destination: {project_name}/requirements/
  - ALL files copied ✅
```

**Why this matters:** Master TDDs contain shared architectural decisions, constraints, and context required for complete validation. Missing these files breaks cross-references and architectural consistency.

### Rule 2: Byte-for-Byte Preservation

When copying TDD files:

✅ **DO:**
- Copy TDD files AS-IS without modification
- Preserve original formatting, line endings, and encoding
- Keep original file extension (.md, .docx, .pdf)
- Use byte-for-byte identical copies

❌ **DO NOT:**
- Summarize or excerpt TDD content
- Reformat or convert to different formats
- Strip metadata or change encoding
- Modify any content during ingestion

**Why this matters:** The TDD is the immutable specification that all diagrams are generated from. Any modification risks introducing inconsistencies between the documented architecture and the generated diagrams.

## Quick Start

1. **Add TDD Document**
   - Place your Technical Design Document in `requirements/` folder
   - Supported formats: Markdown (.md), Word (.docx), PDF (.pdf)

2. **Generate Diagrams**
   ```bash
   aws-arch workflow run {project_name}
   ```
   This runs the complete workflow automatically.

3. **View Results**
   - PNG diagrams: `diagrams/` folder
   - Draw.io XML: `drawio/` folder (open at https://app.diagrams.net/)

## Available Commands

```bash
# Complete workflow
aws-arch workflow run {project_name}

# Individual operations
aws-arch yaml validate {project_name}/yaml_specs/*.yaml
aws-arch python generate {project_name}/yaml_specs/*.yaml
aws-arch diagram execute {project_name}
aws-arch drawio convert-all {project_name}
```

## Requirements

- **Python 3.8+** - Required for diagram generation
- **Graphviz** - Required for rendering diagrams
  - macOS: `brew install graphviz`
  - Windows: `choco install graphviz` or download from https://graphviz.org/
  - Linux: `sudo apt-get install graphviz`
- **Python Packages** - Installed via CLI:
  - `diagrams` - AWS architecture diagrams
  - `pyyaml` - YAML processing
  - `typer` - CLI framework
  - `rich` - Rich terminal output

## Workflow Steps

1. **TDD Processing** - Extract architecture from requirements
2. **YAML Generation** - Create structured specifications
3. **YAML Validation** - Ensure correctness
4. **Python Generation** - Create diagram scripts
5. **Execution** - Generate PNG/DOT files
6. **Draw.io Conversion** - Create editable XML diagrams

## Tips

- Keep TDD documents comprehensive and detailed
- Review YAML specs before generating Python scripts
- Use `aws-arch yaml validate` to catch issues early
- PNG files are high-resolution (300 DPI) with AWS icons
- Draw.io files are fully editable and customizable

## Support

For issues or questions, refer to the GATHER-tech-architect plugin documentation.

---

Generated by AWS Architecture Agent CLI
Created: {datetime.now().strftime('%Y-%m-%d')}
"""

        readme_path = project_path / "README.md"
        readme_path.write_text(readme_content)

    def _create_gitignore(self, project_path: Path) -> None:
        """Create .gitignore file for project.

        Args:
            project_path: Path to project root
        """
        gitignore_content = """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
build/
dist/
*.egg-info/

# Diagrams (optional - uncomment if you want to commit diagrams)
# diagrams/*.png
# diagrams/*.dot
# drawio/*.xml

# IDE
.vscode/
.idea/
*.swp
*.swo
*.sublime-project
*.sublime-workspace

# OS
.DS_Store
Thumbs.db
Desktop.ini

# Logs
*.log

# Temporary files
*.tmp
*.bak
*~
"""

        gitignore_path = project_path / ".gitignore"
        gitignore_path.write_text(gitignore_content)

    def _get_project_stats(self, project_path: Path) -> Dict[str, int]:
        """Get project statistics.

        Args:
            project_path: Path to project root

        Returns:
            Dictionary with project statistics
        """
        yaml_count = len(list((project_path / "yaml_specs").glob("*.yaml")))
        total_files = sum(1 for _ in project_path.rglob("*") if _.is_file())

        return {
            "yaml_count": yaml_count,
            "total_files": total_files,
        }

    def list_projects(self, path: Optional[Path] = None) -> List[Dict[str, any]]:
        """List all projects in directory.

        Args:
            path: Directory to search (default: base_path)

        Returns:
            List of project dictionaries
        """
        search_path = Path(path) if path else self.base_path

        if not search_path.exists():
            return []

        projects = []

        for item in search_path.iterdir():
            if not item.is_dir():
                continue

            # Check if it's a project (has required folders)
            if self._is_valid_project(item):
                stats = self._get_project_stats(item)
                projects.append(
                    {
                        "name": item.name,
                        "path": str(item),
                        "yaml_count": stats["yaml_count"],
                        "total_files": stats["total_files"],
                    }
                )

        return projects

    def get_project_info(self, name: str) -> Optional[Dict[str, any]]:
        """Get detailed project information.

        Args:
            name: Project name

        Returns:
            Project information dictionary or None if not found
        """
        project_path = self.base_path / name

        if not project_path.exists():
            return None

        # Check if it's a valid project
        if not self._is_valid_project(project_path):
            return None

        # Get folder statistics
        folder_stats = {}
        for folder in self.REQUIRED_FOLDERS:
            folder_path = project_path / folder
            if folder_path.exists():
                file_count = len(list(folder_path.rglob("*")))
                folder_stats[folder] = file_count
            else:
                folder_stats[folder] = -1  # Missing

        # Get overall stats
        stats = self._get_project_stats(project_path)

        return {
            "name": name,
            "path": str(project_path),
            "folders": folder_stats,
            "yaml_count": stats["yaml_count"],
            "total_files": stats["total_files"],
            "is_valid": self._is_valid_project(project_path),
        }

    def _is_valid_project(self, project_path: Path) -> bool:
        """Check if directory is a valid project.

        Args:
            project_path: Path to check

        Returns:
            True if valid project
        """
        # At minimum, should have requirements and yaml_specs folders
        required = ["requirements", "yaml_specs"]
        return all((project_path / folder).exists() for folder in required)

    def format_project_list(self, projects: List[Dict[str, any]]) -> str:
        """Format project list as rich table.

        Args:
            projects: List of project dictionaries

        Returns:
            Formatted table string
        """
        if not projects:
            return "No projects found"

        table = Table(title="AWS Architecture Projects")
        table.add_column("Project Name", style="cyan", no_wrap=True)
        table.add_column("YAML Specs", justify="right", style="green")
        table.add_column("Total Files", justify="right", style="yellow")
        table.add_column("Path", style="dim")

        for project in projects:
            table.add_row(
                project["name"],
                str(project["yaml_count"]),
                str(project["total_files"]),
                project["path"],
            )

        return table

    def format_project_info(self, info: Dict[str, any]) -> str:
        """Format project info as rich display.

        Args:
            info: Project information dictionary

        Returns:
            Formatted info string
        """
        table = Table(title=f"Project: {info['name']}")
        table.add_column("Folder", style="cyan")
        table.add_column("Files", justify="right", style="green")
        table.add_column("Status", style="yellow")

        for folder, count in info["folders"].items():
            if count == -1:
                status = "❌ Missing"
                count_str = "-"
            elif count == 0:
                status = "⚠️  Empty"
                count_str = "0"
            else:
                status = "✅ OK"
                count_str = str(count)

            table.add_row(folder, count_str, status)

        return table
