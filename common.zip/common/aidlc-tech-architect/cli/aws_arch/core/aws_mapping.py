"""
AWS Service to Diagrams Library Import Mapping

This module provides the canonical mapping from AWS service kinds (as used in YAML specs)
to the correct Python import paths in the diagrams library.

WARNING: These mappings are verified and must be kept accurate!
Common mistakes:
- X-Ray is in devtools, NOT integration
- SNS is in integration, NOT devtools
- CloudWatch is in management, NOT integration
"""

from typing import Dict, List, Optional, Tuple

# Service kind to (module_path, class_name) mapping
# Reference: scripts/AWS_IMPORT_REFERENCE.md (from original implementation)
AWS_IMPORT_MAP: Dict[str, Tuple[str, str]] = {
    # Compute Services
    'lambda': ('diagrams.aws.compute', 'Lambda'),
    'ec2': ('diagrams.aws.compute', 'EC2'),
    'ecs': ('diagrams.aws.compute', 'ECS'),
    'fargate': ('diagrams.aws.compute', 'Fargate'),
    'batch': ('diagrams.aws.compute', 'Batch'),
    'elastic-beanstalk': ('diagrams.aws.compute', 'ElasticBeanstalk'),

    # Network Services
    'api-gateway': ('diagrams.aws.network', 'APIGateway'),
    'vpc': ('diagrams.aws.network', 'VPC'),
    'alb': ('diagrams.aws.network', 'ALB'),
    'nlb': ('diagrams.aws.network', 'NLB'),
    'elb': ('diagrams.aws.network', 'ELB'),
    'cloudfront': ('diagrams.aws.network', 'CloudFront'),
    'route53': ('diagrams.aws.network', 'Route53'),
    'internet-gateway': ('diagrams.aws.network', 'InternetGateway'),
    'nat-gateway': ('diagrams.aws.network', 'NATGateway'),

    # Database Services
    'aurora': ('diagrams.aws.database', 'Aurora'),
    'rds': ('diagrams.aws.database', 'RDS'),
    'dynamodb': ('diagrams.aws.database', 'Dynamodb'),
    'elasticache': ('diagrams.aws.database', 'ElastiCache'),
    'redshift': ('diagrams.aws.database', 'Redshift'),
    'neptune': ('diagrams.aws.database', 'Neptune'),
    'documentdb': ('diagrams.aws.database', 'DocumentDB'),

    # Storage Services
    's3': ('diagrams.aws.storage', 'S3'),
    'efs': ('diagrams.aws.storage', 'EFS'),
    'glacier': ('diagrams.aws.storage', 'Glacier'),
    'fsx': ('diagrams.aws.storage', 'FSx'),
    'ebs': ('diagrams.aws.storage', 'EBS'),

    # Integration Services (⚠️ SNS is here!)
    'eventbridge': ('diagrams.aws.integration', 'Eventbridge'),
    'sqs': ('diagrams.aws.integration', 'SQS'),
    'sns': ('diagrams.aws.integration', 'SimpleNotificationServiceSns'),
    'step-functions': ('diagrams.aws.integration', 'StepFunctions'),
    'mq': ('diagrams.aws.integration', 'MQ'),
    'appsync': ('diagrams.aws.integration', 'Appsync'),

    # Management & Monitoring (⚠️ CloudWatch is here!)
    'cloudwatch': ('diagrams.aws.management', 'Cloudwatch'),
    'cloudtrail': ('diagrams.aws.management', 'Cloudtrail'),
    'systems-manager': ('diagrams.aws.management', 'SystemsManager'),
    'config': ('diagrams.aws.management', 'Config'),
    'cloudformation': ('diagrams.aws.management', 'Cloudformation'),
    'opsworks': ('diagrams.aws.management', 'Opsworks'),

    # Developer Tools (⚠️ X-Ray is here!)
    'x-ray': ('diagrams.aws.devtools', 'XRay'),
    'codebuild': ('diagrams.aws.devtools', 'Codebuild'),
    'codepipeline': ('diagrams.aws.devtools', 'Codepipeline'),
    'codecommit': ('diagrams.aws.devtools', 'Codecommit'),
    'codedeploy': ('diagrams.aws.devtools', 'Codedeploy'),

    # Security Services
    'secrets-manager': ('diagrams.aws.security', 'SecretsManager'),
    'iam': ('diagrams.aws.security', 'IAM'),
    'cognito': ('diagrams.aws.security', 'Cognito'),
    'kms': ('diagrams.aws.security', 'KMS'),
    'waf': ('diagrams.aws.security', 'WAF'),
    'shield': ('diagrams.aws.security', 'Shield'),
    'guardduty': ('diagrams.aws.security', 'Guardduty'),
    'inspector': ('diagrams.aws.security', 'Inspector'),

    # Analytics Services
    'kinesis': ('diagrams.aws.analytics', 'Kinesis'),
    'kinesis-data-firehose': ('diagrams.aws.analytics', 'KinesisDataFirehose'),
    'athena': ('diagrams.aws.analytics', 'Athena'),
    'glue': ('diagrams.aws.analytics', 'Glue'),
    'emr': ('diagrams.aws.analytics', 'EMR'),
    'quicksight': ('diagrams.aws.analytics', 'Quicksight'),

    # ML/AI Services
    'sagemaker': ('diagrams.aws.ml', 'Sagemaker'),
    'rekognition': ('diagrams.aws.ml', 'Rekognition'),
    'comprehend': ('diagrams.aws.ml', 'Comprehend'),
    'lex': ('diagrams.aws.ml', 'Lex'),

    # External Systems & Non-AWS Services
    # These use diagrams.onprem for better visualization of external/third-party systems
    'client': ('diagrams.onprem.client', 'Users'),
    'user': ('diagrams.onprem.client', 'Users'),
    'external-system': ('diagrams.onprem.client', 'Users'),
    'oauth': ('diagrams.onprem.security', 'Vault'),  # Secure token provider
    'oauth2': ('diagrams.onprem.security', 'Vault'),
    'vault': ('diagrams.onprem.security', 'Vault'),  # HashiCorp Vault, credential storage
    'secrets': ('diagrams.onprem.security', 'Vault'),

    # Generic/Other
    'generic': ('diagrams', 'Node'),
    'custom': ('diagrams', 'Node'),
}

# Category grouping for import organization
AWS_SERVICE_CATEGORIES = {
    'Compute': ['lambda', 'ec2', 'ecs', 'fargate', 'batch', 'elastic-beanstalk'],
    'Network': ['api-gateway', 'vpc', 'alb', 'nlb', 'elb', 'cloudfront', 'route53',
                'internet-gateway', 'nat-gateway'],
    'Database': ['aurora', 'rds', 'dynamodb', 'elasticache', 'redshift', 'neptune', 'documentdb'],
    'Storage': ['s3', 'efs', 'glacier', 'fsx', 'ebs'],
    'Integration': ['eventbridge', 'sqs', 'sns', 'step-functions', 'mq', 'appsync'],
    'Management': ['cloudwatch', 'cloudtrail', 'systems-manager', 'config',
                   'cloudformation', 'opsworks'],
    'DevTools': ['x-ray', 'codebuild', 'codepipeline', 'codecommit', 'codedeploy'],
    'Security': ['secrets-manager', 'iam', 'cognito', 'kms', 'waf', 'shield',
                 'guardduty', 'inspector'],
    'Analytics': ['kinesis', 'kinesis-data-firehose', 'athena', 'glue', 'emr', 'quicksight'],
    'ML': ['sagemaker', 'rekognition', 'comprehend', 'lex'],
    'External': ['client', 'user', 'external-system', 'oauth', 'oauth2', 'vault', 'secrets'],
}


def get_import_for_service(service_kind: str) -> Optional[Tuple[str, str]]:
    """
    Get the import path and class name for a given service kind.

    Args:
        service_kind: The service kind as specified in YAML (e.g., 'lambda', 'api-gateway')

    Returns:
        Tuple of (module_path, class_name) or None if service not found

    Examples:
        >>> get_import_for_service('lambda')
        ('diagrams.aws.compute', 'Lambda')

        >>> get_import_for_service('api-gateway')
        ('diagrams.aws.network', 'APIGateway')
    """
    return AWS_IMPORT_MAP.get(service_kind.lower())


def get_imports_for_services(service_kinds: List[str]) -> Dict[str, List[Tuple[str, str]]]:
    """
    Get organized imports for multiple services, grouped by module.

    Args:
        service_kinds: List of service kinds from YAML

    Returns:
        Dictionary mapping module paths to list of (class_name, service_kind) tuples

    Examples:
        >>> get_imports_for_services(['lambda', 'api-gateway', 'aurora'])
        {
            'diagrams.aws.compute': [('Lambda', 'lambda')],
            'diagrams.aws.network': [('APIGateway', 'api-gateway')],
            'diagrams.aws.database': [('Aurora', 'aurora')]
        }
    """
    imports: Dict[str, List[Tuple[str, str]]] = {}
    unknown_services = []

    for service_kind in set(service_kinds):  # Remove duplicates
        import_info = get_import_for_service(service_kind)
        if import_info:
            module_path, class_name = import_info
            if module_path not in imports:
                imports[module_path] = []
            imports[module_path].append((class_name, service_kind))
        else:
            unknown_services.append(service_kind)

    # Sort imports for consistent output
    for module_path in imports:
        imports[module_path].sort()

    if unknown_services:
        # Add warning comment about unknown services
        imports['__unknown__'] = [(f"# Unknown service: {s}", s) for s in unknown_services]

    return imports


def generate_import_statements(service_kinds: List[str]) -> List[str]:
    """
    Generate Python import statements for the given service kinds.

    Args:
        service_kinds: List of service kinds used in diagram

    Returns:
        List of import statement strings

    Examples:
        >>> generate_import_statements(['lambda', 'api-gateway'])
        [
            'from diagrams.aws.compute import Lambda',
            'from diagrams.aws.network import APIGateway'
        ]
    """
    imports_dict = get_imports_for_services(service_kinds)
    import_statements = []

    # Check if there are unknown service kinds
    has_unknown = '__unknown__' in imports_dict and imports_dict['__unknown__']

    # Add base imports first - include Node if there are unknown services
    base_imports = ['from diagrams import Diagram, Cluster, Edge']
    if has_unknown:
        base_imports[0] = 'from diagrams import Diagram, Cluster, Edge, Node'

    import_statements.extend(base_imports)
    import_statements.extend(['import os', 'import sys'])

    # Add AWS service imports, sorted by module
    for module_path in sorted(imports_dict.keys()):
        if module_path == '__unknown__':
            # Add unknown services as comments with warning
            for comment, _ in imports_dict[module_path]:
                import_statements.append(f'# {comment}  # Graceful fallback: using Node() for unknown service kind')
        else:
            class_names = [cls for cls, _ in imports_dict[module_path]]
            if len(class_names) == 1:
                import_statements.append(f'from {module_path} import {class_names[0]}')
            else:
                # Multi-line import for readability
                classes_str = ', '.join(class_names)
                import_statements.append(f'from {module_path} import {classes_str}')

    return import_statements


def sanitize_node_id(node_id: str) -> str:
    """
    Convert a node ID to a valid Python variable name.

    Args:
        node_id: Node ID from YAML (e.g., 'api-gateway', 'My Lambda')

    Returns:
        Valid Python identifier

    Examples:
        >>> sanitize_node_id('api-gateway')
        'api_gateway'

        >>> sanitize_node_id('My Lambda Function')
        'my_lambda_function'
    """
    # Convert to lowercase
    var_name = node_id.lower()

    # Replace hyphens and spaces with underscores
    var_name = var_name.replace('-', '_').replace(' ', '_')

    # Remove any non-alphanumeric characters except underscores
    var_name = ''.join(c if c.isalnum() or c == '_' else '' for c in var_name)

    # Ensure it doesn't start with a number
    if var_name and var_name[0].isdigit():
        var_name = 'node_' + var_name

    # Avoid Python keywords
    python_keywords = {'and', 'as', 'assert', 'break', 'class', 'continue', 'def',
                       'del', 'elif', 'else', 'except', 'finally', 'for', 'from',
                       'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal',
                       'not', 'or', 'pass', 'raise', 'return', 'try', 'while',
                       'with', 'yield'}
    if var_name in python_keywords:
        var_name = var_name + '_node'

    return var_name or 'unnamed_node'


def get_class_name_for_service(service_kind: str) -> str:
    """
    Get the class name for a service kind.

    Args:
        service_kind: Service kind from YAML

    Returns:
        Class name for the diagrams library, or 'Node' for unknown services
    """
    import_info = get_import_for_service(service_kind)
    if import_info:
        return import_info[1]
    return 'Node'
