"""Core utility functions for the CLI.

This module provides common utilities used across the CLI:
- JSON output formatting for skill integration
- Error handling and exception management
- Logging configuration
- Platform detection
- File system utilities
"""

import json
import logging
import platform
import sys
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from rich.console import Console
from rich.logging import RichHandler
from rich.panel import Panel

# Initialize console for rich output
console = Console()


class OutputStatus(str, Enum):
    """Status types for CLI output."""

    SUCCESS = "success"
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class CLIError(Exception):
    """Base exception for CLI errors."""

    def __init__(self, message: str, exit_code: int = 1):
        self.message = message
        self.exit_code = exit_code
        super().__init__(self.message)


class ValidationError(CLIError):
    """Exception for validation errors."""

    pass


class FileNotFoundError(CLIError):
    """Exception for missing files."""

    pass


class ConfigurationError(CLIError):
    """Exception for configuration errors."""

    pass


def setup_logging(verbose: bool = False, quiet: bool = False) -> logging.Logger:
    """Configure logging with Rich handler.

    Args:
        verbose: Enable verbose (DEBUG) logging
        quiet: Suppress all logging except errors

    Returns:
        Configured logger instance
    """
    level = logging.ERROR if quiet else (logging.DEBUG if verbose else logging.INFO)

    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(console=console, rich_tracebacks=True, show_path=False)],
    )

    logger = logging.getLogger("aws_arch")
    logger.setLevel(level)

    return logger


def format_json_output(
    status: OutputStatus,
    message: str,
    data: Optional[Dict[str, Any]] = None,
    errors: Optional[List[str]] = None,
    warnings: Optional[List[str]] = None,
) -> str:
    """Format output as JSON for skill consumption.

    Args:
        status: Output status (success, error, warning, info)
        message: Human-readable message
        data: Optional data payload
        errors: Optional list of error messages
        warnings: Optional list of warning messages

    Returns:
        JSON string representation

    Example:
        >>> format_json_output(
        ...     OutputStatus.SUCCESS,
        ...     "Generated 5 diagrams",
        ...     data={"count": 5, "path": "/path/to/diagrams"}
        ... )
        '{"status": "success", "message": "Generated 5 diagrams", ...}'
    """
    output = {
        "status": status.value,
        "message": message,
    }

    if data is not None:
        output["data"] = data

    if errors:
        output["errors"] = errors

    if warnings:
        output["warnings"] = warnings

    return json.dumps(output, indent=2)


def print_json_output(
    status: OutputStatus,
    message: str,
    data: Optional[Dict[str, Any]] = None,
    errors: Optional[List[str]] = None,
    warnings: Optional[List[str]] = None,
) -> None:
    """Print formatted JSON output to stdout.

    Args:
        status: Output status
        message: Human-readable message
        data: Optional data payload
        errors: Optional list of errors
        warnings: Optional list of warnings
    """
    output = format_json_output(status, message, data, errors, warnings)
    console.print(output)


def print_success(message: str, data: Optional[Dict[str, Any]] = None) -> None:
    """Print success message with rich formatting.

    Args:
        message: Success message
        data: Optional data to display
    """
    console.print(f"[green]✓[/green] {message}")
    if data:
        console.print(Panel.fit(json.dumps(data, indent=2), title="Details", border_style="green"))


def print_error(message: str, details: Optional[str] = None) -> None:
    """Print error message with rich formatting.

    Args:
        message: Error message
        details: Optional detailed error information
    """
    console.print(f"[red]✗[/red] {message}", style="bold red")
    if details:
        console.print(Panel.fit(details, title="Error Details", border_style="red"))


def print_warning(message: str) -> None:
    """Print warning message with rich formatting.

    Args:
        message: Warning message
    """
    console.print(f"[yellow]⚠[/yellow] {message}", style="bold yellow")


def print_info(message: str) -> None:
    """Print info message with rich formatting.

    Args:
        message: Info message
    """
    console.print(f"[blue]ℹ[/blue] {message}")


def detect_platform() -> Dict[str, str]:
    """Detect platform information.

    Returns:
        Dictionary with platform details:
        - system: OS name (Linux, Darwin, Windows)
        - version: OS version
        - machine: Machine type (x86_64, arm64, etc.)
        - python_version: Python version

    Example:
        >>> detect_platform()
        {
            'system': 'Darwin',
            'version': '24.6.0',
            'machine': 'arm64',
            'python_version': '3.11.5'
        }
    """
    return {
        "system": platform.system(),
        "version": platform.version(),
        "machine": platform.machine(),
        "python_version": platform.python_version(),
    }


def is_windows() -> bool:
    """Check if running on Windows.

    Returns:
        True if Windows, False otherwise
    """
    return platform.system() == "Windows"


def is_macos() -> bool:
    """Check if running on macOS.

    Returns:
        True if macOS, False otherwise
    """
    return platform.system() == "Darwin"


def is_linux() -> bool:
    """Check if running on Linux.

    Returns:
        True if Linux, False otherwise
    """
    return platform.system() == "Linux"


def ensure_directory(path: Union[str, Path]) -> Path:
    """Ensure directory exists, create if it doesn't.

    Args:
        path: Directory path to ensure

    Returns:
        Path object for the directory

    Raises:
        ConfigurationError: If directory cannot be created
    """
    path_obj = Path(path)
    try:
        path_obj.mkdir(parents=True, exist_ok=True)
        return path_obj
    except Exception as e:
        raise ConfigurationError(f"Cannot create directory {path}: {e}")


def validate_file_exists(path: Union[str, Path], file_type: str = "file") -> Path:
    """Validate that a file exists.

    Args:
        path: File path to validate
        file_type: Description of file type for error messages

    Returns:
        Path object for the file

    Raises:
        FileNotFoundError: If file doesn't exist
    """
    path_obj = Path(path)
    if not path_obj.exists():
        raise FileNotFoundError(f"{file_type} not found: {path}")
    if not path_obj.is_file():
        raise ValidationError(f"{path} is not a file")
    return path_obj


def validate_directory_exists(path: Union[str, Path], dir_type: str = "directory") -> Path:
    """Validate that a directory exists.

    Args:
        path: Directory path to validate
        dir_type: Description of directory type for error messages

    Returns:
        Path object for the directory

    Raises:
        FileNotFoundError: If directory doesn't exist
    """
    path_obj = Path(path)
    if not path_obj.exists():
        raise FileNotFoundError(f"{dir_type} not found: {path}")
    if not path_obj.is_dir():
        raise ValidationError(f"{path} is not a directory")
    return path_obj


def find_files(
    directory: Union[str, Path], pattern: str = "*", recursive: bool = False
) -> List[Path]:
    """Find files in directory matching pattern.

    Args:
        directory: Directory to search
        pattern: Glob pattern (default: all files)
        recursive: Search recursively (default: False)

    Returns:
        List of Path objects for matching files

    Example:
        >>> find_files("yaml_specs", "*.yaml")
        [Path('yaml_specs/01_c4_context.yaml'), ...]
    """
    directory_path = Path(directory)
    if not directory_path.exists():
        return []

    if recursive:
        return list(directory_path.rglob(pattern))
    else:
        return list(directory_path.glob(pattern))


def get_file_size(path: Union[str, Path]) -> int:
    """Get file size in bytes.

    Args:
        path: File path

    Returns:
        File size in bytes

    Raises:
        FileNotFoundError: If file doesn't exist
    """
    path_obj = validate_file_exists(path)
    return path_obj.stat().st_size


def format_file_size(size_bytes: int) -> str:
    """Format file size in human-readable format.

    Args:
        size_bytes: Size in bytes

    Returns:
        Formatted string (e.g., "1.5 MB", "42 KB")

    Example:
        >>> format_file_size(1536)
        '1.5 KB'
        >>> format_file_size(1048576)
        '1.0 MB'
    """
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} PB"


def safe_read_file(path: Union[str, Path], encoding: str = "utf-8") -> str:
    """Safely read file contents with error handling.

    Args:
        path: File path to read
        encoding: File encoding (default: utf-8)

    Returns:
        File contents as string

    Raises:
        FileNotFoundError: If file doesn't exist
        CLIError: If file cannot be read
    """
    path_obj = validate_file_exists(path)
    try:
        return path_obj.read_text(encoding=encoding)
    except UnicodeDecodeError:
        # Try with different encoding
        try:
            return path_obj.read_text(encoding="latin-1")
        except Exception as e:
            raise CLIError(f"Cannot read file {path}: {e}")
    except Exception as e:
        raise CLIError(f"Cannot read file {path}: {e}")


def safe_write_file(
    path: Union[str, Path], content: str, encoding: str = "utf-8", overwrite: bool = False
) -> Path:
    """Safely write content to file with error handling.

    Args:
        path: File path to write
        content: Content to write
        encoding: File encoding (default: utf-8)
        overwrite: Allow overwriting existing file (default: False)

    Returns:
        Path object for written file

    Raises:
        ValidationError: If file exists and overwrite is False
        CLIError: If file cannot be written
    """
    path_obj = Path(path)

    if path_obj.exists() and not overwrite:
        raise ValidationError(f"File already exists: {path}. Use overwrite=True to replace.")

    try:
        # Ensure parent directory exists
        path_obj.parent.mkdir(parents=True, exist_ok=True)
        path_obj.write_text(content, encoding=encoding)
        return path_obj
    except Exception as e:
        raise CLIError(f"Cannot write file {path}: {e}")
