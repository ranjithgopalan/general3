"""DOT to Draw.io Converter.

Converts Graphviz DOT files to Draw.io XML format with native AWS icons.

Key features:
- Uses pydot library for proper DOT parsing
- Extracts positions and bounding boxes from Graphviz output
- Y-axis inversion (Graphviz bottom-left → Draw.io top-left)
- Maps AWS services to native Draw.io shapes (mxgraph.aws3/aws4)
- Preserves edge styling, colors, and labels
- Recursive processing of nested subgraphs
"""

import uuid
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from xml.dom import minidom

import pydot

from aws_arch.core.utils import CLIError, safe_read_file

# AWS Icon mapping - Draw.io's built-in AWS shapes (35+ services)
AWS_ICON_MAP = {
    # Compute
    "lambda": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.lambda_function;fillColor=#F58534;gradientColor=none;",
    "lambda-function": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.lambda_function;fillColor=#F58534;gradientColor=none;",
    "ec2": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.ec2;fillColor=#F58534;gradientColor=none;",
    "ecs": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws4.ecs;fillColor=#F58534;gradientColor=none;",
    "fargate": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws4.fargate;fillColor=#F58534;gradientColor=none;",
    "batch": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws4.batch;fillColor=#F58534;gradientColor=none;",
    "eks": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws4.eks;fillColor=#F58534;gradientColor=none;",
    # Database
    "aurora": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.rds;fillColor=#2E73B8;gradientColor=none;",
    "rds": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.rds;fillColor=#2E73B8;gradientColor=none;",
    "dynamodb": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.dynamodb;fillColor=#2E73B8;gradientColor=none;",
    "elasticache": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.elasticache;fillColor=#2E73B8;gradientColor=none;",
    "redshift": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.redshift;fillColor=#2E73B8;gradientColor=none;",
    # Network
    "api-gateway": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.api_gateway;fillColor=#5294CF;gradientColor=none;",
    "api_gateway": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.api_gateway;fillColor=#5294CF;gradientColor=none;",
    "vpc": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.vpc;fillColor=#F58534;gradientColor=none;",
    "nat-gateway": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.vpc_nat_gateway;fillColor=#F58534;gradientColor=none;",
    "nat_gateway": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.vpc_nat_gateway;fillColor=#F58534;gradientColor=none;",
    "cloudfront": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.cloudfront;fillColor=#5294CF;gradientColor=none;",
    "route53": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.route_53;fillColor=#5294CF;gradientColor=none;",
    "elb": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.elastic_load_balancing;fillColor=#F58534;gradientColor=none;",
    "alb": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.application_load_balancer;fillColor=#F58534;gradientColor=none;",
    # Storage
    "s3": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.s3;fillColor=#E05243;gradientColor=none;",
    "simple-storage-service-s3": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.s3;fillColor=#E05243;gradientColor=none;",
    "efs": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws4.efs;fillColor=#E05243;gradientColor=none;",
    "ebs": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.ebs;fillColor=#E05243;gradientColor=none;",
    # Security
    "secrets-manager": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.permissions;fillColor=#759C3E;gradientColor=none;",
    "secretsmanager": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.permissions;fillColor=#759C3E;gradientColor=none;",
    "iam": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.iam;fillColor=#759C3E;gradientColor=none;",
    "kms": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.kms;fillColor=#759C3E;gradientColor=none;",
    "cognito": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws4.cognito;fillColor=#759C3E;gradientColor=none;",
    "waf": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws4.waf;fillColor=#759C3E;gradientColor=none;",
    # Management & Monitoring
    "cloudwatch": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.cloudwatch;fillColor=#759C3E;gradientColor=none;",
    "cloudwatch-logs": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.cloudwatch;fillColor=#759C3E;gradientColor=none;",
    "cloudwatch-alarm": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.cloudwatch;fillColor=#759C3E;gradientColor=none;",
    "xray": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.cloudwatch;fillColor=#759C3E;gradientColor=none;",
    "x-ray": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.cloudwatch;fillColor=#759C3E;gradientColor=none;",
    "cloudtrail": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.cloudtrail;fillColor=#759C3E;gradientColor=none;",
    # Integration
    "sns": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.sns;fillColor=#D9A741;gradientColor=none;",
    "simple-notification-service-sns": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.sns;fillColor=#D9A741;gradientColor=none;",
    "sqs": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.sqs;fillColor=#D9A741;gradientColor=none;",
    "simple-queue-service-sqs": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.sqs;fillColor=#D9A741;gradientColor=none;",
    "eventbridge": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws4.eventbridge;fillColor=#E7157B;gradientColor=none;",
    "step-functions": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.step_functions;fillColor=#D9A741;gradientColor=none;",
    # Analytics
    "kinesis": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws3.kinesis;fillColor=#5294CF;gradientColor=none;",
    "glue": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws4.glue;fillColor=#8C4FFF;gradientColor=none;",
    "athena": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws4.athena;fillColor=#8C4FFF;gradientColor=none;",
    "emr": "outlineConnect=0;dashed=0;verticalLabelPosition=bottom;verticalAlign=top;align=center;html=1;shape=mxgraph.aws4.emr;fillColor=#8C4FFF;gradientColor=none;",
}


class ConversionResult:
    """Result of DOT to Draw.io conversion."""

    def __init__(
        self,
        input_file: str,
        output_file: str,
        success: bool,
        node_count: int = 0,
        edge_count: int = 0,
        aws_icon_count: int = 0,
        error: Optional[str] = None,
    ):
        self.input_file = input_file
        self.output_file = output_file
        self.success = success
        self.node_count = node_count
        self.edge_count = edge_count
        self.aws_icon_count = aws_icon_count
        self.error = error

    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON output."""
        result = {
            "input_file": self.input_file,
            "output_file": self.output_file,
            "success": self.success,
            "node_count": self.node_count,
            "edge_count": self.edge_count,
            "aws_icon_count": self.aws_icon_count,
        }
        if self.error:
            result["error"] = self.error
        return result


class DrawioConverter:
    """Converter for DOT files to Draw.io XML format."""

    @staticmethod
    def _get_aws_icon_style(node) -> Optional[str]:
        """Determine AWS icon style from node image path or label.

        Returns:
            Draw.io style string or None if not an AWS service
        """
        image_path = node.get_image()
        label = (node.get_label() or "").lower()

        # Try from image path
        if image_path:
            image_path = image_path.strip('"').lower().replace("\\", "/")
            # Extract service name from path like "resources/aws/compute/lambda.png"
            if "/aws/" in image_path:
                parts = image_path.split("/aws/")[-1].split("/")
                if len(parts) >= 2:
                    service = parts[1].replace(".png", "")
                    if service in AWS_ICON_MAP:
                        return AWS_ICON_MAP[service]
                    # Try with underscores
                    service_us = service.replace("-", "_")
                    if service_us in AWS_ICON_MAP:
                        return AWS_ICON_MAP[service_us]

        # Try from label
        for key in AWS_ICON_MAP.keys():
            if key in label:
                return AWS_ICON_MAP[key]

        return None

    @staticmethod
    def _sanitize_label(label: Optional[str]) -> str:
        """Clean up label text from Graphviz format."""
        if not label:
            return ""
        label = label.strip('"')
        label = label.replace("\\n", "\n")
        label = label.replace("\\N", "")
        return label

    @staticmethod
    def _parse_pos(pos_str: Optional[str]) -> Tuple[Optional[float], Optional[float]]:
        """Parse position string from Graphviz format (e.g., '100,200')."""
        if not pos_str:
            return None, None

        pos_str = pos_str.strip('"').strip()

        if "," in pos_str and " " not in pos_str:
            parts = pos_str.split(",")
            if len(parts) >= 2:
                try:
                    x = float(parts[0])
                    y = float(parts[1].rstrip("!"))
                    return x, y
                except ValueError:
                    pass
        return None, None

    @staticmethod
    def _parse_bb(bb_str: Optional[str]) -> Optional[Dict[str, float]]:
        """Parse bounding box string: llx,lly,urx,ury."""
        if not bb_str:
            return None
        bb_str = bb_str.strip('"')
        parts = bb_str.split(",")
        if len(parts) == 4:
            try:
                return {
                    "llx": float(parts[0]),
                    "lly": float(parts[1]),
                    "urx": float(parts[2]),
                    "ury": float(parts[3]),
                }
            except ValueError:
                pass
        return None

    @staticmethod
    def _parse_color(color_str: Optional[str]) -> str:
        """Convert Graphviz color to hex format."""
        if not color_str:
            return "#333333"
        color_str = color_str.strip('"')

        color_map = {
            "blue": "#0000FF",
            "green": "#00FF00",
            "red": "#FF0000",
            "purple": "#800080",
            "orange": "#FFA500",
            "gray": "#696969",
            "grey": "#696969",
            "darkblue": "#00008B",
            "darkgreen": "#006400",
            "brown": "#8B4513",
            "teal": "#008080",
            "black": "#000000",
            "white": "#FFFFFF",
        }

        if color_str.lower() in color_map:
            return color_map[color_str.lower()]

        if color_str.startswith("#"):
            return color_str

        return "#333333"

    @staticmethod
    def _get_edge_style(edge) -> str:
        """Get Draw.io style string for an edge."""
        attrs = edge.obj_dict.get("attributes", {})
        style = attrs.get("style", "")
        color = DrawioConverter._parse_color(attrs.get("color", "#7B8894"))

        stroke_style = ""
        if "dashed" in style:
            stroke_style = ";dashed=1"
        elif "dotted" in style:
            stroke_style = ";dashed=1;dashPattern=1 2"
        elif "bold" in style:
            stroke_style = ";strokeWidth=3"

        return f"edgeStyle=orthogonalEdgeStyle;rounded=0;strokeColor={color}{stroke_style};endArrow=classic;html=1;"

    @staticmethod
    def _get_all_nodes_recursive(graph_or_subgraph) -> List:
        """Recursively get all nodes from graph and all nested subgraphs."""
        nodes = list(graph_or_subgraph.get_nodes())
        for subgraph in graph_or_subgraph.get_subgraphs():
            nodes.extend(DrawioConverter._get_all_nodes_recursive(subgraph))
        return nodes

    @staticmethod
    def _get_all_edges_recursive(graph_or_subgraph) -> List:
        """Recursively get all edges from graph and all nested subgraphs."""
        edges = list(graph_or_subgraph.get_edges())
        for subgraph in graph_or_subgraph.get_subgraphs():
            edges.extend(DrawioConverter._get_all_edges_recursive(subgraph))
        return edges

    def convert_file(
        self, dot_file_path: str, output_path: Optional[str] = None
    ) -> ConversionResult:
        """Convert DOT file to Draw.io XML format with AWS icons.

        Args:
            dot_file_path: Path to input .dot file
            output_path: Path to output .drawio.xml file (optional)

        Returns:
            ConversionResult object with conversion details
        """
        try:
            # Parse DOT file using pydot with UTF-8 encoding
            dot_content = safe_read_file(dot_file_path)

            graphs = pydot.graph_from_dot_data(dot_content)
            if not graphs:
                raise CLIError(f"Could not parse DOT file: {dot_file_path}")

            graph = graphs[0]

            # Get graph bounding box for page size
            graph_bb = None
            for attr in graph.get_graph_defaults():
                if isinstance(attr, dict) and "bb" in attr:
                    graph_bb = self._parse_bb(attr["bb"])
                    break

            page_width = 1600 if not graph_bb else graph_bb["urx"] - graph_bb["llx"] + 100
            page_height = (
                1200 if not graph_bb else graph_bb["ury"] - graph_bb["lly"] + 100
            )

            # Get graph label
            graph_label = graph.get_label()
            if graph_label:
                graph_label = self._sanitize_label(graph_label)
            else:
                graph_label = "AWS Architecture"

            # Create mxfile structure
            mxfile = ET.Element(
                "mxfile",
                {
                    "host": "app.diagrams.net",
                    "modified": "2026-02-16T00:00:00.000Z",
                    "agent": "AWS Architecture CLI",
                    "version": "24.7.17",
                    "type": "device",
                },
            )

            diagram = ET.SubElement(
                mxfile, "diagram", {"id": str(uuid.uuid4()), "name": graph_label}
            )

            mxGraphModel = ET.SubElement(
                diagram,
                "mxGraphModel",
                {
                    "dx": "0",
                    "dy": "0",
                    "grid": "1",
                    "gridSize": "10",
                    "guides": "1",
                    "tooltips": "1",
                    "connect": "1",
                    "arrows": "1",
                    "fold": "1",
                    "page": "1",
                    "pageScale": "1",
                    "pageWidth": str(int(page_width)),
                    "pageHeight": str(int(page_height)),
                    "math": "0",
                    "shadow": "0",
                },
            )

            root = ET.SubElement(mxGraphModel, "root")

            # Add default cells
            ET.SubElement(root, "mxCell", {"id": "0"})
            ET.SubElement(root, "mxCell", {"id": "1", "parent": "0"})

            node_id_map = {}
            cell_counter = 2
            aws_icon_count = 0

            # Process all nodes recursively
            all_nodes = self._get_all_nodes_recursive(graph)

            for node in all_nodes:
                node_name = node.get_name()
                if node_name in ["node", "graph", "edge"]:
                    continue

                # Get node attributes
                label = self._sanitize_label(node.get_label() or node_name)
                pos = node.get_pos()
                x, y = self._parse_pos(pos)

                # Get dimensions
                try:
                    width = float(node.get_width() or 1.4) * 72
                    height = float(node.get_height() or 1.4) * 72
                except (ValueError, TypeError):
                    width, height = 78, 78

                # Default position if not found
                if x is None:
                    x = 100
                    y = 100
                else:
                    # Invert Y coordinate (Graphviz bottom-left → Draw.io top-left)
                    y = page_height - y - 20

                # Get AWS icon style
                aws_style = self._get_aws_icon_style(node)

                if aws_style:
                    style = aws_style
                    node_width = 78
                    node_height = 78
                    aws_icon_count += 1
                else:
                    style = "rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc;strokeColor=#6c8ebf;"
                    node_width = width
                    node_height = height

                # Create node cell
                node_id = str(cell_counter)
                cell_counter += 1
                node_id_map[node_name] = node_id

                node_cell = ET.SubElement(
                    root,
                    "mxCell",
                    {
                        "id": node_id,
                        "value": label.replace("\n", "<br>"),
                        "style": style,
                        "parent": "1",
                        "vertex": "1",
                    },
                )

                # Center node on position
                ET.SubElement(
                    node_cell,
                    "mxGeometry",
                    {
                        "x": str(int(x - node_width / 2)),
                        "y": str(int(y - node_height / 2)),
                        "width": str(int(node_width)),
                        "height": str(int(node_height)),
                        "as": "geometry",
                    },
                )

            # Process all edges recursively
            all_edges = self._get_all_edges_recursive(graph)

            for edge in all_edges:
                source = edge.get_source()
                target = edge.get_destination()

                source_id = node_id_map.get(source)
                target_id = node_id_map.get(target)

                if not source_id or not target_id:
                    continue

                edge_label = self._sanitize_label(edge.get_label() or "")
                edge_style = self._get_edge_style(edge)

                edge_id = str(cell_counter)
                cell_counter += 1

                edge_cell = ET.SubElement(
                    root,
                    "mxCell",
                    {
                        "id": edge_id,
                        "value": edge_label,
                        "style": edge_style,
                        "parent": "1",
                        "source": source_id,
                        "target": target_id,
                        "edge": "1",
                    },
                )

                ET.SubElement(edge_cell, "mxGeometry", {"relative": "1", "as": "geometry"})

            # Count valid nodes (exclude metadata nodes)
            node_count = len(
                [n for n in all_nodes if n.get_name() not in ["node", "graph", "edge"]]
            )
            edge_count = len(all_edges)

            # Convert to pretty XML
            xml_str = minidom.parseString(
                ET.tostring(mxfile, encoding="unicode")
            ).toprettyxml(indent="  ")

            # Clean up XML declaration
            lines = xml_str.split("\n")
            if lines[0].startswith("<?xml"):
                xml_str = "\n".join(lines[1:])

            # Determine output path
            if output_path is None:
                input_path = Path(dot_file_path)
                output_path = str(input_path.with_suffix(".drawio.xml"))

            # Write to file
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(xml_str)

            return ConversionResult(
                input_file=dot_file_path,
                output_file=output_path,
                success=True,
                node_count=node_count,
                edge_count=edge_count,
                aws_icon_count=aws_icon_count,
            )

        except Exception as e:
            return ConversionResult(
                input_file=dot_file_path,
                output_file=output_path or "",
                success=False,
                error=str(e),
            )

    def convert_files(
        self, dot_files: List[str], output_dir: Optional[str] = None
    ) -> List[ConversionResult]:
        """Convert multiple DOT files to Draw.io XML format.

        Args:
            dot_files: List of DOT file paths
            output_dir: Optional output directory for all files

        Returns:
            List of ConversionResult objects
        """
        results = []

        for dot_file in dot_files:
            if output_dir:
                input_path = Path(dot_file)
                output_path = str(
                    Path(output_dir) / f"{input_path.stem}.drawio.xml"
                )
            else:
                output_path = None

            result = self.convert_file(dot_file, output_path)
            results.append(result)

        return results
