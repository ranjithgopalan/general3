"""Configuration modules for AWS Architecture CLI."""
