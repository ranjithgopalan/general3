﻿# aidlc-tech-architect

AWS architecture diagram generator that transforms Technical Design Documents (TDDs) into executable architecture diagrams through an automated 3-phase workflow.

## Description

This plugin generates professional AWS architecture diagrams from Technical Design Documents using the mingrammer/diagrams library with official AWS icons. It automates the complete workflow: TDD analysis → YAML specification generation → Python diagram script generation → PNG/DOT diagram execution → Draw.io XML conversion.

The plugin includes specialized agents for system architecture design, ADR creation, and TDD generation, with an integrated CLI for project management and diagram operations.

## When to Use

Use this plugin when you need to:
- **Generate AWS architecture diagrams** from existing Technical Design Documents
- **Create system architecture designs** from business requirements
- **Document architecture decisions** with Architecture Decision Records (ADRs)
- **Generate comprehensive Technical Design Documents (TDDs)** for implementation teams
- **Convert diagrams to Draw.io format** for collaborative editing and sharing
- **Validate AWS architecture specifications** against requirements

## Available Skills

### `aws-diagram-generator`
Fully automated 3-phase workflow for generating AWS architecture diagrams from TDDs without user approval gates.

**Workflow:**
- **Phase 0 (Initialization):** Setup virtual environment, detect/create AWS architecture projects, collect TDD files
- **Phase 1 (YAML Generation):** Invoke `yaml-from-tdd` skill to extract system components and generate YAML specifications for 5 diagram types
- **Phase 2 (Diagrams):** Generate Python scripts from YAML files, execute with Graphviz to produce PNG/DOT diagrams
- **Phase 3 (Finalize):** Convert diagrams to Draw.io XML format with native AWS icons

**Usage:**
```bash
/aidlc-tech-architect:aws-diagram-generator
```

### `yaml-from-tdd`
Generates rich YAML specifications from Technical Design Documents using semantic analysis. Extracts Lambda functions, business-domain clusters, API endpoints, and network topology.

**Input:** Path to TDD file
**Output:** YAML specifications saved to project's `yaml_specs/` folder
**Integration:** Phase 1 of aws-diagram-generator workflow

**Usage:**
```bash
/aidlc-tech-architect:yaml-from-tdd
```

### `aws-arch-cli-reference`
Reference documentation for aws-arch CLI commands. Provides command reference for project management, diagram operations, YAML validation, and Draw.io conversion.

## Generated Artifacts

| Artifact | Description | Format |
|----------|-------------|--------|
| YAML Specifications | C4 Context, Container, VPC, Data Flow, Monitoring | `.yaml` |
| Python Diagram Scripts | Executable diagram generation code | `.py` |
| PNG Diagrams | Visual architecture diagrams | `.png` |
| DOT Diagrams | Graphviz dot format for further processing | `.dot` |
| Draw.io Files | Interactive diagrams for collaborative editing | `.drawio.xml` |

## Plugin Structure

```
aidlc-tech-architect/
├── agents/
│   ├── tech-architect.md              # Router agent (orchestration)
│   ├── architecture-designer.md       # System architecture design
│   ├── adr-generator.md               # ADR generation
│   └── tdd-generator.md               # TDD generation
├── skills/
│   ├── aws-diagram-generator/         # 3-phase diagram generation workflow
│   ├── yaml-from-tdd/                 # YAML spec extraction from TDDs
│   └── aws-arch-cli-reference/        # CLI command reference
├── cli/
│   ├── aws_arch/                      # CLI Python package
│   │   ├── cli.py                     # Typer CLI application
│   │   ├── commands/                  # Command implementations
│   │   │   ├── project_cmd.py         # Project management
│   │   │   ├── diagram_cmd.py         # Diagram operations
│   │   │   ├── python_cmd.py          # Python script generation
│   │   │   ├── yaml_cmd.py            # YAML validation
│   │   │   └── drawio_cmd.py          # Draw.io conversion
│   │   └── core/                      # Core services
│   │       ├── venv_manager.py        # Virtual environment setup
│   │       ├── project_manager.py     # Project lifecycle
│   │       ├── yaml_transformer.py    # TDD analysis & YAML generation
│   │       ├── python_generator.py    # Python script generation
│   │       ├── diagram_executor.py    # PNG/DOT diagram execution
│   │       └── drawio_converter.py    # Draw.io XML conversion
│   └── templates/                     # YAML templates for diagrams
├── __tests__/                         # Test cases
├── acceptance-criteria.md             # Acceptance criteria
└── README.md                          # This file
```

## Agent Architecture

The plugin includes specialized agents for architecture design, orchestrated by a router agent:

### Router Agent: tech-architect
- **Role:** Context engineering and request routing
- **Responsibilities:** Intent detection, context ADLCing, agent coordination
- **Routing Decisions:**
  - `architecture-designer` → System architecture design from requirements
  - `adr-generator` → Architecture Decision Records
  - `tdd-generator` → Technical Design Documents

### Specialized Designer Agents
| Agent | Input | Output | Use Case |
|-------|-------|--------|----------|
| architecture-designer | Business requirements, BRD | System architecture markdown | Design systems from scratch |
| adr-generator | Technical decisions | ADR-XXX documents | Document technology choices |
| tdd-generator | Architecture + ADRs + context | Complete TDD | Blueprint for implementation |

## CLI Tools

The `cli/aws_arch/` directory contains a Typer-based CLI application with the following command groups:

- **project** — Create, scan, and validate AWS architecture projects
- **yaml** — Validate YAML specifications
- **python** — Generate Python diagram scripts from YAML
- **diagram** — Execute diagram generation and check prerequisites
- **drawio** — Convert diagrams to Draw.io XML format

All CLI commands use a managed virtual environment and require Python 3.8+. See aws-arch-cli-reference skill for detailed command documentation.

## Workflow Example

### Generate diagrams from TDD:

1. **Start the workflow:**
   ```bash
   /aidlc-tech-architect:aws-diagram-generator
   ```

2. **The plugin handles automatically:**
   - Virtual environment setup with aws-arch CLI
   - Project creation/detection
   - TDD file collection
   - YAML specification generation via yaml-from-tdd skill
   - Python script generation
   - PNG/DOT diagram execution
   - Draw.io XML conversion

3. **Output locations:**
   ```
   your-project/
   ├── requirements/          # TDD source files
   ├── yaml_specs/           # Generated YAML specifications
   ├── python_scripts/       # Generated Python diagram scripts
   ├── diagrams/             # PNG and DOT diagram files
   └── drawio/               # Draw.io XML files
   ```

## Key Features

- **Fully Automated** — 3-phase workflow runs end-to-end without user approval gates
- **Virtual Environment Management** — Automatic setup, dependency installation, AWS icon caching
- **Comprehensive Output** — Generates YAML, Python scripts, PNG/DOT diagrams, and Draw.io files
- **Error Resilience** — Single pause point per phase with clear recovery options
- **Graceful Degradation** — Unknown service kinds render as generic nodes with labels
- **Professional Output** — Official AWS icons via mingrammer/diagrams library

## Integration

This plugin integrates with:
- **aidlc-business-analyst** — Input: BRD/EPIC for TDD generation
- **gather-lambda** — Input: Service specifications for architecture design
- **uw-axis** — Input: UI requirements for complete system design
- **gather-code** — Input: Architecture artifacts for validation
- **aidlc-security** — Input: Architecture diagrams for security review

## Technology Stack

| Component | Technology |
|-----------|-----------|
| Diagram Generation | Python, mingrammer/diagrams, Graphviz |
| CLI Framework | Typer (Python CLI) |
| YAML Specs | PyYAML |
| Draw.io Format | XML conversion via diagrams library |
| Project Management | Python pathlib, JSON state tracking |

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 0.9.1 | 2026-02-06 | Plugin manifest fix: directory format for skills and agents |
| 0.9.0 | Initial | AWS diagram generation from TDDs, YAML validation, Draw.io conversion, integrated CLI, specialized agents for architecture/ADR/TDD design |
