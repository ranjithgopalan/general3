# AIDLC-tech-architect Changelog

All notable changes to the AIDLC-tech-architect plugin will be documented in this file.

## **Component Documentation**

### AWS Diagram Generator Skill (`skills/aws-diagram-generator/SKILL.md`)
Fully automated 3-phase workflow for generating AWS architecture diagrams from Technical Design Documents:
- **Phase 0 (Initialization)**: Setup virtual environment, detect/create AWS architecture projects, collect TDD files
- **Phase 1 (YAML Generation)**: Invoke `yaml-from-tdd` skill to extract system components from TDDs and generate YAML specifications for 5 diagram types (C4 context, container, VPC, data flow, monitoring)
- **Phase 2 (Diagrams)**: Generate Python diagram scripts from YAML files, execute scripts to produce PNG/DOT diagrams with Graphviz
- **Phase 3 (Finalize)**: Convert diagrams to Draw.io XML format with native AWS icons

No approval gates—runs end-to-end automatically with single error pause per phase.

### CLI (`cli/aws_arch/`)
Typer-based CLI application providing core infrastructure services:
- **Commands**: `project` (create/scan/validate), `diagram` (check prerequisites/execute), `python` (generate scripts from YAML), `yaml` (validate), `drawio` (convert to XML)
- **Core Services**: VenvManager (virtual environment setup), ProjectManager (AWS architecture project lifecycle), PythonGenerator (diagrams library script generation), DiagramExecutor (PNG/DOT execution), DrawioConverter (XML conversion), YamlValidator/YamlTransformer (spec validation), AwsMapping (service type mappings)
- **Usage**: `python -m aws_arch.cli <command> <args>` (always use venv python, never bare `aws-arch`)

---

## **1.0.0** - Initial Release (2026-02-25)

### Changed

- Migrated virtual environment from plugin-specific `~/.claude/AIDLC-tech-architect/venv/` to shared `~/.claude/venvs/ADLC/` for consistency with other ADLC plugins

---

## **0.9.1** - Plugin Manifest Fix (2026-02-06)

### Bug Fixes

- Fixed plugin.json path references to match actual directory structure
- Updated skills to use directory format (./skills/generate, ./skills/explore, ./skills/validate)

---

## **0.9.0** - Initial Version

### Added

- Technical architecture generation capabilities
- ADR (Architecture Decision Record) generation
- Technology stack recommendations
- Technical Design Document creation
- Specialized agents:
  - tech-architect.md - Main routing agent
  - architecture-designer.md - System architecture design
  - adr-generator.md - ADR creation
  - tdd-generator.md - Technical design documents
