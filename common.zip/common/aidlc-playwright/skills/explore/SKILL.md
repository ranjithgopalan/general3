---
name: explore
description: Explore an existing Playwright suite and report its coverage, selector health and flake risk.
triggers:
  - "explore e2e"
  - "review playwright suite"
  - "e2e coverage"
---

# AIDLC-playwright: explore

## Agent Invocation

Use the Task tool with `subagent_type="router"` and the following prompt:

"""
## User Request
$ARGUMENTS

## Intent: EXPLORE

Report, without modifying anything:

- which stories are covered, and which are not
- selector health: how many structural CSS selectors remain, and where
- flake risk: fixed sleeps, order dependence, shared mutable state
- whether trace/video/screenshot capture and JUnit output are configured
- any hardcoded URL or credential

Rank findings by how likely each is to cause a false failure. A suite that cries
wolf gets skipped in CI, and then it protects nothing.
"""

## Output

An analysis report with file:line evidence. No changes.
