---
name: e2e-patterns
description: Playwright selector, waiting, isolation and evidence patterns for generated end-to-end suites
---

# E2E Patterns

| File | Covers |
|------|--------|
| `flake-avoidance.md` | Why suites go amber, and the four causes worth designing out |
| `evidence-contract.md` | What must be captured for a run to count as evidence |

## The suite's real enemy is distrust

A suite that fails intermittently is worse than no suite: it trains the team to
re-run rather than investigate, and then a genuine regression is re-run too. Every
pattern here exists to keep false failures at zero.

## Selectors

Role and label first, `data-testid` second, structural CSS never.

```python
page.get_by_role("button", name="Approve facility")   # best
page.get_by_label("Customer ID")                      # best
page.get_by_test_id("exposure-total")                 # acceptable
page.locator("div.card > button:nth-child(2)")        # never
```

Role-based selectors have a useful side effect: they only work if the component is
accessible, so the suite asserts accessibility for free.

## Waiting

Retrying assertions and explicit response waits. Never `time.sleep`, which is too
long when passing and too short when the environment is loaded.

## Isolation

Each test creates its own data through a fixture and cleans up. Shared state passes
locally and fails under parallelism, where the failure looks like a product bug.

## Evidence

Trace on first retry, video and screenshot on failure, JUnit XML always. Capturing
everything on every run produces gigabytes nobody reads, which is the same as
capturing nothing.
