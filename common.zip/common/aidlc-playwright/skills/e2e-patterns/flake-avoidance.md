# Flake Avoidance

Four causes account for nearly every amber suite.

## 1. Structural selectors

A selector describing markup structure breaks when the markup changes, which is not
a behaviour change. After the third false failure the suite is skipped in CI.

Fix: role and label based selectors. Where a component offers no accessible name,
report that as a UI defect — working around it with a CSS path hides a real
accessibility gap.

## 2. Fixed sleeps

`time.sleep(5)` is too long on a fast environment and too short on a loaded one.
Both outcomes are bad: slow suites get run less often, and flaky ones get ignored.

Fix: retrying assertions (`expect(...).to_be_visible()`) and explicit
`wait_for_response` on the call that actually matters.

## 3. Shared state

Tests that depend on data another test created pass in the order they were written
and fail under parallelism. The failure surfaces as a product bug and wastes a
developer's afternoon.

Fix: per-test fixtures that create and clean up their own data.

## 4. Animation and transient UI

Clicking during a transition hits the wrong element or nothing. Toasts disappear
before an assertion runs.

Fix: assert on the settled state rather than the transition; disable animations in
the test profile where the application supports it.

## The rule

**A test that needs a retry to pass locally is a test to fix, not to retry.**
Retries belong in CI as protection against infrastructure noise, never as a
substitute for a correct wait.
