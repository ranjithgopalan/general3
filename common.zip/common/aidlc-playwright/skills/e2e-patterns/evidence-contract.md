# Evidence Contract

A run counts as evidence only if, months later, someone can answer: *how do you
know this requirement works?*

## Required per run

| Item | Why |
|------|-----|
| JUnit XML | The machine-readable record. Console output is not evidence. |
| Story id per test | Without it a result cannot be traced to a requirement |
| Environment and build | "It passed" is meaningless without "against what" |
| Timestamp and duration | Ordering, and spotting a suite that silently stopped running |
| Trace for each failure | The only artefact that explains *why* it failed |
| Screenshot and video on failure | What a human needs to triage quickly |

## Required per publication

- a per-story table: PASS / FAIL / **no covering test**
- large artefacts referenced by path, never inlined into the knowledge base
- the outcome reported exactly as the XML records it

## The row people forget

**Stories with no covering test.** A report listing only tests that exist looks
complete while saying nothing about coverage. The uncovered list is the finding the
coverage gate needs, and omitting it makes an evidence pack quietly misleading.

## Never

- Report a pass the XML does not show, including a suite that errored before any
  test ran — some reporters render that as zero failures
- Inline trace zips or videos into a KB payload
- Publish evidence from a production run
