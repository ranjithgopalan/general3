---
name: run
description: Run a generated Playwright suite and publish trace, screenshot, video and JUnit evidence with story traceability.
triggers:
  - "run e2e"
  - "run playwright"
  - "publish test evidence"
  - "e2e report"
---

# AIDLC-playwright: run

## Agent Invocation

Use the Task tool with `subagent_type="router"` and the following prompt:

"""
## User Request
$ARGUMENTS

## Intent: RUN AND PUBLISH

1. Confirm the target environment is not production.
2. Run the suite with JUnit XML output and failure-time capture enabled.
3. Dispatch to `evidence-publisher`.
4. Parse the JUnit XML, not console output. Report exactly what it records --
   never describe a run as passing when the XML shows failures or errors.
5. Map every result to the story it cites, and list stories with NO covering
   test. That list is the finding, not an afterthought.
6. Reference traces and videos by path; do not inline them.
"""

## Output

A per-story pass/fail/uncovered table, failure links to traces, and a published
evidence summary.
