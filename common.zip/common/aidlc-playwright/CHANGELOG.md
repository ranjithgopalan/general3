# Changelog - AIDLC-playwright

## **1.0.0** - Initial release (2026-08-10)

### Added

- `router` with two gates: approved-stories-only, and non-production targets only.
- `e2e-generator` - `pytest-playwright` journeys citing their story id, role and
  label based selectors, retrying assertions, per-test fixtures, and failure-time
  trace/video/screenshot capture with JUnit XML.
- `evidence-publisher` - parses JUnit XML, maps results to stories both ways, and
  always reports stories with no covering test.
- `e2e-patterns` reference skill with `flake-avoidance.md` and
  `evidence-contract.md`.

### Design decisions

- **Complements a runtime MCP harness, does not replace it.** The harness explores;
  this produces a durable suite and traceable evidence.
- **Structural CSS selectors are prohibited.** They break on changes that are not
  behaviour changes, and after three false failures a suite gets skipped in CI.
- **Fixed sleeps are prohibited.** Too long when passing, too short when loaded.
- **Uncovered stories are always reported.** A report listing only existing tests
  looks complete while saying nothing about coverage.
- **A run is only evidence if it can be traced.** Story id, environment, build,
  timestamp and a trace for every failure.
