# AIDLC-playwright

Python `pytest-playwright` end-to-end journeys generated from approved user
stories, with evidence published back to the knowledge base.

## How this relates to a runtime Playwright MCP harness

A Playwright MCP harness drives a browser interactively during a session. That is
genuinely useful for exploration, but it leaves nothing durable: no committed suite,
no regression protection, and no evidence linked to a requirement.

This plugin produces the durable half — a reviewable suite in the repository plus
trace/screenshot/video/JUnit evidence traced to the stories it proves. **The two are
complementary.** Use the harness to explore, this plugin for regression and evidence.

## Commands

| Skill | Purpose |
|-------|---------|
| `/AIDLC-playwright:generate` | Journeys, page objects and fixtures from approved stories |
| `/AIDLC-playwright:run` | Run the suite and publish evidence with story traceability |
| `/AIDLC-playwright:explore` | Report coverage, selector health and flake risk |

## Agents

| Agent | Produces |
|-------|----------|
| `router` | Routing, plus the approved-stories and non-production gates |
| `e2e-generator` | `pytest-playwright` journeys, page objects, fixtures, config |
| `evidence-publisher` | Trace, screenshot, video and JUnit evidence, published to the KB |

## Prerequisites

1. **Approved user stories.** A journey generated from a Draft story pins behaviour
   nobody agreed to, and it gets "fixed" by editing the test rather than the code.
2. **A reachable non-production application URL.** A suite written against an
   imagined DOM is rewritten entirely on first run.
3. **Test credentials in the environment.** Never literals.

## The design principle

**A suite that cries wolf protects nothing.** A suite that fails intermittently
trains the team to re-run rather than investigate — and then a genuine regression
gets re-run too. Every pattern here targets zero false failures:

- role and label selectors, never structural CSS
- retrying assertions, never `time.sleep`
- per-test fixtures, never shared state
- retries in CI only; a test needing a retry locally is a test to fix

## The finding people forget

`evidence-publisher` always reports **stories with no covering test**. A report
listing only the tests that exist looks complete while saying nothing about
coverage, which makes an evidence pack quietly misleading.

## Refusals

- Production as the target
- Draft stories as the source
- Generating against an unreachable application
- Reporting a pass the JUnit XML does not show

## Validation

```bash
python scripts/validate-plugins.py --plugin AIDLC-playwright --verbose
```
