"""Changelog generator — Step 5 of the Epic Assembler (aidlc-merge plugin, docs/27).

Reads merge-bundle.json + merge-results.json + kb-refresh-result.json and generates
a CHANGELOG.md in the workspace directory. The changelog records:
  - New KB version created (STAGING)
  - Each epic with its merged PRs and story list
  - Diff summary (files changed, lines added/removed across all PRs)
  - QA findings (open defects deferred to next workspace)
  - Blockers / skipped PRs

Usage:
  python aidlc_merge_changelog.py <workspace_id>
      [--out-dir PATH]
      [--config PATH]
      [--dry-run]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import aidlc_auth

# ── Constants ────────────────────────────────────────────────────────────────

_PLUGIN = "aidlc-merge"
_BUNDLE_FILE = "merge-bundle.json"
_RESULTS_FILE = "merge-results.json"
_REVIEW_FILE = "pr-review-summary.json"
_KB_REFRESH_RESULT = "kb-refresh-result.json"
_CHANGELOG_FILE = "CHANGELOG.md"
_CONTEXT_FILE = "MERGE_CONTEXT.md"


# ── Config helpers ────────────────────────────────────────────────────────────

def _workspace_dir(cfg: dict[str, Any], workspace_id: str) -> Path:
    return Path(cfg.get("workspace_dir") or ".aidlc") / workspace_id


def _load_optional(path: Path) -> Any:
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


# ── Changelog renderer ────────────────────────────────────────────────────────

def _render_changelog(
    workspace_id: str,
    workspace: dict[str, Any],
    epics: list[dict[str, Any]],
    results: list[dict[str, Any]],
    kb_refresh: dict[str, Any] | None,
    local_artifacts: dict[str, Any],
    review_verdicts: list[dict[str, Any]] | None = None,
) -> str:
    """
    Render CHANGELOG.md content from merged PRs + stories + KB version.

    :inputs: workspace_id (str); workspace (dict); epics (list); results (list);
             kb_refresh (dict|None); local_artifacts (dict);
             review_verdicts (list|None) - verdicts from pr-review-summary.json
             (used as fallback for ALREADY_MERGED PRs when merge-results.json is absent)
    :outputs: (str) - markdown changelog content
    """
    ws_req = (workspace.get("requirement") or "")[:300]
    classification = workspace.get("classification") or workspace.get("change_type") or "—"

    new_kb_version = (kb_refresh or {}).get("new_kb_version") or "(pending sign-off)"
    kb_mode = (kb_refresh or {}).get("mode") or "unknown"
    kb_ok = bool((kb_refresh or {}).get("ok", False))

    # Build lookup: (epic_id, repo_bare, pr_number) → result
    # repo_bare: last segment of "owner/repo" so both formats match
    def _repo_bare(repo: str) -> str:
        return repo.split("/")[-1] if repo else ""

    result_map: dict[tuple[str, str, str], dict[str, Any]] = {}
    for r in results:
        key = (str(r.get("epic_id") or ""), _repo_bare(str(r.get("repo") or "")), str(r.get("pr_number") or ""))
        result_map[key] = r

    # Fallback map from review verdicts (ALREADY_MERGED PRs where merge-results.json absent)
    review_map: dict[tuple[str, str, str], dict[str, Any]] = {}
    for v in (review_verdicts or []):
        key = (str(v.get("epic_id") or ""), _repo_bare(str(v.get("repo") or "")), str(v.get("pr_number") or ""))
        review_map[key] = v

    # Aggregate stats — count both MERGED (this run) and ALREADY_MERGED (previous run)
    all_pr_records = results + [v for v in (review_verdicts or []) if v.get("status") == "ALREADY_MERGED"
                                and (str(v.get("epic_id") or ""), _repo_bare(str(v.get("repo") or "")),
                                     str(v.get("pr_number") or "")) not in result_map]
    total_merged = sum(1 for r in all_pr_records if r.get("status") in ("MERGED", "ALREADY_MERGED"))
    total_files = sum(r.get("files_changed") or 0 for r in all_pr_records if r.get("status") in ("MERGED", "ALREADY_MERGED"))
    total_add = sum(r.get("additions") or 0 for r in all_pr_records if r.get("status") in ("MERGED", "ALREADY_MERGED"))
    total_del = sum(r.get("deletions") or 0 for r in all_pr_records if r.get("status") in ("MERGED", "ALREADY_MERGED"))
    total_skipped = sum(1 for r in results if r.get("status") == "SKIP")

    qa_findings = local_artifacts.get("qa_findings") or []
    open_findings = [f for f in qa_findings if str(f.get("status") or "").upper() not in ("CLOSED", "FIXED")]

    lines: list[str] = [
        "# CHANGELOG",
        "",
        f"## Workspace `{workspace_id}`",
        "",
        f"**Requirement:** {ws_req}  ",
        f"**Change Type:** {classification}  ",
        f"**KB Version (STAGING):** `{new_kb_version}`  ",
        f"**KB Refresh Mode:** {kb_mode} — {'[PASS] success' if kb_ok else '[FAIL] failed (see kb-refresh-result.json)'}  ",
        "",
        "### Diff Summary",
        "",
        f"| PRs Merged | Files Changed | Lines Added | Lines Removed |",
        "|---|---|---|---|",
        f"| {total_merged} | {total_files} | +{total_add} | -{total_del} |",
        "",
    ]

    # ── Per-epic detail ───────────────────────────────────────────────────────
    lines.append("---")
    lines.append("")
    lines.append("## Epics")
    lines.append("")

    for epic in epics:
        epic_id = str(epic.get("id") or epic.get("epic_id") or "?")
        title = epic.get("title") or epic_id
        status = epic.get("status") or "unknown"
        features = epic.get("features") or []
        dev_prs = epic.get("_dev_prs") or []
        qa_prs = epic.get("_qa_prs") or []

        lines.append(f"### {epic_id} — {title}")
        lines.append(f"**Status:** `{status}` → `done`")
        lines.append("")

        # Stories list
        all_stories = [s for f in features for s in (f.get("stories") or [])]
        if all_stories:
            lines.append("**Stories delivered:**")
            lines.append("")
            for story in all_stories:
                story_id = story.get("story_id") or story.get("id") or "?"
                s_title = story.get("title") or ""
                s_type = story.get("story_type") or ""
                s_pts = story.get("points") or 0
                lines.append(f"- `{story_id}` [{s_type}] {s_title} ({s_pts}pts)")
            lines.append("")

        # Dev PRs
        if dev_prs:
            lines.append("**Dev PRs merged:**")
            lines.append("")
            for pr_meta in dev_prs:
                repo = pr_meta.get("repo") or "?"
                num = str(pr_meta.get("pr_number") or pr_meta.get("number") or "?")
                r_key = (epic_id, _repo_bare(repo), num)
                # prefer merge-results; fall back to review verdict for ALREADY_MERGED
                r = result_map.get(r_key) or review_map.get(r_key) or {}
                sha = r.get("sha") or r.get("head_sha") or pr_meta.get("commit") or ""
                merge_status = r.get("status") or "?"
                pr_url = pr_meta.get("pr_url") or ""
                files = r.get("files_changed") or 0
                add_del = f"+{r.get('additions', 0)}/-{r.get('deletions', 0)}"
                icon = "[PASS]" if merge_status == "MERGED" else ("⏭" if merge_status == "ALREADY_MERGED" else "[blocked]")
                sha_short = sha[:12] if sha else "?"
                pr_link = f"[{repo}#{num}]({pr_url})" if pr_url else f"{repo}#{num}"
                lines.append(
                    f"- {icon} {pr_link}  sha=`{sha_short}`  "
                    f"files={files}  {add_del}"
                )
            lines.append("")

        # QA PRs
        if qa_prs:
            lines.append("**QA PRs merged:**")
            lines.append("")
            for pr_meta in qa_prs:
                repo = pr_meta.get("repo") or "?"
                num = str(pr_meta.get("pr_number") or pr_meta.get("number") or "?")
                r_key = (epic_id, _repo_bare(repo), num)
                # prefer merge-results; fall back to review verdict for ALREADY_MERGED
                r = result_map.get(r_key) or review_map.get(r_key) or {}
                sha = r.get("sha") or r.get("head_sha") or pr_meta.get("commit") or ""
                merge_status = r.get("status") or "?"
                pr_url = pr_meta.get("pr_url") or ""
                files = r.get("files_changed") or 0
                add_del = f"+{r.get('additions', 0)}/-{r.get('deletions', 0)}"
                icon = "[PASS]" if merge_status == "MERGED" else ("⏭" if merge_status == "ALREADY_MERGED" else "[blocked]")
                sha_short = sha[:12] if sha else "?"
                pr_link = f"[{repo}#{num}]({pr_url})" if pr_url else f"{repo}#{num}"
                lines.append(f"- {icon} {pr_link}  sha=`{sha_short}`  files={files}  {add_del}")
            lines.append("")

        lines.append("---")
        lines.append("")

    # ── Skipped/blocked PRs ───────────────────────────────────────────────────
    if total_skipped > 0:
        skipped = [r for r in results if r.get("status") == "SKIP"]
        lines.append("## [WARN] Skipped / Blocked PRs")
        lines.append("")
        lines.append(
            "> These PRs were not merged in this run. Resolve the blockers and re-run `aidlc_merge_execute.py`."
        )
        lines.append("")
        for r in skipped:
            lines.append(
                f"- [blocked] `{r.get('epic_id')}` {r.get('repo')}#{r.get('pr_number')}: "
                f"{r.get('reason') or '(no reason)'}"
            )
        lines.append("")

    # ── Open QA findings ──────────────────────────────────────────────────────
    if open_findings:
        lines.append("##  Open QA Findings (deferred)")
        lines.append("")
        lines.append(
            "> These defects were found during QA but are not yet resolved. "
            "Create follow-up workspaces for each."
        )
        lines.append("")
        for f in open_findings:
            # Support both the structured qa-findings format (id/summary/severity)
            # and the legacy format (test_id/scenario)
            finding_id = f.get("id") or f.get("test_id") or "?"
            summary = f.get("summary") or f.get("scenario") or f.get("actual") or "?"
            story_id = f.get("story_id") or "?"
            severity = f.get("severity") or ""
            sev_tag = f" [{severity}]" if severity else ""
            lines.append(f"- `{finding_id}`{sev_tag} (story `{story_id}`): {summary}")
        lines.append("")

    # ── KB version note ───────────────────────────────────────────────────────
    lines.append("## KB Version")
    lines.append("")
    if kb_ok:
        lines.append(
            f"New KB version `{new_kb_version}` is in **STAGING**. "
            "Run `kb-indexer promote` (or set `auto_promote: true` in config) "
            "to move it to **ACTIVE** after SME sign-off."
        )
    else:
        lines.append(
            "[WARN] KB Refresh did not complete successfully. "
            "See `kb-refresh-result.json` for details. "
            "The workspace has advanced to PENDING_SYNC but no new KB version exists."
        )
    lines.append("")
    lines.append("---")
    lines.append("_Generated by aidlc-merge Epic Assembler_")

    return "\n".join(lines)


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    """
    Generate CHANGELOG.md from merged PRs + stories + KB version.

    :inputs: None (reads args from sys.argv)
    :outputs: None (writes CHANGELOG.md)
    """
    ap = argparse.ArgumentParser(
        description="Step 5 — generate CHANGELOG.md from merged PRs + stories + KB version."
    )
    ap.add_argument("workspace_id")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--config", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    ws_dir = Path(args.out_dir) if args.out_dir else _workspace_dir(cfg, args.workspace_id)

    # Load all inputs
    bundle = _load_optional(ws_dir / _BUNDLE_FILE) or {}
    results_data = _load_optional(ws_dir / _RESULTS_FILE) or {}
    kb_refresh = _load_optional(ws_dir / _KB_REFRESH_RESULT)
    review_data = _load_optional(ws_dir / _REVIEW_FILE) or {}

    workspace = bundle.get("workspace") or {}
    epics = bundle.get("epics") or []
    local_artifacts = bundle.get("local_artifacts") or {}
    results = results_data.get("results") or []
    review_verdicts = review_data.get("verdicts") or []

    if not bundle:
        print(f"[{_PLUGIN}] WARNING: {_BUNDLE_FILE} not found — changelog will be sparse")
    if not results:
        print(f"[{_PLUGIN}] WARNING: {_RESULTS_FILE} not found — merge results not included")
    if review_verdicts:
        already_merged = sum(1 for v in review_verdicts if v.get("status") == "ALREADY_MERGED")
        print(f"[{_PLUGIN}] Loaded {len(review_verdicts)} review verdict(s) ({already_merged} ALREADY_MERGED)")
    if not kb_refresh:
        print(f"[{_PLUGIN}] WARNING: {_KB_REFRESH_RESULT} not found — KB version will be '(pending)'")

    print(
        f"[{_PLUGIN}] Generating changelog: "
        f"{len(epics)} epic(s), {len(results)} PR result(s)"
    )

    changelog = _render_changelog(
        workspace_id=args.workspace_id,
        workspace=workspace,
        epics=epics,
        results=results,
        kb_refresh=kb_refresh,
        local_artifacts=local_artifacts,
        review_verdicts=review_verdicts,
    )

    if args.dry_run:
        print(f"[{_PLUGIN}] --dry-run: would write {_CHANGELOG_FILE}")
        print(changelog[:2000])
        return

    out_path = ws_dir / _CHANGELOG_FILE
    out_path.write_text(changelog, encoding="utf-8")
    print(f"[{_PLUGIN}] Wrote {out_path}")

    # Append link to MERGE_CONTEXT.md
    context_path = ws_dir / _CONTEXT_FILE
    if context_path.is_file():
        append = [
            "",
            "---",
            "",
            f"## Changelog",
            "",
            f"See `{_CHANGELOG_FILE}` for the full release changelog.",
            "",
        ]
        context_path.write_text(
            context_path.read_text(encoding="utf-8") + "\n".join(append),
            encoding="utf-8",
        )

    print(f"[{_PLUGIN}] Next: run aidlc_sync_merge.py to sync results to central")


if __name__ == "__main__":
    main()
