"""PR merger — Step 3 of the Epic Assembler (aidlc-merge plugin, docs/27).

Reads merge-bundle.json + pr-review-summary.json and squash-merges all READY PRs
via the GitHub Enterprise API. Skips BLOCKED/SKIP PRs and reports them. After all
PRs for an epic are merged, advances that epic's status from ``qa_in_progress``
(or ``dev_done``) to ``done`` via central PATCH.

Outputs written to ``.aidlc/<workspace_id>/``:
  merge-results.json  — per-PR merge outcome (SHA, timestamp, status, blockers)
  (appends results to MERGE_CONTEXT.md)

Usage:
  python aidlc_merge_execute.py <workspace_id>
      [--epic-ids ID1,ID2,...]   # merge only these epics (default: all from bundle)
      [--skip-epic-status-update] # do not PATCH epic status to done
      [--out-dir PATH]
      [--config PATH]
      [--dry-run]
"""

from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

import aidlc_auth

# ── Constants ────────────────────────────────────────────────────────────────

_PLUGIN = "aidlc-merge"
_BUNDLE_FILE = "merge-bundle.json"
_REVIEW_FILE = "pr-review-summary.json"
_RESULTS_FILE = "merge-results.json"
_CONTEXT_FILE = "MERGE_CONTEXT.md"

_READY_STATUSES = {"READY", "ALREADY_MERGED"}
_GITHUB_RATE_LIMIT_HEADER = "X-RateLimit-Remaining"
_GITHUB_RETRY_AFTER = "Retry-After"
_MAX_RETRIES = 3
_RETRY_BASE_DELAY = 2.0   # seconds


# ── Config helpers ────────────────────────────────────────────────────────────

def _workspace_dir(cfg: dict[str, Any], workspace_id: str) -> Path:
    return Path(cfg.get("workspace_dir") or ".aidlc") / workspace_id


def _git_cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return cfg.get("git") or {}


def _merge_cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return cfg.get("merge") or {}


def _github_token(cfg: dict[str, Any]) -> str:
    import os
    raw = _git_cfg(cfg).get("github_token_env") or ""
    if not raw:
        sys.exit(f"[{_PLUGIN}] config.git.github_token_env is not set")
    if any(raw.startswith(p) for p in ("github_pat_", "ghp_", "gho_", "ghs_", "ghu_")):
        return raw
    token = os.environ.get(raw, "")
    if not token:
        sys.exit(f"[{_PLUGIN}] GitHub token env var '{raw}' is not set — export {raw}=<PAT>")
    return token


def _github_headers(token: str) -> dict[str, str]:
    return {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "Content-Type": "application/json",
    }


# ── GitHub merge ──────────────────────────────────────────────────────────────

def _build_commit_message(template: str, epic_id: str, title: str, pr_number: int, workspace_id: str) -> str:
    """
    Fill commit message template with context values.

    :inputs: template (str); epic_id (str); title (str); pr_number (int); workspace_id (str)
    :outputs: (str) - formatted commit message
    """
    return (
        template
        .replace("{epic_id}", epic_id)
        .replace("{title}", title)
        .replace("{pr_number}", str(pr_number))
        .replace("{workspace_id}", workspace_id)
    )


def _squash_merge_pr(
    repo: str,
    pr_number: int,
    pr_title: str,
    epic_id: str,
    workspace_id: str,
    github_base: str,
    gh_headers: dict[str, str],
    commit_msg_template: str,
    dry_run: bool,
) -> dict[str, Any]:
    """
    Squash-merge a single PR via GitHub API.

    :inputs: repo (str) - owner/repo; pr_number (int); pr_title (str); epic_id (str);
             workspace_id (str); github_base (str); gh_headers (dict); commit_msg_template (str); dry_run (bool)
    :outputs: (dict) - merge outcome dict
    """
    url = f"{github_base}/repos/{repo}/pulls/{pr_number}/merge"
    commit_message = _build_commit_message(
        commit_msg_template, epic_id, pr_title, pr_number, workspace_id
    )
    body = {
        "commit_title": commit_message[:72],   # GitHub limits title to 72 chars
        "commit_message": commit_message,
        "merge_method": "squash",
    }

    if dry_run:
        print(f"  [dry-run] Would squash-merge {repo}#{pr_number}")
        return {
            "repo": repo,
            "pr_number": pr_number,
            "status": "DRY_RUN",
            "sha": None,
            "merged_at": None,
        }

    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=gh_headers, method="PUT")

    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                remaining = resp.getheader(_GITHUB_RATE_LIMIT_HEADER) or "?"
                result = json.loads(resp.read().decode("utf-8"))
                sha = result.get("sha") or ""
                print(
                    f"  [PASS] Merged {repo}#{pr_number} "
                    f"sha={sha[:12] if sha else '?'}  rate_remaining={remaining}"
                )
                return {
                    "repo": repo,
                    "pr_number": pr_number,
                    "status": "MERGED",
                    "sha": sha,
                    "merged_at": result.get("merged") or True,
                    "message": result.get("message") or "",
                }
        except urllib.error.HTTPError as exc:
            body_text = exc.read().decode("utf-8", "replace")
            if exc.code == 405:
                # Not mergeable (e.g. already merged or conflict appeared since review)
                return {
                    "repo": repo,
                    "pr_number": pr_number,
                    "status": "SKIP",
                    "sha": None,
                    "merged_at": None,
                    "reason": f"HTTP 405 Not Mergeable: {body_text[:200]}",
                }
            if exc.code == 409:
                return {
                    "repo": repo,
                    "pr_number": pr_number,
                    "status": "SKIP",
                    "sha": None,
                    "merged_at": None,
                    "reason": f"HTTP 409 Conflict: {body_text[:200]}",
                }
            if exc.code == 429:
                retry_after = float(exc.getheader(_GITHUB_RETRY_AFTER) or _RETRY_BASE_DELAY)
                print(f"  ⏳ Rate limited — waiting {retry_after:.0f}s before retry {attempt}/{_MAX_RETRIES}")
                time.sleep(retry_after)
                continue
            return {
                "repo": repo,
                "pr_number": pr_number,
                "status": "ERROR",
                "sha": None,
                "merged_at": None,
                "reason": f"HTTP {exc.code}: {body_text[:300]}",
            }
        except urllib.error.URLError as exc:
            if attempt < _MAX_RETRIES:
                wait = _RETRY_BASE_DELAY * attempt
                print(f"  ⏳ Network error — retry {attempt}/{_MAX_RETRIES} in {wait}s: {exc.reason}")
                time.sleep(wait)
                continue
            return {
                "repo": repo,
                "pr_number": pr_number,
                "status": "ERROR",
                "sha": None,
                "merged_at": None,
                "reason": str(exc.reason),
            }

    return {
        "repo": repo,
        "pr_number": pr_number,
        "status": "ERROR",
        "sha": None,
        "merged_at": None,
        "reason": f"Exhausted {_MAX_RETRIES} retries",
    }


# ── Epic status update ────────────────────────────────────────────────────────

def _advance_epic_status(
    base: str, workspace_id: str, epic_id: str, cfg: dict[str, Any]
) -> bool:
    """
    Advance epic status to 'done' via PATCH /ws/{id}/epics/{epic_id}.

    :inputs: base (str) - central base URL; workspace_id (str); epic_id (str); cfg (dict)
    :outputs: (bool) - True on success
    """
    url = f"{base}/ws/{workspace_id}/epics/{epic_id}"
    body = {"status": "done"}
    try:
        result = aidlc_auth.post_json(url, cfg, body)
        print(f"  [central] Epic {epic_id} status → done (new_status={result.get('status') or 'done'})")
        return True
    except SystemExit:
        # aidlc_auth.post_json calls sys.exit on HTTP errors; catch and continue
        print(f"  WARNING: Could not advance epic {epic_id} to done via central API")
        return False


# ── Main execute loop ─────────────────────────────────────────────────────────

def main() -> None:
    """
    Squash-merge all READY PRs; skip BLOCKED; advance epic status to done.

    :inputs: None (reads args from sys.argv)
    :outputs: None (writes merge-results.json; appends to MERGE_CONTEXT.md)
    """
    ap = argparse.ArgumentParser(
        description="Step 3 — squash-merge approved PRs via GitHub API; update epic status."
    )
    ap.add_argument("workspace_id")
    ap.add_argument("--epic-ids", default=None, help="Comma-separated epic IDs to merge (default: all)")
    ap.add_argument("--skip-epic-status-update", action="store_true", help="Do not PATCH epic status to done")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--config", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    base = (cfg.get("central_base_url") or "").rstrip("/")
    github_base = (_git_cfg(cfg).get("github_base_url") or "https://github.aig.net/api/v3").rstrip("/")
    token = _github_token(cfg)
    gh_headers = _github_headers(token)
    merge_cfg_data = _merge_cfg(cfg)

    commit_msg_template = (
        merge_cfg_data.get("commit_message_template")
        or "chore(merge): squash merge {epic_id} — {title} [aidlc-merge]"
    )
    skip_blockers = bool(merge_cfg_data.get("skip_blockers", True))

    ws_dir = Path(args.out_dir) if args.out_dir else _workspace_dir(cfg, args.workspace_id)

    # Load bundle
    bundle_path = ws_dir / _BUNDLE_FILE
    if not bundle_path.is_file():
        sys.exit(f"[{_PLUGIN}] {_BUNDLE_FILE} not found — run aidlc_merge_bundle.py first")
    bundle = json.loads(bundle_path.read_text(encoding="utf-8"))

    # Load review summary
    review_path = ws_dir / _REVIEW_FILE
    if not review_path.is_file():
        sys.exit(f"[{_PLUGIN}] {_REVIEW_FILE} not found — run aidlc_merge_review.py first")
    review_data = json.loads(review_path.read_text(encoding="utf-8"))
    verdicts = review_data.get("verdicts") or []

    # Build lookup: (epic_id, pr_number, repo) → verdict
    verdict_map: dict[tuple[str, str, str], dict[str, Any]] = {}
    for v in verdicts:
        key = (
            str(v.get("epic_id") or ""),
            str(v.get("pr_number") or ""),
            str(v.get("repo") or ""),
        )
        verdict_map[key] = v

    # Optional epic filter
    epic_filter: set[str] | None = None
    if args.epic_ids:
        epic_filter = {e.strip() for e in args.epic_ids.split(",") if e.strip()}

    epics = bundle.get("epics") or []
    all_results: list[dict[str, Any]] = []
    blocked_report: list[str] = []

    for epic in epics:
        epic_id = str(epic.get("id") or epic.get("epic_id") or "?")
        if epic_filter and epic_id not in epic_filter:
            continue

        epic_title = epic.get("title") or epic_id
        dev_prs = epic.get("_dev_prs") or []
        qa_prs = epic.get("_qa_prs") or []
        all_prs = [(p, "dev") for p in dev_prs] + [(p, "qa") for p in qa_prs]

        print(f"\n[{_PLUGIN}] Processing epic {epic_id} — {epic_title}")

        epic_merged: list[dict[str, Any]] = []
        epic_blocked: list[str] = []
        epic_already_merged: list[dict[str, Any]] = []

        for pr_meta, pr_type in all_prs:
            pr_number = pr_meta.get("pr_number") or pr_meta.get("number") or 0
            repo = pr_meta.get("repo") or pr_meta.get("repository") or ""

            # Look up verdict
            v_key = (epic_id, str(pr_number), repo)
            verdict = verdict_map.get(v_key)

            if verdict is None:
                # Not in review summary — try fallback (workspace-level PRs)
                v_key_ws = ("", str(pr_number), repo)
                verdict = verdict_map.get(v_key_ws)

            if verdict is None:
                status = "UNKNOWN"
                reason = "Not found in pr-review-summary.json — was aidlc_merge_review.py run?"
            else:
                status = verdict.get("status") or "UNKNOWN"
                reason = verdict.get("reason") or ""

            pr_title = (verdict or {}).get("pr_title") or pr_meta.get("title") or epic_title

            if status == "ALREADY_MERGED":
                sha = (verdict or {}).get("head_sha") or ""
                print(f"  ⏭  {repo}#{pr_number} ({pr_type}) — already merged, skipping")
                epic_already_merged.append({
                    "epic_id": epic_id,
                    "pr_type": pr_type,
                    "repo": repo,
                    "pr_number": pr_number,
                    "pr_title": pr_title,
                    "status": "ALREADY_MERGED",
                    "sha": sha,
                })
                all_results.append(epic_already_merged[-1])
                continue

            if status != "READY":
                msg = f"{repo}#{pr_number} ({pr_type}): {reason}"
                print(f"  [blocked] BLOCKED — {msg}")
                epic_blocked.append(msg)
                blocked_report.append(f"Epic {epic_id}: {msg}")
                if not skip_blockers:
                    sys.exit(f"[{_PLUGIN}] Aborting on first blocker (skip_blockers=false): {msg}")
                result = {
                    "epic_id": epic_id,
                    "pr_type": pr_type,
                    "repo": repo,
                    "pr_number": pr_number,
                    "pr_title": pr_title,
                    "status": "SKIP",
                    "sha": None,
                    "reason": reason,
                }
                all_results.append(result)
                continue

            # READY — merge it
            print(f"  → Merging {repo}#{pr_number} ({pr_type}) ...")
            outcome = _squash_merge_pr(
                repo=repo,
                pr_number=pr_number,
                pr_title=pr_title,
                epic_id=epic_id,
                workspace_id=args.workspace_id,
                github_base=github_base,
                gh_headers=gh_headers,
                commit_msg_template=commit_msg_template,
                dry_run=args.dry_run,
            )
            outcome["epic_id"] = epic_id
            outcome["pr_type"] = pr_type
            outcome["pr_title"] = pr_title

            if outcome["status"] in ("MERGED", "DRY_RUN"):
                epic_merged.append(outcome)
            else:
                epic_blocked.append(f"{repo}#{pr_number}: {outcome.get('reason')}")
                blocked_report.append(f"Epic {epic_id}: {repo}#{pr_number}: {outcome.get('reason')}")
                print(f"  [blocked] Merge failed: {outcome.get('reason')}")

            all_results.append(outcome)

        # Advance epic status if all PRs merged (or already merged) and no blockers
        if not args.skip_epic_status_update and not args.dry_run and base:
            if not epic_blocked:
                print(f"  → Advancing epic {epic_id} to 'done' ...")
                _advance_epic_status(base, args.workspace_id, epic_id, cfg)
            else:
                print(
                    f"  [WARN]  Epic {epic_id} has blocked PRs — skipping status advance to 'done'"
                )

    # ── Write results ─────────────────────────────────────────────────────────
    merged_count = sum(1 for r in all_results if r.get("status") in ("MERGED", "DRY_RUN"))
    already_count = sum(1 for r in all_results if r.get("status") == "ALREADY_MERGED")
    skipped_count = sum(1 for r in all_results if r.get("status") == "SKIP")
    error_count = sum(1 for r in all_results if r.get("status") == "ERROR")

    print(
        f"\n[{_PLUGIN}] Execute complete: "
        f"MERGED={merged_count} | ALREADY_MERGED={already_count} | "
        f"SKIPPED={skipped_count} | ERRORS={error_count}"
    )
    if blocked_report:
        print(f"[{_PLUGIN}] Blocked/skipped PRs ({len(blocked_report)}):")
        for msg in blocked_report:
            print(f"  [blocked] {msg}")

    if args.dry_run:
        print(f"[{_PLUGIN}] --dry-run: not writing {_RESULTS_FILE}")
        return

    results_path = ws_dir / _RESULTS_FILE
    results_path.write_text(
        json.dumps(
            {
                "workspace_id": args.workspace_id,
                "results": all_results,
                "summary": {
                    "merged": merged_count,
                    "already_merged": already_count,
                    "skipped": skipped_count,
                    "errors": error_count,
                    "blocked_report": blocked_report,
                },
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    print(f"[{_PLUGIN}] Wrote {results_path}")

    # Append to MERGE_CONTEXT.md
    context_path = ws_dir / _CONTEXT_FILE
    if context_path.is_file():
        append_lines = [
            "",
            "---",
            "",
            "## Merge Execution Results",
            "",
            f"| Metric | Count |",
            "|---|---|",
            f"| PRs Merged | {merged_count} |",
            f"| Already Merged | {already_count} |",
            f"| Skipped (blockers) | {skipped_count} |",
            f"| Errors | {error_count} |",
            "",
        ]
        if blocked_report:
            append_lines += ["### Blockers / Skipped", ""]
            for msg in blocked_report:
                append_lines.append(f"- [blocked] {msg}")
            append_lines.append("")
        context_path.write_text(
            context_path.read_text(encoding="utf-8") + "\n".join(append_lines),
            encoding="utf-8",
        )

    print(f"[{_PLUGIN}] Next: run aidlc_merge_kb_refresh.py to invoke KB indexer")


if __name__ == "__main__":
    main()
