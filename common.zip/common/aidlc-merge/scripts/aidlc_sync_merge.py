"""Merge sync — Step 6 of the Epic Assembler (aidlc-merge plugin, docs/27).

Syncs the merge results, new KB version, and full traceability back to central,
then advances the workspace from MERGE → PENDING_SYNC.

Posts two artifacts:
  1. Workspace-level ``merge-report`` artifact — full summary of all merged PRs,
     KB version, epic statuses, blockers.
  2. Per-epic ``merge-epic`` artifact — per-epic merge commit SHA + traceability edges
     (EPIC → DEV_PR merge, EPIC → QA_PR merge, via ``POST /ws/{id}/epics/{epic_id}/merge/trace``).

The developer's per-epic ``dev-epic`` trace is authored solely by the aidlc-develop
plugin. This sync must NOT re-post it: doing so shadowed the developer's authored record
(files changed, actor, KB citations) with a thinner merge stamp, because the read returns
the latest ``dev-epic`` row. Merge lineage belongs in the ``merge-epic`` artifact above.

After both are recorded, advances the workspace to PENDING_SYNC via the existing
``POST /ws/{id}/merge`` endpoint (if not already at PENDING_SYNC from the central
KB refresh mode).

Usage:
  python aidlc_sync_merge.py <workspace_id>
      [--no-advance]               # Record artifacts but do not advance state
      [--out-dir PATH]
      [--config PATH]
      [--dry-run]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import aidlc_auth

# ── Constants ────────────────────────────────────────────────────────────────

_PLUGIN = "aidlc-merge"
_BUNDLE_FILE = "merge-bundle.json"
_RESULTS_FILE = "merge-results.json"
_KB_REFRESH_RESULT = "kb-refresh-result.json"
_CHANGELOG_FILE = "CHANGELOG.md"
_CONTEXT_FILE = "MERGE_CONTEXT.md"
_SYNC_RESULT_FILE = "sync-merge-result.json"


# ── Config helpers ────────────────────────────────────────────────────────────

def _workspace_dir(cfg: dict[str, Any], workspace_id: str) -> Path:
    return Path(cfg.get("workspace_dir") or ".aidlc") / workspace_id


def _load_optional(path: Path) -> Any:
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


# ── Payload builders ──────────────────────────────────────────────────────────

def _build_merge_report_payload(
    workspace_id: str,
    epics: list[dict[str, Any]],
    results: list[dict[str, Any]],
    kb_refresh: dict[str, Any] | None,
    local_artifacts: dict[str, Any],
    advance: bool,
) -> dict[str, Any]:
    """
    Build the workspace-level merge-report artifact payload.

    :inputs: workspace_id (str); epics (list); results (list);
             kb_refresh (dict|None); local_artifacts (dict); advance (bool)
    :outputs: (dict) - payload to POST to central
    """
    merged = [r for r in results if r.get("status") in ("MERGED", "ALREADY_MERGED")]
    skipped = [r for r in results if r.get("status") == "SKIP"]
    errors = [r for r in results if r.get("status") == "ERROR"]

    new_kb_version = (kb_refresh or {}).get("new_kb_version")
    kb_ok = bool((kb_refresh or {}).get("ok", False))

    # Build merge summary per epic
    epic_summaries = []
    for epic in epics:
        epic_id = str(epic.get("id") or epic.get("epic_id") or "?")
        epic_results = [r for r in results if str(r.get("epic_id") or "") == epic_id]
        merged_prs = [r for r in epic_results if r.get("status") in ("MERGED", "ALREADY_MERGED")]
        epic_summaries.append({
            "epic_id": epic_id,
            "title": epic.get("title") or epic_id,
            "status_before": epic.get("status") or "unknown",
            "status_after": "done" if merged_prs and not [
                r for r in epic_results if r.get("status") in ("SKIP", "ERROR")
            ] else "partial",
            "prs_merged": len(merged_prs),
            "merged_shas": [r.get("sha") for r in merged_prs if r.get("sha")],
        })

    return {
        "summary": (
            f"Merged {len(merged)} PR(s) across {len(epics)} epic(s). "
            f"KB version: {new_kb_version or 'pending'}. "
            f"Skipped: {len(skipped)}. Errors: {len(errors)}."
        ),
        "advance": advance,
        "workspace_id": workspace_id,
        "new_kb_version": new_kb_version,
        "kb_refresh_ok": kb_ok,
        "epics_summary": epic_summaries,
        "prs_merged": len(merged),
        "prs_skipped": len(skipped),
        "prs_errored": len(errors),
        "playwright_trace_count": len(local_artifacts.get("playwright_trace") or []),
        "qa_findings_count": len(local_artifacts.get("qa_findings") or []),
        "skipped_prs": [
            {"repo": r.get("repo"), "pr_number": r.get("pr_number"), "reason": r.get("reason")}
            for r in skipped
        ],
    }


# ── Central API calls ─────────────────────────────────────────────────────────

def _post_merge_report(
    base: str, workspace_id: str, payload: dict[str, Any], cfg: dict[str, Any]
) -> dict[str, Any]:
    """
    POST workspace-level merge report to central.
    Uses POST /ws/{id}/merge with additional payload fields.

    :inputs: base (str); workspace_id (str); payload (dict); cfg (dict)
    :outputs: (dict) - API response
    """
    url = f"{base}/ws/{workspace_id}/merge"
    print(f"[{_PLUGIN}] POST {url} (merge-report artifact) ...")
    return aidlc_auth.post_json(url, cfg, payload)


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    """
    Sync merge results + KB version + traceability to central; advance to PENDING_SYNC.

    :inputs: None (reads args from sys.argv)
    :outputs: None (writes sync-merge-result.json)
    """
    ap = argparse.ArgumentParser(
        description=(
            "Step 6 — sync merge results + KB version + traceability to central; "
            "advance workspace to PENDING_SYNC."
        )
    )
    ap.add_argument("workspace_id")
    ap.add_argument(
        "--no-advance", action="store_true",
        help="Record artifacts without advancing MERGE → PENDING_SYNC"
    )
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--config", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    base = (cfg.get("central_base_url") or "").rstrip("/")
    if not base:
        sys.exit(f"[{_PLUGIN}] config.central_base_url is required")

    ws_dir = Path(args.out_dir) if args.out_dir else _workspace_dir(cfg, args.workspace_id)

    # Load all inputs
    bundle = _load_optional(ws_dir / _BUNDLE_FILE) or {}
    results_data = _load_optional(ws_dir / _RESULTS_FILE) or {}
    kb_refresh = _load_optional(ws_dir / _KB_REFRESH_RESULT)

    epics = bundle.get("epics") or []
    local_artifacts = bundle.get("local_artifacts") or {}
    results = results_data.get("results") or []

    print(
        f"[{_PLUGIN}] Syncing: {len(epics)} epic(s), {len(results)} PR result(s), "
        f"kb_version={((kb_refresh or {}).get('new_kb_version') or 'none')}"
    )

    # ── Step 1: Post workspace-level merge-report ─────────────────────────────
    report_payload = _build_merge_report_payload(
        workspace_id=args.workspace_id,
        epics=epics,
        results=results,
        kb_refresh=kb_refresh,
        local_artifacts=local_artifacts,
        advance=not args.no_advance,
    )

    sync_record: dict[str, Any] = {
        "workspace_id": args.workspace_id,
        "merge_report": None,
        "advanced": False,
        "new_kb_version": (kb_refresh or {}).get("new_kb_version"),
    }

    if args.dry_run:
        print(f"[{_PLUGIN}] [dry-run] Would POST merge-report to {base}/ws/{args.workspace_id}/merge")
        print(json.dumps(report_payload, indent=2)[:500])
    else:
        try:
            report_result = _post_merge_report(base, args.workspace_id, report_payload, cfg)
            sync_record["merge_report"] = report_result
            new_state = report_result.get("state") or report_result.get("status")
            advanced = report_result.get("advanced", False)
            sync_record["advanced"] = advanced
            print(
                f"[{_PLUGIN}] [PASS] merge-report posted: "
                f"state={new_state}  advanced={advanced}  "
                f"artifact_id={report_result.get('artifact_id')}"
            )
        except SystemExit:
            print(f"[{_PLUGIN}] WARNING: merge-report POST failed (continuing with per-epic traces)")

    # ── Step 2: Post per-epic merge-epic artifacts (trace graph visibility) ──
    for epic in epics:
        epic_id = str(epic.get("id") or epic.get("epic_id") or "?")
        epic_results = [r for r in results if str(r.get("epic_id") or "") == epic_id]
        merged_prs = [
            {"pr_url": r.get("pr_url"), "repo": r.get("repo"),
             "sha": r.get("sha"), "status": r.get("status")}
            for r in epic_results if r.get("status") in ("MERGED", "ALREADY_MERGED")
        ]
        if not merged_prs:
            continue  # no merged PRs for this epic — no merge-epic artifact needed

        merge_trace_url = f"{base}/ws/{args.workspace_id}/epics/{epic_id}/merge/trace"
        features = epic.get("features") or []
        story_ids = [str(s.get("story_id") or s.get("id")) for f in features for s in (f.get("stories") or []) if s.get("story_id") or s.get("id")]
        merged_shas = [r.get("sha") for r in epic_results if r.get("sha")]
        merged_pr_lines = [
            f"{r.get('pr_type', 'dev').upper()} PR {r.get('repo')}#{r.get('pr_number')}"
            for r in epic_results if r.get("status") in ("MERGED", "ALREADY_MERGED")
        ]

        merge_epic_payload: dict[str, Any] = {
            "merge_sha": merged_shas[0] if merged_shas else None,
            "pr_url": merged_prs[0].get("pr_url") if merged_prs else None,
            "pr_number": epic_results[0].get("pr_number") if epic_results else None,
            "repo": merged_prs[0].get("repo") if merged_prs else None,
            "story_ids": story_ids,
            "prs_merged": merged_prs,
            "kb_refresh_status": (kb_refresh or {}).get("status") or "pending",
            "summary": "; ".join(merged_pr_lines) or f"Merged for epic {epic_id}",
        }

        if args.dry_run:
            print(f"[{_PLUGIN}] [dry-run] Would POST merge-epic artifact for {epic_id}")
        else:
            try:
                merge_trace_result = aidlc_auth.post_json(merge_trace_url, cfg, merge_epic_payload)
                print(f"[{_PLUGIN}]   [PASS] merge-epic artifact written for {epic_id}: {merge_trace_result.get('artifact_id')}")
            except (SystemExit, Exception) as exc:
                print(f"[{_PLUGIN}]   WARNING: merge-epic artifact write failed for {epic_id} (non-fatal): {exc}")

    # ── Write sync result ─────────────────────────────────────────────────────
    if not args.dry_run:
        out_path = ws_dir / _SYNC_RESULT_FILE
        out_path.write_text(
            json.dumps(sync_record, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        print(f"[{_PLUGIN}] Wrote {out_path}")

    # ── Final status ──────────────────────────────────────────────────────────
    advanced = sync_record.get("advanced", False)
    if advanced:
        print(
            f"[{_PLUGIN}] [PASS] Workspace advanced to PENDING_SYNC. "
            "Await SME KB sign-off (promote STAGING → ACTIVE), then close the workspace."
        )
    elif args.no_advance:
        print(f"[{_PLUGIN}] --no-advance: workspace state unchanged. Run again without --no-advance to advance.")
    else:
        print(
            f"[{_PLUGIN}] NOTE: advance={advanced}. "
            "If workspace is already at PENDING_SYNC (central mode), this is expected."
        )

    print(
        f"[{_PLUGIN}] Merge sync complete. "
        f"KB version `{sync_record.get('new_kb_version') or '(pending)'}` is in STAGING. "
        "See CHANGELOG.md for full release notes."
    )


if __name__ == "__main__":
    main()
