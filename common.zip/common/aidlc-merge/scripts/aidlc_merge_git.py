"""Git status helper for the AIDLC merge cockpit (docs/27 §merge).

Provides read-only status and diagnostic commands for the merge stage.
The actual PR merges are performed via the GitHub API (aidlc_merge_execute.py),
not via local git operations.

Commands:
  status    <workspace_id>   Print merge state summary: all PR URLs, branch states,
                              whether branches still exist in remote after merge.
  verify    <workspace_id>   Verify each merged PR's SHA exists in the target branch
                              (confirms the squash merge actually landed).
  cleanup   <workspace_id>   List (or delete) local feature branches that have been
                              merged (dry-run by default; --force to delete).

Config-driven, stdlib-only (subprocess + urllib). Reads the same aidlc.config.json
as aidlc_merge_bundle.py.

Usage:
  python aidlc_merge_git.py status  <workspace_id> [--config PATH]
  python aidlc_merge_git.py verify  <workspace_id> [--config PATH]
  python aidlc_merge_git.py cleanup <workspace_id> [--config PATH] [--force]
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

import aidlc_auth

# ── Constants ────────────────────────────────────────────────────────────────

_PLUGIN = "aidlc-merge"
_BUNDLE_FILE = "merge-bundle.json"
_RESULTS_FILE = "merge-results.json"
_REVIEW_FILE = "pr-review-summary.json"


# ── Config helpers ────────────────────────────────────────────────────────────

def _workspace_dir(cfg: dict[str, Any], workspace_id: str) -> Path:
    return Path(cfg.get("workspace_dir") or ".aidlc") / workspace_id


def _git_cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return cfg.get("git") or {}


def _repo_map(cfg: dict[str, Any]) -> list[dict[str, Any]]:
    return cfg.get("repo_map") or []


def _github_token(cfg: dict[str, Any]) -> str:
    raw = _git_cfg(cfg).get("github_token_env") or ""
    if not raw:
        sys.exit(f"[{_PLUGIN}] config.git.github_token_env is not set")
    if any(raw.startswith(p) for p in ("github_pat_", "ghp_", "gho_", "ghs_", "ghu_")):
        return raw
    token = os.environ.get(raw, "")
    if not token:
        sys.exit(f"[{_PLUGIN}] GitHub token env var '{raw}' is not set — export {raw}=<PAT>")
    return token


def _load_optional(path: Path) -> Any:
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


# ── Local git helpers ─────────────────────────────────────────────────────────

def _run_git(cmd: list[str], cwd: str) -> tuple[int, str, str]:
    """
    Run a git command; return (returncode, stdout, stderr).

    :inputs: cmd (list[str]) - git subcommand args; cwd (str) - working directory
    :outputs: (tuple[int, str, str]) - (returncode, stdout, stderr)
    """
    try:
        result = subprocess.run(
            ["git"] + cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=60,
        )
        return result.returncode, result.stdout.strip(), result.stderr.strip()
    except FileNotFoundError:
        return 1, "", "git not found in PATH"
    except subprocess.TimeoutExpired:
        return 1, "", "git command timed out"


def _local_root_for_repo(repo_url: str, cfg: dict[str, Any]) -> str | None:
    """
    Find the local_root for a remote_url from repo_map.

    :inputs: repo_url (str) - remote URL or owner/repo; cfg (dict)
    :outputs: (str|None) - local root path, or None
    """
    for entry in _repo_map(cfg):
        remote = entry.get("remote_url") or ""
        if repo_url in remote or remote.rstrip("/").endswith(repo_url.lstrip("/")):
            return entry.get("local_root") or ""
    return None


# ── GitHub API helpers ────────────────────────────────────────────────────────

def _gh_get_json(url: str, token: str) -> dict[str, Any] | list[Any]:
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
    }
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return {}
        body = exc.read().decode("utf-8", "replace")[:300]
        print(f"[{_PLUGIN}] WARNING: {url} -> HTTP {exc.code}: {body}")
        return {}
    except urllib.error.URLError as exc:
        print(f"[{_PLUGIN}] WARNING: {url} failed: {exc.reason}")
        return {}


# ── Commands ──────────────────────────────────────────────────────────────────

def _cmd_status(workspace_id: str, cfg: dict[str, Any]) -> None:
    """
    Print a merge state summary: workspace state, all epics, all PR URLs + branches.

    :inputs: workspace_id (str); cfg (dict)
    :outputs: None
    """
    ws_dir = _workspace_dir(cfg, workspace_id)
    bundle = _load_optional(ws_dir / _BUNDLE_FILE) or {}
    results_data = _load_optional(ws_dir / _RESULTS_FILE) or {}

    workspace = bundle.get("workspace") or {}
    epics = bundle.get("epics") or []
    results = results_data.get("results") or []
    summary = results_data.get("summary") or {}

    ws_state = workspace.get("state") or workspace.get("status") or "(not fetched)"
    print(f"\n[{_PLUGIN}] Workspace {workspace_id}  state={ws_state}")
    print(f"  Epics:         {len(epics)}")
    print(f"  PRs merged:    {summary.get('merged', 0)}")
    print(f"  PRs skipped:   {summary.get('skipped', 0)}")
    print(f"  PRs errored:   {summary.get('errors', 0)}")
    print("")

    # Build result map; fall back to review verdicts for ALREADY_MERGED PRs
    review_data = _load_optional(ws_dir / _REVIEW_FILE) or {}
    review_verdicts = review_data.get("verdicts") or []

    def _repo_bare(repo: str) -> str:
        return repo.split("/")[-1] if repo else ""

    result_map: dict[tuple, dict[str, Any]] = {}
    for r in results:
        key = (str(r.get("epic_id") or ""), _repo_bare(str(r.get("repo") or "")), str(r.get("pr_number") or ""))
        result_map[key] = r
    for v in review_verdicts:
        key = (str(v.get("epic_id") or ""), _repo_bare(str(v.get("repo") or "")), str(v.get("pr_number") or ""))
        if key not in result_map:
            result_map[key] = v  # use review verdict (has head_sha + status + files_changed)

    for epic in epics:
        epic_id = str(epic.get("id") or epic.get("epic_id") or "?")
        title = epic.get("title") or epic_id
        dev_prs = epic.get("_dev_prs") or []
        qa_prs = epic.get("_qa_prs") or []
        print(f"  Epic {epic_id} — {title}")

        for pr_meta, pr_type in [(p, "dev") for p in dev_prs] + [(p, "qa") for p in qa_prs]:
            repo = pr_meta.get("repo") or "?"
            num = str(pr_meta.get("pr_number") or pr_meta.get("number") or "?")
            branch = pr_meta.get("branch") or "?"
            pr_url = pr_meta.get("pr_url") or "?"
            r = result_map.get((epic_id, _repo_bare(repo), num)) or {}
            status = r.get("status") or "(not in results)"
            sha = r.get("sha") or r.get("head_sha") or pr_meta.get("commit") or ""
            icon = "[PASS]" if status in ("MERGED", "ALREADY_MERGED") else ("[blocked]" if status == "SKIP" else "")
            print(
                f"    {icon} [{pr_type}] {repo}#{num}  branch={branch}  "
                f"status={status}  sha={sha[:12] if sha else '—'}  url={pr_url}"
            )
    print("")


def _cmd_verify(workspace_id: str, cfg: dict[str, Any]) -> None:
    """
    Verify each MERGED PR's SHA exists in the target (base) branch of the repo.

    :inputs: workspace_id (str); cfg (dict)
    :outputs: None
    """
    ws_dir = _workspace_dir(cfg, workspace_id)
    bundle = _load_optional(ws_dir / _BUNDLE_FILE) or {}
    results_data = _load_optional(ws_dir / _RESULTS_FILE) or {}
    results = results_data.get("results") or []

    github_base = (_git_cfg(cfg).get("github_base_url") or "https://github.aig.net/api/v3").rstrip("/")
    token = _github_token(cfg)
    epics = bundle.get("epics") or []

    all_ok = True
    print(f"\n[{_PLUGIN}] Verifying merged SHAs for workspace {workspace_id} ...")

    for r in results:
        if r.get("status") not in ("MERGED",):
            continue
        repo = r.get("repo") or ""
        sha = r.get("sha") or ""
        epic_id = r.get("epic_id") or "?"
        pr_number = r.get("pr_number") or "?"

        if not sha:
            print(f"  [WARN]  {repo}#{pr_number} (epic {epic_id}): no SHA recorded — skip verify")
            continue

        # Check commit exists via GitHub API
        commit_url = f"{github_base}/repos/{repo}/commits/{sha}"
        commit_data = _gh_get_json(commit_url, token)

        if commit_data and isinstance(commit_data, dict):
            actual_sha = commit_data.get("sha") or ""
            print(
                f"  [PASS] {repo}#{pr_number} (epic {epic_id}): "
                f"commit {sha[:12]} found  "
                f"message='{(commit_data.get('commit') or {}).get('message', '')[:60]}'"
            )
        else:
            print(f"  [FAIL] {repo}#{pr_number} (epic {epic_id}): commit {sha[:12]} NOT found in GitHub")
            all_ok = False

    if all_ok:
        print(f"\n[{_PLUGIN}] [PASS] All MERGED SHAs verified")
    else:
        print(f"\n[{_PLUGIN}] [FAIL] Some SHAs could not be verified — check network access and repo visibility")


def _cmd_cleanup(workspace_id: str, cfg: dict[str, Any], force: bool) -> None:
    """
    List (or delete) local feature branches that have been merged.

    :inputs: workspace_id (str); cfg (dict); force (bool) - if True, delete; else list only
    :outputs: None
    """
    ws_dir = _workspace_dir(cfg, workspace_id)
    bundle = _load_optional(ws_dir / _BUNDLE_FILE) or {}
    results_data = _load_optional(ws_dir / _RESULTS_FILE) or {}
    results = results_data.get("results") or []
    epics = bundle.get("epics") or []

    action = "Deleting" if force else "Listing (dry-run; use --force to delete)"
    print(f"\n[{_PLUGIN}] {action} merged feature branches for workspace {workspace_id} ...")

    for epic in epics:
        dev_prs = epic.get("_dev_prs") or []
        qa_prs = epic.get("_qa_prs") or []
        epic_id = str(epic.get("id") or epic.get("epic_id") or "?")

        for pr_meta in dev_prs + qa_prs:
            branch = pr_meta.get("branch") or ""
            repo = pr_meta.get("repo") or pr_meta.get("remote_url") or ""
            if not branch:
                continue

            # Match result: only delete if MERGED
            num = str(pr_meta.get("pr_number") or pr_meta.get("number") or "")
            r = next(
                (x for x in results if str(x.get("epic_id") or "") == epic_id
                 and str(x.get("pr_number") or "") == num
                 and str(x.get("repo") or "") in repo),
                None,
            )
            if not r or r.get("status") not in ("MERGED", "ALREADY_MERGED"):
                continue

            local_root = _local_root_for_repo(repo, cfg)
            if not local_root or not Path(local_root).is_dir():
                print(f"  [WARN]  {repo}: local_root not found or not configured — skip cleanup")
                continue

            rc, out, err = _run_git(["branch", "--list", branch], local_root)
            if not out.strip():
                print(f"  ℹ  {repo}: branch '{branch}' not present locally (already deleted or not cloned)")
                continue

            if force:
                rc2, out2, err2 = _run_git(["branch", "-D", branch], local_root)
                if rc2 == 0:
                    print(f"  [delete]  Deleted {repo}: '{branch}'")
                else:
                    print(f"  [FAIL] Could not delete {repo}: '{branch}': {err2}")
            else:
                print(f"  [list] Would delete {repo}: '{branch}' (merged PR #{num})")

    if not force:
        print(f"\n[{_PLUGIN}] Re-run with --force to actually delete these branches")


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    """
    Git status/verify/cleanup helper for the merge stage.

    :inputs: None (reads args from sys.argv)
    :outputs: None
    """
    ap = argparse.ArgumentParser(
        description="Git status helper for aidlc-merge: status | verify | cleanup"
    )
    ap.add_argument("command", choices=["status", "verify", "cleanup"])
    ap.add_argument("workspace_id")
    ap.add_argument("--config", default=None)
    ap.add_argument(
        "--force", action="store_true",
        help="cleanup: actually delete branches (default is list-only)"
    )
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)

    if args.command == "status":
        _cmd_status(args.workspace_id, cfg)
    elif args.command == "verify":
        _cmd_verify(args.workspace_id, cfg)
    elif args.command == "cleanup":
        _cmd_cleanup(args.workspace_id, cfg, args.force)


if __name__ == "__main__":
    main()
