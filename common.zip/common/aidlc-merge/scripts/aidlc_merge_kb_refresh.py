"""KB indexer invoker — Step 4 of the Epic Assembler (aidlc-merge plugin, docs/27).

Invokes the KB indexer to create a new STAGING KB version after all PRs are merged.
Supports two modes (config-driven):

  local   — runs ``python -m app.cli pipeline --kb-dir <path>`` in the kb-indexer repo.
             Requires the kb-indexer repo to be accessible and Postgres to be reachable.

  central — calls ``POST /ws/{id}/merge`` on central, which triggers ``KbRefreshService``
             in the background, then polls ``GET /ws/{id}/merge`` until the workspace
             advances to ``PENDING_SYNC``.

Outputs written to ``.aidlc/<workspace_id>/``:
  kb-refresh-result.json  — {ok, mode, new_kb_version, staging_version, delta_counts, ...}

Usage:
  python aidlc_merge_kb_refresh.py <workspace_id>
      [--mode local|central]          # override config.kb_refresh.mode
      [--kb-dir PATH]                 # override config.kb_refresh.kb_dir (local mode)
      [--auto-promote]                # override config.kb_refresh.auto_promote
      [--promoted-by EMAIL]           # override config.kb_refresh.promoted_by
      [--dry-run]
      [--out-dir PATH]
      [--config PATH]
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import aidlc_auth

# ── Constants ────────────────────────────────────────────────────────────────

_PLUGIN = "aidlc-merge"
_RESULTS_FILE = "merge-results.json"
_KB_REFRESH_RESULT = "kb-refresh-result.json"
_CONTEXT_FILE = "MERGE_CONTEXT.md"

_PENDING_SYNC_STATES = {"PENDING_SYNC", "CLOSED"}


# ── Config helpers ────────────────────────────────────────────────────────────

def _workspace_dir(cfg: dict[str, Any], workspace_id: str) -> Path:
    return Path(cfg.get("workspace_dir") or ".aidlc") / workspace_id


def _kb_cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return cfg.get("kb_refresh") or {}


# ── Local mode: invoke kb-indexer CLI ────────────────────────────────────────

def _run_local(
    workspace_id: str,
    kb_dir: str,
    kb_indexer_dir: str,
    auto_promote: bool,
    promoted_by: str,
    batch_size: int,
    dry_run: bool,
) -> dict[str, Any]:
    """
    Run kb-indexer CLI: pull → pipeline → (optionally) promote.

    :inputs: workspace_id (str); kb_dir (str) - KB artifact directory;
             kb_indexer_dir (str) - kb-indexer repo root; auto_promote (bool);
             promoted_by (str); batch_size (int); dry_run (bool)
    :outputs: (dict) - result dict with ok, new_kb_version, etc.
    """
    indexer_root = Path(kb_indexer_dir)
    if not indexer_root.is_dir():
        return {
            "ok": False,
            "mode": "local",
            "error": f"kb-indexer directory not found: {kb_indexer_dir}",
        }

    python = sys.executable
    base_cmd = [python, "-m", "app.cli"]
    cwd = str(indexer_root)

    def _run(args: list[str], label: str) -> tuple[bool, str]:
        """Execute a CLI command; return (success, output)."""
        full = base_cmd + args
        print(f"  $ {' '.join(full)}")
        if dry_run:
            print(f"  [dry-run] Would run: {' '.join(full)}")
            return True, f"[dry-run] {label} skipped"
        try:
            result = subprocess.run(
                full,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=600,
            )
            out = (result.stdout or "") + (result.stderr or "")
            if result.returncode != 0:
                print(f"  ERROR [{label}]: exit {result.returncode}")
                print(out[-2000:] if len(out) > 2000 else out)
                return False, out
            print(out[-1000:] if len(out) > 1000 else out)
            return True, out
        except subprocess.TimeoutExpired:
            return False, f"{label} timed out after 600s"
        except FileNotFoundError:
            return False, f"Python not found at {python}"

    # Step 1: Pull current ACTIVE KB base
    print(f"[{_PLUGIN}] [local] Pulling current ACTIVE KB base ...")
    ok, out = _run(["pull", "--kb-dir", kb_dir, "--gear-id", "japan"], "pull")
    if not ok:
        return {"ok": False, "mode": "local", "error": f"kb-indexer pull failed: {out[-500:]}"}

    # Step 2: Run pipeline (load + embed → STAGING)
    print(f"[{_PLUGIN}] [local] Running pipeline: load + embed → STAGING ...")
    pipeline_args = [
        "pipeline",
        "--kb-dir", kb_dir,
        "--batch-size", str(batch_size),
    ]
    if auto_promote:
        pipeline_args += ["--auto-promote", "--by", promoted_by]
    ok, out = _run(pipeline_args, "pipeline")
    if not ok:
        return {"ok": False, "mode": "local", "error": f"kb-indexer pipeline failed: {out[-500:]}"}

    # Extract new_kb_version from output (look for "version=vN" pattern)
    new_version: str | None = None
    for line in out.split("\n"):
        for tok in line.split():
            if tok.startswith("version=v") or tok.startswith("kb_version="):
                new_version = tok.split("=", 1)[1]
                break
            if tok.startswith("v") and tok[1:].replace(".", "").isdigit():
                new_version = tok

    status = "ACTIVE" if auto_promote else "STAGING"
    print(f"[{_PLUGIN}] [local] Pipeline complete: new_version={new_version or '(parse failed)'}  status={status}")

    return {
        "ok": True,
        "mode": "local",
        "new_kb_version": new_version,
        "staging_version": None if auto_promote else new_version,
        "active_version": new_version if auto_promote else None,
        "auto_promoted": auto_promote,
        "promoted_by": promoted_by if auto_promote else None,
        "workspace_id": workspace_id,
        "dry_run": dry_run,
    }


# ── Central mode: POST /ws/{id}/merge + poll ─────────────────────────────────

def _run_central(
    workspace_id: str,
    base: str,
    cfg: dict[str, Any],
    poll_interval: float,
    max_wait: float,
) -> dict[str, Any]:
    """
    Trigger KbRefreshService via central API + poll until PENDING_SYNC.

    :inputs: workspace_id (str); base (str) - central URL; cfg (dict);
             poll_interval (float) - seconds between polls; max_wait (float) - total timeout
    :outputs: (dict) - result dict
    """
    # Trigger merge (QA_TESTING → MERGE + KbRefreshService background job)
    trigger_url = f"{base}/ws/{workspace_id}/merge"
    print(f"[{_PLUGIN}] [central] Triggering KbRefreshService via POST /ws/{workspace_id}/merge ...")
    try:
        trigger_result = aidlc_auth.post_json(trigger_url, cfg, {})
    except SystemExit as exc:
        return {
            "ok": False,
            "mode": "central",
            "error": f"POST /ws/{workspace_id}/merge failed: {exc}",
        }

    print(f"[{_PLUGIN}] [central] Triggered: state={trigger_result.get('state')}")

    # Poll GET /ws/{id}/merge until workspace reaches PENDING_SYNC or CLOSED
    status_url = f"{base}/ws/{workspace_id}/merge"
    waited = 0.0
    print(f"[{_PLUGIN}] [central] Polling for PENDING_SYNC (max {max_wait:.0f}s, interval {poll_interval:.0f}s) ...")

    while waited < max_wait:
        time.sleep(poll_interval)
        waited += poll_interval
        try:
            poll = aidlc_auth.get_json(status_url, cfg)
        except SystemExit:
            print(f"[{_PLUGIN}] WARNING: poll failed at {waited:.0f}s — will retry")
            continue

        state = str(poll.get("state") or poll.get("status") or "").upper()
        kb_version = poll.get("kb_version") or poll.get("new_kb_version")
        print(f"  [{waited:.0f}s] state={state}  kb_version={kb_version}")

        if state in _PENDING_SYNC_STATES:
            print(f"[{_PLUGIN}] [central] KB refresh complete: state={state}")
            return {
                "ok": True,
                "mode": "central",
                "new_kb_version": kb_version,
                "staging_version": kb_version,
                "active_version": None,
                "auto_promoted": False,
                "workspace_state": state,
                "workspace_id": workspace_id,
            }

    return {
        "ok": False,
        "mode": "central",
        "error": f"Timed out after {max_wait:.0f}s waiting for PENDING_SYNC",
        "workspace_id": workspace_id,
    }


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    """
    Invoke KB indexer (local CLI or central API) to create a new STAGING KB version.

    :inputs: None (reads args from sys.argv)
    :outputs: None (writes kb-refresh-result.json)
    """
    ap = argparse.ArgumentParser(
        description="Step 4 — invoke KB indexer to create a new STAGING KB version."
    )
    ap.add_argument("workspace_id")
    ap.add_argument("--mode", choices=["local", "central"], default=None,
                    help="Override config.kb_refresh.mode")
    ap.add_argument("--kb-dir", default=None, help="Override config.kb_refresh.kb_dir (local mode)")
    ap.add_argument("--auto-promote", action="store_true", default=None,
                    help="Override config.kb_refresh.auto_promote")
    ap.add_argument("--promoted-by", default=None, help="Email for promotion record (local mode)")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--config", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    base = (cfg.get("central_base_url") or "").rstrip("/")
    kb_cfg = _kb_cfg(cfg)

    ws_dir = Path(args.out_dir) if args.out_dir else _workspace_dir(cfg, args.workspace_id)
    ws_dir.mkdir(parents=True, exist_ok=True)

    # Resolve config values (CLI overrides win)
    mode = args.mode or kb_cfg.get("mode") or "local"
    auto_promote = args.auto_promote if args.auto_promote is not None else bool(kb_cfg.get("auto_promote", False))
    promoted_by = args.promoted_by or kb_cfg.get("promoted_by") or ""
    batch_size = int(kb_cfg.get("batch_size") or 64)
    poll_interval = float(kb_cfg.get("central_poll_interval") or 5)
    max_wait = float(kb_cfg.get("central_poll_max_wait") or 300)

    print(f"[{_PLUGIN}] KB Refresh — mode={mode}  auto_promote={auto_promote}")

    if mode == "local":
        kb_dir = args.kb_dir or kb_cfg.get("kb_dir") or ""
        kb_indexer_dir = kb_cfg.get("kb_indexer_dir") or ""
        if not kb_dir:
            sys.exit(
                f"[{_PLUGIN}] config.kb_refresh.kb_dir is required for local mode — "
                "set it in aidlc.config.json or pass --kb-dir"
            )
        if not kb_indexer_dir:
            sys.exit(
                f"[{_PLUGIN}] config.kb_refresh.kb_indexer_dir is required for local mode — "
                "path to genai-aig-core-aidlc-platform-kb-indexer-7419/"
            )
        result = _run_local(
            workspace_id=args.workspace_id,
            kb_dir=kb_dir,
            kb_indexer_dir=kb_indexer_dir,
            auto_promote=auto_promote,
            promoted_by=promoted_by,
            batch_size=batch_size,
            dry_run=args.dry_run,
        )
    elif mode == "central":
        if not base:
            sys.exit(f"[{_PLUGIN}] config.central_base_url required for central mode")
        result = _run_central(
            workspace_id=args.workspace_id,
            base=base,
            cfg=cfg,
            poll_interval=poll_interval,
            max_wait=max_wait,
        )
    else:
        sys.exit(f"[{_PLUGIN}] Unknown kb_refresh.mode: '{mode}' — use 'local' or 'central'")

    if result.get("ok"):
        print(
            f"[{_PLUGIN}] [PASS] KB Refresh success: "
            f"new_kb_version={result.get('new_kb_version') or '?'}  "
            f"auto_promoted={result.get('auto_promoted')}"
        )
    else:
        print(f"[{_PLUGIN}] [FAIL] KB Refresh failed: {result.get('error')}")

    if not args.dry_run:
        out_path = ws_dir / _KB_REFRESH_RESULT
        out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"[{_PLUGIN}] Wrote {out_path}")

        # Append to MERGE_CONTEXT.md
        context_path = ws_dir / _CONTEXT_FILE
        if context_path.is_file():
            status_icon = "[PASS]" if result.get("ok") else "[FAIL]"
            append = [
                "",
                "---",
                "",
                "## KB Refresh",
                "",
                f"**Status:** {status_icon} {'Success' if result.get('ok') else 'Failed'}  ",
                f"**Mode:** `{mode}`  ",
                f"**New KB Version:** `{result.get('new_kb_version') or '(pending)'}` (STAGING)  ",
                f"**Auto-Promoted:** {result.get('auto_promoted')}  ",
                "",
            ]
            if not result.get("ok"):
                append.append(f"> [FAIL] Error: {result.get('error')}")
                append.append("")
            context_path.write_text(
                context_path.read_text(encoding="utf-8") + "\n".join(append),
                encoding="utf-8",
            )

    print(f"[{_PLUGIN}] Next: run aidlc_merge_changelog.py then aidlc_sync_merge.py")


if __name__ == "__main__":
    main()
