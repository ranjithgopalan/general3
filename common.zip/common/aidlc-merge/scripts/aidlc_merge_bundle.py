"""Merge bundle fetcher — Step 1 of the Epic Assembler (aidlc-merge plugin, docs/27).

Fetches all epics for the workspace from central, collects the PR metadata left by
the develop and QA plugins from the local .aidlc workspace directory, and renders a
human-readable MERGE_CONTEXT.md so the operator can review before merging.

Outputs written to ``.aidlc/<workspace_id>/``:
  merge-bundle.json   — machine-readable: epics + features + stories + PR lists + trace data
  MERGE_CONTEXT.md    — human-readable summary for operator review

Usage:
  python aidlc_merge_bundle.py <workspace_id>
      [--epic-ids ID1,ID2,...]   # filter specific epics (default: all)
      [--out-dir PATH]           # output directory (default: .aidlc/<workspace_id>)
      [--config PATH]            # aidlc.config.json path
      [--dry-run]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import aidlc_auth

# ── Constants ────────────────────────────────────────────────────────────────

_PLUGIN = "aidlc-merge"
_BUNDLE_FILE = "merge-bundle.json"
_CONTEXT_FILE = "MERGE_CONTEXT.md"
_DEV_PR_META = "dev-pr-meta.json"
_QA_PR_META = "qa-pr-meta.json"
_PLAYWRIGHT_TRACE = "playwright-trace.json"
_QA_FINDINGS = "qa-findings.json"

_EPIC_STATUSES_READY = {"qa_in_progress", "dev_done", "done"}


# ── Config helpers ────────────────────────────────────────────────────────────

def _workspace_dir(cfg: dict[str, Any], workspace_id: str) -> Path:
    base = (cfg.get("workspace_dir") or ".aidlc").rstrip("/\\")
    return Path(base) / workspace_id


def _load_json_optional(path: Path) -> Any:
    """Load a JSON file; return None if absent."""
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


# ── Central API fetchers ──────────────────────────────────────────────────────

def _fetch_workspace(base: str, workspace_id: str, cfg: dict[str, Any]) -> dict[str, Any]:
    url = f"{base}/ws/{workspace_id}"
    print(f"[{_PLUGIN}] Fetching workspace {workspace_id} ...")
    return aidlc_auth.get_json(url, cfg)


def _fetch_epics(base: str, workspace_id: str, cfg: dict[str, Any]) -> list[dict[str, Any]]:
    url = f"{base}/ws/{workspace_id}/epics"
    print(f"[{_PLUGIN}] Fetching epics ...")
    result = aidlc_auth.get_json(url, cfg)
    # Some versions return the list directly
    if isinstance(result, list):
        return result
    epics = result.get("epics") or []
    if isinstance(epics, list):
        return epics
    return []


def _fetch_epic_detail(
    base: str, workspace_id: str, epic_id: str, cfg: dict[str, Any]
) -> dict[str, Any]:
    url = f"{base}/ws/{workspace_id}/epics/{epic_id}"
    return aidlc_auth.get_json_optional(url, cfg)


# ── Local artifact collection ─────────────────────────────────────────────────

def _collect_local_artifacts(
    ws_dir: Path, workspace_id: str, cfg: dict[str, Any] | None = None
) -> dict[str, Any]:
    """
    Collect PR metadata + trace files written by develop and QA plugins.

    Search order for QA artifacts:
    1. ws_dir/qa-pr-meta.json               (workspace-level, same plugin dir)
    2. ws_dir/epics/*/qa-pr-meta.json       (per-epic, same plugin dir — aidlc-qa co-located)
    3. <qa_workspace_root>/<ws_id>/qa-pr-meta.json       (cross-plugin root, workspace-level)
    4. <qa_workspace_root>/<ws_id>/epics/*/qa-pr-meta.json (cross-plugin root, per-epic)

    Config key: ``qa_workspace_root`` — path to the aidlc-qa plugin's ``.aidlc`` root directory.
    Example: ``"qa_workspace_root": "../aidlc-qa/.aidlc"``

    :inputs: ws_dir (Path) - workspace dir (.aidlc/<ws_id>); workspace_id (str);
             cfg (dict|None) - loaded config (for qa_workspace_root)
    :outputs: (dict[str, Any]) - local artifact dict
    """
    artifacts: dict[str, Any] = {
        "dev_prs": [],
        "qa_prs": [],
        "playwright_trace": [],
        "qa_findings": [],
    }

    # ── Dev PR metadata ───────────────────────────────────────────────────────
    # 1. Workspace-level file
    dev_meta = _load_json_optional(ws_dir / _DEV_PR_META)
    if dev_meta is not None:
        artifacts["dev_prs"] = dev_meta if isinstance(dev_meta, list) else [dev_meta]
        print(f"[{_PLUGIN}] Loaded {len(artifacts['dev_prs'])} dev PR record(s) from {_DEV_PR_META}")
    else:
        # 2. Per-epic sub-dirs
        epic_dev_prs = _scan_epic_pr_meta(ws_dir, _DEV_PR_META)
        if epic_dev_prs:
            artifacts["dev_prs"] = epic_dev_prs
            print(f"[{_PLUGIN}] Loaded {len(epic_dev_prs)} dev PR record(s) from per-epic sub-dirs")
        else:
            print(f"[{_PLUGIN}] WARNING: {_DEV_PR_META} not found in {ws_dir} — no dev PR metadata available")

    # ── QA PR metadata ────────────────────────────────────────────────────────
    # 1. Workspace-level file (same plugin dir)
    qa_meta = _load_json_optional(ws_dir / _QA_PR_META)
    if qa_meta is not None:
        artifacts["qa_prs"] = qa_meta if isinstance(qa_meta, list) else [qa_meta]
        print(f"[{_PLUGIN}] Loaded {len(artifacts['qa_prs'])} QA PR record(s) from {_QA_PR_META}")
    else:
        # 2. Per-epic sub-dirs in same ws_dir (aidlc-qa co-located pattern)
        qa_prs = _scan_epic_pr_meta(ws_dir, _QA_PR_META)

        # 3+4. Cross-plugin root (aidlc-qa lives in a different plugin directory)
        if not qa_prs and cfg:
            qa_root_str = (cfg.get("qa_workspace_root") or "").strip()
            if qa_root_str:
                qa_root = Path(qa_root_str) / workspace_id
                # 3. workspace-level in qa root
                cross_ws = _load_json_optional(qa_root / _QA_PR_META)
                if cross_ws is not None:
                    qa_prs = cross_ws if isinstance(cross_ws, list) else [cross_ws]
                    print(f"[{_PLUGIN}] Loaded {len(qa_prs)} QA PR record(s) from qa_workspace_root (ws-level)")
                else:
                    # 4. per-epic in qa root
                    qa_prs = _scan_epic_pr_meta(qa_root, _QA_PR_META)
                    if qa_prs:
                        print(f"[{_PLUGIN}] Loaded {len(qa_prs)} QA PR record(s) from qa_workspace_root (per-epic)")

        if qa_prs:
            artifacts["qa_prs"] = qa_prs
            if not (qa_meta is not None):  # avoid double-print
                print(f"[{_PLUGIN}] Loaded {len(qa_prs)} QA PR record(s) from per-epic sub-dirs")
        else:
            print(f"[{_PLUGIN}] WARNING: {_QA_PR_META} not found in {ws_dir} (or qa_workspace_root) — no QA PR metadata available")

    # ── Playwright trace ──────────────────────────────────────────────────────
    # 1. Workspace-level
    trace = _load_json_optional(ws_dir / _PLAYWRIGHT_TRACE)
    if trace is not None:
        artifacts["playwright_trace"] = trace if isinstance(trace, list) else []
        print(f"[{_PLUGIN}] Loaded {len(artifacts['playwright_trace'])} playwright trace entry(s)")
    else:
        # 2. Aggregate per-epic playwright traces
        traces = _scan_epic_json_list(ws_dir, _PLAYWRIGHT_TRACE)
        if not traces and cfg:
            qa_root_str = (cfg.get("qa_workspace_root") or "").strip()
            if qa_root_str:
                traces = _scan_epic_json_list(Path(qa_root_str) / workspace_id, _PLAYWRIGHT_TRACE)
        if traces:
            artifacts["playwright_trace"] = traces
            print(f"[{_PLUGIN}] Loaded {len(traces)} playwright trace entry(s) from per-epic sub-dirs")

    # ── QA findings ───────────────────────────────────────────────────────────
    findings = _load_json_optional(ws_dir / _QA_FINDINGS)
    if findings is not None:
        artifacts["qa_findings"] = findings if isinstance(findings, list) else []
        print(f"[{_PLUGIN}] Loaded {len(artifacts['qa_findings'])} QA finding(s)")
    else:
        # Per-epic findings
        all_findings = _scan_epic_json_list(ws_dir, _QA_FINDINGS)
        if not all_findings and cfg:
            qa_root_str = (cfg.get("qa_workspace_root") or "").strip()
            if qa_root_str:
                all_findings = _scan_epic_json_list(Path(qa_root_str) / workspace_id, _QA_FINDINGS)
        if all_findings:
            artifacts["qa_findings"] = all_findings
            print(f"[{_PLUGIN}] Loaded {len(all_findings)} QA finding(s) from per-epic sub-dirs")

    return artifacts


def _scan_epic_pr_meta(ws_dir: Path, filename: str) -> list[dict[str, Any]]:
    """
    Scan ws_dir/epics/*/filename for per-epic PR metadata files.
    Returns a flat list of all records found (one record per epic).

    :inputs: ws_dir (Path) - workspace dir; filename (str) - e.g. "qa-pr-meta.json"
    :outputs: (list[dict]) - list of PR metadata records, one per found file
    """
    epics_dir = ws_dir / "epics"
    if not epics_dir.is_dir():
        return []
    records: list[dict[str, Any]] = []
    for epic_dir in sorted(epics_dir.iterdir()):
        if not epic_dir.is_dir():
            continue
        rec = _load_json_optional(epic_dir / filename)
        if rec is not None:
            if isinstance(rec, list):
                records.extend(rec)
            else:
                records.append(rec)
    return records


def _scan_epic_json_list(ws_dir: Path, filename: str) -> list[Any]:
    """
    Scan ws_dir/epics/*/filename and merge all list-valued JSON files into one flat list.

    :inputs: ws_dir (Path) - workspace dir; filename (str)
    :outputs: (list[Any]) - merged list from all per-epic files
    """
    epics_dir = ws_dir / "epics"
    if not epics_dir.is_dir():
        return []
    merged: list[Any] = []
    for epic_dir in sorted(epics_dir.iterdir()):
        if not epic_dir.is_dir():
            continue
        data = _load_json_optional(epic_dir / filename)
        if data is None:
            continue
        if isinstance(data, list):
            merged.extend(data)
        else:
            merged.append(data)
    return merged


# ── Epic ↔ PR association ─────────────────────────────────────────────────────

def _associate_prs(
    epics: list[dict[str, Any]],
    dev_prs: list[dict[str, Any]],
    qa_prs: list[dict[str, Any]],
) -> None:
    """
    Annotate each epic dict with matched dev + QA PRs (in-place).
    Matching: PR records that have 'epic_id' field == epic['id'].
    Unmatched PRs are attached to the first epic (workspace-level fallback).

    :inputs: epics, dev_prs, qa_prs (lists)
    :outputs: None (mutates epics in-place)
    """
    for epic in epics:
        epic_id = str(epic.get("id") or epic.get("epic_id") or "")
        epic["_dev_prs"] = [p for p in dev_prs if str(p.get("epic_id") or "") == epic_id]
        epic["_qa_prs"] = [p for p in qa_prs if str(p.get("epic_id") or "") == epic_id]

    # Workspace-level PRs (no epic_id): attach to first epic
    if epics:
        unmatched_dev = [p for p in dev_prs if not p.get("epic_id")]
        unmatched_qa = [p for p in qa_prs if not p.get("epic_id")]
        if unmatched_dev:
            epics[0]["_dev_prs"].extend(unmatched_dev)
            print(
                f"[{_PLUGIN}] {len(unmatched_dev)} workspace-level dev PR(s) attached to first epic "
                f"'{epics[0].get('title') or epics[0].get('id')}'"
            )
        if unmatched_qa:
            epics[0]["_qa_prs"].extend(unmatched_qa)
            print(
                f"[{_PLUGIN}] {len(unmatched_qa)} workspace-level QA PR(s) attached to first epic"
            )


# ── MERGE_CONTEXT.md renderer ─────────────────────────────────────────────────

def _render_context_md(
    workspace: dict[str, Any],
    epics: list[dict[str, Any]],
    local_artifacts: dict[str, Any],
    epic_filter: list[str] | None,
) -> str:
    """
    Render a human-readable MERGE_CONTEXT.md for operator review.

    :inputs: workspace (dict) - workspace record; epics (list) - epic details with _dev_prs/_qa_prs;
             local_artifacts (dict) - dev/QA PR metadata + trace; epic_filter (list|None) - filtered IDs
    :outputs: (str) - markdown content
    """
    ws_id = workspace.get("id") or workspace.get("workspace_id") or "unknown"
    ws_state = workspace.get("state") or workspace.get("status") or "unknown"
    ws_req = (workspace.get("requirement") or "")[:200]

    lines: list[str] = [
        "# Merge Context",
        "",
        f"**Workspace:** `{ws_id}`  ",
        f"**State:** `{ws_state}`  ",
        f"**Requirement:** {ws_req}  ",
        f"**Epics:** {len(epics)} (filtered: {', '.join(epic_filter) if epic_filter else 'all'})  ",
        "",
        "---",
        "",
        "## Epics & PRs",
        "",
    ]

    total_dev_prs = 0
    total_qa_prs = 0
    blockers: list[str] = []

    for epic in epics:
        epic_id = str(epic.get("id") or epic.get("epic_id") or "?")
        title = epic.get("title") or "(no title)"
        status = epic.get("status") or "unknown"
        dev_prs = epic.get("_dev_prs") or []
        qa_prs = epic.get("_qa_prs") or []
        features = epic.get("features") or []

        lines.append(f"### Epic `{epic_id}` — {title}")
        lines.append(f"**Status:** `{status}`")
        lines.append("")

        if status not in _EPIC_STATUSES_READY:
            msg = f"Epic `{epic_id}` status is `{status}` — expected qa_in_progress or dev_done"
            lines.append(f"> [WARN] **BLOCKER:** {msg}")
            blockers.append(msg)
            lines.append("")

        # Stories summary
        story_count = sum(len(f.get("stories") or []) for f in features)
        lines.append(f"**Features:** {len(features)} | **Stories:** {story_count}")
        lines.append("")

        # Dev PRs
        lines.append("**Dev PRs:**")
        if dev_prs:
            for pr in dev_prs:
                pr_url = pr.get("pr_url") or pr.get("url") or "(no URL)"
                pr_num = pr.get("pr_number") or pr.get("number") or "?"
                repo = pr.get("repo") or pr.get("repository") or "?"
                branch = pr.get("branch") or "?"
                lines.append(f"- PR #{pr_num} | {repo} | branch: `{branch}` | {pr_url}")
            total_dev_prs += len(dev_prs)
        else:
            lines.append("- _(none found in local metadata)_")

        lines.append("")

        # QA PRs
        lines.append("**QA PRs:**")
        if qa_prs:
            for pr in qa_prs:
                pr_url = pr.get("pr_url") or pr.get("url") or "(no URL)"
                pr_num = pr.get("pr_number") or pr.get("number") or "?"
                repo = pr.get("repo") or pr.get("repository") or "?"
                branch = pr.get("branch") or "?"
                lines.append(f"- PR #{pr_num} | {repo} | branch: `{branch}` | {pr_url}")
            total_qa_prs += len(qa_prs)
        else:
            lines.append("- _(none found in local metadata)_")

        lines.append("")
        lines.append("---")
        lines.append("")

    # Summary
    lines.append("## Summary")
    lines.append("")
    lines.append(f"| Item | Count |")
    lines.append(f"|---|---|")
    lines.append(f"| Epics | {len(epics)} |")
    lines.append(f"| Dev PRs | {total_dev_prs} |")
    lines.append(f"| QA PRs | {total_qa_prs} |")
    lines.append(f"| Playwright trace entries | {len(local_artifacts.get('playwright_trace') or [])} |")
    lines.append(f"| QA findings | {len(local_artifacts.get('qa_findings') or [])} |")
    lines.append("")

    if blockers:
        lines.append("## [WARN] Blockers Found")
        lines.append("")
        for b in blockers:
            lines.append(f"- {b}")
        lines.append("")
        lines.append(
            "> Run `aidlc_merge_review.py` to get full CI/review status, "
            "then `aidlc_merge_execute.py` to merge (blockers will be skipped + reported)."
        )
    else:
        lines.append("## [PASS] No Blockers Detected at Bundle Stage")
        lines.append("")
        lines.append("> Run `aidlc_merge_review.py` next to verify CI + review status on all PRs.")

    lines.append("")
    lines.append("## Next Steps")
    lines.append("")
    lines.append(
        "```\n"
        "python aidlc_merge_review.py   <workspace_id>   # Review PR CI + approvals\n"
        "python aidlc_merge_execute.py  <workspace_id>   # Squash-merge approved PRs\n"
        "python aidlc_merge_kb_refresh.py <workspace_id> # Invoke KB indexer (new STAGING)\n"
        "python aidlc_merge_changelog.py  <workspace_id> # Generate CHANGELOG.md\n"
        "python aidlc_sync_merge.py      <workspace_id>  # Sync results + advance to PENDING_SYNC\n"
        "```"
    )

    return "\n".join(lines)


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    """
    Fetch merge bundle from central + local artifacts and write merge-bundle.json + MERGE_CONTEXT.md.

    :inputs: None (reads args from sys.argv)
    :outputs: None (writes files to workspace_dir)
    """
    ap = argparse.ArgumentParser(
        description="Step 1 — fetch merge bundle (all epics + PRs + trace) for a workspace."
    )
    ap.add_argument("workspace_id")
    ap.add_argument(
        "--epic-ids", default=None,
        help="Comma-separated list of epic IDs to include (default: all epics)"
    )
    ap.add_argument("--out-dir", default=None, help="Output directory (default: .aidlc/<workspace_id>)")
    ap.add_argument("--config", default=None)
    ap.add_argument("--dry-run", action="store_true", help="Fetch data but do not write files")
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    base = (cfg.get("central_base_url") or "").rstrip("/")
    if not base:
        sys.exit(f"[{_PLUGIN}] config.central_base_url is required")

    ws_dir = Path(args.out_dir) if args.out_dir else _workspace_dir(cfg, args.workspace_id)
    if not args.dry_run:
        ws_dir.mkdir(parents=True, exist_ok=True)

    # Parse epic filter
    epic_filter: list[str] | None = None
    if args.epic_ids:
        epic_filter = [e.strip() for e in args.epic_ids.split(",") if e.strip()]

    # Fetch workspace
    workspace = _fetch_workspace(base, args.workspace_id, cfg)

    # Fetch epics list
    all_epics = _fetch_epics(base, args.workspace_id, cfg)
    print(f"[{_PLUGIN}] Found {len(all_epics)} epic(s) in workspace")

    # Apply filter
    if epic_filter:
        all_epics = [
            e for e in all_epics
            if str(e.get("id") or e.get("epic_id") or "") in epic_filter
        ]
        print(f"[{_PLUGIN}] After filter: {len(all_epics)} epic(s)")

    # Fetch full detail for each epic
    detailed_epics: list[dict[str, Any]] = []
    for epic in all_epics:
        epic_id = str(epic.get("id") or epic.get("epic_id") or "")
        if not epic_id:
            continue
        print(f"[{_PLUGIN}] Fetching detail for epic {epic_id} ...")
        detail = _fetch_epic_detail(base, args.workspace_id, epic_id, cfg)
        if detail:
            detailed_epics.append(detail)
        else:
            # Fallback to the summary record
            detailed_epics.append(epic)

    # Collect local PR metadata + trace
    local_artifacts = _collect_local_artifacts(ws_dir, args.workspace_id, cfg)

    # Associate PRs to epics
    _associate_prs(detailed_epics, local_artifacts["dev_prs"], local_artifacts["qa_prs"])

    # Build merge bundle
    bundle: dict[str, Any] = {
        "workspace_id": args.workspace_id,
        "workspace": workspace,
        "epic_filter": epic_filter,
        "epics": detailed_epics,
        "local_artifacts": local_artifacts,
    }

    # Render context doc
    context_md = _render_context_md(workspace, detailed_epics, local_artifacts, epic_filter)

    if args.dry_run:
        print(f"[{_PLUGIN}] --dry-run: would write {_BUNDLE_FILE} and {_CONTEXT_FILE}")
        print(context_md)
        return

    bundle_path = ws_dir / _BUNDLE_FILE
    bundle_path.write_text(json.dumps(bundle, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[{_PLUGIN}] Wrote {bundle_path}")

    context_path = ws_dir / _CONTEXT_FILE
    context_path.write_text(context_md, encoding="utf-8")
    print(f"[{_PLUGIN}] Wrote {context_path}")

    # Summary
    total_dev = sum(len(e.get("_dev_prs") or []) for e in detailed_epics)
    total_qa = sum(len(e.get("_qa_prs") or []) for e in detailed_epics)
    print(
        f"[{_PLUGIN}] Bundle complete: "
        f"{len(detailed_epics)} epic(s), {total_dev} dev PR(s), {total_qa} QA PR(s)"
    )
    print(f"[{_PLUGIN}] Review {_CONTEXT_FILE} then run aidlc_merge_review.py")


if __name__ == "__main__":
    main()
