"""Shared authentication module and CLI for AIDLC cockpit plugins.

Canonical source: plugins/_shared/aidlc_auth.py
Copied into each consuming plugin's scripts/ via plugins/scripts/sync-shared.py.
Stdlib-only — do not add third-party imports.

Obtains scope:
  browser_login  -> user Okta identity token (+ refresh token) only.
  build_headers  -> attaches both the user Bearer token and the separately-provisioned
                    platform HMAC key (X-Platform-Api-Key), never conflating the two.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import http.server
import json
import os
import secrets
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from pathlib import Path
from typing import Any

_DEFAULT_CONFIG = "aidlc.config.json"
_DEFAULT_TOKEN_CACHE = "~/.aidlc/token.json"
_TOKEN_SKEW_SECONDS = 60        # treat token as expired this many seconds early
_BROWSER_LOGIN_TIMEOUT = 120    # seconds to wait for the loopback callback


# ── Config ───────────────────────────────────────────────────────────────────────

def load_config(explicit: str | None = None) -> dict[str, Any]:
    """Resolve and parse the plugin config (--config > $AIDLC_CONFIG > ./aidlc.config.json).

    :inputs: explicit (str | None) - explicit config path override
    :outputs: (dict[str, Any]) - parsed config dict
    """
    path = explicit or os.environ.get("AIDLC_CONFIG") or _DEFAULT_CONFIG
    p = Path(path)
    if not p.is_file():
        sys.exit(
            f"[aidlc] config not found: {p} "
            f"(copy config/aidlc.config.example.json -> {_DEFAULT_CONFIG})"
        )
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        sys.exit(f"[aidlc] config is not valid JSON: {p}: {exc}")


# ── Token cache helpers ──────────────────────────────────────────────────────────

def _cache_path(okta_cfg: dict[str, Any]) -> Path:
    """Return the resolved token cache file path.

    :inputs: okta_cfg (dict[str, Any]) - auth.okta config block
    :outputs: (Path) - resolved absolute path to token.json
    """
    raw = okta_cfg.get("token_cache") or _DEFAULT_TOKEN_CACHE
    return Path(raw).expanduser()


def _read_cache(cache_file: Path, issuer: str) -> dict[str, Any] | None:
    """Read and validate the token cache; return None if missing, corrupt, or issuer-mismatched.

    :inputs: cache_file (Path) - path to token.json; issuer (str) - expected Okta issuer
    :outputs: (dict[str, Any] | None) - session dict or None
    """
    if not cache_file.is_file():
        return None
    try:
        data = json.loads(cache_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    if not isinstance(data, dict):
        return None
    if data.get("issuer") != issuer:
        return None
    return data


def _write_cache(cache_file: Path, session: dict[str, Any]) -> None:
    """Write the session dict to token.json at mode 0600.

    :inputs: cache_file (Path) - destination path; session (dict[str, Any]) - token session data
    :outputs: None
    """
    cache_file.parent.mkdir(parents=True, exist_ok=True)
    cache_file.write_text(json.dumps(session, indent=2), encoding="utf-8")
    cache_file.chmod(0o600)


def _is_token_valid(session: dict[str, Any]) -> bool:
    """Return True if the access token has not yet expired (with skew guard).

    :inputs: session (dict[str, Any]) - cached session dict
    :outputs: (bool) - True when the token can still be used
    """
    expires_at = session.get("expires_at")
    if not isinstance(expires_at, (int, float)):
        return False
    return time.time() < expires_at - _TOKEN_SKEW_SECONDS


# ── PKCE ────────────────────────────────────────────────────────────────────────

def _pkce_pair() -> tuple[str, str]:
    """Generate a PKCE (code_verifier, code_challenge) pair using S256.

    :inputs: None
    :outputs: (tuple[str, str]) - (code_verifier, code_challenge)
    """
    # token_urlsafe(96) -> 128-char URL-safe string, within the 43-128 RFC 7636 range
    verifier = secrets.token_urlsafe(96)
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


def _decode_sub(jwt_like: str) -> str:
    """Best-effort extraction of 'sub' from a JWT payload (informational only; not verified).

    :inputs: jwt_like (str) - a JWT or access-token string
    :outputs: (str) - subject claim, or empty string on failure
    """
    parts = jwt_like.split(".")
    if len(parts) < 2:
        return ""
    try:
        padded = parts[1] + "=" * (-len(parts[1]) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded).decode("utf-8", "replace"))
        return str(payload.get("sub") or payload.get("email") or "")
    except Exception:
        return ""


# ── Browser login — build-ui token relay ─────────────────────────────────────────

def browser_login(okta_cfg: dict[str, Any]) -> dict[str, Any]:
    """Get the Okta access token by relaying from the AIDLC build-ui session.

    Instead of a full PKCE redirect flow (which requires a registered redirect URI),
    opens http://localhost:4200/plugin-token-bridge in the browser. That Angular page
    reads the active Okta access_token from localStorage and POSTs it back here via a
    one-shot loopback HTTP server. No additional Okta redirect URI registration needed.

    Pre-condition: the user must be logged into the build-ui at build_ui_url (default
    http://localhost:4200). If not logged in, the bridge page will prompt them to do so.

    :inputs: okta_cfg (dict[str, Any]) - auth.okta config block
    :outputs: (dict[str, Any]) - session dict (access_token, expires_at, sub, issuer)
    """
    issuer = (okta_cfg.get("issuer") or "").rstrip("/")
    port = int(okta_cfg.get("redirect_port") or 8765)
    build_ui_url = (okta_cfg.get("build_ui_url") or "http://localhost:4200").rstrip("/")
    bridge_url = f"{build_ui_url}/plugin-token-bridge?port={port}"

    result: dict[str, str] = {}
    done_event = threading.Event()

    class _Handler(http.server.BaseHTTPRequestHandler):
        def do_OPTIONS(self) -> None:  # CORS preflight from Angular fetch
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", build_ui_url)
            self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.end_headers()

        def do_POST(self) -> None:
            if self.path != "/relay":
                self.send_response(404)
                self.end_headers()
                return
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            self.send_response(200)
            self.send_header("Access-Control-Allow-Origin", build_ui_url)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"ok":true}')
            try:
                result["access_token"] = json.loads(body).get("access_token") or ""
            except (json.JSONDecodeError, AttributeError):
                pass
            done_event.set()

        def log_message(self, *args: Any) -> None:
            pass  # suppress HTTP server logs to stdout

    try:
        server = http.server.HTTPServer(("127.0.0.1", port), _Handler)
    except OSError as exc:
        sys.exit(
            f"[aidlc] cannot bind port {port} for plugin token relay: {exc}. "
            "Change auth.okta.redirect_port or free the port."
        )

    # Serve both the CORS OPTIONS preflight and the POST with the token.
    def _serve() -> None:
        server.handle_request()  # OPTIONS preflight (browser sends this before the POST)
        server.handle_request()  # POST containing the access_token

    threading.Thread(target=_serve, daemon=True).start()
    print(f"[aidlc] Opening AIDLC Platform to retrieve your session token ...")
    print(f"[aidlc] If the page says 'Not logged in', open {build_ui_url}, log in, then re-run.")
    webbrowser.open(bridge_url)

    if not done_event.wait(timeout=_BROWSER_LOGIN_TIMEOUT):
        server.server_close()
        sys.exit(f"[aidlc] plugin token relay timed out after {_BROWSER_LOGIN_TIMEOUT}s")

    server.server_close()

    token = result.get("access_token") or ""
    if not token:
        sys.exit(
            f"[aidlc] no access token received — make sure you are logged into {build_ui_url} first"
        )

    # Decode exp and sub from the JWT payload (stdlib only, no third-party deps).
    sub = _decode_sub(token)
    try:
        payload_b64 = token.split(".")[1]
        padded = payload_b64 + "=" * (-len(payload_b64) % 4)
        payload_data: dict[str, Any] = json.loads(
            base64.urlsafe_b64decode(padded).decode("utf-8")
        )
        expires_at = float(payload_data.get("exp") or (time.time() + 3600))
    except Exception:
        expires_at = time.time() + 3600

    session: dict[str, Any] = {
        "access_token": token,
        "refresh_token": None,
        "expires_at": expires_at,
        "token_type": "Bearer",
        "sub": sub,
    }
    cache_file = _cache_path(okta_cfg)
    _write_cache(cache_file, {**session, "issuer": issuer})
    print(f"[aidlc] Authenticated as: {sub or '(unknown)'}")
    return session


def _exchange_code(
    issuer: str,
    client_id: str,
    code: str,
    verifier: str,
    redirect_uri: str,
) -> dict[str, Any]:
    """Exchange authorization code for tokens via POST {issuer}/v1/token.

    :inputs: issuer (str) - Okta issuer URL; client_id (str) - public client ID;
             code (str) - authorization code; verifier (str) - PKCE code verifier;
             redirect_uri (str) - loopback redirect URI
    :outputs: (dict[str, Any]) - session dict with computed expires_at and sub
    """
    body = urllib.parse.urlencode({
        "grant_type": "authorization_code",
        "code": code,
        "code_verifier": verifier,
        "redirect_uri": redirect_uri,
        "client_id": client_id,
    }).encode("ascii")
    req = urllib.request.Request(
        f"{issuer}/v1/token", data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw: dict[str, Any] = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        sys.exit(
            f"[aidlc] token exchange failed HTTP {exc.code}: "
            f"{exc.read().decode('utf-8', 'replace')[:400]}"
        )
    except urllib.error.URLError as exc:
        sys.exit(f"[aidlc] token exchange failed: {exc.reason}")

    expires_in = int(raw.get("expires_in") or 3600)
    sub = _decode_sub(raw.get("id_token") or raw.get("access_token") or "")
    return {
        "access_token": raw["access_token"],
        "refresh_token": raw.get("refresh_token"),
        "expires_at": time.time() + expires_in,
        "token_type": raw.get("token_type", "Bearer"),
        "sub": sub,
    }


def _refresh_token(
    issuer: str,
    client_id: str,
    refresh_tok: str,
    cache_file: Path,
    okta_cfg: dict[str, Any],
) -> str | None:
    """Attempt a silent token refresh; update cache on success; return new access_token or None.

    :inputs: issuer (str) - Okta issuer; client_id (str) - public client ID;
             refresh_tok (str) - current refresh token; cache_file (Path) - cache path;
             okta_cfg (dict[str, Any]) - full okta config block
    :outputs: (str | None) - refreshed access token, or None if refresh failed
    """
    body = urllib.parse.urlencode({
        "grant_type": "refresh_token",
        "refresh_token": refresh_tok,
        "client_id": client_id,
    }).encode("ascii")
    req = urllib.request.Request(
        f"{issuer}/v1/token", data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw: dict[str, Any] = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.HTTPError, urllib.error.URLError):
        return None  # refresh failed — fall through to re-login

    expires_in = int(raw.get("expires_in") or 3600)
    session = {
        "access_token": raw["access_token"],
        "refresh_token": raw.get("refresh_token") or refresh_tok,
        "expires_at": time.time() + expires_in,
        "token_type": raw.get("token_type", "Bearer"),
        "sub": _decode_sub(raw.get("id_token") or raw.get("access_token") or ""),
        "issuer": issuer,
    }
    _write_cache(cache_file, session)
    return raw["access_token"]


# ── Token resolution ladder ──────────────────────────────────────────────────────

def get_token(cfg: dict[str, Any]) -> str | None:
    """Resolve an access token: valid cache → refresh → bearer_env → browser_login.

    Returns None when no auth.okta block and no bearer_env token are present — this
    is the dev fallback (unauthenticated localhost) and is identical to today's behavior.

    :inputs: cfg (dict[str, Any]) - plugin config dict
    :outputs: (str | None) - access token, or None for dev fallback
    """
    auth = cfg.get("auth") or {}
    okta_cfg: dict[str, Any] | None = auth.get("okta")

    if okta_cfg:
        issuer = (okta_cfg.get("issuer") or "").rstrip("/")
        cache_file = _cache_path(okta_cfg)
        cached = _read_cache(cache_file, issuer)
        if cached:
            if _is_token_valid(cached):
                return cached["access_token"]
            # Expired — try silent refresh
            refresh_tok = cached.get("refresh_token")
            if refresh_tok:
                new_token = _refresh_token(
                    issuer, okta_cfg.get("client_id") or "",
                    refresh_tok, cache_file, okta_cfg,
                )
                if new_token:
                    return new_token
        # Cache missing / corrupt / refresh failed → fall through

    # bearer_env fallback (works even without an okta block)
    bearer_env = auth.get("bearer_env")
    if bearer_env and os.environ.get(bearer_env):
        return os.environ[bearer_env]

    # Browser login (requires okta block to be configured)
    if okta_cfg:
        session = browser_login(okta_cfg)
        return session["access_token"]

    # Dev fallback — no token
    return None


# ── HTTP helpers ─────────────────────────────────────────────────────────────────

def build_headers(cfg: dict[str, Any]) -> dict[str, str]:
    """Build HTTP request headers: bearer token + platform HMAC key, both from config-named env vars.

    When no okta block and no env token exist the output is identical to today's
    unauthenticated headers (spec FR-008 / SC-007 dev fallback preserved).

    :inputs: cfg (dict[str, Any]) - plugin config dict
    :outputs: (dict[str, str]) - headers dict (Accept always included; Authorization and X-Platform-Api-Key added when available)
    """
    headers: dict[str, str] = {"Accept": "application/json"}
    token = get_token(cfg)
    if token:
        headers["Authorization"] = f"Bearer {token}"
    auth = cfg.get("auth") or {}
    api_key_env = auth.get("api_key_env")
    if api_key_env and os.environ.get(api_key_env):
        headers["X-Platform-Api-Key"] = os.environ[api_key_env]
    return headers


def get_json(url: str, cfg: dict[str, Any], timeout: float = 120.0) -> dict[str, Any]:
    """GET a JSON document; exit non-zero with a clear message on HTTP/transport error.

    :inputs: url (str) - request URL; cfg (dict[str, Any]) - plugin config; timeout (float) - request timeout in seconds
    :outputs: (dict[str, Any]) - parsed JSON response body
    """
    req = urllib.request.Request(url, headers=build_headers(cfg), method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        sys.exit(
            f"[aidlc] GET {url} -> HTTP {exc.code}: "
            f"{exc.read().decode('utf-8', 'replace')[:400]}"
        )
    except urllib.error.URLError as exc:
        sys.exit(f"[aidlc] cannot reach central at {url}: {exc.reason}")


def get_json_optional(url: str, cfg: dict[str, Any], timeout: float = 120.0) -> dict[str, Any]:
    """GET a JSON document; return empty dict on 404 (not yet generated).

    :inputs: url (str) - request URL; cfg (dict[str, Any]) - plugin config; timeout (float) - request timeout in seconds
    :outputs: (dict[str, Any]) - parsed JSON response, or {} when the resource does not exist yet
    """
    req = urllib.request.Request(url, headers=build_headers(cfg), method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return {}
        sys.exit(
            f"[aidlc] GET {url} -> HTTP {exc.code}: "
            f"{exc.read().decode('utf-8', 'replace')[:400]}"
        )
    except urllib.error.URLError as exc:
        sys.exit(f"[aidlc] cannot reach central at {url}: {exc.reason}")


def post_json(
    url: str,
    cfg: dict[str, Any],
    body: dict[str, Any],
    timeout: float = 120.0,
) -> dict[str, Any]:
    """POST a JSON document; exit non-zero with a clear message on HTTP/transport error.

    :inputs: url (str) - request URL; cfg (dict[str, Any]) - plugin config; body (dict[str, Any]) - JSON payload; timeout (float) - request timeout in seconds
    :outputs: (dict[str, Any]) - parsed JSON response body
    """
    headers = {**build_headers(cfg), "Content-Type": "application/json"}
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        sys.exit(
            f"[aidlc] POST {url} -> HTTP {exc.code}: "
            f"{exc.read().decode('utf-8', 'replace')[:400]}"
        )
    except urllib.error.URLError as exc:
        sys.exit(f"[aidlc] cannot reach central at {url}: {exc.reason}")


# ── CLI: login | whoami | logout ─────────────────────────────────────────────────

def _cli_login(cfg: dict[str, Any]) -> None:
    """Perform browser login and print the authenticated subject.

    :inputs: cfg (dict[str, Any]) - plugin config
    :outputs: None
    """
    okta_cfg = (cfg.get("auth") or {}).get("okta")
    if not okta_cfg:
        sys.exit("[aidlc] auth.okta is not configured — cannot perform browser login")
    session = browser_login(okta_cfg)
    print(f"[aidlc] Signed in as: {session.get('sub') or '(unknown)'}")


def _cli_whoami(cfg: dict[str, Any]) -> None:
    """Print the cached subject and expiry; exit 1 if not logged in.

    :inputs: cfg (dict[str, Any]) - plugin config
    :outputs: None
    """
    okta_cfg = (cfg.get("auth") or {}).get("okta")
    if not okta_cfg:
        sys.exit("[aidlc] auth.okta is not configured")
    issuer = (okta_cfg.get("issuer") or "").rstrip("/")
    cached = _read_cache(_cache_path(okta_cfg), issuer)
    if not cached:
        sys.exit("[aidlc] not logged in (no valid session cache)")
    sub = cached.get("sub") or "(unknown)"
    expires_at = cached.get("expires_at")
    valid = _is_token_valid(cached)
    status = "valid" if valid else "expired (refresh pending on next API call)"
    if expires_at:
        import datetime
        exp_str = datetime.datetime.fromtimestamp(expires_at).strftime("%Y-%m-%d %H:%M:%S")
        print(f"[aidlc] {sub}  expires={exp_str}  status={status}")
    else:
        print(f"[aidlc] {sub}  status={status}")


def _cli_logout(cfg: dict[str, Any]) -> None:
    """Delete the cached session; idempotent.

    :inputs: cfg (dict[str, Any]) - plugin config
    :outputs: None
    """
    okta_cfg = (cfg.get("auth") or {}).get("okta")
    if not okta_cfg:
        sys.exit("[aidlc] auth.okta is not configured")
    cache_file = _cache_path(okta_cfg)
    if cache_file.is_file():
        cache_file.unlink()
        print(f"[aidlc] Logged out (cache removed: {cache_file})")
    else:
        print("[aidlc] Already logged out (no cache found)")


def main() -> None:
    """CLI entrypoint: login | whoami | logout [--config PATH]. No secrets are printed.

    :inputs: None
    :outputs: None
    """
    ap = argparse.ArgumentParser(description="AIDLC plugin authentication CLI")
    ap.add_argument("command", choices=["login", "whoami", "logout"])
    ap.add_argument("--config", default=None, help="path to aidlc.config.json")
    args = ap.parse_args()
    cfg = load_config(args.config)
    {"login": _cli_login, "whoami": _cli_whoami, "logout": _cli_logout}[args.command](cfg)


if __name__ == "__main__":
    main()
