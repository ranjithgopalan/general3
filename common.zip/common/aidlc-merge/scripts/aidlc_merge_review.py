"""PR reviewer — Step 2 of the Epic Assembler (aidlc-merge plugin, docs/27).

Reads the merge-bundle.json written by aidlc_merge_bundle.py, then queries the
GitHub Enterprise API for each PR's CI status, review approvals, and merge-ability.
Also fetches a short diff summary (files changed, lines added/removed).

Outputs written to ``.aidlc/<workspace_id>/``:
  pr-review-summary.json  — machine-readable per-PR review verdicts
  (updates MERGE_CONTEXT.md with review results appended)

Usage:
  python aidlc_merge_review.py <workspace_id>
      [--out-dir PATH]
      [--config PATH]
      [--dry-run]
"""

from __future__ import annotations

import argparse
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

import aidlc_auth

# ── Constants ────────────────────────────────────────────────────────────────

_PLUGIN = "aidlc-merge"
_BUNDLE_FILE = "merge-bundle.json"
_REVIEW_FILE = "pr-review-summary.json"
_CONTEXT_FILE = "MERGE_CONTEXT.md"

# CI states that mean "all checks passed"
_CI_GREEN_STATES = {"success"}
# CI states that are still running (treat as blocker)
_CI_PENDING_STATES = {"pending", "queued", "in_progress"}
# Mergeable states
_MERGEABLE_CLEAN = "clean"


# ── Config helpers ────────────────────────────────────────────────────────────

def _workspace_dir(cfg: dict[str, Any], workspace_id: str) -> Path:
    base = (cfg.get("workspace_dir") or ".aidlc").rstrip("/\\")
    return Path(base) / workspace_id


def _git_cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return cfg.get("git") or {}


def _merge_cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return cfg.get("merge") or {}


def _github_token(cfg: dict[str, Any]) -> str:
    """
    Resolve the GitHub PAT from config (same two-mode logic as dev/QA plugins).

    :inputs: cfg (dict[str, Any]) - plugin config
    :outputs: (str) - resolved token (exits on failure)
    """
    raw = _git_cfg(cfg).get("github_token_env") or ""
    if not raw:
        sys.exit(
            f"[{_PLUGIN}] config.git.github_token_env is not set — add it to aidlc.config.json"
        )
    # Mode 1: the value IS the token
    if any(raw.startswith(pfx) for pfx in ("github_pat_", "ghp_", "gho_", "ghs_", "ghu_")):
        return raw
    # Mode 2: the value is an env var NAME
    import os
    token = os.environ.get(raw, "")
    if not token:
        sys.exit(
            f"[{_PLUGIN}] GitHub token env var '{raw}' is not set — "
            f"export {raw}=<your-PAT> before running"
        )
    return token


def _github_headers(token: str) -> dict[str, str]:
    return {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
    }


# ── GitHub API helpers ────────────────────────────────────────────────────────

def _gh_get(url: str, headers: dict[str, str], timeout: float = 30.0) -> dict[str, Any] | list[Any]:
    """
    GET from GitHub API; return parsed JSON.

    :inputs: url (str); headers (dict); timeout (float)
    :outputs: parsed JSON (dict or list)
    """
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")[:300]
        print(f"[{_PLUGIN}] WARNING: GET {url} -> HTTP {exc.code}: {body}")
        return {}
    except urllib.error.URLError as exc:
        print(f"[{_PLUGIN}] WARNING: GET {url} failed: {exc.reason}")
        return {}


def _parse_repo_and_number(pr_meta: dict[str, Any], github_base: str) -> tuple[str, int] | None:
    """
    Extract owner/repo and PR number from a PR metadata record.

    :inputs: pr_meta (dict) - PR record from dev/QA plugin; github_base (str) - API base URL
    :outputs: (tuple[str, int] | None) - (owner/repo, pr_number) or None if not parseable
    """
    pr_number = pr_meta.get("pr_number") or pr_meta.get("number")
    repo = pr_meta.get("repo") or pr_meta.get("repository") or ""
    remote_url = pr_meta.get("remote_url") or pr_meta.get("pr_url") or ""

    # Extract pr_number from URL if not explicitly set
    if not pr_number and remote_url:
        parts = remote_url.rstrip("/").split("/")
        if parts and parts[-1].isdigit():
            pr_number = int(parts[-1])
        if len(parts) >= 3 and parts[-2] == "pull":
            pr_number = int(parts[-1])

    # Extract owner/repo from pr_url when:
    # (a) repo not set at all, OR
    # (b) repo is set but has no owner prefix (no "/" in it)
    # pr_url format: https://github.aig.net/Owner/RepoName/pull/123
    if ("/" not in repo) and remote_url:
        parts = remote_url.replace("https://", "").replace("http://", "").split("/")
        # parts: [host, Owner, RepoName, "pull", "123"]
        if len(parts) >= 3:
            repo = f"{parts[1]}/{parts[2]}"

    if not repo or not pr_number:
        return None

    return repo, int(pr_number)


def _review_pr(
    pr_meta: dict[str, Any],
    github_base: str,
    gh_headers: dict[str, str],
    require_ci: bool,
    require_reviews: bool,
) -> dict[str, Any]:
    """
    Check a single PR's CI status, review approvals, mergeability, and diff summary.

    :inputs: pr_meta (dict) - PR record; github_base (str); gh_headers (dict);
             require_ci (bool); require_reviews (bool)
    :outputs: (dict[str, Any]) - review verdict record
    """
    parsed = _parse_repo_and_number(pr_meta, github_base)
    if not parsed:
        return {
            "pr_meta": pr_meta,
            "status": "SKIP",
            "reason": "Cannot determine repo or PR number from metadata",
            "blockers": ["No repo/PR number in metadata"],
            "ci_state": None,
            "reviews_approved": None,
            "mergeable": None,
            "files_changed": 0,
            "additions": 0,
            "deletions": 0,
        }

    repo, pr_number = parsed
    pr_url = f"{github_base}/repos/{repo}/pulls/{pr_number}"

    # ── Fetch PR details ──────────────────────────────────────────────────────
    pr_detail = _gh_get(pr_url, gh_headers)
    if not isinstance(pr_detail, dict) or not pr_detail:
        return {
            "pr_meta": pr_meta,
            "status": "SKIP",
            "reason": f"PR {repo}#{pr_number} not accessible from GitHub API",
            "blockers": ["PR not found or no access"],
            "ci_state": None,
            "reviews_approved": None,
            "mergeable": None,
            "files_changed": 0,
            "additions": 0,
            "deletions": 0,
        }

    pr_state = pr_detail.get("state") or "unknown"
    mergeable = pr_detail.get("mergeable_state") or "unknown"
    merged = pr_detail.get("merged", False)
    head_sha = (pr_detail.get("head") or {}).get("sha") or ""
    additions = pr_detail.get("additions") or 0
    deletions = pr_detail.get("deletions") or 0
    changed_files = pr_detail.get("changed_files") or 0
    pr_title = pr_detail.get("title") or ""

    # ── Check if already merged ───────────────────────────────────────────────
    if merged:
        return {
            "pr_meta": pr_meta,
            "repo": repo,
            "pr_number": pr_number,
            "pr_title": pr_title,
            "head_sha": head_sha,
            "status": "ALREADY_MERGED",
            "reason": "PR is already merged",
            "blockers": [],
            "ci_state": "success",
            "reviews_approved": True,
            "mergeable": "already_merged",
            "files_changed": changed_files,
            "additions": additions,
            "deletions": deletions,
        }

    if pr_state == "closed":
        return {
            "pr_meta": pr_meta,
            "repo": repo,
            "pr_number": pr_number,
            "pr_title": pr_title,
            "head_sha": head_sha,
            "status": "SKIP",
            "reason": "PR is closed (not merged)",
            "blockers": ["PR is closed without merge"],
            "ci_state": None,
            "reviews_approved": None,
            "mergeable": "closed",
            "files_changed": changed_files,
            "additions": additions,
            "deletions": deletions,
        }

    blockers: list[str] = []

    # ── CI status ─────────────────────────────────────────────────────────────
    ci_state: str | None = None
    if head_sha:
        status_url = f"{github_base}/repos/{repo}/commits/{head_sha}/status"
        status_data = _gh_get(status_url, gh_headers)
        if isinstance(status_data, dict):
            ci_state = status_data.get("state") or "unknown"

        # Also check check-runs (GitHub Actions)
        checks_url = f"{github_base}/repos/{repo}/commits/{head_sha}/check-runs"
        checks_data = _gh_get(checks_url, gh_headers)
        if isinstance(checks_data, dict):
            check_runs = checks_data.get("check_runs") or []
            if check_runs:
                conclusions = [c.get("conclusion") for c in check_runs]
                statuses = [c.get("status") for c in check_runs]
                if all(c == "success" for c in conclusions if c):
                    ci_state = "success"
                elif any(c in ("failure", "cancelled") for c in conclusions):
                    ci_state = "failure"
                elif any(s in ("queued", "in_progress") for s in statuses):
                    ci_state = "pending"
                elif ci_state is None:
                    ci_state = "unknown"

    if require_ci and ci_state not in _CI_GREEN_STATES:
        blockers.append(f"CI not green: state={ci_state}")

    # ── Reviews ───────────────────────────────────────────────────────────────
    reviews_approved = False
    reviews_url = f"{github_base}/repos/{repo}/pulls/{pr_number}/reviews"
    reviews_data = _gh_get(reviews_url, gh_headers)
    approved_count = 0
    if isinstance(reviews_data, list):
        # Most recent review per reviewer wins
        reviewer_states: dict[str, str] = {}
        for rev in reviews_data:
            reviewer = (rev.get("user") or {}).get("login") or str(rev.get("id") or "anon")
            state = rev.get("state") or "PENDING"
            reviewer_states[reviewer] = state
        approved_count = sum(1 for s in reviewer_states.values() if s == "APPROVED")
        reviews_approved = approved_count >= 1

    if require_reviews and not reviews_approved:
        blockers.append(f"No approved reviews (approved={approved_count})")

    # ── Mergeability ──────────────────────────────────────────────────────────
    if mergeable not in (_MERGEABLE_CLEAN, "unknown", ""):
        # "dirty" = merge conflicts; "blocked" = branch protection; "behind" = needs rebase
        if mergeable == "dirty":
            blockers.append("Merge conflicts detected (mergeable_state=dirty)")
        elif mergeable == "blocked":
            blockers.append("Merge blocked by branch protection rules")
        elif mergeable == "behind":
            blockers.append("Branch is behind base branch — needs rebase")

    # ── Verdict ───────────────────────────────────────────────────────────────
    if blockers:
        verdict = "BLOCKED"
    else:
        verdict = "READY"

    return {
        "pr_meta": pr_meta,
        "repo": repo,
        "pr_number": pr_number,
        "pr_title": pr_title,
        "head_sha": head_sha,
        "status": verdict,
        "reason": "; ".join(blockers) if blockers else "All checks passed",
        "blockers": blockers,
        "ci_state": ci_state,
        "reviews_approved": reviews_approved,
        "approved_reviews": approved_count,
        "mergeable": mergeable,
        "files_changed": changed_files,
        "additions": additions,
        "deletions": deletions,
    }


# ── Review all PRs across epics ───────────────────────────────────────────────

def _review_all_prs(
    bundle: dict[str, Any],
    cfg: dict[str, Any],
) -> list[dict[str, Any]]:
    """
    Review every dev + QA PR across all epics in the bundle.

    :inputs: bundle (dict) - merge-bundle.json contents; cfg (dict) - plugin config
    :outputs: (list[dict]) - per-PR review verdict list
    """
    github_base = (_git_cfg(cfg).get("github_base_url") or "https://github.aig.net/api/v3").rstrip("/")
    token = _github_token(cfg)
    gh_headers = _github_headers(token)
    merge_cfg = _merge_cfg(cfg)
    require_ci = bool(merge_cfg.get("require_ci_green", True))
    require_reviews = bool(merge_cfg.get("require_reviews", True))

    epics = bundle.get("epics") or []
    verdicts: list[dict[str, Any]] = []

    for epic in epics:
        epic_id = str(epic.get("id") or epic.get("epic_id") or "?")
        dev_prs = epic.get("_dev_prs") or []
        qa_prs = epic.get("_qa_prs") or []

        print(f"[{_PLUGIN}] Reviewing {len(dev_prs)} dev + {len(qa_prs)} QA PR(s) for epic {epic_id}")

        for pr_meta in dev_prs:
            result = _review_pr(pr_meta, github_base, gh_headers, require_ci, require_reviews)
            result["epic_id"] = epic_id
            result["pr_type"] = "dev"
            verdicts.append(result)
            _print_pr_verdict(result)

        for pr_meta in qa_prs:
            result = _review_pr(pr_meta, github_base, gh_headers, require_ci, require_reviews)
            result["epic_id"] = epic_id
            result["pr_type"] = "qa"
            verdicts.append(result)
            _print_pr_verdict(result)

    return verdicts


def _print_pr_verdict(v: dict[str, Any]) -> None:
    """
    Print a one-line verdict summary to stdout.

    :inputs: v (dict) - verdict dict
    :outputs: None
    """
    repo = v.get("repo") or "?"
    num = v.get("pr_number") or "?"
    status = v.get("status") or "?"
    ci = v.get("ci_state") or "?"
    approved = v.get("reviews_approved")
    blockers = v.get("blockers") or []
    icon = "[PASS]" if status == "READY" else ("⏭" if status == "ALREADY_MERGED" else "[blocked]")
    print(
        f"  {icon} {repo}#{num}  status={status}  ci={ci}  approved={approved}"
        + (f"  BLOCKERS: {blockers}" if blockers else "")
    )


# ── Summary report ────────────────────────────────────────────────────────────

def _append_review_to_context(ws_dir: Path, verdicts: list[dict[str, Any]]) -> None:
    """
    Append the PR review table to MERGE_CONTEXT.md.

    :inputs: ws_dir (Path) - workspace dir; verdicts (list) - review verdict records
    :outputs: None
    """
    context_path = ws_dir / _CONTEXT_FILE
    if not context_path.is_file():
        return

    lines: list[str] = [
        "",
        "---",
        "",
        "## PR Review Results",
        "",
        "| Epic | Type | Repo | PR# | Status | CI | Approved | Files | +/- | Blockers |",
        "|---|---|---|---|---|---|---|---|---|---|",
    ]

    for v in verdicts:
        epic_id = v.get("epic_id") or "?"
        pr_type = v.get("pr_type") or "?"
        repo = v.get("repo") or "?"
        num = v.get("pr_number") or "?"
        status = v.get("status") or "?"
        ci = v.get("ci_state") or "?"
        approved = "[PASS]" if v.get("reviews_approved") else "[FAIL]"
        files = v.get("files_changed") or 0
        add_del = f"+{v.get('additions', 0)}/-{v.get('deletions', 0)}"
        blockers = "; ".join(v.get("blockers") or [])
        lines.append(
            f"| `{epic_id}` | {pr_type} | {repo} | {num} | `{status}` "
            f"| `{ci}` | {approved} | {files} | {add_del} | {blockers or '—'} |"
        )

    lines.append("")
    ready = sum(1 for v in verdicts if v.get("status") == "READY")
    blocked = sum(1 for v in verdicts if v.get("status") == "BLOCKED")
    already = sum(1 for v in verdicts if v.get("status") == "ALREADY_MERGED")
    lines.append(f"**READY:** {ready} | **BLOCKED:** {blocked} | **ALREADY MERGED:** {already}")
    lines.append("")

    existing = context_path.read_text(encoding="utf-8")
    context_path.write_text(existing + "\n".join(lines), encoding="utf-8")


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    """
    Review all PRs across epics (CI + approvals + conflicts + diff summary).

    :inputs: None (reads args from sys.argv)
    :outputs: None (writes pr-review-summary.json; appends to MERGE_CONTEXT.md)
    """
    ap = argparse.ArgumentParser(
        description="Step 2 — review all PRs (CI, reviews, conflicts, diff summary)."
    )
    ap.add_argument("workspace_id")
    ap.add_argument("--out-dir", default=None, help="Workspace output directory")
    ap.add_argument("--config", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    ws_dir = Path(args.out_dir) if args.out_dir else (
        Path(cfg.get("workspace_dir") or ".aidlc") / args.workspace_id
    )

    bundle_path = ws_dir / _BUNDLE_FILE
    if not bundle_path.is_file():
        sys.exit(
            f"[{_PLUGIN}] merge-bundle.json not found at {bundle_path} — "
            "run aidlc_merge_bundle.py first"
        )

    bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
    print(
        f"[{_PLUGIN}] Reviewing PRs for workspace {args.workspace_id} — "
        f"{len(bundle.get('epics') or [])} epic(s)"
    )

    verdicts = _review_all_prs(bundle, cfg)

    # Summary
    ready = [v for v in verdicts if v.get("status") == "READY"]
    blocked = [v for v in verdicts if v.get("status") == "BLOCKED"]
    already = [v for v in verdicts if v.get("status") == "ALREADY_MERGED"]
    skipped = [v for v in verdicts if v.get("status") == "SKIP"]

    print(
        f"\n[{_PLUGIN}] Review complete: "
        f"READY={len(ready)} | BLOCKED={len(blocked)} | "
        f"ALREADY_MERGED={len(already)} | SKIP={len(skipped)}"
    )
    if blocked:
        print(f"[{_PLUGIN}] Blocked PRs will be skipped (skip_blockers=true by default):")
        for v in blocked:
            print(f"  [blocked] {v.get('repo')}#{v.get('pr_number')}: {v.get('reason')}")

    if args.dry_run:
        print(f"[{_PLUGIN}] --dry-run: not writing files")
        return

    review_path = ws_dir / _REVIEW_FILE
    review_path.write_text(
        json.dumps({"verdicts": verdicts}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"[{_PLUGIN}] Wrote {review_path}")

    _append_review_to_context(ws_dir, verdicts)
    print(f"[{_PLUGIN}] Updated {_CONTEXT_FILE}")
    print(f"[{_PLUGIN}] Next: run aidlc_merge_execute.py to squash-merge READY PRs")


if __name__ == "__main__":
    main()
