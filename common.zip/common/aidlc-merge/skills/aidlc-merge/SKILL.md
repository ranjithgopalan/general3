---
name: aidlc-merge
description: Epic Assembler — closes the SDLC loop by reviewing and squash-merging all dev + QA PRs across every epic, triggering a KB indexer refresh to a new STAGING version, generating a CHANGELOG, syncing traceability back to central, and advancing the workspace from MERGE → PENDING_SYNC → CLOSED.
when_to_use: When the user runs /aidlc-merge <workspace_id> to squash-merge all approved dev + QA PRs for a workspace that is in the MERGE state (after aidlc-qa has completed for all epics), or /aidlc-merge <workspace_id> <step> to run a specific step (bundle | review | execute | kb-refresh | changelog | sync | git-verify).
disable-model-invocation: true
user-invocable: true
allowed-tools: Read, Write, Edit, Glob, Grep, Bash, TodoWrite
arguments: [workspace_id, step?]
---

# SKILL: aidlc-merge — Epic Assembler

**Stage:** MERGE (workspace state `MERGE → PENDING_SYNC → CLOSED`)  
**Persona:** DevOps / Scrum Master  
**Plugin:** `plugins/aidlc-merge/`  
**Prerequisite:** `aidlc-qa` plugin complete (QA PRs raised; workspace at `MERGE`)

---

## Mission

The Epic Assembler closes the SDLC loop. After all epics complete QA:
1. Reviews all PRs (dev + QA) across every epic — CI, approvals, conflicts + diff summary
2. Squash-merges approved PRs via GitHub Enterprise API; skips + reports blockers
3. Invokes the KB indexer → new STAGING KB version
4. Generates CHANGELOG.md from merged PRs + stories
5. Syncs results + new KB version + traceability back to central
6. Advances workspace `MERGE → PENDING_SYNC`

---

## Pre-Task File

Before running, write `.aidlc/<workspace_id>/MERGE_PLAN.md` with:
- Workspace ID, state, requirement summary
- Epic IDs in scope (or "all")
- KB refresh mode (`local` or `central`)
- Auto-promote decision (`true` / `false`)
- Any known blockers from QA

---

## Steps

### Step 1 — Bundle (read-only)

Fetch all epics + PR metadata + trace data from central. No mutations.

```bash
cd plugins/aidlc-merge/scripts
python aidlc_merge_bundle.py <workspace_id> [--epic-ids E1,E2] [--config PATH]
```

**Outputs:**
- `.aidlc/<workspace_id>/merge-bundle.json` — machine-readable bundle
- `.aidlc/<workspace_id>/MERGE_CONTEXT.md` — human-readable review document

**Review MERGE_CONTEXT.md before proceeding.**

---

### Step 2 — Review (read-only)

Check every PR's CI status, review approvals, merge conflicts, and diff summary.

```bash
python aidlc_merge_review.py <workspace_id> [--config PATH]
```

**Outputs:**
- `.aidlc/<workspace_id>/pr-review-summary.json` — per-PR verdicts: READY | BLOCKED | ALREADY_MERGED
- MERGE_CONTEXT.md updated with review table

**Check MERGE_CONTEXT.md.** BLOCKED PRs will be skipped (not abort). Resolve blockers before re-running.

---

### Step 3 — Execute (merges PRs — irreversible)

Squash-merge all READY PRs via GitHub API. Update epic status to `done` in central.

```bash
python aidlc_merge_execute.py <workspace_id> [--epic-ids E1,E2] [--dry-run] [--config PATH]
```

**Always run with `--dry-run` first to preview what will be merged.**

```bash
# Dry run — safe to run; no mutations
python aidlc_merge_execute.py <workspace_id> --dry-run

# Live run — merges PRs
python aidlc_merge_execute.py <workspace_id>
```

**Outputs:**
- `.aidlc/<workspace_id>/merge-results.json` — per-PR outcome (SHA, status, blockers)
- MERGE_CONTEXT.md updated with merge results
- Epic status `qa_in_progress → done` via central PATCH

**Blockers are skipped + reported** (not abort). Epics with skipped PRs are NOT advanced to `done`.

---

### Step 4 — KB Refresh

Invoke the KB indexer to create a new STAGING KB version from the merged artifacts.

```bash
python aidlc_merge_kb_refresh.py <workspace_id> [--mode local|central] [--dry-run] [--config PATH]
```

**Config:** Set `kb_refresh.mode` in `aidlc.config.json`:

| Mode | When to use | Config required |
|---|---|---|
| `local` | KB indexer accessible on this machine | `kb_indexer_dir`, `kb_dir` |
| `central` | Central API running; KbRefreshService available | `central_base_url` |

**Auto-promote:** Default `false` (leave in STAGING for SME sign-off). Set `auto_promote: true` only after confirming the new version is correct.

**Outputs:**
- `.aidlc/<workspace_id>/kb-refresh-result.json` — `{ok, new_kb_version, mode, staging_version}`

---

### Step 5 — Changelog

Generate CHANGELOG.md from merged PRs + stories + KB version.

```bash
python aidlc_merge_changelog.py <workspace_id> [--config PATH]
```

**Outputs:**
- `.aidlc/<workspace_id>/CHANGELOG.md` — full release changelog

---

### Step 6 — Sync to Central

Post merge results + per-epic traces + new KB version to central. Advance workspace to PENDING_SYNC.

```bash
python aidlc_sync_merge.py <workspace_id> [--no-advance] [--config PATH]
```

**Outputs:**
- `.aidlc/<workspace_id>/sync-merge-result.json`
- Workspace state advanced: `MERGE → PENDING_SYNC`
- Central traceability updated:
  - Workspace-level `merge-report` artifact
  - Per-epic `merge-epic` artifact via `POST .../epics/{id}/merge/trace` (merge SHA + KB IDs). The
    developer's `dev-epic` trace is left untouched — merge no longer re-posts it.

---

### Step 7 — Git Verify (optional)

Verify merged SHAs exist in GitHub. Clean up local feature branches.

```bash
python aidlc_merge_git.py status  <workspace_id>   # Summary of all PRs + branches
python aidlc_merge_git.py verify  <workspace_id>   # Confirm merged SHAs in GitHub
python aidlc_merge_git.py cleanup <workspace_id>   # List merged branches (--force to delete)
```

---

### Step 8 — SME KB Sign-Off (manual)

After Step 4, the new KB version is in STAGING. SME must review and promote before the workspace closes.

```bash
# Promote STAGING → ACTIVE (local mode only — or via SME sign-off in central UI)
cd <kb_indexer_dir>
python -m app.cli promote <new_kb_version> --by <sme_email>
```

Central records: `kb_versions.status = ACTIVE`, `signed_off_at`, `signed_off_by`.

---

### Step 9 — Close Workspace (manual / DevOps action)

After SME sign-off and KB promotion, close the workspace in central:
- Set workspace state to `CLOSED`
- Central triggers `kb-refresh` to ingest workspace artifacts into the KB

---

## Traceability Chain

```
Requirement (workspace)
  → Analysis → FSD → SRD → Stories
  → Epics (dev branches, QA branches)
  → Dev PRs (per epic, per repo) — squash merged [this plugin]
  → QA PRs (in qa-scripts repo) — squash merged [this plugin]
  → Merged commits (SHA recorded per repo)
  → New KB version (STAGING → ACTIVE after sign-off)
  → PENDING_SYNC → CLOSED
  → KB updated with workspace artifacts (kb-refresh)
```

---

## Config Reference

Key blocks in `config/aidlc.config.json` for this plugin:

```json
{
  "central_base_url": "http://localhost:8080",
  "kb_refresh": {
    "mode": "local",
    "auto_promote": false,
    "promoted_by": "devops@example.com",
    "kb_indexer_dir": "/path/to/genai-aig-core-aidlc-platform-kb-indexer-7419",
    "kb_dir": "/path/to/kb-artifacts",
    "batch_size": 64,
    "central_poll_interval": 5,
    "central_poll_max_wait": 300
  },
  "merge": {
    "strategy": "squash",
    "skip_blockers": true,
    "require_ci_green": true,
    "require_reviews": true,
    "commit_message_template": "chore(merge): squash merge {epic_id} — {title} [aidlc-merge]"
  },
  "git": {
    "github_base_url": "https://github.aig.net/api/v3",
    "github_token_env": "GITHUB_AIG_TOKEN"
  }
}
```

Copy `config/aidlc.config.example.json` → `config/aidlc.config.json` and fill in real values.  
**Never commit `aidlc.config.json`** (listed in `.gitignore`).

---

## Files Written Per Run

| File | Written by | Purpose |
|---|---|---|
| `.aidlc/<ws>/merge-bundle.json` | bundle | All epics + PRs + trace |
| `.aidlc/<ws>/MERGE_CONTEXT.md` | bundle + review + execute + refresh + changelog | Human review doc |
| `.aidlc/<ws>/pr-review-summary.json` | review | Per-PR CI/review verdicts |
| `.aidlc/<ws>/merge-results.json` | execute | Per-PR merge outcomes + SHAs |
| `.aidlc/<ws>/kb-refresh-result.json` | kb_refresh | New KB version + status |
| `.aidlc/<ws>/CHANGELOG.md` | changelog | Release changelog |
| `.aidlc/<ws>/sync-merge-result.json` | sync | Central sync outcome |

---

## Error Handling

| Scenario | Behaviour |
|---|---|
| PR with failing CI | Treated as BLOCKED; skipped (logged in merge-results.json) |
| PR with no approved reviews | Treated as BLOCKED; skipped |
| Merge conflict | Treated as BLOCKED; skipped |
| GitHub rate limit (429) | Automatic retry with backoff (3 attempts) |
| KB indexer fails | `kb-refresh-result.json` records `ok: false`; workspace still advances to PENDING_SYNC |
| Central API unreachable | Script exits with clear error; no partial state mutations |
| Epic status update fails | WARNING logged; merge results still written |

---

## Quick Command Reference

```bash
cd plugins/aidlc-merge/scripts

# Full merge flow
python aidlc_merge_bundle.py   <ws_id>
python aidlc_merge_review.py   <ws_id>
python aidlc_merge_execute.py  <ws_id> --dry-run   # preview first
python aidlc_merge_execute.py  <ws_id>              # live merge
python aidlc_merge_kb_refresh.py <ws_id>
python aidlc_merge_changelog.py  <ws_id>
python aidlc_sync_merge.py       <ws_id>

# Partial epic merge
python aidlc_merge_bundle.py  <ws_id> --epic-ids EP-001,EP-002
python aidlc_merge_execute.py <ws_id> --epic-ids EP-001,EP-002

# Git helpers
python aidlc_merge_git.py status  <ws_id>
python aidlc_merge_git.py verify  <ws_id>
python aidlc_merge_git.py cleanup <ws_id> --force
```
