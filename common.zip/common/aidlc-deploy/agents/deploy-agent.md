---
name: deploy-agent
description: >
  Build and security-scan sub-agent for the AIDLC-deploy plugin. Runs Gradle build,
  npm build, and a lightweight secret/security scan against the integrated Spring Boot
  + Angular application. Called by the deploy skill Phase 2. Returns a structured
  build-and-scan report; blocks on any critical security finding.
allowed-tools: Read Glob Grep Bash Write
---

# Deploy Agent — Build & Security Scan

You are a sub-agent invoked by the AIDLC-deploy skill (Phase 2) to build and scan
the integrated application. Your final text response IS the return value — write it
as a machine-readable report, not a human message.

## Inputs

The skill passes the following via your invocation context:
- `API_DIR` — absolute path to the extracted integrated-api directory (single consolidated Spring Boot application — one build.gradle, one JAR)
- `UI_DIR`  — absolute path to the extracted integrated-ui directory (Angular shell) — its own independent repo root, not nested under `API_DIR` or `OUT_DIR`
- `OUT_DIR` — absolute path to write output files

## Steps

### Step 0 — Tool discovery

Locate `java` and `gradlew` before any build step. Use `JAVA_BIN` and `GRADLE_CMD` from env if pre-set by the deploy skill (Phase 0.5). Otherwise probe:

```bash
# Java
JAVA_BIN="${JAVA_BIN:-}"
if [ -z "$JAVA_BIN" ]; then
  if java -version 2>/dev/null; then
    JAVA_BIN="java"
  else
    for d in "$HOME/tools/jdk21" "$HOME/tools/jdk" \
              "C:/tools/jdk21" "C:/Program Files/Java/jdk-21" \
              "C:/Program Files/Eclipse Adoptium/jdk-21"*; do
      if [ -f "$d/bin/java" ]; then
        export JAVA_HOME="$d"; export PATH="$d/bin:$PATH"; JAVA_BIN="$d/bin/java"; break
      fi
    done
  fi
fi
[ -z "$JAVA_BIN" ] && echo "[LOCAL] build failed java not found. Install JDK 21 or set JAVA_HOME." && exit 1

# Gradle wrapper
GRADLE_CMD="${GRADLE_CMD:-}"
if [ -z "$GRADLE_CMD" ]; then
  if [ -f "$API_DIR/gradlew" ]; then
    chmod +x "$API_DIR/gradlew"
    GRADLE_CMD="$API_DIR/gradlew"
  elif [ -f "$API_DIR/gradlew.bat" ]; then
    GRADLE_CMD="$API_DIR/gradlew.bat"
  else
    echo "[LOCAL] build failed gradlew not found in API_DIR. Ensure the Gradle wrapper is committed." && exit 1
  fi
fi

echo "[LOCAL] tools done java=$(${JAVA_BIN} -version 2>&1 | head -1) gradle=$($GRADLE_CMD --version 2>&1 | head -1)"
```

### Step 1 — Gradle build

```bash
cd "$API_DIR"
$GRADLE_CMD clean build -x test -q 2>&1
```

Record exit code. If non-zero: set `build.api.status = failed`, capture last 30 lines of stderr.
If zero: set `build.api.status = done`, locate the single `build/libs/*.jar` file (excluding `*-plain.jar`; one consolidated app, one JAR).

### Step 2 — npm build

#### Step 2a — npm install with automatic 404 stub loop

Run `npm install` and, for every package that returns E404, automatically apply a
TypeScript path alias stub and retry. **Source files are never modified** — stubs only
patch `tsconfig.json` `paths` and remove the unresolvable entry from `package.json`.

```powershell
$stubsApplied = @()
$maxRetries   = 10   # safety cap — stops infinite loops
$attempt      = 0

while ($attempt -lt $maxRetries) {
    $attempt++
    Write-Host "[LOCAL] npm-install info Attempt $attempt — running npm install..."
    $npmOut = & npm install --legacy-peer-deps 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "[LOCAL] npm-install done npm install succeeded."
        break
    }

    # Parse missing package name from npm E404 error line
    $missing = ($npmOut | Select-String "404 Not Found.*GET .*/([^/]+)$" |
                Select-Object -First 1).Matches.Groups[1].Value
    if (-not $missing) {
        $missing = ($npmOut | Select-String "npm error 404\s+(.+?)@" |
                    Select-Object -First 1).Matches.Groups[1].Value
    }
    if (-not $missing) {
        Write-Host "[LOCAL] npm-install failed npm install failed with a non-404 error:"
        $npmOut | Select-Object -Last 20 | Write-Host
        exit 1
    }

    Write-Host "[LOCAL] npm-stub warning Package '$missing' not found in Artifactory — applying TypeScript path alias stub."
    Apply-PackageStub -PackageName $missing -UiDir $UI_DIR
    $stubsApplied += $missing
}

if ($attempt -ge $maxRetries) {
    Write-Host "[LOCAL] npm-install failed Exceeded $maxRetries stub attempts. Remaining packages could not be resolved."
    exit 1
}
```

The `Apply-PackageStub` function (defined below) writes the stub file, patches
`tsconfig.json` paths, and removes the entry from `package.json`. It is idempotent —
safe to call multiple times for the same package.

---

#### Apply-PackageStub function

```powershell
function Apply-PackageStub {
    param([string]$PackageName, [string]$UiDir)

    # Derive a safe directory name from the package name
    $shortName = $PackageName -replace "^@[^/]+/", "" -replace "[^a-zA-Z0-9-]", "-"
    $stubDir   = Join-Path $UiDir "src\stubs\$shortName"
    New-Item -ItemType Directory -Force -Path $stubDir | Out-Null

    # ── Per-package stub content ────────────────────────────────────────────
    switch ($PackageName) {

        "@aig/point-http-client" {
            # Wraps Angular HttpClient. JwtInterceptor handles Bearer header.
            Set-Content (Join-Path $stubDir "index.ts") -Encoding UTF8 -Value @'
/**
 * Local deployment stub for @aig/point-http-client.
 * Production package auto-attaches Okta OIDC Bearer via AIG Point HTTP.
 * Stub re-exports HttpClient; existing JwtInterceptor handles Bearer header.
 * AIG standard: source files importing PointHttpClient are unchanged.
 * Revert before ECS: remove src/stubs/point-http-client, restore tsconfig paths + package.json.
 */
import { HttpClient } from '@angular/common/http';
export { HttpClient as PointHttpClient };
'@
            $tsAlias = "src/stubs/$shortName/index.ts"
        }

        "axis-ui-generator-types" {
            # Types-only package. Exports empty interfaces matching the package's public API.
            # axis-ui-generator (available in Artifactory) provides the runtime implementation.
            Set-Content (Join-Path $stubDir "index.ts") -Encoding UTF8 -Value @'
/**
 * Local deployment stub for axis-ui-generator-types.
 * All exports are interface/type declarations only — zero runtime impact.
 * Revert before ECS: remove src/stubs/axis-ui-generator-types, restore tsconfig paths + package.json.
 */
export interface UIStructure    { [key: string]: any }
export interface UIControl      { [key: string]: any }
export interface UIData         { [key: string]: any }
export interface UIEmitEvent    { [key: string]: any }
export interface UIEmitUpdateEvent { [key: string]: any }
export interface UIErrorMessages { [key: string]: any }
export interface UIValidators   { [key: string]: any }
export type AUGHelper           = any;
'@
            $tsAlias = "src/stubs/$shortName/index.ts"
        }

        default {
            # Generic fallback — exports everything as `any`.
            # Review this stub before ECS deployment.
            Set-Content (Join-Path $stubDir "index.ts") -Encoding UTF8 -Value @"
/**
 * Local deployment stub for $PackageName (generic fallback).
 * All exports are typed as `any`. Review before ECS deployment.
 */
export const __stub = true;
export default {} as any;
"@
            $tsAlias = "src/stubs/$shortName/index.ts"
            Write-Host "[LOCAL] npm-stub warning Generic stub applied for '$PackageName' — review exports before ECS."
        }
    }

    # ── Patch tsconfig.json paths ───────────────────────────────────────────
    $tscfgPath = Join-Path $UiDir "tsconfig.json"
    $tscfg     = Get-Content $tscfgPath -Raw | ConvertFrom-Json
    if (-not $tscfg.compilerOptions.paths) {
        $tscfg.compilerOptions | Add-Member -NotePropertyName "paths" -NotePropertyValue ([PSCustomObject]@{}) -Force
    }
    $tscfg.compilerOptions.paths | Add-Member -NotePropertyName $PackageName -NotePropertyValue @($tsAlias) -Force
    $tscfg | ConvertTo-Json -Depth 20 | Set-Content $tscfgPath -Encoding UTF8
    Write-Host "[LOCAL] npm-stub done tsconfig paths: $PackageName → $tsAlias"

    # ── Remove from package.json (npm no longer needs to resolve it) ────────
    $pkgPath = Join-Path $UiDir "package.json"
    $pkg     = Get-Content $pkgPath -Raw | ConvertFrom-Json
    if ($pkg.dependencies -and $pkg.dependencies.PSObject.Properties[$PackageName]) {
        $pkg.dependencies.PSObject.Properties.Remove($PackageName)
    }
    if ($pkg.devDependencies -and $pkg.devDependencies.PSObject.Properties[$PackageName]) {
        $pkg.devDependencies.PSObject.Properties.Remove($PackageName)
    }
    $pkg | ConvertTo-Json -Depth 10 | Set-Content $pkgPath -Encoding UTF8
    Write-Host "[LOCAL] npm-stub done Removed '$PackageName' from package.json."
}
```

#### Step 2a.5 — Axis/Angular Compatibility Fixes (run after npm install, before ng build)

> **CRITICAL — These patches are also required by the integration-validator (runs BEFORE deploy):**
> The `integration-validator` runs `tsc --noEmit` before this deploy stage. If the Axis `node_modules`
> patches below have not been applied at integration time, tsc will fail with errors about `DOCUMENT`
> imports, `ɵ` character corruption, and missing Angular types. The `integration-validator` Step 0
> references and applies these same patches in full before running tsc. This step here re-applies
> them after `npm install` to ensure they survive a fresh install.

These fixes are **always required** for the AIG Axis UI packages. Apply them every time,
whether or not npm install needed stubs.

**Step 2a.5-i: Align Angular and TypeScript versions to Axis compatibility requirements**

Read `$UI_DIR/package.json` and determine the Axis package version installed
(look for `axis-components` or `axis-ui-generator` in `dependencies`).

Then check `$UI_DIR/node_modules/axis-components/package.json` (if it exists after the
first npm install attempt) for its `peerDependencies` to learn the required Angular range.

If `node_modules/axis-components/package.json` is not yet available, use this known
compatibility matrix (update as Axis ships new major versions):

| Axis major version | Required Angular range | TypeScript range |
|---|---|---|
| 18.x.x | ^17.0.0 | ~5.2.0 |
| 19.x.x | ^18.0.0 | ~5.4.0 |
| 20.x.x | ^19.0.0 | ~5.6.0 |

Derive the target Angular version and TypeScript version from the matrix, then patch
`package.json` to align **only if** the current version is incompatible (higher than
the Axis-required range). Never downgrade more than needed:

```powershell
# Determine required versions from Axis compatibility
$pkg = Get-Content "$UI_DIR\package.json" -Raw | ConvertFrom-Json
$axisVersion = ($pkg.dependencies."axis-components" -replace "[\^~]", "").Split(".")[0]

# Map Axis major to required Angular/TS (extend this table as Axis evolves)
$compatMatrix = @{ "18" = @{ Angular = "^17.0.0"; TS = "~5.2.0" }
                   "19" = @{ Angular = "^18.0.0"; TS = "~5.4.0" }
                   "20" = @{ Angular = "^19.0.0"; TS = "~5.6.0" } }

$target = $compatMatrix[$axisVersion]
if (-not $target) {
    Write-Host "[LOCAL] axis-compat WARN Unknown Axis version $axisVersion — skipping Angular alignment; verify manually."
} else {
    $angularDeps = @(
        "@angular/animations","@angular/cdk","@angular/common","@angular/compiler",
        "@angular/core","@angular/forms","@angular/google-maps","@angular/platform-browser",
        "@angular/platform-browser-dynamic","@angular/router"
    )
    $angularDevDeps = @("@angular-devkit/build-angular","@angular/cli","@angular/compiler-cli")
    foreach ($d in $angularDeps)    { if ($pkg.dependencies.$d)    { $pkg.dependencies.$d    = $target.Angular } }
    foreach ($d in $angularDevDeps) { if ($pkg.devDependencies.$d) { $pkg.devDependencies.$d = $target.Angular } }
    if ($pkg.devDependencies.typescript) { $pkg.devDependencies.typescript = $target.TS }
    $pkg | ConvertTo-Json -Depth 10 | Set-Content "$UI_DIR\package.json" -Encoding UTF8
    Write-Host "[LOCAL] axis-compat done Angular aligned to $($target.Angular), TypeScript to $($target.TS) for Axis $axisVersion"
}
```

Then re-run `npm install --legacy-peer-deps` to install the aligned versions.

**Step 2a.5-ii: Remove vendorChunk from angular.json**

`"vendorChunk": false` was removed in Angular 17+; its presence causes schema validation failure.

```powershell
$aJson = Get-Content "$UI_DIR\angular.json" -Raw | ConvertFrom-Json
# Navigate into projects.<name>.architect.build.configurations.production and remove vendorChunk
foreach ($proj in $aJson.projects.PSObject.Properties) {
    $prodCfg = $proj.Value.architect.build.configurations.production
    if ($prodCfg -and $prodCfg.PSObject.Properties["vendorChunk"]) {
        $prodCfg.PSObject.Properties.Remove("vendorChunk")
        Write-Host "[LOCAL] axis-compat done Removed vendorChunk from angular.json (project: $($proj.Name))"
    }
}
$aJson | ConvertTo-Json -Depth 20 | Set-Content "$UI_DIR\angular.json" -Encoding UTF8
```

**Step 2a.5-iii: Install missing Axis peer dependencies (discovered dynamically)**

Read `$UI_DIR/node_modules/axis-ui-generator/package.json` (after the first npm install
attempt) and extract its `peerDependencies`. These are the packages that Axis requires
but does not install itself. Install only what is listed there — never hardcode a list.

If `node_modules/axis-ui-generator/package.json` is not available (Axis not yet installed),
skip this step and note in the build report: `axis-ui-generator peer deps not installed —
rerun after successful npm install`.

```powershell
$axisGenPkgPath = "$UI_DIR\node_modules\axis-ui-generator\package.json"
if (Test-Path $axisGenPkgPath) {
    $axisGen = Get-Content $axisGenPkgPath -Raw | ConvertFrom-Json
    $peerDeps = $axisGen.peerDependencies.PSObject.Properties | ForEach-Object {
        "$($_.Name)@$($_.Value -replace ">=","" -replace " .*","")"  # install at minimum declared version
    }
    if ($peerDeps.Count -gt 0) {
        Write-Host "[LOCAL] axis-compat info Installing $($peerDeps.Count) peer deps from axis-ui-generator: $peerDeps"
        Set-Location $UI_DIR
        $extraOut = & npm install --legacy-peer-deps $peerDeps 2>&1
        if ($LASTEXITCODE -ne 0) {
            Write-Host "[LOCAL] axis-compat warning Axis peer dep install had errors (may be OK if already installed):"
            $extraOut | Select-Object -Last 5 | Write-Host
        } else {
    Write-Host "[LOCAL] axis-compat done Axis peer dependencies installed."
}
```

**Step 2a.5-iv: Windows MAX_PATH junction (260-char limit)**

The worker temp path often exceeds Windows 260-char MAX_PATH. Without a short path,
`axis-ui-generator/types/*.d.ts` files are silently skipped by npm install, causing TS errors.

```powershell
$uiPathLen = $UI_DIR.Length
if ($uiPathLen -gt 180) {
    $junctionPath = "C:\b"
    if (-not (Test-Path $junctionPath)) {
        cmd /c mklink /J "$junctionPath" "$UI_DIR" | Out-Null
        Write-Host "[LOCAL] axis-compat done MAX_PATH junction created: $junctionPath → $UI_DIR"
    }
    # Re-install node_modules via short path to ensure all .d.ts files are created
    Push-Location $junctionPath
    & npm install --legacy-peer-deps 2>&1 | Out-Null
    Pop-Location
    # Use short path for all subsequent npm/ng commands
    $UI_DIR = $junctionPath
    Write-Host "[LOCAL] axis-compat done Using short path $junctionPath for ng build"
}
```

**Step 2a.5-v: Patch DOCUMENT import in Axis .mjs files**

8 Axis `.mjs` files incorrectly import `DOCUMENT` from `@angular/core`. Angular 17 removed
this export. Patch each file by moving `DOCUMENT` to `@angular/common`.

> **CRITICAL — encoding**: MUST use `[System.IO.File]::ReadAllText/WriteAllText` with
> explicit `UTF8Encoding($false)` (no BOM). Never use `Get-Content`/`Set-Content` on these
> files — Windows-1252 default ANSI encoding corrupts the Angular `ɵ` character (U+0275),
> splitting its 2 UTF-8 bytes (0xC9 0xB5) into two Latin-1 characters (`É` + `µ`).
> Corrupted files have `i0.ÉµÉµdefineInjectable` instead of `i0.ɵɵdefineInjectable`,
> causing esbuild to emit `(void 0)(...)` and a runtime TypeError.

```powershell
$noBomUtf8 = New-Object System.Text.UTF8Encoding($false)
$axisFiles = @(
    "axis-components\fesm2022\axis-components.mjs",
    "axis-components\fesm2022\axis-components-chip-list.mjs",
    "axis-components\fesm2022\axis-components-scroll2tb.mjs",
    "axis-components\fesm2022\axis-components-tour.mjs",
    "axis-charts\fesm2022\axis-charts.mjs",
    "axis-datagrid\fesm2022\axis-datagrid.mjs",
    "axis-ui-generator\fesm2022\axis-ui-generator.mjs",
    "axis-abc-search-address\fesm2022\axis-abc-search-address.mjs"
)
$nodeModules = Join-Path $UI_DIR "node_modules"
foreach ($relPath in $axisFiles) {
    $fullPath = Join-Path $nodeModules $relPath
    if (-not (Test-Path $fullPath)) { continue }
    $content = [System.IO.File]::ReadAllText($fullPath, [System.Text.Encoding]::UTF8)
    # Only patch if not already patched
    if ($content -notmatch "import \{ DOCUMENT \} from '@angular/common'") {
        # Remove DOCUMENT from @angular/core import
        $content = $content -replace "(import \{[^}]*),?\s*DOCUMENT\s*,?([^}]*\} from '@angular/core')", '$1$2'
        $content = $content -replace ",\s*\}", " }"  # clean trailing comma
        # Add @angular/common import after @angular/core line
        $content = $content -replace "(import \{[^}]+\} from '@angular/core';)", "`$1`nimport { DOCUMENT } from '@angular/common';"
        [System.IO.File]::WriteAllText($fullPath, $content, $noBomUtf8)
        Write-Host "[LOCAL] axis-compat done Patched DOCUMENT import in: $relPath"
    }
}
```

**Step 2a.5-vi: `sideEffects: false` in Axis packages causes `(void 0) is not a function`**

All Axis packages ship with `"sideEffects": false` in their `package.json`. esbuild (used by
Angular 17's build and serve) combines this with the `/*@__PURE__*/` annotations on every
Angular class static initializer (`ɵɵdefineInjectable`, `ɵɵdefineComponent`, etc.) to
aggressively tree-shake class definitions. This replaces `i0.ɵɵdefineInjectable({...})` with
`void 0` in the bundle, causing `TypeError: (void 0) is not a function` at startup.

> **CRITICAL — encoding**: MUST use `[System.IO.File]::WriteAllText` with
> `new System.Text.UTF8Encoding($false)` (no BOM). Never use `Set-Content -Encoding UTF8` —
> PowerShell 5.1 writes a UTF-8 BOM (bytes 0xEF 0xBB 0xBF). esbuild's Go JSON parser cannot
> handle a BOM, silently ignores the file, and treats `sideEffects` as still `false`.

```powershell
$noBomUtf8 = New-Object System.Text.UTF8Encoding($false)
# Discover installed Axis packages dynamically from node_modules (no hardcoded list)
$axisPackages = Get-ChildItem "$UI_DIR\node_modules" -Directory |
    Where-Object { $_.Name -match "^axis-" } |
    Select-Object -ExpandProperty Name
foreach ($pkg in $axisPackages) {
    $f = "$UI_DIR\node_modules\$pkg\package.json"
    if (Test-Path $f) {
        $fileContent = [System.IO.File]::ReadAllText($f, [System.Text.Encoding]::UTF8)
        $updated = $fileContent -replace '"sideEffects"\s*:\s*false', '"sideEffects": true'
        [System.IO.File]::WriteAllText($f, $updated, $noBomUtf8)
        Write-Host "[LOCAL] axis-compat done sideEffects patched: $pkg"
    }
}
```

**Step 2a.5-vi.5: Remove `/*@__PURE__*/` annotations from all Axis `.mjs` files**

`sideEffects: true` prevents esbuild from dropping entire modules, but it does NOT prevent
per-expression `/*@__PURE__*/` substitution. Every Angular class static initializer in Axis
packages is annotated like:

```javascript
static { this.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({...}) }
```

esbuild still replaces the marked call with `void 0`, producing `(void 0) is not a function`
at runtime. The fix is to strip ALL `/*@__PURE__*/` annotations from all Axis `.mjs` files.

> **CRITICAL — encoding**: Same as Step 2a.5-v and 2a.5-vi — must use no-BOM UTF-8 write.
> Also: do this step AFTER the DOCUMENT patch (Step 2a.5-v) so ɵ characters are already
> correct before this pass runs.

```powershell
$noBomUtf8 = New-Object System.Text.UTF8Encoding($false)
$axisMjsFiles = Get-ChildItem "$UI_DIR\node_modules" -Path "axis-*\fesm2022\*.mjs" -Recurse
$totalFixed = 0
foreach ($f in $axisMjsFiles) {
    $raw = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8)
    if ($raw -match '/\*@__PURE__\*/') {
        $fixed = $raw -replace ' /\*@__PURE__\*/', ''
        [System.IO.File]::WriteAllText($f.FullName, $fixed, $noBomUtf8)
        $count = ([regex]::Matches($raw, '/\*@__PURE__\*/')).Count
        $totalFixed += $count
    }
}
Write-Host "[LOCAL] axis-compat done Removed $totalFixed @__PURE__ annotations from Axis .mjs files"
```

**Step 2a.5-vi.6: Detect and fix encoding corruption (Éµ → ɵ) in DOCUMENT-patched files**

If the DOCUMENT patch (Step 2a.5-v) was previously run with incorrect encoding (Windows-1252
`Get-Content` / `Set-Content`), the Angular `ɵ` character (U+0275, UTF-8: 0xC9 0xB5) will
have been corrupted into two Latin-1 characters `É` (U+00C9) + `µ` (U+00B5). This causes
`i0.ɵɵdefineInjectable` to become `i0.ÉµÉµdefineInjectable` — a property that does not
exist on `@angular/core`, so esbuild emits `(void 0)` for it.

Run this detection-and-correction pass on all 8 patched files:

```powershell
$noBomUtf8 = New-Object System.Text.UTF8Encoding($false)
$wrongPair   = [char]0x00C9 + [char]0x00B5   # Éµ — two chars that should be one ɵ
$correctChar = [char]0x0275                    # ɵ  — correct Angular prefix character
$axisFiles = @(
    "axis-components\fesm2022\axis-components.mjs",
    "axis-components\fesm2022\axis-components-chip-list.mjs",
    "axis-components\fesm2022\axis-components-scroll2tb.mjs",
    "axis-components\fesm2022\axis-components-tour.mjs",
    "axis-charts\fesm2022\axis-charts.mjs",
    "axis-datagrid\fesm2022\axis-datagrid.mjs",
    "axis-ui-generator\fesm2022\axis-ui-generator.mjs",
    "axis-abc-search-address\fesm2022\axis-abc-search-address.mjs"
)
foreach ($relPath in $axisFiles) {
    $fullPath = Join-Path "$UI_DIR\node_modules" $relPath
    if (-not (Test-Path $fullPath)) { continue }
    $raw = [System.IO.File]::ReadAllText($fullPath, [System.Text.Encoding]::UTF8)
    $corruptCount = ([regex]::Matches($raw, [regex]::Escape($wrongPair))).Count
    if ($corruptCount -gt 0) {
        $corrected = $raw.Replace($wrongPair, "$correctChar")
        [System.IO.File]::WriteAllText($fullPath, $corrected, $noBomUtf8)
        Write-Host "[LOCAL] axis-compat done Corrected $corruptCount corrupted ɵ chars in: $relPath"
    }
}
```

**Step 2a.5-vii: Patch tsconfig.json — add baseUrl and noPropertyAccessFromIndexSignature**

Required for TypeScript path aliases (stubs) and for axis-ui-generator-types stub compatibility.

```powershell
$tscfgPath = "$UI_DIR\tsconfig.json"
$tscfg = Get-Content $tscfgPath -Raw | ConvertFrom-Json
if (-not $tscfg.compilerOptions.baseUrl) {
    $tscfg.compilerOptions | Add-Member -NotePropertyName "baseUrl" -NotePropertyValue "./" -Force
}
$tscfg.compilerOptions | Add-Member -NotePropertyName "noPropertyAccessFromIndexSignature" -NotePropertyValue $false -Force
$tscfg | ConvertTo-Json -Depth 20 | Set-Content $tscfgPath -Encoding UTF8
Write-Host "[LOCAL] axis-compat done tsconfig: baseUrl and noPropertyAccessFromIndexSignature set"
```

**Step 2a.5-viii: Patch auth components — add missing AlertModule / LoadingModule imports**

Generated auth components use `<axis-alert>` and `<axis-loading>` in templates but may not
import the required modules. Check and fix each component:

```powershell
$authComponents = @(
    @{ path="src\app\auth\components\auth-callback\auth-callback.component.ts"; modules=@("AlertModule","LoadingModule") },
    @{ path="src\app\auth\components\auth-error\auth-error.component.ts";       modules=@("AlertModule") },
    @{ path="src\app\auth\components\account-locked\account-locked.component.ts"; modules=@("AlertModule") }
)
foreach ($comp in $authComponents) {
    $filePath = Join-Path $UI_DIR $comp.path
    if (-not (Test-Path $filePath)) { continue }
    $content = Get-Content $filePath -Raw -Encoding UTF8
    $changed = $false
    # Add import statement if missing
    $neededModules = $comp.modules -join ", "
    if ($content -notmatch "from 'axis-components'") {
        $content = "import { $neededModules } from 'axis-components';`n" + $content
        $changed = $true
    } else {
        foreach ($mod in $comp.modules) {
            if ($content -notmatch $mod) {
                $content = $content -replace "(from 'axis-components')", "$mod, `$1"
                $changed = $true
            }
        }
    }
    # Add to imports array if missing
    foreach ($mod in $comp.modules) {
        if ($content -notmatch "imports:.*$mod" -and $content -match "imports:\s*\[") {
            $content = $content -replace "(imports:\s*\[)", "`$1$mod, "
            $changed = $true
        }
    }
    if ($changed) {
        Set-Content $filePath -Value $content -Encoding UTF8 -NoNewline
        Write-Host "[LOCAL] axis-compat done Added $($comp.modules -join ', ') to $($comp.path)"
    }
}
```

**Step 2a.5-ix: Fix usePkce type in oidc-init.service.ts**

`angular-oauth2-oidc@17` does not include `usePkce` in the `AuthConfig` type definition.

```powershell
$oidcFile = Join-Path $UI_DIR "src\app\core\services\oidc-init.service.ts"
if (Test-Path $oidcFile) {
    $content = Get-Content $oidcFile -Raw -Encoding UTF8
    if ($content -match "const authConfig: AuthConfig = \{") {
        $content = $content -replace "const authConfig: AuthConfig = \{", "const authConfig = {"
        $content = $content -replace "(\};)\s*(\r?\n.*OAuthService|// oidc)", '$1 as AuthConfig;$2'
        Set-Content $oidcFile -Value $content -Encoding UTF8 -NoNewline
        Write-Host "[LOCAL] axis-compat done Fixed usePkce AuthConfig type cast in oidc-init.service.ts"
    }
}
```

**Step 2a.5-x: Fix Angular 17 @else if comment restriction**

Angular 17 does not allow HTML comments between `}` and `@else if`. Scan all template files
and move any such comments inside the blocks:

```powershell
$templates = Get-ChildItem "$UI_DIR\src" -Recurse -Filter "*.html"
foreach ($tmpl in $templates) {
    $content = Get-Content $tmpl.FullName -Raw -Encoding UTF8
    # Pattern: } followed by whitespace + HTML comment + whitespace before @else
    if ($content -match "\}\s*<!--[^>]*-->\s*@else") {
        $content = $content -replace "(\})\s*(<!--[^>]*-->)\s*(@else)", '$1 $3 { $2'
        Set-Content $tmpl.FullName -Value $content -Encoding UTF8 -NoNewline
        Write-Host "[LOCAL] axis-compat done Moved @else comment inside block in: $($tmpl.Name)"
    }
}
```

---

#### Step 2b — Run ng build (after successful npm install and Axis patches)

> **IMPORTANT — dev configuration**: Use `--configuration development`, NOT `--production`.
> Production budgets fail on large Axis bundles. The app is served via `npx serve` anyway —
> `ng serve` is NOT used because Node 24 causes Vite dependency-resolution failures with
> Angular 17's `axis-components` optimizeDeps.include.
>
> **IMPORTANT — use local ng binary, not global npx ng**: The local binary at
> `node_modules\.bin\ng.cmd` (accessed via the short junction path) is correct for this
> project's Angular version. `npx ng` may resolve to a different version.
>
> **IMPORTANT — clear .angular cache first**: Angular's esbuild cache from previous runs
> may contain stale tree-shaken versions of patched Axis files. Always delete it before
> rebuilding after any Axis node_modules patch.

```powershell
# Use C:\b junction to avoid Windows MAX_PATH 260-char limit
$shortPath = "C:\b"
if (-not (Test-Path $shortPath)) {
    cmd /c mklink /J "$shortPath" "$UI_DIR" | Out-Null
}

# Clear esbuild cache so patched .mjs files are picked up fresh
$cacheDir = "$shortPath\.angular\cache"
if (Test-Path $cacheDir) {
    Remove-Item $cacheDir -Recurse -Force
    Write-Host "[LOCAL] npm-build info Cleared .angular/cache"
}

# Run ng build --configuration development via the local binary and short path
$ngBin  = "$shortPath\node_modules\.bin\ng.cmd"
$buildOut = & "$ngBin" build --configuration development 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "[LOCAL] build failed ng build exited with code $LASTEXITCODE"
    $buildOut | Select-Object -Last 30 | Write-Host
    exit 1
}
$distSize = (Get-ChildItem "$shortPath\dist" -Recurse | Measure-Object -Property Length -Sum).Sum
Write-Host "[LOCAL] npm-build done ng build succeeded. dist/ size: $([math]::Round($distSize/1MB, 1)) MB"
```

Record which stubs were applied (`$stubsApplied`) — used in Step 4 report and the
`[LOCAL] npm-stub info` summary lines below.

After build succeeds, emit for each stub:
```
[LOCAL] npm-stub info Applied TypeScript path alias stub for: <package-name>
[LOCAL] npm-stub info Source files unchanged — AIG coding standards preserved.
[LOCAL] npm-stub info Remove stubs before ECS deployment if real package is available in Artifactory.
```

### Step 2b — Generate local-start-all.ps1

`api-integrator` always produces a single consolidated Spring Boot application — one
JAR, one port, no gateway. **Before writing this file, discover that port:**

1. Read `<API_DIR>/environment-urls.json` → parse `apiUrl` → extract the port number.
   Example: `"apiUrl": "http://localhost:8080"` → `APP_PORT = 8080`.
2. If `environment-urls.json` is absent or has no `apiUrl`, read
   `<API_DIR>/src/main/resources/application.yml` → parse `server.port`.
3. If neither is found, default to `8080` and log:
   `[DEPLOY] app port not found in codebase — defaulting to 8080; verify application.yml`

Store the result as `APP_PORT` and substitute it everywhere below.

Write `<OUT_DIR>/local-start-all.ps1` after the build completes. Required for any local
deployment — without it the developer must manually set env vars and launch the JAR.

```powershell
# local-start-all.ps1 — auto-generated by AIDLC deploy-agent

# Source real credentials from .env if present
if (Test-Path "$PSScriptRoot\.env") {
    Get-Content "$PSScriptRoot\.env" | ForEach-Object {
        if ($_ -match '^\s*([^#][^=]*)=(.*)') {
            [System.Environment]::SetEnvironmentVariable($Matches[1].Trim(), $Matches[2].Trim(), 'Process')
        }
    }
}

# Safe local-dev defaults — override in .env for real credentials.
# One block per epic datasource (derived from environment-urls.json / .env.example — not hardcoded):
# if (-not $env:<ARTIFACT_ID_UPPER>_DB_URL) { $env:<ARTIFACT_ID_UPPER>_DB_URL = "jdbc:..." }

# APP_PORT and APP_JAR are substituted by deploy-agent — never hardcoded.
$appJar  = (Resolve-Path "$PSScriptRoot\<APP_JAR_RELATIVE_PATH>" -ErrorAction SilentlyContinue)

New-Item -ItemType Directory -Force -Path "$PSScriptRoot\logs" | Out-Null
if (-not $appJar) {
    Write-Host "[START] SKIP app — JAR not found. Run ./gradlew bootJar first."
} else {
    $log  = "$PSScriptRoot\logs\app.log"
    $proc = Start-Process java -ArgumentList @(
        "-Dspring.datasource.hikari.initialization-fail-timeout=-1",
        "-Dspring.flyway.enabled=false",
        "-Dserver.port=<APP_PORT>",
        "-jar", $appJar
    ) -RedirectStandardOutput $log -RedirectStandardError $log -PassThru -NoNewWindow
    Write-Host "[START] app PID=$($proc.Id) port=<APP_PORT>"
}

Write-Host "API : http://localhost:<APP_PORT>"
Write-Host "UI  : http://localhost:4200  (run: cd <UI_DIR> && npx ng serve --proxy-config proxy.conf.json)"
```

**`-Dspring.datasource.hikari.initialization-fail-timeout=-1`** is mandatory. Without it,
Spring Boot refuses to start when the database is unreachable or credentials are blank,
blocking all local development.

**`-Dspring.flyway.enabled=false`** prevents Flyway from running baseline migrations
against the dev profile's H2 or a remote DB that isn't yet provisioned.

### Step 2c — Generate proxy.conf.json in the UI repo

Use the same `APP_PORT` discovered in Step 2b. Substitute it into the `target` URL
before writing the file — do not hardcode `8080`.

Write `<UI_DIR>/proxy.conf.json` — **into the UI's own repo root**, not a `ui/` subfolder
of `OUT_DIR`, since `UI_DIR` is now an independent repository:

```json
{
  "/api": {
    "target": "http://localhost:<APP_PORT>",
    "secure": false,
    "changeOrigin": true,
    "logLevel": "info"
  }
}
```

`<APP_PORT>` is replaced with the port read from `environment-urls.json` `apiUrl`
or `application.yml` `server.port` — never a literal value.

The `ng serve` command **must** include `--proxy-config proxy.conf.json`. Without it,
every Angular `HttpClient` call to `/api/**` returns `404` from the Angular dev server
instead of being forwarded to the single Spring Boot app on the discovered port.

---

### Step 3 — Security scan

Scan for common secret/security patterns across both directories using Grep:

Patterns to check (each a separate Grep call):
1. `AKIA[0-9A-Z]{16}` — AWS access key IDs
2. `-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----` — private keys in source
3. `(password|secret|api_key|apikey)\s*=\s*['"][^'"]{8,}['"]` — hardcoded credentials (case-insensitive)
4. `(jdbc:mysql|jdbc:postgresql|jdbc:oracle|jdbc:sqlserver)://[^$\{][^@\s]*:[^@\s]+@` — credentials embedded in JDBC URLs (exclude `${...}` placeholders)
5. `client-secret:\s+[^$\{\s]` — OAuth2 client secret hardcoded in YAML (not a `${...}` placeholder); search `application.yml` and `application-prod.yml` only (exclude `application-dev.yml`)
6. `issuer-uri:\s+https://` in files named `application.yml` (not `application-dev.yml`) — live OIDC issuer committed to main config instead of using env substitution
7. `_authToken\s*=\s*[^$\{\s]` — Artifactory or npm auth token hardcoded in `.npmrc`

For each match:
- Classify: AWS key or private key → `critical`; patterns 5–7 → `high`; hardcoded credential (3) → `high`; JDBC URL with password (4) → `high`
- Record: file path, line number, matched pattern type, severity
- For pattern 6 (`issuer-uri` in non-dev YAML): classify as `medium` — it is not a secret but indicates the config is not environment-portable

Aggregate counts: `{ critical: N, high: N, medium: N, low: N, files_scanned: N }`

**Block rule**: If `critical > 0`, set `scan.status = blocked` and include the file + line for each critical finding.
Otherwise: set `scan.status = done`.

### Step 4 — Write scan report

Write `$OUT_DIR/security-scan.json`:
```json
{
  "status": "done|blocked",
  "files_scanned": 0,
  "findings": { "critical": 0, "high": 0, "medium": 0, "low": 0 },
  "critical_details": []
}
```

## Output

Return a single-line summary per step in the format the deploy skill expects:

```
[LOCAL] validate done Backend, frontend and build artifacts present.
[LOCAL] security done 0 critical, 0 high findings across N files.
```

If any step fails or is blocked, emit the failure line and stop:
```
[LOCAL] validate failed Gradle build exited with code 1. Check API_DIR/build/reports/.
[LOCAL] security blocked 2 critical findings — hardcoded AWS keys. Deployment halted.
```
