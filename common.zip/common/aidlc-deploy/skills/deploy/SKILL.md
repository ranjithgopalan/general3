---
name: deploy
description: >
  Local validation deployment for the Epic Assembler (stage A3 — local-deployment).
  Builds the integrated Spring Boot API and Angular UI, runs a security scan, starts
  both locally on free ports, health-checks them, and produces a deployment-report
  artifact as evidence before the test suite runs.
allowed-tools: Read Write Glob Grep Bash Task
arguments: []
---

# AIDLC Deploy Skill — Local Deployment (A3)

This skill is invoked by the AIDLC-launcher worker for the `local-deployment` stage of the
`uw-cr-epic-assembler` pipeline. It follows the same headless-worker pattern as
`AIDLC-integrator:integrate`.

## Phase 0 — Mode Detection (Unified Execution Model)

**This skill complies with** [`AIDLC-PLUGIN-EXECUTION-CONTRACT.md`](../AIDLC-PLUGIN-EXECUTION-CONTRACT.md)

```powershell
# Always read config (never renamed to .bak)
if (-not (Test-Path "aidlc.config.json")) {
    throw "aidlc.config.json not found"
}

$cfg = Get-Content "aidlc.config.json" -Raw | ConvertFrom-Json
$centralBaseUrl = $cfg.central_base_url.TrimEnd('/')
$workspaceId = $cfg.workspace_id

# Detect mode via env var (only difference from ECS to local)
$runId = [System.Environment]::GetEnvironmentVariable("AIDLC_RUN_ID")
$isLocalMode = $runId -eq "local"

Write-Host "Mode: $(if ($isLocalMode) { 'LOCAL API' } else { 'ECS' })"
Write-Host "Workspace: $workspaceId"
Write-Host "Central API: $centralBaseUrl"
```

| Mode | Condition | Behavior |
|---|---|---|
| **Local API** | `$env:AIDLC_RUN_ID = "local"` | Deploy locally; fetch prerequisites from temp directory; no ECS run management |
| **ECS** | `$env:AIDLC_RUN_ID` = run ID or empty | Deploy locally; fetch prerequisites from central API; upload artifacts to ECS |

Set `$isLocalMode` flag for use throughout the skill.

---

## Phase 0a — ECS Run Management (local launcher mode only)

Skip this phase in WORKER and STANDALONE modes.

Read config and apply smart run management — cancel any queued run, attach to any running
run, or create a fresh run if none is active. Then set `$AIDLC_RUN_ID` in the local
environment so Phase 5 can upload artifacts and call `/complete`.

```powershell
$cfg   = Get-Content "aidlc.config.json" | ConvertFrom-Json
$BASE  = $cfg.central_base_url.TrimEnd('/')
$TOKEN = [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env)
if (-not $TOKEN) {
    $relayFile = Join-Path (Get-Location) ".aidlc_token"
    if (Test-Path $relayFile) { $TOKEN = (Get-Content $relayFile -Raw -Encoding UTF8).Trim() }
}
$WS    = $cfg.workspace_id
$HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
$STAGE = "local-deployment"

# Smart run management: cancel queued, attach running, create fresh
try {
    $active = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS&stage_key=$STAGE" -Headers $HDR).items |
              Where-Object { $_.state -in @("queued","running") -and (-not $_.worktree) }
} catch { $active = @() }

$runningRun = $active | Where-Object { $_.state -eq "running" } | Select-Object -First 1
$queuedRun  = $active | Where-Object { $_.state -eq "queued"  } | Select-Object -First 1

if ($runningRun) {
    $RUN_ID = $runningRun.run_id
    Write-Host "Attaching to running ECS run: $RUN_ID"
} elseif ($queuedRun) {
    Invoke-RestMethod "$BASE/pipeline-runs/$($queuedRun.run_id)/cancel" -Headers $HDR -Method Post | Out-Null
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true } | ConvertTo-Json
    $RUN_ID = (Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body).run.run_id
    Write-Host "ECS run created: $RUN_ID"
} else {
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true } | ConvertTo-Json
    $RUN_ID = (Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body).run.run_id
    Write-Host "ECS run created: $RUN_ID"
}

$env:AIDLC_RUN_ID = $RUN_ID
$env:AIDLC_WS_ID  = $WS
$env:AIDLC_TOKEN  = $TOKEN
```

---

## Phase 1 — Read config and locate artifacts

1. **Resolve workspace context:**
   - **LOCAL LAUNCHER mode**: `$WS_ID`, `$TOKEN`, `$BASE`, and `$HDR` already set in Phase 0a — reuse them.
   - **WORKER mode**: `$WS_ID = $env:AIDLC_WS_ID`; `$TOKEN = $env:AIDLC_TOKEN`; `$BASE = $env:AIDLC_CENTRAL_BASE_URL` if set.
   - **STANDALONE mode**: prompt the user for workspace ID and ECS base URL.

2. **Set working directories (LOCAL LAUNCHER and WORKER modes):**
   ```powershell
   # Worker writes all stage output under aidlc-ws\{wsId}\{stageKey}\
   $workerBase = Join-Path $env:TEMP "aidlc-ws\$WS_ID"
   $outDir     = Join-Path $workerBase "local-deployment"
   New-Item -ItemType Directory -Force $outDir | Out-Null
   $WORK_DIR = $outDir
   ```

3. **Locate artifacts from worker output directories (LOCAL LAUNCHER and WORKER modes):**

   The worker downloads and extracts approved upstream stage artifacts directly into its own
   temp directory (`aidlc-ws\{wsId}\{stageKey}\`). Read from there — no ECS download needed:

   ```powershell
   # EA1 (epic-assemble) output lives under integration-output\
   $ea1OutDir = Join-Path $workerBase "epic-assemble\integration-output"
   # EA2 (db-wiring) output lives directly under the db-wiring stage dir
   $ea2Dir    = Join-Path $workerBase "db-wiring"

   # Validate both stage output directories exist
   if (-not (Test-Path $ea1OutDir)) {
       Write-Host "[LOCAL] artifacts failed EA1 output not found at: $ea1OutDir"
       Write-Host "[LOCAL] artifacts info  Ensure the epic-assemble stage completed and was approved before running local-deployment."
       exit 1
   }
   if (-not (Test-Path $ea2Dir)) {
       Write-Host "[LOCAL] artifacts failed EA2 output not found at: $ea2Dir"
       Write-Host "[LOCAL] artifacts info  Ensure the db-wiring stage completed and was approved before running local-deployment."
       exit 1
   }
   ```

4. **Set directory variables:**
   ```powershell
   # Folder names are project-prefixed (e.g. test-admin-v2-api), not fixed strings.
   # Discover them by pattern rather than hardcoding.
   $API_DIR = (Get-ChildItem $ea1OutDir -Directory | Where-Object { $_.Name -like "*-api" } | Select-Object -First 1).FullName
   $UI_DIR  = (Get-ChildItem $ea1OutDir -Directory | Where-Object { $_.Name -like "*-ui"  } | Select-Object -First 1).FullName
   $OUT_DIR = $outDir

   if (-not $API_DIR) { Write-Host "[LOCAL] artifacts failed No *-api folder found in $ea1OutDir"; exit 1 }
   if (-not $UI_DIR)  { Write-Host "[LOCAL] artifacts failed No *-ui  folder found in $ea1OutDir"; exit 1 }

   Write-Host "[LOCAL] artifacts found API : $API_DIR"
   Write-Host "[LOCAL] artifacts found UI  : $UI_DIR"
   ```

   **STANDALONE mode**: prompt user for `$API_DIR`, `$UI_DIR`, and set `$OUT_DIR` to a local
   directory of their choice.

---

## Phase 0.5 — Tool Discovery

Probe for JDK 21, Gradle wrapper, Node.js, and npm before attempting any build or JAR startup.
This runs once and exports `$JAVA_BIN`, `$GRADLE_CMD`, and `$NODE_MAJOR` for use in all subsequent phases.

> **Build system: Gradle (not Maven).** The integrated API project uses `build.gradle` /
> `gradlew`. Maven (`pom.xml`) is not present. Always use `./gradlew` (or `gradlew.bat` on
> Windows) — never `mvn`.

```bash
# ── Java ──────────────────────────────────────────────────────────────────────
JAVA_BIN=""
if java -version 2>/dev/null; then
  JAVA_BIN="java"
else
  for d in "$HOME/tools/jdk21" "$HOME/tools/jdk" \
            "C:/tools/jdk21" "C:/Program Files/Java/jdk-21" \
            "C:/Program Files/Eclipse Adoptium/jdk-21"*; do
    if [ -f "$d/bin/java" ]; then
      export JAVA_HOME="$d"
      export PATH="$d/bin:$PATH"
      JAVA_BIN="$d/bin/java"
      echo "[LOCAL] tools found Java at $JAVA_HOME"
      break
    fi
  done
fi

if [ -z "$JAVA_BIN" ]; then
  echo "[LOCAL] build failed java not found. Searched: ~/tools/jdk21, C:/tools/jdk21, Program Files. Install JDK 21 or set JAVA_HOME."
  exit 1
fi

# ── Gradle wrapper ────────────────────────────────────────────────────────────
# Always use the project's own gradlew / gradlew.bat — do NOT use a system-wide gradle.
if [ -f "$API_DIR/gradlew" ]; then
  GRADLE_CMD="$API_DIR/gradlew"
  chmod +x "$GRADLE_CMD" 2>/dev/null
  echo "[LOCAL] tools found Gradle wrapper at $GRADLE_CMD"
elif [ -f "$API_DIR/gradlew.bat" ]; then
  GRADLE_CMD="$API_DIR/gradlew.bat"
  echo "[LOCAL] tools found Gradle wrapper (bat) at $GRADLE_CMD"
else
  echo "[LOCAL] build failed gradlew not found in $API_DIR. The integrated API must include a Gradle wrapper."
  exit 1
fi

# ── Node.js ───────────────────────────────────────────────────────────────────
NODE_MAJOR=$(node -e "process.stdout.write(String(process.versions.node.split('.')[0]))" 2>/dev/null)
if [ -z "$NODE_MAJOR" ]; then
  echo "[LOCAL] build failed Node.js not found. Install Node 20 LTS (https://nodejs.org/en/download) or use nvm: nvm use 20"
  exit 1
fi
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo "[LOCAL] build failed Node.js $NODE_MAJOR detected — Node 20 LTS required for Angular 17 + Axis v18.0.32."
  echo "[LOCAL] build info Switch versions: nvm install 20 && nvm use 20"
  exit 1
fi
echo "[LOCAL] tools Node.js $NODE_MAJOR detected (OK)"

# ── npm ───────────────────────────────────────────────────────────────────────
NPM_MAJOR=$(npm -v 2>/dev/null | cut -d. -f1)
if [ -z "$NPM_MAJOR" ]; then
  echo "[LOCAL] build warning npm not found — will use npx fallback during build"
elif [ "$NPM_MAJOR" -lt 9 ]; then
  echo "[LOCAL] build warning npm $NPM_MAJOR detected — npm 9+ recommended. Run: npm install -g npm@latest"
fi
```

Pass `JAVA_BIN`, `GRADLE_CMD`, and `NODE_MAJOR` in the environment when spawning the deploy-agent sub-agent in Phase 2.

---

## Phase 2 — Build validation

Spawn the build-and-scan sub-agent:

```
Task({
  subagent_type: "AIDLC-deploy:deploy-agent",
  prompt: "Build and security-scan. API_DIR=$API_DIR UI_DIR=$UI_DIR OUT_DIR=$OUT_DIR"
})
```

Parse the sub-agent's output lines:
- Lines starting with `[LOCAL]` → emit them verbatim (they are picked up by the UI log parser)
- Lines starting with `[LOCAL] npm-stub` → also emit verbatim and record stub names for Phase 4
- If any line contains `failed` or `blocked` → abort and call `/complete` with `status: failed`

> **AIG package stub policy:** The deploy-agent applies TypeScript path alias stubs for any
> `@aig/*` package unavailable in the configured Artifactory registry (Step 2a–2b of
> deploy-agent). Source files are **never modified** — the stub satisfies the TypeScript
> compiler only. AIG coding standards (e.g. `PointHttpClient` usage) are fully preserved.
> Stubs applied during this run are listed in the deployment report (Phase 4).

---

## Phase 3 — Local run validation

### 3a — Pre-flight: free required ports

`api-integrator` always produces a single consolidated Spring Boot application — one
port for the app, one for the frontend. Before starting any process, verify both are free:

```bash
free_port() {
  local PORT=$1
  local NAME=$2
  # lsof on Unix / netstat on Windows
  PID=$(lsof -ti:$PORT 2>/dev/null \
     || netstat -ano 2>/dev/null | awk "/:$PORT /{print \$NF}" | head -1 | tr -d ' ')
  if [ -n "$PID" ]; then
    echo "[LOCAL] port warning Port $PORT occupied by PID $PID — attempting kill..."
    kill -9 "$PID" 2>/dev/null || taskkill /F /PID "$PID" 2>/dev/null
    sleep 2
    STILL=$(lsof -ti:$PORT 2>/dev/null \
          || netstat -ano 2>/dev/null | awk "/:$PORT /{print \$NF}" | head -1 | tr -d ' ')
    if [ -n "$STILL" ]; then
      echo "[LOCAL] $NAME failed Port $PORT still occupied after kill attempt (PID $STILL). Manual cleanup required."
      exit 1
    fi
    echo "[LOCAL] port info Port $PORT is now free."
  fi
}
```

Call `free_port <APP_PORT> app`, then `free_port 4201 frontend`, where `<APP_PORT>` is
read from `$API_DIR/environment-urls.json`'s `apiUrl` (fall back to `application.yml`
`server.port` if absent).

If any port cannot be freed → abort with `[LOCAL] <name> failed` and stop all previously started PIDs.

### 3b — Locate the app JAR

There is one `build.gradle` and one JAR now — no per-module discovery needed:
- Locate the JAR: `$API_DIR/build/libs/*.jar` (exclude `*-plain.jar` — that is the non-executable archive Gradle also produces).
- Read `$API_DIR/environment-urls.json` → `apiUrl` for `APP_PORT` (fallback: `$API_DIR/src/main/resources/application.yml` → `server.port`).

```powershell
$APP_JAR = Get-ChildItem "$API_DIR/build/libs" -Filter "*.jar" |
           Where-Object { $_.Name -notlike "*-plain.jar" } |
           Sort-Object Length -Descending | Select-Object -First 1 -ExpandProperty FullName

if (-not $APP_JAR) {
    Write-Host "[LOCAL] build failed No executable JAR found in $API_DIR/build/libs"
    Write-Host "[LOCAL] build info  Run: cd '$API_DIR' && ./gradlew bootJar"
    exit 1
}
Write-Host "[LOCAL] jar found $APP_JAR"
```

### 3c — Start the app with real DB credentials

The project has a real database configured by the EA2 (db-wiring) stage. Read the `.env`
file from `$API_DIR/.env` to get the real JDBC URLs, username, and password — one
credential set per epic that has a datasource (namespaced `<EPIC>_DB_*` variables).

**Do NOT substitute H2 or any in-memory database.** The EA2 stage already wired the real
MSSQL credentials. Use them directly:

```powershell
# Locate .env — must be present in the integrated API artifact
$dotEnvPath = "$API_DIR/.env"
if (-not (Test-Path $dotEnvPath)) {
    Write-Host "[LOCAL] db-config failed .env not found at: $dotEnvPath"
    Write-Host "[LOCAL] db-config info Create $dotEnvPath with your SQL Server credentials."
    Write-Host "[LOCAL] db-config info Copy .env.example from the same directory and fill in the real values"
    Write-Host "[LOCAL] db-config info   one <EPIC>_DB_URL / <EPIC>_DB_USERNAME / <EPIC>_DB_PASSWORD block per epic datasource"
    Write-Host "[LOCAL] db-config info   OIDC_ISSUER_URI, OIDC_CLIENT_ID (obtain from Okta/AIG Identity team)"
    exit 1
}

# Parse .env file
$envVars = @{}
Get-Content $dotEnvPath | Where-Object { $_ -match "^\s*[^#]" -and $_ -match "=" } | ForEach-Object {
    $parts = $_ -split "=", 2
    $envVars[$parts[0].Trim()] = $parts[1].Trim()
}

# Validate every <EPIC>_DB_USERNAME / <EPIC>_DB_PASSWORD pair present in .env is not blank
# or a REPLACE_WITH placeholder (discover the var names from .env.example, not hardcoded).
$credErrors = @()
foreach ($key in $envVars.Keys | Where-Object { $_ -match "_DB_(USERNAME|PASSWORD)$" }) {
    if ($envVars[$key] -match "REPLACE_WITH" -or -not $envVars[$key]) {
        $credErrors += "$key is blank or a placeholder"
    }
}
if ($credErrors.Count -gt 0) {
    Write-Host "[LOCAL] db-config failed .env contains placeholder or blank credentials:"
    $credErrors | ForEach-Object { Write-Host "[LOCAL] db-config failed   - $_" }
    Write-Host "[LOCAL] db-config info Edit $dotEnvPath and provide real SQL Server credentials."
    exit 1
}

# Validate OIDC configuration is present (required for Spring Security JWT validation)
$oidcErrors = @()
if (-not $envVars["OIDC_ISSUER_URI"] -and -not $envVars["SPRING_SECURITY_OAUTH2_RESOURCESERVER_JWT_ISSUER_URI"]) {
    $oidcErrors += "OIDC_ISSUER_URI (or SPRING_SECURITY_OAUTH2_RESOURCESERVER_JWT_ISSUER_URI) is missing"
}
if ($oidcErrors.Count -gt 0) {
    Write-Host "[LOCAL] oidc-config warning .env is missing OIDC configuration (app will start but JWT validation will fail):"
    $oidcErrors | ForEach-Object { Write-Host "[LOCAL] oidc-config warning   - $_" }
    Write-Host "[LOCAL] oidc-config info Obtain OIDC_ISSUER_URI and OIDC_CLIENT_ID from the Okta/AIG Identity team."
    Write-Host "[LOCAL] oidc-config info Proceeding with startup — Spring Boot will reject all JWT-validated requests until OIDC is configured."
}
```

**Load ALL `.env` vars as OS environment variables first** — this is the correct way to expose
them to Spring Boot. Spring Boot resolves `${VAR_NAME}` placeholders from OS env vars, so setting
them in the process environment avoids having to pass every var as a command-line arg.

```powershell
# Set ALL .env vars as OS environment variables — child process inherits them
$envVars.GetEnumerator() | ForEach-Object { Set-Item "env:$($_.Key)" $_.Value }
```

Start the single JAR. **JVM system properties (`-D`) must appear BEFORE `-jar`**. Let the
env vars (set above) resolve all Spring `${VAR}` placeholders automatically — do NOT
manually re-pass datasource URL/username/password as command-line args:

```powershell
# Check whether any epic package has a @Profile("dev") fallback DAO.
# If so, add --spring.profiles.active=dev so the dev stub is active for local testing.
$hasDevProfile = (Get-ChildItem "$API_DIR/src/main/java" -Recurse -Filter "*.java" |
    Select-String '@Profile\("dev"\)' | Measure-Object).Count -gt 0
$profileArg = if ($hasDevProfile) { "--spring.profiles.active=dev" } else { "" }

$proc = Start-Process -FilePath $JAVA_BIN -ArgumentList (
    @("-jar", "$APP_JAR", "--server.port=$APP_PORT", "--spring.flyway.enabled=false") +
    $(if ($profileArg) { @($profileArg) } else { @() })
) -PassThru -WindowStyle Hidden `
  -RedirectStandardOutput "$OUT_DIR/app.log" `
  -RedirectStandardError  "$OUT_DIR/app-err.log"
$proc.Id | Out-File "$OUT_DIR/app.pid" -Encoding ascii
Write-Host "[LOCAL] app running Starting on :$APP_PORT..."
```

**Dev profile convention:** If any epic package has a `@Profile("dev")` DAO stub (e.g.
`DevInMemory*Dao`), activating `dev` profile lets the app start locally without requiring
all stored-procedure DAOs to be fully wired. This is intentional — the production JDBC
DAOs are generated in the db-integration stage but local-deployment smoke-tests only need
the app to boot and respond to health checks.

Poll the app's health endpoint (20 × 3s):
```bash
for i in $(seq 1 20); do
  CODE=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$APP_PORT/actuator/health" 2>/dev/null)
  [ "$CODE" = "200" ] && echo "[LOCAL] app done Healthy on :$APP_PORT" && HEALTHY=1 && break
  sleep 3
done
[ -z "$HEALTHY" ] && echo "[LOCAL] app failed Did not reach UP after 60s. Check $OUT_DIR/app.log" && exit 1
```

### 3d — Serve Angular frontend (SPA-aware)

Locate the Angular build output directory (contains `index.html`) — `$UI_DIR` is the
UI's own independent repo root, not nested under `$API_DIR` or `$OUT_DIR`:
```bash
DIST_DIR=$(find "$UI_DIR/dist" -name "index.html" -maxdepth 3 | head -1 | xargs dirname)

# npx serve -s rewrites all 404s to index.html — required for Angular pushState routing
npx serve -s "$DIST_DIR" -l 4201 \
  > "$OUT_DIR/frontend.log" 2>&1 &
echo $! > "$OUT_DIR/frontend.pid"
FRONTEND_PORT=4201
echo "[LOCAL] frontend running Serving Angular SPA on :$FRONTEND_PORT (SPA mode)..."
```

Note: `python3 -m http.server` is NOT used — it does not support HTML5 pushState routing and returns 404 for Angular deep-link paths (e.g. `/business-lines/search`).

### 3e — Smoke assertions

```
Task({
  subagent_type: "AIDLC-deploy:deploy-validator",
  prompt: "Smoke test. APP_URL=http://localhost:$APP_PORT LOCAL_FRONTEND_URL=http://localhost:$FRONTEND_PORT"
})
```

Forward all `[LOCAL]` and `[LOCAL_URL]` lines from the sub-agent verbatim.

Emit on success:
```
[LOCAL] ready done App healthy. Business routes verified.
[LOCAL_URL] Application http://localhost:$FRONTEND_PORT/ web
[LOCAL_URL] App Health http://localhost:$APP_PORT/actuator/health api
```

---

## Phase 4 — Generate deployment manifests

Write the following files to `$OUT_DIR/`:

### `deployment-report.md`

```markdown
# Deployment Report — Local Validation

| Step | Status | Detail |
|---|---|---|
| Gradle build | ✔ done | ... |
| npm build | ✔ done | ... |
| Security scan | ✔ done | N files, 0 critical |
| Backend start | ✔ done | http://localhost:PORT |
| Health check | ✔ done | HTTP 200 |
| Frontend serve | ✔ done | http://localhost:PORT |

## Live URLs
- Application: http://localhost:$FRONTEND_PORT/
- API Health: http://localhost:$BACKEND_PORT/actuator/health

## AIG Package Stubs Applied (local deployment only)

> Include this section only when `$stubsApplied` is non-empty. Omit entirely if no stubs were needed.

| Package | Stub Location | Reason | Revert Before ECS |
|---|---|---|---|
| @aig/point-http-client | src/stubs/point-http-client/index.ts | Package not found in Artifactory registry | Yes — restore package.json entry and remove tsconfig path alias |

**AIG standard compliance:** Source files are unchanged. `PointHttpClient` is used as
generated. The stub re-exports Angular `HttpClient` under the `PointHttpClient` name;
the existing `JwtInterceptor` attaches the Okta Bearer header identically to the
production `@aig/point-http-client` package.

**Before ECS/QA deployment:**
1. Confirm `@aig/point-http-client` is resolvable from the ECS build environment's Artifactory registry.
2. If yes: remove `src/stubs/point-http-client/`, remove the tsconfig `paths` entry, restore `package.json`.
3. If no: raise with the AIG Platform team to publish the package to the Artifactory virtual npm repo.

## Next Steps
- QA deployment: submit to QA approver in ECS UI
- Production: pending QA sign-off
```

### `deployment-status.json`

```json
{
  "local": {
    "status": "succeeded",
    "backend_url": "http://localhost:BACKEND_PORT",
    "frontend_url": "http://localhost:FRONTEND_PORT",
    "security": { "critical": 0, "high": 0 }
  },
  "qa": { "status": "pending" },
  "production": { "status": "pending" }
}
```

### `docker-compose.yml`

Generate a docker-compose.yml wiring the Spring Boot backend container and an nginx
container serving the Angular dist, referencing any Dockerfile found in `$API_DIR`.

---

## Phase 5 — Artifact upload and run completion

Run whenever `$env:AIDLC_RUN_ID` is set (LOCAL LAUNCHER and WORKER modes). Skip in STANDALONE mode.

**WORKER mode:** The CLI worker owns all ECS lifecycle steps — ensure all output files are
written to the current working directory (`$stageOutputDir`). The worker scans for new files,
zips them by artifact type, uploads, and calls `/complete` automatically. Files to confirm:
- `deployment-report.md`
- `deployment-status.json`
- `docker-compose.yml`

**LOCAL LAUNCHER mode:** Call ECS directly after Phase 4 writes all output files:

1. ZIP the output directory:
   ```powershell
   $zipPath = Join-Path $env:TEMP "aidlc-ws\$WS_ID\deployment-report.zip"
   Compress-Archive -Path (Join-Path $OUT_DIR "*") -DestinationPath $zipPath -Force
   ```

2. Upload the ZIP:
   ```powershell
   $result     = Invoke-RestMethod "$BASE/artifacts/upload" `
                   -Headers @{ Authorization = "Bearer $TOKEN" } `
                   -Method Post `
                   -Form @{ file=(Get-Item $zipPath); artifact_type="deployment-report"; run_id=$env:AIDLC_RUN_ID }
   $artifactId = $result.artifact_id
   ```

3. Complete the run:
   ```powershell
   $completeBody = @{ status="completed"; artifact_ids=@($artifactId) } | ConvertTo-Json
   Invoke-RestMethod "$BASE/pipeline-runs/$($env:AIDLC_RUN_ID)/complete" `
       -Headers $HDR -Method Post -Body $completeBody | Out-Null
   Write-Host "ECS run $($env:AIDLC_RUN_ID) marked completed. Artifacts uploaded."
   ```

4. Open ECS UI for DevOps approval:
   ```
   https://poc-ecs-build-ui.npsdlchgapp.us-east-1.aws.aig.net/aidlc-platform-management/pipeline
   ```
   Approval persona: **DevOps**

---

## Phase 6 — Human-readable summary (standalone mode only)

Print after Phase 5 in STANDALONE mode (no ECS tracking). In LOCAL LAUNCHER and WORKER modes the
ECS UI serves as the record — skip this box to avoid duplication. In STANDALONE mode:

```
╔══════════════════════════════════════════════════════════════╗
║  LOCAL DEPLOYMENT COMPLETE                                   ║
╠══════════════════════════════════════════════════════════════╣
║  Application   http://localhost:FRONTEND_PORT/               ║
║  API Health    http://localhost:BACKEND_PORT/actuator/health ║
╠══════════════════════════════════════════════════════════════╣
║  Security: 0 critical · 0 high · N files scanned            ║
║  Next: approve in ECS UI to unlock EA4 (ui-smoke)            ║
╚══════════════════════════════════════════════════════════════╝
```

