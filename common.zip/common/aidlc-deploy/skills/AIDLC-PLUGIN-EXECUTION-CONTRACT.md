---
# AIDLC Plugin Execution Contract v1.0

**All pipeline execution plugins MUST comply with this contract.**

Ensures unified behavior across local and ECS central API modes — the only difference is the API endpoint, not the execution logic.

---

## Core Principle

**One execution model. Two API endpoints.**

- `central_base_url: "http://localhost:8080/..."` → Local mode
- `central_base_url: "https://cloud-api.../..."` → ECS mode

Everything else (prerequisites, output, temp directories) works identically.

---

## Mandatory Phases

### **Phase 0 — Config Reading**

**ALWAYS read `aidlc.config.json`** from the current working directory. Never rename it to `.bak` or any other variant.

```powershell
# Read config
if (-not (Test-Path "aidlc.config.json")) {
    throw "aidlc.config.json not found — run /launch first."
}

$cfg = Get-Content "aidlc.config.json" -Raw -Encoding UTF8 | ConvertFrom-Json

# Extract critical fields
$centralBaseUrl = $cfg.central_base_url.TrimEnd('/')
$workspaceId    = $cfg.workspace_id
$authBearerEnv  = $cfg.auth.bearer_env  # Usually "AIDLC_TOKEN"

# Resolve token
$TOKEN = [System.Environment]::GetEnvironmentVariable($authBearerEnv)
if (-not $TOKEN) {
    # Fallback to relay file
    $relayFile = Join-Path (Get-Location) ".aidlc_token"
    if (Test-Path $relayFile) {
        $TOKEN = (Get-Content $relayFile -Raw -Encoding UTF8).Trim()
    }
}

Write-Host "Config read: workspace_id=$workspaceId, central_base_url=$centralBaseUrl"
```

### **Phase 1 — Mode Detection**

**Detect execution mode** by checking the `AIDLC_RUN_ID` environment variable.

```powershell
$runId = [System.Environment]::GetEnvironmentVariable("AIDLC_RUN_ID")
$isLocalMode = $runId -eq "local"

if ($isLocalMode) {
    Write-Host "[LOCAL MODE] Running locally, prerequisites from temp directory"
} else {
    Write-Host "[ECS MODE] Running in ECS, prerequisites from central API"
}
```

**Two paths from here:**
- **Local mode** (`AIDLC_RUN_ID = "local"`): Discover prerequisites from temp directory
- **ECS mode** (`AIDLC_RUN_ID` = run ID or empty): Query central API for prerequisites

### **Phase 2 — Prerequisite Discovery (Unified: Query API + Download from S3)**

**Both local AND ECS modes follow the same flow:**

Always query the Central API for completed prerequisite runs, get their artifact IDs from S3, download them fresh, and place them in the temp directory. This ensures you always have the latest version, not stale temp cache.

**Step 2A: Query Central API for Completed Runs**

```powershell
$HDR = @{ 
    Authorization = "Bearer $TOKEN"
    "Content-Type" = "application/json" 
}

# Example: Get completed ui-code runs
$runsUrl = "$centralBaseUrl/pipeline-runs?workspace_id=$workspaceId&stage_key=ui-code"
$runs = (Invoke-RestMethod $runsUrl -Headers $HDR).items

$completedRun = $runs | Where-Object { $_.state -in @("completed", "waiting_for_approval") } |
                     Sort-Object queued_at -Descending |
                     Select-Object -First 1

if (-not $completedRun) {
    Write-Host "⚠ No completed ui-code run found"
    throw "Prerequisite ui-code run not found in Central API"
}

Write-Host "Found completed run: $($completedRun.run_id)"
```

**Step 2B: Get Artifact IDs from Run Record**

```powershell
# The API response includes artifact information
$artifactIds = $completedRun.artifacts | Where-Object { $_.artifact_type -eq "ui-source" }

if (-not $artifactIds) {
    throw "No ui-source artifacts found in run $($completedRun.run_id)"
}

Write-Host "Found $($artifactIds.Count) artifact(s) to download"
```

**Step 2C: Download Artifacts from S3**

```powershell
# Download each artifact from S3 using the artifact ID
foreach ($artifact in $artifactIds) {
    $artifactId = $artifact.artifact_id
    $downloadUrl = "$centralBaseUrl/artifacts/$artifactId/download"
    
    Write-Host "Downloading artifact: $artifactId"
    
    # Download to temp location
    $tempArtifactZip = Join-Path $env:TEMP "artifact-$artifactId.zip"
    Invoke-WebRequest -Uri $downloadUrl -Headers $HDR -OutFile $tempArtifactZip
    
    # Extract to temp working directory
    $extractPath = Join-Path (Join-Path (Join-Path $env:TEMP "aidlc-ws") $workspaceId) "ui-code"
    if (Test-Path $extractPath) { Remove-Item $extractPath -Recurse -Force }
    New-Item -ItemType Directory -Path $extractPath -Force | Out-Null
    
    Expand-Archive -Path $tempArtifactZip -DestinationPath $extractPath -Force
    Remove-Item $tempArtifactZip
    
    Write-Host "✓ Artifact extracted to: $extractPath"
}

# Set worktree to the extracted path
$uiCodeWorktree = $extractPath
```

**Key Points:**
- ✅ **Both local and ECS**: Query Central API (not temp cache)
- ✅ **Both fetch from S3**: Download latest artifact versions
- ✅ **Both update temp directory**: Place fresh code in working directory
- ✅ **Only difference**: `$isLocalMode` affects where artifacts are queried from next (not used in this unified phase)

**Temp Directory Role:**
- Temp directory = **working directory for the skill to execute**
- NOT a cache to reuse between runs
- Always refreshed with latest artifacts from S3

### **Phase 3 — Prerequisite Validation (Gate Check)**

Before executing, verify all required prerequisites are available.

```powershell
# Example for EA1 (epic-assemble): requires ui-code AND api-code
if (-not $uiCodeWorktree -or -not $apiCodeWorktree) {
    $msg = @(
        "⚠ GATE CHECK FAILED — Missing prerequisites:"
        "  UI Code:  $(if ($uiCodeWorktree) { 'found' } else { 'NOT FOUND' })"
        "  API Code: $(if ($apiCodeWorktree) { 'found' } else { 'NOT FOUND' })"
        ""
        "Run the prerequisite stages (M2, M3) before running EA1."
    ) -join "`n"
    throw $msg
}

Write-Host "✓ All prerequisites found"
```

### **Phase 4 — Execution (Plugin-Specific)**

Execute the stage's core logic using the discovered prerequisites.

The logic is identical whether prerequisites came from temp directory or API — the plugin doesn't care where they came from.

### **Phase 5 — Output to Temp Directory**

**All output goes to the temp directory**, never to the project root.

**For M1-M7 stages** (individual epic work — no integration):
```powershell
$stageKey = "lld"      # M1 design documents
# OR: "ui-code", "api-code", "security-opa", "api-test", "ui-smoke"

$tempBase = Join-Path (Join-Path (Join-Path $env:TEMP "aidlc-ws") $wsId) $stageKey
if (-not (Test-Path $tempBase)) {
    New-Item -ItemType Directory -Path $tempBase -Force | Out-Null
}

Write-Host "Output directory: $tempBase"
# Write generated files directly to $tempBase (no integration-output/ subfolder)
# Examples:
# - M1: Write FEATURE-TDD.md, UI-TDD.md, SERVICE-TDD.md to $tempBase
# - M2: Write src/, angular.json to $tempBase
# - M3: Write pom.xml, src/ to $tempBase
```

**For EA1-EA3 stages** (assembler workspace — integration happens here):
```powershell
$stageKey = "epic-assemble"  # Or "db-wiring", "local-deployment"

$tempBase = Join-Path (Join-Path (Join-Path $env:TEMP "aidlc-ws") $wsId) $stageKey
if (-not (Test-Path $tempBase)) {
    New-Item -ItemType Directory -Path $tempBase -Force | Out-Null
}

# EA1-EA3 use integration-output/ subfolder
$outputDir = Join-Path $tempBase "integration-output"
if (-not (Test-Path $outputDir)) {
    New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
}

Write-Host "Output directory: $outputDir"

# Write integrated/assembled code here
# Examples:
# - EA1: Write merged api/, ui/, INTEGRATION-SUMMARY.md to $outputDir
# - EA2: Write api/ (with DAO layer), DB-INTEGRATION-REPORT.md to $outputDir
# - EA3: Write docker-compose.yml, Dockerfile, DEPLOYMENT-REPORT.md to $outputDir
```

### **Phase 6 — ECS Run Reporting (Local Launcher Mode Only)**

**Only if running in local launcher mode** (config exists AND `AIDLC_RUN_ID` is empty OR set to "local" by launcher):

Upload artifacts to ECS and mark the run complete.

```powershell
# Only run this phase if:
# 1. Config exists (aidlc.config.json)
# 2. We're supposed to report to ECS (check env var or launcher context)

$shouldReportToEcs = $true  # Detect based on execution context

if ($shouldReportToEcs) {
    # Upload artifacts
    $artifacts = @(
        @{ 
            artifact_type = "api-source"
            artifact_id = "api-code-output"
            path = $mergedApiCode
        }
    )
    
    # Call ECS API to upload and mark run complete
    # POST {central_base_url}/pipeline-runs/{run_id}/artifacts
    # POST {central_base_url}/pipeline-runs/{run_id}/complete
    
    Write-Host "✓ Artifacts uploaded to ECS"
}
```

---

## Output Directory Structure

Each epic workspace produces its own code. Integration happens only at EA1 (epic-assemble) stage.

```
%TEMP%\aidlc-ws\

# Mini Epic Workspaces (one per epic)
├── {workspace_id--epic-1}\
│   ├── lld\                              # M1 output (design docs)
│   │   ├── FEATURE-TDD.md
│   │   ├── UI-TDD.md
│   │   ├── SERVICE-TDD.md
│   │   └── ...
│   ├── ui-code\                          # M2 output (Angular UI)
│   │   ├── src\
│   │   ├── angular.json
│   │   └── ...
│   ├── api-code\                         # M3 output (Spring Boot API)
│   │   ├── pom.xml
│   │   ├── src\
│   │   └── ...
│   ├── security-opa\                     # M5 output (OPA policies)
│   │   ├── policies\
│   │   └── SECURITY-REPORT.md
│   ├── api-test\                         # M6 output (JUnit tests)
│   │   ├── src/test\
│   │   └── TEST-REPORT.md
│   └── ui-smoke\                         # M7 output (Jasmine tests)
│       ├── src/app\
│       └── TEST-REPORT.md
├── {workspace_id--epic-2}\
│   ├── lld\
│   ├── ui-code\
│   ├── api-code\
│   └── ...
├── {workspace_id--epic-3}\
│   └── ...
├── {workspace_id--epic-4}\
│   └── ...

# Epic Assembler Workspace (integration happens here)
└── {workspace_id--epic-assembler}\
    ├── epic-assemble\                   # EA1 — INTEGRATION OUTPUT
    │   └── integration-output\
    │       ├── api\                     # Merged API from all epics
    │       ├── ui\                      # Merged UI from all epics
    │       ├── INTEGRATION-SUMMARY.md
    │       └── openapi.yaml             # Merged OpenAPI spec
    ├── db-wiring\                       # EA2 — DB WIRING OUTPUT
    │   └── integration-output\
    │       ├── api\                     # Integrated API + DAO layer
    │       └── DB-INTEGRATION-REPORT.md
    └── local-deployment\                # EA3 — DEPLOYMENT OUTPUT
        └── integration-output\
            ├── docker-compose.yml
            ├── Dockerfile (per service)
            ├── DEPLOYMENT-REPORT.md
            └── ...
```

**Key points:**
- **M1-M7 stages**: Output goes directly to stage directory (no `integration-output/` subfolder)
- **EA1 (epic-assemble)**: ONLY here does `integration-output/` exist (for merged API + UI)
- **EA2-EA3**: Use `integration-output/` to store wired/deployed artifacts

---

## Environment Variables (Set by Launcher)

| Variable | Set by | Value | Purpose |
|----------|--------|-------|---------|
| `AIDLC_TOKEN` | Launcher Phase 0 | Okta Bearer token | API authentication |
| `AIDLC_RUN_ID` | Launcher Phase 2.5 | `"local"` OR run ID | Mode detection |
| `AIDLC_WS_ID` | Launcher Phase 2.5 | workspace_id | Workspace context |

**Your plugin reads these:**
```powershell
$token = [System.Environment]::GetEnvironmentVariable("AIDLC_TOKEN")
$runId = [System.Environment]::GetEnvironmentVariable("AIDLC_RUN_ID")
$wsId  = [System.Environment]::GetEnvironmentVariable("AIDLC_WS_ID")
```

---

## Validation Checklist

Every plugin must pass these checks:

- [ ] **Config**: Reads `aidlc.config.json` directly (never renamed)
- [ ] **Mode Detection**: Checks `$env:AIDLC_RUN_ID` to determine local vs ECS
- [ ] **Local Path**: When local, discovers prerequisites from `%TEMP%\aidlc-ws\{wsId}\{prereq-stage}\integration-output\`
- [ ] **ECS Path**: When ECS, queries `{central_base_url}/pipeline-runs?workspace_id={wsId}&stage_key={prereq-stage}`
- [ ] **Gate Check**: Validates all prerequisites exist before executing
- [ ] **Output**: Writes to `%TEMP%\aidlc-ws\{wsId}\{stageKey}\integration-output\` (never to project root)
- [ ] **Error Handling**: Clear messages when prerequisites missing or API fails
- [ ] **ECS Reporting**: (If applicable) Uploads artifacts and marks run complete

---

## Examples

### Example 1: M2 (UI Code Generation)

```powershell
# Phase 0: Read config
$cfg = Get-Content "aidlc.config.json" -Raw | ConvertFrom-Json

# Phase 1: Detect mode
$isLocalMode = [System.Environment]::GetEnvironmentVariable("AIDLC_RUN_ID") -eq "local"

# Phase 2: Discover prerequisites (design docs from M1)
if ($isLocalMode) {
    $designTempDir = Join-Path (Join-Path (Join-Path $env:TEMP "aidlc-ws") $cfg.workspace_id) "lld"
    $designDocs = Get-ChildItem (Join-Path $designTempDir "integration-output") -Filter "*.md"
} else {
    $runs = Invoke-RestMethod "$($cfg.central_base_url)/pipeline-runs?workspace_id=$($cfg.workspace_id)&stage_key=lld"
    $designRun = $runs.items | Where-Object state -eq "completed" | Select-Object -First 1
    # Download design artifacts...
}

# Phase 3: Gate check
if (-not $designDocs) { throw "Design docs not found" }

# Phase 4: Execute (generate UI from design docs)
# ... axis-implement logic ...

# Phase 5: Output to temp
$outputDir = Join-Path (Join-Path (Join-Path $env:TEMP "aidlc-ws") $cfg.workspace_id) "ui-code"
New-Item -ItemType Directory -Path (Join-Path $outputDir "integration-output") -Force | Out-Null
# ... write generated UI code ...
```

### Example 2: EA1 (Epic Assembly)

```powershell
# Phase 0: Read config
$cfg = Get-Content "aidlc.config.json" -Raw | ConvertFrom-Json

# Phase 1: Detect mode
$isLocalMode = [System.Environment]::GetEnvironmentVariable("AIDLC_RUN_ID") -eq "local"

# Phase 2: Discover prerequisites (UI and API code from M2, M3)
if ($isLocalMode) {
    # Search temp directory for epic folders
    $tempBase = Join-Path $env:TEMP "aidlc-ws"
    $epicDirs = Get-ChildItem $tempBase | Where-Object Name -like "*epic-*"
    
    foreach ($epicDir in $epicDirs) {
        $uiPath = Join-Path $epicDir.FullName "ui-code\integration-output"
        $apiPath = Join-Path $epicDir.FullName "api-code\integration-output"
        # Extract UI and API code...
    }
} else {
    # Query API for completed ui-code and api-code runs
    $uiRuns = Invoke-RestMethod "$($cfg.central_base_url)/pipeline-runs?workspace_id=$($cfg.workspace_id)&stage_key=ui-code"
    $apiRuns = Invoke-RestMethod "$($cfg.central_base_url)/pipeline-runs?workspace_id=$($cfg.workspace_id)&stage_key=api-code"
    # Download worktrees...
}

# Phase 3: Gate check
if (-not $uiCode -or -not $apiCode) { throw "Missing UI or API code" }

# Phase 4: Execute (merge UI and API)
# ... integration logic ...

# Phase 5: Output to temp
$outputDir = Join-Path (Join-Path (Join-Path $env:TEMP "aidlc-ws") $cfg.workspace_id) "epic-assemble"
New-Item -ItemType Directory -Path (Join-Path $outputDir "integration-output") -Force | Out-Null
# ... write merged code ...
```

---

## Version History

- **v1.0** (2026-09-18): Initial contract. Unified local + ECS execution model. All plugins must comply.

