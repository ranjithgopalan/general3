---
name: aidlc-tech-lead
description: Tech Lead code reviewer — reads the dev handover docs and QA context for each epic in a workspace, fetches the PR diff from GitHub, writes a grounded code review, posts it as a GitHub PR review (APPROVED or CHANGES_REQUESTED) as the authenticated Okta user, and merges approved PRs. Runs after aidlc-qa (workspace at MERGE). Does not advance workspace state.
when_to_use: When the user runs /aidlc-tech-lead with a workspace_id, or asks to review/approve the dev and QA PRs for a central AIDLC workspace.
disable-model-invocation: true
user-invocable: true
allowed-tools: Read, Write, Edit, Glob, Grep, Bash, TodoWrite
arguments: [workspace_id, action?]
---

# aidlc-tech-lead — Tech Lead code reviewer

Review all dev and QA PRs for workspace **$1**, **one epic at a time**.
For each epic: read the grounded spec docs → fetch the PR diff → analyze → post a GitHub PR review
(APPROVED or CHANGES_REQUESTED). Does **not** merge or advance workspace state.

**Guardrails (non-negotiable):**
- **Grounded review only.** Every finding must cite a spec element: a story AC clause, an FR delta, a
  KB ID, or an explicit checklist item from the dev handover doc. Do not flag style preferences.
- **No fabrication.** If the diff is absent or the spec is unclear, note it explicitly — do not invent
  requirements. Write `// AIDLC-TL-TODO` where you cannot determine the correct behaviour.
- **Approve when in spec.** If the implementation matches the spec and all checklist items pass,
  approve. Do not hold the PR for hypothetical issues.
- **One review per PR.** Post the review once — include all comments in the same review body.
  Re-run only if the developer pushes new commits.
- **Stop on first failure.** If any epic fails (bundle fetch, diff fetch, approve post), stop and
  report. Do not continue to the next epic.

---

## Action dispatch

| `$2` | Action |
|---|---|
| *(omitted)* or `review` | Full epic loop — auth → fetch bundle → per-epic review + post |
| `status` | Print review status per epic without posting (reads tl-findings-*.json) |

---

## Automated Workflow

**Track every step with TodoWrite. Run all steps without pausing unless a step fails.**

Let `S = ${CLAUDE_PLUGIN_ROOT}/scripts` and `CFG = config/aidlc.config.json`.
Run all Python with `python` (not `py` / `python3`).

Ask the user for `workspace_id` if not provided as `$1`, then proceed without further prompts.

---

### Step 0 — Authenticate

```bash
python "$S/aidlc_auth.py" login --config "$CFG"
```

No-op when `auth.okta` is null. Always run — token resolution ladder must execute.

---

### Step 1 — Fetch TL bundle

```bash
python "$S/aidlc_tl_bundle.py" $1 --config "$CFG"
```

Writes:
- `.aidlc/$1/tl-bundle.json` — workspace + epics + PR metadata + local doc paths
- `.aidlc/$1/TL_CONTEXT.md` — human-readable overview for your review

**Read `TL_CONTEXT.md` immediately.** It shows which epics have PRs, whether the dev handover docs
and QA context docs are present, and any missing artifacts.

- If no epics are found: fall back to workspace-level mode (run the per-epic steps once without
  `--epic-id`, using the workspace-level PR metadata + dev-handover doc).
- If required artifacts are missing (no dev-handover doc, no PR URL), note it in the summary and
  skip that epic — do not stop the entire loop.

---

### Step 1.5 — Check if all PRs are already merged (fast-path)

Read `.aidlc/$1/tl-bundle.json`. Check every object in `bundle.epics`:

```
all_merged = every epic has merge_pr == true
```

**If `all_merged` is true:**

Print:
```
[PASS] All PRs already merged — skipping review loop.
   Proceeding directly to Step 6 (KB refresh).
```

Then skip the entire per-epic loop (Steps 2–4.5) and jump to **Step 5 → Step 6**.

**If any epic has `merge_pr != true`:** continue with the per-epic loop below.

---

### FOR EACH EPIC — execute Steps 2–4 sequentially

**Run the block below for each epic in order. Stop on failure; do not start the next epic.**

---

#### Step 2 — Fetch PR diff and build review context

```bash
python "$S/aidlc_tl_review.py" $1 --epic-id <EPIC_ID> --config "$CFG"
```

Writes:
- `.aidlc/$1/epics/<EPIC_ID>/tl-review.json` — diff text + PR metadata per PR
- `.aidlc/$1/epics/<EPIC_ID>/TL_REVIEW.md` — combined review context (spec + diff) for you to read

**Read `TL_REVIEW.md` immediately.** It contains:
- The epic's dev handover doc (stories, AC, FR deltas, KB IDs, target files)
- The QA context doc (Playwright spec targets, test plan, TC-* cases)
- The full PR diff for each dev and QA PR
- The checklist items from the dev handover doc (Section 8 handover checklist)

---

#### Step 3 — Analyze and write findings

Read the `TL_REVIEW.md` for this epic and produce a structured review.

**Review criteria — check each in order:**

**For dev PRs:**
1. **Spec compliance** — does the diff implement the To-be change from each FR delta? Compare the
   `As-is` → `To-be` in the handover doc against what the diff actually changes.
2. **KB ID citations** — are the required `// [CMP-xxx]` / `// [FR-xxx]` inline comments present
   in the changed files? Each story should have KB card comments.
3. **AC coverage** — do the changed files plausibly cover the Gherkin `Given/When/Then` AC clauses?
   Flag any AC clause with no corresponding code change.
4. **No fabrication** — are there `// AIDLC-TODO` items left in the diff? Flag them as
   `CHANGES_REQUESTED` blockers.
5. **Build-check evidence** — did the skill output show passing `ng build` / `mvn test`? If not, note it.
6. **Checklist items** — work through Section 8 of the handover doc. Any unchecked items that can
   be verified from the diff (unit tests, REGO stubs, integration wiring) should be called out.

**For QA PRs:**
1. **Gherkin coverage** — does each changed Playwright spec cover at least one happy-path and one
   negative test per AC clause?
2. **AIDLC-QA header** — is the traceability header block present at the top of each spec file?
3. **AIDLC-TODO completeness** — `AIDLC-TODO` selectors are expected and OK; flag missing AC
   coverage or specs without any test body.
4. **Spec vs. changed files** — do the Playwright specs target the files listed in `files_changed`
   from the epic dev/trace?

**Write findings to:** `.aidlc/$1/epics/<EPIC_ID>/tl-findings.json`

```json
{
  "epic_id": "<EPIC_ID>",
  "verdict": "APPROVED" | "CHANGES_REQUESTED",
  "summary": "One paragraph: what was reviewed, what passed, what was flagged.",
  "dev_pr_verdict": "APPROVED" | "CHANGES_REQUESTED" | "SKIP",
  "qa_pr_verdict": "APPROVED" | "CHANGES_REQUESTED" | "SKIP",
  "findings": [
    {
      "pr_type": "dev" | "qa",
      "severity": "blocker" | "warning" | "info",
      "criterion": "Spec compliance | KB ID citations | AC coverage | ...",
      "file": "relative/file/path or null",
      "line": 42,
      "body": "Finding text with specific reference to the spec. Cite the FR ID or KB ID."
    }
  ]
}
```

Rules:
- `verdict` = `APPROVED` only if `dev_pr_verdict` AND `qa_pr_verdict` are both `APPROVED` or `SKIP`.
- `severity=blocker` → must be `CHANGES_REQUESTED`.
- `severity=warning` → leave as `APPROVED` but include in body so developer sees it.
- `severity=info` → factual observations, always OK with `APPROVED`.
- If a PR is missing (no PR URL in the bundle), set that verdict to `SKIP` and explain in `summary`.

---

#### Step 4 — Post the GitHub PR review and merge

```bash
python "$S/aidlc_tl_approve.py" $1 \
  --epic-id <EPIC_ID> \
  --findings-file ".aidlc/$1/epics/<EPIC_ID>/tl-findings.json" \
  --config "$CFG"
```

This posts one GitHub PR review per dev PR and one per QA PR for this epic, then merges approved PRs:
- **APPROVED PRs**: posts `event=APPROVE` as the authenticated Okta user, then immediately merges the PR
  via `PUT /repos/{repo}/pulls/{pr}/merge` using the method in `tech_lead.merge_method` (default: `squash`).
  If the PR is still in draft state, `aidlc_tl_approve.py` automatically converts it to ready-for-review
  via the GraphQL `markPullRequestReadyForReview` mutation before attempting the merge — no manual intervention needed.
- **CHANGES_REQUESTED**: posts `event=REQUEST_CHANGES` — PR is blocked; developer must push new commits. No merge.
- Review body = `summary` + formatted findings table + reviewer identity (decoded from Okta token).
- Merge failure is non-fatal — the review is already posted; log the error and continue.
- Add `--no-merge` to post the review without merging.
- Writes `.aidlc/$1/epics/<EPIC_ID>/tl-approve-result.json` with review ID, URL, reviewer, and merge SHA per PR.

**Identity:** The GitHub review and merge are performed with the token in `config.git.github_token_env`.
That token must be the user's own personal GitHub PAT (linked to their Okta/SAML identity via GitHub
Enterprise SSO), not a shared service account — GitHub attributes the review and merge to the token owner.

If the review post fails (HTTP error), STOP and report. Do not continue to the next epic.

---

#### Step 4.5 — Sync review and merge status to central

```bash
python "$S/aidlc_tl_sync_review.py" $1 \
  --epic-id <EPIC_ID> \
  --config "$CFG"
```

Records the code review summary and merge status for this epic back to central:
- `POST /ws/$1/epics/<EPIC_ID>/review` → `{ "code_review": "[VERDICT] <summary>" }`
- `PATCH /ws/$1/epics/<EPIC_ID>/review` → `{ "merge_pr": true|false }`

This makes the review and merge state visible in the UI `/review` page.

---

### END FOR EACH EPIC

After all epics, continue to Step 5.

---

### Step 5 — Final summary

Print a per-epic results table, then proceed to Step 6 (KB refresh if all APPROVED, blocked message if any CHANGES_REQUESTED).

```
[PASS] aidlc-tech-lead complete for workspace $1

Epic results:
┌─────────────────────────┬──────────────────────────────┬────────────────────┬──────────────────────┬────────────┐
│ Epic ID                 │ Title                        │ Dev PR             │ QA PR                │ Verdict    │
├─────────────────────────┼──────────────────────────────┼────────────────────┼──────────────────────┼────────────┤
│ epic-abc123456789       │ Payment method enhancement   │ [PASS] APPROVED         │ [PASS] APPROVED           │ [PASS] APPROVED │
│ epic-def012345678       │ Receipt email notification   │ [WARN] CHANGES_REQUESTED│ [PASS] APPROVED           │ [FAIL] BLOCKED  │
└─────────────────────────┴──────────────────────────────┴────────────────────┴──────────────────────┴────────────┘

Blockers:
  epic-def012345678: [FR-042] To-be change for receipt email trigger not found in diff (PaymentService.java)
  epic-def012345678: Missing // [FR-042] KB citation in ReceiptController.java

Next steps:
  - Developer resolves CHANGES_REQUESTED items and pushes new commits
  - Re-run /aidlc-tech-lead $1 review to re-review updated PRs
  - Once all blockers resolved: re-run /aidlc-tech-lead $1 to re-review updated PRs
```

---

### Step 6 — KB Refresh (conditional on all-APPROVED)

**Only run this step if every epic in the results table is `APPROVED`.  
If any epic is `BLOCKED` (CHANGES_REQUESTED), skip Step 6 — the developer must resolve blockers first.**

**When all epics APPROVED → tell the user:**

> "All PRs have been reviewed and merged. To merge the delivered work into the Knowledge Base, run the KB indexer via one of these Claude Code skills:
>
> **Option A — aidlc-merge (full KB pipeline):**
> ```
> /aidlc-merge <workspace_id>
> ```
> Runs `aidlc_merge_kb_refresh.py` which invokes `python -m app.cli pipeline --kb-dir <dir>` (the KB indexer), creates a new STAGING version, generates a changelog, and syncs to central.
>
> **Option B — KB engine refresh only:**
> ```
> /kb-agent-engine:kb-refresh
> ```
> Runs the KB indexer (`stage8.py → python -m app.cli pipeline`) directly to create a new STAGING version.
>
> Both options run the indexer and create a STAGING KB version awaiting SME promotion. See the workspace `/merge` page for details."

**When any epic is BLOCKED → tell the user:**

> "[WARN] KB refresh is blocked — the following epic(s) have unresolved CHANGES_REQUESTED items:
>
> `<list of blocked epic IDs with their blocker descriptions>`
>
> Once the developer pushes new commits addressing the findings, re-run:
> ```
> /aidlc-tech-lead:aidlc-tech-lead $1
> ```
> The KB indexer will not run until all epics are APPROVED."

Do **not** run the KB indexer yourself — it requires local access to the KB indexer repo and Postgres. Instruct the user to run the appropriate skill.

---

## Notes

- **Config is the source of truth.** Every URL, credential, and token comes from `aidlc.config.json`.
  Never print the GitHub PAT.
- **`git.pr_defaults.auto-approve: true`** — script warns and prompts `y/N` before posting any
  APPROVE review or merge. Dry-run skips the prompt. Default is `false` (safe).
- **Epic-scoped review.** Each epic → one dev PR review + one QA PR review.
  A workspace without epics (no `--list-epics` result) uses the workspace-level PR metadata.
- **Re-reviews are safe.** Running again after a developer pushes new commits posts a new review;
  existing reviews are not deleted.
- **aidlc-merge prerequisite.** `aidlc-merge` requires all PRs to have at least one `APPROVED` review
  (when `merge.require_reviews=true`). This plugin is the canonical way to satisfy that requirement.

## References (in-plugin)

| Script | Purpose |
|---|---|
| `scripts/aidlc_tl_bundle.py` | Fetch workspace epics + collect local doc paths + PR metadata |
| `scripts/aidlc_tl_review.py` | Fetch PR diff from GitHub + write TL_REVIEW.md per epic |
| `scripts/aidlc_tl_approve.py` | Post GitHub PR review from tl-findings.json |
| `scripts/aidlc_tl_sync_review.py` | POST code review + PATCH merge status to central |
| `scripts/aidlc_auth.py` | Shared auth (copied from `_shared/`) |
| `config/aidlc.config.example.json` | Full config template |

Design: symmetric to `aidlc-merge` review step, but focused on spec compliance, not merge execution.
