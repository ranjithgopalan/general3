"""Tech Lead sync — records code review and merge status back to central.

Reads tl-findings.json and tl-approve-result.json for an epic, then calls:
  POST  /ws/{workspace_id}/epics/{epic_id}/review  { "code_review": "<summary>" }
  PATCH /ws/{workspace_id}/epics/{epic_id}/review  { "merge_pr": true|false }

Run after aidlc_tl_approve.py (Step 4) for each epic.

Usage:
  python aidlc_tl_sync_review.py <workspace_id>
      --epic-id <EPIC_ID>
      [--findings-file PATH]    # default: .aidlc/<ws>/epics/<epic_id>/tl-findings.json
      [--approve-result PATH]   # default: .aidlc/<ws>/epics/<epic_id>/tl-approve-result.json
      [--config PATH]
      [--dry-run]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import aidlc_auth

_PLUGIN = "aidlc-tech-lead"


def _workspace_dir(cfg: dict[str, Any], workspace_id: str) -> Path:
    base = (cfg.get("workspace_dir") or ".aidlc").rstrip("/\\")
    return Path(base) / workspace_id


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Sync TL code review and merge status back to central."
    )
    ap.add_argument("workspace_id")
    ap.add_argument("--epic-id", required=True)
    ap.add_argument("--findings-file", default=None,
                    help="Path to tl-findings.json (default: .aidlc/<ws>/epics/<epic_id>/tl-findings.json)")
    ap.add_argument("--approve-result", default=None,
                    help="Path to tl-approve-result.json (default: .aidlc/<ws>/epics/<epic_id>/tl-approve-result.json)")
    ap.add_argument("--config", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    base = (cfg.get("central_base_url") or "").rstrip("/")
    if not base:
        sys.exit(f"[{_PLUGIN}] config.central_base_url is required")

    ws_dir = _workspace_dir(cfg, args.workspace_id)
    epic_dir = ws_dir / "epics" / args.epic_id

    # Load tl-findings.json (required)
    findings_path = Path(args.findings_file) if args.findings_file else epic_dir / "tl-findings.json"
    if not findings_path.is_file():
        sys.exit(f"[{_PLUGIN}] tl-findings.json not found at {findings_path} — run Step 3 first")
    findings = json.loads(findings_path.read_text(encoding="utf-8"))

    # Load tl-approve-result.json (optional — absence means PRs not yet merged)
    approve_path = Path(args.approve_result) if args.approve_result else epic_dir / "tl-approve-result.json"
    approve_result: dict[str, Any] = {}
    if approve_path.is_file():
        approve_result = json.loads(approve_path.read_text(encoding="utf-8"))
    else:
        print(f"[{_PLUGIN}] WARNING: tl-approve-result.json not found — merge_pr will be false")

    # merge_pr = true if at least one PR was successfully merged
    results = approve_result.get("results") or []
    merge_pr = any(r.get("merged") for r in results)

    # Build code_review dict: API expects dict[str, Any], not a plain string
    verdict = findings.get("verdict") or "UNKNOWN"
    summary = findings.get("summary") or ""
    code_review: dict[str, Any] = {
        "verdict": verdict,
        "summary": summary,
        "dev_pr_verdict": findings.get("dev_pr_verdict"),
        "qa_pr_verdict": findings.get("qa_pr_verdict"),
        "findings": findings.get("findings") or [],
    }

    review_url = f"{base}/ws/{args.workspace_id}/epics/{args.epic_id}/review"

    # POST: record code review notes
    post_payload: dict[str, Any] = {"code_review": code_review}
    preview = f"verdict={verdict} findings={len(code_review['findings'])}"
    print(f"[{_PLUGIN}] POST {review_url}")
    print(f"  code_review: {preview}")
    if not args.dry_run:
        aidlc_auth.post_json(review_url, cfg, post_payload)
        print(f"[{_PLUGIN}] [PASS] Code review recorded for epic {args.epic_id}")
    else:
        print(f"[{_PLUGIN}] [dry-run] Would POST code_review")

    # PATCH: record merge status
    patch_payload: dict[str, Any] = {"merge_pr": merge_pr}
    print(f"[{_PLUGIN}] PATCH {review_url}")
    print(f"  merge_pr: {merge_pr}")
    if not args.dry_run:
        aidlc_auth.patch_json(review_url, cfg, patch_payload)
        print(f"[{_PLUGIN}] [PASS] Merge status recorded: merge_pr={merge_pr}")
    else:
        print(f"[{_PLUGIN}] [dry-run] Would PATCH merge_pr={merge_pr}")

    # POST: record review-epic trace artifact (for trace graph visibility)
    review_trace_url = f"{base}/ws/{args.workspace_id}/epics/{args.epic_id}/review/trace"
    # Extract PR URLs from approve_result
    dev_pr_url = None
    qa_pr_url = None
    for r in results:
        if r.get("pr_type") == "dev" and r.get("pr_url"):
            dev_pr_url = r["pr_url"]
        elif r.get("pr_type") == "qa" and r.get("pr_url"):
            qa_pr_url = r["pr_url"]

    review_trace_payload: dict[str, Any] = {
        "verdict": verdict,
        "summary": summary,
        "dev_pr_verdict": findings.get("dev_pr_verdict"),
        "qa_pr_verdict": findings.get("qa_pr_verdict"),
        "findings": findings.get("findings") or [],
        "dev_pr_url": dev_pr_url,
        "qa_pr_url": qa_pr_url,
        "story_ids": findings.get("story_ids") or [],
        "actor": approve_result.get("reviewer") or None,
    }
    print(f"[{_PLUGIN}] POST {review_trace_url}")
    print(f"  review trace: verdict={verdict} findings={len(review_trace_payload['findings'])}")
    if not args.dry_run:
        try:
            aidlc_auth.post_json(review_trace_url, cfg, review_trace_payload)
            print(f"[{_PLUGIN}] [PASS] Review trace artifact written for epic {args.epic_id}")
        except Exception as exc:
            print(f"[{_PLUGIN}] WARNING: review trace write failed (non-fatal): {exc}")
    else:
        print(f"[{_PLUGIN}] [dry-run] Would POST review trace artifact")

    print(
        f"[{_PLUGIN}] Synced epic {args.epic_id}: verdict={verdict} merge_pr={merge_pr}"
    )


if __name__ == "__main__":
    main()
