"""Tech Lead PR approver — Step 4 of the Tech Lead reviewer (aidlc-tech-lead plugin).

Reads ``tl-findings.json`` (written by Claude after reviewing TL_REVIEW.md) and posts a
GitHub PR review (APPROVED or REQUEST_CHANGES) for each dev and QA PR in the epic.

Outputs written to ``.aidlc/<workspace_id>/epics/<epic_id>/``:
  tl-approve-result.json  — per-PR review outcome (review_id, review_url, verdict)

Usage:
  python aidlc_tl_approve.py <workspace_id>
      --epic-id <EPIC_ID>
      --findings-file <path/to/tl-findings.json>
      [--pr-type dev|qa|both]   # which PRs to post to (default: both)
      [--config PATH]
      [--dry-run]
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

import aidlc_auth

_PLUGIN = "aidlc-tech-lead"
_RESULT_FILE = "tl-approve-result.json"
_BUNDLE_FILE = "tl-bundle.json"

# ponytail: GitHub event names differ from our internal verdict names
_VERDICT_TO_EVENT = {
    "APPROVED": "APPROVE",
    "CHANGES_REQUESTED": "REQUEST_CHANGES",
    "SKIP": None,  # don't post
}


# ── Config helpers ────────────────────────────────────────────────────────────

def _workspace_dir(cfg: dict[str, Any], workspace_id: str) -> Path:
    base = (cfg.get("workspace_dir") or ".aidlc").rstrip("/\\")
    return Path(base) / workspace_id


def _git_cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return cfg.get("git") or {}


def _github_token(cfg: dict[str, Any]) -> str:
    raw = _git_cfg(cfg).get("github_token_env") or ""
    if not raw:
        sys.exit(
            f"[{_PLUGIN}] config.git.github_token_env is not set — add it to aidlc.config.json"
        )
    if any(raw.startswith(pfx) for pfx in ("github_pat_", "ghp_", "gho_", "ghs_", "ghu_")):
        return raw
    token = os.environ.get(raw, "")
    if not token:
        sys.exit(f"[{_PLUGIN}] GitHub token env var '{raw}' is not set — export {raw}=<PAT>")
    return token


def _github_headers(token: str) -> dict[str, str]:
    return {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "Content-Type": "application/json",
    }


# ── GitHub API helpers ────────────────────────────────────────────────────────

def _parse_repo_and_number(pr_meta: dict[str, Any]) -> tuple[str, int] | None:
    pr_number = pr_meta.get("pr_number") or pr_meta.get("number")
    repo = pr_meta.get("repo") or pr_meta.get("repository") or ""
    pr_url = pr_meta.get("pr_url") or pr_meta.get("remote_url") or ""

    if not pr_number and pr_url:
        parts = pr_url.rstrip("/").split("/")
        if len(parts) >= 2 and parts[-2] == "pull" and parts[-1].isdigit():
            pr_number = int(parts[-1])

    # A bare repo name (no owner) is incomplete for the GitHub API — the central trace stores
    # repo without an owner, so derive owner/repo from the PR URL when it lacks a "/".
    if (not repo or "/" not in repo) and pr_url:
        parts = pr_url.replace("https://", "").replace("http://", "").split("/")
        if len(parts) >= 3:
            repo = f"{parts[1]}/{parts[2]}"

    if not repo or not pr_number:
        return None
    return repo, int(pr_number)


def _post_review(
    github_base: str,
    repo: str,
    pr_number: int,
    event: str,
    body: str,
    comments: list[dict[str, Any]],
    gh_headers: dict[str, str],
    dry_run: bool,
) -> dict[str, Any]:
    """Post a GitHub PR review. Returns the review record or a dry-run stub."""
    url = f"{github_base}/repos/{repo}/pulls/{pr_number}/reviews"

    payload: dict[str, Any] = {
        "event": event,   # "APPROVE" | "REQUEST_CHANGES" | "COMMENT"
        "body": body,
    }

    # Inline comments: GitHub requires `path` and either `position` (diff) or `line` (file).
    # We use `line` (requires side="RIGHT" for added lines). Only include comments with a line.
    inline: list[dict[str, Any]] = []
    for c in (comments or []):
        if c.get("path") and c.get("line"):
            inline.append({
                "path": c["path"],
                "line": c["line"],
                "side": "RIGHT",
                "body": c["body"],
            })
        # Comments without line are folded into the review body instead.

    if inline:
        payload["comments"] = inline

    payload_bytes = json.dumps(payload).encode("utf-8")

    if dry_run:
        print(
            f"  [dry-run] Would POST {url}: event={event} "
            f"body_len={len(body)} inline_comments={len(inline)}"
        )
        return {"dry_run": True, "event": event, "url": url}

    req = urllib.request.Request(url, data=payload_bytes, headers=gh_headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result
    except urllib.error.HTTPError as exc:
        err = exc.read().decode("utf-8", "replace")[:400]
        raise RuntimeError(
            f"POST {url} failed HTTP {exc.code}: {err}"
        ) from exc


def _build_review_body(findings: dict[str, Any], pr_type: str, reviewer: str = "") -> str:
    """Render the review body from tl-findings.json for one PR type (dev or qa)."""
    summary = findings.get("summary") or ""
    all_findings = [
        f for f in (findings.get("findings") or [])
        if f.get("pr_type") == pr_type
    ]

    lines = [
        "## AIDLC Tech Lead Review",
        "",
        summary,
        "",
    ]

    if all_findings:
        lines += [
            "### Findings",
            "",
            "| Severity | Criterion | File | Body |",
            "|---|---|---|---|",
        ]
        for f in all_findings:
            sev = f.get("severity") or "info"
            icon = {"blocker": "[red]", "warning": "[WARN]", "info": "ℹ"}.get(sev, "ℹ")
            criterion = f.get("criterion") or "—"
            file_ = f"`{f['file']}`" if f.get("file") else "—"
            body = (f.get("body") or "").replace("|", "\\|")
            lines.append(f"| {icon} `{sev}` | {criterion} | {file_} | {body} |")

        lines.append("")

    by_line = f" by {reviewer}" if reviewer else ""
    lines += [
        f"_Reviewed{by_line} via [AIDLC Tech Lead plugin](https://github.aig.net) — "
        "every finding is grounded in the dev handover doc or QA context doc._",
    ]
    return "\n".join(lines)


def _comments_for_pr_type(findings: dict[str, Any], pr_type: str) -> list[dict[str, Any]]:
    """Extract inline comment candidates (only those with file + line)."""
    return [
        f for f in (findings.get("findings") or [])
        if f.get("pr_type") == pr_type and f.get("file") and f.get("line")
    ]


def _graphql_url(github_base: str) -> str:
    """Derive the GraphQL endpoint from the REST base (GHE: /api/v3 → /api/graphql)."""
    if github_base.endswith("/api/v3"):
        return github_base[: -len("/api/v3")] + "/api/graphql"
    if "api.github.com" in github_base:
        return "https://api.github.com/graphql"
    return github_base.rstrip("/") + "/graphql"


def _get_pr(github_base: str, repo: str, pr_number: int, gh_headers: dict[str, str]) -> dict[str, Any]:
    """Fetch a PR (for its draft flag + node_id) via GET /repos/{repo}/pulls/{pr}."""
    url = f"{github_base}/repos/{repo}/pulls/{pr_number}"
    req = urllib.request.Request(url, headers=gh_headers, method="GET")
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _mark_ready_for_review(
    graphql_url: str, node_id: str, gh_headers: dict[str, str], dry_run: bool
) -> None:
    """Flip a draft PR to ready-for-review via the markPullRequestReadyForReview GraphQL
    mutation. There is no REST endpoint for this, and a draft PR cannot be merged."""
    if dry_run:
        print(f"  [dry-run] Would mark PR ready-for-review (node={node_id})")
        return
    query = (
        "mutation($id:ID!){markPullRequestReadyForReview(input:{pullRequestId:$id})"
        "{pullRequest{number isDraft}}}"
    )
    payload = json.dumps({"query": query, "variables": {"id": node_id}}).encode("utf-8")
    # GraphQL wants `bearer` auth (REST uses `token`); reuse the same PAT.
    gql_headers = dict(gh_headers)
    gql_headers["Authorization"] = gh_headers.get("Authorization", "").replace("token ", "bearer ")
    req = urllib.request.Request(graphql_url, data=payload, headers=gql_headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        err = exc.read().decode("utf-8", "replace")[:400]
        raise RuntimeError(f"POST {graphql_url} (markReady) failed HTTP {exc.code}: {err}") from exc
    if result.get("errors"):
        raise RuntimeError(f"markPullRequestReadyForReview failed: {result['errors']}")


def _merge_pr(
    github_base: str,
    repo: str,
    pr_number: int,
    merge_method: str,
    commit_title: str,
    gh_headers: dict[str, str],
    dry_run: bool,
) -> dict[str, Any]:
    """Merge a GitHub PR via PUT /repos/{repo}/pulls/{pr}/merge.

    A draft PR (aidlc-develop/qa raise PRs with pr_defaults.draft=true) cannot be merged, so
    mark it ready-for-review first when needed.
    """
    # Un-draft first: GitHub rejects merges of draft PRs with HTTP 405.
    try:
        pr = _get_pr(github_base, repo, pr_number, gh_headers)
    except (urllib.error.HTTPError, urllib.error.URLError):
        pr = {}
    if pr.get("draft") and pr.get("node_id"):
        print(f"  [note] PR {repo}#{pr_number} is a draft — marking ready-for-review")
        _mark_ready_for_review(_graphql_url(github_base), pr["node_id"], gh_headers, dry_run)
        time.sleep(2)  # allow GitHub to propagate draft→ready state before merge PUT

    url = f"{github_base}/repos/{repo}/pulls/{pr_number}/merge"
    payload = {"merge_method": merge_method, "commit_title": commit_title}
    payload_bytes = json.dumps(payload).encode("utf-8")

    if dry_run:
        print(f"  [dry-run] Would PUT {url}: merge_method={merge_method}")
        return {"dry_run": True, "merged": True}

    req = urllib.request.Request(url, data=payload_bytes, headers=gh_headers, method="PUT")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        err = exc.read().decode("utf-8", "replace")[:400]
        raise RuntimeError(f"PUT {url} failed HTTP {exc.code}: {err}") from exc


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    ap = argparse.ArgumentParser(
        description="Post GitHub PR reviews from tl-findings.json."
    )
    ap.add_argument("workspace_id")
    ap.add_argument("--epic-id", required=True)
    ap.add_argument("--findings-file", required=True,
                    help="Path to tl-findings.json written by Claude")
    ap.add_argument("--pr-type", choices=["dev", "qa", "both"], default="both",
                    help="Which PR types to post reviews for (default: both)")
    ap.add_argument("--no-merge", action="store_true",
                    help="Post review only; do not merge approved PRs")
    ap.add_argument("--config", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    github_base = (
        (_git_cfg(cfg) or {}).get("github_base_url") or "https://github.aig.net/api/v3"
    ).rstrip("/")
    token = _github_token(cfg)
    gh_headers = _github_headers(token)

    # Resolve reviewer identity from the Okta token (informational; display-only)
    okta_token = aidlc_auth.get_token(cfg)
    reviewer = aidlc_auth._decode_sub(okta_token) if okta_token else ""

    tl_cfg = cfg.get("tech_lead") or {}
    merge_method = str(tl_cfg.get("merge_method") or "squash")

    pr_defaults = (_git_cfg(cfg).get("pr_defaults") or {})
    if pr_defaults.get("auto-approve"):
        print(
            f"\n[WARN]  WARNING: config.git.pr_defaults.auto-approve is ON.\n"
            f"   This will post APPROVE reviews and merge ALL PRs for epic {args.epic_id} without per-finding review.\n"
            f"   GitHub PAT: {_git_cfg(cfg).get('github_token_env', '?')}  merge_method: {merge_method}\n"
        )
        if not args.dry_run:
            answer = input("   Proceed? [y/N] ").strip().lower()
            if answer != "y":
                sys.exit("[aidlc-tech-lead] Aborted by user.")

    ws_dir = _workspace_dir(cfg, args.workspace_id)
    epic_dir = ws_dir / "epics" / args.epic_id
    epic_dir.mkdir(parents=True, exist_ok=True)

    # Load findings
    findings_path = Path(args.findings_file)
    if not findings_path.is_file():
        sys.exit(f"[{_PLUGIN}] findings file not found: {findings_path}")
    findings = json.loads(findings_path.read_text(encoding="utf-8"))

    # Load tl-bundle.json for PR metadata
    bundle_path = ws_dir / _BUNDLE_FILE
    if not bundle_path.is_file():
        sys.exit(
            f"[{_PLUGIN}] tl-bundle.json not found at {bundle_path} — run aidlc_tl_bundle.py first"
        )
    bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
    artifact = next(
        (a for a in (bundle.get("artifacts") or []) if a.get("epic_id") == args.epic_id),
        {},
    )

    results: list[dict[str, Any]] = []
    pr_types_to_post = (["dev", "qa"] if args.pr_type == "both" else [args.pr_type])

    for pr_type in pr_types_to_post:
        verdict_key = f"{pr_type}_pr_verdict"
        verdict = findings.get(verdict_key) or "SKIP"
        event = _VERDICT_TO_EVENT.get(verdict)

        if event is None:
            print(f"[{_PLUGIN}]   {pr_type} PR: verdict=SKIP — not posting review")
            results.append({"pr_type": pr_type, "verdict": verdict, "status": "skipped"})
            continue

        # Resolve PR metadata
        meta_key = f"{pr_type}_pr_meta"
        pr_meta_raw = artifact.get(meta_key)
        if not pr_meta_raw:
            print(f"[{_PLUGIN}]   {pr_type} PR: no PR metadata in bundle — skipping")
            results.append({"pr_type": pr_type, "verdict": verdict, "status": "no_metadata"})
            continue

        pr_metas = pr_meta_raw if isinstance(pr_meta_raw, list) else [pr_meta_raw]

        for pr_meta in pr_metas:
            parsed = _parse_repo_and_number(pr_meta)
            if not parsed:
                print(f"[{_PLUGIN}]   {pr_type} PR: cannot parse repo/number — skipping")
                results.append({
                    "pr_type": pr_type, "verdict": verdict, "status": "parse_error",
                    "pr_meta": pr_meta,
                })
                continue

            repo, pr_number = parsed
            print(
                f"[{_PLUGIN}]   Posting {event} review on {pr_type} PR {repo}#{pr_number}"
            )

            body = _build_review_body(findings, pr_type, reviewer=reviewer)
            comments = _comments_for_pr_type(findings, pr_type)

            try:
                result = _post_review(
                    github_base, repo, pr_number, event, body, comments, gh_headers,
                    dry_run=args.dry_run,
                )
                review_id = result.get("id")
                review_url = result.get("html_url") or f"{pr_meta.get('pr_url', '')}#pullrequestreview-{review_id}"
                icon = "[PASS]" if event == "APPROVE" else "[WARN]"
                print(
                    f"  {icon} Posted {event} review on {repo}#{pr_number}: "
                    f"review_id={review_id} url={review_url}"
                )
                entry: dict[str, Any] = {
                    "pr_type": pr_type,
                    "repo": repo,
                    "pr_number": pr_number,
                    "verdict": verdict,
                    "event": event,
                    "review_id": review_id,
                    "review_url": review_url,
                    "reviewer": reviewer,
                    "inline_comments_posted": len(comments),
                    "status": "dry_run" if args.dry_run else "posted",
                }

                # Merge the PR immediately after an APPROVE review
                if event == "APPROVE" and not args.no_merge:
                    merge_title = f"[AIDLC TL] APPROVED epic {args.epic_id} ({pr_type})"
                    if reviewer:
                        merge_title += f" — reviewed by {reviewer}"
                    try:
                        merge_result = _merge_pr(
                            github_base, repo, pr_number, merge_method, merge_title,
                            gh_headers, dry_run=args.dry_run,
                        )
                        entry["merged"] = bool(merge_result.get("merged"))
                        entry["merge_sha"] = merge_result.get("sha")
                        print(
                            f"  [shuffle] Merged {repo}#{pr_number} ({merge_method}) "
                            f"sha={merge_result.get('sha', 'dry-run')}"
                        )
                    except RuntimeError as exc:
                        # Review already posted — merge failure is non-fatal but surfaced
                        print(f"  [WARN] Merge failed (review was posted): {exc}")
                        entry["merged"] = False
                        entry["merge_error"] = str(exc)

                results.append(entry)
            except RuntimeError as exc:
                print(f"  [blocked] FAILED to post review on {repo}#{pr_number}: {exc}")
                sys.exit(f"[{_PLUGIN}] Review post failed — stopping")

    # Write result file
    result_path = epic_dir / _RESULT_FILE
    result_path.write_text(
        json.dumps({"epic_id": args.epic_id, "results": results}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"[{_PLUGIN}] Wrote {result_path}")

    # Final summary
    approved = sum(1 for r in results if r.get("event") == "APPROVE" and r.get("status") == "posted")
    changes = sum(1 for r in results if r.get("event") == "REQUEST_CHANGES" and r.get("status") == "posted")
    skipped = sum(1 for r in results if r.get("status") in ("skipped", "no_metadata"))

    print(
        f"[{_PLUGIN}] Epic {args.epic_id}: "
        f"APPROVED={approved} CHANGES_REQUESTED={changes} SKIPPED={skipped}"
    )


if __name__ == "__main__":
    main()
