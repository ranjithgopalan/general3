"""Tech Lead PR diff fetcher — Step 2 of the Tech Lead reviewer (aidlc-tech-lead plugin).

For one epic: reads the local tl-bundle.json, fetches the PR diff from the GitHub Enterprise
API, reads the dev handover doc and QA context doc, and renders a TL_REVIEW.md that contains
everything the Tech Lead (Claude) needs to write a grounded review.

Outputs written to ``.aidlc/<workspace_id>/epics/<epic_id>/``:
  tl-review.json  — machine-readable: diff text + PR metadata per PR in this epic
  TL_REVIEW.md    — combined review context: spec docs + diffs, ready for Claude to read

Usage:
  python aidlc_tl_review.py <workspace_id> --epic-id <EPIC_ID> [--config PATH] [--dry-run]
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

import aidlc_auth

_PLUGIN = "aidlc-tech-lead"
_BUNDLE_FILE = "tl-bundle.json"
_REVIEW_FILE = "tl-review.json"
_REVIEW_MD = "TL_REVIEW.md"


# ── Config helpers ────────────────────────────────────────────────────────────

def _workspace_dir(cfg: dict[str, Any], workspace_id: str) -> Path:
    base = (cfg.get("workspace_dir") or ".aidlc").rstrip("/\\")
    return Path(base) / workspace_id


def _git_cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    return cfg.get("git") or {}


def _github_token(cfg: dict[str, Any]) -> str:
    raw = _git_cfg(cfg).get("github_token_env") or ""
    if not raw:
        sys.exit(
            f"[{_PLUGIN}] config.git.github_token_env is not set — add it to aidlc.config.json"
        )
    if any(raw.startswith(pfx) for pfx in ("github_pat_", "ghp_", "gho_", "ghs_", "ghu_")):
        return raw
    token = os.environ.get(raw, "")
    if not token:
        sys.exit(f"[{_PLUGIN}] GitHub token env var '{raw}' is not set — export {raw}=<PAT>")
    return token


def _github_headers(token: str) -> dict[str, str]:
    return {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
    }


def _diff_headers(token: str) -> dict[str, str]:
    return {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3.diff",
    }


# ── GitHub API helpers ────────────────────────────────────────────────────────

def _gh_get(url: str, headers: dict[str, str], timeout: float = 60.0) -> str:
    """GET from GitHub; return raw response body as text (works for both JSON and diff)."""
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")[:300]
        print(f"[{_PLUGIN}] WARNING: GET {url} -> HTTP {exc.code}: {body}")
        return ""
    except urllib.error.URLError as exc:
        print(f"[{_PLUGIN}] WARNING: GET {url} failed: {exc.reason}")
        return ""


def _parse_repo_and_number(pr_meta: dict[str, Any]) -> tuple[str, int] | None:
    pr_number = pr_meta.get("pr_number") or pr_meta.get("number")
    repo = pr_meta.get("repo") or pr_meta.get("repository") or ""
    pr_url = pr_meta.get("pr_url") or pr_meta.get("remote_url") or ""

    if not pr_number and pr_url:
        parts = pr_url.rstrip("/").split("/")
        if len(parts) >= 2 and parts[-2] == "pull" and parts[-1].isdigit():
            pr_number = int(parts[-1])

    # A bare repo name (no owner) is incomplete for the GitHub API — the central trace stores
    # repo without an owner, so derive owner/repo from the PR URL when it lacks a "/".
    if (not repo or "/" not in repo) and pr_url:
        parts = pr_url.replace("https://", "").replace("http://", "").split("/")
        if len(parts) >= 3:
            repo = f"{parts[1]}/{parts[2]}"

    if not repo or not pr_number:
        return None
    return repo, int(pr_number)


def _fetch_pr_diff(
    pr_meta: dict[str, Any],
    github_base: str,
    json_headers: dict[str, str],
    diff_headers_val: dict[str, str],
) -> dict[str, Any]:
    """Fetch PR metadata + full diff for one PR."""
    parsed = _parse_repo_and_number(pr_meta)
    if not parsed:
        return {
            "pr_meta": pr_meta,
            "repo": None,
            "pr_number": None,
            "pr_title": None,
            "diff": "",
            "error": "Cannot determine repo or PR number from metadata",
        }

    repo, pr_number = parsed
    pr_url = f"{github_base}/repos/{repo}/pulls/{pr_number}"

    # Fetch PR title/body for context
    pr_detail_raw = _gh_get(pr_url, json_headers)
    try:
        pr_detail = json.loads(pr_detail_raw) if pr_detail_raw else {}
    except json.JSONDecodeError:
        pr_detail = {}

    pr_title = pr_detail.get("title") or ""
    pr_body = pr_detail.get("body") or ""
    head_sha = (pr_detail.get("head") or {}).get("sha") or ""
    base_branch = (pr_detail.get("base") or {}).get("ref") or ""
    changed_files = pr_detail.get("changed_files") or 0
    additions = pr_detail.get("additions") or 0
    deletions = pr_detail.get("deletions") or 0

    # Fetch the diff (Accept: application/vnd.github.v3.diff)
    diff_text = _gh_get(pr_url, diff_headers_val)

    # Truncate very large diffs (keep first 50k chars — ample for most PRs)
    if len(diff_text) > 50_000:
        diff_text = diff_text[:50_000] + "\n\n... [diff truncated at 50k chars] ..."

    return {
        "pr_meta": pr_meta,
        "repo": repo,
        "pr_number": pr_number,
        "pr_title": pr_title,
        "pr_body": pr_body,
        "head_sha": head_sha,
        "base_branch": base_branch,
        "changed_files": changed_files,
        "additions": additions,
        "deletions": deletions,
        "diff": diff_text,
        "error": None,
    }


# ── Central grounded-spec context (fallback when local handover doc is absent) ──

def _fetch_grounded_spec(
    base: str, workspace_id: str, epic_id: str, cfg: dict[str, Any], timeout: float
) -> str:
    """Render the epic's grounded spec (user stories + AC + FR deltas) from central.

    Used as the Section 1 spec when the local dev-handover markdown is absent — the handover
    doc is written only inside the aidlc-develop plugin's own working dir and is never pushed,
    so central is the cross-plugin source of the grounded requirement.
    """
    lines: list[str] = []

    # Stories from epic detail — the epic-scoped bundle's stories artifact is often empty.
    try:
        epic = aidlc_auth.get_json(f"{base}/ws/{workspace_id}/epics/{epic_id}", cfg, timeout)
    except Exception:
        epic = {}
    stories = [s for f in (epic.get("features") or []) for s in (f.get("stories") or [])]
    if stories:
        lines.append("#### User Stories & Acceptance Criteria (from central)\n")
        for s in stories:
            lines.append(f"**`{s.get('id', '?')}` — {s.get('title', '')}**\n")
            desc = (s.get("description") or "").strip()
            if desc:
                lines.append(f"> {desc}\n")
            ac = {a.get("id"): a.get("criterion", "") for a in (s.get("acceptance_criteria") or [])}
            if any(ac.values()):
                lines.append("```gherkin")
                lines.append(f"Given {ac.get('ac-given', '—')}")
                lines.append(f"When  {ac.get('ac-when', '—')}")
                lines.append(f"Then  {ac.get('ac-then', '—')}")
                lines.append("```")
            kb = s.get("kb_trace_ids") or []
            if kb:
                lines.append(f"_KB: {' '.join('`' + k + '`' for k in kb)}_\n")

    # FR deltas (as-is → to-be) from the epic bundle's FSD document.
    try:
        bundle = aidlc_auth.get_json(f"{base}/ws/{workspace_id}/epics/{epic_id}/bundle", cfg, timeout)
    except Exception:
        bundle = {}
    fsd = next(
        (a.get("document") or {} for a in (bundle.get("artifacts") or []) if a.get("kind") == "fsd"),
        {},
    )
    frs = fsd.get("functional_requirements") or []
    if frs:
        lines.append("\n#### Functional Requirement Deltas (as-is → to-be)\n")
        for fr in frs:
            lines.append(f"- **`{fr.get('id', '?')}` {fr.get('title', '')}**")
            if fr.get("as_is"):
                lines.append(f"  - As-is: {str(fr['as_is'])[:300]}")
            if fr.get("to_be"):
                lines.append(f"  - To-be: {str(fr['to_be'])[:300]}")

    return "\n".join(lines)


def _render_dev_trace(trace: dict[str, Any]) -> str:
    """Render the developer work trace (branch / PR / files_changed / KB cited) from central."""
    lines = ["#### Developer Work Trace (from central)\n"]
    lines.append(
        f"- **Branch:** `{trace.get('branch', '?')}`  "
        f"**PR:** {trace.get('pr_url', '?')}  "
        f"**Commit:** `{(trace.get('commit_sha') or '')[:10]}`"
    )
    lines.append(f"- **Actor:** {trace.get('actor') or trace.get('created_by') or '?'}")
    files = trace.get("files_changed") or []
    if files:
        lines.append(f"- **Files changed ({len(files)}):**")
        lines += [f"  - `{fp}`" for fp in files]
    kb = trace.get("kb_ids_cited") or []
    if kb:
        lines.append(f"- **KB cited:** {' '.join('`' + k + '`' for k in kb)}")
    story_ids = trace.get("story_ids") or []
    if story_ids:
        lines.append(f"- **Stories:** {', '.join(story_ids)}")
    return "\n".join(lines)


def _render_qa_trace(trace: dict[str, Any]) -> str:
    """Render the QA test trace (branch / PR / test files / spec mapping) from central."""
    lines = ["#### QA Test Trace (from central)\n"]
    lines.append(f"- **Branch:** `{trace.get('branch', '?')}`  **PR:** {trace.get('pr_url', '?')}")
    test_files = trace.get("test_files") or []
    if test_files:
        lines.append(f"- **Test files ({len(test_files)}):**")
        lines += [f"  - `{t}`" for t in test_files]
    pw = trace.get("playwright_trace") or []
    if pw:
        lines.append("- **DEV_FILE → PLAYWRIGHT_SPEC mapping:**")
        lines += [f"  - `{e.get('dev_file', '?')}` → `{e.get('playwright_spec', '?')}`" for e in pw]
    kb = trace.get("kb_ids") or []
    if kb:
        lines.append(f"- **KB cited:** {' '.join('`' + k + '`' for k in kb)}")
    return "\n".join(lines)


# ── Markdown renderers ────────────────────────────────────────────────────────

def _render_review_md(
    workspace_id: str,
    epic_id: str,
    epic_title: str,
    dev_handover_text: str,
    qa_context_text: str,
    pr_reviews: list[dict[str, Any]],
) -> str:
    lines = [
        f"# Tech Lead Review Context — epic `{epic_id}`",
        f"**Workspace:** `{workspace_id}`  **Epic:** {epic_title}",
        "",
        "> **Instructions for Claude (Tech Lead):**",
        "> Read Sections 1 and 2 for the grounded spec, then read Section 3 for the diffs.",
        "> Write `tl-findings.json` based on the review criteria in the SKILL.md.",
        "",
        "---",
        "",
        "## Section 1 — Dev Handover Document",
        "",
    ]

    if dev_handover_text:
        lines.append(dev_handover_text)
    else:
        lines.append("> [WARN] **Dev handover document not found** — run `aidlc-develop` first.")

    lines += [
        "",
        "---",
        "",
        "## Section 2 — QA Context Document",
        "",
    ]

    if qa_context_text:
        lines.append(qa_context_text)
    else:
        lines.append("> [WARN] **QA context document not found** — run `aidlc-qa` first.")

    lines += [
        "",
        "---",
        "",
        "## Section 3 — PR Diffs",
        "",
    ]

    for r in pr_reviews:
        pr_type = r.get("pr_type") or "?"
        repo = r.get("repo") or "?"
        pr_number = r.get("pr_number") or "?"
        pr_title = r.get("pr_title") or ""
        diff = r.get("diff") or ""
        error = r.get("error")

        lines.append(f"### {pr_type.upper()} PR — `{repo}#{pr_number}` — {pr_title}")
        lines.append("")

        if error:
            lines.append(f"> [WARN] Error fetching diff: {error}")
        elif not diff:
            lines.append("> [WARN] Diff is empty or could not be fetched.")
        else:
            changed_files = r.get("changed_files") or 0
            additions = r.get("additions") or 0
            deletions = r.get("deletions") or 0
            lines.append(
                f"**Stats:** {changed_files} files changed  +{additions} / -{deletions}"
            )
            lines.append("")
            lines.append("```diff")
            lines.append(diff)
            lines.append("```")

        lines.append("")

    lines += [
        "---",
        "",
        "## Section 4 — Review Instructions",
        "",
        "Write `.aidlc/{workspace_id}/epics/{epic_id}/tl-findings.json` following the schema",
        "in the SKILL.md. Key points:",
        "- Cite FR IDs, KB IDs, or AC clauses for every finding.",
        "- `blocker` severity → `CHANGES_REQUESTED`.",
        "- `warning` or `info` severity → `APPROVED` (still include in findings).",
        "- If a PR is missing/unfetchable → `SKIP` for that verdict.",
        "",
    ]

    return "\n".join(lines)


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    ap = argparse.ArgumentParser(
        description="Fetch PR diff and build TL_REVIEW.md for one epic."
    )
    ap.add_argument("workspace_id")
    ap.add_argument("--epic-id", required=True)
    ap.add_argument("--config", default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    ws_dir = _workspace_dir(cfg, args.workspace_id)
    epic_dir = ws_dir / "epics" / args.epic_id
    epic_dir.mkdir(parents=True, exist_ok=True)

    github_base = (_git_cfg(cfg).get("github_base_url") or "https://github.aig.net/api/v3").rstrip("/")
    token = _github_token(cfg)
    j_headers = _github_headers(token)
    d_headers = _diff_headers(token)

    # Load tl-bundle.json to get PR metadata and doc paths
    bundle_path = ws_dir / _BUNDLE_FILE
    if not bundle_path.is_file():
        sys.exit(
            f"[{_PLUGIN}] tl-bundle.json not found at {bundle_path} — run aidlc_tl_bundle.py first"
        )
    bundle = json.loads(bundle_path.read_text(encoding="utf-8"))

    # Find this epic's artifact record
    artifact = next(
        (a for a in (bundle.get("artifacts") or []) if a.get("epic_id") == args.epic_id),
        None,
    )
    if artifact is None:
        sys.exit(
            f"[{_PLUGIN}] Epic {args.epic_id} not found in tl-bundle.json — "
            "re-run aidlc_tl_bundle.py or pass --epic-ids to include it"
        )

    # Resolve epic title
    epic_title = next(
        (str(ep.get("title") or "") for ep in (bundle.get("epics") or [])
         if str(ep.get("id") or ep.get("epic_id") or "") == args.epic_id),
        args.epic_id,
    )

    base = (cfg.get("central_base_url") or "").rstrip("/")
    timeout = float(cfg.get("request_timeout") or 120)

    # Section 1 (dev spec): local handover doc if present, else the grounded spec from central
    # (stories + AC + FR deltas). Always append the developer work trace from central.
    dev_handover_path = artifact.get("dev_handover_path")
    dev_parts: list[str] = []
    if dev_handover_path:
        dev_parts.append(Path(dev_handover_path).read_text(encoding="utf-8"))
    elif base:
        dev_parts.append(_fetch_grounded_spec(base, args.workspace_id, args.epic_id, cfg, timeout))
    dev_trace = artifact.get("dev_trace")
    if dev_trace:
        dev_parts.append(_render_dev_trace(dev_trace))
    dev_handover_text = "\n\n".join(p for p in dev_parts if p)

    # Section 2 (QA context): local QA_CONTEXT doc if present, plus the QA trace from central.
    qa_context_path = artifact.get("qa_context_path")
    qa_parts: list[str] = []
    if qa_context_path:
        qa_parts.append(Path(qa_context_path).read_text(encoding="utf-8"))
    qa_trace = artifact.get("qa_trace")
    if qa_trace:
        qa_parts.append(_render_qa_trace(qa_trace))
    qa_context_text = "\n\n".join(p for p in qa_parts if p)

    # Fetch diffs for dev and QA PRs
    pr_reviews: list[dict[str, Any]] = []

    dev_pr_meta = artifact.get("dev_pr_meta")
    if dev_pr_meta:
        # dev_pr_meta may be a dict or list (one per repo)
        dev_prs = dev_pr_meta if isinstance(dev_pr_meta, list) else [dev_pr_meta]
        for pr_meta in dev_prs:
            print(
                f"[{_PLUGIN}]   Fetching dev PR diff: "
                f"{pr_meta.get('repo', '?')}#{pr_meta.get('pr_number', '?')}"
            )
            r = _fetch_pr_diff(pr_meta, github_base, j_headers, d_headers)
            r["pr_type"] = "dev"
            pr_reviews.append(r)
    else:
        print(f"[{_PLUGIN}]   WARNING: no dev PR metadata for epic {args.epic_id}")

    qa_pr_meta = artifact.get("qa_pr_meta")
    if qa_pr_meta:
        qa_prs = qa_pr_meta if isinstance(qa_pr_meta, list) else [qa_pr_meta]
        for pr_meta in qa_prs:
            print(
                f"[{_PLUGIN}]   Fetching QA PR diff: "
                f"{pr_meta.get('repo', '?')}#{pr_meta.get('pr_number', '?')}"
            )
            r = _fetch_pr_diff(pr_meta, github_base, j_headers, d_headers)
            r["pr_type"] = "qa"
            pr_reviews.append(r)
    else:
        print(f"[{_PLUGIN}]   WARNING: no QA PR metadata for epic {args.epic_id}")

    if args.dry_run:
        print(f"[{_PLUGIN}] --dry-run: fetched {len(pr_reviews)} PR diff(s); not writing files")
        return

    # Write tl-review.json
    review_json = {
        "workspace_id": args.workspace_id,
        "epic_id": args.epic_id,
        "epic_title": epic_title,
        "pr_reviews": [
            {k: v for k, v in r.items() if k != "diff"}  # exclude diff from JSON (it's in the MD)
            for r in pr_reviews
        ],
    }
    review_path = epic_dir / _REVIEW_FILE
    review_path.write_text(json.dumps(review_json, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[{_PLUGIN}] Wrote {review_path}")

    # Write TL_REVIEW.md (includes the full diff text for Claude to read)
    review_md = _render_review_md(
        args.workspace_id,
        args.epic_id,
        epic_title,
        dev_handover_text,
        qa_context_text,
        pr_reviews,
    )
    md_path = epic_dir / _REVIEW_MD
    md_path.write_text(review_md, encoding="utf-8")
    print(f"[{_PLUGIN}] Wrote {md_path}")
    print(f"[{_PLUGIN}] Read {md_path} then write tl-findings.json for this epic")


if __name__ == "__main__":
    main()
