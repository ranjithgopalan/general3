"""Tech Lead bundle fetcher — Step 1 of the Tech Lead reviewer (aidlc-tech-lead plugin).

Fetches all epics from central, collects local dev handover docs and QA context docs written
by the develop and QA plugins, and assembles a TL_CONTEXT.md for operator review.

Outputs written to ``.aidlc/<workspace_id>/``:
  tl-bundle.json   — machine-readable: epics + PR metadata + local doc paths
  TL_CONTEXT.md    — human-readable overview (what exists, what's missing)

Usage:
  python aidlc_tl_bundle.py <workspace_id>
      [--epic-ids ID1,ID2,...]  # filter specific epics (default: all)
      [--out-dir PATH]
      [--config PATH]
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import aidlc_auth

_PLUGIN = "aidlc-tech-lead"
_BUNDLE_FILE = "tl-bundle.json"
_CONTEXT_FILE = "TL_CONTEXT.md"

# Files written by the develop plugin (per-epic)
_DEV_HANDOVER_PATTERN = "dev-handover-epic-{epic_id}.md"
_DEV_PR_META = "dev-pr-meta.json"

# Files written by the QA plugin (per-epic)
_QA_CONTEXT = "QA_CONTEXT.md"
_QA_PR_META = "qa-pr-meta.json"
_QA_FINDINGS = "qa-findings.json"
_PLAYWRIGHT_TRACE = "playwright-trace.json"


def _workspace_dir(cfg: dict[str, Any], workspace_id: str) -> Path:
    base = (cfg.get("workspace_dir") or ".aidlc").rstrip("/\\")
    return Path(base) / workspace_id


def _load_json_optional(path: Path) -> Any:
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _fetch_epics(base: str, workspace_id: str, cfg: dict[str, Any]) -> list[dict[str, Any]]:
    url = f"{base}/ws/{workspace_id}/epics"
    result = aidlc_auth.get_json(url, cfg)
    if isinstance(result, list):
        return result
    return result.get("epics") or []


def _fetch_trace(
    base: str, workspace_id: str, epic_id: str, kind: str, cfg: dict[str, Any]
) -> dict[str, Any] | None:
    """GET the epic's dev or qa trace from central (the PR + files + KB citations recorded by
    the aidlc-develop / aidlc-qa plugins). Returns None if absent, null, or unavailable —
    the handover markdown is local-only, so the trace is the authoritative cross-plugin record.
    """
    url = f"{base}/ws/{workspace_id}/epics/{epic_id}/{kind}/trace"
    try:
        result = aidlc_auth.get_json(url, cfg)
    except Exception:
        return None
    return result if isinstance(result, dict) and result else None


def _has_pr(meta: Any) -> bool:
    """True when PR metadata (dict, or list of dicts for multi-repo) carries a pr_url."""
    items = meta if isinstance(meta, list) else ([meta] if meta else [])
    return any(isinstance(m, dict) and m.get("pr_url") for m in items)


def _collect_epic_artifacts(
    ws_dir: Path,
    epic_id: str,
    dev_trace: dict[str, Any] | None,
    qa_trace: dict[str, Any] | None,
) -> dict[str, Any]:
    """Collect PR metadata (from central traces, falling back to local *-pr-meta.json) plus any
    local handover / QA context docs for an epic."""
    epic_dir = ws_dir / "epics" / epic_id

    dev_handover_path = epic_dir / _DEV_HANDOVER_PATTERN.format(epic_id=epic_id)
    qa_context_path = epic_dir / _QA_CONTEXT

    # PR metadata: prefer local *-pr-meta.json, fall back to the central trace
    dev_pr_meta = _load_json_optional(epic_dir / _DEV_PR_META) or dev_trace
    qa_pr_meta = _load_json_optional(epic_dir / _QA_PR_META) or qa_trace

    playwright_trace = (
        (qa_trace or {}).get("playwright_trace")
        or _load_json_optional(epic_dir / _PLAYWRIGHT_TRACE)
    )
    qa_findings = _load_json_optional(epic_dir / _QA_FINDINGS)

    return {
        "epic_id": epic_id,
        "epic_dir": str(epic_dir),
        "dev_handover_path": str(dev_handover_path) if dev_handover_path.is_file() else None,
        "dev_handover_present": dev_handover_path.is_file(),
        "dev_trace": dev_trace,
        "dev_pr_meta": dev_pr_meta,
        "dev_pr_present": _has_pr(dev_pr_meta),
        "qa_context_path": str(qa_context_path) if qa_context_path.is_file() else None,
        "qa_context_present": qa_context_path.is_file(),
        "qa_trace": qa_trace,
        "qa_pr_meta": qa_pr_meta,
        "qa_pr_present": _has_pr(qa_pr_meta),
        "playwright_trace": playwright_trace,
        "qa_findings": qa_findings,
    }


def _render_context_md(
    workspace_id: str,
    workspace: dict[str, Any],
    epics: list[dict[str, Any]],
    artifacts: list[dict[str, Any]],
) -> str:
    lines = [
        f"# Tech Lead Review — workspace {workspace_id}",
        "",
        f"**State:** `{workspace.get('state', '?')}`  "
        f"**Requirement:** {workspace.get('requirement_text', '_(not set)_')[:200]}",
        "",
        "---",
        "",
        "## Epics in Scope",
        "",
        "| Epic ID | Title | Status | Dev Handover | Dev PR | QA Context | QA PR | Warnings |",
        "|---|---|---|---|---|---|---|---|",
    ]

    art_by_id = {a["epic_id"]: a for a in artifacts}

    for ep in epics:
        eid = str(ep.get("id") or ep.get("epic_id") or "?")
        title = (ep.get("title") or "")[:50]
        status = ep.get("status") or "?"
        a = art_by_id.get(eid, {})
        dev_h = "[PASS]" if (a.get("dev_handover_present") or a.get("dev_trace")) else "—"
        dev_pr = "[PASS]" if a.get("dev_pr_present") else "[FAIL] MISSING"
        qa_ctx = "[PASS]" if (a.get("qa_context_present") or a.get("qa_trace")) else "—"
        qa_pr = "[PASS]" if a.get("qa_pr_present") else "[FAIL] MISSING"

        warnings: list[str] = []
        if not a.get("dev_pr_present"):
            warnings.append("no dev PR trace — run aidlc-develop")
        if not a.get("qa_pr_present"):
            warnings.append("no qa PR trace — run aidlc-qa")
        warn_str = "; ".join(warnings) if warnings else "—"

        lines.append(
            f"| `{eid}` | {title} | `{status}` | {dev_h} | {dev_pr} | {qa_ctx} | {qa_pr} | {warn_str} |"
        )

    lines += [
        "",
        "---",
        "",
        "## Next Steps",
        "",
        "For each epic, run:",
        "```bash",
        f"python scripts/aidlc_tl_review.py {workspace_id} --epic-id <EPIC_ID>",
        "# Read .aidlc/<workspace_id>/epics/<EPIC_ID>/TL_REVIEW.md",
        "# Write .aidlc/<workspace_id>/epics/<EPIC_ID>/tl-findings.json",
        f"python scripts/aidlc_tl_approve.py {workspace_id} --epic-id <EPIC_ID> \\",
        "  --findings-file .aidlc/<workspace_id>/epics/<EPIC_ID>/tl-findings.json",
        "```",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser(description="Fetch TL bundle — workspace epics + local doc paths.")
    ap.add_argument("workspace_id")
    ap.add_argument("--epic-ids", default=None,
                    help="Comma-separated list of epic IDs to include (default: all)")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--config", default=None)
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    base = (cfg.get("central_base_url") or "").rstrip("/")
    if not base:
        sys.exit(f"[{_PLUGIN}] config.central_base_url is required")

    ws_dir = Path(args.out_dir) if args.out_dir else _workspace_dir(cfg, args.workspace_id)
    ws_dir.mkdir(parents=True, exist_ok=True)

    # Fetch workspace metadata
    try:
        workspace = aidlc_auth.get_json(f"{base}/ws/{args.workspace_id}", cfg)
    except Exception as exc:
        print(f"[{_PLUGIN}] WARNING: could not fetch workspace metadata: {exc}")
        workspace = {}

    # Fetch epics
    epics = _fetch_epics(base, args.workspace_id, cfg)

    # Filter by --epic-ids if supplied
    if args.epic_ids:
        ids_filter = {e.strip() for e in args.epic_ids.split(",") if e.strip()}
        epics = [ep for ep in epics if str(ep.get("id") or ep.get("epic_id") or "") in ids_filter]

    print(f"[{_PLUGIN}] {len(epics)} epic(s) in scope for workspace {args.workspace_id}")

    # Collect local artifacts per epic
    artifacts: list[dict[str, Any]] = []
    for ep in epics:
        eid = str(ep.get("id") or ep.get("epic_id") or "?")
        dev_trace = _fetch_trace(base, args.workspace_id, eid, "dev", cfg)
        qa_trace = _fetch_trace(base, args.workspace_id, eid, "qa", cfg)
        a = _collect_epic_artifacts(ws_dir, eid, dev_trace, qa_trace)
        artifacts.append(a)
        missing = []
        if not a["dev_pr_present"]:
            missing.append("dev-PR")
        if not a["qa_pr_present"]:
            missing.append("qa-PR")
        if missing:
            print(f"[{_PLUGIN}]   WARNING: epic {eid} missing: {', '.join(missing)}")
        else:
            print(f"[{_PLUGIN}]   epic {eid}: dev+qa PR traces present")

    # Write tl-bundle.json
    bundle = {
        "workspace_id": args.workspace_id,
        "workspace": workspace,
        "epics": epics,
        "artifacts": artifacts,
    }
    bundle_path = ws_dir / _BUNDLE_FILE
    bundle_path.write_text(json.dumps(bundle, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[{_PLUGIN}] Wrote {bundle_path}")

    # Write TL_CONTEXT.md
    context_md = _render_context_md(args.workspace_id, workspace, epics, artifacts)
    (ws_dir / _CONTEXT_FILE).write_text(context_md, encoding="utf-8")
    print(f"[{_PLUGIN}] Wrote {ws_dir / _CONTEXT_FILE}")
    print(f"[{_PLUGIN}] Next: read TL_CONTEXT.md, then run aidlc_tl_review.py per epic")


if __name__ == "__main__":
    main()
