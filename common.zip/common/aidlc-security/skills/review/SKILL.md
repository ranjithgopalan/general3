---
name: review
description: "Security review (code, crypto, design, data-privacy) AND OPA Rego policy generation from the domain pack rbac block. Produces security-report.md and opa-policies. Use for M5 security-opa stage."
---

## Pre-Processing: Detect Inline Content

**CRITICAL:** Before invoking the router, check if the user provided INLINE content:

1. **IF** `$ARGUMENTS` contains code blocks (```typescript, ```python, etc.) OR markdown documents:
   - Set flag: `INLINE_CONTENT_PROVIDED=true`
   - Extract the inline content
   - Pass to router with explicit instruction: "USER PROVIDED INLINE CONTENT - ANALYZE IT DIRECTLY, DO NOT ASK FOR PATHS"

2. **ELSE** (no inline content detected):
   - Set flag: `INLINE_CONTENT_PROVIDED=false`
   - Let router ask for paths as normal

## CRITICAL: Response Handling

**When presenting findings to the user, you MUST:**
1. Include the FULL evidence package for EVERY finding - do NOT summarize
2. Each finding must have: file:line location, code snippet, severity, confidence, CWE reference, mitigations checked, confidence justification, PoC, and remediation
3. NEVER abbreviate or condense the security findings
4. Pass through the complete detailed output from the security reviewer

## Agent Invocation

> ⚡ **AIDLC Launcher mode**: If `aidlc.config.json` **exists** in the current working directory,
> skip this entire workflow and jump directly to **Reporting to the AIDLC Platform** at the
> bottom of this file. The local session's only role is to create the ECS run and monitor the
> CLI subprocess — do **not** invoke agents or generate files locally.

Use Task tool with `subagent_type="security-reviewer-router"` with the following enriched prompt:

Prompt: """
## User Request
$ARGUMENTS

🚨 **INLINE CONTENT DETECTION:**
- **IF** the above request contains CODE BLOCKS (```language) or MARKDOWN DOCUMENTS:
  → Extract them IMMEDIATELY and delegate to reviewers
  → DO NOT ask "what would you like me to review?"
  → SKIP Step 2 (asking for paths)
  → Proceed DIRECTLY to delegation

## Intent: REVIEW (Security Analysis) + OPA POLICY GENERATION

### 1. Analyze Review Scope
Determine from keywords:
- design/architecture/HLD → design-security-reviewer
- code/source/implementation → code-security-reviewer
- crypto/encryption/JWT → crypto-security-reviewer
- infrastructure/IAM/SAM → infrastructure-security-reviewer
- full/comprehensive → All reviewers

For M5 (security-opa) ECS runs: always run ALL reviewers — code, crypto,
design, and data-privacy — then generate OPA policies (Steps 5-6 below).

### 2. Get Target Content
- **PRIORITY 1:** Check if code/documents provided INLINE in the request
  - Look for code blocks: ```typescript, ```python, ```javascript, etc.
  - Look for markdown design documents in the prompt
  - Look for multiple files with comments like "// file: path/to/file.ts"
  - If INLINE content found → analyze it DIRECTLY, do NOT ask for paths
- **PRIORITY 2:** Check if file paths specified in the request
  - Absolute paths: /home/user/project/src/file.ts
  - Relative paths: ./src/file.ts, src/**/*.ts
  - If paths found → read and analyze those files
- **PRIORITY 3:** If NO inline content AND NO paths provided
  - Ask user: "Please provide either (1) inline code/documents to review, or (2) file paths to review"
  - Examples:
    - Inline: "Paste your code here in a code block"
    - Paths: "Specify paths like ./src or ./docs/architecture.md"

For M5 ECS runs: input artifacts are downloaded into the stage working
directory by the worker. Scan the following paths:
- `api-source/` — generated Spring Boot code (M3)
- `ui-source/` — generated Angular code (M2)
- `api-data-access/` — DAOs and datasource config (M4)
- `business-rules/` — approved business rules document (Global)

### 3. Present Plan Before Execution (ONLY if analyzing file system)
- If analyzing INLINE content → SKIP plan presentation, analyze immediately
- If analyzing file system paths → Present plan:
  - Review type and scope
  - Target paths
  - Specialized reviewers to invoke
  - Wait for user confirmation

### 4. Delegate to Appropriate Reviewers
- design-security-reviewer → Architecture security
- code-security-reviewer → Business logic flaws, OWASP Top 10
- crypto-security-reviewer → Encryption, key management
- data-privacy-reviewer → PII/PHI leaks, logging hygiene, compliance gaps
- infrastructure-security-reviewer → IAM, Lambda, API Gateway

### 5. Aggregate Security Review Results
Read `aidlc.config.json` to resolve `workspace_id`, then write:
- `workspaces/{workspace_id}/security-opa/security-report.md`

Create the directory if it does not exist.

Report contents:
- Severity (CRITICAL/HIGH/MEDIUM/LOW)
- Confidence levels
- Remediation roadmap
- Professional pentest recommendation

### 6. Generate OPA Rego Policies (always run — satisfies `opa-policies` artifact)

After `security-report.md` is written, invoke the rego-policy-generator:

```
Task(subagent_type: "AIDLC-security:rego-policy-generator", prompt: """
## Workspace
{workspace_id}

## Domain pack location
workspaces/{workspace_id}/  (look for domain-pack.json)

## Business rules
business-rules/  (downloaded input artifact)

## Output path
workspaces/{workspace_id}/security-opa/opa/

Generate one .rego policy file per Spring Boot service declared in the domain
pack. Each file must cover:
1. API endpoint access — which roles may call which HTTP method + path
2. Stored-procedure invocation — which roles may invoke which SP family
3. S3 document access — which roles may upload / download / delete
4. Row-level data scope — region x profit-centre filtering where the rbac
   block declares scoped_by fields
5. Data-driven sign-off positions — approval roles mapped to business-rules

Coverage requirement: each .rego file must ship with a matching _test.rego
file that achieves >90% rule coverage (every allow/deny branch exercised).

Write a policy manifest at:
  workspaces/{workspace_id}/security-opa/opa/POLICY-MANIFEST.md
listing every generated .rego file, the service it covers, and the rule
coverage percentage achieved.
""")
```

**Gate:** If the rego-policy-generator reports coverage below 90% for any
policy, log a warning in `security-report.md` under a "OPA Coverage Gaps"
section — do NOT fail the stage, but flag for the DevOps approver to review.
"""

Request to process: $ARGUMENTS

---

## Reporting to the AIDLC Platform (ECS UI tracking)

> **SERVER CLI GUARD:** If `aidlc.config.json` does **not** exist in your current
> working directory, skip this entire ECS section and run only the main workflow
> above. These steps are for the **local Claude Code session only**.

The local session creates the ECS run and monitors progress. All generation
is performed by the ECS server CLI — do **not** generate or copy files locally.

---

**Step 0 — Read config**
```powershell
$cfgPath = (Resolve-Path "aidlc.config.json" -ErrorAction Stop).Path
$cfg     = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
$BASE    = $cfg.central_base_url.TrimEnd('/')
$TOKEN   = [System.Environment]::GetEnvironmentVariable($cfg.auth.bearer_env)
if (-not $TOKEN) {
    $relayFile = Join-Path (Split-Path $cfgPath) ".aidlc_token"
    if (Test-Path $relayFile) { $TOKEN = (Get-Content $relayFile -Raw -Encoding UTF8).Trim() }
}
$WS    = $cfg.workspace_id
$HDR   = @{ Authorization = "Bearer $TOKEN"; "Content-Type" = "application/json" }
$STAGE = "security-opa"
```

**Step 1 — Smart run management: cancel queued / attach running / create fresh**
```powershell
# Check for an existing active run for this stage
$existing = $null
try {
    $existing = (Invoke-RestMethod "$BASE/pipeline-runs?workspace_id=$WS&stage_key=$STAGE" -Headers $HDR).items |
        Where-Object { $_.state -in @("queued", "running") } |
        Sort-Object queued_at -Descending |
        Select-Object -First 1
} catch {}

if ($existing -and $existing.state -eq "queued") {
    # Queued but not started — cancel immediately and restart fresh
    Invoke-RestMethod "$BASE/pipeline-runs/$($existing.run_id)/cancel" -Headers $HDR -Method Post | Out-Null
    Write-Host "Cancelled queued run $($existing.run_id) — creating fresh run."
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true; force=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
} elseif ($existing -and $existing.state -eq "running") {
    # Already being processed by the worker — attach and monitor, do NOT cancel
    $RUN_ID = $existing.run_id
    Write-Host "Run already in progress: $RUN_ID — attaching to monitor."
} else {
    # No active run — create a fresh one
    $body   = @{ stage=$STAGE; workspace_id=$WS; execute=$true; force=$true } | ConvertTo-Json
    $resp   = Invoke-RestMethod "$BASE/pipeline-runs" -Headers $HDR -Method Post -Body $body -ContentType "application/json"
    $RUN_ID = if ($resp.run_id) { $resp.run_id } else { $resp.run.run_id }
    Write-Host "ECS run created: $RUN_ID — server CLI is generating. Monitoring..."
}
```

**Step 2 — Monitor and display elapsed time**
```powershell
do {
    Start-Sleep -Seconds 15
    # API wraps response in a "run" envelope — unwrap before accessing fields
    $run     = (Invoke-RestMethod "$BASE/pipeline-runs/$RUN_ID" -Headers $HDR).run
    $elapsed = if ($run.started_at) {
        $s = [datetime]::Parse($run.started_at)
        $e = if ($run.finished_at) { [datetime]::Parse($run.finished_at) } else { Get-Date }
        "$([int]($e - $s).TotalSeconds)s"
    } else { "queued" }
    $files = if ($run.files_written) { $run.files_written.Count } else { 0 }
    Write-Host "  [$elapsed]  state=$($run.state)  files=$files"
} while ($run.state -notin @("waiting_for_approval","completed","failed","cancelled"))
```

**Step 3 — Final timing summary**
```powershell
$fmt = { param($t) if ($t) { [datetime]::Parse($t).ToLocalTime().ToString("HH:mm:ss") } else { "—" } }
$sec = if ($run.started_at -and $run.finished_at) {
    [int]([datetime]::Parse($run.finished_at) - [datetime]::Parse($run.started_at)).TotalSeconds
} else { 0 }
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
Write-Host "  Run     : $RUN_ID"
Write-Host "  Stage   : $STAGE"
Write-Host "  State   : $($run.state)"
Write-Host "  Queued  : $(& $fmt $run.queued_at)"
Write-Host "  Started : $(& $fmt $run.started_at)"
Write-Host "  Finished: $(& $fmt $run.finished_at)"
Write-Host "  Elapsed : ${sec}s"
Write-Host "  Files   : $($run.files_written.Count) written"
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
```

**Step 4 — Generation Summary**
```powershell
$files = $run.files_written
$groups = [ordered]@{
    "Security Report"  = @($files | Where-Object { $_ -like "*security-report*" })
    "OPA Rego Policies"= @($files | Where-Object { $_ -like "*.rego" -and $_ -notlike "*_test*" })
    "OPA Policy Tests" = @($files | Where-Object { $_ -like "*_test.rego" })
    "Policy Manifest"  = @($files | Where-Object { $_ -like "*POLICY-MANIFEST*" })
}
Write-Host ""
Write-Host "┌──────────────────────────────────────────────────────────────────┐"
Write-Host "│           GENERATION SUMMARY — security-opa (M5)                 │"
Write-Host "├──────────────────────────────┬─────────┬────────────────────────┤"
Write-Host "│ Category                     │  Count  │ Sample files           │"
Write-Host "├──────────────────────────────┼─────────┼────────────────────────┤"
foreach ($key in $groups.Keys) {
    $items = $groups[$key]
    if ($items.Count -gt 0) {
        $sample = ($items | ForEach-Object { [System.IO.Path]::GetFileName($_) } | Select-Object -First 2) -join ", "
        if ($sample.Length -gt 24) { $sample = $sample.Substring(0,21) + "..." }
        Write-Host ("│ {0,-28} │ {1,7} │ {2,-22} │" -f $key, $items.Count, $sample)
    }
}
Write-Host "├──────────────────────────────┼─────────┼────────────────────────┤"
Write-Host ("│ {0,-28} │ {1,7} │ {2,-22} │" -f "TOTAL", $files.Count, "")
Write-Host "└──────────────────────────────┴─────────┴────────────────────────┘"

# Warn if OPA policies or security report are absent
$missing = @()
if (-not ($files | Where-Object { $_ -like "*security-report*" })) { $missing += "security-report.md" }
if (-not ($files | Where-Object { $_ -like "*.rego" }))            { $missing += "OPA .rego policies" }
if ($missing) {
    Write-Host ""
    Write-Host "  ⚠ Missing required artifacts: $($missing -join ', ')"
}
$wsPath = Join-Path (Split-Path $cfgPath) "workspaces\$WS\security-opa"
Write-Host ""
Write-Host "  Output path : $wsPath"
```

**Step 5 — Review in ECS UI**
```
https://poc-ecs-build-ui.npsdlchgapp.us-east-1.aws.aig.net/aidlc-platform-management/pipeline
```

Approval persona: **DevOps**