"""Git operations for the AIDLC develop cockpit (docs/27).

Clone a remote repo at a specified source branch, create a feature branch from it,
push after edits, and create a PR via GitHub Enterprise REST API.

Config-driven, stdlib-only (urllib + subprocess) — no extra deps.
Reads aidlc.config.json (same as aidlc_bundle.py).

Auth — GitHub PAT only (no SSH):
  The PAT is resolved from config.git.github_token_env.
  Two modes supported:
    1. The value is an env var NAME  → token = os.environ[value]
    2. The value IS the token itself → used directly (starts with github_pat_ or ghp_)

  The PAT is used for:
    - HTTPS git clone  (https://<PAT>@github.aig.net/owner/repo.git)
    - HTTPS git push   (same credential via git remote)
    - GitHub REST API  (Authorization: token <PAT>)

Usage:
  python aidlc_git.py clone   <workspace_id> --source-branch <branch> [--config PATH]
  python aidlc_git.py branch  <workspace_id> [--source-branch <branch>] [--slug TEXT] [--config PATH]
  python aidlc_git.py push    <workspace_id> [--config PATH]
  python aidlc_git.py pr      <workspace_id> [--source-branch <branch>] [--title TEXT]
                               [--requirement TEXT] [--kb-citations IDS] [--test-summary TEXT]
                               [--config PATH]
  python aidlc_git.py status  <workspace_id> [--config PATH]
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

import aidlc_auth

# ── Constants ────────────────────────────────────────────────────────────────────

_STATUS_FILE = "git-ops-status.json"
_FEATURE_BRANCH_PREFIX = "aidlc"
# Token prefixes that indicate the config value IS the token, not an env var name
_TOKEN_PREFIXES = ("github_pat_", "ghp_", "gho_", "ghs_", "ghu_")


# ── Config helpers ────────────────────────────────────────────────────────────────

def _git_cfg(cfg: dict[str, Any]) -> dict[str, Any]:
    """Return the git sub-config block (or empty dict if absent)."""
    return cfg.get("git") or {}


def _github_token(cfg: dict[str, Any]) -> str:
    """Resolve GitHub PAT.

    Strategy:
      1. Read config.git.github_token_env
      2. If the value looks like a PAT (starts with known prefix) → use it directly
      3. Otherwise treat it as an env var name and read from os.environ
      4. If neither resolves → exit with instructions
    """
    raw = _git_cfg(cfg).get("github_token_env") or ""
    if not raw:
        sys.exit(
            "[aidlc-git] config.git.github_token_env is not set.\n"
            "  Set it to your PAT directly, or to the name of an env var that holds it."
        )

    # If the raw value looks like a token, use it directly
    if any(raw.startswith(prefix) for prefix in _TOKEN_PREFIXES):
        return raw

    # Otherwise treat it as an env var name
    token = os.environ.get(raw, "")
    if not token:
        sys.exit(
            f"[aidlc-git] GitHub token not found — env var '{raw}' is not set.\n"
            f"  Run: export {raw}=<your-PAT>  or set the PAT directly in config.git.github_token_env"
        )
    return token


def _github_base(cfg: dict[str, Any]) -> str:
    """Return the GitHub Enterprise API base URL (no trailing slash)."""
    return (_git_cfg(cfg).get("github_base_url") or "https://github.aig.net/api/v3").rstrip("/")


def _github_host(cfg: dict[str, Any]) -> str:
    """Return just the host (scheme + netloc) from github_base_url."""
    parsed = urllib.parse.urlparse(_github_base(cfg))
    return f"{parsed.scheme}://{parsed.netloc}"


def _default_base_branch(cfg: dict[str, Any]) -> str:
    return _git_cfg(cfg).get("default_base_branch") or "master"


def _feature_branch_name(workspace_id: str, slug: str = "", epic_id: str = "") -> str:
    """Build the feature branch name.

    Epic-scoped (Phase B): ``ws-<workspace_id>-<epic_id>``
    Workspace-level:       ``aidlc/<workspace_id>[-<slug>]``
    """
    if epic_id:
        return f"ws-{workspace_id}-{epic_id}"
    parts = [_FEATURE_BRANCH_PREFIX, workspace_id]
    if slug:
        clean = slug.lower().replace(" ", "-")[:40]
        parts.append(clean)
    return "/".join(parts)


def _repo_name_from_entry(entry: dict[str, Any]) -> str:
    """Derive the repo directory name (e.g. ``aig-connect-auto-services-3396``) from a
    repo_map entry — used to match against source loci that embed the repo folder name."""
    remote = (entry.get("remote_url") or "").rstrip("/")
    name = remote.split("/")[-1] if remote else Path(entry.get("local_root") or "").name
    return name[:-4] if name.endswith(".git") else name


def _collect_bundle_loci(bundle: dict[str, Any]) -> set[str]:
    """Collect every source-locus-like string anywhere in the bundle (component_design,
    citations, evidence, etc.), normalised to the path portion before any ``§``/``#`` anchor."""
    LOCUS_KEYS = {"source_locus", "locus", "file", "path", "file_path"}
    loci: set[str] = set()

    def _walk(node: Any) -> None:
        if isinstance(node, dict):
            for k, v in node.items():
                if k in LOCUS_KEYS and isinstance(v, str) and v.strip():
                    loci.add(v.split(" §")[0].split(" #")[0].strip())
                _walk(v)
        elif isinstance(node, list):
            for v in node:
                _walk(v)

    _walk(bundle)
    return loci


def identify_affected_repos(
    bundle: dict[str, Any], repo_map: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Return the subset of ``repo_map`` entries touched by this bundle.

    Scans every source-locus string in the bundle (component_design *and* citations/evidence)
    and matches a repo when either its ``corpus_prefix`` prefixes a locus, or its repo folder
    name appears inside a locus (robust to corpus roots that prepend a domain segment such as
    ``input/Auto/CodeBase/...`` vs a config prefix of ``input/CodeBase/...``).
    Falls back to the full ``repo_map`` when no loci can be matched (safe default).
    """
    loci = _collect_bundle_loci(bundle)
    if not loci:
        return repo_map
    matched: list[dict[str, Any]] = []
    for entry in repo_map:
        prefix = (entry.get("corpus_prefix") or "").replace("\\", "/").rstrip("/")
        repo_name = _repo_name_from_entry(entry)
        if any(
            (prefix and f.startswith(prefix)) or (repo_name and repo_name in f)
            for f in loci
        ):
            matched.append(entry)
    return matched if matched else repo_map


def _load_bundle_for(cfg: dict[str, Any], workspace_id: str, epic_id: str) -> dict[str, Any]:
    """Load the locally-written bundle.json for a workspace or epic (empty dict if absent)."""
    ws_dir = Path(cfg.get("workspace_dir") or ".aidlc") / workspace_id
    bundle_path = (ws_dir / "epics" / epic_id / "bundle.json") if epic_id else (ws_dir / "bundle.json")
    if bundle_path.is_file():
        try:
            return json.loads(bundle_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    return {}


def _scope_ops_to_affected(ops: "AidlcGitOps", cfg: dict[str, Any]) -> None:
    """Narrow ``ops.repo_map`` to the repos this epic actually touches (no-op without a bundle
    or when nothing matches). Keeps epic-scoped setup/push/pr off unrelated repos."""
    if not ops.epic_id:
        return
    bundle = _load_bundle_for(cfg, ops.workspace_id, ops.epic_id)
    if not bundle:
        return
    affected = identify_affected_repos(bundle, ops.repo_map)
    if affected and len(affected) < len(ops.repo_map):
        names = ", ".join(_repo_name_from_entry(e) for e in affected)
        print(f"[aidlc-git] Epic scope: {len(affected)}/{len(ops.repo_map)} affected repo(s) → {names}")
        ops.repo_map = affected


# ── HTTPS clone URL builder ───────────────────────────────────────────────────────

def _https_clone_url(remote_url: str, token: str) -> str:
    """Build an authenticated HTTPS clone URL: https://<token>@host/owner/repo.git

    Works for both HTTPS and SSH-format remote_urls in the config.
    """
    # Normalise SSH format (git@host:owner/repo) → HTTPS
    if remote_url.startswith("git@"):
        # git@github.aig.net:owner/repo.git → https://github.aig.net/owner/repo.git
        without_scheme = remote_url[4:]  # strip 'git@'
        host, path = without_scheme.split(":", 1)
        remote_url = f"https://{host}/{path}"

    parsed = urllib.parse.urlparse(remote_url)
    # Embed token in netloc: https://TOKEN@host/owner/repo.git
    netloc_with_token = f"{urllib.parse.quote(token, safe='')}@{parsed.netloc}"
    url = urllib.parse.urlunparse(parsed._replace(netloc=netloc_with_token))
    if not url.endswith(".git"):
        url = url + ".git"
    return url


# ── Subprocess helpers ────────────────────────────────────────────────────────────

def _run(cmd: list[str], cwd: str | Path, env: dict[str, str] | None = None,
         check: bool = True, capture: bool = False) -> subprocess.CompletedProcess:
    """Run a subprocess command."""
    result = subprocess.run(
        cmd,
        cwd=str(cwd),
        env=env or os.environ.copy(),
        capture_output=capture,
        text=True,
        check=False,
    )
    if check and result.returncode != 0:
        stderr = (result.stderr or "").strip()
        stdout = (result.stdout or "").strip()
        msg = stderr or stdout
        sys.exit(f"[aidlc-git] Command failed: {' '.join(cmd)}\n{msg}")
    return result


# ── GitHub Enterprise REST API ────────────────────────────────────────────────────

class GitHubAPI:
    """Thin GitHub Enterprise REST API client (stdlib urllib only)."""

    def __init__(self, base_url: str, token: str):
        self.base = base_url.rstrip("/")
        self.headers = {
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github.v3+json",
            "Content-Type": "application/json",
        }

    def _request(self, method: str, path: str, body: dict | None = None) -> dict[str, Any]:
        url = f"{self.base}/{path.lstrip('/')}"
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body else None
        req = urllib.request.Request(url, data=data, headers=self.headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            body_text = exc.read().decode("utf-8", "replace")[:400]
            sys.exit(f"[aidlc-git] GitHub API {method} {url} → HTTP {exc.code}: {body_text}")
        except urllib.error.URLError as exc:
            sys.exit(f"[aidlc-git] Cannot reach GitHub API at {url}: {exc.reason}")

    def get_branch_sha(self, owner: str, repo: str, branch: str) -> str:
        """Return the HEAD commit SHA of a branch."""
        data = self._request("GET", f"/repos/{owner}/{repo}/git/ref/heads/{branch}")
        sha = (data.get("object") or {}).get("sha") or ""
        if not sha:
            sys.exit(f"[aidlc-git] Could not resolve SHA for branch '{branch}' in {owner}/{repo}")
        return sha

    def create_branch(self, owner: str, repo: str, new_branch: str, from_sha: str) -> dict[str, Any]:
        """Create a new git ref (branch) from a given SHA."""
        return self._request("POST", f"/repos/{owner}/{repo}/git/refs", {
            "ref": f"refs/heads/{new_branch}",
            "sha": from_sha,
        })

    def branch_exists(self, owner: str, repo: str, branch: str) -> bool:
        """Return True if the branch already exists on the remote."""
        url = f"{self.base}/repos/{owner}/{repo}/git/ref/heads/{branch}"
        req = urllib.request.Request(url, headers=self.headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.status == 200
        except urllib.error.HTTPError as exc:
            return exc.code != 404
        except urllib.error.URLError:
            return False

    def create_pull_request(
        self,
        owner: str,
        repo: str,
        title: str,
        body: str,
        head_branch: str,
        base_branch: str,
        draft: bool = False,
        labels: list[str] | None = None,
        reviewers: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create a PR and optionally add labels + reviewers."""
        pr = self._request("POST", f"/repos/{owner}/{repo}/pulls", {
            "title": title,
            "body": body,
            "head": head_branch,
            "base": base_branch,
            "draft": draft,
        })
        pr_number = pr.get("number")
        if pr_number and labels:
            try:
                self._request("POST", f"/repos/{owner}/{repo}/issues/{pr_number}/labels",
                              {"labels": labels})
            except SystemExit:
                print("[aidlc-git] WARNING: Could not add labels to PR")
        if pr_number and reviewers:
            try:
                self._request("POST", f"/repos/{owner}/{repo}/pulls/{pr_number}/requested_reviewers",
                              {"reviewers": reviewers})
            except SystemExit:
                print("[aidlc-git] WARNING: Could not add reviewers to PR")
        return pr


# ── Repo map helpers ──────────────────────────────────────────────────────────────

def _extract_owner_repo(remote_url: str) -> tuple[str, str]:
    """Extract (owner, repo) from an HTTPS or SSH GitHub URL."""
    url = remote_url.rstrip("/")
    if url.endswith(".git"):
        url = url[:-4]
    if url.startswith("git@"):
        # git@github.aig.net:owner/repo
        path_part = url.split(":")[-1]
    else:
        parsed = urllib.parse.urlparse(url)
        path_part = parsed.path.lstrip("/")
    parts = path_part.split("/")
    if len(parts) < 2:
        sys.exit(f"[aidlc-git] Cannot parse owner/repo from: {remote_url}")
    return parts[-2], parts[-1]


def _repo_key(entry: dict[str, Any]) -> str:
    """Stable display key for a repo_map entry."""
    return entry.get("local_root") or entry.get("corpus_prefix") or str(entry)


# ── Status tracking ───────────────────────────────────────────────────────────────

def _status_path(cfg: dict[str, Any], workspace_id: str) -> Path:
    ws_dir = Path(cfg.get("workspace_dir") or ".aidlc") / workspace_id
    ws_dir.mkdir(parents=True, exist_ok=True)
    return ws_dir / _STATUS_FILE


def _load_status(cfg: dict[str, Any], workspace_id: str) -> dict[str, Any]:
    p = _status_path(cfg, workspace_id)
    if p.is_file():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    return {"workspace_id": workspace_id, "repos": {}}


def _save_status(cfg: dict[str, Any], workspace_id: str, status: dict[str, Any]) -> None:
    _status_path(cfg, workspace_id).write_text(
        json.dumps(status, indent=2, ensure_ascii=False), encoding="utf-8"
    )


# ── Core operations ───────────────────────────────────────────────────────────────

class AidlcGitOps:
    """PAT-based git operations for the AIDLC develop workflow (no SSH)."""

    def __init__(self, cfg: dict[str, Any], workspace_id: str, *, epic_id: str = ""):
        self.cfg = cfg
        self.workspace_id = workspace_id
        self.epic_id = epic_id  # when set, all branch ops use ws-<ws_id>-<epic_id> naming
        self.git_cfg = _git_cfg(cfg)
        self.repo_map: list[dict[str, Any]] = cfg.get("repo_map") or []
        self.token = _github_token(cfg)
        self.github_base = _github_base(cfg)
        self.default_base = _default_base_branch(cfg)
        self.auto_clone = self.git_cfg.get("auto_clone", True)
        self.pr_defaults: dict[str, Any] = self.git_cfg.get("pr_defaults") or {}

    def _api(self) -> GitHubAPI:
        return GitHubAPI(self.github_base, self.token)

    def _clone_url(self, remote_url: str) -> str:
        """Return an authenticated HTTPS clone URL for the given remote."""
        return _https_clone_url(remote_url, self.token)

    # ── Clone ─────────────────────────────────────────────────────────

    def is_cloned(self, entry: dict[str, Any]) -> bool:
        local = entry.get("local_root", "")
        return bool(local) and (Path(local) / ".git").exists()

    def clone_repo(self, entry: dict[str, Any], source_branch: str) -> bool:
        """Clone repo at source_branch via HTTPS+PAT. Fetch/pull if already cloned."""
        remote_url = entry.get("remote_url", "")
        local_root = entry.get("local_root", "")
        if not remote_url:
            print(f"[aidlc-git] Skipping — no remote_url: {entry.get('corpus_prefix')}")
            return False
        if not local_root:
            print(f"[aidlc-git] Skipping — no local_root: {entry.get('corpus_prefix')}")
            return False

        local_path = Path(local_root)
        clone_url = self._clone_url(remote_url)

        if self.is_cloned(entry):
            print(f"[aidlc-git] Already cloned: {local_path} — fetching '{source_branch}'")
            _run(["git", "fetch", "origin", source_branch], cwd=local_path)
            _run(["git", "checkout", source_branch], cwd=local_path)
            _run(["git", "pull", "--ff-only", "origin", source_branch], cwd=local_path)
            return True

        local_path.mkdir(parents=True, exist_ok=True)
        print(f"[aidlc-git] Cloning {remote_url} @ '{source_branch}' → {local_path}")

        result = subprocess.run(
            ["git", "clone", "--branch", source_branch, "--depth", "1",
             "--single-branch", clone_url, str(local_path)],
            capture_output=True, text=True, check=False,
        )

        if result.returncode != 0:
            stderr = result.stderr or ""
            if "already exists and is not an empty directory" in stderr:
                # Dir exists but has no .git — init + fetch
                _run(["git", "init"], cwd=local_path)
                _run(["git", "remote", "add", "origin", clone_url], cwd=local_path)
                _run(["git", "fetch", "origin", source_branch, "--depth", "1"], cwd=local_path)
                _run(["git", "checkout", "-b", source_branch,
                      f"origin/{source_branch}"], cwd=local_path)
            else:
                # Redact the token from error output before printing
                safe_err = stderr.replace(self.token, "<PAT>")
                sys.exit(f"[aidlc-git] Clone failed:\n{safe_err}")

        print(f"[aidlc-git] Clone complete: {local_path}")
        return True

    def clone_all(self, source_branch: str) -> list[dict[str, Any]]:
        """Clone all repo_map entries at source_branch."""
        results = []
        for entry in self.repo_map:
            success = self.clone_repo(entry, source_branch)
            results.append({
                "repo": _repo_key(entry),
                "local_root": entry.get("local_root"),
                "source_branch": source_branch,
                "cloned": success,
            })
        return results

    # ── Setup (clone-if-needed + branch, one atomic step) ─────────────

    def setup(self, source_branch: str, slug: str = "") -> list[dict[str, Any]]:
        """Check each repo: clone if not present, then create the feature branch.

        This is the single command that runs before any code edits begin.
        Returns per-repo status with fields: repo, local_root, was_cloned,
        source_branch, feature_branch.
        """
        feature_branch = _feature_branch_name(self.workspace_id, slug, self.epic_id)
        results = []

        print(f"\n[aidlc-git] ── Setup: checking {len(self.repo_map)} repo(s) ──────────────")
        for i, entry in enumerate(self.repo_map, 1):
            prefix = entry.get("corpus_prefix") or entry.get("local_root", "?")
            local_path = Path(entry.get("local_root", ""))
            remote_url = entry.get("remote_url", "")

            print(f"\n[aidlc-git] [{i}/{len(self.repo_map)}] {prefix}")

            # Skip if no remote configured
            if not remote_url:
                print(f"[aidlc-git]   [WARN] Skipping — no remote_url in config")
                results.append({
                    "repo": _repo_key(entry),
                    "local_root": str(local_path),
                    "skipped": True,
                    "reason": "no_remote_url",
                })
                continue

            # Step A: clone or fetch
            was_cloned = self.is_cloned(entry)
            if was_cloned:
                print(f"[aidlc-git]   [PASS] Already cloned at {local_path}")
                print(f"[aidlc-git]   → Fetching latest '{source_branch}'")
                fetch = _run(["git", "fetch", "origin", source_branch],
                             cwd=local_path, capture=True, check=False)
                if fetch.returncode != 0:
                    safe = (fetch.stderr or "").replace(self.token, "<PAT>").strip()
                    print(f"[aidlc-git]   [WARN] Fetch warning: {safe}")
            else:
                print(f"[aidlc-git]   → Not cloned. Cloning from {remote_url}")
                ok = self.clone_repo(entry, source_branch)
                if not ok:
                    results.append({
                        "repo": _repo_key(entry),
                        "local_root": str(local_path),
                        "skipped": True,
                        "reason": "clone_failed",
                    })
                    continue

            # Step B: check if feature branch already exists locally
            existing_local = _run(
                ["git", "branch", "--list", feature_branch],
                cwd=local_path, capture=True, check=False,
            ).stdout.strip()

            if existing_local:
                print(f"[aidlc-git]   [PASS] Feature branch '{feature_branch}' already exists — checking out")
                _run(["git", "checkout", feature_branch], cwd=local_path)
            else:
                # Ensure we're on source_branch at latest before branching
                checkout = _run(["git", "checkout", source_branch],
                                cwd=local_path, capture=True, check=False)
                if checkout.returncode != 0:
                    # Try origin/source_branch if local tracking branch doesn't exist yet
                    _run(["git", "checkout", "-b", source_branch,
                          f"origin/{source_branch}"], cwd=local_path)

                pull = _run(["git", "pull", "--ff-only", "origin", source_branch],
                            cwd=local_path, capture=True, check=False)
                if pull.returncode != 0:
                    print(f"[aidlc-git]   [WARN] Pull warning — proceeding anyway")

                _run(["git", "checkout", "-b", feature_branch], cwd=local_path)
                print(f"[aidlc-git]   [PASS] Created feature branch '{feature_branch}'")

                # Create branch on remote via GitHub API (so push works first time)
                owner, repo_name = _extract_owner_repo(remote_url)
                api = self._api()
                if api.branch_exists(owner, repo_name, feature_branch):
                    print(f"[aidlc-git]   ℹ Remote branch '{feature_branch}' already exists")
                else:
                    try:
                        sha = api.get_branch_sha(owner, repo_name, source_branch)
                        api.create_branch(owner, repo_name, feature_branch, sha)
                        print(f"[aidlc-git]   [PASS] Remote branch created @ {sha[:8]}")
                    except SystemExit as exc:
                        print(f"[aidlc-git]   [WARN] Could not create remote branch: {exc}")

            results.append({
                "repo": _repo_key(entry),
                "local_root": str(local_path),
                "was_cloned": was_cloned,
                "source_branch": source_branch,
                "feature_branch": feature_branch,
                "ready": True,
            })

        ready = sum(1 for r in results if r.get("ready"))
        print(f"\n[aidlc-git] ── Setup complete: {ready}/{len(self.repo_map)} repos ready ──")
        print(f"[aidlc-git]    Feature branch: '{feature_branch}'")
        print(f"[aidlc-git]    Source branch:  '{source_branch}'\n")
        return results

    # ── Branch ───────────────────────────────────────────────────────

    def create_feature_branch(self, entry: dict[str, Any], source_branch: str,
                               slug: str = "") -> str:
        """Create feature branch locally and on remote. Returns branch name."""
        local_path = Path(entry.get("local_root", ""))

        # Warn on dirty working tree
        dirty = _run(["git", "status", "--porcelain"], cwd=local_path,
                     capture=True, check=False)
        if dirty.stdout.strip():
            print(f"[aidlc-git] WARNING: Dirty working tree in {local_path} — "
                  f"stash or commit before edits.")

        feature = _feature_branch_name(self.workspace_id, slug, self.epic_id)

        # Check for existing local branch
        existing = _run(["git", "branch", "--list", feature], cwd=local_path,
                        capture=True, check=False).stdout.strip()
        if existing:
            print(f"[aidlc-git] Feature branch '{feature}' exists locally — checking out")
            _run(["git", "checkout", feature], cwd=local_path)
        else:
            _run(["git", "checkout", source_branch], cwd=local_path)
            _run(["git", "pull", "--ff-only", "origin", source_branch], cwd=local_path)
            _run(["git", "checkout", "-b", feature], cwd=local_path)
            print(f"[aidlc-git] Created local branch '{feature}' from '{source_branch}'")

        # Create on remote via GitHub API
        remote_url = entry.get("remote_url", "")
        if remote_url:
            owner, repo = _extract_owner_repo(remote_url)
            api = self._api()
            if api.branch_exists(owner, repo, feature):
                print(f"[aidlc-git] Remote branch '{feature}' already exists in {owner}/{repo}")
            else:
                sha = api.get_branch_sha(owner, repo, source_branch)
                api.create_branch(owner, repo, feature, sha)
                print(f"[aidlc-git] Created remote branch '{feature}' @ {sha[:8]}")

        return feature

    def branch_all(self, source_branch: str, slug: str = "") -> list[dict[str, Any]]:
        """Create feature branch in all cloned repos."""
        results = []
        for entry in self.repo_map:
            if not self.is_cloned(entry):
                print(f"[aidlc-git] Skipping branch — not cloned: {entry.get('local_root')}")
                results.append({"repo": _repo_key(entry), "skipped": True, "reason": "not_cloned"})
                continue
            feature = self.create_feature_branch(entry, source_branch, slug)
            results.append({
                "repo": _repo_key(entry),
                "local_root": entry.get("local_root"),
                "feature_branch": feature,
                "source_branch": source_branch,
            })
        return results

    # ── Push ──────────────────────────────────────────────────────────

    def push_branch(self, entry: dict[str, Any]) -> dict[str, Any]:
        """Push current branch to origin via HTTPS+PAT."""
        local_path = Path(entry.get("local_root", ""))
        if not local_path.exists():
            return {"repo": _repo_key(entry), "pushed": False, "reason": "not_cloned"}

        # Ensure the remote URL uses the PAT (re-set it in case it was cloned without token)
        remote_url = entry.get("remote_url", "")
        if remote_url:
            clone_url = self._clone_url(remote_url)
            _run(["git", "remote", "set-url", "origin", clone_url],
                 cwd=local_path, check=False)

        # Current branch
        branch_r = _run(["git", "rev-parse", "--abbrev-ref", "HEAD"],
                        cwd=local_path, capture=True)
        current_branch = branch_r.stdout.strip()

        if not (current_branch.startswith(_FEATURE_BRANCH_PREFIX) or current_branch.startswith("ws-")):
            print(f"[aidlc-git] WARNING: Not on aidlc/* or ws-* branch ({current_branch}) — skipping push")
            return {"repo": _repo_key(entry), "pushed": False,
                    "reason": "wrong_branch", "branch": current_branch}

        print(f"[aidlc-git] Pushing '{current_branch}' in {local_path}")
        push = _run(["git", "push", "-u", "origin", current_branch],
                    cwd=local_path, capture=True, check=False)

        if push.returncode != 0:
            stderr = (push.stderr or "").replace(self.token, "<PAT>").strip()
            if "rejected" in stderr or "non-fast-forward" in stderr:
                sys.exit(
                    f"[aidlc-git] Push rejected — remote has diverged.\n"
                    f"Run: git pull --rebase origin {current_branch}  then retry.\n{stderr}"
                )
            sys.exit(f"[aidlc-git] Push failed:\n{stderr}")

        sha = _run(["git", "rev-parse", "HEAD"], cwd=local_path,
                   capture=True).stdout.strip()
        print(f"[aidlc-git] Pushed '{current_branch}' @ {sha[:8]}")
        return {
            "repo": _repo_key(entry),
            "pushed": True,
            "branch": current_branch,
            "commit_sha": sha,
            "local_root": str(local_path),
        }

    def push_all(self) -> list[dict[str, Any]]:
        """Push current branch in all repo_map entries."""
        return [self.push_branch(e) for e in self.repo_map]

    # ── PR creation ───────────────────────────────────────────────────

    def create_pr(
        self,
        entry: dict[str, Any],
        title: str,
        body: str,
        source_branch: str,
        head_branch: str | None = None,
    ) -> dict[str, Any]:
        """Create a PR for one repo via GitHub Enterprise API."""
        remote_url = entry.get("remote_url", "")
        if not remote_url:
            return {"repo": _repo_key(entry), "created": False, "reason": "no_remote_url"}

        local_path = Path(entry.get("local_root", ""))
        if not head_branch and local_path.exists():
            head_branch = _run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=local_path, capture=True,
            ).stdout.strip()
        if not head_branch:
            head_branch = _feature_branch_name(self.workspace_id, epic_id=self.epic_id)

        base_branch = entry.get("base_branch") or source_branch or self.default_base
        owner, repo = _extract_owner_repo(remote_url)
        api = self._api()

        pr = api.create_pull_request(
            owner=owner, repo=repo,
            title=title, body=body,
            head_branch=head_branch, base_branch=base_branch,
            draft=self.pr_defaults.get("draft", False),
            labels=self.pr_defaults.get("labels"),
            reviewers=self.pr_defaults.get("reviewers"),
        )
        pr_url = pr.get("html_url") or pr.get("url") or ""
        pr_number = pr.get("number")
        print(f"[aidlc-git] PR created: #{pr_number} → {pr_url}")
        return {
            "repo": _repo_key(entry),
            "created": True,
            "pr_url": pr_url,
            "pr_number": pr_number,
            "head_branch": head_branch,
            "base_branch": base_branch,
            "owner": owner,
            "repo_name": repo,
        }

    def create_prs(self, title: str, body: str, source_branch: str) -> list[dict[str, Any]]:
        """Create PRs in repo_map entries that have a remote_url AND have commits ahead of base."""
        results = []
        for e in self.repo_map:
            if not e.get("remote_url"):
                continue
            local_path = Path(e.get("local_root", ""))
            # Determine how many commits the feature branch has ahead of base
            base = e.get("base_branch") or source_branch or self.default_base
            commits_ahead = 0
            if local_path.exists():
                try:
                    out = _run(
                        ["git", "rev-list", "--count", f"origin/{base}..HEAD"],
                        cwd=local_path, capture=True,
                    ).stdout.strip()
                    commits_ahead = int(out) if out.isdigit() else 0
                except Exception:
                    commits_ahead = 0
            if commits_ahead == 0:
                print(f"[aidlc-git] Skipping PR for {_repo_key(e)} — no commits ahead of {base}")
                results.append({"repo": _repo_key(e), "created": False, "reason": "no_new_commits"})
                continue
            results.append(self.create_pr(e, title, body, source_branch))
        return results

    # ── Status ────────────────────────────────────────────────────────

    def show_status(self) -> None:
        """Print clone/branch/dirty status for all repos in the map."""
        print(f"\n{'─' * 60}")
        print(f"  AIDLC Git Status — workspace: {self.workspace_id}")
        print(f"{'─' * 60}")
        for entry in self.repo_map:
            local_path = Path(entry.get("local_root", ""))
            prefix = entry.get("corpus_prefix", "")
            remote = entry.get("remote_url", "(no remote_url)")
            cloned = self.is_cloned(entry)

            if cloned:
                branch_r = _run(["git", "rev-parse", "--abbrev-ref", "HEAD"],
                                 cwd=local_path, capture=True, check=False)
                current = branch_r.stdout.strip() if branch_r.returncode == 0 else "?"
                dirty_r = _run(["git", "status", "--porcelain"],
                                cwd=local_path, capture=True, check=False)
                dirty = "DIRTY" if dirty_r.stdout.strip() else "clean"
                print(f"  [PASS] {prefix}")
                print(f"     local:  {local_path}")
                print(f"     remote: {remote}")
                print(f"     branch: {current}  [{dirty}]")
            else:
                print(f"  [FAIL] {prefix}  (not cloned)")
                print(f"     local:  {local_path}")
                print(f"     remote: {remote}")
            print()


# ── PR body builder ───────────────────────────────────────────────────────────────

def _build_pr_body(
    workspace_id: str,
    requirement: str,
    kb_citations: list[str] | None = None,
    change_specs: list[str] | None = None,
    test_summary: str = "",
    kb_drift_notes: str = "",
) -> str:
    sections = [
        f"## Workspace\n`{workspace_id}`\n",
        f"## Requirement\n{requirement or '_(not provided)_'}\n",
    ]
    if change_specs:
        sections.append(f"## Change Specs Implemented\n" +
                        "\n".join(f"- {s}" for s in change_specs) + "\n")
    if kb_citations:
        sections.append(f"## KB Citations\n" +
                        " ".join(f"`{c}`" for c in kb_citations) + "\n")
    if test_summary:
        sections.append(f"## Test Results\n{test_summary}\n")
    if kb_drift_notes:
        sections.append(f"## KB Drift Notes\n[WARN] {kb_drift_notes}\n")
    sections.append("---\n_Generated by AIDLC develop cockpit · Japan Auto_")
    return "\n".join(sections)


# ── CLI commands ──────────────────────────────────────────────────────────────────

def _cmd_setup(args: argparse.Namespace, cfg: dict[str, Any]) -> None:
    """Clone repos if needed, then create the feature branch — all in one step."""
    epic_id = getattr(args, "epic_id", "") or ""
    ops = AidlcGitOps(cfg, args.workspace_id, epic_id=epic_id)
    _scope_ops_to_affected(ops, cfg)
    source = args.source_branch or _default_base_branch(cfg)
    if not args.source_branch:
        # Try to read from saved status
        saved = _load_status(cfg, args.workspace_id)
        source = saved.get("source_branch") or source
    slug = getattr(args, "slug", "") or ""

    results = ops.setup(source, slug)

    status = _load_status(cfg, args.workspace_id)
    status["source_branch"] = source
    feature = next((r.get("feature_branch") for r in results if r.get("feature_branch")), "")
    if feature:
        status["feature_branch"] = feature
    for r in results:
        status["repos"].setdefault(r["repo"], {}).update(r)
    _save_status(cfg, args.workspace_id, status)

    ready = sum(1 for r in results if r.get("ready"))
    if ready == 0:
        sys.exit(
            "[aidlc-git] No repos were set up. Check that repo_map entries have "
            "remote_url and local_root set in aidlc.config.json"
        )


def _cmd_clone(args: argparse.Namespace, cfg: dict[str, Any]) -> None:
    ops = AidlcGitOps(cfg, args.workspace_id, epic_id=getattr(args, "epic_id", "") or "")
    source = args.source_branch or _default_base_branch(cfg)
    print(f"[aidlc-git] Cloning repos @ source branch '{source}' (HTTPS+PAT)")
    results = ops.clone_all(source)
    status = _load_status(cfg, args.workspace_id)
    status["source_branch"] = source
    for r in results:
        status["repos"].setdefault(r["repo"], {}).update(r)
    _save_status(cfg, args.workspace_id, status)
    ok = sum(1 for r in results if r.get("cloned"))
    print(f"[aidlc-git] Done: {ok}/{len(results)} repos cloned/updated")


def _cmd_branch(args: argparse.Namespace, cfg: dict[str, Any]) -> None:
    ops = AidlcGitOps(cfg, args.workspace_id, epic_id=getattr(args, "epic_id", "") or "")
    status = _load_status(cfg, args.workspace_id)
    source = args.source_branch or status.get("source_branch") or _default_base_branch(cfg)
    slug = args.slug or ""
    print(f"[aidlc-git] Creating feature branches from '{source}'")
    results = ops.branch_all(source, slug)
    for r in results:
        status["repos"].setdefault(r["repo"], {}).update(r)
    if results:
        status["feature_branch"] = next(
            (r.get("feature_branch") for r in results if r.get("feature_branch")), "")
    _save_status(cfg, args.workspace_id, status)
    feature = status.get("feature_branch", "?")
    print(f"\n[aidlc-git] Feature branch: '{feature}'")
    print(f"[aidlc-git] [PASS] Repos ready for edits. When done:")
    print(f"   git add <files>")
    print(f"   git commit -m 'aidlc({args.workspace_id}): <title>'")
    print(f"   python aidlc_git.py push {args.workspace_id}")


def _cmd_push(args: argparse.Namespace, cfg: dict[str, Any]) -> None:
    ops = AidlcGitOps(cfg, args.workspace_id, epic_id=getattr(args, "epic_id", "") or "")
    _scope_ops_to_affected(ops, cfg)
    print("[aidlc-git] Pushing branches via HTTPS+PAT")
    results = ops.push_all()
    status = _load_status(cfg, args.workspace_id)
    for r in results:
        status["repos"].setdefault(r["repo"], {}).update(r)
    _save_status(cfg, args.workspace_id, status)
    pushed = sum(1 for r in results if r.get("pushed"))
    print(f"[aidlc-git] Pushed {pushed}/{len(results)} repos")


def _cmd_pr(args: argparse.Namespace, cfg: dict[str, Any]) -> None:
    ops = AidlcGitOps(cfg, args.workspace_id, epic_id=getattr(args, "epic_id", "") or "")
    _scope_ops_to_affected(ops, cfg)
    status = _load_status(cfg, args.workspace_id)
    source = args.source_branch or status.get("source_branch") or _default_base_branch(cfg)

    # Load bundle for PR body context (degrades gracefully if absent)
    ws_dir = Path(cfg.get("workspace_dir") or ".aidlc") / args.workspace_id
    bundle: dict[str, Any] = {}
    bundle_path = ws_dir / "bundle.json"
    if bundle_path.is_file():
        try:
            bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass

    requirement = args.requirement or bundle.get("requirement_text") or ""
    citations = [c.strip() for c in args.kb_citations.split(",") if c.strip()] \
        if args.kb_citations else []
    drift_path = ws_dir / "kb-drift.md"
    drift_notes = drift_path.read_text(encoding="utf-8") if drift_path.is_file() else ""

    title = args.title or f"aidlc({args.workspace_id}): {requirement[:80] or 'workspace change'}"
    body = _build_pr_body(
        workspace_id=args.workspace_id,
        requirement=requirement,
        kb_citations=citations or None,
        test_summary=args.test_summary,
        kb_drift_notes=drift_notes,
    )

    print("[aidlc-git] Creating PRs via GitHub Enterprise API")
    results = ops.create_prs(title, body, source)
    for r in results:
        status["repos"].setdefault(r["repo"], {}).update(r)
    status["pr_results"] = results
    _save_status(cfg, args.workspace_id, status)

    created = [r for r in results if r.get("created")]
    print(f"[aidlc-git] Created {len(created)}/{len(results)} PRs")
    for r in created:
        print(f"   {r.get('repo_name', r['repo'])}: {r['pr_url']}")

    # Print the sync-back command
    if created:
        r0 = created[0]
        sha = (status.get("repos") or {}).get(r0["repo"], {}).get("commit_sha", "")
        print(f"\n[aidlc-git] Next — sync PR back to central:")
        cmd = (
            f"  python aidlc_sync_pr.py {args.workspace_id}"
            f" --pr-url {r0['pr_url']}"
            f" --branch {r0['head_branch']}"
            + (f" --commit {sha}" if sha else "")
            + f" --repo {r0['repo_name']}"
            + f" --summary \"{requirement[:80]}\""
        )
        print(cmd)


def _cmd_status(args: argparse.Namespace, cfg: dict[str, Any]) -> None:
    ops = AidlcGitOps(cfg, args.workspace_id, epic_id=getattr(args, "epic_id", "") or "")
    ops.show_status()
    status_file = _status_path(cfg, args.workspace_id)
    if status_file.is_file():
        status = _load_status(cfg, args.workspace_id)
        print(f"  Status file: {status_file}")
        print(f"  Source branch : {status.get('source_branch', '(not set)')}")
        print(f"  Feature branch: {status.get('feature_branch', '(not set)')}")


# ── Main ──────────────────────────────────────────────────────────────────────────

def main() -> None:
    ap = argparse.ArgumentParser(
        description="AIDLC git operations (HTTPS+PAT): clone, branch, push, PR, status."
    )
    ap.add_argument("command", choices=["setup", "clone", "branch", "push", "pr", "status"],
                    help="setup = clone-if-needed + branch (recommended first step); "
                         "clone/branch = individual steps; push/pr/status = later steps")
    ap.add_argument("workspace_id", help="AIDLC workspace ID")
    ap.add_argument("--source-branch", default=None,
                    help="Remote branch to clone FROM and to target the PR at "
                         "(e.g. 'develop', 'release-12.4'). Defaults to config.git.default_base_branch.")
    ap.add_argument("--epic-id", default="",
                    help="Epic ID for per-epic branching. When set, branch name is ws-<workspace_id>-<epic_id> "
                         "instead of aidlc/<workspace_id>.")
    ap.add_argument("--slug", default="",
                    help="Short slug appended to workspace-level feature branch name (e.g. 'endorsement-email'). "
                         "Ignored when --epic-id is set.")
    ap.add_argument("--title", default=None,
                    help="PR title (default: auto-generated from bundle requirement)")
    ap.add_argument("--requirement", default=None,
                    help="Requirement text for PR body (default: read from bundle.json)")
    ap.add_argument("--kb-citations", default="",
                    help="Comma-separated KB IDs for PR body (e.g. 'CMP-001,FR-002')")
    ap.add_argument("--test-summary", default="",
                    help="Test results summary line for PR body")
    ap.add_argument("--config", default=None,
                    help="Path to aidlc.config.json (else $AIDLC_CONFIG or ./aidlc.config.json)")
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)

    dispatch = {
        "setup":  _cmd_setup,
        "clone":  _cmd_clone,
        "branch": _cmd_branch,
        "push":   _cmd_push,
        "pr":     _cmd_pr,
        "status": _cmd_status,
    }
    dispatch[args.command](args, cfg)


if __name__ == "__main__":
    main()
