"""Sync a raised PR back to central (docs/27 P2/P3) — records provenance + advances DEVELOPMENT→QA_TESTING.

Config-driven, stdlib-only (urllib). Same config + auth resolution as ``aidlc_bundle.py``. Posts to
``POST /ws/{id}/dev/pr`` for workspace-level sync, or ``POST /ws/{id}/epics/{epic_id}/dev/trace``
for per-epic sync (Phase B: when --epic-id is given).

Usage (workspace-level):
  python aidlc_sync_pr.py <workspace_id> --pr-url URL --branch BRANCH [--commit SHA]
                          [--repo NAME] [--summary TEXT] [--no-advance] [--config PATH]

Usage (epic-scoped — Phase B):
  python aidlc_sync_pr.py <workspace_id> --epic-id EPIC_ID --branch ws-<ws>-<epic>
                          [--pr-url URL] [--commit SHA] [--repo NAME]
                          [--story-ids STO-1,STO-2] [--files-changed path/a.java,path/b.ts]
                          [--kb-ids CMP-001,BR-002] [--summary TEXT] [--config PATH]
"""

from __future__ import annotations

import argparse
import base64
import json
import sys
from pathlib import Path
from typing import Any

import aidlc_auth


def _split_csv(value: str) -> list[str]:
    """Split a comma-separated CLI argument into a trimmed list, dropping empties."""
    return [v.strip() for v in value.split(",") if v.strip()]


def _decode_actor_from_token(cfg: dict[str, Any]) -> str | None:
    """Decode the actor identity (email / sub) from the cached bearer token JWT.

    Reads the token cache path from config (auth.okta.token_cache), loads the
    access_token, base64-decodes the payload segment, and returns the `email`
    claim if present, falling back to `sub`.  Returns None on any failure so
    callers can degrade gracefully.
    """
    try:
        cache_path_raw = (
            (cfg.get("auth") or {}).get("okta", {}).get("token_cache") or "~/.aidlc/token.json"
        )
        cache_path = Path(cache_path_raw).expanduser()
        if not cache_path.is_file():
            return None
        token_data = json.loads(cache_path.read_text(encoding="utf-8"))
        access_token: str = token_data.get("access_token") or token_data.get("token") or ""
        if not access_token:
            return None
        # JWT payload is the second segment (index 1), base64url-encoded
        parts = access_token.split(".")
        if len(parts) < 2:
            return None
        # Add padding so base64 decodes cleanly
        payload_b64 = parts[1] + "=" * (4 - len(parts[1]) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64).decode("utf-8"))
        return payload.get("email") or payload.get("sub")
    except Exception:
        return None


def main() -> None:
    ap = argparse.ArgumentParser(description="Sync a raised PR back to central.")
    ap.add_argument("workspace_id")
    ap.add_argument("--epic-id", default=None,
                    help="Epic ID to post a per-epic dev trace (Phase B). "
                         "When set, posts to POST /ws/{id}/epics/{epic_id}/dev/trace "
                         "instead of the workspace-level PR sync endpoint.")
    ap.add_argument("--pr-url", default=None, help="URL of the raised PR")
    ap.add_argument("--pr-number", default=None, type=int, help="PR number (integer)")
    ap.add_argument("--branch", default=None, help="branch the PR was raised from")
    ap.add_argument("--commit", default=None, help="commit SHA")
    ap.add_argument("--repo", default=None, help="repo name (for epic trace)")
    ap.add_argument("--story-ids", default="",
                    help="Comma-separated story IDs implemented in this epic (epic mode)")
    ap.add_argument("--files-changed", default="",
                    help="Comma-separated file paths touched in this epic (epic mode)")
    ap.add_argument("--kb-ids", default="",
                    help="Comma-separated KB IDs cited in code comments (epic mode)")
    ap.add_argument("--summary", default="", help="Short description of the change")
    ap.add_argument("--no-advance", action="store_true",
                    help="Record the PR but do NOT advance workspace to QA_TESTING (workspace mode only)")
    ap.add_argument("--drift-file", default=None,
                    help="Path to a JSON array of KB-drift notes — workspace mode only")
    ap.add_argument("--agent-steps", default="",
                    help="JSON-encoded agent steps array from the dev doc (epic mode)")
    ap.add_argument("--design-artifacts", default="",
                    help="JSON-encoded design artifacts dict {hld, lld} (epic mode)")
    ap.add_argument("--gear-id", required=True,
                    help="Gear ID resolved in Step 0. Appended as ?gear_id= on all central API calls.")
    ap.add_argument("--config", default=None)
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    base = (cfg.get("central_base_url") or "").rstrip("/")
    if not base:
        sys.exit("[aidlc] config.central_base_url is required")
    timeout = float(cfg.get("request_timeout") or 120)
    gear_id: str = args.gear_id

    # Resolve actor from the bearer token JWT (email / sub claim) for traceability.
    actor = _decode_actor_from_token(cfg)

    if args.epic_id:
        # per-epic dev trace — POST /ws/{id}/epics/{epic_id}/dev/trace
        payload: dict[str, Any] = {
            "branch": args.branch or "",
            "commit_sha": args.commit,
            "pr_url": args.pr_url,
            "pr_number": args.pr_number,
            "repo": args.repo,
            "story_ids": _split_csv(args.story_ids),
            "files_changed": _split_csv(args.files_changed),
            "kb_ids_cited": _split_csv(args.kb_ids),
            "summary": args.summary,
            "actor": actor,  # populated from JWT bearer token (email / sub claim)
        }

        # Include agent steps and design artifacts if provided
        if args.agent_steps:
            try:
                payload["agent_steps"] = json.loads(args.agent_steps)
            except json.JSONDecodeError:
                print("[aidlc] [WARN] --agent-steps is not valid JSON; skipping")
        if args.design_artifacts:
            try:
                payload["design_artifacts"] = json.loads(args.design_artifacts)
            except json.JSONDecodeError:
                print("[aidlc] [WARN] --design-artifacts is not valid JSON; skipping")
        url = f"{base}/ws/{args.workspace_id}/epics/{args.epic_id}/dev/trace?gear_id={gear_id}"
        result = aidlc_auth.post_json(url, cfg, payload, timeout)
        print(
            f"[aidlc] Epic trace recorded: "
            f"artifact_id={result.get('artifact_id')} "
            f"epic_id={args.epic_id} "
            f"kb_grounds={result.get('kb_grounds_written', 0)} "
            f"stories_linked={result.get('stories_linked', 0)}"
        )
        return

    # Workspace-level PR sync — POST /ws/{id}/dev/pr
    body: dict[str, Any] = {
        "summary": args.summary,
        "advance": not args.no_advance,
        "actor": actor,  # populated from JWT bearer token (email / sub claim)
    }
    if args.pr_url:
        body["pr_url"] = args.pr_url
    if args.branch:
        body["branch"] = args.branch
    if args.commit:
        body["commit"] = args.commit
    if args.repo:
        body["repo"] = args.repo
    if args.drift_file:
        drift_path = Path(args.drift_file)
        if not drift_path.is_file():
            sys.exit(f"[aidlc] --drift-file not found: {drift_path}")
        try:
            drift = json.loads(drift_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            sys.exit(f"[aidlc] --drift-file is not valid JSON: {drift_path}: {exc}")
        if drift:
            body["kb_drift"] = drift

    result = aidlc_auth.post_json(f"{base}/ws/{args.workspace_id}/dev/pr?gear_id={gear_id}", cfg, body, timeout)
    print(f"[aidlc] PR synced: state={result.get('state')} advanced={result.get('advanced')} "
          f"artifact_id={result.get('artifact_id')} drift_recorded={result.get('drift_recorded', 0)}")


if __name__ == "__main__":
    main()
