"""Fetch a workspace bundle from central, compose a DevDocument locally, upload it, and render
the 9-section developer handover document (docs/27 P3).

Config-driven, stdlib-only (urllib) — no extra deps on the developer machine. Reads:
  - the config file at ``$AIDLC_CONFIG`` or ``./aidlc.config.json`` (base URL + auth env names)
  - the auth token / api key from the ENV var *names* the config points to (never hardcoded)

Flow:
  1. GET  /ws/{id}/bundle          → bundle.json  (impact + FSD + SRD + stories + citations)
  2. GET  /ws/{id}/kb-loci         → {kb_id: source_locus} for citations (real corpus file paths)
  3. Compose DevDocument from bundle + KB loci (deterministic, no LLM)
  4. Write dev.json locally
  5. POST /ws/{id}/dev/upload      → persists to S3 + DB (same path as central generation)
  6. Render dev-handover-{id}.md   → 9-section handover identical to central export.md

Usage:  python aidlc_bundle.py <workspace_id> [--config PATH]
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import aidlc_auth


# ── Bundle helpers ───────────────────────────────────────────────────────────────

def _bundle_docs(bundle: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """kind -> stage document from the bundle artifacts (impact/fsd/srd/stories)."""
    return {a.get("kind"): (a.get("document") or {}) for a in (bundle.get("artifacts") or [])}


# ── DevDocument composition ──────────────────────────────────────────────────────

# ── Sub-Agent Lane Classification (demo visibility) ─────────────────────────────
# Classifies each code change into a named "sub-agent" lane so the UI can
# show which specialized agent is handling each part of the epic implementation.

AGENT_LANES = {
    "angular":        {"agent": "UI / Axis Agent",    "icon": "[style]", "color": "#4A90D9"},
    "java_springboot":{"agent": "API Coding Agent",   "icon": "[config]", "color": "#E67E22"},
    "java_legacy":    {"agent": "API Coding Agent",   "icon": "[config]", "color": "#E67E22"},
    "sql":            {"agent": "DB Agent",            "icon": "[db]", "color": "#27AE60"},
    "ibm_esb":        {"agent": "Integration Agent",   "icon": "[link]", "color": "#8E44AD"},
    "adobe_xdp":      {"agent": "Forms Agent",         "icon": "[list]", "color": "#F39C12"},
    "pega":           {"agent": "Integration Agent",   "icon": "[link]", "color": "#8E44AD"},
    "unknown":        {"agent": "General Agent",       "icon": "[config]", "color": "#95A5A6"},
}


def classify_agent_lane(stack: str) -> dict[str, str]:
    """Return the agent lane metadata for a given stack.

    :inputs: stack (str) - the technology stack (e.g. 'angular', 'sql')
    :outputs: (dict) - {agent, icon, color} for the sub-agent lane
    """
    return AGENT_LANES.get(stack, AGENT_LANES["unknown"])


def build_agent_steps(
    code_stubs: list[dict[str, Any]],
    impl_tasks: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Build the ordered list of sub-agent execution steps from code stubs and tasks.

    Groups stubs by agent lane, then produces a step entry for each group
    showing which sub-agent is invoked, what files it handles, and the
    story IDs it implements. This is what the UI renders as the step-by-step
    agent execution view during the demo.

    :inputs: code_stubs (list) - code stub dicts; impl_tasks (list) - implementation tasks
    :outputs: (list[dict]) - ordered agent steps [{agent, icon, color, files, story_ids, status}]
    """
    # Group stubs by agent lane
    lane_groups: dict[str, dict[str, Any]] = {}
    for stub in code_stubs:
        stack = stub.get("stack") or "unknown"
        lane = classify_agent_lane(stack)
        agent_name = lane["agent"]
        if agent_name not in lane_groups:
            lane_groups[agent_name] = {
                "agent": agent_name,
                "icon": lane["icon"],
                "color": lane["color"],
                "files": [],
                "story_ids": set(),
                "components": [],
                "stack": stack,
            }
        grp = lane_groups[agent_name]
        grp["files"].append(stub.get("filename") or stub.get("component_id") or "?")
        if stub.get("story_id"):
            grp["story_ids"].add(stub["story_id"])
        grp["components"].append(stub.get("component_id") or "?")

    # Convert to ordered list (UI/Axis first, then API, DB, Integration)
    order = ["UI / Axis Agent", "API Coding Agent", "DB Agent",
             "Integration Agent", "Forms Agent", "General Agent"]
    steps = []
    step_num = 1
    for agent_name in order:
        if agent_name not in lane_groups:
            continue
        grp = lane_groups[agent_name]
        steps.append({
            "step": step_num,
            "agent": grp["agent"],
            "icon": grp["icon"],
            "color": grp["color"],
            "files": grp["files"],
            "file_count": len(grp["files"]),
            "story_ids": sorted(grp["story_ids"]),
            "components": grp["components"],
            "status": "pending",
        })
        step_num += 1
    return steps


def post_step_progress(
    base: str,
    workspace_id: str,
    epic_id: str,
    step: dict[str, Any],
    cfg: dict[str, Any],
    timeout: float,
) -> None:
    """Best-effort: POST a step progress event to central so the UI shows live execution.

    Endpoint: POST /ws/{workspace_id}/epics/{epic_id}/dev/step
    Never fails the run — logs and ignores errors.
    """
    url = f"{base}/ws/{workspace_id}/epics/{epic_id}/dev/step"
    try:
        aidlc_auth.post_json(url, cfg, step, timeout)
        print(f"[aidlc] {step.get('icon', '[config]')} Step {step.get('step', '?')}: "
              f"{step.get('agent', '?')} → {step.get('file_count', 0)} file(s) "
              f"[{step.get('status', '?')}]")
    except SystemExit:
        # post_json exits on HTTP error — best-effort, keep going
        print(f"[aidlc] step progress POST skipped (best-effort)")


# ── Design Artifact Generation (HLD / LLD before implementation) ────────────────
# Before the developer sub-agents start implementing, the plugin produces
# High-Level Design (HLD) and Low-Level Design (LLD) artifacts from the
# bundle data (SRD + FSD + stories). These are posted back to central as
# artifacts so the UI shows the design phase completing before code begins.


def _compose_hld(
    bundle: dict[str, Any],
    docs: dict[str, Any],
    agent_steps: list[dict[str, Any]],
) -> dict[str, Any]:
    """Compose a High-Level Design artifact from the bundle.

    HLD covers: architecture overview, system boundaries, integration points,
    technology stack breakdown by agent lane, and the epic-level scope.
    Deterministic (no LLM) — extracted from SRD + impact analysis.
    """
    srd = docs.get("srd") or {}
    impact = docs.get("impact") or {}
    stories_doc = docs.get("stories") or {}

    # Systems from impact
    systems = [
        {"id": s.get("id") or s.get("system_id"), "name": s.get("system_name") or s.get("label") or s.get("id")}
        for s in (impact.get("systems_affected") or [])
        if s.get("id") or s.get("system_id")
    ]

    # Integration points from SRD
    integrations = [
        {
            "id": i.get("id") or i.get("integration_id"),
            "label": i.get("label") or i.get("name") or "",
            "protocol": i.get("protocol"),
            "from": i.get("from_component") or i.get("from"),
            "to": i.get("to_component") or i.get("to"),
        }
        for i in (srd.get("integration_design") or [])
    ]

    # Technology stack summary from agent lanes
    stack_summary = [
        {"agent": s["agent"], "icon": s["icon"], "file_count": s["file_count"],
         "components": s.get("components", [])}
        for s in agent_steps
    ]

    return {
        "artifact_type": "hld",
        "title": "High-Level Design",
        "requirement": bundle.get("requirement_text") or "",
        "change_class": (
            (lambda c: c.get("change_class") if isinstance(c, dict) else c)(
                impact.get("classification")
            ) or "Enhancement"
        ),
        "systems_affected": systems,
        "integration_points": integrations,
        "technology_stack": stack_summary,
        "story_count": len((stories_doc or {}).get("stories") or []),
        "component_count": len(srd.get("component_design") or []),
        "scope_notes": [
            item.get("description") or str(item)
            for item in (srd.get("open_items") or [])
            if item.get("description")
        ],
        "status": "generated",
    }


def _compose_lld(
    docs: dict[str, Any],
    code_stubs: list[dict[str, Any]],
    impl_tasks: list[dict[str, Any]],
    kb_loci: dict[str, str],
) -> dict[str, Any]:
    """Compose a Low-Level Design artifact from code stubs and implementation tasks.

    LLD covers: per-file change specifications, method-level guidance,
    data flow between components, API contracts, DB schema changes.
    Deterministic (no LLM) — derived from SRD component_design + FSD FRs.
    """
    srd = docs.get("srd") or {}
    fsd = docs.get("fsd") or {}

    # Per-component design specs
    component_specs = []
    for stub in code_stubs:
        spec = {
            "component_id": stub.get("component_id") or "?",
            "filename": stub.get("filename") or "?",
            "stack": stub.get("stack") or "unknown",
            "language": stub.get("language") or "reference",
            "stub_type": stub.get("stub_type") or "component",
            "source_locus": stub.get("source_locus"),
            "story_id": stub.get("story_id"),
            "action": "modify" if stub.get("source_locus") else "create",
        }
        component_specs.append(spec)

    # API contracts from SRD
    api_contracts = [
        {
            "id": c.get("id") or c.get("component_id"),
            "label": c.get("label") or "",
            "kind": c.get("kind") or c.get("type") or "",
            "responsibility": c.get("responsibility") or "",
        }
        for c in (srd.get("component_design") or [])
        if (c.get("kind") or c.get("type") or "").lower() in ("apiop", "api", "controller", "service")
    ]

    # DB schema changes (from SRD or FSD if any table references exist)
    db_changes = [
        {
            "component_id": stub.get("component_id"),
            "filename": stub.get("filename"),
            "source_locus": stub.get("source_locus"),
        }
        for stub in code_stubs
        if stub.get("stack") == "sql"
    ]

    # FR deltas (functional requirement changes)
    fr_deltas = [
        {
            "id": fr.get("id"),
            "title": fr.get("title") or "",
            "as_is": fr.get("as_is"),
            "to_be": fr.get("to_be"),
        }
        for fr in (fsd.get("functional_requirements") or [])
        if fr.get("id")
    ]

    return {
        "artifact_type": "lld",
        "title": "Low-Level Design",
        "component_specs": component_specs,
        "api_contracts": api_contracts,
        "db_changes": db_changes,
        "fr_deltas": fr_deltas,
        "total_files": len(component_specs),
        "files_to_modify": sum(1 for s in component_specs if s["action"] == "modify"),
        "files_to_create": sum(1 for s in component_specs if s["action"] == "create"),
        "kb_loci_resolved": len(kb_loci),
        "status": "generated",
    }


def post_design_artifact(
    base: str,
    workspace_id: str,
    epic_id: str,
    artifact: dict[str, Any],
    cfg: dict[str, Any],
    timeout: float,
) -> dict[str, Any] | None:
    """POST a design artifact (HLD/LLD) to central so it appears in the UI timeline.

    Endpoint: POST /ws/{workspace_id}/epics/{epic_id}/dev/design
    Returns the server response or None on failure (best-effort).
    """
    url = f"{base}/ws/{workspace_id}/epics/{epic_id}/dev/design"
    try:
        result = aidlc_auth.post_json(url, cfg, artifact, timeout)
        atype = artifact.get("artifact_type", "?")
        print(f"[aidlc] [PASS] Design artifact posted: {atype.upper()} "
              f"(artifact_id={result.get('artifact_id', '?')})")
        return result
    except SystemExit:
        atype = artifact.get("artifact_type", "?")
        print(f"[aidlc] [WARN] Design artifact POST skipped (best-effort): {atype.upper()}")
        return None


def _detect_stack(source_locus: str) -> str:
    """
        Detect stack.
        :inputs: source_locus (str) - the source locus
        :outputs: (str) - the str result
        """
    locus = (source_locus or "").lower()
    if "adobeforms" in locus or ".xdp" in locus:
        return "adobe_xdp"
    if "esb" in locus or ".esql" in locus or ".msgflow" in locus:
        return "ibm_esb"
    if ".sql" in locus or "asacdp" in locus or "database" in locus:
        return "sql"
    if "freia" in locus or "webonline" in locus:
        return "java_legacy"
    if "pega" in locus:
        return "pega"
    if "services-" in locus or ".java" in locus:
        return "java_springboot"
    if "ui-" in locus or ".ts" in locus or ".html" in locus:
        return "angular"
    return "unknown"


def _detect_language(source_locus: str) -> str:
    """
        Detect language.
        :inputs: source_locus (str) - the source locus
        :outputs: (str) - the str result
        """
    locus = (source_locus or "").lower()
    if ".ts" in locus:
        return "typescript"
    if ".java" in locus:
        return "java"
    if ".sql" in locus:
        return "sql"
    if ".esql" in locus or ".msgflow" in locus:
        return "esql"
    return "reference"


def _detect_stub_type(kind: str) -> str:
    """
        Detect stub type.
        :inputs: kind (str) - the kind
        :outputs: (str) - the str result
        """
    return {
        "Component": "component",
        "ApiOp": "controller",
        "Integration": "esb_reference",
        "Screen": "component",
        "FunctionalReq": "service",
        "System": "service",
    }.get(kind, "component")


def _stack_to_layer(stack: str) -> str:
    """
        Stack to layer.
        :inputs: stack (str) - the stack
        :outputs: (str) - the str result
        """
    return {
        "angular": "Frontend",
        "java_springboot": "Backend",
        "ibm_esb": "Integration",
        "adobe_xdp": "Forms",
        "sql": "Data",
        "java_legacy": "Backend",
        "pega": "Integration",
    }.get(stack, "Other")


def _stub_code(comp: dict[str, Any], task: dict[str, Any] | None = None) -> str:
    """Generate implementation guidance for a file change.

    Uses FR as-is/to-be from the linked story (task) and Gherkin AC to give
    the developer concrete instructions rather than generic comments.
    """
    cid = comp.get("id", "?")
    responsibility = comp.get("responsibility") or comp.get("label") or comp.get("kind") or ""
    locus = comp.get("source_locus") or ""
    stack = _detect_stack(locus) if locus else _detect_stack_from_label(comp.get("label") or "")

    separator = "// " + "─" * 60
    lines = [separator, f"// KB card: {cid}"]
    if locus:
        lines.append(f"// File:    {Path(locus.split(' §')[0].split(' #')[0].strip()).name}")
        lines.append(f"// Path:    {locus.split(' §')[0].strip()}")
    lines.append(f"// Stack:   {stack}")
    lines.append("//")

    if responsibility:
        lines.append(f"// CHANGE:  {responsibility}")
        lines.append("//")

    # FR as-is → to-be from the linked story
    fr_deltas = (task or {}).get("fr_deltas") or []
    if fr_deltas:
        lines.append("// WHAT TO CHANGE (Functional Requirements):")
        for delta in fr_deltas[:3]:
            as_is = (delta.get("as_is") or "").strip()
            to_be = (delta.get("to_be") or "").strip()
            if as_is:
                lines.append(f"//   As-is: {as_is[:200]}")
            if to_be:
                lines.append(f"//   To-be: {to_be[:200]}")
            lines.append("//")

    # Gherkin AC from the linked story
    gherkin = (task or {}).get("gherkin_ac") or {}
    if gherkin.get("given") or gherkin.get("when") or gherkin.get("then"):
        lines.append("// ACCEPTANCE CRITERIA:")
        if gherkin.get("given"):
            lines.append(f"//   Given: {gherkin['given'][:200]}")
        if gherkin.get("when"):
            lines.append(f"//   When:  {gherkin['when'][:200]}")
        if gherkin.get("then"):
            lines.append(f"//   Then:  {gherkin['then'][:200]}")
        lines.append("//")

    lines.append("// [DEV-TODO] Implement the above change in this file")
    lines.append(separator)
    return "\n".join(lines)


# ── KB loci resolution ───────────────────────────────────────────────────────────

_CODE_EXTS = frozenset({".ts", ".html", ".java", ".sql", ".esql", ".wsdl", ".xml", ".xdp", ".js", ".kt", ".py"})

# Preferred extensions per component kind — ordered by specificity
_KIND_EXTS: dict[str, tuple[str, ...]] = {
    "ui":          (".ts", ".html"),
    "service":     (".java", ".kt"),
    "integration": (".java", ".wsdl", ".xml"),
    "db":          (".sql",),
}

# Preferred filename suffixes per kind — higher score when present
_KIND_SUFFIX_PREFS: dict[str, tuple[str, ...]] = {
    "ui":          ("component.ts", "component.html"),
    "service":     ("service.java", "serviceimpl.java", "controller.java"),
    "integration": ("service.java", ".wsdl"),
    "db":          (".sql",),
}


def _is_code_locus(locus: str) -> bool:
    """True when locus points to a source code file (not a PDF/doc/image)."""
    path = locus.split(" §")[0].split(" #")[0].strip().lower()
    return any(path.endswith(ext) for ext in _CODE_EXTS)


def fetch_epics(
    base: str, workspace_id: str, gear_id: str, cfg: dict[str, Any], timeout: float
) -> list[dict[str, Any]]:
    """Fetch all epics for a workspace (GET /ws/{id}/epics?gear_id={gear_id}).

    Returns an empty list if the endpoint is unavailable, so callers degrade gracefully.
    """
    url = f"{base}/ws/{workspace_id}/epics?gear_id={gear_id}"
    req = urllib.request.Request(url, headers=aidlc_auth.build_headers(cfg), method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except (urllib.error.HTTPError, urllib.error.URLError) as exc:
        print(f"[aidlc] Failed to fetch epics: {exc}")
        return []


def fetch_epic_bundle(
    base: str, workspace_id: str, epic_id: str, gear_id: str, cfg: dict[str, Any], timeout: float
) -> dict[str, Any]:
    """Fetch the epic-scoped bundle (GET /ws/{id}/epics/{epic_id}/bundle?gear_id={gear_id}).

    Returns stories filtered to this epic only; SRD/FSD/impact included in full.
    """
    url = f"{base}/ws/{workspace_id}/epics/{epic_id}/bundle?gear_id={gear_id}"
    return aidlc_auth.get_json(url, cfg, timeout)


def mark_epic_status(
    base: str, workspace_id: str, epic_id: str, status: str,
    gear_id: str, cfg: dict[str, Any], timeout: float,
) -> None:
    """Best-effort: set the epic's status (e.g. ``in_dev``) so the UI shows the plugin is
    actively working this epic. NEVER fails the run — a rejected transition (epic already past
    this point on a re-run) or a 409 from the transition machine is logged and ignored.
    """
    try:
        aidlc_auth.post_json(
            f"{base}/ws/{workspace_id}/epics/{epic_id}/status?gear_id={gear_id}",
            cfg, {"status": status}, timeout,
        )
        print(f"[aidlc] epic {epic_id} → status '{status}' (plugin started)")
    except SystemExit as exc:  # post_json exits on HTTP error — best-effort, keep going
        print(f"[aidlc] status mark '{status}' skipped (best-effort): {exc}")


def dev_epic_action(status: str) -> str:
    """Deterministic resume/loop decision for the develop plugin, by epic status.

    do     — fresh epic (pending/approved) → implement now
    resume — dev started but not accepted (dev_started/in_dev/active) → re-implement + re-review
    skip   — already accepted or beyond (dev_done/done/qa_started/qa_in_progress)
    blocked— epic blocked; needs unblocking first
    """
    s = (status or "").lower()
    if s in ("dev_done", "done", "qa_started", "qa_in_progress"):
        return "skip"
    if s in ("dev_started", "in_dev", "active"):
        return "resume"
    if s == "blocked":
        return "blocked"
    return "do"  # pending / approved / unknown → fresh


def _fetch_epic_stories_fallback(
    base: str, workspace_id: str, epic_id: str, gear_id: str, cfg: dict[str, Any], timeout: float
) -> list[dict[str, Any]]:
    """Fallback: GET /ws/{id}/epics/{epic_id}?gear_id={gear_id} and map its stories to bundle format.

    Called when the epic bundle returns an empty stories array — the central API
    does not always populate the stories artifact for epic-scoped bundles.
    Maps each story's ac-given/ac-when/ac-then acceptance criteria and
    description ("As a …, I want …, so that …") to the fields _compose_impl_tasks
    expects: story_id, as_a, i_want, so_that, ac_given, ac_when, ac_then, title,
    source_refs.
    """
    url = f"{base}/ws/{workspace_id}/epics/{epic_id}?gear_id={gear_id}"
    try:
        epic = aidlc_auth.get_json(url, cfg, timeout)
    except Exception as exc:
        print(f"[aidlc] epic fallback fetch failed ({exc}); stories will be empty")
        return []

    stories: list[dict[str, Any]] = []
    for feature in (epic.get("features") or []):
        for s in (feature.get("stories") or []):
            # Parse ac-given / ac-when / ac-then from acceptance_criteria list
            ac_map = {
                ac.get("id"): ac.get("criterion", "")
                for ac in (s.get("acceptance_criteria") or [])
            }
            # Parse "As a X, I want Y, so that Z" from description
            desc = s.get("description") or ""
            as_a = i_want = so_that = ""
            if "As a" in desc and "I want" in desc and "so that" in desc:
                try:
                    as_a = desc.split("As a ", 1)[1].split(", I want", 1)[0].strip()
                    i_want = desc.split(", I want ", 1)[1].split(", so that", 1)[0].strip()
                    so_that = desc.split(", so that ", 1)[1].strip()
                except IndexError:
                    pass
            stories.append({
                "story_id": s.get("id", ""),
                "id": s.get("id", ""),
                "title": s.get("title", ""),
                "as_a": as_a,
                "i_want": i_want,
                "so_that": so_that,
                "ac_given": ac_map.get("ac-given", ""),
                "ac_when": ac_map.get("ac-when", ""),
                "ac_then": ac_map.get("ac-then", ""),
                "source_refs": s.get("kb_trace_ids") or [],
                "screens": [],
                "story_type": s.get("story_type", "user"),
                "points": s.get("points"),
                "priority": s.get("priority"),
                "feature_id": feature.get("id", ""),
                "feature_title": feature.get("title", ""),
            })
    return stories


def _get_kb_loci(
    base: str,
    workspace_id: str,
    gear_id: str,
    cfg: dict[str, Any],
    timeout: float,
) -> dict[str, str]:
    """Fetch {kb_id: source_locus} for all code-level KB cards (CMP-*/API-*) from central.

    Uses the kind-based endpoint which returns the full inventory of code-extractable cards
    regardless of what the impact analysis cited. Returns only code-file loci.
    Empty dict if the endpoint is unavailable (degrades to local search fallback).
    """
    url = f"{base}/ws/{workspace_id}/kb-loci?gear_id={gear_id}"
    req = urllib.request.Request(url, headers=aidlc_auth.build_headers(cfg), method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw: dict[str, str] = json.loads(resp.read().decode("utf-8"))
        return {k: v for k, v in raw.items() if v and _is_code_locus(v)}
    except (urllib.error.HTTPError, urllib.error.URLError) as exc:
        print(f"[aidlc] kb-loci unavailable ({exc}); file paths will use local search fallback")
        return {}


def _best_locus_for_kind(kind: str, kb_loci: dict[str, str]) -> str | None:
    """Pick the best source_locus from the KB loci dict for a given component kind.

    Filters to matching extensions, then scores by preferred filename suffix.
    Returns the highest-scoring match, or None if no match.
    """
    target_exts = _KIND_EXTS.get(kind, ())
    prefs = _KIND_SUFFIX_PREFS.get(kind, ())
    if not target_exts:
        return None

    best: str | None = None
    best_score = -1
    for locus in kb_loci.values():
        path = locus.split(" §")[0].split(" #")[0].strip().lower()
        if not any(path.endswith(ext) for ext in target_exts):
            continue
        score = sum(1 for p in prefs if path.endswith(p))
        if score > best_score:
            best_score = score
            best = locus
    return best


# ── Local file search ────────────────────────────────────────────────────────────

_GENERIC_TERMS = frozenset({
    "component", "section", "page", "view", "module", "unit",
})

_LABEL_KIND_MAP = {
    "ui": ("angular", [".ts", ".html"], ["component.ts", "component.html"]),
    "service": ("java_springboot", [".java"], ["Service.java", "ServiceImpl.java", "Controller.java"]),
    "integration": ("ibm_esb", [".java", ".wsdl", ".xml"], [".java"]),
    "db": ("sql", [".sql"], [".sql"]),
}


def _extract_keywords(label: str) -> list[str]:
    """Extract searchable English keywords from a component label.

    'UI component — Reception Registration Screen — Renewal (受付登録情報) — Section 0'
    → ['reception', 'registration', 'renewal']
    """
    text = re.sub(r'\([^)]*\)', '', label)  # strip Japanese parenthetical
    for generic in ("UI component", "Service component", "Component", "Section"):
        text = text.replace(generic, " ")
    parts = re.split(r'[—\-–\s/]+', text)
    return [
        p.lower() for p in parts
        if len(p) >= 4 and p.isascii() and p.isalpha() and p.lower() not in _GENERIC_TERMS
    ]


def _label_to_kind(label: str) -> str:
    """
        Label to kind.
        :inputs: label (str) - the label
        :outputs: (str) - the str result
        """
    low = label.lower()
    if any(t in low for t in ("ui component", "angular", "front-end", "frontend")):
        return "ui"
    if any(t in low for t in ("service component", "back-end", "backend", "java", "spring")):
        return "service"
    if any(t in low for t in ("integration", "esb", "api", "wsdl")):
        return "integration"
    if any(t in low for t in ("database", "schema", "table", "sql", "migration")):
        return "db"
    return "ui"  # default: assume Angular for Japan Auto frontend-heavy corpus


def _detect_stack_from_label(label: str) -> str:
    """Fallback stack detection from component label when source_locus is unavailable."""
    kind = _label_to_kind(label)
    return _LABEL_KIND_MAP.get(kind, ("unknown", [], []))[0]


def _derive_filename(source_locus: str | None, component_id: str) -> str:
    """Real filename from resolved source_locus, or stub fallback."""
    if source_locus:
        path_part = source_locus.split(" §")[0].split(" #")[0].strip()
        return Path(path_part).name
    return f"{component_id}-stub.txt"


def _search_local_repos(
    keywords: list[str],
    kind: str,
    repo_map: list[dict[str, str]],
) -> str | None:
    """Search local repo roots for a file matching keywords and component kind.

    Returns a corpus-rooted path (using corpus_prefix from repo_map) on match,
    or None if no match found. Uses rglob — fast on developer-scale repos.
    """
    if not keywords or not repo_map:
        return None
    _, target_exts, pref_suffixes = _LABEL_KIND_MAP.get(kind, ("unknown", [".ts", ".java"], []))

    best_path: str | None = None
    best_score = 0

    for entry in repo_map:
        corpus_prefix = (entry.get("corpus_prefix") or "").replace("\\", "/").rstrip("/")
        local_root = entry.get("local_root") or ""
        if not local_root:
            continue
        root = Path(local_root)
        if not root.exists():
            continue
        for ext in target_exts:
            try:
                for fpath in root.rglob(f"*{ext}"):
                    fname = fpath.name.lower()
                    score = sum(1 for kw in keywords if kw in fname)
                    if score == 0:
                        continue
                    if any(fname.endswith(s.lower()) for s in pref_suffixes):
                        score += 1
                    if score > best_score:
                        best_score = score
                        try:
                            rel = fpath.relative_to(root)
                            best_path = f"{corpus_prefix}/{str(rel).replace(chr(92), '/')}"
                        except ValueError:
                            best_path = str(fpath).replace("\\", "/")
            except (PermissionError, OSError):
                continue

    return best_path if best_score > 0 else None


def _resolve_component_locus(
    comp: dict[str, Any],
    repo_map: list[dict[str, str]],
) -> str | None:
    """Return the best available source file path for a component.

    Priority:
      1. Existing source_locus on the component (already KB-grounded)
      2. Local filesystem search using label keywords + repo_map
    """
    if comp.get("source_locus"):
        return comp["source_locus"]
    label = comp.get("label") or comp.get("id") or ""
    keywords = _extract_keywords(label)
    if not keywords:
        return None
    return _search_local_repos(keywords, _label_to_kind(label), repo_map)


def _compose_impl_tasks(
    stories_doc: dict[str, Any],
    fsd_doc: dict[str, Any],
) -> list[dict[str, Any]]:
    """
        Compose impl tasks.
        :inputs: stories_doc (dict[str, Any]) - the stories doc; fsd_doc (dict[str, Any]) - the fsd doc
        :outputs: (list[dict[str, Any]]) - the list[dict[str, any]] result
        """
    stories = (stories_doc or {}).get("stories") or []
    fsd_frs: dict[str, dict] = {
        fr.get("id"): fr
        for fr in ((fsd_doc or {}).get("functional_requirements") or [])
        if fr.get("id")
    }
    fsd_brs = (fsd_doc or {}).get("business_rules") or []
    tasks = []
    for s in stories:
        sid = s.get("story_id") or s.get("id") or "?"
        as_a, i_want, so_that = s.get("as_a") or "", s.get("i_want") or "", s.get("so_that") or ""
        story_text = (
            f"As a {as_a}, I want {i_want}, so that {so_that}".strip()
            if (as_a or i_want or so_that) else ""
        )
        refs = s.get("source_refs") or []
        fr_deltas = [
            {
                "fr_id": fid,
                "title": fsd_frs[fid].get("title", ""),
                "as_is": fsd_frs[fid].get("as_is"),
                "to_be": fsd_frs[fid].get("to_be"),
                "source_type": "fsd_derived",
            }
            for fid in refs if fid in fsd_frs
        ]
        brs = [
            f"[{br.get('rule_id', '?')}] {(br.get('rule_text') or '')[:200]}"
            for br in fsd_brs
            if sid in (br.get("story_ids") or [])
        ]
        ac_given = s.get("ac_given") or ""
        ac_when = s.get("ac_when") or ""
        ac_then = s.get("ac_then") or ""
        tasks.append({
            "story_id": sid,
            "title": s.get("title") or "",
            "kb_ids": refs,
            "components_to_modify": [],
            "apis_to_implement": [],
            "integrations_to_wire": [],
            "screens_to_update": s.get("screens") or [],
            "ownership": "DEV-TODO",
            "gap_status": "gap",
            "match_confidence": 0.0,
            "status": "TODO",
            "source_type": "plugin_derived",
            "story_text": story_text,
            "gherkin_ac": (
                {"given": ac_given, "when": ac_when, "then": ac_then}
                if (ac_given or ac_when or ac_then) else {}
            ),
            "definition_of_done": s.get("definition_of_done") or [],
            "story_priority": s.get("priority") or "Medium",
            "story_points": s.get("points") or 0,
            "fr_deltas": fr_deltas,
            "business_rules_summary": brs,
        })
    return tasks


def _compose_code_stubs(
    srd_doc: dict[str, Any],
    impl_tasks: list[dict[str, Any]],
    repo_map: list[dict[str, str]],
    kb_loci: dict[str, str],
) -> list[dict[str, Any]]:
    """
        Compose code stubs.
        :inputs: srd_doc (dict[str, Any]) - the srd doc; impl_tasks (list[dict[str, Any]]) - the impl tasks; repo_map (list[dict[str, str]]) - the repo map; kb_loci (dict[str, str]) - the kb loci
        :outputs: (list[dict[str, Any]]) - the list[dict[str, any]] result
        """
    components = (srd_doc or {}).get("component_design") or []
    story_map: dict[str, str] = {}
    for ref in ((srd_doc or {}).get("story_refs") or []):
        sid = ref.get("story_id")
        for cid in (ref.get("components") or ref.get("component_ids") or []):
            story_map[cid] = sid
    fallback = impl_tasks[0]["story_id"] if impl_tasks else "_no-story_"
    task_by_story: dict[str, dict] = {t["story_id"]: t for t in impl_tasks}

    stubs = []
    for comp in components:
        cid = comp.get("id") or comp.get("component_id") or "?"
        label = comp.get("label") or ""
        kind = _label_to_kind(label)

        # Resolution priority:
        # 1. SRD source_locus (KB-grounded from Architecture stage)
        # 2. KB loci from central (real file paths from the KB extraction run)
        # 3. Local filesystem search via repo_map (fallback)
        if comp.get("source_locus"):
            resolved_locus = comp["source_locus"]
            source_type = "srd_derived"
        else:
            kb_match = _best_locus_for_kind(kind, kb_loci)
            if kb_match:
                resolved_locus = kb_match
                source_type = "kb_loci"
            else:
                resolved_locus = _resolve_component_locus(comp, repo_map)
                source_type = "local_search" if resolved_locus else "proposed"

        stack = _detect_stack(resolved_locus or "")
        if stack == "unknown":
            stack = _detect_stack_from_label(label)

        story_id = story_map.get(cid, fallback)
        task = task_by_story.get(story_id)
        enriched_comp = {**comp, "source_locus": resolved_locus}
        stubs.append({
            "story_id": story_id,
            "component_id": cid,
            "language": _detect_language(resolved_locus or ""),
            "stub_type": _detect_stub_type(comp.get("kind") or comp.get("type") or ""),
            "stack": stack,
            "filename": _derive_filename(resolved_locus, cid),
            "code": _stub_code(enriched_comp, task),
            "ownership": "DEV-TODO",
            "source_type": source_type,
            "source_locus": resolved_locus or None,
        })
    return stubs


def _compose_wiring(srd_doc: dict[str, Any]) -> list[dict[str, Any]]:
    """
        Compose wiring.
        :inputs: srd_doc (dict[str, Any]) - the srd doc
        :outputs: (list[dict[str, Any]]) - the list[dict[str, any]] result
        """
    return [
        {
            "integration_id": i.get("id") or i.get("integration_id") or "?",
            "label": i.get("label") or i.get("name") or "",
            "protocol": i.get("protocol"),
            "from_component": i.get("from_component") or i.get("from"),
            "to_component": i.get("to_component") or i.get("to"),
            "wiring_note": i.get("wiring_note") or i.get("note") or "",
            "ownership": "DEV-TODO",
            "status": "TODO",
        }
        for i in ((srd_doc or {}).get("integration_design") or [])
    ]


def _compose_gaps(srd_doc: dict[str, Any]) -> list[dict[str, Any]]:
    """
        Compose gaps.
        :inputs: srd_doc (dict[str, Any]) - the srd doc
        :outputs: (list[dict[str, Any]]) - the list[dict[str, any]] result
        """
    return [
        {
            "story_id": None,
            "component_id": "",
            "description": item.get("description") or str(item),
            "gap_status": "deferred",
            "sme_required": False,
            "source": "srd_inheritance",
        }
        for item in ((srd_doc or {}).get("open_items") or [])
        if item.get("description")
    ]


def _compose_dev_doc(
    bundle: dict[str, Any],
    docs: dict[str, Any],
    generated_at: str,
    repo_map: list[dict[str, str]],
    kb_loci: dict[str, str],
) -> dict[str, Any]:
    """Compose a DevDocument-conformant dict from the 4 bundle artifacts."""
    impact = docs.get("impact") or {}
    srd_doc = docs.get("srd") or {}
    impl_tasks = _compose_impl_tasks(docs.get("stories") or {}, docs.get("fsd") or {})
    code_stubs = _compose_code_stubs(srd_doc, impl_tasks, repo_map, kb_loci)

    # Build responsibility lookup from SRD component_design for meaningful "change" text
    responsibility_map: dict[str, str] = {
        (c.get("id") or ""): (c.get("responsibility") or c.get("label") or "")
        for c in (srd_doc.get("component_design") or [])
    }
    change_plan = [
        {
            "file": s["filename"],
            "layer": _stack_to_layer(s["stack"]),
            "action": "Modify existing file" if s.get("source_locus") else "Create new file",
            "change": responsibility_map.get(s["component_id"]) or f"Apply the required change in this file.",
            "component_id": s["component_id"],
        }
        for s in code_stubs
    ]
    # Build sub-agent execution steps for demo visibility
    agent_steps = build_agent_steps(code_stubs, impl_tasks)

    # Build design artifacts (HLD / LLD) — generated before implementation begins
    hld = _compose_hld(bundle, docs, agent_steps)
    lld = _compose_lld(docs, code_stubs, impl_tasks, kb_loci)

    return {
        "workspace_id": bundle.get("workspace_id", ""),
        "kb_version": bundle.get("pinned_kb_version") or "unpinned",
        "persona": "developer",
        "template_id": "aig-dev",
        "template_version": "v2",
        "requirement": bundle.get("requirement_text") or "",
        "change_class": (
            (lambda c: c.get("change_class") if isinstance(c, dict) else c)(
                impact.get("classification")
            ) or "Enhancement"
        ),
        "grounding_score": 0.85,
        "stub_count": sum(1 for s in code_stubs if not s.get("source_locus")),
        "change_plan": change_plan,
        "implementation_plan": impl_tasks,
        "code_stubs": code_stubs,
        "integration_wiring": _compose_wiring(docs.get("srd") or {}),
        "change_specs": [],
        "development_notes": [],
        "open_items": [],
        "dev_gaps": _compose_gaps(docs.get("srd") or {}),
        "codegen_files": [],
        "codegen_output_dir": None,
        "section_basis": {"source": "plugin-composed"},
        "abstained": False,
        "generated_at": generated_at,
        "agent_steps": agent_steps,
        "design_artifacts": {
            "hld": hld,
            "lld": lld,
        },
    }


# ── Markdown render helpers ──────────────────────────────────────────────────────

def _h(level: int, text: str) -> str:
    """
        H the _h operation.
        :inputs: level (int) - the level; text (str) - the text
        :outputs: (str) - the str result
        """
    return f"{'#' * level} {text}\n"


def _table(headers: list[str], rows: list[list[str]]) -> str:
    """
        Table the _table operation.
        :inputs: headers (list[str]) - the headers; rows (list[list[str]]) - the rows
        :outputs: (str) - the str result
        """
    col = len(headers)
    sep = " | ".join(["---"] * col)
    head = " | ".join(headers)
    lines = [f"| {head} |", f"| {sep} |"]
    for row in rows:
        padded = [str(c) for c in row] + [""] * (col - len(row))
        lines.append("| " + " | ".join(padded) + " |")
    return "\n".join(lines) + "\n"


def _code_block(code: str, lang: str = "") -> str:
    """
        Code block.
        :inputs: code (str) - the code; lang (str) - the lang
        :outputs: (str) - the str result
        """
    return f"```{lang}\n{code}\n```\n"


def _divider() -> str:
    """
        Divider the _divider operation.
        :inputs: None
        :outputs: (str) - the str result
        """
    return "\n---\n\n"


def _short(text: Any, limit: int = 240) -> str:
    """
        Short the _short operation.
        :inputs: text (Any) - the text; limit (int) - the limit
        :outputs: (str) - the str result
        """
    if isinstance(text, list):
        text = " ".join(str(x) for x in text)
    s = " ".join(str(text or "").split())
    return s if len(s) <= limit else s[: limit - 1] + "…"


def _extract_file_path(source_locus: str) -> str:
    """
        Extract file path.
        :inputs: source_locus (str) - the source locus
        :outputs: (str) - the str result
        """
    if not source_locus:
        return ""
    for sep in (" §", "§", " #", " @"):
        idx = source_locus.find(sep)
        if idx != -1:
            return source_locus[:idx].strip()
    return source_locus.strip()


def _extract_repo_name(file_path: str) -> str:
    """
        Extract repo name.
        :inputs: file_path (str) - the filesystem path
        :outputs: (str) - the str result
        """
    if not file_path:
        return "_unknown_"
    parts = file_path.replace("\\", "/").split("/")
    for i, part in enumerate(parts):
        if part.lower() in ("codebase",):
            if i + 1 < len(parts):
                return parts[i + 1]
    for i, part in enumerate(parts):
        if part == "Auto" and i + 1 < len(parts):
            return parts[i + 1]
    return parts[-2] if len(parts) >= 2 else file_path


# ── Markdown sections ────────────────────────────────────────────────────────────

def _sec_change_summary(doc: dict[str, Any]) -> str:
    """
        Sec change summary.
        :inputs: doc (dict[str, Any]) - the doc
        :outputs: (str) - the str result
        """
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    impl = doc.get("implementation_plan") or []
    stubs = doc.get("code_stubs") or []
    gaps = doc.get("dev_gaps") or []
    lines = [
        _h(2, "1. Change Summary"),
        "| Field | Value |",
        "| --- | --- |",
        f"| Workspace | `{doc.get('workspace_id', '?')}` |",
        f"| Generated | {ts} |",
        f"| KB Version | `{doc.get('kb_version', '?')}` |",
        f"| Change Class | **{doc.get('change_class', '?')}** |",
        f"| Grounding Score | {doc.get('grounding_score', 0):.2f} |",
        f"| Template | `{doc.get('template_id', '')}` `{doc.get('template_version', '')}` |",
        f"| Stories | {len(impl)} |",
        f"| Files to Change | {len(stubs)} |",
        f"| Open Gaps | {len(gaps)} |",
        "",
        "**Requirement:**",
        "",
        f"> {doc.get('requirement') or '_(not set)_'}",
        "",
    ]
    return "\n".join(lines)


def _format_story_block(task: dict[str, Any], doc: dict[str, Any]) -> str:
    """
        Format story block.
        :inputs: task (dict[str, Any]) - the task; doc (dict[str, Any]) - the doc
        :outputs: (str) - the str result
        """
    stubs = doc.get("code_stubs") or []
    story_stubs = [s for s in stubs if s.get("story_id") == task.get("story_id") and s.get("filename")]
    priority = task.get("story_priority") or "Medium"
    pts = f"{task.get('story_points', 0)}pts" if task.get("story_points") else "—pts"
    ownership_icon = {"AUTO": "[PASS] AUTO", "HYBRID": "[fast] HYBRID"}.get(task.get("ownership", ""), "[red] DEV-TODO")
    gap_icon = {"direct": "[green]", "derived": "[yellow]", "partial": "[yellow]"}.get(task.get("gap_status", ""), "[red]")
    change_class = doc.get("change_class") or "Enhancement"
    lines = [
        _h(3, f"{task.get('story_id', '?')} — {task.get('title') or task.get('story_id', '?')}"),
        f"`{priority}` `{pts}` `{change_class}` {gap_icon} `{task.get('gap_status', 'gap')}` {ownership_icon}\n",
    ]
    if story_stubs:
        lines.append("**[dir] Files to Touch:**\n")
        seen: set[str] = set()
        rows: list[list[str]] = []
        for stub in story_stubs:
            file_path = _extract_file_path(stub.get("source_locus") or "")
            repo = _extract_repo_name(file_path) if file_path else "_unknown_"
            key = file_path or stub.get("filename") or ""
            if key in seen:
                continue
            seen.add(key)
            action = "MODIFY" if file_path else "ADD"
            rows.append([f"`{repo}`", f"`{file_path or stub.get('filename')}`", f"`{stub.get('stack', '?')}`", action, f"`{stub.get('ownership', '?')}`"])
        if rows:
            lines.append(_table(["Repo", "File Path (corpus)", "Stack", "Action", "Ownership"], rows))
    elif task.get("kb_ids"):
        lines.append("> [WARN] **No file paths available** — run the Architecture stage to generate code stubs with concrete source loci. KB cards: " + ", ".join(f"`{k}`" for k in task["kb_ids"][:5]) + ".\n")
    else:
        lines.append("> [red] **DEV-TODO: No KB cards in scope for this story.** Manually locate relevant source files in `input/Auto/CodeBase/`.\n")

    story_text = task.get("story_text") or ""
    if story_text:
        lines.append(f"**User Story:**\n\n> {story_text}\n")
    else:
        lines.append("> [WARN] **Stories stage not yet run** — user story will appear here after running the Stories stage.\n")

    gherkin = task.get("gherkin_ac") or {}
    if gherkin:
        lines.append("**Acceptance Criteria (Gherkin):**\n")
        lines.append(_code_block(
            f"Given {gherkin.get('given', '[BA-TODO: specify precondition]')}\n"
            f"When  {gherkin.get('when', '[BA-TODO: specify trigger action]')}\n"
            f"Then  {gherkin.get('then', '[BA-TODO: specify observable outcome]')}",
            "gherkin",
        ))
    else:
        lines.append("**Acceptance Criteria:** [WARN] _Run Stories stage first — Gherkin Given/When/Then will appear here._\n")

    fr_deltas = task.get("fr_deltas") or []
    if fr_deltas:
        lines.append("**Functional Requirement Deltas (as-is → to-be):**\n")
        rows = [[f"`{d.get('fr_id', '?')}`", d.get("title", ""), d.get("as_is") or "_not documented_", d.get("to_be") or "`[DEV-TODO]`: determine from BA"] for d in fr_deltas]
        lines.append(_table(["FR ID", "Title", "Current Behaviour (as-is)", "Required Change (to-be)"], rows))

    brs = task.get("business_rules_summary") or []
    if brs:
        lines.append("**Applicable Business Rules:**\n")
        for rule in brs:
            lines.append(f"- {rule}")
        lines.append("")

    kb_ids = task.get("kb_ids") or []
    if kb_ids:
        lines.append(f"_KB cards: {' '.join(f'`{k}`' for k in kb_ids)}_\n")

    if story_stubs:
        lines.append("**Code Stubs:**\n")
        for stub in story_stubs:
            lines.append(f"##### `{stub.get('filename') or stub.get('component_id')}`")
            meta = f"KB: `{stub.get('component_id', '?')}` | Stack: `{stub.get('stack', '?')}` | Ownership: `{stub.get('ownership', '?')}`"
            if stub.get("source_locus"):
                meta += f"\nSource: `{stub['source_locus']}`"
            lines.append(meta + "\n")
            lines.append(_code_block(stub.get("code", ""), stub.get("language", "")))

    dod = task.get("definition_of_done") or []
    if dod:
        lines.append("**Definition of Done:**\n")
        for item in dod:
            lines.append(f"- [ ] {item}")
        lines.append("")
    else:
        lines.append("**Definition of Done:** `[DEV-TODO]` — derive from Gherkin AC\n")

    return "\n".join(lines)


def _sec_story_workbook(doc: dict[str, Any]) -> str:
    """
        Sec story workbook.
        :inputs: doc (dict[str, Any]) - the doc
        :outputs: (str) - the str result
        """
    impl = doc.get("implementation_plan") or []
    stubs = doc.get("code_stubs") or []
    has_stories = any(t.get("story_text") for t in impl)
    has_stubs = bool(stubs)
    note = (
        "> **Pipeline note:** Each story block requires: **Stories stage** (user story + Gherkin + DoD) · "
        "**FSD stage** (FR delta + business rules) · **Architecture stage** (code stubs).\n"
    )
    if not has_stories:
        note += ">\n> [WARN] **Stories stage output not found** — user story and Gherkin fields are showing as stubs.\n"
    if not has_stubs:
        note += ">\n> [WARN] **No code stubs generated** — Architecture stage SRD may have no CMP-*/API-* cards.\n"
    lines = [
        _h(2, "2. Story-by-Story Implementation Workbook"),
        "_Self-contained per-story developer handover. Each block: user story · Gherkin AC · FR delta · business rules · components + source loci · code stubs · Definition of Done._\n",
        "_**Handover instruction for Claude Code / developer:** Read Section 1 for the full requirement, then implement each story block in order._\n",
        note,
    ]
    if not impl:
        lines.append("> `[GAP]`: No implementation tasks found — SRD story_refs may be empty. Re-run the Architecture stage.\n")
        return "\n".join(lines)
    for task in impl:
        lines.append(_format_story_block(task, doc))
        lines.append(_divider())
    return "\n".join(lines)


def _sec_architecture_context(doc: dict[str, Any]) -> str:
    """
        Sec architecture context.
        :inputs: doc (dict[str, Any]) - the doc
        :outputs: (str) - the str result
        """
    stubs = doc.get("code_stubs") or []
    wiring = doc.get("integration_wiring") or []
    lines = [
        _h(2, "2. Architecture Context"),
        "_Extracted from the accepted SRD. Reference only — do not modify without Architect sign-off._\n",
    ]
    if wiring:
        lines.append(_h(3, "Integration Points"))
        rows = [[f"`{w.get('integration_id', '?')}`", w.get("label", ""), w.get("protocol") or "_ARCH-TODO_", w.get("from_component") or "_TBD_", w.get("to_component") or "_TBD_"] for w in wiring]
        lines.append(_table(["INT ID", "Label", "Protocol", "From", "To"], rows))
    if stubs:
        lines.append(_h(3, "Components in Scope"))
        seen: set[str] = set()
        for stub in stubs:
            cid = stub.get("component_id", "?")
            if cid in seen:
                continue
            seen.add(cid)
            locus = f"`{stub['source_locus']}`" if stub.get("source_locus") else "_no source locus_"
            lines.append(f"- **`{cid}`** — {stub.get('stub_type', 'component')} ({stub.get('stack', '?')}) at {locus}")
        lines.append("")
    return "\n".join(lines)


def _sec_full_code_stubs(doc: dict[str, Any]) -> str:
    """
        Sec full code stubs.
        :inputs: doc (dict[str, Any]) - the doc
        :outputs: (str) - the str result
        """
    stubs = doc.get("code_stubs") or []
    lines = [
        _h(2, "3. Files to Change"),
        "_Per-file implementation guidance — file path, what to change (as-is → to-be), and acceptance criteria. "
        "DEV-TODO items must be implemented before QA handover._\n",
    ]
    if not stubs:
        lines.append("> `[DEV-TODO]`: No files identified — check SRD component_design and KB card confidence.\n")
        return "\n".join(lines)
    by_story: dict[str, list] = {}
    for stub in stubs:
        by_story.setdefault(stub.get("story_id") or "_no-story_", []).append(stub)
    for story_id, story_stubs in by_story.items():
        lines.append(_h(3, f"Story: {story_id}"))
        for stub in story_stubs:
            lines.append(f"#### `{stub.get('filename') or stub.get('component_id')}`")
            parts = [f"KB: `{stub.get('component_id', '?')}`", f"Stack: `{stub.get('stack', '?')}`", f"Lang: `{stub.get('language', '?')}`", f"Ownership: `{stub.get('ownership', '?')}`"]
            if stub.get("source_locus"):
                parts.append(f"Source: `{stub['source_locus']}`")
            lines.append(" | ".join(parts) + "\n")
            lines.append(_code_block(stub.get("code", ""), stub.get("language", "")))
    return "\n".join(lines)


def _sec_integration_wiring(doc: dict[str, Any]) -> str:
    """
        Sec integration wiring.
        :inputs: doc (dict[str, Any]) - the doc
        :outputs: (str) - the str result
        """
    wiring = doc.get("integration_wiring") or []
    lines = [
        _h(2, "4. Integration Wiring Checklist"),
        "_One row per INT-* from the SRD. Protocol, endpoint, and from/to component must be confirmed before QA handover._\n",
    ]
    if not wiring:
        lines.append("> No integration tasks — either no INT-* cards in SRD, or all integrations are out-of-scope.\n")
        return "\n".join(lines)
    rows = [[f"`{w.get('integration_id', '?')}`", w.get("label", ""), w.get("protocol") or "`[ARCH-TODO]`", w.get("from_component") or "_TBD_", w.get("to_component") or "_TBD_", w.get("wiring_note") or "_—_", f"`{w.get('status', 'TODO')}`"] for w in wiring]
    lines.append(_table(["INT ID", "Label", "Protocol", "From", "To", "Wiring Note", "Status"], rows))
    lines += [
        "\n**Wiring verification steps:**\n",
        "- [ ] Confirm all ARCH-TODO protocols with Architect before implementation",
        "- [ ] Smoke-test each integration point in the dev environment",
        "- [ ] ESB integrations: validate via IBM ACE Toolkit (no source file changes)",
        "- [ ] Update this checklist with actual endpoint URLs before QA handover\n",
    ]
    return "\n".join(lines)


def _sec_rego_stubs(doc: dict[str, Any]) -> str:
    """
        Sec rego stubs.
        :inputs: doc (dict[str, Any]) - the doc
        :outputs: (str) - the str result
        """
    impl = doc.get("implementation_plan") or []
    lines = [
        _h(2, "5. REGO Policy Stubs"),
        "_Authorisation policy stubs — one per persona + capability combination affected by this change._\n",
    ]
    if not impl:
        lines.append("> No implementation tasks — REGO stubs skipped.\n")
        return "\n".join(lines)
    written: set[str] = set()
    for task in impl:
        for scr in (task.get("screens_to_update") or []):
            if scr in written:
                continue
            written.add(scr)
            rego = (
                f"package japan_auto.authz\n\n"
                f"# DEV-TODO: replace with real persona + capability rules\n"
                f"allow {{\n"
                f'  input.persona in {{"ba", "developer", "qa"}}\n'
                f'  input.screen == "{scr}"\n'
                f'  input.action in {{"read", "write"}}\n'
                f"}}\n"
            )
            lines.append(f"#### Screen: `{scr}`\n")
            lines.append(_code_block(rego, "rego"))
            lines.append("> `[DEV-TODO]`: confirm allowed personas from `personas.json` with Architect.\n")
    if not written:
        lines.append("> No screens in scope — REGO stubs not required for this change.\n")
    return "\n".join(lines)


def _sec_test_expectations(doc: dict[str, Any]) -> str:
    """
        Sec test expectations.
        :inputs: doc (dict[str, Any]) - the doc
        :outputs: (str) - the str result
        """
    impl = doc.get("implementation_plan") or []
    lines = [
        _h(2, "6. Test Expectations"),
        "_Auto-generated from Gherkin AC + Definition of Done. QA engineer: use as the starting point for the formal test plan._\n",
    ]
    if not impl:
        lines.append("> No implementation tasks — test expectations not generated.\n")
        return "\n".join(lines)
    for task in impl:
        gherkin = task.get("gherkin_ac") or {}
        dod = task.get("definition_of_done") or []
        if not gherkin and not dod:
            continue
        lines.append(_h(3, f"{task.get('story_id', '?')} — {task.get('title') or task.get('story_id', '?')}"))
        if gherkin:
            lines.append("**Happy-path test case (from Gherkin AC):**\n")
            lines.append(_code_block(
                f"Test: {task.get('story_id', '?')} — happy path\n"
                f"  Arrange: {gherkin.get('given', '[DEV-TODO]')}\n"
                f"  Act:     {gherkin.get('when', '[DEV-TODO]')}\n"
                f"  Assert:  {gherkin.get('then', '[DEV-TODO]')}",
                "plaintext",
            ))
        if dod:
            lines.append("**Completion checks:**\n")
            for item in dod:
                lines.append(f"- [ ] {item}")
            lines.append("")
        if gherkin:
            lines.append("**Negative test case (DEV-TODO — QA to specify):**\n")
            lines.append(_code_block(
                f"Test: {task.get('story_id', '?')} — negative / boundary\n"
                f"  Arrange: [DEV-TODO: invalid state or missing input]\n"
                f"  Act:     {gherkin.get('when', '[DEV-TODO]')}\n"
                f"  Assert:  [DEV-TODO: error / rejection behaviour]",
                "plaintext",
            ))
    return "\n".join(lines)


def _sec_gap_log(doc: dict[str, Any]) -> str:
    """
        Sec gap log.
        :inputs: doc (dict[str, Any]) - the doc
        :outputs: (str) - the str result
        """
    gaps = doc.get("dev_gaps") or []
    lines = [
        _h(2, "7. Gap Log"),
        "_All DEV-TODO items, compliance gaps, and SME-required gaps. Each must be resolved or escalated before QA handover._\n",
    ]
    if not gaps:
        lines.append("> [PASS] No gaps recorded. Review DEV-TODO comments in code stubs manually.\n")
        return "\n".join(lines)
    lines.append(_h(3, "Developer Gaps"))
    rows = [
        [
            gap.get("story_id") or "_—_",
            f"`{gap['component_id']}`" if gap.get("component_id") else "_—_",
            gap.get("description", ""),
            f"`{gap.get('gap_status', '?')}`",
            "[WARN] Yes" if gap.get("sme_required") else "No",
            f"`{gap.get('source', '?')}`",
        ]
        for gap in gaps
    ]
    lines.append(_table(["Story", "Component", "Description", "Status", "SME Required", "Source"], rows))
    lines += [
        "\n**Gap resolution process:**\n",
        "1. `compliance_gap` → escalate to Compliance team immediately (cannot defer)",
        "2. `gap` + `sme_required=true` → raise with BA/Architect in next standup",
        "3. `partial` → implement best-effort; flag in code comments; QA to test boundary",
        "4. `deferred` → create backlog ticket with workspace_id reference\n",
    ]
    return "\n".join(lines)


def _sec_handover_checklist(doc: dict[str, Any]) -> str:
    """
        Sec handover checklist.
        :inputs: doc (dict[str, Any]) - the doc
        :outputs: (str) - the str result
        """
    lines = [
        _h(2, "8. Handover Checklist"),
        "_Developer signs off on each item before handing over to QA._\n",
        _h(3, "Development"),
        "- [ ] All user stories implemented (no `TODO` left in Section 2)",
        "- [ ] All code stubs implemented (no `DEV-TODO` in Section 4)",
        "- [ ] All integration wirings confirmed (Section 5 — no ARCH-TODO protocols)",
        "- [ ] REGO policy stubs reviewed and updated with correct personas (Section 6)",
        "- [ ] Every code change has inline KB card ID comment: `// [CMP-xxx]` or `// [FR-xxx]`",
        "- [ ] SQL migrations written and DBA review requested (if Section 8 has DB gaps)",
        "- [ ] Flyway migration version number confirmed (no duplicate versions)",
        "",
        _h(3, "Quality"),
        "- [ ] Unit tests pass (≥ 80% coverage on changed files)",
        "- [ ] Happy-path test cases from Section 7 executed and passing",
        "- [ ] Negative test cases from Section 7 executed and passing",
        "- [ ] No Sonar issues / critical vulnerabilities introduced",
        "- [ ] OWASP checks pass (parameterised SQL, no hardcoded secrets)",
        "- [ ] Cyclomatic complexity ≤ 21 on all new functions",
        "",
        _h(3, "Governance"),
        "- [ ] Gap log (Section 8) — all `compliance_gap` items escalated",
        "- [ ] Gap log — all `sme_required=true` items have SME response recorded",
        "- [ ] KB IDs used in this document are all valid (no dangling refs)",
        "- [ ] Workspace advanced to QA_TESTING (`POST /ws/{id}/dev/accept`)",
        "",
        _h(3, "Sign-off"),
        "| Role | Name | Date |",
        "| --- | --- | --- |",
        "| Developer | _________________________ | __________ |",
        "| Architect | _________________________ | __________ |",
        "| BA | _________________________ | __________ |",
        "",
    ]
    return "\n".join(lines)


def _render_handover_md(doc: dict[str, Any]) -> str:
    """Render a DevDocument dict as the 9-section enterprise developer handover document.

    Produces output identical in structure to central's render_dev_markdown() — the same
    document the developer would download via GET /ws/{id}/dev/export.md.
    """
    kb_ver = doc.get("kb_version", "?")
    ws_id = doc.get("workspace_id", "?")
    sections = [
        _h(1, f"Developer Handover Document — {ws_id}"),
        f"_Generated by AIG Central Platform · Japan Auto · `{kb_ver}`_\n",
        "---\n",
        _sec_change_summary(doc),
        _divider(),
        _sec_architecture_context(doc),
        _divider(),
        _sec_full_code_stubs(doc),
        _divider(),
        _sec_integration_wiring(doc),
        _divider(),
        _sec_rego_stubs(doc),
        _divider(),
        _sec_test_expectations(doc),
        _divider(),
        _sec_gap_log(doc),
        _divider(),
        _sec_handover_checklist(doc),
    ]
    return "\n".join(sections)


# ── Main ─────────────────────────────────────────────────────────────────────────

def main() -> None:
    ap = argparse.ArgumentParser(
        description="Fetch bundle, compose DevDocument, upload to central, render handover doc."
    )
    ap.add_argument("workspace_id")
    ap.add_argument("--epic-id", default=None,
                    help="Epic ID for per-epic mode. Fetches the epic-scoped bundle "
                         "(stories filtered to this epic only) and writes output under "
                         ".aidlc/<ws_id>/epics/<epic_id>/.")
    ap.add_argument("--list-epics", action="store_true",
                    help="List all epics for the workspace and exit (no bundle fetch).")
    ap.add_argument("--gear-id", required=True,
                    help="Gear ID resolved in Step 0. Passed as ?gear_id= on all central API calls.")
    ap.add_argument("--config", default=None,
                    help="Path to aidlc.config.json (else $AIDLC_CONFIG or ./aidlc.config.json)")
    args = ap.parse_args()

    cfg = aidlc_auth.load_config(args.config)
    base = (cfg.get("central_base_url") or "").rstrip("/")
    if not base:
        sys.exit("[aidlc] config.central_base_url is required")
    timeout = float(cfg.get("request_timeout") or 120)
    repo_map: list[dict[str, str]] = cfg.get("repo_map") or []
    gear_id: str = args.gear_id

    # ── --list-epics: print epics table (with resume action) and exit ─────────
    if args.list_epics:
        epics = fetch_epics(base, args.workspace_id, gear_id, cfg, timeout)
        if not epics:
            print(f"[aidlc] No epics found for workspace {args.workspace_id}")
            return
        print(f"\n{'─' * 78}")
        print(f"  Epics — workspace: {args.workspace_id}  ({len(epics)} total)   [action = resume plan]")
        print(f"{'─' * 78}")
        for ep in epics:
            action = dev_epic_action(ep.get("status", ""))
            print(f"  [{action:7s}] {ep.get('id', '?'):30s}  ({ep.get('status', '?'):11s})  {ep.get('title', '')[:36]}")
        print(f"{'─' * 78}\n")
        print("[aidlc] action: do=fresh · resume=started-not-accepted · skip=already dev_done+ · blocked=unblock first")
        print(f"[aidlc] To fetch a per-epic bundle: python aidlc_bundle.py {args.workspace_id} --epic-id <EPIC_ID>")
        return

    # ── Determine output directory ────────────────────────────────────────────
    base_ws_dir = Path(cfg.get("workspace_dir") or ".aidlc") / args.workspace_id
    if args.epic_id:
        ws_dir = base_ws_dir / "epics" / args.epic_id
    else:
        ws_dir = base_ws_dir
    ws_dir.mkdir(parents=True, exist_ok=True)

    # 1 — fetch bundle (workspace-level or epic-scoped)
    if args.epic_id:
        # Mark this epic 'in_dev' up front so the UI shows dev is actively running it.
        # NOTE: central's EpicSummary model only accepts {pending, approved, in_dev, dev_done,
        # qa_in_progress, done, active, blocked}. 'dev_started' is NOT a valid value — writing it
        # persists an unreadable status that 500s every subsequent read. 'in_dev' is the valid
        # in-progress equivalent and maps to the same 'resume' action in dev_epic_action().
        mark_epic_status(base, args.workspace_id, args.epic_id, "in_dev", gear_id, cfg, timeout)
        bundle = fetch_epic_bundle(base, args.workspace_id, args.epic_id, gear_id, cfg, timeout)

        # Bug workaround: the epic-scoped bundle endpoint returns an empty stories
        # array even when stories exist on the epic.  Detect and fill from the epic
        # GET endpoint directly so _compose_impl_tasks has the full story set.
        stories_doc = next(
            (a.get("document") or {} for a in bundle.get("artifacts", []) if a.get("kind") == "stories"),
            {},
        )
        bundle_story_count = len(stories_doc.get("stories") or [])
        if bundle_story_count == 0:
            fallback_stories = _fetch_epic_stories_fallback(
                base, args.workspace_id, args.epic_id, gear_id, cfg, timeout
            )
            if fallback_stories:
                stories_doc["stories"] = fallback_stories
                # Patch the artifact in-place so _bundle_docs picks it up
                for art in bundle.get("artifacts", []):
                    if art.get("kind") == "stories":
                        art["document"] = stories_doc
                        break
                print(f"[aidlc] epic bundle fetched: epic={args.epic_id} "
                      f"stories=0 (bundle) → {len(fallback_stories)} (epic fallback injected)")
            else:
                print(f"[aidlc] epic bundle fetched: epic={args.epic_id} stories=0")
        else:
            print(f"[aidlc] epic bundle fetched: epic={args.epic_id} stories={bundle_story_count}")
    else:
        bundle = aidlc_auth.get_json(f"{base}/ws/{args.workspace_id}/bundle?gear_id={gear_id}", cfg, timeout)
    (ws_dir / "bundle.json").write_text(json.dumps(bundle, indent=2, ensure_ascii=False), encoding="utf-8")

    # 2 — resolve KB loci (all CMP-*/API-* cards with real file paths from the KB extraction run)
    kb_loci = _get_kb_loci(base, args.workspace_id, gear_id, cfg, timeout)
    print(f"[aidlc] kb-loci: {len(kb_loci)} code-file loci resolved")

    # 3 — compose DevDocument
    docs = _bundle_docs(bundle)
    generated_at = datetime.now(timezone.utc).isoformat()
    dev_doc = _compose_dev_doc(bundle, docs, generated_at, repo_map, kb_loci)

    # 4 — write dev.json locally
    (ws_dir / "dev.json").write_text(json.dumps(dev_doc, indent=2, ensure_ascii=False), encoding="utf-8")

    # 5 — upload to central (S3 + DB) — workspace-level only; epic trace is a separate POST
    if not args.epic_id:
        upload_result = aidlc_auth.post_json(f"{base}/ws/{args.workspace_id}/dev/upload?gear_id={gear_id}", cfg, dev_doc, timeout)
        print(f"[aidlc] upload: {upload_result.get('status', '?')} (kind={upload_result.get('kind', '?')})")

    # 6 — render handover markdown locally
    label = f"epic-{args.epic_id}" if args.epic_id else args.workspace_id
    md_path = ws_dir / f"dev-handover-{label}.md"
    md_path.write_text(_render_handover_md(dev_doc), encoding="utf-8")

    present = [a["kind"] for a in bundle.get("artifacts", []) if a.get("present")]
    print(f"[aidlc] bundle for {args.workspace_id}: artifacts={present or '(none)'} citations={len(bundle.get('citations') or [])}")
    print(f"[aidlc] wrote {ws_dir / 'bundle.json'}, {ws_dir / 'dev.json'}, {md_path}")

    # ── Generate and post design artifacts (HLD / LLD) before implementation ──
    design = dev_doc.get("design_artifacts") or {}
    hld_artifact = design.get("hld")
    lld_artifact = design.get("lld")

    if hld_artifact or lld_artifact:
        print(f"\n{'═' * 70}")
        print(f"  [design] Design Phase — producing artifacts before implementation")
        print(f"{'═' * 70}")

    if hld_artifact:
        print(f"\n  [list] HIGH-LEVEL DESIGN (HLD)")
        print(f"     Systems affected: {len(hld_artifact.get('systems_affected') or [])}")
        print(f"     Integration points: {len(hld_artifact.get('integration_points') or [])}")
        print(f"     Stories: {hld_artifact.get('story_count', 0)}  |  Components: {hld_artifact.get('component_count', 0)}")
        for stack in (hld_artifact.get("technology_stack") or []):
            print(f"     {stack.get('icon', '[config]')} {stack['agent']}: {stack['file_count']} file(s)")
        if hld_artifact.get("scope_notes"):
            print(f"     [WARN] Open items: {len(hld_artifact['scope_notes'])}")

        # Post HLD to central (best-effort, epic mode only)
        if args.epic_id:
            post_design_artifact(base, args.workspace_id, args.epic_id, hld_artifact, cfg, timeout)

    if lld_artifact:
        print(f"\n  [config] LOW-LEVEL DESIGN (LLD)")
        print(f"     Total files: {lld_artifact.get('total_files', 0)}")
        print(f"     Modify: {lld_artifact.get('files_to_modify', 0)}  |  Create: {lld_artifact.get('files_to_create', 0)}")
        print(f"     API contracts: {len(lld_artifact.get('api_contracts') or [])}")
        print(f"     DB changes: {len(lld_artifact.get('db_changes') or [])}")
        print(f"     FR deltas: {len(lld_artifact.get('fr_deltas') or [])}")
        print(f"     KB loci resolved: {lld_artifact.get('kb_loci_resolved', 0)}")

        # Post LLD to central (best-effort, epic mode only)
        if args.epic_id:
            post_design_artifact(base, args.workspace_id, args.epic_id, lld_artifact, cfg, timeout)

    if hld_artifact or lld_artifact:
        print(f"\n{'═' * 70}")

    # ── Print sub-agent execution plan (demo visibility) ─────────────────────
    agent_steps = dev_doc.get("agent_steps") or []
    if agent_steps:
        print(f"\n{'─' * 70}")
        print(f"  [bot] Sub-Agent Execution Plan — {len(agent_steps)} agent(s) for this epic")
        print(f"{'─' * 70}")
        for step in agent_steps:
            print(f"  {step['icon']}  Step {step['step']}: {step['agent']}")
            print(f"     Files: {step['file_count']}  |  Stories: {', '.join(step.get('story_ids') or ['—'])}")
            for f in step.get("files", [])[:5]:
                print(f"       → {f}")
            if step["file_count"] > 5:
                print(f"       … and {step['file_count'] - 5} more")
        print(f"{'─' * 70}\n")

        # Post each step to central for UI visibility (best-effort, epic mode only)
        if args.epic_id:
            for step in agent_steps:
                post_step_progress(base, args.workspace_id, args.epic_id, step, cfg, timeout)


if __name__ == "__main__":
    main()
