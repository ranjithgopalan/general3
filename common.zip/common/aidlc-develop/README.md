# aidlc-develop — local Developer cockpit

Run the **Developer** persona locally (docs/27). Central does intake → impact → FSD → architecture →
stories; this plugin binds to that workspace by `workspace_id`, pulls the grounded specs, and lets a
developer + Claude Code implement the change on the **live** repo(s), run tests, raise a PR, and sync
it back to central.

The database is the source of truth — this plugin reads the workspace bundle and writes back one PR
provenance artifact + one guarded state advance (`DEVELOPMENT → QA_TESTING`). No LangGraph state crosses
the machine boundary (docs/27 §4).

## Setup

1. Copy the config and fill in your local paths:
   ```
   cp config/aidlc.config.example.json aidlc.config.json
   ```
   - `central_base_url` — the agents backend (e.g. `http://localhost:8080`, or the deployed URL).
   - `repo_map` — one entry per subsystem: `corpus_prefix` (e.g. `input/Auto/CodeBase/AIG-Connect-Services`)
     → `local_root` (your checkout). Longest-prefix wins. **The repo name is irrelevant — only the mapping.**
   - `auth` — the ENV var *names* holding your bearer token / platform API key (never put secrets in the file).
     In dev (`PERSONA_GROUP_CHECK_ENABLED=off`) no token is needed; the persona resolves to the dev default.

2. Ensure `gh` is authenticated (`gh auth status`) for the PR step, and `python` is on PATH.

3. **Authentication (Okta — optional):** When the agents backend has `JWT_VALIDATION_ENABLED=true`,
   configure `auth.okta` in `aidlc.config.json` and run Step 0 before the workflow:
   ```
   python scripts/aidlc_auth.py login --config config/aidlc.config.json
   ```
   Opens the browser for a one-time Okta PKCE login; caches the session at `~/.aidlc/token.json`
   (shared with `aidlc-qa`). Set `"okta": null` for dev environments with auth disabled.

## Use

```
/aidlc-develop <workspace_id>
```

Or run the scripts directly:
```
python scripts/aidlc_bundle.py <workspace_id>          # → .aidlc/<id>/bundle.json + CONTEXT.md
python scripts/aidlc_sync_pr.py <workspace_id> --pr-url <URL> --branch <BRANCH> [--commit SHA] [--repo NAME]
```

## Local testing without the real repos

Copy the relevant `input/Auto/CodeBase/…` sub-tree into a personal repo (keep the internal folder layout),
map its `corpus_prefix → local_root`, and point `gh` at your personal remote. See docs/27 §6.2.

## Flow

`pull bundle → read CONTEXT.md → resolve repos → branch → grounded edit + tests → commit → gh pr create → sync back`.

Grounding is preserved locally: every edit ties to a change-spec + its KB IDs; KB IDs travel into the
commit + PR body; if a live file diverges from its `As-is`, the drift is flagged (never silently overwritten).
