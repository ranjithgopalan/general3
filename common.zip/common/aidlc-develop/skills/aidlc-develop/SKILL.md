---
name: aidlc-develop
description: Local Developer cockpit — bind to a central AIDLC workspace by workspace_id, iterate through its epics one at a time (sequential loop, stop-on-failure), fetch the epic-scoped grounded bundle per epic, clone/branch the affected repos per epic (ws-<ws_id>-<epic_id> branches), implement the epic's stories grounded in the specs, push, raise a PR per epic, sync each epic's PR trace back to central.
when_to_use: When the user runs /aidlc-develop with a workspace_id, or asks to implement/code a central AIDLC workspace locally and raise a PR.
disable-model-invocation: true
user-invocable: true
allowed-tools: Read, Write, Edit, Glob, Grep, Bash, TodoWrite
arguments: [workspace_id, gear_id?]
---

# aidlc-develop — local Developer cockpit

Implement central workspace **$1** end-to-end, **one epic at a time**.
Each epic gets its own branch (`ws-<ws_id>-<epic_id>`), its own PR, and its own trace record in central.

**Guardrails (non-negotiable):**
- **Grounded or flag.** Every edit ties to a change-spec + its KB IDs. If a live file diverges from its `As-is`, that is **KB drift** — record it; do NOT silently overwrite.
- **No fabrication.** Implement only what the spec + FSD/SRD state. Leave a clear `// AIDLC-TODO` and raise a question rather than inventing behaviour.
- **Traceability.** KB IDs travel into every commit message and the PR body.
- **Stop on first failure.** If any epic fails (code, push, PR, sync), stop the loop immediately. Report which epics completed and which failed. Do NOT continue to the next epic.

---

## Step toggles (read from `aidlc.config.json` → `steps` block)

| flag | when `false` |
|---|---|
| `branch` | skip setup + branch — edit directly on current working tree |
| `commit` | skip commit — leave edits staged for developer to review |
| `pr` | skip push + PR creation |
| `sync_back` | skip central write-back; workspace stays in DEVELOPMENT |

Read the `steps` block **before executing any step** and skip disabled steps silently.

---

## Automated Workflow

**Track every step with TodoWrite. Run all steps in sequence without pausing for confirmation — EXCEPT the per-epic review gate (Step 6.5), which is a mandatory human Accept/Rerun decision — and unless a step fails or a question is raised.**

Let `S = ${CLAUDE_PLUGIN_ROOT}/scripts` and `CFG = config/aidlc.config.json`.
Run all Python with `python` (not `py` / `python3`).

Ask the user for **three inputs** at the very start if not provided as arguments:
1. `workspace_id`  — the AIDLC workspace ID (argument `$1`)
2. `gear_id`       — the gear this workspace belongs to (argument `$2`, optional — resolved in Step 0 if absent)
3. `source_branch` — the remote branch to clone FROM (e.g. `master`, `develop`, `release-12.4`). This is also the PR base branch.

Once you have `workspace_id` and `source_branch`, proceed. `gear_id` is resolved in Step 0 if not provided.
Do **not** ask for `gear_id` up front — Step 0 handles it.

---

### Step 0 — Authenticate + Gear Resolution

```bash
python "$S/aidlc_auth.py" login --config "$CFG"
python "$S/aidlc_auth.py" list-gears --config "$CFG"
```

`login` is a no-op when `auth.okta` is null but the token ladder must always run.
`list-gears` calls `GET /gear-ids` and writes `.aidlc/_gears.json` (list of gears you have access to).

**Gear resolution — do this immediately after `list-gears` returns:**

Read `.aidlc/_gears.json`. Extract the list of `gear_id` values.

- If `$2` (gear_id) was provided as an argument:
  - Check it is present in the list.
  - **Not found → STOP.** Print:
    ```
    [STOP] gear_id '$2' is not in your accessible gears.
    Your gears: <list from _gears.json>
    Re-run with a valid gear_id or omit $2 to be prompted.
    ```
- If `$2` was not provided AND `.aidlc/$1/meta.json` exists with a `gear_id` field:
  - Use the cached `gear_id` (re-run resume path). Confirm to the user: `[aidlc] Using cached gear_id: <id>`.
- If `$2` was not provided AND no cache exists:
  - Use `AskUserQuestion` showing the gear list from `_gears.json` (gear_id + display_name + lob).
  - **No selection → STOP.** Print: `[STOP] No gear selected. Re-run and provide gear_id as $2 or select one when prompted.`

Set `RESOLVED_GEAR_ID` to the validated gear_id. Use it in every subsequent step.

---

### Step 0b — Workspace Validation

```bash
python "$S/aidlc_auth.py" list-workspaces --gear-id <RESOLVED_GEAR_ID> --config "$CFG"
```

Calls `GET /ws?gear_id=<RESOLVED_GEAR_ID>` and writes `.aidlc/_workspaces_<RESOLVED_GEAR_ID>.json`.

Read the file. Check whether `$1` (workspace_id) appears in the list (match on `workspace_id` or `id` field).

- **Not found → STOP.** Print:
  ```
  [STOP] Workspace '$1' was not found under gear <RESOLVED_GEAR_ID>.
  Check the workspace_id, or try a different gear_id.
  ```
- **Found** → cache the resolved context for re-runs:
  ```bash
  # write .aidlc/$1/meta.json
  {
    "workspace_id": "$1",
    "gear_id": "<RESOLVED_GEAR_ID>"
  }
  ```
  Print: `[aidlc] Workspace $1 confirmed under gear <RESOLVED_GEAR_ID> — proceeding.`

Continue to Step 0.5.

---

### Step 0.5 — Fetch and plan the epic loop

```bash
python "$S/aidlc_bundle.py" $1 --list-epics --gear-id <RESOLVED_GEAR_ID> --config "$CFG"
```

This prints all epics with a deterministic **`action`** column — the resume plan, computed from
each epic's status so a re-run after stopping mid-way does the right thing:

| `action` | Epic status | What to do this run |
|---|---|---|
| **do** | `pending` / `approved` | Implement fresh. |
| **resume** | `dev_started` / `in_dev` / `active` | Started but **not accepted** — re-implement and re-run the review gate (a prior session stopped here). |
| **skip** | `dev_done` / `done` / `qa_*` | Already accepted or beyond — do not touch (unless the user explicitly asks to redo). |
| **blocked** | `blocked` | Surface to the user; unblock before processing. |

**Build your loop plan from the `action` column:** process every epic marked **do** or **resume**
(in order); skip **skip**; surface **blocked** and ask the user. This is how the plugin resumes an
interrupted session correctly — an epic left at `dev_started` is re-done, an already-accepted
`dev_done` epic is not re-implemented.

- If no epics are found: fall back to workspace-level mode (skip the epic loop; use the original Step 1–8 flow with `python "$S/aidlc_bundle.py" $1 --config "$CFG"` and `--branch aidlc/$1-<slug>`).

---

### FOR EACH EPIC — execute Steps 1–7 sequentially

**Run the following block for each epic in order. If any step fails for epic N, STOP the loop. Do not start epic N+1.**

---

#### Step 1 — Fetch the epic-scoped bundle + design artifacts

```bash
python "$S/aidlc_bundle.py" $1 --epic-id <EPIC_ID> --gear-id <RESOLVED_GEAR_ID> --config "$CFG"
```

Writes:
- `.aidlc/$1/epics/<EPIC_ID>/bundle.json` — epic bundle (stories filtered to this epic; SRD/FSD/impact in full)
- `.aidlc/$1/epics/<EPIC_ID>/dev.json` — DevDocument with design artifacts and agent steps
- `.aidlc/$1/epics/<EPIC_ID>/dev-handover-epic-<EPIC_ID>.md` — per-epic handover doc

**The script now produces three outputs visible in the console and posted to central:**

1. **[design] Design Artifacts (HLD + LLD)** — generated BEFORE any code implementation begins:
   - **HLD (High-Level Design)** — systems affected, integration points, technology stack by agent lane, scope
   - **LLD (Low-Level Design)** — per-file change specs, API contracts, DB changes, FR deltas
   - Both are posted to central via `POST /ws/{id}/epics/{epic_id}/dev/design` so they appear in the UI timeline

2. **[bot] Sub-Agent Execution Plan** — classifies each code change into an agent lane:
   - [style] **UI / Axis Agent** — Angular/TypeScript component changes
   - [config] **API Coding Agent** — Java/Spring Boot service/controller changes
   - [db] **DB Agent** — SQL/migration changes
   - [link] **Integration Agent** — ESB/PEGA/WSDL integration changes
   - [list] **Forms Agent** — Adobe XDP form changes
   - Each step is posted to central via `POST /ws/{id}/epics/{epic_id}/dev/step`

3. **Handover doc** — the full 9-section developer handover with KB-grounded stubs

**Read the handover doc and dev.json immediately.** They contain:
- The epic's stories with their Gherkin AC, FR deltas, and business rules
- Target files (from SRD component_design source_locus) for the stories in this epic
- KB citations scoped to this epic
- The agent execution plan showing which sub-agent handles each file

Determine the implementation mode from the handover doc:
- **Change-spec mode** — change-specs list concrete target files → use those file paths.
- **Story-driven mode** — no change-specs but STORIES present → derive target files by grepping the cloned repos for screen/entity/field names from the stories.

---

#### Step 2 — Setup repos for this epic *(only if `steps.branch`)*

```bash
python "$S/aidlc_git.py" setup $1 \
  --epic-id <EPIC_ID> \
  --source-branch <SOURCE_BRANCH> \
  --config "$CFG"
```

This creates branch `ws-$1-<EPIC_ID>` in each affected repo (clones first if not present).

What it does automatically for **each repo in `repo_map`**:
1. Checks whether `local_root` is already a git repo (has `.git/`)
2. **If not cloned** → `git clone --depth 1 --branch <SOURCE_BRANCH> https://<PAT>@github.aig.net/...`
3. **If already cloned** → `git fetch origin <SOURCE_BRANCH>` + `git checkout <SOURCE_BRANCH>` + `git pull --ff-only`
4. Creates branch `ws-$1-<EPIC_ID>` locally and on the remote via GitHub API

After this step, every affected repo is on branch `ws-$1-<EPIC_ID>` and ready for edits.

> **If `steps.branch` is false:** skip this step. Edits happen on the current working tree.

---

#### Step 3 — Grounded code edits (this epic's stories only)

**Execute implementation by agent lane.** The dev.json `agent_steps` array lists the sub-agents
and their file assignments. Process each agent lane in order (UI/Axis → API → DB → Integration),
printing the agent name and icon as each lane begins:

```
[style] UI / Axis Agent — implementing 3 files...
[config] API Coding Agent — implementing 2 files...
[db] DB Agent — implementing 1 file...
```

For each story in this epic's handover doc:

1. **Open the target file** at its resolved local path.
2. **Compare** the live file to the `As-is` in the spec.
3. **Implement** the `To-be` change, anchored to KB IDs:
   ```typescript
   // [CMP-JAUTO-045] aidlc(ws-$1/<EPIC_ID>): Added email notification trigger
   ```
4. **KB drift:** if the live file does not match `As-is`, record it:
   - Append to `.aidlc/$1/epics/<EPIC_ID>/kb-drift.md` (human note)
   - Append to `.aidlc/$1/epics/<EPIC_ID>/kb-drift.json`:
     ```json
     {"file": "src/...", "expected": "...", "actual": "...", "kb_ids": ["CMP-001"]}
     ```
5. **Build + test** after each file change using the repo's own commands:
   - Angular: `ng build --configuration development` then `ng test --watch=false`
   - Java/Maven: `mvn test -pl <module>`
6. Fix compilation/test failures before moving to the next story. **If a story cannot be implemented, STOP and report — do NOT continue to Step 4 for this epic.**

Track the following for Step 7:
- `STORY_IDS` — list of story IDs implemented (from `story_id` fields in handover)
- `FILES_CHANGED` — list of relative file paths edited
- `KB_IDS_CITED` — KB IDs from the KB citation comments you added inline (`// [KB-ID]`)

---

#### Step 4 — Commit *(only if `steps.commit`)*

In each affected repo, stage only the files that implement this epic:

```bash
git add <changed-files>
git commit -m "aidlc($1/<EPIC_ID>): <epic-title>" \
           -m "Stories: <STORY_IDS>
KB citations: <KB_IDS_CITED>
Files: <FILES_CHANGED>"
```

Record the resulting `HEAD_SHA` (from `git rev-parse HEAD`) for Step 6.

---

#### Step 5 — Push epic branch *(only if `steps.pr`)*

```bash
python "$S/aidlc_git.py" push $1 --epic-id <EPIC_ID> --config "$CFG"
```

Pushes `ws-$1-<EPIC_ID>` to origin via HTTPS+PAT.
If push is rejected (remote diverged), STOP and report; do not continue to the next epic.

---

#### Step 6 — Create PR for this epic *(only if `steps.pr`)*

```bash
python "$S/aidlc_git.py" pr $1 \
  --epic-id <EPIC_ID> \
  --source-branch <SOURCE_BRANCH> \
  --title "aidlc($1/<EPIC_ID>): <epic-title>" \
  --kb-citations "<comma-separated-KB_IDS_CITED>" \
  --test-summary "<one-line test result>" \
  --config "$CFG"
```

- Creates one PR per affected repo.
- PR head = `ws-$1-<EPIC_ID>`, base = `<SOURCE_BRANCH>`.
- Record the returned `PR_URL` and `PR_NUMBER` for Step 7.

---

#### Step 6.5 — Review gate: **Accept** or **Rerun** (mandatory human decision)

**STOP and ask the user to review this epic's changes before recording anything to central.**
This is a deliberate pause — do NOT auto-continue. Present:

- The epic title + the PR link(s) from Step 6 (or the local diff if `steps.pr` is false).
- A concise summary of what changed: `FILES_CHANGED`, the `STORY_IDS` implemented, `KB_IDS_CITED`,
  the build/test result from Step 3, and any KB-drift notes.

Then present exactly two options and wait for the user's choice (use AskUserQuestion):

| Option | What happens |
|---|---|
| **Accept** | The epic's dev work is approved → proceed to **Step 7** (post the dev trace, which marks the epic `dev_done`). |
| **Rerun** | The user is not satisfied → capture their feedback, then **go back to Step 3** for THIS epic: revise the code edits (incorporating the feedback), re-run build + tests (Step 3), re-commit (Step 4), re-push the **same** branch `ws-$1-<EPIC_ID>` which updates the existing PR (Steps 5–6), and return to **Step 6.5** for another review. Loop until the user Accepts. Do NOT post the dev trace on a Rerun — nothing is recorded to central until Accept. |

> Rationale: the `dev-epic` trace = the record of **accepted** work. Rerun iterations must not
> leave traces or advance the epic status; only Accept does. If the user abandons the epic, STOP
> (stop-on-failure) — do not continue to the next epic.

---

#### Step 7 — On **Accept**: sync epic trace back to central *(only if `steps.sync_back`)*

Run this **only after the user clicked Accept in Step 6.5.** It posts the `dev-epic` traceability
artifact, creates GROUNDS links for each KB ID cited, and **advances the epic status to `dev_done`**
(so the workspace-level dev accept in Step 9 will pass its gate).

```bash
python "$S/aidlc_sync_pr.py" $1 \
  --epic-id <EPIC_ID> \
  --gear-id <RESOLVED_GEAR_ID> \
  --branch ws-$1-<EPIC_ID> \
  --pr-url <PR_URL> \
  --pr-number <PR_NUMBER> \
  --commit <HEAD_SHA> \
  --repo <REPO_NAME> \
  --story-ids "<comma-separated STORY_IDS>" \
  --files-changed "<comma-separated FILES_CHANGED>" \
  --kb-ids "<comma-separated KB_IDS_CITED>" \
  --summary "<one-line epic title>" \
  --config "$CFG"
```

If KB drift was recorded in Step 3, append:
```bash
  --drift-file ".aidlc/$1/epics/<EPIC_ID>/kb-drift.json"
```

**Include design artifacts and agent steps** (read from `.aidlc/$1/epics/<EPIC_ID>/dev.json`):
```bash
  --agent-steps '<JSON array from dev.json agent_steps>' \
  --design-artifacts '<JSON object from dev.json design_artifacts>'
```
These are optional — if omitted, the trace is still valid but the UI won't show the design/agent breakdown.

> If `steps.pr` was false (no PR raised), still post the trace with `--branch ws-$1-<EPIC_ID>` and omit `--pr-url`.

---

### END FOR EACH EPIC

After all epics are **Accepted** (or on stop-on-failure), continue to Step 8.

---

### Step 8 — Final summary

After all epics have been processed, print a summary table:

```
[PASS] aidlc-develop complete for workspace $1

Epic results:
┌─────────────────────────┬──────────────────────────────────┬────────┬─────────────────┬──────────┬───────┐
│ Epic ID                 │ Title                            │ Status │ Branch          │ Stories  │ Files │
├─────────────────────────┼──────────────────────────────────┼────────┼─────────────────┼──────────┼───────┤
│ epic-abc123456789       │ Payment method enhancement       │ [PASS] done │ ws-<ws>-epic-ab │ 3        │ 5     │
│ epic-def012345678       │ Receipt email notification       │ [PASS] done │ ws-<ws>-epic-de │ 2        │ 3     │
│ epic-ghi678901234       │ Renewal screen update            │ [FAIL] FAIL │ —               │ —        │ —     │
└─────────────────────────┴──────────────────────────────────┴────────┴─────────────────┴──────────┴───────┘

KB drift items: <total count> (see .aidlc/$1/epics/*/kb-drift.md)
```

The `Status` column reflects the epic's `status` in central: `dev_done` once its trace is posted
on Accept (Step 7); `—`/FAIL for an epic that was not accepted or failed. If a stop-on-failure
occurred, clearly state which epic failed and why, and what the developer should fix before re-running.

---

### Step 9 — Accept the Dev stage → advance workspace to QA_TESTING *(only if `steps.sync_back`)*

Run this **only when EVERY epic was Accepted** in Step 6.5 (each now `dev_done` in central).
Do NOT run it if any epic failed or was left unaccepted — resolve those first and re-run the plugin.

```bash
python "$S/aidlc_sync_pr.py" $1 --gear-id <RESOLVED_GEAR_ID> --summary "Dev complete — all epics accepted" --config "$CFG"
```

This workspace-level sync posts a `dev-pr` provenance artifact and fires the guarded
`DEVELOPMENT → QA_TESTING` transition — the single, deliberate hand-off into QA.

> **Alternative (explicit accept):** `POST /ws/$1/dev/accept`. This enforces the gate "all epics
> must be `dev_done`" and 409s if any epic is still pending — use it when you want the gate checked.
> The `aidlc_sync_pr.py $1` sync above advances via the workspace state machine and is what the
> plugin runs by default.

After this step the workspace is in **QA_TESTING** — hand off to the `aidlc-qa` plugin
(`/aidlc-qa $1`), which runs the symmetric per-epic Accept-style loop for Playwright specs.

Print the final line:
```
Workspace state: QA_TESTING — ready for /aidlc-qa $1   (all N epics dev_done)
```

---

## Notes

- **Config is the source of truth.** Every URL, credential, and repo mapping comes from
  `aidlc.config.json`. Never hardcode paths. Never print the PAT.
- **Epic-scoped branching.** Each epic produces one branch (`ws-<ws_id>-<epic_id>`), one PR,
  and one `dev-epic` trace record. The workspace-level `dev/pr` sync happens once at the very
  end (if `steps.sync_back` is true) only when ALL epics are done.
- **Multi-repo.** `setup`, `push`, and `pr` operate on all repos in `repo_map` that have a
  `remote_url`. The `identify_affected_repos()` helper in `aidlc_git.py` can scope branching
  to only repos whose corpus_prefix appears in the epic bundle.
- **No-epics fallback.** If `--list-epics` returns an empty list, fall back to the workspace-level
  flow (original Steps 1–8, `--branch aidlc/$1-<slug>`, no epic loop).
- **Grounding help.** During Step 3 you may call `kb.query` / `kb.read` (MCP) to deepen
  understanding. The change-specs + FSD/SRD in the handover doc are the authoritative intent.

## References (in-plugin)

`scripts/aidlc_bundle.py` (--epic-id, --list-epics) · `scripts/aidlc_git.py` (--epic-id, ws-* branches) · `scripts/aidlc_sync_pr.py` (--epic-id, --story-ids, --files-changed, --kb-ids) · `config/aidlc.config.example.json`
